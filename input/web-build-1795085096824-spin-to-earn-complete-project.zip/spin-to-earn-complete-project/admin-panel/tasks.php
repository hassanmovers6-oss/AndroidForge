<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create_task') {
        $title = trim((string)($_POST['title'] ?? ''));
        $cat = (string)($_POST['category'] ?? 'survey');
        $instr = trim((string)($_POST['instructions'] ?? ''));
        $reward = round((float)($_POST['reward_pkr'] ?? 0), 2);
        if ($title !== '' && $instr !== '' && $reward > 0) {
            $driver = strtolower((string)$pdo->getAttribute(PDO::ATTR_DRIVER_NAME));
            if ($driver === 'pgsql') {
                $tIns = $pdo->prepare("INSERT INTO tasks (title, category, instructions, reward_pkr, status) VALUES (?, ?, ?, ?, 'active') RETURNING id");
                $tIns->execute([$title, $cat, $instr, $reward]);
                $newTid = (int)$tIns->fetchColumn();
            } else {
                $pdo->prepare("INSERT INTO tasks (title, category, instructions, reward_pkr, status) VALUES (?, ?, ?, ?, 'active')")
                    ->execute([$title, $cat, $instr, $reward]);
                $newTid = (int)$pdo->lastInsertId();
            }
            Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'task_created', 'task', $newTid);
            $_SESSION['flash_success'] = 'Task created.';
        }
    } elseif ($action === 'delete_task') {
        $tid = (int)($_POST['task_id'] ?? 0);
        $pdo->prepare("UPDATE tasks SET status = 'archived' WHERE id = ?")->execute([$tid]);
        Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'task_archived', 'task', $tid);
        $_SESSION['flash_success'] = 'Task archived.';
    } elseif ($action === 'review_submission') {
        $subId = (int)($_POST['submission_id'] ?? 0);
        $decision = ($_POST['decision'] ?? '') === 'approve' ? 'approved' : 'rejected';
        $note = trim((string)($_POST['admin_note'] ?? ''));

        $pdo->beginTransaction();
        try {
            $sStmt = $pdo->prepare('SELECT * FROM task_submissions WHERE id = ? FOR UPDATE');
            $sStmt->execute([$subId]);
            $sub = $sStmt->fetch();

            if ($sub && $sub['status'] === 'pending') {
                $pdo->prepare(
                    'UPDATE task_submissions SET status = ?, admin_note = ?, reviewed_by_admin_id = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?'
                )->execute([$decision, $note ?: null, (int)$currentAdmin['id'], $subId]);

                if ($decision === 'approved') {
                    $uid = (int)$sub['user_id'];
                    $amt = (float)$sub['reward_snapshot_pkr'];
                    $ptsAwarded = max(1, (int)round($amt * 1000));

                    $pStmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ? FOR UPDATE');
                    $pStmt->execute([$uid]);
                    $curPts = $pStmt->fetchColumn();
                    if ($curPts === false) {
                        $pdo->prepare('INSERT INTO user_non_cash_points (user_id) VALUES (?)')->execute([$uid]);
                        $curPts = 0;
                    }
                    $newPtsBal = (int)$curPts + $ptsAwarded;

                    $pdo->prepare(
                        'UPDATE user_non_cash_points SET points_balance = points_balance + ?, lifetime_points_earned = lifetime_points_earned + ? WHERE user_id = ?'
                    )->execute([$ptsAwarded, $ptsAwarded, $uid]);

                    $refId = Security::generateUniqueRefId('TASKPTS');
                    $pdo->prepare(
                        "INSERT INTO non_cash_reward_history (user_id, source_type, points_delta, balance_after, reference_id, description)
                         VALUES (?, 'task_reward', ?, ?, ?, ?)"
                    )->execute([$uid, $ptsAwarded, $newPtsBal, $refId, "Approved task submission #{$subId}"]);

                    $pdo->prepare("INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, 'task')")
                        ->execute([$uid, 'Task Approved', "+{$ptsAwarded} non-cash points have been credited to your points balance."]);
                }
                Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], "task_submission_{$decision}", 'task_submission', $subId);
                $_SESSION['flash_success'] = "Submission #{$subId} marked {$decision}.";
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['flash_error'] = 'Failed to process submission review.';
        }
    }
    header('Location: tasks.php');
    exit;
}

$tasks = $pdo->query("SELECT * FROM tasks WHERE status != 'archived' ORDER BY id DESC")->fetchAll();
$submissions = $pdo->query(
    "SELECT ts.*, t.title AS task_title, u.email AS user_email
     FROM task_submissions ts
     INNER JOIN tasks t ON t.id = ts.task_id
     INNER JOIN users u ON u.id = ts.user_id
     ORDER BY CASE WHEN ts.status = 'pending' THEN 0 ELSE 1 END, ts.id DESC LIMIT 50"
)->fetchAll();

$pageTitle = 'Task Management';
$activeNav = 'tasks';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <h2 style="margin:0 0 12px;font-size:15px;">Create Task (Auto-Approved Non-Cash Points: 1,000 pts = Rs. 1)</h2>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create_task">
    <div><label>Title</label><input name="title" required></div>
    <div><label>Category</label>
      <select name="category">
        <option value="survey">Approved Survey</option>
        <option value="data_entry">Data Entry</option>
        <option value="website_testing">Website Testing</option>
        <option value="sponsor_task">Sponsor Task</option>
        <option value="assignment">Admin Assignment</option>
      </select>
    </div>
    <div><label>Reward Value (PKR equiv; 1 PKR = 1,000 pts)</label><input name="reward_pkr" type="number" step="0.01" min="1" required></div>
    <div style="grid-column:1 / -1;"><label>Instructions</label><textarea name="instructions" rows="2" required></textarea></div>
    <div><button type="submit" class="btn">Publish Task</button></div>
  </form>
</div>

<div class="card table-wrap">
  <h2 style="margin:0 0 12px;font-size:15px;">Task Submissions &amp; Auto-Approved Rewards</h2>
  <table>
    <thead><tr><th>ID</th><th>User</th><th>Task</th><th>Proof</th><th>Points Reward</th><th>Status</th><th>Review / Approval Note</th></tr></thead>
    <tbody>
      <?php foreach ($submissions as $sub):
        $pts = max(1, (int)round((float)$sub['reward_snapshot_pkr'] * 1000));
        $statusStr = (string)$sub['status'];
        $badgeClass = $statusStr === 'approved' ? 'badge-green' : ($statusStr === 'rejected' ? 'badge-red' : 'badge-amber');
      ?>
      <tr>
        <td>#<?= (int)$sub['id'] ?></td>
        <td><?= h($sub['user_email']) ?></td>
        <td><?= h($sub['task_title']) ?></td>
        <td><?= h($sub['proof_text']) ?></td>
        <td>+<?= number_format($pts) ?> pts <span style="color:#64748b;font-size:11px;">(Rs. <?= number_format((float)$sub['reward_snapshot_pkr'], 2) ?>)</span></td>
        <td><span class="badge <?= $badgeClass ?>"><?= h(strtoupper($statusStr)) ?></span></td>
        <td>
          <?php if ($statusStr === 'pending'): ?>
          <form method="post" style="display:flex;gap:6px;align-items:center;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="review_submission">
            <input type="hidden" name="submission_id" value="<?= (int)$sub['id'] ?>">
            <input name="admin_note" placeholder="Optional note" style="width:130px;">
            <button type="submit" name="decision" value="approve" class="btn btn-sm btn-green">Approve</button>
            <button type="submit" name="decision" value="reject" class="btn btn-sm btn-red">Reject</button>
          </form>
          <?php else: ?>
            <div><?= h($sub['admin_note'] ?: 'Reviewed') ?></div>
            <?php if (!empty($sub['reviewed_at'])): ?>
              <div style="color:#64748b;font-size:11px;"><?= h($sub['reviewed_at']) ?></div>
            <?php endif; ?>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card table-wrap">
  <h2 style="margin:0 0 12px;font-size:15px;">Active Tasks</h2>
  <table>
    <thead><tr><th>Title</th><th>Category</th><th>Reward</th><th>Action</th></tr></thead>
    <tbody>
      <?php foreach ($tasks as $t): ?>
      <tr>
        <td><?= h($t['title']) ?></td>
        <td><?= h($t['category']) ?></td>
        <td>Rs. <?= number_format((float)$t['reward_pkr'], 2) ?></td>
        <td>
          <form method="post" onsubmit="return confirmAction('Archive this task?')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_task">
            <input type="hidden" name="task_id" value="<?= (int)$t['id'] ?>">
            <button type="submit" class="btn btn-sm btn-red">Archive</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
