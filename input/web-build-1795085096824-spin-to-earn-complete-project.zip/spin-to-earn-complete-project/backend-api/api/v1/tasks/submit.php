<?php
/**
 * POST /api/v1/tasks/submit.php
 * Automatically approves valid task submissions and immediately credits
 * non-cash points (1000 points = Rs 1) without touching cash_wallets.
 * Enforces idempotency_key & completion limits inside an atomic transaction.
 * Compatible with both PostgreSQL/Supabase PDO and MySQL/MariaDB PDO.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';
require_once __DIR__ . '/../../../helpers/RateLimiter.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

RateLimiter::enforce('task_submit_' . $userId, 10, 300);

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
if (stripos($contentType, 'application/json') !== false) {
    $input = Response::readJsonBody();
} else {
    $input = $_POST;
}

$taskId = (int)($input['task_id'] ?? 0);
$proofText = trim((string)($input['proof_text'] ?? ''));
$idempotencyKey = trim((string)($input['idempotency_key'] ?? ''));

if ($taskId <= 0) {
    Response::json(422, false, 'Valid task_id is required.');
}
if ($idempotencyKey !== '' && (strlen($idempotencyKey) < 12 || strlen($idempotencyKey) > 80)) {
    Response::json(422, false, 'idempotency_key must be between 12 and 80 characters.');
}

$taskStmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND status = 'active' LIMIT 1");
$taskStmt->execute([$taskId]);
$task = $taskStmt->fetch();
if (!$task) {
    Response::json(404, false, 'Task not found or no longer active.');
}

$proofFilePath = null;
if (!empty($_FILES['proof_file']) && $_FILES['proof_file']['error'] === UPLOAD_ERR_OK) {
    $config = require __DIR__ . '/../../../config.php';
    $tmp = $_FILES['proof_file']['tmp_name'];
    if ($_FILES['proof_file']['size'] > $config['app']['max_upload_bytes']) {
        Response::json(422, false, 'Proof image exceeds 5 MB limit.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmp);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime])) {
        Response::json(422, false, 'Only JPEG, PNG, and WebP proof screenshots are allowed.');
    }
    $dir = $config['app']['upload_dir'];
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $safeName = 'proof_' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    $dest = $dir . '/' . $safeName;
    if (!move_uploaded_file($tmp, $dest)) {
        Response::json(500, false, 'Failed to store uploaded proof.');
    }
    $proofFilePath = $safeName;
}

if ((int)$task['requires_proof'] === 1 && $proofFilePath === null && mb_strlen($proofText) < 3) {
    Response::json(422, false, 'Please provide valid proof details or screenshot (min 3 characters).');
}

$driver = strtolower((string)$pdo->getAttribute(PDO::ATTR_DRIVER_NAME));
$hasIdemColumn = false;
try {
    if ($driver === 'pgsql') {
        $colStmt = $pdo->query(
            "SELECT 1 FROM information_schema.columns
             WHERE table_schema = current_schema()
               AND table_name = 'task_submissions'
               AND column_name = 'idempotency_key'
             LIMIT 1"
        );
    } else {
        $colStmt = $pdo->query(
            "SELECT 1 FROM information_schema.columns
             WHERE table_schema = DATABASE()
               AND table_name = 'task_submissions'
               AND column_name = 'idempotency_key'
             LIMIT 1"
        );
    }
    $hasIdemColumn = (bool)$colStmt->fetchColumn();
} catch (Throwable $e) {
    $hasIdemColumn = false;
}

$effectiveIdemKey = $idempotencyKey !== ''
    ? $idempotencyKey
    : ('srv_task_' . $userId . '_' . $taskId . '_' . bin2hex(random_bytes(8)));

$rewardPkr = round((float)$task['reward_pkr'], 2);
// Conversion rule: 1000 non-cash points = Rs 1.00 (cash_wallets is never credited on task completion)
$pointsAwarded = max(1, (int)round($rewardPkr * 1000));

$pdo->beginTransaction();
try {
    // Lock user's non-cash points row to serialize concurrent task submissions
    $lockStmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ? FOR UPDATE');
    $lockStmt->execute([$userId]);
    $currentPoints = $lockStmt->fetchColumn();
    if ($currentPoints === false) {
        $pdo->prepare('INSERT INTO user_non_cash_points (user_id) VALUES (?)')->execute([$userId]);
        $currentPoints = 0;
    }
    $currentPoints = (int)$currentPoints;

    // 1. Idempotency check if column exists and client provided idempotency_key
    if ($hasIdemColumn && $idempotencyKey !== '') {
        $idemStmt = $pdo->prepare(
            'SELECT id, status, reward_snapshot_pkr FROM task_submissions WHERE idempotency_key = ? LIMIT 1'
        );
        $idemStmt->execute([$idempotencyKey]);
        if ($existingSub = $idemStmt->fetch()) {
            $pdo->rollBack();
            Response::json(409, false, 'Duplicate task submission blocked.', [
                'already_processed'   => true,
                'submission_id'       => (int)$existingSub['id'],
                'status'              => (string)$existingSub['status'],
                'reward_snapshot_pkr' => round((float)$existingSub['reward_snapshot_pkr'], 2),
                'points_awarded'      => max(1, (int)round((float)$existingSub['reward_snapshot_pkr'] * 1000)),
                'points_balance'      => $currentPoints,
            ]);
        }
    }

    // 2. Enforce per-user task completion limit inside transaction lock
    $countStmt = $pdo->prepare(
        "SELECT COUNT(*) FROM task_submissions WHERE task_id = ? AND user_id = ? AND status IN ('pending', 'approved')"
    );
    $countStmt->execute([$taskId, $userId]);
    if ((int)$countStmt->fetchColumn() >= (int)$task['max_completions_per_user']) {
        $pdo->rollBack();
        Response::json(409, false, 'You have already reached the submission limit for this task.');
    }

    // 3. Prevent identical proof text resubmission for the same task
    if ($proofText !== '') {
        $dupProofStmt = $pdo->prepare(
            "SELECT id FROM task_submissions
             WHERE task_id = ? AND user_id = ? AND proof_text = ? AND status IN ('pending', 'approved')
             LIMIT 1"
        );
        $dupProofStmt->execute([$taskId, $userId, $proofText]);
        if ($dupProofStmt->fetchColumn()) {
            $pdo->rollBack();
            Response::json(409, false, 'This task proof has already been submitted.');
        }
    }

    $autoNote = 'Auto-approved upon valid submission';
    if ($hasIdemColumn) {
        $sql = $driver === 'pgsql'
            ? "INSERT INTO task_submissions
               (task_id, user_id, proof_text, proof_file_path, reward_snapshot_pkr, status, admin_note, reviewed_at, idempotency_key)
               VALUES (?, ?, ?, ?, ?, 'approved', ?, CURRENT_TIMESTAMP, ?) RETURNING id"
            : "INSERT INTO task_submissions
               (task_id, user_id, proof_text, proof_file_path, reward_snapshot_pkr, status, admin_note, reviewed_at, idempotency_key)
               VALUES (?, ?, ?, ?, ?, 'approved', ?, CURRENT_TIMESTAMP, ?)";
        $ins = $pdo->prepare($sql);
        $ins->execute([
            $taskId,
            $userId,
            $proofText !== '' ? $proofText : null,
            $proofFilePath,
            $rewardPkr,
            $autoNote,
            $effectiveIdemKey,
        ]);
    } else {
        $sql = $driver === 'pgsql'
            ? "INSERT INTO task_submissions
               (task_id, user_id, proof_text, proof_file_path, reward_snapshot_pkr, status, admin_note, reviewed_at)
               VALUES (?, ?, ?, ?, ?, 'approved', ?, CURRENT_TIMESTAMP) RETURNING id"
            : "INSERT INTO task_submissions
               (task_id, user_id, proof_text, proof_file_path, reward_snapshot_pkr, status, admin_note, reviewed_at)
               VALUES (?, ?, ?, ?, ?, 'approved', ?, CURRENT_TIMESTAMP)";
        $ins = $pdo->prepare($sql);
        $ins->execute([
            $taskId,
            $userId,
            $proofText !== '' ? $proofText : null,
            $proofFilePath,
            $rewardPkr,
            $autoNote,
        ]);
    }

    $submissionId = $driver === 'pgsql' ? (int)$ins->fetchColumn() : (int)$pdo->lastInsertId();
    $newPointsBalance = $currentPoints + $pointsAwarded;

    // 4. Credit user_non_cash_points immediately (never cash_wallets)
    $pdo->prepare(
        'UPDATE user_non_cash_points
         SET points_balance = points_balance + ?, lifetime_points_earned = lifetime_points_earned + ?
         WHERE user_id = ?'
    )->execute([$pointsAwarded, $pointsAwarded, $userId]);

    // 5. Log non-cash reward history
    $refId = Security::generateUniqueRefId('TASKPTS');
    $pdo->prepare(
        "INSERT INTO non_cash_reward_history (user_id, source_type, points_delta, balance_after, reference_id, description)
         VALUES (?, 'task_reward', ?, ?, ?, ?)"
    )->execute([
        $userId,
        $pointsAwarded,
        $newPointsBalance,
        $refId,
        "Auto-approved task #{$submissionId}: " . mb_substr((string)$task['title'], 0, 120),
    ]);

    // 6. Send user notification
    $pdo->prepare(
        "INSERT INTO notifications (user_id, title, message, category) VALUES (?, ?, ?, 'task')"
    )->execute([
        $userId,
        'Task Approved',
        "+{$pointsAwarded} non-cash points were automatically credited for completing \"{$task['title']}\".",
    ]);

    Security::writeAuditLog($pdo, 'user', $userId, 'task_auto_approved', 'task_submission', $submissionId, [
        'task_id'        => $taskId,
        'points_awarded' => $pointsAwarded,
        'reference_id'   => $refId,
    ]);

    $pdo->commit();

    Response::json(201, true, "Task approved! +{$pointsAwarded} non-cash points credited.", [
        'submission_id'       => $submissionId,
        'status'              => 'approved',
        'reward_snapshot_pkr' => $rewardPkr,
        'points_awarded'      => $pointsAwarded,
        'points_balance'      => $newPointsBalance,
        'reference_id'        => $refId,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    Response::json(500, false, 'Failed to process task submission.');
}
