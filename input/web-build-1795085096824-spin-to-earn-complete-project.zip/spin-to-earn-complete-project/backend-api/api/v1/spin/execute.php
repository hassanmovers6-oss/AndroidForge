<?php
/**
 * POST /api/v1/spin/execute.php
 * Server-authoritative spin execution:
 * - Enforces server UTC daily limit (5/day default; immune to device clock manipulation)
 * - Enforces idempotency_key to prevent duplicate spin requests
 * - Computes weighted random slice strictly on server (<500 non-cash points)
 * - Stores every spin in spin_history + non_cash_reward_history atomically
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';
require_once __DIR__ . '/../../../helpers/RateLimiter.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

RateLimiter::enforce('spin_exec_' . $userId, 12, 60);

if (Security::getSetting($pdo, 'spins_enabled', '1') !== '1') {
    Response::json(403, false, 'Spin wheel is temporarily paused by administrator.');
}

$body = Response::readJsonBody();
$idempotencyKey = trim((string)($body['idempotency_key'] ?? ''));
$deviceId = substr(trim((string)($body['device_fingerprint'] ?? '')), 0, 128);

if (strlen($idempotencyKey) < 16 || strlen($idempotencyKey) > 80) {
    Response::json(422, false, 'A valid idempotency_key (16-80 chars) is required.');
}

$todayUtc = gmdate('Y-m-d');
$dailyLimit = (int)Security::getSetting($pdo, 'daily_spin_limit', '5');

$pdo->beginTransaction();
try {
    // Lock user's non-cash points row to serialize concurrent spin requests for the same user
    $lockStmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ? FOR UPDATE');
    $lockStmt->execute([$userId]);
    $currentPoints = $lockStmt->fetchColumn();
    if ($currentPoints === false) {
        $pdo->prepare('INSERT INTO user_non_cash_points (user_id) VALUES (?)')->execute([$userId]);
        $currentPoints = 0;
    }
    $currentPoints = (int)$currentPoints;

    // Duplicate spin request check
    $dupStmt = $pdo->prepare('SELECT id, slice_id, points_awarded FROM spin_history WHERE idempotency_key = ? LIMIT 1');
    $dupStmt->execute([$idempotencyKey]);
    if ($existing = $dupStmt->fetch()) {
        $pdo->rollBack();
        Response::json(409, false, 'Duplicate spin request blocked.', [
            'already_processed' => true,
            'slice_id'          => (int)$existing['slice_id'],
            'points_awarded'    => (int)$existing['points_awarded'],
        ]);
    }

    // Server-time daily spin count check
    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM spin_history WHERE user_id = ? AND spin_date_utc = ?');
    $countStmt->execute([$userId, $todayUtc]);
    $usedToday = (int)$countStmt->fetchColumn();

    if ($usedToday >= $dailyLimit) {
        $pdo->rollBack();
        Response::json(429, false, "Daily spin limit ({$dailyLimit}) reached. Resets at 00:00 UTC.");
    }

    // Load active slices (<500 points enforced)
    $slices = $pdo->query(
        'SELECT id, slice_index, label, points_value, probability_weight
         FROM spin_reward_settings
         WHERE is_active = 1 AND points_value > 0 AND points_value < 500
         ORDER BY slice_index ASC'
    )->fetchAll();

    if (empty($slices)) {
        $pdo->rollBack();
        Response::json(500, false, 'No active spin slices configured.');
    }

    // Weighted random selection using cryptographic random_int
    $totalWeight = 0;
    foreach ($slices as $s) {
        $totalWeight += max(1, (int)round((float)$s['probability_weight'] * 100));
    }
    $roll = random_int(1, $totalWeight);
    $acc = 0;
    $winningSlice = $slices[0];
    foreach ($slices as $s) {
        $acc += max(1, (int)round((float)$s['probability_weight'] * 100));
        if ($roll <= $acc) {
            $winningSlice = $s;
            break;
        }
    }

    $pointsAwarded = (int)$winningSlice['points_value'];
    $newBalance = $currentPoints + $pointsAwarded;

    // Suspicious rapid spin detection (< 3 seconds since previous spin)
    $lastSpinStmt = $pdo->prepare('SELECT created_at FROM spin_history WHERE user_id = ? ORDER BY id DESC LIMIT 1');
    $lastSpinStmt->execute([$userId]);
    $lastSpinTime = $lastSpinStmt->fetchColumn();
    $suspicious = ($lastSpinTime && (time() - strtotime((string)$lastSpinTime)) < 3) ? 1 : 0;

    $pdo->prepare(
        'INSERT INTO spin_history (user_id, spin_date_utc, slice_id, points_awarded, idempotency_key, ip_address, device_id, flagged_suspicious)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $userId,
        $todayUtc,
        (int)$winningSlice['id'],
        $pointsAwarded,
        $idempotencyKey,
        Security::clientIp(),
        $deviceId ?: null,
        $suspicious,
    ]);

    $pdo->prepare(
        'UPDATE user_non_cash_points
         SET points_balance = points_balance + ?, lifetime_points_earned = lifetime_points_earned + ?
         WHERE user_id = ?'
    )->execute([$pointsAwarded, $pointsAwarded, $userId]);

    $refId = Security::generateUniqueRefId('SPIN');
    $pdo->prepare(
        "INSERT INTO non_cash_reward_history (user_id, source_type, points_delta, balance_after, reference_id, description)
         VALUES (?, 'spin_wheel', ?, ?, ?, ?)"
    )->execute([
        $userId,
        $pointsAwarded,
        $newBalance,
        $refId,
        "Spin Wheel non-cash reward ({$winningSlice['label']})",
    ]);

    $pdo->commit();

    $newUsed = $usedToday + 1;
    Response::json(200, true, "You won {$pointsAwarded} non-cash points!", [
        'status'          => 'approved',
        'slice_id'        => (int)$winningSlice['id'],
        'slice_index'     => (int)$winningSlice['slice_index'],
        'label'           => $winningSlice['label'],
        'points_awarded'  => $pointsAwarded,
        'points_balance'  => $newBalance,
        'used_today'      => $newUsed,
        'remaining_today' => max(0, $dailyLimit - $newUsed),
        'reference_id'    => $refId,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    Response::json(500, false, 'Failed to execute spin.');
}
