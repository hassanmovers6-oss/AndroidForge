# Keep generic signatures, inner classes, enclosing methods, exceptions, and annotations for Retrofit & Gson
-keepattributes Signature,InnerClasses,EnclosingMethod,Exceptions,*Annotation*

# Keep custom SpinWheelView animated property setter used by ObjectAnimator
-keepclassmembers class com.spintoearn.app.ui.custom.SpinWheelView {
    public void setWheelRotation(float);
}

# Keep API data models & Gson @SerializedName fields (preserve generic signatures & constructors)
-keep class com.spintoearn.app.data.model.** { *; }
-keepclassmembers class com.spintoearn.app.data.model.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Comprehensive Gson & TypeToken rules for R8 Full Mode (prevents TypeToken missing type argument crash)
-keep class com.google.gson.** { *; }
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken { *; }
-keepclassmembers class * extends com.google.gson.reflect.TypeToken { *; }
-keep,allowobfuscation,allowshrinking class * extends com.google.gson.TypeAdapter { *; }
-keep,allowobfuscation,allowshrinking class * implements com.google.gson.TypeAdapterFactory { *; }
-keep,allowobfuscation,allowshrinking class * implements com.google.gson.JsonSerializer { *; }
-keep,allowobfuscation,allowshrinking class * implements com.google.gson.JsonDeserializer { *; }

# Keep Kotlin Metadata & Reflection signatures used by Gson/Retrofit
-keep class kotlin.Metadata { *; }

# Retrofit 2 & OkHttp 4 rules
-keep,allowobfuscation,allowshrinking interface com.spintoearn.app.data.api.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-keep,allowobfuscation,allowshrinking class retrofit2.Response { *; }
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation { *; }
-dontwarn retrofit2.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
-dontwarn com.google.errorprone.annotations.**

# Keep Google Mobile Ads SDK classes
-keep class com.google.android.gms.ads.** { *; }
-keep class com.spintoearn.app.ads.AdMobManager { *; }
