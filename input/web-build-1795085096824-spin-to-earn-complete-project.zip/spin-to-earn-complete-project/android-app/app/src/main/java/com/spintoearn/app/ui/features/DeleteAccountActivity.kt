package com.spintoearn.app.ui.features

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.ActivityDeleteAccountBinding
import com.spintoearn.app.ui.auth.LoginActivity
import kotlinx.coroutines.launch

class DeleteAccountActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDeleteAccountBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeleteAccountBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnConfirmDelete.setOnClickListener {
            val password = binding.etConfirmPassword.text.toString()
            if (password.isEmpty()) {
                Toast.makeText(this, "Enter your password to confirm deletion.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.btnConfirmDelete.isEnabled = false
            lifecycleScope.launch {
                try {
                    val res = ApiClient.getService(this@DeleteAccountActivity).deleteAccount(
                        mapOf("password" to password, "reason" to "In-app user request")
                    )
                    Toast.makeText(
                        this@DeleteAccountActivity,
                        res.message ?: if (res.success) "Account deleted." else "Unable to delete account.",
                        Toast.LENGTH_LONG
                    ).show()
                    if (res.success) {
                        SessionManager(this@DeleteAccountActivity).clearSession()
                        startActivity(Intent(this@DeleteAccountActivity, LoginActivity::class.java))
                        finishAffinity()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@DeleteAccountActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
                } finally {
                    binding.btnConfirmDelete.isEnabled = true
                }
            }
        }
    }
}
