package com.spintoearn.app.ui.features

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.model.TaskItem
import com.spintoearn.app.databinding.ActivityTasksBinding
import com.spintoearn.app.databinding.ItemListRowBinding
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

class TasksActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTasksBinding
    private var isSubmitting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTasksBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        loadTasks()
    }

    private fun loadTasks() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@TasksActivity).getTasks()
                if (res.success && res.data != null) {
                    binding.rvTasks.adapter = TaskAdapter(res.data.tasks.orEmpty()) { task ->
                        openProofDialog(task)
                    }
                } else {
                    Toast.makeText(this@TasksActivity, res.message ?: "Unable to load tasks.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@TasksActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshDashboardInBackground() {
        lifecycleScope.launch {
            try {
                ApiClient.getService(this@TasksActivity).getDashboard()
            } catch (_: Exception) {
                // Non-fatal background cache sync
            }
        }
    }

    private fun openProofDialog(task: TaskItem) {
        if (!task.canSubmit) {
            Toast.makeText(this, "Submission limit reached for this task.", Toast.LENGTH_SHORT).show()
            return
        }
        if (isSubmitting) {
            Toast.makeText(this, "Task submission in progress...", Toast.LENGTH_SHORT).show()
            return
        }
        val rewardPts = if (task.rewardPoints > 0) task.rewardPoints else max(1, (task.rewardPkr * 1000.0).roundToInt())
        val input = EditText(this).apply { hint = task.proofPlaceholder ?: "Enter proof details" }
        MaterialAlertDialogBuilder(this)
            .setTitle(task.title ?: "Reward Task")
            .setMessage("${task.instructions.orEmpty()}\n\nInstant Reward: +$rewardPts non-cash points")
            .setView(input)
            .setPositiveButton("Submit Task") { _, _ ->
                val proof = input.text.toString().trim()
                if (task.requiresProof && proof.length < 3) {
                    Toast.makeText(this, "Please enter valid proof details before submitting.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                isSubmitting = true
                val idempotencyKey = "task_${task.id}_${UUID.randomUUID()}"
                lifecycleScope.launch {
                    try {
                        val res = ApiClient.getService(this@TasksActivity).submitTask(
                            mapOf(
                                "task_id" to task.id,
                                "proof_text" to proof,
                                "idempotency_key" to idempotencyKey
                            )
                        )
                        if (res.success && res.data != null) {
                            val earned = if (res.data.pointsAwarded > 0) res.data.pointsAwarded else rewardPts
                            MaterialAlertDialogBuilder(this@TasksActivity)
                                .setTitle("Task Approved")
                                .setMessage(
                                    "Your task has been automatically approved!\n\n" +
                                    "Points Earned: +$earned pts\n" +
                                    "New Non-Cash Balance: ${res.data.pointsBalance} pts"
                                )
                                .setPositiveButton("OK", null)
                                .show()
                            loadTasks()
                            refreshDashboardInBackground()
                        } else {
                            Toast.makeText(
                                this@TasksActivity,
                                res.message ?: "Submission failed.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@TasksActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
                    } finally {
                        isSubmitting = false
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private class TaskAdapter(
        private val items: List<TaskItem>,
        private val onClick: (TaskItem) -> Unit
    ) : RecyclerView.Adapter<TaskAdapter.VH>() {
        class VH(val b: ItemListRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            val pts = if (item.rewardPoints > 0) item.rewardPoints else max(1, (item.rewardPkr * 1000.0).roundToInt())
            val statusLabel = if (item.canSubmit) "Tap to Complete" else "Completed"
            holder.b.tvRowTitle.text = item.title.orEmpty()
            holder.b.tvRowSubtitle.text = item.instructions.orEmpty()
            holder.b.tvRowMeta.text = "Reward: +$pts pts · ${item.category.orEmpty()} · $statusLabel"
            holder.itemView.setOnClickListener { onClick(item) }
        }
    }
}
