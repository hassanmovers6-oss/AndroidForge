package com.spintoearn.app.ui.features

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.databinding.ActivityRewardsBinding
import kotlinx.coroutines.launch

class RewardsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRewardsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRewardsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refreshPoints()

        binding.btnWatchRewardedAd.setOnClickListener {
            AdMobManager.loadAndShowRewarded(
                this,
                onEarned = { nonce -> verifyAdReward("rewarded", nonce) },
                onUnavailable = { msg -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
            )
        }

        binding.btnPerkBadge.setOnClickListener { redeemPerk("badge_emerald") }
        binding.btnPerkTheme.setOnClickListener { redeemPerk("theme_midnight") }
    }

    private fun refreshPoints() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@RewardsActivity).getDashboard()
                if (res.success && res.data != null) {
                    binding.tvPointsSummary.text = "Available Non-Cash Points: ${res.data.nonCashPoints?.balance ?: 0L} pts"
                } else {
                    Toast.makeText(this@RewardsActivity, res.message ?: "Unable to refresh points.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@RewardsActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun verifyAdReward(format: String, nonce: String) {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@RewardsActivity).verifyRewardedAd(
                    mapOf("ad_format" to format, "reward_nonce" to nonce)
                )
                Toast.makeText(this@RewardsActivity, res.message ?: "Verification completed.", Toast.LENGTH_LONG).show()
                refreshPoints()
            } catch (e: Exception) {
                Toast.makeText(this@RewardsActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun redeemPerk(perkId: String) {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@RewardsActivity).redeemPerk(mapOf("perk_id" to perkId))
                Toast.makeText(this@RewardsActivity, res.message ?: "Perk request processed.", Toast.LENGTH_LONG).show()
                refreshPoints()
            } catch (e: Exception) {
                Toast.makeText(this@RewardsActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
            }
        }
    }
}
