package com.spintoearn.app.ui.features

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.model.NotificationItem
import com.spintoearn.app.databinding.ActivityNotificationsBinding
import com.spintoearn.app.databinding.ItemListRowBinding
import kotlinx.coroutines.launch

class NotificationsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rvNotifications.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@NotificationsActivity).getNotifications()
                if (res.success && res.data != null) {
                    binding.rvNotifications.adapter = NotifAdapter(res.data.items.orEmpty())
                } else {
                    Toast.makeText(this@NotificationsActivity, res.message ?: "Unable to load notifications.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@NotificationsActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
            }
        }
    }

    private class NotifAdapter(private val items: List<NotificationItem>) : RecyclerView.Adapter<NotifAdapter.VH>() {
        class VH(val b: ItemListRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.b.tvRowTitle.text = item.title.orEmpty()
            holder.b.tvRowSubtitle.text = item.message.orEmpty()
            holder.b.tvRowMeta.text = "${item.category.orEmpty()} · ${item.createdAt.orEmpty()}"
        }
    }
}
