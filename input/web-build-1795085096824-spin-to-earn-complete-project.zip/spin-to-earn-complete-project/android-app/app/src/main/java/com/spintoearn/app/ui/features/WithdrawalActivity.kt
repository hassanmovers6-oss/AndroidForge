package com.spintoearn.app.ui.features

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.databinding.ActivityWithdrawalBinding
import kotlinx.coroutines.launch
import java.util.UUID

class WithdrawalActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWithdrawalBinding
    private var minWithdraw = 100.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWithdrawalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadWalletLimits()

        binding.btnSubmitWithdrawal.setOnClickListener {
            val method = if (binding.rbEasypaisa.isChecked) "Easypaisa" else "JazzCash"
            val holder = binding.etAccountHolder.text.toString().trim()
            val number = binding.etAccountNumber.text.toString().trim()
            val amount = binding.etAmount.text.toString().toDoubleOrNull() ?: 0.0

            if (holder.length < 3 || !Regex("^03[0-9]{9}$").matches(number)) {
                Toast.makeText(this, "Enter valid account holder name and 03XXXXXXXXX number.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (amount < minWithdraw) {
                Toast.makeText(this, "Minimum withdrawal is Rs. $minWithdraw", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            binding.btnSubmitWithdrawal.isEnabled = false
            val idemKey = "wdr_${UUID.randomUUID()}"

            lifecycleScope.launch {
                try {
                    val res = ApiClient.getService(this@WithdrawalActivity).requestWithdrawal(
                        mapOf(
                            "payment_method" to method,
                            "account_holder_name" to holder,
                            "account_number" to number,
                            "amount_pkr" to amount,
                            "idempotency_key" to idemKey
                        )
                    )
                    Toast.makeText(
                        this@WithdrawalActivity,
                        res.message ?: if (res.success) "Withdrawal submitted." else "Withdrawal failed.",
                        Toast.LENGTH_LONG
                    ).show()
                    if (res.success) finish()
                } catch (e: Exception) {
                    Toast.makeText(this@WithdrawalActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
                } finally {
                    binding.btnSubmitWithdrawal.isEnabled = true
                }
            }
        }
    }

    private fun loadWalletLimits() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@WithdrawalActivity).getWalletSummary()
                if (res.success && res.data != null) {
                    minWithdraw = res.data.minimumWithdrawalPkr
                    binding.tvAvailableInfo.text = String.format(
                        "Available: Rs. %.2f | Minimum: Rs. %.2f",
                        res.data.availableBalancePkr, minWithdraw
                    )
                } else {
                    Toast.makeText(this@WithdrawalActivity, res.message ?: "Unable to load wallet balance.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WithdrawalActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
