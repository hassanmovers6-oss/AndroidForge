package com.spintoearn.app.data.api

import com.spintoearn.app.data.model.*
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @GET("config/app.php")
    suspend fun getAppConfig(): ApiResponse<AppConfigData>

    @POST("auth/register.php")
    suspend fun register(@Body body: Map<String, String>): ApiResponse<AuthData>

    @POST("auth/login.php")
    suspend fun login(@Body body: Map<String, String>): ApiResponse<AuthData>

    @POST("auth/logout.php")
    suspend fun logout(): ApiResponse<Any>

    @POST("auth/delete_account.php")
    suspend fun deleteAccount(@Body body: Map<String, String>): ApiResponse<Any>

    @GET("home/dashboard.php")
    suspend fun getDashboard(): ApiResponse<DashboardData>

    @GET("spin/wheel.php")
    suspend fun getSpinWheel(): ApiResponse<WheelData>

    @GET("spin/history.php")
    suspend fun getSpinHistory(): ApiResponse<SpinHistoryData>

    @POST("spin/execute.php")
    suspend fun executeSpin(@Body body: Map<String, String>): ApiResponse<SpinResultData>

    @POST("ads/rewarded_verify.php")
    suspend fun verifyRewardedAd(@Body body: Map<String, String>): ApiResponse<RewardedVerifyData>

    @POST("rewards/redeem_perk.php")
    suspend fun redeemPerk(@Body body: Map<String, String>): ApiResponse<Any>

    @GET("tasks/list.php")
    suspend fun getTasks(): ApiResponse<TasksData>

    @POST("tasks/submit.php")
    suspend fun submitTask(@Body body: Map<String, Any>): ApiResponse<TaskSubmitData>

    @GET("wallet/summary.php")
    suspend fun getWalletSummary(): ApiResponse<WalletSummaryData>

    @POST("wallet/withdraw.php")
    suspend fun requestWithdrawal(@Body body: Map<String, Any>): ApiResponse<Any>

    @GET("wallet/transactions.php")
    suspend fun getTransactions(): ApiResponse<TransactionsData>

    @GET("referrals/info.php")
    suspend fun getReferralInfo(): ApiResponse<ReferralData>

    @GET("notifications/list.php")
    suspend fun getNotifications(): ApiResponse<NotificationsData>

    @GET("activity/daily.php")
    suspend fun getDailyActivity(): ApiResponse<DailyActivityData>

    @POST("activity/daily.php")
    suspend fun claimDailyCheckin(): ApiResponse<Any>
}
