package com.spintoearn.app.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.ActivitySplashBinding
import com.spintoearn.app.ui.main.MainActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.HttpException

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val session = SessionManager(this)
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@SplashActivity).getAppConfig()
                if (res.success && res.data != null) {
                    session.saveAppConfig(res.data)
                    if (res.data.maintenanceMode) {
                        binding.tvSplashStatus.text = "Scheduled maintenance in progress."
                        return@launch
                    }
                }
            } catch (_: Exception) {
                binding.tvSplashStatus.text = "Starting offline session check..."
            }

            AdMobManager.preloadAppOpen(this@SplashActivity)
            AdMobManager.preloadInterstitial(this@SplashActivity)
            delay(900)

            val hasToken = !session.getToken().isNullOrBlank()
            if (hasToken) {
                val sessionExpired = try {
                    ApiClient.getService(this@SplashActivity).getDashboard()
                    false
                } catch (e: HttpException) {
                    e.code() == 401
                } catch (_: Exception) {
                    false
                }
                if (sessionExpired) {
                    finish()
                    return@launch
                }
            }

            val target = if (session.getToken().isNullOrBlank()) {
                LoginActivity::class.java
            } else {
                MainActivity::class.java
            }
            startActivity(Intent(this@SplashActivity, target))
            finish()
        }
    }
}
