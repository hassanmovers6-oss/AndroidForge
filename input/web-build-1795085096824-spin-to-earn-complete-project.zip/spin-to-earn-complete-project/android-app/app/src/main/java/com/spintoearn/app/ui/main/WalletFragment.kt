package com.spintoearn.app.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.databinding.FragmentWalletBinding
import com.spintoearn.app.ui.features.TransactionHistoryActivity
import com.spintoearn.app.ui.features.WithdrawalActivity
import kotlinx.coroutines.launch

class WalletFragment : Fragment() {

    private var _binding: FragmentWalletBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentWalletBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AdMobManager.loadBanner(requireContext(), binding.bannerAdContainer)

        binding.btnWithdraw.setOnClickListener {
            startActivity(Intent(requireContext(), WithdrawalActivity::class.java))
        }
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(requireContext(), TransactionHistoryActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadWallet()
    }

    private fun loadWallet() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).getWalletSummary()
                if (res.success && res.data != null && _binding != null) {
                    val w = res.data
                    val txList = w.recentTransactions.orEmpty()
                    binding.tvAvailableCash.text = String.format("Rs. %.2f", w.availableBalancePkr)
                    binding.tvWalletBreakdown.text = String.format(
                        "Pending: Rs. %.2f | Approved Tasks: Rs. %.2f | Withdrawn: Rs. %.2f",
                        w.pendingWithdrawalPkr, w.approvedTaskEarningsPkr, w.totalWithdrawnPkr
                    )
                    binding.tvRecentTransactions.text = if (txList.isEmpty()) {
                        "No cash transactions recorded yet."
                    } else {
                        txList.take(6).joinToString("\n") {
                            "• ${it.referenceId.orEmpty()}: Rs. ${String.format("%.2f", it.amountPkr)} (${it.txType.orEmpty()})"
                        }
                    }
                } else if (_binding != null) {
                    binding.tvRecentTransactions.text = res.message ?: "Unable to load wallet."
                }
            } catch (e: Exception) {
                if (_binding != null) {
                    binding.tvRecentTransactions.text = ApiClient.extractErrorMessage(e)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
