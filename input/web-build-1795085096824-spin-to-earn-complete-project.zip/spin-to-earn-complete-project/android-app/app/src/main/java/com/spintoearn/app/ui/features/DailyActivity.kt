package com.spintoearn.app.ui.features

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.databinding.ActivityDailyActivityBinding
import kotlinx.coroutines.launch

class DailyActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDailyActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDailyActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadDaily()

        binding.btnClaimCheckin.setOnClickListener {
            binding.btnClaimCheckin.isEnabled = false
            lifecycleScope.launch {
                try {
                    val res = ApiClient.getService(this@DailyActivity).claimDailyCheckin()
                    Toast.makeText(
                        this@DailyActivity,
                        res.message ?: if (res.success) "Daily check-in claimed." else "Check-in failed.",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(this@DailyActivity, ApiClient.extractErrorMessage(e), Toast.LENGTH_LONG).show()
                } finally {
                    loadDaily()
                }
            }
        }
    }

    private fun loadDaily() {
        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@DailyActivity).getDailyActivity()
                if (res.success && res.data != null) {
                    val d = res.data
                    binding.tvDailySummary.text =
                        "Server Date (UTC): ${d.serverDateUtc.orEmpty()}\n" +
                        "Check-In Streak: ${d.checkinStreak} day(s)\n" +
                        "Spins Used Today: ${d.spinsUsedToday} / ${d.dailySpinLimit}\n" +
                        "Approved Cash Tasks: ${d.approvedTasks}"
                    binding.btnClaimCheckin.isEnabled = !d.checkedInToday
                    binding.btnClaimCheckin.text = if (d.checkedInToday) {
                        "Today's Check-In Claimed"
                    } else {
                        "Claim Daily Check-In (+${d.checkinPoints} Non-Cash Pts)"
                    }
                } else {
                    binding.tvDailySummary.text = res.message ?: "Unable to load daily activity."
                    binding.btnClaimCheckin.isEnabled = false
                }
            } catch (e: Exception) {
                val msg = ApiClient.extractErrorMessage(e)
                binding.tvDailySummary.text = msg
                binding.btnClaimCheckin.isEnabled = false
                Toast.makeText(this@DailyActivity, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
