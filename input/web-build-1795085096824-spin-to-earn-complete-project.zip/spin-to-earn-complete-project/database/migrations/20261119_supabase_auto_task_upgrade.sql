-- ============================================================================
-- SpinReward Pro — Safe Non-Destructive Supabase / PostgreSQL Upgrade Migration
-- Purpose:
--   1) Add idempotency_key support + partial unique index on task_submissions
--      to prevent duplicate submissions and duplicate point credits.
--   2) Allow 'task_reward' in non_cash_reward_history.source_type whether the
--      existing Supabase column uses a CHECK constraint or a PostgreSQL ENUM.
--
-- Safety:
--   - Does NOT drop, truncate, or reset any tables.
--   - Does NOT delete or overwrite existing users, admins, wallets, tasks, or history.
-- ============================================================================

BEGIN;

-- 1. Idempotency key on task_submissions (safe if re-run)
ALTER TABLE task_submissions
    ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(80) DEFAULT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_ts_idempotency
    ON task_submissions (idempotency_key)
    WHERE idempotency_key IS NOT NULL;

-- 2. Allow 'task_reward' in non_cash_reward_history.source_type
DO $$
DECLARE
    col_udt_name TEXT;
    chk_name TEXT;
BEGIN
    SELECT c.udt_name
    INTO col_udt_name
    FROM information_schema.columns c
    WHERE c.table_schema = current_schema()
      AND c.table_name = 'non_cash_reward_history'
      AND c.column_name = 'source_type';

    -- Case A: Column uses a PostgreSQL custom ENUM type
    IF col_udt_name IS NOT NULL
       AND col_udt_name NOT IN ('varchar', 'text', 'bpchar', 'name')
       AND EXISTS (SELECT 1 FROM pg_type t WHERE t.typname = col_udt_name AND t.typtype = 'e') THEN
        IF NOT EXISTS (
            SELECT 1
            FROM pg_enum e
            JOIN pg_type t ON t.oid = e.enumtypid
            WHERE t.typname = col_udt_name
              AND e.enumlabel = 'task_reward'
        ) THEN
            EXECUTE format('ALTER TYPE %I ADD VALUE IF NOT EXISTS %L', col_udt_name, 'task_reward');
        END IF;
    ELSE
        -- Case B: Column uses VARCHAR/TEXT with a CHECK constraint on source_type
        FOR chk_name IN
            SELECT con.conname
            FROM pg_constraint con
            JOIN pg_class rel ON rel.oid = con.conrelid
            JOIN pg_namespace nsp ON nsp.oid = rel.relnamespace
            WHERE nsp.nspname = current_schema()
              AND rel.relname = 'non_cash_reward_history'
              AND con.contype = 'c'
              AND pg_get_constraintdef(con.oid) ILIKE '%source_type%'
        LOOP
            EXECUTE format('ALTER TABLE non_cash_reward_history DROP CONSTRAINT IF EXISTS %I', chk_name);
        END LOOP;

        ALTER TABLE non_cash_reward_history
            ADD CONSTRAINT chk_ncrh_source_type
            CHECK (source_type IN (
                'spin_wheel',
                'rewarded_ad',
                'daily_checkin',
                'task_reward',
                'perk_redemption',
                'admin_adjustment'
            ));
    END IF;
END $$;

COMMIT;
