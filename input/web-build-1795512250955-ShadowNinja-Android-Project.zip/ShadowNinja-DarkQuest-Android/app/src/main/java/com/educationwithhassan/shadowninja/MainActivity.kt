package com.educationwithhassan.shadowninja

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity(), AdMobManager.HostCallbacks {

    private lateinit var webView: WebView
    private lateinit var bannerContainer: FrameLayout
    private lateinit var nativeOverlayContainer: FrameLayout
    private lateinit var appOpenLoadingOverlay: LinearLayout

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        enableImmersiveMode()

        webView = findViewById(R.id.gameWebView)
        bannerContainer = findViewById(R.id.bannerAdContainer)
        nativeOverlayContainer = findViewById(R.id.nativeAdOverlayContainer)
        appOpenLoadingOverlay = findViewById(R.id.appOpenLoadingOverlay)

        AdMobManager.attachActivity(this, bannerContainer, nativeOverlayContainer, this)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        val bridge = GameBridge(this, webView)
        webView.addJavascriptInterface(bridge, "ShadowNinjaNative")

        // Non-blocking startup: load game immediately while resolving UMP consent & MobileAds SDK
        webView.loadUrl("https://appassets.androidplatform.net/index.html")

        val consentMgr = AdMobManager.consentManager
        if (consentMgr != null) {
            if (consentMgr.canRequestAds) {
                AdMobManager.initializeSdkAfterConsent(this)
                AdMobManager.tryColdLaunchAppOpen()
            }
            consentMgr.gatherConsent(this) { canRequest ->
                if (canRequest) {
                    AdMobManager.initializeSdkAfterConsent(this)
                    AdMobManager.tryColdLaunchAppOpen()
                }
            }
        }
    }

    override fun onFullscreenAdWillShow() {
        webView.post {
            webView.evaluateJavascript(
                "window.onNativeFullscreenAdWillShow && window.onNativeFullscreenAdWillShow();",
                null
            )
        }
    }

    override fun onFullscreenAdDismissed() {
        webView.post {
            enableImmersiveMode()
            webView.onResume()
            webView.evaluateJavascript(
                "window.onNativeFullscreenAdDismissed && window.onNativeFullscreenAdDismissed();",
                null
            )
        }
    }

    override fun onTransitionInterstitialFinished(shown: Boolean) {
        webView.post {
            enableImmersiveMode()
            webView.onResume()
            webView.evaluateJavascript(
                "window.onNativeInterstitialFinished && window.onNativeInterstitialFinished($shown);",
                null
            )
        }
    }

    override fun onNativeAdAvailabilityChanged(loaded: Boolean) {
        webView.post {
            webView.evaluateJavascript(
                "window.onNativeAdAvailabilityChanged && window.onNativeAdAvailabilityChanged($loaded);",
                null
            )
        }
    }

    override fun onColdLaunchOverlayVisibility(visible: Boolean) {
        runOnUiThread {
            appOpenLoadingOverlay.visibility = if (visible) View.VISIBLE else View.GONE
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        AdMobManager.refreshBannerLayout()
    }

    private fun enableImmersiveMode() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        AdMobManager.onActivityPaused()
    }

    override fun onResume() {
        super.onResume()
        enableImmersiveMode()
        webView.onResume()
        AdMobManager.onActivityResumed()
    }

    override fun onDestroy() {
        AdMobManager.detachActivity(this)
        webView.destroy()
        super.onDestroy()
    }
}
