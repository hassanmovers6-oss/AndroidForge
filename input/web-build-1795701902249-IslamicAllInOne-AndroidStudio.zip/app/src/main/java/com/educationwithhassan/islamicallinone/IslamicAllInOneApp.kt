package com.educationwithhassan.islamicallinone

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.educationwithhassan.islamicallinone.ads.AdManager
import com.educationwithhassan.islamicallinone.ads.RewardStorage
import com.educationwithhassan.islamicallinone.audio.AudioDownloadManager
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.EducationalTtsManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import java.lang.ref.WeakReference

class IslamicAllInOneApp : Application(), Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {
    lateinit var adManager: AdManager
        private set
    lateinit var rewardStorage: RewardStorage
        private set
    lateinit var downloadManager: AudioDownloadManager
        private set
    lateinit var audioPlayerManager: AudioPlayerManager
        private set
    lateinit var educationalTtsManager: EducationalTtsManager
        private set

    private var currentActivityRef: WeakReference<Activity>? = null
    private var hasCompletedColdLaunch = false

    override fun onCreate() {
        super.onCreate()
        rewardStorage = RewardStorage(this)
        adManager = AdManager(this)
        adManager.initialize()
        downloadManager = AudioDownloadManager(this)
        audioPlayerManager = AudioPlayerManager(this, downloadManager)
        educationalTtsManager = EducationalTtsManager(this)
        audioPlayerManager.onBeforeMediaPlay = { educationalTtsManager.stop() }
        educationalTtsManager.onBeforeSpeak = { audioPlayerManager.stop() }

        registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    override fun onStart(owner: LifecycleOwner) {
        if (!hasCompletedColdLaunch) {
            hasCompletedColdLaunch = true
            return
        }
        val activity = currentActivityRef?.get() ?: return
        val audioState = audioPlayerManager.uiState.value
        val ttsState = educationalTtsManager.uiState.value
        val isAudioActive = audioState.isPlaying || audioState.isLoading || ttsState.isSpeaking || audioState.mode != PlaybackModeState.IDLE
        adManager.showAppOpenOnForeground(activity = activity, isAudioPlaying = isAudioActive)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityStarted(activity: Activity) { currentActivityRef = WeakReference(activity) }
    override fun onActivityResumed(activity: Activity) { currentActivityRef = WeakReference(activity) }
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivityRef?.get() === activity) currentActivityRef = null
    }
}
