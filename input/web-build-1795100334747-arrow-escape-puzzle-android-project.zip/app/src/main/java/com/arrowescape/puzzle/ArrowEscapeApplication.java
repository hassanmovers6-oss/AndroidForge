package com.arrowescape.puzzle;

import android.app.Application;

import com.google.android.gms.ads.MobileAds;

public class ArrowEscapeApplication extends Application {
    private AppOpenAdManager appOpenAdManager;

    @Override
    public void onCreate() {
        super.onCreate();
        appOpenAdManager = new AppOpenAdManager(this);
        MobileAds.initialize(this, initializationStatus -> appOpenAdManager.loadAd());
    }

    public AppOpenAdManager getAppOpenAdManager() {
        return appOpenAdManager;
    }
}
