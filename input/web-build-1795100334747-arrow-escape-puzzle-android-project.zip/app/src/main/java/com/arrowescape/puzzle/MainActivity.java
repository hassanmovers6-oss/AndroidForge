package com.arrowescape.puzzle;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private AdMobManager adMobManager;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.game_webview);
        FrameLayout bannerContainer = findViewById(R.id.banner_container);
        FrameLayout nativeContainer = findViewById(R.id.native_ad_container);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/", path -> {
                    String assetPath = path.equals("/") || path.isEmpty() ? "public/index.html" : "public" + (path.startsWith("/") ? path : "/" + path);
                    try {
                        String mimeType = guessMimeType(assetPath);
                        return new WebResourceResponse(mimeType, "UTF-8", getAssets().open(assetPath));
                    } catch (Exception e) {
                        return null;
                    }
                })
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    @NonNull WebView view,
                    @NonNull WebResourceRequest request
            ) {
                Uri url = request.getUrl();
                return assetLoader.shouldInterceptRequest(url);
            }
        });

        adMobManager = new AdMobManager(this, webView, bannerContainer, nativeContainer);
        webView.addJavascriptInterface(adMobManager.createJsBridge(), "AndroidAds");
        adMobManager.initializeAndPreload();

        webView.loadUrl("https://appassets.androidplatform.net/index.html");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript(
                        "(function(){return window.__handleAndroidBack ? window.__handleAndroidBack() : false;})()",
                        result -> {
                            if ("false".equals(result) || "null".equals(result)) {
                                finish();
                            }
                        }
                );
            }
        });
    }

    private String guessMimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    @Override
    protected void onPause() {
        if (adMobManager != null) adMobManager.onPause();
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (adMobManager != null) adMobManager.onResume();
    }

    @Override
    protected void onDestroy() {
        if (adMobManager != null) adMobManager.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
