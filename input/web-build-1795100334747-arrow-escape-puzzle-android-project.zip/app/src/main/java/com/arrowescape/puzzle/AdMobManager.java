package com.arrowescape.puzzle;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;

import org.json.JSONObject;

public class AdMobManager {

    private final Activity activity;
    private final WebView webView;
    private final FrameLayout bannerContainer;
    private final FrameLayout nativeContainer;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    private AdView bannerAdView;
    @Nullable
    private InterstitialAd interstitialAd;
    @Nullable
    private RewardedAd rewardedAd;
    @Nullable
    private RewardedInterstitialAd rewardedInterstitialAd;
    @Nullable
    private NativeAd currentNativeAd;

    private boolean isLoadingInterstitial = false;
    private boolean isLoadingRewarded = false;
    private boolean isLoadingRewardedInterstitial = false;
    private boolean isLoadingNative = false;
    private boolean nativeVisibleRequested = false;
    private boolean nativeNeedsRefresh = false;

    public AdMobManager(
            @NonNull Activity activity,
            @NonNull WebView webView,
            @NonNull FrameLayout bannerContainer,
            @NonNull FrameLayout nativeContainer
    ) {
        this.activity = activity;
        this.webView = webView;
        this.bannerContainer = bannerContainer;
        this.nativeContainer = nativeContainer;
    }

    public void initializeAndPreload() {
        activity.runOnUiThread(() -> {
            loadBanner();
            loadInterstitial();
            loadRewarded();
            loadRewardedInterstitial();
            loadNativeAd();
        });
    }

    private void suppressAppOpenOnFullscreen() {
        if (activity.getApplication() instanceof ArrowEscapeApplication app) {
            if (app.getAppOpenAdManager() != null) {
                app.getAppOpenAdManager().setSuppressNextShow(true);
            }
        }
    }

    private void dispatchJsEvent(String eventType, String placement, boolean granted) {
        activity.runOnUiThread(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("type", eventType);
                payload.put("placement", placement);
                payload.put("granted", granted);
                String js = "if(window.__onAndroidAdEvent){window.__onAndroidAdEvent(" + payload + ");}";
                webView.evaluateJavascript(js, null);
            } catch (Exception ignored) {
            }
        });
    }

    private AdSize getAdaptiveBannerSize() {
        DisplayMetrics outMetrics = activity.getResources().getDisplayMetrics();
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public void loadBanner() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerContainer.removeAllViews();
        }
        bannerAdView = new AdView(activity);
        bannerAdView.setAdUnitId(AdConfig.BANNER_AD_ID);
        bannerAdView.setAdSize(getAdaptiveBannerSize());
        bannerAdView.setAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError error) {
                mainHandler.postDelayed(() -> {
                    if (!activity.isFinishing() && bannerAdView != null) {
                        bannerAdView.loadAd(new AdRequest.Builder().build());
                    }
                }, 10000L);
            }
        });
        bannerContainer.addView(bannerAdView);
        bannerAdView.loadAd(new AdRequest.Builder().build());
    }

    public void setBannerVisible(boolean visible) {
        activity.runOnUiThread(() ->
                bannerContainer.setVisibility(visible ? View.VISIBLE : View.GONE)
        );
    }

    public void loadInterstitial() {
        if (isLoadingInterstitial || interstitialAd != null) return;
        isLoadingInterstitial = true;
        InterstitialAd.load(
                activity,
                AdConfig.INTERSTITIAL_AD_ID,
                new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                        isLoadingInterstitial = false;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        interstitialAd = null;
                        isLoadingInterstitial = false;
                        mainHandler.postDelayed(AdMobManager.this::loadInterstitial, 8000L);
                    }
                }
        );
    }

    public void showInterstitial(String placement) {
        activity.runOnUiThread(() -> {
            if (interstitialAd == null) {
                loadInterstitial();
                dispatchJsEvent("interstitial_closed", placement, false);
                return;
            }
            suppressAppOpenOnFullscreen();
            interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    interstitialAd = null;
                    loadInterstitial();
                    dispatchJsEvent("interstitial_closed", placement, true);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    interstitialAd = null;
                    loadInterstitial();
                    dispatchJsEvent("interstitial_closed", placement, false);
                }
            });
            interstitialAd.show(activity);
        });
    }

    public void loadRewarded() {
        if (isLoadingRewarded || rewardedAd != null) return;
        isLoadingRewarded = true;
        RewardedAd.load(
                activity,
                AdConfig.REWARDED_AD_ID,
                new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        isLoadingRewarded = false;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        rewardedAd = null;
                        isLoadingRewarded = false;
                        mainHandler.postDelayed(AdMobManager.this::loadRewarded, 8000L);
                    }
                }
        );
    }

    public void showRewarded(String placement) {
        activity.runOnUiThread(() -> {
            if (rewardedAd == null) {
                loadRewarded();
                dispatchJsEvent("rewarded_unavailable", placement, false);
                return;
            }
            suppressAppOpenOnFullscreen();
            final boolean[] rewardGranted = {false};
            rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    rewardedAd = null;
                    loadRewarded();
                    dispatchJsEvent("rewarded_closed", placement, rewardGranted[0]);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    rewardedAd = null;
                    loadRewarded();
                    dispatchJsEvent("rewarded_failed", placement, false);
                }
            });
            rewardedAd.show(activity, rewardItem -> {
                rewardGranted[0] = true;
                dispatchJsEvent("rewarded_earned", placement, true);
            });
        });
    }

    public void loadRewardedInterstitial() {
        if (isLoadingRewardedInterstitial || rewardedInterstitialAd != null) return;
        isLoadingRewardedInterstitial = true;
        RewardedInterstitialAd.load(
                activity,
                AdConfig.REWARDED_INTERSTITIAL_AD_ID,
                new AdRequest.Builder().build(),
                new RewardedInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedInterstitialAd ad) {
                        rewardedInterstitialAd = ad;
                        isLoadingRewardedInterstitial = false;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        rewardedInterstitialAd = null;
                        isLoadingRewardedInterstitial = false;
                        mainHandler.postDelayed(AdMobManager.this::loadRewardedInterstitial, 8000L);
                    }
                }
        );
    }

    public void showRewardedInterstitial(String placement) {
        activity.runOnUiThread(() -> {
            if (rewardedInterstitialAd == null) {
                loadRewardedInterstitial();
                // Fallback to regular interstitial if rewarded interstitial is still loading
                if (interstitialAd != null) {
                    showInterstitial(placement);
                } else {
                    dispatchJsEvent("rewarded_interstitial_unavailable", placement, false);
                }
                return;
            }
            suppressAppOpenOnFullscreen();
            final boolean[] rewardGranted = {false};
            rewardedInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    rewardedInterstitialAd = null;
                    loadRewardedInterstitial();
                    dispatchJsEvent("rewarded_interstitial_closed", placement, rewardGranted[0]);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    rewardedInterstitialAd = null;
                    loadRewardedInterstitial();
                    dispatchJsEvent("rewarded_interstitial_failed", placement, false);
                }
            });
            rewardedInterstitialAd.show(activity, rewardItem -> {
                rewardGranted[0] = true;
                dispatchJsEvent("rewarded_interstitial_earned", placement, true);
            });
        });
    }

    public void loadNativeAd() {
        if (isLoadingNative) return;
        isLoadingNative = true;

        AdLoader adLoader = new AdLoader.Builder(activity, AdConfig.NATIVE_ADVANCED_AD_ID)
                .forNativeAd(nativeAd -> {
                    if (activity.isDestroyed() || activity.isFinishing()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (currentNativeAd != null) {
                        currentNativeAd.destroy();
                    }
                    currentNativeAd = nativeAd;
                    isLoadingNative = false;
                    if (nativeVisibleRequested) {
                        renderNativeAd();
                    }
                })
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        isLoadingNative = false;
                        mainHandler.postDelayed(AdMobManager.this::loadNativeAd, 12000L);
                    }
                })
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void renderNativeAd() {
        if (currentNativeAd == null) {
            nativeContainer.setVisibility(View.GONE);
            loadNativeAd();
            return;
        }
        NativeAdView adView = (NativeAdView) LayoutInflater.from(activity)
                .inflate(R.layout.native_ad_card, nativeContainer, false);

        TextView headline = adView.findViewById(R.id.ad_headline);
        TextView body = adView.findViewById(R.id.ad_body);
        TextView advertiser = adView.findViewById(R.id.ad_advertiser);
        Button cta = adView.findViewById(R.id.ad_call_to_action);
        ImageView icon = adView.findViewById(R.id.ad_app_icon);
        MediaView media = adView.findViewById(R.id.ad_media);

        adView.setHeadlineView(headline);
        adView.setBodyView(body);
        adView.setAdvertiserView(advertiser);
        adView.setCallToActionView(cta);
        adView.setIconView(icon);
        adView.setMediaView(media);

        headline.setText(currentNativeAd.getHeadline());

        if (currentNativeAd.getBody() != null) {
            body.setVisibility(View.VISIBLE);
            body.setText(currentNativeAd.getBody());
        } else {
            body.setVisibility(View.GONE);
        }

        if (currentNativeAd.getAdvertiser() != null) {
            advertiser.setVisibility(View.VISIBLE);
            advertiser.setText(currentNativeAd.getAdvertiser());
        } else {
            advertiser.setVisibility(View.GONE);
        }

        if (currentNativeAd.getCallToAction() != null) {
            cta.setVisibility(View.VISIBLE);
            cta.setText(currentNativeAd.getCallToAction());
        } else {
            cta.setVisibility(View.INVISIBLE);
        }

        if (currentNativeAd.getIcon() != null) {
            icon.setVisibility(View.VISIBLE);
            icon.setImageDrawable(currentNativeAd.getIcon().getDrawable());
        } else {
            icon.setVisibility(View.GONE);
        }

        if (currentNativeAd.getMediaContent() != null) {
            media.setMediaContent(currentNativeAd.getMediaContent());
        }

        adView.setNativeAd(currentNativeAd);
        nativeContainer.removeAllViews();
        nativeContainer.addView(adView);
        nativeContainer.setVisibility(View.VISIBLE);
        nativeNeedsRefresh = true;
    }

    public void showNativeAd() {
        activity.runOnUiThread(() -> {
            nativeVisibleRequested = true;
            if (currentNativeAd != null) {
                renderNativeAd();
            } else {
                loadNativeAd();
            }
        });
    }

    public void hideNativeAd() {
        activity.runOnUiThread(() -> {
            nativeVisibleRequested = false;
            nativeContainer.setVisibility(View.GONE);
            if (nativeNeedsRefresh) {
                nativeNeedsRefresh = false;
                loadNativeAd();
            }
        });
    }

    public void onPause() {
        if (bannerAdView != null) {
            bannerAdView.pause();
        }
    }

    public void onResume() {
        if (bannerAdView != null) {
            bannerAdView.resume();
        }
    }

    public void destroy() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        if (currentNativeAd != null) {
            currentNativeAd.destroy();
            currentNativeAd = null;
        }
    }

    public AdJsBridge createJsBridge() {
        return new AdJsBridge();
    }

    public class AdJsBridge {
        @JavascriptInterface
        public void setBannerVisible(boolean visible) {
            AdMobManager.this.setBannerVisible(visible);
        }

        @JavascriptInterface
        public void showInterstitial(String placement) {
            AdMobManager.this.showInterstitial(placement);
        }

        @JavascriptInterface
        public void showRewarded(String placement) {
            AdMobManager.this.showRewarded(placement);
        }

        @JavascriptInterface
        public void showRewardedInterstitial(String placement) {
            AdMobManager.this.showRewardedInterstitial(placement);
        }

        @JavascriptInterface
        public void showNativeAd() {
            AdMobManager.this.showNativeAd();
        }

        @JavascriptInterface
        public void hideNativeAd() {
            AdMobManager.this.hideNativeAd();
        }

        @JavascriptInterface
        public boolean isRewardedReady() {
            return rewardedAd != null;
        }

        @JavascriptInterface
        public boolean isInterstitialReady() {
            return interstitialAd != null;
        }
    }
}
