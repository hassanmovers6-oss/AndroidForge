package com.educationwithhassan.arrowpuzzle.ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.educationwithhassan.arrowpuzzle.BuildConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

class AdMobManager(private val application: Application) :
    Application.ActivityLifecycleCallbacks,
    DefaultLifecycleObserver {

    private companion object {
        const val PREFS_NAME = "arrow_puzzle_admob_pacing"
        const val KEY_LAST_APP_OPEN_SHOWN_MS = "last_app_open_shown_ms"
        const val KEY_LAST_INTERSTITIAL_SHOWN_MS = "last_interstitial_shown_ms"
    }

    private val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val isMobileAdsInitStarted = AtomicBoolean(false)

    private val _isSdkInitializedFlow = MutableStateFlow(false)
    val isSdkInitializedFlow: StateFlow<Boolean> = _isSdkInitializedFlow.asStateFlow()

    private val _isColdLaunchCompleteFlow = MutableStateFlow(false)
    val isColdLaunchCompleteFlow: StateFlow<Boolean> = _isColdLaunchCompleteFlow.asStateFlow()

    private val _nativeAdFlow = MutableStateFlow<NativeAd?>(null)
    val nativeAdFlow: StateFlow<NativeAd?> = _nativeAdFlow.asStateFlow()

    private var currentActivity: Activity? = null
    private var isShowingFullScreenAd = false

    @Volatile
    var isInActiveGameplay: Boolean = false

    // App Open Ad state
    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAppOpen = false
    private var appOpenLoadTimeMs = 0L
    private var lastAppOpenShownMs = prefs.getLong(KEY_LAST_APP_OPEN_SHOWN_MS, 0L)
    private var appOpenRetryAttempt = 0
    private var isAppOpenRetryPending = false
    private var coldLaunchHandled = false
    private val coldLaunchTimeoutRunnable = Runnable {
        finishColdLaunchGate()
    }

    // Interstitial Ad state
    private var interstitialAd: InterstitialAd? = null
    private var isLoadingInterstitial = false
    private var interstitialRetryAttempt = 0
    private var isInterstitialRetryPending = false
    private var lastInterstitialShownMs = prefs.getLong(KEY_LAST_INTERSTITIAL_SHOWN_MS, 0L)
    private var completedLevelsCounter = 0

    // Rewarded Ad state
    private var rewardedAd: RewardedAd? = null
    private var isLoadingRewarded = false
    private var rewardedRetryAttempt = 0
    private var isRewardedRetryPending = false

    // Native Ad state
    private var isLoadingNative = false
    private var nativeRetryAttempt = 0
    private var isNativeRetryPending = false

    init {
        application.registerActivityLifecycleCallbacks(this)
    }

    /**
     * Starts the bounded initial loading screen gate so App Open ads can display cleanly
     * at cold launch when ready, or proceed into the game immediately on timeout/failure.
     */
    fun startColdLaunchGate() {
        if (coldLaunchHandled) return
        val withinCap = System.currentTimeMillis() - lastAppOpenShownMs < AdMobConfig.APP_OPEN_FREQUENCY_CAP_MS
        if (withinCap) {
            finishColdLaunchGate()
            return
        }
        mainHandler.removeCallbacks(coldLaunchTimeoutRunnable)
        mainHandler.postDelayed(coldLaunchTimeoutRunnable, AdMobConfig.APP_OPEN_COLD_START_TIMEOUT_MS)
    }

    private fun finishColdLaunchGate() {
        coldLaunchHandled = true
        mainHandler.removeCallbacks(coldLaunchTimeoutRunnable)
        _isColdLaunchCompleteFlow.value = true
    }

    fun initializeSdkIfAllowed(canRequestAds: Boolean) {
        if (!canRequestAds) {
            finishColdLaunchGate()
            return
        }
        if (isMobileAdsInitStarted.getAndSet(true)) {
            if (_isSdkInitializedFlow.value) {
                preloadAllFormats()
            }
            return
        }

        if (BuildConfig.DEBUG) {
            val config = RequestConfiguration.Builder()
                .setTestDeviceIds(AdMobConfig.DEBUG_TEST_DEVICE_IDS)
                .build()
            MobileAds.setRequestConfiguration(config)
        }

        MobileAds.initialize(application) {
            mainHandler.post {
                _isSdkInitializedFlow.value = true
                preloadAllFormats()
            }
        }
    }

    private fun preloadAllFormats() {
        loadAppOpenAd()
        loadInterstitialAd()
        loadRewardedAd()
        loadNativeAdIfNeeded()
    }

    private fun backoffDelayMs(attempt: Int): Long {
        val shift = (attempt - 1).coerceIn(0, AdMobConfig.MAX_RETRY_EXPONENT)
        val delay = AdMobConfig.RETRY_INITIAL_DELAY_MS * (1L shl shift)
        return min(delay, AdMobConfig.RETRY_MAX_DELAY_MS)
    }

    // region App Open Ad
    fun loadAppOpenAd() {
        if (!_isSdkInitializedFlow.value || isLoadingAppOpen || isAppOpenAvailable()) return
        isLoadingAppOpen = true
        val request = AdRequest.Builder().build()

        AppOpenAd.load(
            application,
            AdMobConfig.APP_OPEN_AD_UNIT_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    appOpenLoadTimeMs = System.currentTimeMillis()
                    isLoadingAppOpen = false
                    appOpenRetryAttempt = 0
                    isAppOpenRetryPending = false

                    // Opportunistically show as soon as the ad is ready and it's safe to do so,
                    // rather than only attempting this while the cold-launch splash gate is
                    // still open. In practice, consent gathering + SDK init + the ad network
                    // round trip routinely take longer than the splash timeout, so the gate had
                    // almost always already closed by the time onAdLoaded fired here, silently
                    // dropping the only chance to display the ad until the next foreground resume.
                    val wasColdLaunch = !coldLaunchHandled
                    val activity = currentActivity
                    if (activity != null && !activity.isFinishing && !activity.isDestroyed &&
                        !isInActiveGameplay && !isShowingFullScreenAd
                    ) {
                        showAppOpenIfAvailable(activity, isColdLaunch = wasColdLaunch)
                    } else if (wasColdLaunch) {
                        finishColdLaunchGate()
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoadingAppOpen = false
                    if (!coldLaunchHandled) {
                        finishColdLaunchGate()
                    }
                    if (!isAppOpenRetryPending) {
                        isAppOpenRetryPending = true
                        appOpenRetryAttempt++
                        mainHandler.postDelayed({
                            isAppOpenRetryPending = false
                            loadAppOpenAd()
                        }, backoffDelayMs(appOpenRetryAttempt))
                    }
                }
            }
        )
    }

    private fun isAppOpenAvailable(): Boolean {
        val ad = appOpenAd ?: return false
        val age = System.currentTimeMillis() - appOpenLoadTimeMs
        return ad != null && age < AdMobConfig.APP_OPEN_EXPIRY_MS
    }

    fun showAppOpenIfAvailable(activity: Activity, isColdLaunch: Boolean = false) {
        if (activity.isFinishing || activity.isDestroyed) {
            if (isColdLaunch) finishColdLaunchGate()
            return
        }
        if (isShowingFullScreenAd || isInActiveGameplay) {
            if (isColdLaunch) finishColdLaunchGate()
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastAppOpenShownMs < AdMobConfig.APP_OPEN_FREQUENCY_CAP_MS) {
            if (isColdLaunch) finishColdLaunchGate()
            return
        }

        if (!isAppOpenAvailable()) {
            if (isColdLaunch) finishColdLaunchGate()
            loadAppOpenAd()
            return
        }

        val ad = appOpenAd ?: run {
            if (isColdLaunch) finishColdLaunchGate()
            return
        }

        mainHandler.removeCallbacks(coldLaunchTimeoutRunnable)
        isShowingFullScreenAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                lastAppOpenShownMs = System.currentTimeMillis()
                prefs.edit().putLong(KEY_LAST_APP_OPEN_SHOWN_MS, lastAppOpenShownMs).apply()
            }

            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isShowingFullScreenAd = false
                if (isColdLaunch || !coldLaunchHandled) {
                    finishColdLaunchGate()
                }
                loadAppOpenAd()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                appOpenAd = null
                isShowingFullScreenAd = false
                if (isColdLaunch || !coldLaunchHandled) {
                    finishColdLaunchGate()
                }
                loadAppOpenAd()
            }
        }
        ad.show(activity)
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        val activity = currentActivity ?: return
        if (coldLaunchHandled && !isInActiveGameplay && !isShowingFullScreenAd) {
            showAppOpenIfAvailable(activity, isColdLaunch = false)
        }
    }
    // endregion

    // region Interstitial Ad
    fun loadInterstitialAd() {
        if (!_isSdkInitializedFlow.value || isLoadingInterstitial || interstitialAd != null) return
        isLoadingInterstitial = true
        val request = AdRequest.Builder().build()

        InterstitialAd.load(
            application,
            AdMobConfig.INTERSTITIAL_AD_UNIT_ID,
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoadingInterstitial = false
                    interstitialRetryAttempt = 0
                    isInterstitialRetryPending = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isLoadingInterstitial = false
                    if (!isInterstitialRetryPending) {
                        isInterstitialRetryPending = true
                        interstitialRetryAttempt++
                        // Use the same exponential backoff as the other ad formats instead of a
                        // fixed 5s retry, so a transient failure doesn't hammer the ad server at
                        // a constant interval indefinitely.
                        mainHandler.postDelayed({
                            isInterstitialRetryPending = false
                            loadInterstitialAd()
                        }, backoffDelayMs(interstitialRetryAttempt))
                    }
                }
            }
        )
    }

    fun onLevelCompletedMaybeShowInterstitial(activity: Activity, onDone: () -> Unit) {
        completedLevelsCounter++
        if (activity.isFinishing || activity.isDestroyed) {
            onDone()
            return
        }

        val now = System.currentTimeMillis()
        val cadenceReached = completedLevelsCounter >= AdMobConfig.INTERSTITIAL_LEVEL_CADENCE
        val intervalElapsed = now - lastInterstitialShownMs >= AdMobConfig.INTERSTITIAL_MIN_INTERVAL_MS

        if (!cadenceReached || !intervalElapsed || isShowingFullScreenAd) {
            if (interstitialAd == null) loadInterstitialAd()
            onDone()
            return
        }

        val ad = interstitialAd
        if (ad == null) {
            loadInterstitialAd()
            onDone()
            return
        }

        completedLevelsCounter = 0
        isShowingFullScreenAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                lastInterstitialShownMs = System.currentTimeMillis()
                prefs.edit().putLong(KEY_LAST_INTERSTITIAL_SHOWN_MS, lastInterstitialShownMs).apply()
            }

            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                isShowingFullScreenAd = false
                loadInterstitialAd()
                onDone()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitialAd = null
                isShowingFullScreenAd = false
                loadInterstitialAd()
                onDone()
            }
        }
        ad.show(activity)
    }
    // endregion

    // region Rewarded Ad
    fun loadRewardedAd() {
        if (!_isSdkInitializedFlow.value || isLoadingRewarded || rewardedAd != null) return
        isLoadingRewarded = true
        val request = AdRequest.Builder().build()

        RewardedAd.load(
            application,
            AdMobConfig.REWARDED_AD_UNIT_ID,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isLoadingRewarded = false
                    rewardedRetryAttempt = 0
                    isRewardedRetryPending = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isLoadingRewarded = false
                    if (!isRewardedRetryPending) {
                        isRewardedRetryPending = true
                        rewardedRetryAttempt++
                        mainHandler.postDelayed({
                            isRewardedRetryPending = false
                            loadRewardedAd()
                        }, backoffDelayMs(rewardedRetryAttempt))
                    }
                }
            }
        )
    }

    fun isRewardedAdReady(): Boolean = rewardedAd != null

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdClosed: () -> Unit,
        onUnavailable: () -> Unit
    ) {
        if (activity.isFinishing || activity.isDestroyed || isShowingFullScreenAd) {
            onUnavailable()
            return
        }
        val ad = rewardedAd
        if (ad == null) {
            loadRewardedAd()
            onUnavailable()
            return
        }

        var rewardGranted = false
        isShowingFullScreenAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                isShowingFullScreenAd = false
                loadRewardedAd()
                onAdClosed()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewardedAd = null
                isShowingFullScreenAd = false
                loadRewardedAd()
                onUnavailable()
            }
        }

        ad.show(activity) { _ ->
            // Grant reward strictly inside Google Mobile Ads OnUserEarnedRewardListener
            if (!rewardGranted) {
                rewardGranted = true
                mainHandler.post { onRewardEarned() }
            }
        }
    }
    // endregion

    // region Native Advanced Ad (Silent preloaded cache — zero Toast/Snackbar/popup)
    fun loadNativeAdIfNeeded() {
        if (!_isSdkInitializedFlow.value || isLoadingNative || _nativeAdFlow.value != null) return
        isLoadingNative = true

        val adLoader = AdLoader.Builder(application, AdMobConfig.NATIVE_AD_UNIT_ID)
            .forNativeAd { loadedAd ->
                isLoadingNative = false
                nativeRetryAttempt = 0
                isNativeRetryPending = false
                val previous = _nativeAdFlow.value
                _nativeAdFlow.value = loadedAd
                if (previous != null && previous !== loadedAd) {
                    previous.destroy()
                }
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoadingNative = false
                    if (!isNativeRetryPending) {
                        isNativeRetryPending = true
                        nativeRetryAttempt++
                        mainHandler.postDelayed({
                            isNativeRetryPending = false
                            loadNativeAdIfNeeded()
                        }, backoffDelayMs(nativeRetryAttempt))
                    }
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setRequestMultipleImages(false)
                    .build()
            )
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun destroyNativeAd() {
        _nativeAdFlow.value?.destroy()
        _nativeAdFlow.value = null
    }
    // endregion

    fun destroy() {
        mainHandler.removeCallbacksAndMessages(null)
        application.unregisterActivityLifecycleCallbacks(this)
        appOpenAd?.fullScreenContentCallback = null
        appOpenAd = null
        interstitialAd?.fullScreenContentCallback = null
        interstitialAd = null
        rewardedAd?.fullScreenContentCallback = null
        rewardedAd = null
        destroyNativeAd()
        currentActivity = null
    }

    // region ActivityLifecycleCallbacks
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {
        if (!isShowingFullScreenAd) {
            currentActivity = activity
        }
    }
    override fun onActivityResumed(activity: Activity) {
        if (!isShowingFullScreenAd) {
            currentActivity = activity
        }
    }
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivity === activity) {
            currentActivity = null
        }
    }
    // endregion
}
