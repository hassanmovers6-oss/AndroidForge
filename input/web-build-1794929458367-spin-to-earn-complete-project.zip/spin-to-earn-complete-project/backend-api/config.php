<?php
/**
 * SpinReward Pro — Backend Configuration
 * File: backend-api/config.php
 *
 * IMPORTANT: Replace placeholder values before deploying to production.
 * Never commit real database credentials or secrets to version control.
 */

declare(strict_types=1);

return [
    'db' => [
        'host'    => getenv('DB_HOST') ?: '127.0.0.1',
        'port'    => (int)(getenv('DB_PORT') ?: 3306),
        'name'    => getenv('DB_NAME') ?: 'spin_to_earn',
        'user'    => getenv('DB_USER') ?: 'YOUR_DB_USERNAME',
        'pass'    => getenv('DB_PASS') ?: 'YOUR_DB_PASSWORD',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'base_url'         => getenv('APP_BASE_URL') ?: 'https://your-domain.example.com',
        'timezone'         => 'UTC',
        'token_ttl_days'   => 30,
        'upload_dir'       => __DIR__ . '/uploads/proofs',
        'max_upload_bytes' => 5 * 1024 * 1024, // 5 MB
    ],
    'security' => [
        // Generate a 64-char random hex secret for production
        'app_secret'       => getenv('APP_SECRET') ?: 'REPLACE_WITH_64_CHAR_RANDOM_HEX_SECRET',
        'rate_limit_dir'   => sys_get_temp_dir() . '/spin_earn_rl',
        'admob_ssv_verify' => (bool)(getenv('ADMOB_SSV_VERIFY') ?: false),
    ],
];
