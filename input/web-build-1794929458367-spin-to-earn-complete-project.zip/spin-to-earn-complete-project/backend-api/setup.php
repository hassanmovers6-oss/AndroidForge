<?php
/**
 * SpinReward Pro — One-Time Installer & Schema Verification Script
 * File: backend-api/setup.php
 *
 * Usage: Run once via CLI (`php setup.php`) or protected setup URL, then delete or lock.
 */

declare(strict_types=1);

require_once __DIR__ . '/database.php';

$config = require __DIR__ . '/config.php';

if (php_sapi_name() !== 'cli' && ($_GET['setup_token'] ?? '') !== $config['security']['app_secret']) {
    http_response_code(403);
    exit('Forbidden: Provide valid setup_token or execute via PHP CLI.');
}

$pdo = Database::getConnection();

// Ensure upload directory exists outside web-executable paths
$uploadDir = $config['app']['upload_dir'];
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
    file_put_contents($uploadDir . '/.htaccess', "php_flag engine off\nOptions -Indexes\n");
}

// Create initial super admin if none exists
$adminCount = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
if ($adminCount === 0) {
    $defaultUsername = 'admin';
    $defaultEmail    = 'admin@your-domain.example.com';
    $initialPassword = bin2hex(random_bytes(8)); // Printed once at setup time
    $hash = password_hash($initialPassword, PASSWORD_ARGON2ID);

    $stmt = $pdo->prepare(
        'INSERT INTO admins (username, email, password_hash, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$defaultUsername, $defaultEmail, $hash, 'Primary Administrator', 'super_admin', 'active']);

    echo "Super Admin created.\n";
    echo "Username: {$defaultUsername}\n";
    echo "Password: {$initialPassword}\n";
    echo "IMPORTANT: Change this password immediately after first login and restrict setup.php.\n";
} else {
    echo "Admins table already initialized ({$adminCount} admin record(s) found).\n";
}

echo "Setup verification complete.\n";
