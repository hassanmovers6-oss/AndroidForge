<?php
/**
 * POST /api/v1/auth/login.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';
require_once __DIR__ . '/../../helpers/RateLimiter.php';

Security::requireMethod('POST');
RateLimiter::enforce('login_' . Security::clientIp(), 15, 900);

$body = Response::readJsonBody();
$email    = strtolower(trim((string)($body['email'] ?? '')));
$password = (string)($body['password'] ?? '');
$deviceFp = substr(trim((string)($body['device_fingerprint'] ?? '')), 0, 128);

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    Response::json(422, false, 'Valid email and password are required.');
}

$pdo = Database::getConnection();
$stmt = $pdo->prepare(
    'SELECT id, full_name, email, phone, password_hash, referral_code, status FROM users WHERE email = ? LIMIT 1'
);
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    Response::json(401, false, 'Invalid email or password.');
}

if ($user['status'] !== 'active') {
    Response::json(403, false, 'Account is ' . $user['status'] . '. Contact support.');
}

$rawToken = bin2hex(random_bytes(32));
$tokenHash = hash('sha256', $rawToken);
$config = require __DIR__ . '/../../config.php';
$ttlDays = (int)$config['app']['token_ttl_days'];

$pdo->prepare(
    'INSERT INTO user_sessions (user_id, token_hash, device_id, ip_address, user_agent, expires_at)
     VALUES (?, ?, ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY))'
)->execute([
    (int)$user['id'],
    $tokenHash,
    $deviceFp ?: null,
    Security::clientIp(),
    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Android', 0, 255),
    $ttlDays,
]);

Security::writeAuditLog($pdo, 'user', (int)$user['id'], 'user_login', 'user', (int)$user['id']);

Response::json(200, true, 'Login successful.', [
    'token' => $rawToken,
    'user'  => [
        'id'            => (int)$user['id'],
        'full_name'     => $user['full_name'],
        'email'         => $user['email'],
        'phone'         => $user['phone'],
        'referral_code' => $user['referral_code'],
    ],
]);
