<?php
/**
 * GET / POST /api/v1/activity/daily.php
 * Server-UTC daily check-in & activity summary (awards non-cash points only).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];
$todayUtc = gmdate('Y-m-d');
$yesterdayUtc = gmdate('Y-m-d', strtotime('-1 day'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $checkinPts = (int)Security::getSetting($pdo, 'daily_checkin_points', '40');
    $pdo->beginTransaction();
    try {
        $uStmt = $pdo->prepare('SELECT last_checkin_date, checkin_streak FROM users WHERE id = ? FOR UPDATE');
        $uStmt->execute([$userId]);
        $uRow = $uStmt->fetch();

        if ($uRow && $uRow['last_checkin_date'] === $todayUtc) {
            $pdo->rollBack();
            Response::json(409, false, 'Today\'s daily check-in has already been claimed.');
        }

        $newStreak = ($uRow && $uRow['last_checkin_date'] === $yesterdayUtc)
            ? ((int)$uRow['checkin_streak'] + 1)
            : 1;

        $pdo->prepare('UPDATE users SET last_checkin_date = ?, checkin_streak = ? WHERE id = ?')
            ->execute([$todayUtc, $newStreak, $userId]);

        $pStmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ? FOR UPDATE');
        $pStmt->execute([$userId]);
        $bal = (int)$pStmt->fetchColumn() + $checkinPts;

        $pdo->prepare(
            'UPDATE user_non_cash_points SET points_balance = points_balance + ?, lifetime_points_earned = lifetime_points_earned + ? WHERE user_id = ?'
        )->execute([$checkinPts, $checkinPts, $userId]);

        $refId = Security::generateUniqueRefId('CHK');
        $pdo->prepare(
            'INSERT INTO non_cash_reward_history (user_id, source_type, points_delta, balance_after, reference_id, description)
             VALUES (?, "daily_checkin", ?, ?, ?, ?)'
        )->execute([$userId, $checkinPts, $bal, $refId, "Daily Check-In Day {$newStreak} (non-cash points)"]);

        $pdo->commit();
        Response::json(200, true, "Daily check-in claimed (+{$checkinPts} non-cash pts).", [
            'checkin_streak' => $newStreak,
            'points_balance' => $bal,
        ]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        Response::json(500, false, 'Failed to process daily check-in.');
    }
}

$spinsToday = $pdo->prepare('SELECT COUNT(*) FROM spin_history WHERE user_id = ? AND spin_date_utc = ?');
$spinsToday->execute([$userId, $todayUtc]);

$tasksDone = $pdo->prepare('SELECT COUNT(*) FROM task_submissions WHERE user_id = ? AND status = "approved"');
$tasksDone->execute([$userId]);

Response::json(200, true, 'Daily activity loaded.', [
    'server_date_utc'  => $todayUtc,
    'checked_in_today' => ($user['last_checkin_date'] === $todayUtc),
    'checkin_streak'   => (int)$user['checkin_streak'],
    'checkin_points'   => (int)Security::getSetting($pdo, 'daily_checkin_points', '40'),
    'spins_used_today' => (int)$spinsToday->fetchColumn(),
    'daily_spin_limit' => (int)Security::getSetting($pdo, 'daily_spin_limit', '5'),
    'approved_tasks'   => (int)$tasksDone->fetchColumn(),
]);
