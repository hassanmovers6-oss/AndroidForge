<?php
/**
 * GET /api/v1/spin/history.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);

$stmt = $pdo->prepare(
    'SELECT sh.id, sh.spin_date_utc, sh.points_awarded, sh.created_at, srs.label
     FROM spin_history sh
     INNER JOIN spin_reward_settings srs ON srs.id = sh.slice_id
     WHERE sh.user_id = ?
     ORDER BY sh.id DESC
     LIMIT 50'
);
$stmt->execute([(int)$user['id']]);

Response::json(200, true, 'Spin history loaded.', [
    'items' => $stmt->fetchAll(),
]);
