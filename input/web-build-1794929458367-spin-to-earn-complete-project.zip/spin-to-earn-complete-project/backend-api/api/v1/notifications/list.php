<?php
/**
 * GET / POST /api/v1/notifications/list.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$userId]);
    Response::json(200, true, 'All notifications marked as read.');
}

$stmt = $pdo->prepare(
    'SELECT id, title, message, category, is_read, created_at
     FROM notifications
     WHERE user_id = ? OR user_id IS NULL
     ORDER BY id DESC
     LIMIT 50'
);
$stmt->execute([$userId]);

Response::json(200, true, 'Notifications loaded.', [
    'items' => $stmt->fetchAll(),
]);
