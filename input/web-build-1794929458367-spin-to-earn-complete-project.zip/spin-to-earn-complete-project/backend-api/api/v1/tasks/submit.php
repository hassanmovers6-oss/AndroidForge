<?php
/**
 * POST /api/v1/tasks/submit.php
 * Submits task proof (JSON or multipart/form-data with validated image upload) for admin review.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';
require_once __DIR__ . '/../../helpers/RateLimiter.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

RateLimiter::enforce('task_submit_' . $userId, 10, 300);

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
if (stripos($contentType, 'application/json') !== false) {
    $input = Response::readJsonBody();
} else {
    $input = $_POST;
}

$taskId = (int)($input['task_id'] ?? 0);
$proofText = trim((string)($input['proof_text'] ?? ''));

if ($taskId <= 0) {
    Response::json(422, false, 'Valid task_id is required.');
}

$taskStmt = $pdo->prepare('SELECT * FROM tasks WHERE id = ? AND status = "active" LIMIT 1');
$taskStmt->execute([$taskId]);
$task = $taskStmt->fetch();
if (!$task) {
    Response::json(404, false, 'Task not found or no longer active.');
}

$countStmt = $pdo->prepare(
    'SELECT COUNT(*) FROM task_submissions WHERE task_id = ? AND user_id = ? AND status IN ("pending", "approved")'
);
$countStmt->execute([$taskId, $userId]);
if ((int)$countStmt->fetchColumn() >= (int)$task['max_completions_per_user']) {
    Response::json(409, false, 'You have already reached the submission limit for this task.');
}

$proofFilePath = null;
if (!empty($_FILES['proof_file']) && $_FILES['proof_file']['error'] === UPLOAD_ERR_OK) {
    $config = require __DIR__ . '/../../config.php';
    $tmp = $_FILES['proof_file']['tmp_name'];
    if ($_FILES['proof_file']['size'] > $config['app']['max_upload_bytes']) {
        Response::json(422, false, 'Proof image exceeds 5 MB limit.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmp);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime])) {
        Response::json(422, false, 'Only JPEG, PNG, and WebP proof screenshots are allowed.');
    }
    $dir = $config['app']['upload_dir'];
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $safeName = 'proof_' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    $dest = $dir . '/' . $safeName;
    if (!move_uploaded_file($tmp, $dest)) {
        Response::json(500, false, 'Failed to store uploaded proof.');
    }
    $proofFilePath = $safeName;
}

if ((int)$task['requires_proof'] === 1 && $proofText === '' && $proofFilePath === null) {
    Response::json(422, false, 'Please provide proof text or screenshot before submitting.');
}

$ins = $pdo->prepare(
    'INSERT INTO task_submissions (task_id, user_id, proof_text, proof_file_path, reward_snapshot_pkr, status)
     VALUES (?, ?, ?, ?, ?, "pending")'
);
$ins->execute([$taskId, $userId, $proofText ?: null, $proofFilePath, $task['reward_pkr']]);
$submissionId = (int)$ins->lastInsertId();

Security::writeAuditLog($pdo, 'user', $userId, 'task_submitted', 'task_submission', $submissionId, ['task_id' => $taskId]);

Response::json(201, true, 'Task proof submitted for admin review.', [
    'submission_id' => $submissionId,
    'status'        => 'pending',
]);
