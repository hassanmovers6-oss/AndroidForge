<?php
/**
 * GET /api/v1/home/dashboard.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$todayUtc = gmdate('Y-m-d');
$dailyLimit = (int)Security::getSetting($pdo, 'daily_spin_limit', '5');

$usedStmt = $pdo->prepare('SELECT COUNT(*) FROM spin_history WHERE user_id = ? AND spin_date_utc = ?');
$usedStmt->execute([$userId, $todayUtc]);
$spinsUsed = (int)$usedStmt->fetchColumn();

$pointsStmt = $pdo->prepare('SELECT points_balance, lifetime_points_earned FROM user_non_cash_points WHERE user_id = ?');
$pointsStmt->execute([$userId]);
$points = $pointsStmt->fetch() ?: ['points_balance' => 0, 'lifetime_points_earned' => 0];

$walletStmt = $pdo->prepare('SELECT available_balance_pkr, pending_withdrawal_pkr, approved_task_earnings_pkr, total_withdrawn_pkr FROM cash_wallets WHERE user_id = ?');
$walletStmt->execute([$userId]);
$wallet = $walletStmt->fetch() ?: [
    'available_balance_pkr'      => '0.00',
    'pending_withdrawal_pkr'     => '0.00',
    'approved_task_earnings_pkr' => '0.00',
    'total_withdrawn_pkr'        => '0.00',
];

$unreadStmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0');
$unreadStmt->execute([$userId]);

$activeTasksCount = (int)$pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'active'")->fetchColumn();

Response::json(200, true, 'Dashboard loaded.', [
    'user' => [
        'id'              => $userId,
        'full_name'       => $user['full_name'],
        'email'           => $user['email'],
        'referral_code'   => $user['referral_code'],
        'checkin_streak'  => (int)$user['checkin_streak'],
        'checked_in_today'=> ($user['last_checkin_date'] === $todayUtc),
    ],
    'spins' => [
        'server_date_utc' => $todayUtc,
        'daily_limit'     => $dailyLimit,
        'used_today'      => $spinsUsed,
        'remaining_today' => max(0, $dailyLimit - $spinsUsed),
        'spins_enabled'   => Security::getSetting($pdo, 'spins_enabled', '1') === '1',
    ],
    'non_cash_points' => [
        'balance'         => (int)$points['points_balance'],
        'lifetime_earned' => (int)$points['lifetime_points_earned'],
        'policy_note'     => 'Non-cash in-app benefit points only. Never convertible to cash.',
    ],
    'cash_wallet' => [
        'available_balance_pkr'      => (float)$wallet['available_balance_pkr'],
        'pending_withdrawal_pkr'     => (float)$wallet['pending_withdrawal_pkr'],
        'approved_task_earnings_pkr' => (float)$wallet['approved_task_earnings_pkr'],
        'total_withdrawn_pkr'        => (float)$wallet['total_withdrawn_pkr'],
    ],
    'active_tasks_count'   => $activeTasksCount,
    'unread_notifications' => (int)$unreadStmt->fetchColumn(),
    'announcement'         => Security::getSetting($pdo, 'announcement_message', ''),
]);
