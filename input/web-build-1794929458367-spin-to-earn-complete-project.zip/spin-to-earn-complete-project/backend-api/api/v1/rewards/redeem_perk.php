<?php
/**
 * POST /api/v1/rewards/redeem_perk.php
 * Allows users to spend non-cash points ONLY on permitted in-app perks (themes, badges, avatar frames).
 * Strictly enforces non-cash policy (never cash, gift cards, or crypto).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$perks = [
    'badge_emerald'   => ['title' => 'Emerald Crown Profile Badge', 'cost' => 300],
    'theme_midnight'  => ['title' => 'Midnight Slate App Theme',    'cost' => 500],
    'frame_gold_ring' => ['title' => 'Golden Ring Avatar Frame',    'cost' => 800],
];

$body = Response::readJsonBody();
$perkId = (string)($body['perk_id'] ?? '');
if (!isset($perks[$perkId])) {
    Response::json(422, false, 'Invalid in-app perk selected.');
}

$perk = $perks[$perkId];
$cost = $perk['cost'];

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ? FOR UPDATE');
    $stmt->execute([$userId]);
    $bal = (int)$stmt->fetchColumn();

    if ($bal < $cost) {
        $pdo->rollBack();
        Response::json(422, false, 'Insufficient non-cash points for this in-app perk.');
    }

    $newBal = $bal - $cost;
    $pdo->prepare(
        'UPDATE user_non_cash_points
         SET points_balance = points_balance - ?, lifetime_points_spent = lifetime_points_spent + ?
         WHERE user_id = ?'
    )->execute([$cost, $cost, $userId]);

    $refId = Security::generateUniqueRefId('PERK');
    $pdo->prepare(
        'INSERT INTO non_cash_reward_history (user_id, source_type, points_delta, balance_after, reference_id, description)
         VALUES (?, "perk_redemption", ?, ?, ?, ?)'
    )->execute([$userId, -$cost, $newBal, $refId, "Unlocked in-app perk: {$perk['title']}"]);

    $pdo->commit();
    Response::json(200, true, "Unlocked {$perk['title']}!", [
        'perk_id'        => $perkId,
        'points_balance' => $newBal,
        'reference_id'   => $refId,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    Response::json(500, false, 'Failed to unlock in-app perk.');
}
