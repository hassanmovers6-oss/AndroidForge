<?php
/**
 * POST /api/v1/profile/update.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$body = Response::readJsonBody();
$fullName = trim((string)($body['full_name'] ?? ''));
$phone    = trim((string)($body['phone'] ?? ''));

if (mb_strlen($fullName) < 2 || mb_strlen($fullName) > 120) {
    Response::json(422, false, 'Full name must be between 2 and 120 characters.');
}

$pdo->prepare('UPDATE users SET full_name = ?, phone = ? WHERE id = ?')
    ->execute([$fullName, $phone ?: null, $userId]);

Response::json(200, true, 'Profile updated successfully.', [
    'full_name' => $fullName,
    'phone'     => $phone,
]);
