<?php
/**
 * GET /api/v1/config/app.php
 * Public app configuration + AdMob settings for Android initialization
 */

declare(strict_types=1);

require_once __DIR__ . '/../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$settings = Security::getAllSettings($pdo);
$ads = $pdo->query(
    'SELECT ad_format, is_enabled, test_mode, test_ad_unit_id, prod_ad_unit_id,
            placement_notes, frequency_cap_per_hour, cooldown_seconds, rewarded_points
     FROM advertisements_settings ORDER BY id ASC'
)->fetchAll();

$adConfig = [];
foreach ($ads as $row) {
    $adUnit = ((int)$row['test_mode'] === 1 || empty($row['prod_ad_unit_id']))
        ? $row['test_ad_unit_id']
        : $row['prod_ad_unit_id'];

    $adConfig[$row['ad_format']] = [
        'enabled'                => (int)$row['is_enabled'] === 1,
        'test_mode'              => (int)$row['test_mode'] === 1,
        'ad_unit_id'             => $adUnit,
        'frequency_cap_per_hour' => (int)$row['frequency_cap_per_hour'],
        'cooldown_seconds'       => (int)$row['cooldown_seconds'],
        'rewarded_points'        => (int)$row['rewarded_points'],
        'placement_notes'        => $row['placement_notes'],
    ];
}

Response::json(200, true, 'App configuration loaded.', [
    'app_name'               => $settings['app_name'] ?? 'SpinReward Pro',
    'app_version'            => $settings['app_version'] ?? '1.0.0',
    'support_email'          => $settings['support_email'] ?? '',
    'minimum_withdrawal_pkr' => (float)($settings['minimum_withdrawal_pkr'] ?? 100),
    'payment_methods'        => explode(',', $settings['payment_methods'] ?? 'JazzCash,Easypaisa'),
    'privacy_policy_url'     => $settings['privacy_policy_url'] ?? '',
    'terms_url'              => $settings['terms_url'] ?? '',
    'maintenance_mode'       => ($settings['maintenance_mode'] ?? '0') === '1',
    'announcement_message'   => $settings['announcement_message'] ?? '',
    'spins_enabled'          => ($settings['spins_enabled'] ?? '1') === '1',
    'daily_spin_limit'       => (int)($settings['daily_spin_limit'] ?? 5),
    'admob'                  => $adConfig,
]);
