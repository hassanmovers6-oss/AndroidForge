# 01. MySQL Database Installation Instructions

## Prerequisites
- MySQL 8.0+ or MariaDB 10.6+
- Dedicated database user with least-privilege permissions (`SELECT, INSERT, UPDATE, DELETE` — avoid `DROP` in production runtime).

## Steps
1. Create the database and import the schema:
   ```bash
   mysql -u root -p < database/spin_to_earn.sql
   ```
2. Create a dedicated application user:
   ```sql
   CREATE USER 'spin_app'@'localhost' IDENTIFIED BY 'STRONG_RANDOM_PASSWORD';
   GRANT SELECT, INSERT, UPDATE, DELETE ON spin_to_earn.* TO 'spin_app'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. Configure `backend-api/config.php` (or environment variables `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`, `APP_SECRET`).
4. Run the one-time setup script via CLI to generate your initial Super Admin account and secure the proof upload directory:
   ```bash
   php backend-api/setup.php
   ```
5. Record the generated admin username/password, sign in to `/admin-panel/login.php`, and delete or restrict `setup.php`.
