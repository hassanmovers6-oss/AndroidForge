# 02. PHP 8+ Backend & Admin Panel Hosting Guide

## Server Requirements
- PHP 8.1+ with extensions: `pdo_mysql`, `openssl`, `fileinfo`, `mbstring`, `json`
- Apache (with `mod_rewrite` enabled) or Nginx + PHP-FPM
- Valid HTTPS/TLS certificate (Let's Encrypt or managed TLS — required because `usesCleartextTraffic="false"` is enforced in AndroidManifest).

## Deployment Steps
1. Upload `backend-api/` and `admin-panel/` to your HTTPS host.
2. Ensure `backend-api/config.php`, `backend-api/database.php`, and `backend-api/setup.php` are blocked from direct HTTP access (`.htaccess` is included for Apache).
3. For Nginx, add:
   ```nginx
   location ~* /(config|database|setup)\.php$ {
       deny all;
   }
   location ^~ /backend-api/uploads/ {
       deny all;
   }
   ```
4. Set `API_BASE_URL` in `android-app/app/build.gradle.kts` to `https://YOUR_DOMAIN/backend-api/api/v1/`.
5. Configure cron or backup job for MySQL daily snapshots.
