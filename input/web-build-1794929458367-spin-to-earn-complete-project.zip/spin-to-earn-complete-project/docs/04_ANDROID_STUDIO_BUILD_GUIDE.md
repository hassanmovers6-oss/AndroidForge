# 04. Android Studio Build & Debug APK Instructions

## Prerequisites
- Android Studio Jellyfish / Koala or newer (AGP 8.5.2, Gradle 8.7+, JDK 17)
- Android SDK Platform 34

## Steps to Build Debug APK
1. Open `android-app/` in Android Studio.
2. Wait for Gradle Sync to finish.
3. Update `API_BASE_URL` in `android-app/app/build.gradle.kts` to point to your hosted HTTPS backend URL.
4. Build the Debug APK via UI (**Build -> Build Bundle(s) / APK(s) -> Build APK(s)**) or via terminal:
   ```bash
   cd android-app
   gradle assembleDebug
   ```
5. Output location: `android-app/app/build/outputs/apk/debug/app-debug.apk`.
6. Note on Test Ads: Keep Google Test Ad Unit IDs active during all QA and emulator runs. Never click live ads.
