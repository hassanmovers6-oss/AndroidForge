# Keep Retrofit models & AdMob classes
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.spintoearn.app.data.model.** { *; }
-keep class com.google.android.gms.ads.** { *; }
