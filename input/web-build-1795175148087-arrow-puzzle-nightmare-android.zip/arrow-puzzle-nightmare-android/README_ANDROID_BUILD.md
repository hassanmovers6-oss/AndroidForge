# Arrow Puzzle – Nightmare Edition (Android Project)

- **Package Name**: `com.educationwithhassan.arrowpuzzle`
- **Developer**: Rana Hassan
- **Min SDK**: 26 (Android 8.0 Oreo)
- **Target SDK**: 35
- **Orientation**: Portrait (`android:screenOrientation="portrait"`)

## Opening & Building in Android Studio

1. Extract the downloaded ZIP (`arrow-puzzle-nightmare-android.zip`).
2. Open Android Studio (Ladybug / 2024.2+ recommended) and choose **Open** on the extracted folder.
3. Let Gradle sync (`compileSdk 35`, Kotlin `2.0.21`, Jetpack Compose BOM `2024.10.01`).
4. Connect an Android 8.0+ device or start an Emulator, then click **Run 'app'**.
5. To build a signed release APK/AAB: **Build > Generate Signed Bundle / APK**.

## Google AdMob Integration Summary

Production AdMob identifiers are configured in:
1. `app/src/main/AndroidManifest.xml` (`com.google.android.gms.ads.APPLICATION_ID`)
2. `app/src/main/java/com/educationwithhassan/arrowpuzzle/ads/AdMobConfig.kt` (App Open, Adaptive Banner, Interstitial, Native Advanced, Rewarded unit IDs)

Centralized lifecycle, UMP consent, frequency caps, and retry backoff are managed in:
- `ads/ConsentManager.kt` (Google UMP consent flow + privacy options)
- `ads/AdMobManager.kt` (App Open 4-hour cap + cold-launch gate + active-gameplay guard; Interstitial 3-level & 3-minute cadence with 5s exponential retry backoff; Rewarded verification via `OnUserEarnedRewardListener`; silent preloaded Native Advanced cache; `destroy()` cleanup)
- `ads/AdComposables.kt` (`AdaptiveBannerAd` with reserved height & lifecycle pause/resume/destroy; silent `NativeAdCard` with `MediaView` binding)
