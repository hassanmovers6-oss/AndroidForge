package com.educationwithhassan.arrowpuzzle.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.arrowpuzzle.ads.AdMobManager
import com.educationwithhassan.arrowpuzzle.ads.NativeAdCard
import com.educationwithhassan.arrowpuzzle.data.PlayerProgressState
import com.educationwithhassan.arrowpuzzle.engine.ChapterCatalog
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowColors

@Composable
fun LevelSelectScreen(
    progress: PlayerProgressState,
    adMobManager: AdMobManager,
    onSelectLevel: (Int) -> Unit,
    onBack: () -> Unit
) {
    val initialChapter = ChapterCatalog.getChapterForLevel(progress.unlockedLevel).id
    var activeChapterId by remember { mutableIntStateOf(initialChapter) }
    val activeChapter = ChapterCatalog.chapters.first { it.id == activeChapterId }
    val levels = (activeChapter.startLevel..activeChapter.endLevel).toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = ArrowColors.CardWhite,
                        border = BorderStroke(1.dp, ArrowColors.SlateBorder)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                    Column {
                        Text("Chapters & Levels", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("${ChapterCatalog.TOTAL_CAMPAIGN_LEVELS} Levels · ${ChapterCatalog.chapters.size} Chapters", fontSize = 12.sp, color = ArrowColors.SlateMuted)
                    }
                }
                Text(
                    "${progress.unlockedLevel}/${ChapterCatalog.TOTAL_CAMPAIGN_LEVELS}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ArrowColors.SlateMuted
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ChapterCatalog.chapters.forEach { ch ->
                    val selected = ch.id == activeChapterId
                    Button(
                        onClick = { activeChapterId = ch.id },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) ArrowColors.NavyInk else ArrowColors.CardWhite,
                            contentColor = if (selected) Color.White else ArrowColors.NavyInk
                        ),
                        border = if (selected) null else BorderStroke(1.dp, ArrowColors.SlateBorder),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("Ch.${ch.id} · ${ch.primaryDifficulty.displayName}", fontSize = 12.sp)
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
                border = BorderStroke(1.dp, ArrowColors.SlateBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(activeChapter.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(activeChapter.subtitle, fontSize = 12.sp, color = ArrowColors.SlateMuted)
                }
            }

            NativeAdCard(adMobManager = adMobManager)

            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(levels) { levelId ->
                    val unlocked = levelId <= progress.unlockedLevel
                    val record = progress.completedLevels[levelId]
                    val isCurrent = levelId == progress.unlockedLevel

                    Card(
                        onClick = { if (unlocked) onSelectLevel(levelId) },
                        enabled = unlocked,
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when {
                                isCurrent -> ArrowColors.NavyInk
                                unlocked -> ArrowColors.CardWhite
                                else -> Color(0xFFF1F5F9)
                            }
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isCurrent) ArrowColors.NavyInk else ArrowColors.SlateBorder
                        ),
                        modifier = Modifier.height(60.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "$levelId",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isCurrent) Color.White else if (unlocked) ArrowColors.NavyInk else ArrowColors.SlateMuted
                                )
                                if (!unlocked) {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(11.dp), tint = ArrowColors.SlateMuted)
                                }
                            }
                            if (record != null) {
                                Row {
                                    for (s in 1..3) {
                                        Icon(
                                            Icons.Default.Star,
                                            contentDescription = null,
                                            tint = if (s <= record.stars) ArrowColors.AmberStar else Color(0xFFE2E8F0),
                                            modifier = Modifier.size(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
