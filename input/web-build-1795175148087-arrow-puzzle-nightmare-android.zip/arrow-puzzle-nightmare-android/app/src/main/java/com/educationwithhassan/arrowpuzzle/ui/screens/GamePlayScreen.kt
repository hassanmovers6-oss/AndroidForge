package com.educationwithhassan.arrowpuzzle.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.arrowpuzzle.audio.SoundAndHapticManager
import com.educationwithhassan.arrowpuzzle.data.PlayerProgressState
import com.educationwithhassan.arrowpuzzle.engine.ChapterCatalog
import com.educationwithhassan.arrowpuzzle.engine.PuzzleGenerator
import com.educationwithhassan.arrowpuzzle.model.ArrowEntity
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import com.educationwithhassan.arrowpuzzle.model.GridPoint
import com.educationwithhassan.arrowpuzzle.model.HintResult
import com.educationwithhassan.arrowpuzzle.model.PuzzleLevel
import com.educationwithhassan.arrowpuzzle.ui.components.ExitingArrowState
import com.educationwithhassan.arrowpuzzle.ui.components.MazeBoardCanvas
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowColors
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun GamePlayScreen(
    level: PuzzleLevel,
    progress: PlayerProgressState,
    hasNextLevel: Boolean,
    soundManager: SoundAndHapticManager,
    onConsumeHint: () -> Boolean,
    onRequestRewardedHint: (onUnavailable: () -> Unit) -> Unit,
    onRequestRewardedLife: (onGranted: () -> Unit, onUnavailable: () -> Unit) -> Unit,
    onToggleSound: () -> Unit,
    onRecordMovesDelta: (moves: Int, mistakes: Int) -> Unit,
    onLevelComplete: (stars: Int, moves: Int, mistakes: Int, elapsedMs: Long) -> Unit,
    onNextLevel: () -> Unit,
    onExitHome: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var remainingArrows by remember(level) { mutableStateOf(level.arrows) }
    val undoStack = remember(level) { mutableStateListOf<List<ArrowEntity>>() }
    val exitingAnims = remember(level) { mutableStateMapOf<String, Pair<ArrowEntity, Animatable<Float, *>>>() }
    val exitingJobs = remember(level) { mutableMapOf<String, Job>() }

    var lives by remember(level) { mutableIntStateOf(3) }
    var moves by remember(level) { mutableIntStateOf(0) }
    var mistakes by remember(level) { mutableIntStateOf(0) }
    var elapsedMs by remember(level) { mutableLongStateOf(0L) }
    var isPaused by remember(level) { mutableStateOf(false) }
    var isWon by remember(level) { mutableStateOf(false) }
    var isGameOver by remember(level) { mutableStateOf(false) }
    var activeHint by remember(level) { mutableStateOf<HintResult?>(null) }
    var statusText by remember(level) {
        mutableStateOf(level.tutorialText ?: "Study the maze carefully. Tap an arrow with a clear sightline.")
    }
    var blockedArrowId by remember(level) { mutableStateOf<String?>(null) }
    var blockerArrowId by remember(level) { mutableStateOf<String?>(null) }
    var blockerPoint by remember(level) { mutableStateOf<GridPoint?>(null) }
    var shakeTick by remember(level) { mutableIntStateOf(0) }
    var showInfoDialog by remember(level) { mutableStateOf(false) }
    var showRewardedHintDialog by remember(level) { mutableStateOf(false) }

    val exitDurationMs = ChapterCatalog.getArrowExitDurationMs(
        levelId = level.id,
        difficulty = level.difficulty,
        speedMultiplier = progress.arrowSpeedMultiplier
    )

    val difficultyColor = when (level.difficulty) {
        Difficulty.EASY_PRACTICE -> Color(0xFF047857)
        Difficulty.VERY_HARD -> Color(0xFFB45309)
        Difficulty.EXTREME -> Color(0xFFC2410C)
        else -> ArrowColors.CrimsonHeart
    }

    fun cancelAllExitingAnimations() {
        exitingJobs.values.forEach { it.cancel() }
        exitingJobs.clear()
        exitingAnims.clear()
    }

    DisposableEffect(level) {
        onDispose {
            cancelAllExitingAnimations()
        }
    }

    LaunchedEffect(level, isPaused, isWon, isGameOver) {
        while (!isPaused && !isWon && !isGameOver) {
            delay(250L)
            elapsedMs += 250L
        }
    }

    LaunchedEffect(blockedArrowId) {
        if (blockedArrowId != null) {
            delay(650L)
            blockedArrowId = null
            blockerArrowId = null
            blockerPoint = null
        }
    }

    fun restart() {
        soundManager.playClick()
        cancelAllExitingAnimations()
        remainingArrows = level.arrows
        undoStack.clear()
        lives = 3
        moves = 0
        mistakes = 0
        elapsedMs = 0L
        isPaused = false
        isWon = false
        isGameOver = false
        activeHint = null
        blockedArrowId = null
        blockerArrowId = null
        blockerPoint = null
        statusText = "Board reset. Plan your escape sequence."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top HUD (Banner intentionally hidden during active play)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = CircleShape,
                    color = ArrowColors.CardWhite,
                    border = BorderStroke(1.dp, ArrowColors.SlateBorder)
                ) {
                    IconButton(onClick = {
                        soundManager.playClick()
                        onExitHome()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Home")
                    }
                }
                Column {
                    Text(level.title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = ArrowColors.NavyInk)
                    Text(
                        "${level.difficulty.displayName} · Glide ${"%.1f".format(exitDurationMs / 1000.0)}s",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = difficultyColor
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = CircleShape,
                    color = ArrowColors.CardWhite,
                    border = BorderStroke(1.dp, ArrowColors.SlateBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 1..3) {
                            Icon(
                                imageVector = if (i <= lives) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = null,
                                tint = if (i <= lives) ArrowColors.CrimsonHeart else Color(0xFFCBD5E1),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = ArrowColors.CardWhite,
                    border = BorderStroke(1.dp, ArrowColors.SlateBorder)
                ) {
                    IconButton(onClick = {
                        soundManager.playClick()
                        isPaused = true
                    }) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause")
                    }
                }
            }
        }

        // Center Puzzle Board
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically)
        ) {
            if (level.tutorialText != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFECFDF5),
                    border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = level.tutorialText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF065F46),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Arrows: ${remainingArrows.size}/${level.arrows.size}", fontSize = 12.sp, color = ArrowColors.SlateMuted)
                Text("Grid: ${level.width}x${level.height}", fontSize = 12.sp, color = ArrowColors.SlateMuted)
                Text("Moves: $moves · ${formatElapsed(elapsedMs)}", fontSize = 12.sp, color = ArrowColors.SlateMuted)
            }

            val renderExiting = exitingAnims.values.map { (arr, anim) ->
                ExitingArrowState(arr, anim.value)
            }

            MazeBoardCanvas(
                width = level.width,
                height = level.height,
                arrows = if (isPaused) emptyList() else remainingArrows,
                obstacles = if (isPaused) emptyList() else level.obstacles,
                exitingArrows = if (isPaused) emptyList() else renderExiting,
                hintArrowId = activeHint?.arrowId,
                blockedArrowId = blockedArrowId,
                blockerArrowId = blockerArrowId,
                blockerPoint = blockerPoint,
                shakeTick = shakeTick,
                disabled = isPaused || isWon || isGameOver,
                modifier = Modifier.weight(1f, fill = false),
                onTapArrow = { arrow ->
                    // Block re-tapping arrows currently gliding out
                    if (exitingAnims.containsKey(arrow.id)) return@MazeBoardCanvas

                    val liveSnapshot = remainingArrows
                    val check = PuzzleGenerator.checkArrowEscape(
                        arrow,
                        liveSnapshot,
                        level.obstacles,
                        level.width,
                        level.height
                    )
                    if (check.canEscape) {
                        soundManager.playArrowSlide()
                        activeHint = null
                        blockedArrowId = null
                        blockerArrowId = null
                        blockerPoint = null

                        val anim = Animatable(0f)
                        exitingAnims[arrow.id] = arrow to anim
                        statusText = "Arrow gliding out of the maze..."

                        val job = scope.launch {
                            try {
                                anim.animateTo(
                                    targetValue = 1f,
                                    animationSpec = tween(
                                        durationMillis = exitDurationMs.toInt().coerceAtLeast(140),
                                        easing = LinearEasing
                                    )
                                )
                                exitingAnims.remove(arrow.id)
                                exitingJobs.remove(arrow.id)

                                val preRemoval = remainingArrows
                                if (preRemoval.none { it.id == arrow.id }) return@launch
                                val nextRemaining = preRemoval.filter { it.id != arrow.id }
                                undoStack.add(preRemoval)
                                remainingArrows = nextRemaining
                                moves += 1
                                onRecordMovesDelta(1, 0)

                                if (nextRemaining.isEmpty()) {
                                    val stars = when (mistakes) {
                                        0 -> 3
                                        1 -> 2
                                        else -> 1
                                    }
                                    isWon = true
                                    statusText = "All arrows escaped!"
                                    soundManager.playWin()
                                    onLevelComplete(stars, moves, mistakes, elapsedMs)
                                } else {
                                    statusText = "${nextRemaining.size} arrows remaining."
                                }
                            } catch (_: kotlinx.coroutines.CancellationException) {
                                exitingAnims.remove(arrow.id)
                                exitingJobs.remove(arrow.id)
                            }
                        }
                        exitingJobs[arrow.id] = job
                    } else {
                        soundManager.playBlocked()
                        soundManager.playHeartLost()
                        lives = (lives - 1).coerceAtLeast(0)
                        mistakes += 1
                        shakeTick += 1
                        blockedArrowId = arrow.id
                        blockerArrowId = check.blockerArrowId
                        blockerPoint = check.blockerPoint
                        onRecordMovesDelta(1, 1)
                        statusText = if (check.blockerType == "OBSTACLE") {
                            "Path blocked by an immovable wall."
                        } else {
                            "Path blocked by another arrow ahead."
                        }
                        if (lives == 0) {
                            isGameOver = true
                            soundManager.playGameOver()
                        }
                    }
                }
            )

            Text(
                text = statusText,
                fontSize = 12.sp,
                color = if (blockedArrowId != null) ArrowColors.CrimsonHeart else if (activeHint != null) ArrowColors.CobaltHint else ArrowColors.SlateMuted,
                textAlign = TextAlign.Center
            )
        }

        // Bottom Circular Controls
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularControl(
                icon = Icons.AutoMirrored.Filled.Undo,
                label = "Undo",
                enabled = undoStack.isNotEmpty(),
                onClick = {
                    if (undoStack.isNotEmpty() && !isPaused && !isWon && !isGameOver) {
                        soundManager.playClick()
                        cancelAllExitingAnimations()
                        remainingArrows = undoStack.removeAt(undoStack.lastIndex)
                        activeHint = null
                        statusText = "Last extracted arrow restored."
                    }
                }
            )
            CircularControl(
                icon = Icons.Default.Refresh,
                label = "Restart",
                onClick = { restart() }
            )
            val isHintLocked = !progress.hintsUnlockedByAd || progress.hintsRemaining <= 0
            CircularControl(
                icon = Icons.Default.Lightbulb,
                label = if (isHintLocked) "Hint (Locked)" else "Hint (${progress.hintsRemaining})",
                primary = true,
                showAdBadge = true,
                showLockOverlay = isHintLocked,
                onClick = {
                    soundManager.playClick()
                    if (activeHint != null) {
                        statusText = activeHint!!.explanation
                    } else if (isHintLocked) {
                        showRewardedHintDialog = true
                    } else {
                        val hint = PuzzleGenerator.findSafeHint(
                            remainingArrows = remainingArrows,
                            obstacles = level.obstacles,
                            width = level.width,
                            height = level.height,
                            excludeArrowIds = exitingAnims.keys.toSet()
                        )
                        if (hint != null && onConsumeHint()) {
                            activeHint = hint
                            statusText = hint.explanation
                        }
                    }
                }
            )
            CircularControl(
                icon = if (progress.soundEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                label = "Sound",
                onClick = {
                    soundManager.playClick()
                    onToggleSound()
                }
            )
            CircularControl(
                icon = Icons.Default.Info,
                label = "Info",
                onClick = {
                    soundManager.playClick()
                    showInfoDialog = true
                }
            )
        }
    }

    if (showInfoDialog) {
        val densityPct = (level.metrics.boardDensity * 100.0).toInt()
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = { Text(level.title) },
            text = {
                Text(
                    "Difficulty: ${level.difficulty.displayName}\n" +
                        "Board: ${level.width}x${level.height} (${densityPct}% fill)\n" +
                        "Glide Duration: ${"%.2f".format(exitDurationMs / 1000.0)}s\n" +
                        "Complexity Score: ${level.metrics.difficultyScore}\n" +
                        "Total Arrows: ${level.arrows.size} (${level.metrics.blockedArrowCount} blocked)\n" +
                        "Initial Safe Moves: ${level.metrics.initialFreeCount}\n" +
                        "Dependency Edges: ${level.metrics.dependencyEdgeCount}\n" +
                        "Dependency Waves: ${level.metrics.maxDependencyDepth}"
                )
            },
            confirmButton = {
                Button(onClick = { showInfoDialog = false }) { Text("Close") }
            }
        )
    }

    if (isPaused) {
        AlertDialog(
            onDismissRequest = { isPaused = false },
            title = { Text("Game Paused") },
            text = { Text("Timer suspended and board concealed.") },
            confirmButton = {
                Button(onClick = { isPaused = false }) { Text("Resume") }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { restart() }) { Text("Restart") }
                    OutlinedButton(onClick = onExitHome) { Text("Home") }
                }
            }
        )
    }

    if (isWon) {
        val earnedStars = when (mistakes) { 0 -> 3; 1 -> 2; else -> 1 }
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Board Cleared!") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (s in 1..3) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = null,
                                tint = if (s <= earnedStars) ArrowColors.AmberStar else Color(0xFFE2E8F0),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Moves: $moves · Time: ${formatElapsed(elapsedMs)} · Mistakes: $mistakes")
                }
            },
            confirmButton = {
                if (hasNextLevel) {
                    Button(onClick = onNextLevel) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Text("Next Level")
                    }
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { restart() }) { Text("Replay") }
                    OutlinedButton(onClick = onExitHome) { Text("Home") }
                }
            }
        )
    }

    if (showRewardedHintDialog) {
        AlertDialog(
            onDismissRequest = { showRewardedHintDialog = false },
            title = { Text("Out of Hints") },
            text = { Text("Watch an optional rewarded video to earn +2 Hints for puzzle assistance?") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.NavyInk),
                    onClick = {
                        showRewardedHintDialog = false
                        onRequestRewardedHint {
                            statusText = "No rewarded ad available right now. Keep solving!"
                        }
                    }
                ) {
                    Text("Watch Ad (+2 Hints)")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRewardedHintDialog = false }) {
                    Text("No Thanks")
                }
            }
        )
    }

    if (isGameOver) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Out of Lives") },
            text = { Text("${remainingArrows.size} arrows remained. Restore 1 life with an optional ad or retry freely.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.CrimsonHeart),
                    onClick = {
                        onRequestRewardedLife(
                            {
                                lives = 1
                                isGameOver = false
                                statusText = "1 life restored!"
                            },
                            {
                                statusText = "No rewarded ad ready right now. Tap Retry to play again."
                            }
                        )
                    }
                ) {
                    Text("Watch Ad (+1 Life)")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { restart() }) { Text("Retry") }
                    OutlinedButton(onClick = onExitHome) { Text("No Thanks · Home") }
                }
            }
        )
    }
}

@Composable
private fun CircularControl(
    icon: ImageVector,
    label: String,
    enabled: Boolean = true,
    primary: Boolean = false,
    showAdBadge: Boolean = false,
    showLockOverlay: Boolean = false,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Surface(
                shape = CircleShape,
                color = if (primary) ArrowColors.NavyInk else ArrowColors.CardWhite,
                border = if (primary) null else BorderStroke(1.dp, ArrowColors.SlateBorder),
                modifier = Modifier.size(48.dp)
            ) {
                IconButton(onClick = onClick, enabled = enabled) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (primary) Color.White else if (enabled) ArrowColors.NavyInk else Color(0xFFCBD5E1)
                    )
                }
            }
            if (showLockOverlay) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked",
                    tint = Color(0xFFFCD34D),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(3.dp)
                        .size(13.dp)
                )
            }
            if (showAdBadge) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFFBBF24),
                    border = BorderStroke(1.dp, Color.White),
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Text(
                        text = "Ad",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = ArrowColors.NavyInk,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }
        }
        Text(label, fontSize = 11.sp, color = ArrowColors.SlateMuted)
    }
}

private fun formatElapsed(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return "%02d:%02d".format(mins, secs)
}
