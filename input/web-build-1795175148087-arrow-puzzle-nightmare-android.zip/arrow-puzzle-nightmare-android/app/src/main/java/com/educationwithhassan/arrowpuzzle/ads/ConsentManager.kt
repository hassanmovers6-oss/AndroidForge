package com.educationwithhassan.arrowpuzzle.ads

import android.app.Activity
import android.content.Context
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

class ConsentManager(context: Context) {
    private val consentInformation: ConsentInformation =
        UserMessagingPlatform.getConsentInformation(context)

    val canRequestAds: Boolean
        get() = consentInformation.canRequestAds()

    val isPrivacyOptionsRequired: Boolean
        get() = consentInformation.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun gatherConsent(
        activity: Activity,
        onConsentGatheringComplete: (canRequestAds: Boolean) -> Unit
    ) {
        val completed = AtomicBoolean(false)
        fun completeOnce() {
            if (completed.compareAndSet(false, true)) {
                onConsentGatheringComplete(consentInformation.canRequestAds())
            }
        }

        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                if (activity.isFinishing || activity.isDestroyed) {
                    completeOnce()
                    return@requestConsentInfoUpdate
                }
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                    completeOnce()
                }
            },
            { _ ->
                // Proceed gracefully if offline or UMP server is unreachable
                completeOnce()
            }
        )
    }

    fun showPrivacyOptionsForm(
        activity: Activity,
        onDismissed: () -> Unit
    ) {
        if (activity.isFinishing || activity.isDestroyed) {
            onDismissed()
            return
        }
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ ->
            onDismissed()
        }
    }
}
