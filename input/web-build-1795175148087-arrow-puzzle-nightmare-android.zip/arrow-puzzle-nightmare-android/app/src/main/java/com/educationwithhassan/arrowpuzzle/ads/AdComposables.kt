package com.educationwithhassan.arrowpuzzle.ads

import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.educationwithhassan.arrowpuzzle.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAdView

@Composable
fun AdaptiveBannerAd(
    isSdkInitialized: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val screenWidthDp = LocalConfiguration.current.screenWidthDp.coerceAtLeast(320)

    val adSize = remember(screenWidthDp) {
        AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, screenWidthDp)
    }
    val reservedHeightDp = remember(adSize) { adSize.height.coerceAtLeast(50).dp }

    val adView = remember(adSize) {
        AdView(context).apply {
            adUnitId = AdMobConfig.BANNER_AD_UNIT_ID
            setAdSize(adSize)
        }
    }
    var hasRequestedLoad by remember(adView) { mutableStateOf(false) }

    LaunchedEffect(adView, isSdkInitialized) {
        if (isSdkInitialized && !hasRequestedLoad) {
            hasRequestedLoad = true
            adView.loadAd(AdRequest.Builder().build())
        }
    }

    DisposableEffect(lifecycleOwner, adView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> adView.resume()
                Lifecycle.Event.ON_PAUSE -> adView.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            adView.destroy()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        HorizontalDivider(thickness = 1.dp, color = Color(0xFFE2E8F0))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(reservedHeightDp),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { adView },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Silent, policy-compliant Native Advanced Ad card reusing the centralized preloaded NativeAd
 * from AdMobManager without triggering duplicate requests on navigation or recomposition.
 * Never shows Toasts, Snackbars, or alerts on load or failure.
 */
@Composable
fun NativeAdCard(
    adMobManager: AdMobManager,
    modifier: Modifier = Modifier
) {
    val currentAd by adMobManager.nativeAdFlow.collectAsState()
    val ad = currentAd ?: return

    AndroidView(
        factory = { ctx ->
            LayoutInflater.from(ctx).inflate(R.layout.native_ad_layout, null) as NativeAdView
        },
        update = { adView ->
            if (adView.tag === ad) return@AndroidView
            adView.tag = ad

            val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
            val bodyView = adView.findViewById<TextView>(R.id.ad_body)
            val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)
            val iconView = adView.findViewById<ImageView>(R.id.ad_app_icon)
            val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)

            headlineView.text = ad.headline
            adView.headlineView = headlineView

            bodyView.text = ad.body ?: ""
            bodyView.visibility = if (ad.body != null) View.VISIBLE else View.GONE
            adView.bodyView = bodyView

            ctaView.text = ad.callToAction ?: "Learn More"
            ctaView.visibility = if (ad.callToAction != null) View.VISIBLE else View.GONE
            adView.callToActionView = ctaView

            if (ad.icon != null) {
                iconView.setImageDrawable(ad.icon?.drawable)
                iconView.visibility = View.VISIBLE
                adView.iconView = iconView
            } else {
                iconView.visibility = View.GONE
            }

            if (ad.mediaContent != null) {
                mediaView.mediaContent = ad.mediaContent
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
            } else {
                mediaView.visibility = View.GONE
            }

            advertiserView.text = ad.advertiser ?: "Sponsored"
            adView.advertiserView = advertiserView

            adView.setNativeAd(ad)
        },
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
    )
}
