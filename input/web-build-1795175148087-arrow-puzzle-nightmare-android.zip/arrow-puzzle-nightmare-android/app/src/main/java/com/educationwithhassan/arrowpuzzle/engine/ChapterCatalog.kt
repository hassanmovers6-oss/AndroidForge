package com.educationwithhassan.arrowpuzzle.engine

import com.educationwithhassan.arrowpuzzle.model.ChapterInfo
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import java.time.LocalDate
import kotlin.math.roundToLong

object ChapterCatalog {
    const val TOTAL_CAMPAIGN_LEVELS = 500
    const val LEVELS_PER_CHAPTER = 50

    val chapters: List<ChapterInfo> = listOf(
        ChapterInfo(1, "Chapter 1: Practice & Awakening", "Level 1 tutorial followed by escalating Very Hard to Insane boards", 1, 50, Difficulty.INSANE),
        ChapterInfo(2, "Chapter 2: Nightmare", "Dense multi-layer corridors & razor-thin safe openings", 51, 100, Difficulty.NIGHTMARE),
        ChapterInfo(3, "Chapter 3: Brutal Nightmare I", "Long interlocking arrow chains & corridor bottlenecks", 101, 150, Difficulty.BRUTAL_NIGHTMARE),
        ChapterInfo(4, "Chapter 4: Brutal Nightmare II", "Complex directional patterns & hidden dead-end traps", 151, 200, Difficulty.BRUTAL_NIGHTMARE),
        ChapterInfo(5, "Chapter 5: Master Nightmare I", "Massive 68x68+ boards with 1,500+ tightly packed arrows", 201, 250, Difficulty.MASTER_NIGHTMARE),
        ChapterInfo(6, "Chapter 6: Master Nightmare II", "Extended multi-step escape sequences & deceptive layouts", 251, 300, Difficulty.MASTER_NIGHTMARE),
        ChapterInfo(7, "Chapter 7: Master Nightmare III", "High-density marathon labyrinth architecture", 301, 350, Difficulty.MASTER_NIGHTMARE),
        ChapterInfo(8, "Chapter 8: Ultimate Nightmare I", "Ultra-dense 73x73–78x78 labyrinths nearing 2,000 arrows", 351, 400, Difficulty.ULTIMATE_NIGHTMARE),
        ChapterInfo(9, "Chapter 9: Ultimate Nightmare II", "Deepest dependency chains & master-tier marathon layouts", 401, 450, Difficulty.ULTIMATE_NIGHTMARE),
        ChapterInfo(10, "Chapter 10: Ultimate Nightmare III", "Final 2,000-arrow gauntlet culminating in Level 500", 451, 500, Difficulty.ULTIMATE_NIGHTMARE)
    )

    fun getChapterForLevel(levelId: Int): ChapterInfo {
        val clamped = levelId.coerceIn(1, TOTAL_CAMPAIGN_LEVELS)
        val index = (clamped - 1) / LEVELS_PER_CHAPTER
        return chapters[index]
    }

    fun getDifficultyForLevel(levelId: Int): Difficulty = when {
        levelId <= 1 -> Difficulty.EASY_PRACTICE
        levelId <= 10 -> Difficulty.VERY_HARD
        levelId <= 25 -> Difficulty.EXTREME
        levelId <= 50 -> Difficulty.INSANE
        levelId <= 100 -> Difficulty.NIGHTMARE
        levelId <= 200 -> Difficulty.BRUTAL_NIGHTMARE
        levelId <= 350 -> Difficulty.MASTER_NIGHTMARE
        else -> Difficulty.ULTIMATE_NIGHTMARE
    }

    fun getArrowExitDurationMs(
        levelId: Int,
        difficulty: Difficulty,
        speedMultiplier: Float = 1.0f
    ): Long {
        val baseMs = when {
            levelId == 1 || difficulty == Difficulty.EASY_PRACTICE -> 240.0
            levelId in 2..10 -> 300.0
            levelId in 11..50 -> 350.0
            levelId in 51..200 -> 400.0
            levelId >= 201 -> 460.0
            else -> when (difficulty) {
                Difficulty.VERY_HARD -> 300.0
                Difficulty.EXTREME, Difficulty.INSANE -> 350.0
                Difficulty.NIGHTMARE, Difficulty.BRUTAL_NIGHTMARE -> 400.0
                else -> 460.0
            }
        }
        val safeMult = speedMultiplier.coerceIn(0.7f, 1.4f).toDouble()
        return (baseMs * safeMult).roundToLong()
    }

    fun getDailySeed(date: LocalDate = LocalDate.now()): Pair<String, Long> {
        val dateKey = date.toString()
        var hash = 2166136261L
        for (ch in dateKey) {
            hash = hash xor ch.code.toLong()
            hash = (hash * 16777619L) and 0xFFFFFFFFL
        }
        return dateKey to (if (hash == 0L) 133742L else hash)
    }
}

