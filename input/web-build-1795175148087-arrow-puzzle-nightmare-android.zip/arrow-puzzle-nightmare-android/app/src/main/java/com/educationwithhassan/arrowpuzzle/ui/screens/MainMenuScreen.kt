package com.educationwithhassan.arrowpuzzle.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.arrowpuzzle.ads.AdMobManager
import com.educationwithhassan.arrowpuzzle.ads.NativeAdCard
import com.educationwithhassan.arrowpuzzle.data.PlayerProgressState
import com.educationwithhassan.arrowpuzzle.engine.ChapterCatalog
import com.educationwithhassan.arrowpuzzle.model.AppScreen
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowColors

@Composable
fun MainMenuScreen(
    progress: PlayerProgressState,
    adMobManager: AdMobManager,
    onContinue: () -> Unit,
    onPlayDifficulty: (Difficulty) -> Unit,
    onStartDaily: () -> Unit,
    onStartRandom: () -> Unit,
    onNavigate: (AppScreen) -> Unit
) {
    val completedCount = progress.completedLevels.size
    val totalStars = progress.completedLevels.values.sumOf { it.stars }
    val (todayKey, _) = ChapterCatalog.getDailySeed()
    val isDailyDone = todayKey in progress.dailyCompletedDates

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Brand Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Arrow Puzzle",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = ArrowColors.NavyInk
                    )
                    Text(
                        text = "Nightmare Edition · By Rana Hassan",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = ArrowColors.CrimsonHeart
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = ArrowColors.CardWhite,
                        border = BorderStroke(1.dp, ArrowColors.SlateBorder)
                    ) {
                        IconButton(onClick = { onNavigate(AppScreen.STATISTICS) }) {
                            Icon(Icons.Default.BarChart, contentDescription = "Statistics", tint = ArrowColors.NavyInk)
                        }
                    }
                    Surface(
                        shape = CircleShape,
                        color = ArrowColors.CardWhite,
                        border = BorderStroke(1.dp, ArrowColors.SlateBorder)
                    ) {
                        IconButton(onClick = { onNavigate(AppScreen.SETTINGS) }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = ArrowColors.NavyInk)
                        }
                    }
                }
            }

            // Primary Hero Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
                border = BorderStroke(1.dp, ArrowColors.SlateBorder)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Campaign · $completedCount/${ChapterCatalog.TOTAL_CAMPAIGN_LEVELS} Cleared · $totalStars Stars",
                        fontSize = 12.sp,
                        color = ArrowColors.SlateMuted
                    )
                    Text(
                        text = "Escape the Labyrinth in Exact Logical Order",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = ArrowColors.NavyInk
                    )
                    Button(
                        onClick = onContinue,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.NavyInk),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text(
                            text = if (progress.unlockedLevel > 1) "Continue · Level ${progress.unlockedLevel}" else "Play · Level 1",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { onPlayDifficulty(Difficulty.NIGHTMARE) },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.CrimsonHeart),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Whatshot, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text("Nightmare Mode", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 2x2 Mode Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MenuTile(
                    icon = Icons.Default.Layers,
                    title = "${ChapterCatalog.TOTAL_CAMPAIGN_LEVELS} Levels",
                    subtitle = "${ChapterCatalog.chapters.size} Chapters",
                    onClick = { onNavigate(AppScreen.LEVEL_SELECT) },
                    modifier = Modifier.weight(1f)
                )
                MenuTile(
                    icon = Icons.Default.Tune,
                    title = "Difficulty",
                    subtitle = progress.selectedDifficulty.displayName,
                    onClick = { onNavigate(AppScreen.DIFFICULTY_SELECT) },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MenuTile(
                    icon = Icons.Default.CalendarToday,
                    title = "Daily Challenge",
                    subtitle = if (isDailyDone) "Completed Today" else "Streak: ${progress.dailyStreak}d",
                    onClick = onStartDaily,
                    modifier = Modifier.weight(1f)
                )
                MenuTile(
                    icon = Icons.Default.Shuffle,
                    title = "Random Board",
                    subtitle = progress.selectedDifficulty.displayName,
                    onClick = onStartRandom,
                    modifier = Modifier.weight(1f)
                )
            }

            // Native Advanced Ad Card
            NativeAdCard(adMobManager = adMobManager)

        // Privacy & About Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { onNavigate(AppScreen.PRIVACY) }) {
                    Icon(Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Privacy Policy", fontSize = 12.sp)
                }
                TextButton(onClick = { onNavigate(AppScreen.ABOUT) }) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("About Us", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MenuTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
        border = BorderStroke(1.dp, ArrowColors.SlateBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = ArrowColors.NavyInk)
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ArrowColors.NavyInk)
                Text(subtitle, fontSize = 12.sp, color = ArrowColors.SlateMuted)
            }
        }
    }
}
