package com.educationwithhassan.arrowpuzzle.ads

import com.google.android.gms.ads.AdRequest

/**
 * Centralized Google AdMob production configuration for Arrow Puzzle – Nightmare Edition.
 * Identifiers are kept strictly internal and never displayed in user-facing UI.
 */
object AdMobConfig {
    const val ADMOB_APP_ID = "ca-app-pub-3133971041724338~2576474017"
    const val APP_OPEN_AD_UNIT_ID = "ca-app-pub-3133971041724338/3930964467"
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3133971041724338/6675501123"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3133971041724338/5362419458"
    const val NATIVE_AD_UNIT_ID = "ca-app-pub-3133971041724338/2736256113"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3133971041724338/6020895009"

    // Applied only on debug builds so emulators receive safe test fill.
    val DEBUG_TEST_DEVICE_IDS: List<String> = listOf(
        AdRequest.DEVICE_ID_EMULATOR
    )

    // Policy & pacing guardrails
    const val APP_OPEN_EXPIRY_MS = 4 * 60 * 60 * 1000L          // 4 hours ad cache expiration
    const val APP_OPEN_FREQUENCY_CAP_MS = 4 * 60 * 60 * 1000L   // Max 1 App Open impression every 4 hours
    const val APP_OPEN_COLD_START_TIMEOUT_MS = 2500L            // Initial loading screen wait cap

    const val INTERSTITIAL_LEVEL_CADENCE = 3                    // ~1 interstitial every 3 completed levels
    const val INTERSTITIAL_MIN_INTERVAL_MS = 3 * 60 * 1000L     // Minimum 3-minute interval between interstitials

    // Failed load retry backoff (5s initial, fixed 5s retry for Interstitial preloading)
    const val INTERSTITIAL_RELOAD_RETRY_MS = 5000L
    const val RETRY_INITIAL_DELAY_MS = 5000L
    const val RETRY_MAX_DELAY_MS = 60_000L
    const val MAX_RETRY_EXPONENT = 4
}
