package com.educationwithhassan.arrowpuzzle.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.arrowpuzzle.model.ArrowEntity
import com.educationwithhassan.arrowpuzzle.model.Direction
import com.educationwithhassan.arrowpuzzle.model.GridPoint
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowColors
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ExitingArrowState(
    val arrow: ArrowEntity,
    val progress: Float
)

private data class PreparedArrowKt(
    val arrow: ArrowEntity,
    val minX: Int,
    val maxX: Int,
    val minY: Int,
    val maxY: Int
)

@Composable
fun MazeBoardCanvas(
    width: Int,
    height: Int,
    arrows: List<ArrowEntity>,
    obstacles: List<GridPoint>,
    exitingArrows: List<ExitingArrowState>,
    hintArrowId: String?,
    blockedArrowId: String?,
    blockerArrowId: String?,
    blockerPoint: GridPoint?,
    shakeTick: Int,
    disabled: Boolean,
    onTapArrow: (ArrowEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val shakeOffset = remember { Animatable(0f) }

    val maxZoom = remember(width) { max(2.5f, min(9.5f, width / 7.5f)) }
    val supportsZoom = width >= 8 || height >= 8
    var zoom by remember(width, height) { mutableFloatStateOf(1f) }
    var pan by remember(width, height) { mutableStateOf(Offset.Zero) }

    val exitingIdSet = remember(exitingArrows) {
        exitingArrows.mapTo(HashSet()) { it.arrow.id }
    }

    // Precompute spatial cell lookup (O(1) hit-test) & bounding boxes for viewport culling
    val (preparedArrows, cellLookup) = remember(arrows, width, height) {
        val lookup = IntArray(width * height) { -1 }
        val prepared = ArrayList<PreparedArrowKt>(arrows.size)
        for (i in arrows.indices) {
            val a = arrows[i]
            var minX = width
            var maxX = -1
            var minY = height
            var maxY = -1
            for (c in a.cells) {
                if (c.x in 0 until width && c.y in 0 until height) {
                    lookup[c.y * width + c.x] = i
                }
                if (c.x < minX) minX = c.x
                if (c.x > maxX) maxX = c.x
                if (c.y < minY) minY = c.y
                if (c.y > maxY) maxY = c.y
            }
            prepared.add(PreparedArrowKt(a, minX, maxX, minY, maxY))
        }
        prepared to lookup
    }

    fun clampPan(rawPan: Offset, currentZoom: Float, boardWidth: Float, boardHeight: Float): Offset {
        val maxX = max(0f, (boardWidth * (currentZoom - 1f)) / 2f)
        val maxY = max(0f, (boardHeight * (currentZoom - 1f)) / 2f)
        return Offset(
            rawPan.x.coerceIn(-maxX, maxX),
            rawPan.y.coerceIn(-maxY, maxY)
        )
    }

    LaunchedEffect(shakeTick) {
        if (shakeTick > 0) {
            for (x in listOf(-12f, 12f, -8f, 8f, 0f)) {
                shakeOffset.animateTo(x, animationSpec = tween(42))
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .weight(1f, fill = false)
                .aspectRatio(1f)
                .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                .clip(RoundedCornerShape(24.dp))
                .background(ArrowColors.CardWhite)
                .border(1.dp, ArrowColors.SlateBorder, RoundedCornerShape(24.dp))
        ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(preparedArrows, cellLookup, width, height, disabled, supportsZoom, maxZoom, exitingIdSet) {
                    val slop = viewConfiguration.touchSlop
                    awaitEachGesture {
                        val firstDown = awaitFirstDown(requireUnconsumed = false)
                        var totalMovement = 0f
                        var wasMultiTouch = false
                        var lastPosition = firstDown.position

                        do {
                            val event = awaitPointerEvent()
                            val pressedCount = event.changes.count { it.pressed }
                            if (pressedCount >= 2) {
                                wasMultiTouch = true
                            }

                            if (supportsZoom && (pressedCount >= 2 || zoom > 1.01f)) {
                                val zoomChange = event.calculateZoom()
                                val panChange = event.calculatePan()
                                val gestureDelta = hypot(panChange.x, panChange.y)
                                totalMovement += gestureDelta

                                if (zoomChange != 1f || (gestureDelta > 0.5f && (zoom > 1.01f || pressedCount >= 2))) {
                                    val nextZoom = (zoom * zoomChange).coerceIn(1f, maxZoom)
                                    zoom = nextZoom
                                    pan = if (nextZoom <= 1.01f) {
                                        Offset.Zero
                                    } else {
                                        clampPan(pan + panChange, nextZoom, size.width.toFloat(), size.height.toFloat())
                                    }
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            } else if (event.changes.isNotEmpty()) {
                                val curr = event.changes.first().position
                                totalMovement += hypot(curr.x - lastPosition.x, curr.y - lastPosition.y)
                                lastPosition = curr
                            }
                        } while (event.changes.any { it.pressed })

                        if (!disabled && !wasMultiTouch && totalMovement <= slop) {
                            val cxCenter = size.width / 2f
                            val cyCenter = size.height / 2f
                            val boardTapX = (firstDown.position.x - cxCenter - pan.x) / zoom + cxCenter
                            val boardTapY = (firstDown.position.y - cyCenter - pan.y) / zoom + cyCenter

                            val pad = size.width * 0.032f
                            val cellW = (size.width - pad * 2f) / width.toFloat()
                            val cellH = (size.height - pad * 2f) / height.toFloat()
                            val cellSize = minOf(cellW, cellH)
                            val strokeW = max(2.2f, cellSize * 0.21f)
                            val headR = max(3.0f, cellSize * 0.27f)
                            val maxShaftDist = max(strokeW * 1.15f, cellSize * 0.32f)
                            val maxHeadDist = max(headR * 1.25f, cellSize * 0.36f)

                            val exactGx = floor((boardTapX - pad) / cellSize).toInt()
                            val exactGy = floor((boardTapY - pad) / cellSize).toInt()
                            if (exactGx in 0 until width && exactGy in 0 until height) {
                                val arrowIdx = cellLookup[exactGy * width + exactGx]
                                if (arrowIdx >= 0) {
                                    val candidate = preparedArrows[arrowIdx].arrow
                                    if (candidate.id !in exitingIdSet) {
                                        var hit = false
                                        for (s in 1 until candidate.cells.size) {
                                            val c0 = candidate.cells[s - 1]
                                            val c1 = candidate.cells[s]
                                            val ax = pad + c0.x * cellSize + cellSize / 2f
                                            val ay = pad + c0.y * cellSize + cellSize / 2f
                                            val bx = pad + c1.x * cellSize + cellSize / 2f
                                            val by = pad + c1.y * cellSize + cellSize / 2f
                                            val d = distPointToSegmentKt(boardTapX, boardTapY, ax, ay, bx, by)
                                            if (d <= maxShaftDist) {
                                                hit = true
                                                break
                                            }
                                        }
                                        if (!hit) {
                                            val head = candidate.cells.last()
                                            val hx = pad + head.x * cellSize + cellSize / 2f
                                            val hy = pad + head.y * cellSize + cellSize / 2f
                                            if (hypot(boardTapX - hx, boardTapY - hy) <= maxHeadDist) {
                                                hit = true
                                            }
                                        }
                                        if (hit) {
                                            onTapArrow(candidate)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        ) {
            val pad = size.width * 0.032f
            val cellSize = minOf(
                (size.width - pad * 2f) / width.toFloat(),
                (size.height - pad * 2f) / height.toFloat()
            )
            val strokeWidth = max(2.2f, cellSize * 0.21f)
            val headRadius = max(3.0f, cellSize * 0.27f)

            fun toCenter(pt: GridPoint): Offset = Offset(
                pad + pt.x * cellSize + cellSize / 2f,
                pad + pt.y * cellSize + cellSize / 2f
            )

            // Compute visible grid window for tight viewport culling on 2,000-arrow boards
            val cxMid = size.width / 2f
            val cyMid = size.height / 2f
            val leftBoard = (0f - (cxMid + pan.x)) / zoom + cxMid
            val topBoard = (0f - (cyMid + pan.y)) / zoom + cyMid
            val rightBoard = (size.width - (cxMid + pan.x)) / zoom + cxMid
            val bottomBoard = (size.height - (cyMid + pan.y)) / zoom + cyMid

            val visMinX = max(0, floor((leftBoard - pad) / cellSize).toInt() - 2)
            val visMaxX = min(width - 1, ceil((rightBoard - pad) / cellSize).toInt() + 2)
            val visMinY = max(0, floor((topBoard - pad) / cellSize).toInt() - 2)
            val visMaxY = min(height - 1, ceil((bottomBoard - pad) / cellSize).toInt() + 2)

            withTransform({
                translate(left = pan.x, top = pan.y)
                scale(scaleX = zoom, scaleY = zoom, pivot = Offset(cxMid, cyMid))
            }) {
                // Batched dot matrix for fast 60fps rendering even on 70x70 grids
                val dotStep = if (zoom < 1.3f && width >= 48) 2 else 1
                val dotOffsets = ArrayList<Offset>(
                    (((visMaxY - visMinY) / dotStep + 1) * ((visMaxX - visMinX) / dotStep + 1)).coerceAtLeast(1)
                )
                var yy = visMinY
                while (yy <= visMaxY) {
                    val py = pad + yy * cellSize + cellSize / 2f
                    var xx = visMinX
                    while (xx <= visMaxX) {
                        dotOffsets.add(Offset(pad + xx * cellSize + cellSize / 2f, py))
                        xx += dotStep
                    }
                    yy += dotStep
                }
                drawPoints(
                    points = dotOffsets,
                    pointMode = PointMode.Points,
                    color = ArrowColors.SlateBorder,
                    strokeWidth = max(2.0f, cellSize * 0.08f),
                    cap = StrokeCap.Round
                )

                // Hint sightline guide
                val hintArrow = arrows.firstOrNull { it.id == hintArrowId }
                if (hintArrow != null) {
                    val headCenter = toCenter(hintArrow.cells.last())
                    val exitDist = (max(width, height) + 2) * cellSize
                    val end = Offset(
                        headCenter.x + hintArrow.direction.dx * exitDist,
                        headCenter.y + hintArrow.direction.dy * exitDist
                    )
                    drawLine(
                        color = Color(0xFF60A5FA),
                        start = headCenter,
                        end = end,
                        strokeWidth = max(2.2f, strokeWidth * 0.45f),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                    )
                }

                // Obstacle blocks (viewport-culled)
                for (obs in obstacles) {
                    if (obs.x !in visMinX..visMaxX || obs.y !in visMinY..visMaxY) continue
                    val center = toCenter(obs)
                    val boxSize = cellSize * 0.64f
                    val isHit = blockerPoint == obs
                    drawRoundRect(
                        color = if (isHit) ArrowColors.CrimsonHeart else ArrowColors.ObstacleWall,
                        topLeft = Offset(center.x - boxSize / 2f, center.y - boxSize / 2f),
                        size = Size(boxSize, boxSize),
                        cornerRadius = CornerRadius(max(3f, cellSize * 0.18f), max(3f, cellSize * 0.18f))
                    )
                }

                // Stationary arrows (viewport-culled, excluding arrows actively gliding out)
                for (item in preparedArrows) {
                    if (item.maxX < visMinX || item.minX > visMaxX || item.maxY < visMinY || item.minY > visMaxY) {
                        continue
                    }
                    val arrow = item.arrow
                    if (arrow.id in exitingIdSet) continue

                    val color = when {
                        arrow.id == blockedArrowId -> ArrowColors.CrimsonHeart
                        arrow.id == blockerArrowId -> Color(0xFFDC2626)
                        arrow.id == hintArrowId -> ArrowColors.CobaltHint
                        else -> ArrowColors.NavyInk
                    }
                    drawArrowEntity(
                        arrow = arrow,
                        toCenter = ::toCenter,
                        strokeWidth = strokeWidth,
                        headRadius = headRadius,
                        color = color,
                        isHighlighted = arrow.id == hintArrowId || arrow.id == blockedArrowId || arrow.id == blockerArrowId,
                        highlightAlpha = 0.25f,
                        exitProgress = null,
                        visibleExitDist = 0f
                    )
                }

                // Slowly gliding exiting arrows on top with glowing travel highlight
                for (anim in exitingArrows) {
                    val arrow = anim.arrow
                    val headCenter = toCenter(arrow.cells.last())
                    val distToEdge = when (arrow.direction) {
                        Direction.RIGHT -> size.width - headCenter.x + headRadius * 3f
                        Direction.LEFT -> headCenter.x + headRadius * 3f
                        Direction.DOWN -> size.height - headCenter.y + headRadius * 3f
                        Direction.UP -> headCenter.y + headRadius * 3f
                    }
                    val visibleExitDist = max(cellSize * 2.2f, distToEdge)
                    val glowAlpha = max(0.15f, 0.45f * (1f - anim.progress * 0.7f))

                    drawArrowEntity(
                        arrow = arrow,
                        toCenter = ::toCenter,
                        strokeWidth = strokeWidth,
                        headRadius = headRadius,
                        color = Color(0xFF1D4ED8),
                        isHighlighted = true,
                        highlightAlpha = glowAlpha,
                        exitProgress = anim.progress,
                        visibleExitDist = visibleExitDist
                    )
                }

                // Blocker highlight ring
                if (blockerPoint != null) {
                    drawCircle(
                        color = ArrowColors.CrimsonHeart,
                        radius = max(8f, cellSize * 0.36f),
                        center = toCenter(blockerPoint),
                        style = Stroke(width = 3.5f)
                    )
                }
            }
        }
        }

        if (supportsZoom) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = CircleShape,
                color = ArrowColors.CardWhite,
                border = BorderStroke(1.dp, ArrowColors.SlateBorder)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(0.dp),
                    modifier = Modifier.padding(horizontal = 6.dp)
                ) {
                    TextButton(
                        onClick = {
                            val next = (zoom - 0.5f).coerceIn(1f, maxZoom)
                            zoom = next
                            if (next <= 1.01f) pan = Offset.Zero
                        },
                        enabled = zoom > 1.05f,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("-", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = ArrowColors.NavyInk)
                    }
                    TextButton(
                        onClick = {
                            zoom = 1f
                            pan = Offset.Zero
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            if (zoom <= 1.02f) "Fit" else "${(zoom * 100f).roundToInt()}%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = ArrowColors.NavyInk
                        )
                    }
                    TextButton(
                        onClick = {
                            zoom = (zoom + 0.5f).coerceIn(1f, maxZoom)
                        },
                        enabled = zoom < maxZoom - 0.05f,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("+", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = ArrowColors.NavyInk)
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawArrowEntity(
    arrow: ArrowEntity,
    toCenter: (GridPoint) -> Offset,
    strokeWidth: Float,
    headRadius: Float,
    color: Color,
    isHighlighted: Boolean,
    highlightAlpha: Float,
    exitProgress: Float?,
    visibleExitDist: Float
) {
    val centers = arrow.cells.map(toCenter)
    val headCenter = centers.last()
    val dx = arrow.direction.dx.toFloat()
    val dy = arrow.direction.dy.toFloat()

    val bodyEnd = Offset(
        headCenter.x - dx * (headRadius * 0.45f),
        headCenter.y - dy * (headRadius * 0.45f)
    )
    val bodyPoints = centers.dropLast(1) + bodyEnd

    val bodyPath = Path().apply {
        moveTo(bodyPoints.first().x, bodyPoints.first().y)
        for (i in 1 until bodyPoints.size) {
            lineTo(bodyPoints[i].x, bodyPoints[i].y)
        }
    }

    if (exitProgress == null) {
        if (isHighlighted) {
            drawPath(
                path = bodyPath,
                color = color.copy(alpha = highlightAlpha),
                style = Stroke(width = strokeWidth * 2.3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        drawPath(
            path = bodyPath,
            color = color,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawCircle(color = color, radius = strokeWidth * 0.52f, center = centers.first())
        drawArrowHead(headCenter, arrow.direction, headRadius, color)
    } else {
        val rawT = exitProgress.coerceIn(0f, 1f)
        val eased = Math.pow(rawT.toDouble(), 0.85).toFloat()

        val fullPath = Path().apply {
            addPath(bodyPath)
            lineTo(headCenter.x + dx * visibleExitDist, headCenter.y + dy * visibleExitDist)
        }
        val measure = PathMeasure()
        measure.setPath(bodyPath, false)
        val bodyLen = measure.length
        measure.setPath(fullPath, false)
        val travel = eased * (bodyLen + visibleExitDist)
        val segment = Path()
        measure.getSegment(travel, travel + bodyLen, segment, true)

        drawPath(
            path = segment,
            color = color.copy(alpha = highlightAlpha),
            style = Stroke(width = strokeWidth * 2.3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawPath(
            path = segment,
            color = color,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        val shiftedHead = Offset(headCenter.x + dx * travel, headCenter.y + dy * travel)
        drawArrowHead(shiftedHead, arrow.direction, headRadius * 1.04f, color)
    }
}

private fun DrawScope.drawArrowHead(
    center: Offset,
    direction: Direction,
    radius: Float,
    color: Color
) {
    val fx = direction.dx.toFloat()
    val fy = direction.dy.toFloat()
    val px = -fy
    val py = fx

    val tip = Offset(center.x + fx * radius * 1.18f, center.y + fy * radius * 1.18f)
    val leftWing = Offset(
        center.x - fx * radius * 0.78f + px * radius * 0.85f,
        center.y - fy * radius * 0.78f + py * radius * 0.85f
    )
    val notch = Offset(center.x - fx * radius * 0.46f, center.y - fy * radius * 0.46f)
    val rightWing = Offset(
        center.x - fx * radius * 0.78f - px * radius * 0.85f,
        center.y - fy * radius * 0.78f - py * radius * 0.85f
    )

    val path = Path().apply {
        moveTo(tip.x, tip.y)
        lineTo(leftWing.x, leftWing.y)
        lineTo(notch.x, notch.y)
        lineTo(rightWing.x, rightWing.y)
        close()
    }
    drawPath(path = path, color = color)
}

private fun distPointToSegmentKt(
    px: Float,
    py: Float,
    ax: Float,
    ay: Float,
    bx: Float,
    by: Float
): Float {
    val dx = bx - ax
    val dy = by - ay
    val lenSq = dx * dx + dy * dy
    if (lenSq == 0f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / lenSq).coerceIn(0f, 1f)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

