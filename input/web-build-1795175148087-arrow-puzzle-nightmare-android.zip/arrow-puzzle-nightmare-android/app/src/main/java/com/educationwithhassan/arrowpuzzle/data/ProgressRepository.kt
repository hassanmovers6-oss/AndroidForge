package com.educationwithhassan.arrowpuzzle.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import com.educationwithhassan.arrowpuzzle.model.LevelResultRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "arrow_puzzle_progress")

data class PlayerProgressState(
    val unlockedLevel: Int = 1,
    val completedLevels: Map<Int, LevelResultRecord> = emptyMap(),
    val totalMoves: Int = 0,
    val totalMistakes: Int = 0,
    val totalPlayTimeMs: Long = 0L,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val arrowSpeedMultiplier: Float = 1.0f,
    val selectedDifficulty: Difficulty = Difficulty.NIGHTMARE,
    val hintsRemaining: Int = 0,
    val hintsUnlockedByAd: Boolean = false,
    val dailyCompletedDates: Set<String> = emptySet(),
    val dailyStreak: Int = 0
)

class ProgressRepository(private val context: Context) {
    private object Keys {
        val UNLOCKED_LEVEL = intPreferencesKey("unlocked_level")
        val COMPLETED_JSON = stringPreferencesKey("completed_levels_json")
        val TOTAL_MOVES = intPreferencesKey("total_moves")
        val TOTAL_MISTAKES = intPreferencesKey("total_mistakes")
        val TOTAL_PLAY_TIME_MS = longPreferencesKey("total_play_time_ms")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val ARROW_SPEED_MULTIPLIER = floatPreferencesKey("arrow_speed_multiplier")
        val SELECTED_DIFFICULTY = stringPreferencesKey("selected_difficulty")
        val HINTS_REMAINING = intPreferencesKey("hints_remaining")
        val HINTS_UNLOCKED_BY_AD = booleanPreferencesKey("hints_unlocked_by_ad")
        val DAILY_DATES_CSV = stringPreferencesKey("daily_dates_csv")
        val DAILY_STREAK = intPreferencesKey("daily_streak")
    }

    val progressFlow: Flow<PlayerProgressState> = context.dataStore.data.map { prefs ->
        val completed = parseCompletedJson(prefs[Keys.COMPLETED_JSON] ?: "{}")
        val diffName = prefs[Keys.SELECTED_DIFFICULTY] ?: Difficulty.NIGHTMARE.name
        val difficulty = migrateDifficulty(diffName)
        val dailyDates = (prefs[Keys.DAILY_DATES_CSV] ?: "")
            .split(",")
            .filter { it.isNotBlank() }
            .toSet()

        PlayerProgressState(
            unlockedLevel = (prefs[Keys.UNLOCKED_LEVEL] ?: 1).coerceIn(1, 500),
            completedLevels = completed,
            totalMoves = prefs[Keys.TOTAL_MOVES] ?: 0,
            totalMistakes = prefs[Keys.TOTAL_MISTAKES] ?: 0,
            totalPlayTimeMs = prefs[Keys.TOTAL_PLAY_TIME_MS] ?: 0L,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION_ENABLED] ?: true,
            arrowSpeedMultiplier = (prefs[Keys.ARROW_SPEED_MULTIPLIER] ?: 1.0f).coerceIn(0.7f, 1.4f),
            selectedDifficulty = difficulty,
            hintsRemaining = prefs[Keys.HINTS_REMAINING] ?: 0,
            hintsUnlockedByAd = prefs[Keys.HINTS_UNLOCKED_BY_AD] ?: false,
            dailyCompletedDates = dailyDates,
            dailyStreak = prefs[Keys.DAILY_STREAK] ?: 0
        )
    }

    private fun migrateDifficulty(raw: String): Difficulty {
        return when (raw) {
            "EASY", "EASY_PRACTICE" -> Difficulty.VERY_HARD
            "MEDIUM" -> Difficulty.EXTREME
            "HARD" -> Difficulty.INSANE
            "EXPERT" -> Difficulty.NIGHTMARE
            else -> runCatching { Difficulty.valueOf(raw) }.getOrDefault(Difficulty.NIGHTMARE)
        }
    }

    suspend fun recordLevelComplete(
        levelId: Int,
        stars: Int,
        moves: Int,
        mistakes: Int,
        elapsedMs: Long,
        isDaily: Boolean,
        dailyDateKey: String?
    ) {
        context.dataStore.edit { prefs ->
            val currentCompleted = parseCompletedJson(prefs[Keys.COMPLETED_JSON] ?: "{}").toMutableMap()
            var unlocked = (prefs[Keys.UNLOCKED_LEVEL] ?: 1).coerceIn(1, 500)

            if (levelId > 0) {
                val existing = currentCompleted[levelId]
                currentCompleted[levelId] = if (existing != null) {
                    LevelResultRecord(
                        stars = maxOf(existing.stars, stars),
                        bestMoves = minOf(existing.bestMoves, moves),
                        bestTimeMs = minOf(existing.bestTimeMs, elapsedMs),
                        fewestMistakes = minOf(existing.fewestMistakes, mistakes)
                    )
                } else {
                    LevelResultRecord(stars, moves, elapsedMs, mistakes)
                }
                if (levelId >= unlocked && levelId < 500) {
                    unlocked = levelId + 1
                }
            }

            prefs[Keys.UNLOCKED_LEVEL] = unlocked
            prefs[Keys.COMPLETED_JSON] = encodeCompletedJson(currentCompleted)
            prefs[Keys.TOTAL_PLAY_TIME_MS] = (prefs[Keys.TOTAL_PLAY_TIME_MS] ?: 0L) + elapsedMs

            if (isDaily && dailyDateKey != null) {
                val dates = (prefs[Keys.DAILY_DATES_CSV] ?: "")
                    .split(",")
                    .filter { it.isNotBlank() }
                    .toMutableSet()
                if (dates.add(dailyDateKey)) {
                    prefs[Keys.DAILY_DATES_CSV] = dates.joinToString(",")
                    prefs[Keys.DAILY_STREAK] = (prefs[Keys.DAILY_STREAK] ?: 0) + 1
                    prefs[Keys.HINTS_REMAINING] = (prefs[Keys.HINTS_REMAINING] ?: 3) + 1
                }
            }
        }
    }

    suspend fun recordMovesAndMistakes(movesDelta: Int, mistakesDelta: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.TOTAL_MOVES] = (prefs[Keys.TOTAL_MOVES] ?: 0) + movesDelta
            prefs[Keys.TOTAL_MISTAKES] = (prefs[Keys.TOTAL_MISTAKES] ?: 0) + mistakesDelta
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VIBRATION_ENABLED] = enabled }
    }

    suspend fun setArrowSpeedMultiplier(mult: Float) {
        context.dataStore.edit { it[Keys.ARROW_SPEED_MULTIPLIER] = mult.coerceIn(0.7f, 1.4f) }
    }

    suspend fun setSelectedDifficulty(difficulty: Difficulty) {
        context.dataStore.edit { it[Keys.SELECTED_DIFFICULTY] = difficulty.name }
    }

    suspend fun consumeHint(): Boolean {
        var success = false
        context.dataStore.edit { prefs ->
            val unlocked = prefs[Keys.HINTS_UNLOCKED_BY_AD] ?: false
            val current = prefs[Keys.HINTS_REMAINING] ?: 0
            if (unlocked && current > 0) {
                val next = current - 1
                prefs[Keys.HINTS_REMAINING] = next
                prefs[Keys.HINTS_UNLOCKED_BY_AD] = next > 0
                success = true
            }
        }
        return success
    }

    suspend fun addHints(amount: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.HINTS_REMAINING] = (prefs[Keys.HINTS_REMAINING] ?: 0) + amount
        }
    }

    suspend fun unlockHintsFromAd(amount: Int) {
        context.dataStore.edit { prefs ->
            val next = (prefs[Keys.HINTS_REMAINING] ?: 0) + amount
            prefs[Keys.HINTS_REMAINING] = next
            prefs[Keys.HINTS_UNLOCKED_BY_AD] = next > 0
        }
    }

    suspend fun resetAll() {
        context.dataStore.edit { it.clear() }
    }

    private fun parseCompletedJson(json: String): Map<Int, LevelResultRecord> {
        val result = mutableMapOf<Int, LevelResultRecord>()
        runCatching {
            val root = JSONObject(json)
            val keys = root.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val obj = root.getJSONObject(key)
                result[key.toInt()] = LevelResultRecord(
                    stars = obj.getInt("stars"),
                    bestMoves = obj.getInt("bestMoves"),
                    bestTimeMs = obj.getLong("bestTimeMs"),
                    fewestMistakes = obj.getInt("fewestMistakes")
                )
            }
        }
        return result
    }

    private fun encodeCompletedJson(map: Map<Int, LevelResultRecord>): String {
        val root = JSONObject()
        for ((id, rec) in map) {
            val obj = JSONObject().apply {
                put("stars", rec.stars)
                put("bestMoves", rec.bestMoves)
                put("bestTimeMs", rec.bestTimeMs)
                put("fewestMistakes", rec.fewestMistakes)
            }
            root.put(id.toString(), obj)
        }
        return root.toString()
    }
}
