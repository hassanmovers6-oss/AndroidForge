package com.educationwithhassan.arrowpuzzle.model

enum class Direction(val dx: Int, val dy: Int) {
    UP(0, -1),
    RIGHT(1, 0),
    DOWN(0, 1),
    LEFT(-1, 0)
}

enum class Difficulty(val displayName: String) {
    EASY_PRACTICE("Easy Practice"),
    VERY_HARD("Very Hard"),
    EXTREME("Extreme"),
    INSANE("Insane"),
    NIGHTMARE("Nightmare"),
    BRUTAL_NIGHTMARE("Brutal Nightmare"),
    MASTER_NIGHTMARE("Master Nightmare"),
    ULTIMATE_NIGHTMARE("Ultimate Nightmare")
}

data class GridPoint(val x: Int, val y: Int)

data class ArrowEntity(
    val id: String,
    val cells: List<GridPoint>,
    val direction: Direction
)

data class PuzzleMetrics(
    val arrowCount: Int,
    val blockedArrowCount: Int,
    val dependencyEdgeCount: Int,
    val minRequiredMoves: Int,
    val initialFreeCount: Int,
    val maxDependencyDepth: Int,
    val boardDensity: Double,
    val totalBends: Int,
    val pathComplexity: Double,
    val difficultyScore: Int
)

data class PuzzleLevel(
    val id: Int,
    val chapterId: Int,
    val levelInChapter: Int,
    val title: String,
    val difficulty: Difficulty,
    val width: Int,
    val height: Int,
    val arrows: List<ArrowEntity>,
    val obstacles: List<GridPoint>,
    val seed: Long,
    val isDaily: Boolean = false,
    val isRandom: Boolean = false,
    val tutorialText: String? = null,
    val metrics: PuzzleMetrics
)

data class ChapterInfo(
    val id: Int,
    val name: String,
    val subtitle: String,
    val startLevel: Int,
    val endLevel: Int,
    val primaryDifficulty: Difficulty
)

data class LevelResultRecord(
    val stars: Int,
    val bestMoves: Int,
    val bestTimeMs: Long,
    val fewestMistakes: Int
)

data class HintResult(
    val arrowId: String,
    val direction: Direction,
    val unlocksCount: Int,
    val explanation: String
)

enum class AppScreen {
    MENU,
    PLAY,
    LEVEL_SELECT,
    DAILY_CHALLENGE,
    DIFFICULTY_SELECT,
    STATISTICS,
    SETTINGS,
    PRIVACY,
    ABOUT
}
