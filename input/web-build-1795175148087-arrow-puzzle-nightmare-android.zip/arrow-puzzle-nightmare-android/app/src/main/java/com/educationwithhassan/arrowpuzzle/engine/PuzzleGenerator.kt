package com.educationwithhassan.arrowpuzzle.engine

import com.educationwithhassan.arrowpuzzle.model.ArrowEntity
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import com.educationwithhassan.arrowpuzzle.model.Direction
import com.educationwithhassan.arrowpuzzle.model.GridPoint
import com.educationwithhassan.arrowpuzzle.model.HintResult
import com.educationwithhassan.arrowpuzzle.model.PuzzleLevel
import com.educationwithhassan.arrowpuzzle.model.PuzzleMetrics
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class EscapeCheckResult(
    val canEscape: Boolean,
    val blockerType: String? = null,
    val blockerArrowId: String? = null,
    val blockerPoint: GridPoint? = null
)

data class ValidationReport(
    val valid: Boolean,
    val metrics: PuzzleMetrics
)

private class Mulberry32(seed: Long) {
    private var t: Int = seed.toInt()
    fun nextDouble(): Double {
        t += 0x6d2b79f5
        var r = (t xor (t ushr 15)) * (1 or t)
        r = r xor (r + ((r xor (r ushr 7)) * (61 or r)))
        val u = (r xor (r ushr 14)).toLong() and 0xFFFFFFFFL
        return u.toDouble() / 4294967296.0
    }

    fun nextInt(bound: Int): Int = (nextDouble() * bound).toInt().coerceIn(0, max(0, bound - 1))
}

private data class StageSpec(
    val minSize: Int,
    val maxSize: Int,
    val minArrows: Int,
    val maxArrows: Int,
    val gates: Int,
    val minObstacles: Int,
    val maxObstacles: Int,
    val maxLen: Int,
    val minWaveDepth: Int
)

private data class BoardResult(
    val width: Int,
    val height: Int,
    val arrows: List<ArrowEntity>,
    val obstacles: List<GridPoint>,
    val validation: ValidationReport
)

private data class NeighborPick(
    val x: Int,
    val y: Int,
    val dx: Int,
    val dy: Int,
    val weight: Double
)

object PuzzleGenerator {
    private val DX = intArrayOf(0, 1, 0, -1) // UP, RIGHT, DOWN, LEFT
    private val DY = intArrayOf(-1, 0, 1, 0)
    private val ALL_DIRS = arrayOf(Direction.UP, Direction.RIGHT, Direction.DOWN, Direction.LEFT)

    private val campaignCache = mutableMapOf<Int, PuzzleLevel>()
    private var cachedPractice1: PuzzleLevel? = null

    private val specs = mapOf(
        Difficulty.EASY_PRACTICE to StageSpec(8, 8, 14, 16, 3, 0, 0, 3, 2),
        Difficulty.VERY_HARD to StageSpec(16, 32, 68, 340, 3, 2, 8, 4, 10),
        Difficulty.EXTREME to StageSpec(33, 38, 355, 495, 4, 8, 12, 4, 22),
        Difficulty.INSANE to StageSpec(39, 45, 504, 695, 4, 10, 14, 4, 26),
        Difficulty.NIGHTMARE to StageSpec(46, 54, 706, 993, 5, 12, 16, 4, 34),
        Difficulty.BRUTAL_NIGHTMARE to StageSpec(55, 67, 1004, 1490, 6, 16, 20, 4, 42),
        Difficulty.MASTER_NIGHTMARE to StageSpec(68, 73, 1502, 1745, 6, 20, 24, 4, 50),
        Difficulty.ULTIMATE_NIGHTMARE to StageSpec(73, 78, 1747, 1995, 6, 24, 30, 4, 55)
    )

    private fun dirIndex(dir: Direction): Int = when (dir) {
        Direction.UP -> 0
        Direction.RIGHT -> 1
        Direction.DOWN -> 2
        Direction.LEFT -> 3
    }

    fun getDirectionFromStep(from: GridPoint, to: GridPoint): Direction {
        val dx = to.x - from.x
        val dy = to.y - from.y
        return when {
            dx == 1 && dy == 0 -> Direction.RIGHT
            dx == -1 && dy == 0 -> Direction.LEFT
            dx == 0 && dy == 1 -> Direction.DOWN
            else -> Direction.UP
        }
    }

    fun getForwardRay(head: GridPoint, direction: Direction, width: Int, height: Int): List<GridPoint> {
        val ray = mutableListOf<GridPoint>()
        var cx = head.x + direction.dx
        var cy = head.y + direction.dy
        while (cx in 0 until width && cy in 0 until height) {
            ray.add(GridPoint(cx, cy))
            cx += direction.dx
            cy += direction.dy
        }
        return ray
    }

    fun checkArrowEscape(
        arrow: ArrowEntity,
        remainingArrows: List<ArrowEntity>,
        obstacles: List<GridPoint>,
        width: Int,
        height: Int
    ): EscapeCheckResult {
        val occ = IntArray(width * height) { -1 }
        for (o in obstacles) {
            if (o.x in 0 until width && o.y in 0 until height) {
                occ[o.y * width + o.x] = -2
            }
        }
        for (i in remainingArrows.indices) {
            for (c in remainingArrows[i].cells) {
                occ[c.y * width + c.x] = i
            }
        }

        val head = arrow.cells.last()
        val dx = arrow.direction.dx
        val dy = arrow.direction.dy
        var cx = head.x + dx
        var cy = head.y + dy
        while (cx in 0 until width && cy in 0 until height) {
            val own = occ[cy * width + cx]
            if (own == -2) {
                return EscapeCheckResult(false, "OBSTACLE", null, GridPoint(cx, cy))
            }
            if (own >= 0) {
                return EscapeCheckResult(false, "ARROW", remainingArrows[own].id, GridPoint(cx, cy))
            }
            cx += dx
            cy += dy
        }
        return EscapeCheckResult(true)
    }

    private fun countTotalBends(arrows: List<ArrowEntity>): Int {
        var bends = 0
        for (a in arrows) {
            if (a.cells.size < 3) continue
            var prev = getDirectionFromStep(a.cells[0], a.cells[1])
            for (i in 2 until a.cells.size) {
                val next = getDirectionFromStep(a.cells[i - 1], a.cells[i])
                if (next != prev) bends++
                prev = next
            }
        }
        return bends
    }

    fun computeDifficultyScore(
        arrowCount: Int,
        blockedArrowCount: Int,
        dependencyEdgeCount: Int,
        maxDependencyDepth: Int,
        boardDensity: Double,
        pathComplexity: Double,
        initialFreeCount: Int
    ): Int {
        return (
            arrowCount * 100 +
                blockedArrowCount * 50 +
                (dependencyEdgeCount * 0.1).roundToInt() +
                min(80, maxDependencyDepth) * 6 +
                (boardDensity * 100.0).roundToInt() * 3 +
                pathComplexity.roundToInt() +
                max(0, 10 - initialFreeCount) * 20
            )
    }

    /**
     * High-speed O(V + E) topological DAG validator using flat IntArrays.
     * Validates 2,000+ arrows on 70x70+ grids in milliseconds.
     */
    fun validatePuzzle(
        arrows: List<ArrowEntity>,
        obstacles: List<GridPoint>,
        width: Int,
        height: Int
    ): ValidationReport {
        val emptyMetrics = PuzzleMetrics(0, 0, 0, 0, 0, 0, 0.0, 0, 0.0, 0)
        if (arrows.isEmpty()) return ValidationReport(false, emptyMetrics)

        val nCells = width * height
        val occ = IntArray(nCells) { -1 }

        for (obs in obstacles) {
            if (obs.x !in 0 until width || obs.y !in 0 until height) {
                return ValidationReport(false, emptyMetrics)
            }
            occ[obs.y * width + obs.x] = -2
        }

        var totalArrowCells = 0
        for (i in arrows.indices) {
            val arrow = arrows[i]
            if (arrow.cells.size < 2) return ValidationReport(false, emptyMetrics)
            for (j in arrow.cells.indices) {
                val c = arrow.cells[j]
                if (c.x !in 0 until width || c.y !in 0 until height) {
                    return ValidationReport(false, emptyMetrics)
                }
                val idx = c.y * width + c.x
                if (occ[idx] != -1) return ValidationReport(false, emptyMetrics)
                if (j > 0) {
                    val prev = arrow.cells[j - 1]
                    if (abs(c.x - prev.x) + abs(c.y - prev.y) != 1) {
                        return ValidationReport(false, emptyMetrics)
                    }
                }
                occ[idx] = i
            }
            totalArrowCells += arrow.cells.size

            val expectedDir = getDirectionFromStep(
                arrow.cells[arrow.cells.size - 2],
                arrow.cells.last()
            )
            if (expectedDir != arrow.direction) return ValidationReport(false, emptyMetrics)
        }

        val count = arrows.size
        val unlocks = Array(count) { mutableListOf<Int>() }
        val inDeg = IntArray(count)
        val seenStamp = IntArray(count)
        var stamp = 1
        var dependencyEdgeCount = 0
        var blockedArrowCount = 0
        var initialFreeCount = 0

        for (i in 0 until count) {
            val arrow = arrows[i]
            val head = arrow.cells.last()
            val dIdx = dirIndex(arrow.direction)
            val dx = DX[dIdx]
            val dy = DY[dIdx]
            var cx = head.x + dx
            var cy = head.y + dy
            var deps = 0
            stamp++
            while (cx in 0 until width && cy in 0 until height) {
                val owner = occ[cy * width + cx]
                if (owner == -2 || owner == i) return ValidationReport(false, emptyMetrics)
                if (owner >= 0 && seenStamp[owner] != stamp) {
                    seenStamp[owner] = stamp
                    unlocks[owner].add(i)
                    inDeg[i]++
                    deps++
                    dependencyEdgeCount++
                }
                cx += dx
                cy += dy
            }
            if (deps > 0) blockedArrowCount++ else initialFreeCount++
        }

        val depth = IntArray(count)
        val queue = IntArray(count)
        var qTail = 0
        for (i in 0 until count) {
            if (inDeg[i] == 0) {
                depth[i] = 1
                queue[qTail++] = i
            }
        }

        var qHead = 0
        var maxDependencyDepth = 0
        while (qHead < qTail) {
            val u = queue[qHead++]
            if (depth[u] > maxDependencyDepth) maxDependencyDepth = depth[u]
            val children = unlocks[u]
            for (k in children.indices) {
                val v = children[k]
                if (depth[u] + 1 > depth[v]) depth[v] = depth[u] + 1
                inDeg[v]--
                if (inDeg[v] == 0) {
                    queue[qTail++] = v
                }
            }
        }

        if (qTail != count) return ValidationReport(false, emptyMetrics)

        val totalBends = countTotalBends(arrows)
        val boardDensity = (totalArrowCells + obstacles.size).toDouble() / nCells.toDouble()
        val pathComplexity = totalBends.toDouble() + totalArrowCells.toDouble() / max(1, count).toDouble()
        val score = computeDifficultyScore(
            arrowCount = count,
            blockedArrowCount = blockedArrowCount,
            dependencyEdgeCount = dependencyEdgeCount,
            maxDependencyDepth = maxDependencyDepth,
            boardDensity = boardDensity,
            pathComplexity = pathComplexity,
            initialFreeCount = initialFreeCount
        )

        return ValidationReport(
            true,
            PuzzleMetrics(
                arrowCount = count,
                blockedArrowCount = blockedArrowCount,
                dependencyEdgeCount = dependencyEdgeCount,
                minRequiredMoves = count,
                initialFreeCount = initialFreeCount,
                maxDependencyDepth = maxDependencyDepth,
                boardDensity = boardDensity,
                totalBends = totalBends,
                pathComplexity = pathComplexity,
                difficultyScore = score
            )
        )
    }

    /**
     * Practice Level 1: 8x8 beginner-friendly board with 14–16 clean arrows,
     * multiple open perimeter exits, and crystal-clear blocking demonstrations.
     */
    fun buildPracticeLevel1(): PuzzleLevel {
        cachedPractice1?.let { return it }

        val board = generateMassiveWavefrontBoard(4021L, 8, 15, 3, 0, 3)
        if (board != null && board.arrows.size in 12..20) {
            val level = PuzzleLevel(
                id = 1,
                chapterId = 1,
                levelInChapter = 1,
                title = "Level 1",
                difficulty = Difficulty.EASY_PRACTICE,
                width = board.width,
                height = board.height,
                arrows = board.arrows,
                obstacles = board.obstacles,
                seed = 4021L,
                tutorialText = "Practice Level: Tap any arrow with an open sightline to watch it glide off the board. Clear outer arrows first to free blocked interior paths.",
                metrics = board.validation.metrics
            )
            cachedPractice1 = level
            return level
        }

        val fallback = listOf(
            ArrowEntity("a_1", listOf(GridPoint(6, 0), GridPoint(7, 0)), Direction.RIGHT),
            ArrowEntity("a_2", listOf(GridPoint(0, 6), GridPoint(0, 7)), Direction.DOWN),
            ArrowEntity("a_3", listOf(GridPoint(7, 6), GridPoint(7, 7)), Direction.DOWN),
            ArrowEntity("a_4", listOf(GridPoint(4, 0), GridPoint(5, 0)), Direction.RIGHT),
            ArrowEntity("a_5", listOf(GridPoint(2, 0), GridPoint(3, 0)), Direction.RIGHT),
            ArrowEntity("a_6", listOf(GridPoint(0, 4), GridPoint(0, 5)), Direction.DOWN),
            ArrowEntity("a_7", listOf(GridPoint(0, 2), GridPoint(0, 3)), Direction.DOWN),
            ArrowEntity("a_8", listOf(GridPoint(4, 1), GridPoint(5, 1)), Direction.RIGHT),
            ArrowEntity("a_9", listOf(GridPoint(2, 1), GridPoint(3, 1)), Direction.RIGHT),
            ArrowEntity("a_10", listOf(GridPoint(5, 2), GridPoint(5, 3)), Direction.DOWN),
            ArrowEntity("a_11", listOf(GridPoint(3, 2), GridPoint(3, 3)), Direction.DOWN),
            ArrowEntity("a_12", listOf(GridPoint(4, 4), GridPoint(5, 4)), Direction.RIGHT),
            ArrowEntity("a_13", listOf(GridPoint(2, 4), GridPoint(3, 4)), Direction.RIGHT),
            ArrowEntity("a_14", listOf(GridPoint(4, 6), GridPoint(5, 6)), Direction.RIGHT)
        )
        val valReport = validatePuzzle(fallback, emptyList(), 8, 8)
        val level = PuzzleLevel(
            id = 1,
            chapterId = 1,
            levelInChapter = 1,
            title = "Level 1",
            difficulty = Difficulty.EASY_PRACTICE,
            width = 8,
            height = 8,
            arrows = fallback,
            obstacles = emptyList(),
            seed = 1L,
            tutorialText = "Practice Level: Tap any arrow with an open sightline to watch it glide off the board. Clear outer arrows first to free blocked interior paths.",
            metrics = valReport.metrics
        )
        cachedPractice1 = level
        return level
    }

    /**
     * Massive Pinwheel + Concentric Inward Shell + Winding Snake DAG Generator.
     * Supports 1,500–2,000 arrows on 68x68–70x70 grids in ~10–25ms with guaranteed solvability.
     */
    private fun generateMassiveWavefrontBoard(
        seed: Long,
        size: Int,
        targetArrows: Int,
        gates: Int,
        obsCount: Int,
        maxLen: Int
    ): BoardResult? {
        val rng = Mulberry32(seed)
        val w = size
        val h = size
        val nCells = w * h
        val occ = IntArray(nCells) { -1 }
        val forb = ByteArray(nCells)
        val arrows = mutableListOf<ArrowEntity>()
        val depthArr = mutableListOf<Int>()
        val selfStamp = IntArray(nCells)
        var curStamp = 1

        fun placeArrow(hx: Int, hy: Int, dir: Int, maxD: Int, desiredLen: Int): Boolean {
            val dx = DX[dir]
            val dy = DY[dir]
            val nx = hx - dx
            val ny = hy - dy
            if (nx !in 0 until w || ny !in 0 until h) return false
            val hIdx = hy * w + hx
            val nIdx = ny * w + nx
            if (occ[hIdx] != -1 || forb[hIdx] != 0.toByte() || occ[nIdx] != -1 || forb[nIdx] != 0.toByte()) {
                return false
            }

            curStamp++
            var rcx = hx + dx
            var rcy = hy + dy
            while (rcx in 0 until w && rcy in 0 until h) {
                selfStamp[rcy * w + rcx] = curStamp
                rcx += dx
                rcy += dy
            }
            selfStamp[hIdx] = curStamp
            selfStamp[nIdx] = curStamp

            val rev = mutableListOf(GridPoint(hx, hy), GridPoint(nx, ny))
            var curX = nx
            var curY = ny
            var prevDx = -dx
            var prevDy = -dy

            while (rev.size < desiredLen) {
                var pickNb: NeighborPick? = null
                for (d in 0..3) {
                    val mx = curX + DX[d]
                    val my = curY + DY[d]
                    if (mx !in 0 until w || my !in 0 until h) continue
                    val mi = my * w + mx
                    if (occ[mi] != -1 || forb[mi] != 0.toByte() || selfStamp[mi] == curStamp) continue
                    val isTurn = DX[d] != prevDx || DY[d] != prevDy
                    val distBorder = min(min(mx, w - 1 - mx), min(my, h - 1 - my))
                    var occNb = 0
                    for (ad in 0..3) {
                        val ax = mx + DX[ad]
                        val ay = my + DY[ad]
                        if (ax !in 0 until w || ay !in 0 until h || occ[ay * w + ax] != -1) occNb++
                    }
                    val weight = (if (isTurn) 1.85 else 1.0) + occNb * 1.1 + distBorder * 0.15 + rng.nextDouble() * 0.85
                    if (pickNb == null || weight > pickNb.weight) {
                        pickNb = NeighborPick(mx, my, DX[d], DY[d], weight)
                    }
                }
                if (pickNb == null) break
                rev.add(GridPoint(pickNb.x, pickNb.y))
                selfStamp[pickNb.y * w + pickNb.x] = curStamp
                prevDx = pickNb.dx
                prevDy = pickNb.dy
                curX = pickNb.x
                curY = pickNb.y
            }

            val cells = rev.reversed()
            val aIdx = arrows.size
            arrows.add(ArrowEntity("a_${aIdx + 1}", cells, ALL_DIRS[dir]))
            depthArr.add(maxD + 1)
            for (c in cells) occ[c.y * w + c.x] = aIdx

            rcx = hx + dx
            rcy = hy + dy
            while (rcx in 0 until w && rcy in 0 until h) {
                val ri = rcy * w + rcx
                if (occ[ri] == -1) forb[ri] = 1
                rcx += dx
                rcy += dy
            }
            return true
        }

        // 1. Place perimeter pinwheel gates
        val gateStarts = arrayOf(
            intArrayOf(w - 1, 0, 1),
            intArrayOf(0, h - 1, 3),
            intArrayOf(w - 1, h - 1, 2),
            intArrayOf(0, 0, 0),
            intArrayOf(w - 1, 1, 1),
            intArrayOf(0, h - 2, 3),
            intArrayOf(w - 2, h - 1, 2),
            intArrayOf(1, 0, 0)
        )
        for (g in 0 until min(gates, gateStarts.size)) {
            val gs = gateStarts[g]
            placeArrow(gs[0], gs[1], gs[2], 0, 2)
        }
        if (arrows.isEmpty()) return null

        // 2. Sweep inward concentric shells packing chains and cross-blockers
        val maxRing = min(w, h) / 2
        var passGap = 0
        while (passGap <= 4 && arrows.size < targetArrows) {
            var r = 0
            while (r <= maxRing && arrows.size < targetArrows) {
                val ringCellsList = mutableListOf<Int>()
                for (x in (w - 1 - r) downTo r) ringCellsList.add(r * w + x)
                for (y in (r + 1) until (h - r)) ringCellsList.add(y * w + (w - 1 - r))
                for (x in r until (w - 1 - r)) ringCellsList.add((h - 1 - r) * w + x)
                for (y in (r + 1) until (h - 1 - r)) ringCellsList.add(y * w + r)
                val ringCells = ringCellsList.toIntArray()

                var sub = 0
                while (sub < 8 && arrows.size < targetArrows) {
                    var placedThisSub = 0
                    if (r >= 1) {
                        for (i in ringCells.size - 1 downTo 1) {
                            val j = floor(rng.nextDouble() * (i + 1)).toInt()
                            val tmp = ringCells[i]
                            ringCells[i] = ringCells[j]
                            ringCells[j] = tmp
                        }
                    }

                    for (ci in ringCells) {
                        if (arrows.size >= targetArrows) break
                        if (occ[ci] != -1 || forb[ci] != 0.toByte()) continue
                        val hx = ci % w
                        val hy = ci / w

                        var bestDir = -1
                        var bestMaxD = -1
                        var bestScore = -1e9
                        val d0 = floor(rng.nextDouble() * 4).toInt()

                        for (di in 0..3) {
                            val d = (d0 + di) and 3
                            val dx = DX[d]
                            val dy = DY[d]
                            val nx = hx - dx
                            val ny = hy - dy
                            if (nx !in 0 until w || ny !in 0 until h) continue
                            val nIdx = ny * w + nx
                            if (occ[nIdx] != -1 || forb[nIdx] != 0.toByte()) continue

                            var cx = hx + dx
                            var cy = hy + dy
                            var blockers = 0
                            var maxD = 0
                            var emptyGap = 0
                            var ok = true
                            while (cx in 0 until w && cy in 0 until h) {
                                val idx = cy * w + cx
                                val own = occ[idx]
                                if (own >= 0) {
                                    blockers++
                                    if (depthArr[own] > maxD) maxD = depthArr[own]
                                } else if (forb[idx] == 0.toByte()) {
                                    emptyGap++
                                    if (emptyGap > passGap) {
                                        ok = false
                                        break
                                    }
                                }
                                cx += dx
                                cy += dy
                            }
                            if (!ok || blockers == 0) continue
                            val sc = maxD * 4.0 + blockers * 0.45 - emptyGap * 20.0 + rng.nextDouble() * 3.5
                            if (sc > bestScore) {
                                bestScore = sc
                                bestDir = d
                                bestMaxD = maxD
                            }
                        }

                        if (bestDir != -1) {
                            val remCells = max(0, nCells - (arrows.size * 2.2).roundToInt())
                            val remNeeded = max(1, targetArrows - arrows.size)
                            val avgBudget = remCells.toDouble() / remNeeded.toDouble()
                            val lenCap = when {
                                avgBudget < 2.6 -> 2
                                avgBudget < 3.4 -> 3
                                else -> maxLen
                            }
                            val desiredLen = 2 + floor(rng.nextDouble() * max(1, lenCap - 1)).toInt()
                            if (placeArrow(hx, hy, bestDir, bestMaxD, desiredLen)) {
                                placedThisSub++
                            }
                        }
                    }
                    if (placedThisSub == 0) break
                    sub++
                }
                r++
            }
            passGap++
        }

        // 3. Place immovable obstacles in un-forbidden empty cells
        val obstacles = mutableListOf<GridPoint>()
        if (obsCount > 0) {
            val empties = mutableListOf<Int>()
            for (i in 0 until nCells) {
                if (occ[i] == -1 && forb[i] == 0.toByte()) empties.add(i)
            }
            val empArr = empties.toIntArray()
            for (i in empArr.size - 1 downTo 1) {
                val j = floor(rng.nextDouble() * (i + 1)).toInt()
                val tmp = empArr[i]
                empArr[i] = empArr[j]
                empArr[j] = tmp
            }
            for (idx in empArr) {
                if (obstacles.size >= obsCount) break
                occ[idx] = -2
                obstacles.add(GridPoint(idx % w, idx / w))
            }
        }

        val validation = validatePuzzle(arrows, obstacles, w, h)
        if (!validation.valid) return null
        return BoardResult(w, h, arrows, obstacles, validation)
    }

    fun generatePuzzleBySeed(
        seed: Long,
        difficulty: Difficulty,
        levelId: Int = 0,
        chapterId: Int = 0,
        levelInChapter: Int = 1,
        title: String = "${difficulty.displayName} Challenge",
        progressFactor: Double = 0.65,
        overrideSize: Int? = null,
        isDaily: Boolean = false,
        isRandom: Boolean = false
    ): PuzzleLevel {
        if (levelId == 1 || difficulty == Difficulty.EASY_PRACTICE) {
            return buildPracticeLevel1()
        }

        val spec = specs.getValue(difficulty)
        val pf = progressFactor.coerceIn(0.0, 1.0)
        val size = overrideSize ?: (spec.minSize + (spec.maxSize - spec.minSize) * pf).roundToInt()
        val targetArrows = (spec.minArrows + (spec.maxArrows - spec.minArrows) * pf).roundToInt()
        val obsCount = (spec.minObstacles + (spec.maxObstacles - spec.minObstacles) * pf).roundToInt()

        var best: BoardResult? = null
        var bestScore = -1

        for (attempt in 0 until 6) {
            val attemptSeed = (seed + attempt * 7919L) and 0xFFFFFFFFL
            val candidate = generateMassiveWavefrontBoard(
                seed = attemptSeed,
                size = size,
                targetArrows = targetArrows,
                gates = spec.gates,
                obsCount = obsCount,
                maxLen = spec.maxLen
            ) ?: continue

            val m = candidate.validation.metrics
            if (m.difficultyScore > bestScore) {
                bestScore = m.difficultyScore
                best = candidate
            }
            if (m.arrowCount >= (targetArrows * 0.92).toInt() &&
                m.maxDependencyDepth >= spec.minWaveDepth
            ) {
                best = candidate
                break
            }
        }

        val finalBoard = best!!
        return PuzzleLevel(
            id = levelId,
            chapterId = chapterId,
            levelInChapter = levelInChapter,
            title = title,
            difficulty = difficulty,
            width = finalBoard.width,
            height = finalBoard.height,
            arrows = finalBoard.arrows,
            obstacles = finalBoard.obstacles,
            seed = seed,
            isDaily = isDaily,
            isRandom = isRandom,
            metrics = finalBoard.validation.metrics
        )
    }

    fun getCampaignLevel(levelId: Int): PuzzleLevel {
        val clamped = levelId.coerceIn(1, ChapterCatalog.TOTAL_CAMPAIGN_LEVELS)
        if (clamped == 1) return buildPracticeLevel1()

        return campaignCache.getOrPut(clamped) {
            val chapter = ChapterCatalog.getChapterForLevel(clamped)
            val difficulty = ChapterCatalog.getDifficultyForLevel(clamped)
            val levelInChapter = ((clamped - 1) % ChapterCatalog.LEVELS_PER_CHAPTER) + 1
            val cal = CalibratedSeeds.levels[clamped]

            if (cal != null) {
                val board = generateMassiveWavefrontBoard(
                    seed = cal.seed,
                    size = cal.size,
                    targetArrows = cal.targetArrows,
                    gates = cal.gates,
                    obsCount = cal.obsCount,
                    maxLen = cal.maxLen
                )
                if (board != null) {
                    return@getOrPut PuzzleLevel(
                        id = clamped,
                        chapterId = chapter.id,
                        levelInChapter = levelInChapter,
                        title = "Level $clamped",
                        difficulty = difficulty,
                        width = board.width,
                        height = board.height,
                        arrows = board.arrows,
                        obstacles = board.obstacles,
                        seed = cal.seed,
                        metrics = board.validation.metrics
                    )
                }
            }

            generatePuzzleBySeed(
                seed = ((clamped.toLong() * 2654435761L) xor 0x9E3779B9L) and 0xFFFFFFFFL,
                difficulty = difficulty,
                levelId = clamped,
                chapterId = chapter.id,
                levelInChapter = levelInChapter,
                title = "Level $clamped",
                progressFactor = clamped.toDouble() / ChapterCatalog.TOTAL_CAMPAIGN_LEVELS.toDouble(),
                overrideSize = cal?.size
            )
        }
    }

    /**
     * O(N) fast hint finder using flat IntArray grid & reverse ray unlock count.
     * Runs in <1ms even when 2,000 arrows remain on the board.
     */
    fun findSafeHint(
        remainingArrows: List<ArrowEntity>,
        obstacles: List<GridPoint>,
        width: Int,
        height: Int,
        excludeArrowIds: Set<String> = emptySet()
    ): HintResult? {
        if (remainingArrows.isEmpty()) return null

        val nCells = width * height
        val occ = IntArray(nCells) { -1 }
        for (o in obstacles) {
            if (o.x in 0 until width && o.y in 0 until height) {
                occ[o.y * width + o.x] = -2
            }
        }
        for (i in remainingArrows.indices) {
            for (c in remainingArrows[i].cells) {
                occ[c.y * width + c.x] = i
            }
        }

        val blockerCount = IntArray(remainingArrows.size)
        val singleBlockerTarget = IntArray(remainingArrows.size) { -1 }
        val freeIndices = mutableListOf<Int>()

        for (i in remainingArrows.indices) {
            val a = remainingArrows[i]
            val head = a.cells.last()
            val dIdx = dirIndex(a.direction)
            val dx = DX[dIdx]
            val dy = DY[dIdx]
            var cx = head.x + dx
            var cy = head.y + dy
            var deps = 0
            var soleBlocker = -1
            var hitObs = false
            val seen = HashSet<Int>()

            while (cx in 0 until width && cy in 0 until height) {
                val own = occ[cy * width + cx]
                if (own == -2) {
                    hitObs = true
                    break
                }
                if (own >= 0 && seen.add(own)) {
                    deps++
                    soleBlocker = own
                }
                cx += dx
                cy += dy
            }

            if (!hitObs) {
                blockerCount[i] = deps
                if (deps == 0) {
                    if (a.id !in excludeArrowIds) {
                        freeIndices.add(i)
                    }
                } else if (deps == 1) {
                    singleBlockerTarget[i] = soleBlocker
                }
            }
        }

        if (freeIndices.isEmpty()) return null

        val unlockGain = IntArray(remainingArrows.size)
        for (i in remainingArrows.indices) {
            val sb = singleBlockerTarget[i]
            if (sb >= 0) unlockGain[sb]++
        }

        var bestIdx = freeIndices[0]
        var bestUnlocks = unlockGain[bestIdx]
        for (k in 1 until freeIndices.size) {
            val idx = freeIndices[k]
            if (unlockGain[idx] > bestUnlocks) {
                bestUnlocks = unlockGain[idx]
                bestIdx = idx
            }
        }

        val bestArrow = remainingArrows[bestIdx]
        val edgeName = when (bestArrow.direction) {
            Direction.UP -> "top"
            Direction.RIGHT -> "right"
            Direction.DOWN -> "bottom"
            Direction.LEFT -> "left"
        }
        val msg = if (bestUnlocks > 0) {
            "Safe path to the $edgeName edge — unlocks $bestUnlocks trapped ${if (bestUnlocks == 1) "arrow" else "arrows"}."
        } else {
            "Safe move — clear sightline to the $edgeName edge."
        }
        return HintResult(bestArrow.id, bestArrow.direction, max(0, bestUnlocks), msg)
    }
}
