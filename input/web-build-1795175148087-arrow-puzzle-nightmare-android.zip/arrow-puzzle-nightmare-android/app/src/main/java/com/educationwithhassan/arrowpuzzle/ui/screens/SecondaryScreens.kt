package com.educationwithhassan.arrowpuzzle.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.arrowpuzzle.BuildConfig
import com.educationwithhassan.arrowpuzzle.ads.AdMobManager
import com.educationwithhassan.arrowpuzzle.ads.NativeAdCard
import com.educationwithhassan.arrowpuzzle.data.PlayerProgressState
import com.educationwithhassan.arrowpuzzle.engine.ChapterCatalog
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowColors

@Composable
private fun ScreenTopBar(title: String, subtitle: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = ArrowColors.CardWhite,
            border = BorderStroke(1.dp, ArrowColors.SlateBorder)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        }
        Column {
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = ArrowColors.NavyInk)
            Text(subtitle, fontSize = 12.sp, color = ArrowColors.SlateMuted)
        }
    }
}

@Composable
fun DailyChallengeScreen(
    progress: PlayerProgressState,
    adMobManager: AdMobManager,
    onPlayDaily: () -> Unit,
    onRequestDailyBonusAd: (onGranted: () -> Unit, onUnavailable: () -> Unit) -> Unit,
    onBack: () -> Unit
) {
    val (todayKey, _) = ChapterCatalog.getDailySeed()
    val isDailyDone = todayKey in progress.dailyCompletedDates
    var showBonusDialog by remember { mutableStateOf(false) }
    var bonusStatusMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTopBar("Daily Challenge", "Daily Nightmare Board · $todayKey", onBack)

        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
            border = BorderStroke(1.dp, ArrowColors.SlateBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = ArrowColors.CrimsonHeart)
                        Text(
                            text = if (isDailyDone) "Completed Today" else "Daily Nightmare Ready",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = ArrowColors.NavyInk
                        )
                    }
                    Text(
                        text = "Streak: ${progress.dailyStreak}d",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = ArrowColors.CrimsonHeart
                    )
                }

                Text(
                    text = "Conquer today's deterministic Ultimate Nightmare labyrinth to extend your streak and earn a bonus hint.",
                    fontSize = 13.sp,
                    color = ArrowColors.SlateMuted
                )

                Button(
                    onClick = onPlayDaily,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.NavyInk),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = if (isDailyDone) "Replay Today's Challenge" else "Play Daily Challenge",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Optional Daily Bonus Rewarded Ad Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
            border = BorderStroke(1.dp, ArrowColors.SlateBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = ArrowColors.NavyInk)
                    Text("Optional Daily Bonus", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ArrowColors.NavyInk)
                }
                Text(
                    text = "Need extra hints for today's board? Watch an optional rewarded video for +2 Hints.",
                    fontSize = 12.sp,
                    color = ArrowColors.SlateMuted
                )
                if (bonusStatusMessage != null) {
                    Text(
                        text = bonusStatusMessage!!,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = ArrowColors.NavyInk
                    )
                }
                OutlinedButton(
                    onClick = { showBonusDialog = true },
                    shape = CircleShape,
                    border = BorderStroke(1.dp, ArrowColors.NavyInk),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Claim Daily Bonus (+2 Hints)", color = ArrowColors.NavyInk, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        NativeAdCard(adMobManager = adMobManager)
    }

    if (showBonusDialog) {
        AlertDialog(
            onDismissRequest = { showBonusDialog = false },
            title = { Text("Daily Bonus Reward") },
            text = { Text("Watch a short optional ad to receive +2 Hints for your puzzle inventory?") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.NavyInk),
                    onClick = {
                        showBonusDialog = false
                        onRequestDailyBonusAd(
                            {
                                bonusStatusMessage = "+2 Bonus Hints added to your inventory."
                            },
                            {
                                bonusStatusMessage = "No rewarded video is ready right now. You can play normally anytime."
                            }
                        )
                    }
                ) {
                    Text("Watch Ad", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBonusDialog = false }) {
                    Text("No Thanks")
                }
            }
        )
    }
}

@Composable
fun DifficultySelectScreen(
    selectedDifficulty: Difficulty,
    adMobManager: AdMobManager,
    onSelectAndPlay: (Difficulty) -> Unit,
    onBack: () -> Unit
) {
    val selectableDifficulties = Difficulty.entries.filter { it != Difficulty.EASY_PRACTICE }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTopBar("Select Difficulty", "Only Level 1 is Easy Practice; all random boards are Very Hard+", onBack)
        selectableDifficulties.forEach { diff ->
            val isNightmareTier = diff.ordinal >= Difficulty.NIGHTMARE.ordinal
            Card(
                onClick = { onSelectAndPlay(diff) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
                border = BorderStroke(1.dp, if (diff == selectedDifficulty) ArrowColors.NavyInk else ArrowColors.SlateBorder)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            diff.displayName,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = if (isNightmareTier) ArrowColors.CrimsonHeart else ArrowColors.NavyInk
                        )
                        Text(
                            when (diff) {
                                Difficulty.EASY_PRACTICE -> "8x8 · 14–16 arrows · Level 1 practice tutorial"
                                Difficulty.VERY_HARD -> "16x16–32x32 · 68–340 interlocking arrows"
                                Difficulty.EXTREME -> "33x33–38x38 · 355–495 arrows · Multi-layer traps"
                                Difficulty.INSANE -> "39x39–45x45 · 504–695 arrows · Narrow winding corridors"
                                Difficulty.NIGHTMARE -> "46x46–54x54 · 706–993 arrows · 30+ wave labyrinths"
                                Difficulty.BRUTAL_NIGHTMARE -> "55x55–67x67 · 1,004–1,490 arrows · Marathon chains"
                                Difficulty.MASTER_NIGHTMARE -> "68x68–73x73 · 1,502–1,745 arrows · High-density master"
                                Difficulty.ULTIMATE_NIGHTMARE -> "73x73–78x78 · 1,747–1,990 arrows · Peak complexity"
                            },
                            fontSize = 12.sp,
                            color = ArrowColors.SlateMuted
                        )
                    }
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = ArrowColors.NavyInk)
                }
            }
        }
        NativeAdCard(adMobManager = adMobManager)
    }
}

@Composable
fun StatisticsScreen(
    progress: PlayerProgressState,
    adMobManager: AdMobManager,
    onBack: () -> Unit
) {
    val cleared = progress.completedLevels.size
    val totalStars = progress.completedLevels.values.sumOf { it.stars }
    val accuracy = if (progress.totalMoves > 0) {
        (((progress.totalMoves - progress.totalMistakes).toFloat() / progress.totalMoves) * 100f).toInt().coerceIn(0, 100)
    } else 100

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTopBar("Statistics", "Local lifetime performance", onBack)
        val rows = listOf(
            "Levels Cleared" to "$cleared / ${ChapterCatalog.TOTAL_CAMPAIGN_LEVELS}",
            "Total Stars" to "$totalStars",
            "Total Moves" to "${progress.totalMoves}",
            "Accuracy" to "$accuracy%",
            "Daily Streak" to "${progress.dailyStreak} days",
            "Available Hints" to "${progress.hintsRemaining}"
        )
        rows.forEach { (label, value) ->
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
                border = BorderStroke(1.dp, ArrowColors.SlateBorder)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(label, color = ArrowColors.SlateMuted, fontSize = 14.sp)
                    Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = ArrowColors.NavyInk)
                }
            }
        }
        NativeAdCard(adMobManager = adMobManager)
    }
}

@Composable
fun SettingsScreen(
    progress: PlayerProgressState,
    adMobManager: AdMobManager,
    onToggleSound: () -> Unit,
    onToggleVibration: () -> Unit,
    onChangeArrowSpeed: (Float) -> Unit,
    onResetProgress: () -> Unit,
    onBack: () -> Unit
) {
    val speedPresets = listOf(
        "Brisk (0.75x)" to 0.75f,
        "Standard (1.0x)" to 1.0f,
        "Slow (1.2x)" to 1.2f,
        "Cinematic (1.35x)" to 1.35f
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTopBar("Settings", "Audio, haptics, speed, and local storage", onBack)

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
            border = BorderStroke(1.dp, ArrowColors.SlateBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Sound Effects", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Arrow glide and victory chimes", fontSize = 12.sp, color = ArrowColors.SlateMuted)
                    }
                    Switch(checked = progress.soundEnabled, onCheckedChange = { onToggleSound() })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Vibration Feedback", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Haptic feedback on taps and blocks", fontSize = 12.sp, color = ArrowColors.SlateMuted)
                    }
                    Switch(checked = progress.vibrationEnabled, onCheckedChange = { onToggleVibration() })
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Arrow Exit Animation Speed", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Smooth exit travel timing (0.24s–0.46s by level)", fontSize = 12.sp, color = ArrowColors.SlateMuted)
                        }
                        Text(
                            "${"%.2f".format(progress.arrowSpeedMultiplier)}x",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = ArrowColors.NavyInk
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        speedPresets.forEach { (label, mult) ->
                            val selected = kotlin.math.abs(progress.arrowSpeedMultiplier - mult) < 0.05f
                            OutlinedButton(
                                onClick = { onChangeArrowSpeed(mult) },
                                shape = CircleShape,
                                border = BorderStroke(1.dp, if (selected) ArrowColors.NavyInk else ArrowColors.SlateBorder),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) ArrowColors.NavyInk else ArrowColors.CardWhite,
                                    contentColor = if (selected) Color.White else ArrowColors.NavyInk
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(label.substringBefore(" "), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        NativeAdCard(adMobManager = adMobManager)

        Button(
            onClick = onResetProgress,
            colors = ButtonDefaults.buttonColors(containerColor = ArrowColors.CrimsonHeart),
            shape = CircleShape,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset Local Progress")
        }
    }
}

@Composable
fun PrivacyPolicyScreen(
    isPrivacyOptionsRequired: Boolean,
    adMobManager: AdMobManager,
    onShowPrivacyOptions: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTopBar("Privacy Policy", "Arrow Puzzle – Nightmare Edition", onBack)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
            border = BorderStroke(1.dp, ArrowColors.SlateBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("1. Local Save Data", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Game progression, stars, and preferences are stored locally via Jetpack DataStore. No user account is required.", fontSize = 13.sp, color = ArrowColors.SlateMuted)
                Text("2. Google AdMob & UMP Consent", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("This application uses Google Mobile Ads SDK (App Open, Banner, Interstitial, Native Advanced, and optional Rewarded formats) and Google User Messaging Platform (UMP) for consent compliance.", fontSize = 13.sp, color = ArrowColors.SlateMuted)
                Text("3. Content Rating", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Rated Everyone. Optional rewarded ads never block core gameplay.", fontSize = 13.sp, color = ArrowColors.SlateMuted)

                if (isPrivacyOptionsRequired) {
                    OutlinedButton(onClick = onShowPrivacyOptions, shape = CircleShape) {
                        Text("Manage Ad Privacy Options")
                    }
                }
            }
        }
        NativeAdCard(adMobManager = adMobManager)
    }
}

@Composable
fun AboutUsScreen(
    adMobManager: AdMobManager,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTopBar("About Us", "Application & developer details", onBack)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ArrowColors.CardWhite),
            border = BorderStroke(1.dp, ArrowColors.SlateBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Arrow Puzzle – Nightmare Edition", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                Text("Developer: Rana Hassan", fontSize = 13.sp, color = ArrowColors.NavyInk)
                Text("Package: ${BuildConfig.APPLICATION_ID}", fontSize = 13.sp, color = ArrowColors.SlateMuted)
                Text("Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", fontSize = 13.sp, color = ArrowColors.SlateMuted)
                Text("Content Rating: Everyone", fontSize = 13.sp, color = ArrowColors.SlateMuted)
            }
        }
        NativeAdCard(adMobManager = adMobManager)
    }
}
