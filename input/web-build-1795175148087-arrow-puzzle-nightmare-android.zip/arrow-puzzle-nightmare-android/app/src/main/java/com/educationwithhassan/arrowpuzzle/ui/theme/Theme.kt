package com.educationwithhassan.arrowpuzzle.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object ArrowColors {
    val Background = Color(0xFFF8FAFC)
    val CardWhite = Color(0xFFFFFFFF)
    val NavyInk = Color(0xFF0B132B)
    val SlateBorder = Color(0xFFE2E8F0)
    val SlateMuted = Color(0xFF64748B)
    val CrimsonHeart = Color(0xFFE11D48)
    val CobaltHint = Color(0xFF2563EB)
    val AmberStar = Color(0xFFF59E0B)
    val ObstacleWall = Color(0xFF334155)
}

private val LightPalette = lightColorScheme(
    primary = ArrowColors.NavyInk,
    onPrimary = Color.White,
    secondary = ArrowColors.CrimsonHeart,
    onSecondary = Color.White,
    background = ArrowColors.Background,
    onBackground = ArrowColors.NavyInk,
    surface = ArrowColors.CardWhite,
    onSurface = ArrowColors.NavyInk
)

@Composable
fun ArrowPuzzleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightPalette,
        content = content
    )
}
