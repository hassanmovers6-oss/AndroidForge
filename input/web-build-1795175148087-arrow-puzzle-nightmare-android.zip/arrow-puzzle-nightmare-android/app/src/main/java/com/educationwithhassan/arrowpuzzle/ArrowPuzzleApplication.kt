package com.educationwithhassan.arrowpuzzle

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.educationwithhassan.arrowpuzzle.ads.AdMobManager

class ArrowPuzzleApplication : Application() {
    lateinit var adMobManager: AdMobManager
        private set

    override fun onCreate() {
        super.onCreate()
        adMobManager = AdMobManager(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(adMobManager)
    }

    override fun onTerminate() {
        ProcessLifecycleOwner.get().lifecycle.removeObserver(adMobManager)
        adMobManager.destroy()
        super.onTerminate()
    }
}
