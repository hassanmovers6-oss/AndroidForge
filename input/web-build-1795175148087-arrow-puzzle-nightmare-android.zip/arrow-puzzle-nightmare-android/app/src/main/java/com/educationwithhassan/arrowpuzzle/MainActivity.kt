package com.educationwithhassan.arrowpuzzle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.arrowpuzzle.ads.AdaptiveBannerAd
import com.educationwithhassan.arrowpuzzle.ads.ConsentManager
import com.educationwithhassan.arrowpuzzle.audio.SoundAndHapticManager
import com.educationwithhassan.arrowpuzzle.data.PlayerProgressState
import com.educationwithhassan.arrowpuzzle.data.ProgressRepository
import com.educationwithhassan.arrowpuzzle.engine.ChapterCatalog
import com.educationwithhassan.arrowpuzzle.engine.PuzzleGenerator
import com.educationwithhassan.arrowpuzzle.model.AppScreen
import com.educationwithhassan.arrowpuzzle.model.Difficulty
import com.educationwithhassan.arrowpuzzle.model.PuzzleLevel
import com.educationwithhassan.arrowpuzzle.ui.screens.AboutUsScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.DailyChallengeScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.DifficultySelectScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.GamePlayScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.LevelSelectScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.MainMenuScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.PrivacyPolicyScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.SettingsScreen
import com.educationwithhassan.arrowpuzzle.ui.screens.StatisticsScreen
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowColors
import com.educationwithhassan.arrowpuzzle.ui.theme.ArrowPuzzleTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var repository: ProgressRepository
    private lateinit var soundManager: SoundAndHapticManager
    private lateinit var consentManager: ConsentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as ArrowPuzzleApplication
        val adMobManager = app.adMobManager

        repository = ProgressRepository(applicationContext)
        soundManager = SoundAndHapticManager(applicationContext)
        consentManager = ConsentManager(applicationContext)

        adMobManager.startColdLaunchGate()
        consentManager.gatherConsent(this) { canRequestAds ->
            adMobManager.initializeSdkIfAllowed(canRequestAds)
        }

        setContent {
            val progress by repository.progressFlow.collectAsState(initial = PlayerProgressState())
            val isSdkInitialized by adMobManager.isSdkInitializedFlow.collectAsState()
            val isColdLaunchComplete by adMobManager.isColdLaunchCompleteFlow.collectAsState()
            val scope = rememberCoroutineScope()
            var screen by remember { mutableStateOf(AppScreen.MENU) }
            var activeLevel by remember { mutableStateOf<PuzzleLevel?>(null) }

            LaunchedEffect(progress.soundEnabled, progress.vibrationEnabled) {
                soundManager.soundEnabled = progress.soundEnabled
                soundManager.vibrationEnabled = progress.vibrationEnabled
            }

            // Never interrupt active puzzle gameplay with App Open or banner placements
            LaunchedEffect(screen) {
                adMobManager.isInActiveGameplay = (screen == AppScreen.PLAY)
            }

            fun launchCampaign(levelId: Int) {
                activeLevel = PuzzleGenerator.getCampaignLevel(levelId.coerceIn(1, ChapterCatalog.TOTAL_CAMPAIGN_LEVELS))
                screen = AppScreen.PLAY
            }

            fun launchRandom(difficulty: Difficulty) {
                val safeDifficulty = if (difficulty == Difficulty.EASY_PRACTICE) Difficulty.VERY_HARD else difficulty
                scope.launch { repository.setSelectedDifficulty(safeDifficulty) }
                val seed = System.currentTimeMillis()
                activeLevel = PuzzleGenerator.generatePuzzleBySeed(
                    seed = seed,
                    difficulty = safeDifficulty,
                    title = "${safeDifficulty.displayName} Board",
                    progressFactor = 0.72,
                    isRandom = true
                )
                screen = AppScreen.PLAY
            }

            fun launchDaily() {
                val (dateKey, seed) = ChapterCatalog.getDailySeed()
                activeLevel = PuzzleGenerator.generatePuzzleBySeed(
                    seed = seed,
                    difficulty = Difficulty.ULTIMATE_NIGHTMARE,
                    title = "Daily · $dateKey",
                    progressFactor = 0.85,
                    isDaily = true
                )
                screen = AppScreen.PLAY
            }

            ArrowPuzzleTheme {
                if (!isColdLaunchComplete) {
                    AppStartupLoadingScreen()
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.weight(1f)) {
                            when (screen) {
                                AppScreen.MENU -> MainMenuScreen(
                                    progress = progress,
                                    adMobManager = adMobManager,
                                    onContinue = {
                                        soundManager.playClick()
                                        launchCampaign(progress.unlockedLevel)
                                    },
                                    onPlayDifficulty = {
                                        soundManager.playClick()
                                        launchRandom(it)
                                    },
                                    onStartDaily = {
                                        soundManager.playClick()
                                        screen = AppScreen.DAILY_CHALLENGE
                                    },
                                    onStartRandom = {
                                        soundManager.playClick()
                                        launchRandom(progress.selectedDifficulty)
                                    },
                                    onNavigate = {
                                        soundManager.playClick()
                                        screen = it
                                    }
                                )

                                AppScreen.LEVEL_SELECT -> LevelSelectScreen(
                                    progress = progress,
                                    adMobManager = adMobManager,
                                    onSelectLevel = {
                                        soundManager.playClick()
                                        launchCampaign(it)
                                    },
                                    onBack = {
                                        soundManager.playClick()
                                        screen = AppScreen.MENU
                                    }
                                )

                                AppScreen.DAILY_CHALLENGE -> DailyChallengeScreen(
                                    progress = progress,
                                    adMobManager = adMobManager,
                                    onPlayDaily = {
                                        soundManager.playClick()
                                        launchDaily()
                                    },
                                    onRequestDailyBonusAd = { onGranted, onUnavailable ->
                                        adMobManager.showRewardedAd(
                                            activity = this@MainActivity,
                                            onRewardEarned = {
                                                scope.launch { repository.unlockHintsFromAd(2) }
                                                onGranted()
                                            },
                                            onAdClosed = {},
                                            onUnavailable = onUnavailable
                                        )
                                    },
                                    onBack = {
                                        soundManager.playClick()
                                        screen = AppScreen.MENU
                                    }
                                )

                                AppScreen.PLAY -> {
                                    val level = activeLevel
                                    if (level != null) {
                                        GamePlayScreen(
                                            level = level,
                                            progress = progress,
                                            hasNextLevel = level.isRandom || (level.id in 1 until ChapterCatalog.TOTAL_CAMPAIGN_LEVELS),
                                            soundManager = soundManager,
                                            onConsumeHint = {
                                                if (progress.hintsUnlockedByAd && progress.hintsRemaining > 0) {
                                                    scope.launch { repository.consumeHint() }
                                                    true
                                                } else false
                                            },
                                            onRequestRewardedHint = { onUnavailable ->
                                                adMobManager.showRewardedAd(
                                                    activity = this@MainActivity,
                                                    onRewardEarned = { scope.launch { repository.unlockHintsFromAd(2) } },
                                                    onAdClosed = {},
                                                    onUnavailable = onUnavailable
                                                )
                                            },
                                            onRequestRewardedLife = { onGranted, onUnavailable ->
                                                adMobManager.showRewardedAd(
                                                    activity = this@MainActivity,
                                                    onRewardEarned = onGranted,
                                                    onAdClosed = {},
                                                    onUnavailable = onUnavailable
                                                )
                                            },
                                            onToggleSound = {
                                                scope.launch { repository.setSoundEnabled(!progress.soundEnabled) }
                                            },
                                            onRecordMovesDelta = { movesDelta, mistakesDelta ->
                                                scope.launch { repository.recordMovesAndMistakes(movesDelta, mistakesDelta) }
                                            },
                                            onLevelComplete = { stars, moves, mistakes, elapsedMs ->
                                                val (todayKey, _) = ChapterCatalog.getDailySeed()
                                                scope.launch {
                                                    repository.recordLevelComplete(
                                                        levelId = level.id,
                                                        stars = stars,
                                                        moves = moves,
                                                        mistakes = mistakes,
                                                        elapsedMs = elapsedMs,
                                                        isDaily = level.isDaily,
                                                        dailyDateKey = todayKey
                                                    )
                                                }
                                                adMobManager.onLevelCompletedMaybeShowInterstitial(this@MainActivity) {}
                                            },
                                            onNextLevel = {
                                                if (level.isRandom) {
                                                    launchRandom(level.difficulty)
                                                } else if (level.id in 1 until ChapterCatalog.TOTAL_CAMPAIGN_LEVELS) {
                                                    launchCampaign(level.id + 1)
                                                } else {
                                                    screen = AppScreen.LEVEL_SELECT
                                                }
                                            },
                                            onExitHome = { screen = AppScreen.MENU }
                                        )
                                    }
                                }

                                AppScreen.DIFFICULTY_SELECT -> DifficultySelectScreen(
                                    selectedDifficulty = progress.selectedDifficulty,
                                    adMobManager = adMobManager,
                                    onSelectAndPlay = {
                                        soundManager.playClick()
                                        launchRandom(it)
                                    },
                                    onBack = { screen = AppScreen.MENU }
                                )

                                AppScreen.STATISTICS -> StatisticsScreen(
                                    progress = progress,
                                    adMobManager = adMobManager,
                                    onBack = { screen = AppScreen.MENU }
                                )

                                AppScreen.SETTINGS -> SettingsScreen(
                                    progress = progress,
                                    adMobManager = adMobManager,
                                    onToggleSound = { scope.launch { repository.setSoundEnabled(!progress.soundEnabled) } },
                                    onToggleVibration = { scope.launch { repository.setVibrationEnabled(!progress.vibrationEnabled) } },
                                    onChangeArrowSpeed = { mult -> scope.launch { repository.setArrowSpeedMultiplier(mult) } },
                                    onResetProgress = { scope.launch { repository.resetAll() } },
                                    onBack = { screen = AppScreen.MENU }
                                )

                                AppScreen.PRIVACY -> PrivacyPolicyScreen(
                                    isPrivacyOptionsRequired = consentManager.isPrivacyOptionsRequired,
                                    adMobManager = adMobManager,
                                    onShowPrivacyOptions = {
                                        consentManager.showPrivacyOptionsForm(this@MainActivity) {}
                                    },
                                    onBack = { screen = AppScreen.MENU }
                                )

                                AppScreen.ABOUT -> AboutUsScreen(
                                    adMobManager = adMobManager,
                                    onBack = { screen = AppScreen.MENU }
                                )
                            }
                        }

                        // Adaptive Banner docked cleanly at the bottom across menus and below the level arrow board
                        AdaptiveBannerAd(isSdkInitialized = isSdkInitialized)
                    }
                }
            }
        }
    }
}

@Composable
private fun AppStartupLoadingScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArrowColors.Background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Arrow Puzzle",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = ArrowColors.NavyInk
        )
        Text(
            text = "Nightmare Edition",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = ArrowColors.CrimsonHeart
        )
        Spacer(Modifier.height(24.dp))
        CircularProgressIndicator(
            modifier = Modifier.size(28.dp),
            strokeWidth = 3.dp,
            color = ArrowColors.NavyInk
        )
    }
}
