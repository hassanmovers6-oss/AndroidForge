-keep class com.educationwithhassan.arrowpuzzle.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Google Mobile Ads SDK & User Messaging Platform (UMP)
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.ump.** { *; }
-keepclassmembers class * implements androidx.lifecycle.DefaultLifecycleObserver {
    public void onStart(androidx.lifecycle.LifecycleOwner);
}
-dontwarn com.google.android.gms.ads.**
-dontwarn com.google.android.ump.**
