package com.educationwithhassan.financetools.ads

import android.content.res.Configuration
import android.view.ViewGroup
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

private enum class BannerLoadState {
    LOADING,
    LOADED,
    FAILED
}

/**
 * Policy-safe Google Adaptive Anchored Banner Ad container:
 * - Waits for MobileAds SDK initialization before calling loadAd()
 * - Reuses a single AdView instance without recreating duplicates on recomposition or tab switches
 * - Keeps non-zero adaptive dimensions during initial load so creative rendering never fails,
 *   and collapses gracefully to 0.dp when loading fails, offline, or hidden
 * - Handles resume/pause/destroy lifecycle properly to prevent memory leaks
 */
@Composable
fun BannerAdView(
    modifier: Modifier = Modifier,
    adUnitId: String = AdMobConfig.bannerAdUnitId,
    isVisible: Boolean = true,
    applyNavigationBarPadding: Boolean = false
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val screenWidthDp = configuration.screenWidthDp.coerceAtLeast(320)

    val adaptiveSize = remember(screenWidthDp, isLandscape, context) {
        AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, screenWidthDp)
    }
    val adHeightDp = remember(adaptiveSize, context) {
        (adaptiveSize.getHeightInPixels(context) / context.resources.displayMetrics.density)
            .coerceAtLeast(50f)
    }

    var loadState by remember(adUnitId) { mutableStateOf(BannerLoadState.LOADING) }
    var hasRequested by remember(adUnitId) { mutableStateOf(false) }

    val adView = remember(adUnitId) {
        AdView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setAdSize(adaptiveSize)
            this.adUnitId = adUnitId
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    loadState = BannerLoadState.LOADED
                    AdDiagnostics.onAdLoaded(AdFormat.BANNER)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    loadState = BannerLoadState.FAILED
                    AdDiagnostics.onAdFailedToLoad(AdFormat.BANNER, error)
                }

                override fun onAdImpression() {
                    AdDiagnostics.onAdImpression(AdFormat.BANNER)
                }

                override fun onAdClicked() {
                    AdDiagnostics.onAdClicked(AdFormat.BANNER)
                }

                override fun onAdOpened() {
                    AdDiagnostics.onAdDisplayed(AdFormat.BANNER, isFullScreen = false)
                }

                override fun onAdClosed() {
                    AdDiagnostics.onAdDismissed(AdFormat.BANNER, isFullScreen = false)
                }
            }
        }
    }

    // Request banner only once MobileAds SDK initialization completes
    LaunchedEffect(adView, isVisible) {
        if (isVisible && !hasRequested) {
            hasRequested = true
            AdDiagnostics.runWhenSdkReady {
                AdDiagnostics.onRequestStarted(AdFormat.BANNER)
                adView.loadAd(AdRequest.Builder().build())
            }
        }
    }

    // Pause/resume cleanly when visibility or Activity lifecycle changes
    LaunchedEffect(adView, isVisible) {
        if (isVisible) adView.resume() else adView.pause()
    }

    DisposableEffect(lifecycleOwner, adView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> if (isVisible) adView.resume()
                Lifecycle.Event.ON_PAUSE -> adView.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            adView.destroy()
            AdDiagnostics.onAdDisposed(AdFormat.BANNER)
        }
    }

    val shouldReserveSpace = isVisible && loadState != BannerLoadState.FAILED

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = if (isVisible && loadState == BannerLoadState.LOADED) 2.dp else 0.dp,
        modifier = modifier
            .fillMaxWidth()
            .then(if (applyNavigationBarPadding && shouldReserveSpace) Modifier.navigationBarsPadding() else Modifier)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isVisible && loadState == BannerLoadState.LOADED) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
            AndroidView(
                factory = { adView },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (shouldReserveSpace) adHeightDp.dp else 0.dp)
                    .padding(vertical = if (isVisible && loadState == BannerLoadState.LOADED) 2.dp else 0.dp)
            )
        }
    }
}
