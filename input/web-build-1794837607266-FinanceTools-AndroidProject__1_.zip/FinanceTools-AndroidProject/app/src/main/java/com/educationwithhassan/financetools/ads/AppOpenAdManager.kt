package com.educationwithhassan.financetools.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd

/**
 * Policy-safe Google AdMob App Open Ad Manager:
 * - Waits for MobileAds SDK initialization before requesting ads
 * - Supports fresh cold-launch display if ad loads within the startup grace window (5s)
 * - Supports background-to-foreground resume via ProcessLifecycleOwner
 * - Enforces 4-hour ad freshness, 60s App Open cooldown, and 30s post-Interstitial/Rewarded grace period
 * - Never blocks startup and never displays over another active full-screen ad
 */
class AppOpenAdManager(
    context: Context,
    private val appOpenCooldownMs: Long = 60_000L,
    private val postFullScreenGraceMs: Long = 30_000L,
    private val coldLaunchWindowMs: Long = 5_000L
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val appStartMs = System.currentTimeMillis()

    private var appOpenAd: AppOpenAd? = null
    private var isLoading = false
    private var isShowing = false
    private var loadTimeMs = 0L
    private var lastShownMs = 0L
    private var coldLaunchHandled = false
    private var coldLaunchActivityProvider: (() -> Activity?)? = null

    fun setColdLaunchActivityProvider(provider: () -> Activity?) {
        coldLaunchActivityProvider = provider
    }

    fun loadAd() {
        AdDiagnostics.runWhenSdkReady {
            if (isLoading || isAdAvailable()) return@runWhenSdkReady
            isLoading = true
            AdDiagnostics.onRequestStarted(AdFormat.APP_OPEN)
            AppOpenAd.load(
                appContext,
                AdMobConfig.appOpenAdUnitId,
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        loadTimeMs = System.currentTimeMillis()
                        isLoading = false
                        AdDiagnostics.onAdLoaded(AdFormat.APP_OPEN)

                        // Show on fresh app launch if loaded promptly while user is still on startup window
                        val withinColdLaunch = (System.currentTimeMillis() - appStartMs) <= coldLaunchWindowMs
                        if (!coldLaunchHandled && withinColdLaunch) {
                            coldLaunchHandled = true
                            val activity = coldLaunchActivityProvider?.invoke()
                            if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                                showAdIfAvailable(activity)
                            }
                        }
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        appOpenAd = null
                        isLoading = false
                        coldLaunchHandled = true
                        AdDiagnostics.onAdFailedToLoad(AdFormat.APP_OPEN, error)
                    }
                }
            )
        }
    }

    private fun isAdAvailable(): Boolean {
        val fourHoursMs = 4 * 60 * 60 * 1000L
        return appOpenAd != null && (System.currentTimeMillis() - loadTimeMs) < fourHoursMs
    }

    fun showAdIfAvailable(activity: Activity, onComplete: () -> Unit = {}) {
        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                onComplete()
                return@post
            }
            if (isShowing || AdDiagnostics.isAnyFullScreenAdActive()) {
                Log.d(AdFormat.APP_OPEN.logTag, "Skipping App Open Ad: another full-screen ad is active")
                onComplete()
                return@post
            }
            val now = System.currentTimeMillis()
            if (lastShownMs != 0L && now - lastShownMs < appOpenCooldownMs) {
                Log.d(AdFormat.APP_OPEN.logTag, "Skipping App Open Ad: cooldown active")
                onComplete()
                return@post
            }
            if (AdDiagnostics.msSinceLastFullScreenAdDismissed() < postFullScreenGraceMs) {
                Log.d(AdFormat.APP_OPEN.logTag, "Skipping App Open Ad: recent interstitial/rewarded grace period")
                onComplete()
                return@post
            }
            val ad = appOpenAd
            if (ad == null || !isAdAvailable()) {
                appOpenAd = null
                loadAd()
                onComplete()
                return@post
            }

            coldLaunchHandled = true
            isShowing = true
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    AdDiagnostics.onAdDisplayed(AdFormat.APP_OPEN, isFullScreen = true)
                }

                override fun onAdImpression() {
                    AdDiagnostics.onAdImpression(AdFormat.APP_OPEN)
                }

                override fun onAdClicked() {
                    AdDiagnostics.onAdClicked(AdFormat.APP_OPEN)
                }

                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    isShowing = false
                    lastShownMs = System.currentTimeMillis()
                    AdDiagnostics.onAdDismissed(AdFormat.APP_OPEN, isFullScreen = true)
                    loadAd()
                    onComplete()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    appOpenAd = null
                    isShowing = false
                    AdDiagnostics.onAdFailedToShow(AdFormat.APP_OPEN, adError, isFullScreen = true)
                    loadAd()
                    onComplete()
                }
            }
            ad.show(activity)
        }
    }

    fun dispose() {
        mainHandler.post {
            appOpenAd?.fullScreenContentCallback = null
            appOpenAd = null
            coldLaunchActivityProvider = null
            isLoading = false
            isShowing = false
            AdDiagnostics.onAdDisposed(AdFormat.APP_OPEN)
        }
    }
}
