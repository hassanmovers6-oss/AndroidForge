package com.spintoearn.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.ActivityLoginBinding
import com.spintoearn.app.ui.main.MainActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val session = SessionManager(this)

        binding.btnGoRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString()
            if (email.isEmpty() || password.isEmpty()) {
                showError("Please enter both email and password.")
                return@setOnClickListener
            }
            binding.btnLogin.isEnabled = false
            binding.tvError.visibility = View.GONE

            lifecycleScope.launch {
                try {
                    val res = ApiClient.getService(this@LoginActivity).login(
                        mapOf(
                            "email" to email,
                            "password" to password,
                            "device_fingerprint" to session.getDeviceFingerprint()
                        )
                    )
                    if (res.success && res.data != null) {
                        session.saveToken(res.data.token)
                        session.saveUserInfo(
                            res.data.user.fullName,
                            res.data.user.email,
                            res.data.user.referralCode
                        )
                        startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                        finish()
                    } else {
                        showError(res.message)
                    }
                } catch (e: Exception) {
                    showError("Network error: ${e.localizedMessage}")
                } finally {
                    binding.btnLogin.isEnabled = true
                }
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = View.VISIBLE
    }
}
