package com.spintoearn.app.data.model

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    @SerializedName("server_time") val serverTime: String?,
    val data: T?
)

data class AuthData(
    val token: String,
    val user: UserSummary
)

data class UserSummary(
    val id: Long,
    @SerializedName("full_name") val fullName: String,
    val email: String,
    val phone: String?,
    @SerializedName("referral_code") val referralCode: String
)

data class AdFormatRule(
    val enabled: Boolean,
    @SerializedName("test_mode") val testMode: Boolean,
    @SerializedName("ad_unit_id") val adUnitId: String,
    @SerializedName("frequency_cap_per_hour") val frequencyCapPerHour: Int,
    @SerializedName("cooldown_seconds") val cooldownSeconds: Int,
    @SerializedName("rewarded_points") val rewardedPoints: Int,
    @SerializedName("placement_notes") val placementNotes: String?
)

data class AppConfigData(
    @SerializedName("app_name") val appName: String,
    @SerializedName("app_version") val appVersion: String,
    @SerializedName("support_email") val supportEmail: String,
    @SerializedName("minimum_withdrawal_pkr") val minimumWithdrawalPkr: Double,
    @SerializedName("payment_methods") val paymentMethods: List<String>,
    @SerializedName("maintenance_mode") val maintenanceMode: Boolean,
    @SerializedName("announcement_message") val announcementMessage: String,
    @SerializedName("spins_enabled") val spinsEnabled: Boolean,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    val admob: Map<String, AdFormatRule>
)

data class DashboardData(
    val user: UserSummary,
    val spins: SpinQuota,
    @SerializedName("non_cash_points") val nonCashPoints: NonCashPoints,
    @SerializedName("cash_wallet") val cashWallet: CashWallet,
    @SerializedName("active_tasks_count") val activeTasksCount: Int,
    @SerializedName("unread_notifications") val unreadNotifications: Int,
    val announcement: String
)

data class SpinQuota(
    @SerializedName("server_date_utc") val serverDateUtc: String,
    @SerializedName("daily_limit") val dailyLimit: Int,
    @SerializedName("used_today") val usedToday: Int,
    @SerializedName("remaining_today") val remainingToday: Int,
    @SerializedName("spins_enabled") val spinsEnabled: Boolean
)

data class NonCashPoints(
    val balance: Long,
    @SerializedName("lifetime_earned") val lifetimeEarned: Long
)

data class CashWallet(
    @SerializedName("available_balance_pkr") val availableBalancePkr: Double,
    @SerializedName("pending_withdrawal_pkr") val pendingWithdrawalPkr: Double,
    @SerializedName("approved_task_earnings_pkr") val approvedTaskEarningsPkr: Double,
    @SerializedName("total_withdrawn_pkr") val totalWithdrawnPkr: Double
)

data class WheelSlice(
    val id: Int,
    @SerializedName("slice_index") val sliceIndex: Int,
    val label: String,
    @SerializedName("points_value") val pointsValue: Int,
    @SerializedName("slice_color") val sliceColor: String
)

data class RecentSpinItem(
    val id: Long,
    @SerializedName("points_awarded") val pointsAwarded: Int,
    @SerializedName("spin_date_utc") val spinDateUtc: String,
    @SerializedName("created_at") val createdAt: String,
    val label: String
)

data class WheelData(
    @SerializedName("spins_enabled") val spinsEnabled: Boolean,
    @SerializedName("server_date_utc") val serverDateUtc: String,
    @SerializedName("daily_limit") val dailyLimit: Int,
    @SerializedName("used_today") val usedToday: Int,
    @SerializedName("remaining_today") val remainingToday: Int,
    @SerializedName("points_balance") val pointsBalance: Long,
    val slices: List<WheelSlice>,
    @SerializedName("recent_spins") val recentSpins: List<RecentSpinItem>
)

data class SpinResultData(
    @SerializedName("slice_id") val sliceId: Int,
    @SerializedName("slice_index") val sliceIndex: Int,
    val label: String,
    @SerializedName("points_awarded") val pointsAwarded: Int,
    @SerializedName("points_balance") val pointsBalance: Long,
    @SerializedName("used_today") val usedToday: Int,
    @SerializedName("remaining_today") val remainingToday: Int,
    @SerializedName("reference_id") val referenceId: String
)

data class RewardedVerifyData(
    @SerializedName("points_awarded") val pointsAwarded: Int,
    @SerializedName("points_balance") val pointsBalance: Long,
    @SerializedName("reference_id") val referenceId: String
)

data class TaskItem(
    val id: Long,
    val title: String,
    val category: String,
    val instructions: String,
    @SerializedName("reward_pkr") val rewardPkr: Double,
    @SerializedName("requires_proof") val requiresProof: Boolean,
    @SerializedName("proof_placeholder") val proofPlaceholder: String,
    @SerializedName("can_submit") val canSubmit: Boolean
)

data class TasksData(val tasks: List<TaskItem>)

data class WalletSummaryData(
    @SerializedName("available_balance_pkr") val availableBalancePkr: Double,
    @SerializedName("pending_withdrawal_pkr") val pendingWithdrawalPkr: Double,
    @SerializedName("approved_task_earnings_pkr") val approvedTaskEarningsPkr: Double,
    @SerializedName("total_withdrawn_pkr") val totalWithdrawnPkr: Double,
    @SerializedName("minimum_withdrawal_pkr") val minimumWithdrawalPkr: Double,
    @SerializedName("recent_transactions") val recentTransactions: List<CashTransactionItem>
)

data class CashTransactionItem(
    val id: Long,
    @SerializedName("reference_id") val referenceId: String,
    @SerializedName("tx_type") val txType: String,
    @SerializedName("amount_pkr") val amountPkr: Double,
    @SerializedName("balance_after_pkr") val balanceAfterPkr: Double,
    val description: String,
    @SerializedName("created_at") val createdAt: String
)

data class TransactionsData(
    @SerializedName("cash_transactions") val cashTransactions: List<CashTransactionItem>
)

data class ReferralData(
    @SerializedName("referral_code") val referralCode: String,
    @SerializedName("reward_per_referral_pkr") val rewardPerReferralPkr: Double,
    @SerializedName("total_referrals") val totalReferrals: Int,
    @SerializedName("pending_referrals") val pendingReferrals: Int,
    @SerializedName("approved_referrals") val approvedReferrals: Int,
    @SerializedName("total_cash_earned_pkr") val totalCashEarnedPkr: Double
)

data class NotificationItem(
    val id: Long,
    val title: String,
    val message: String,
    val category: String,
    @SerializedName("created_at") val createdAt: String
)

data class NotificationsData(val items: List<NotificationItem>)

data class DailyActivityData(
    @SerializedName("server_date_utc") val serverDateUtc: String,
    @SerializedName("checked_in_today") val checkedInToday: Boolean,
    @SerializedName("checkin_streak") val checkinStreak: Int,
    @SerializedName("checkin_points") val checkinPoints: Int,
    @SerializedName("spins_used_today") val spinsUsedToday: Int,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    @SerializedName("approved_tasks") val approvedTasks: Int
)
