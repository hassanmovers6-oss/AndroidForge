package com.spintoearn.app.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.FragmentProfileBinding
import com.spintoearn.app.ui.auth.LoginActivity
import com.spintoearn.app.ui.features.*
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val session = SessionManager(requireContext())
        binding.tvProfileName.text = session.getUserName()
        binding.tvProfileEmail.text = session.getUserEmail()

        AdMobManager.loadBanner(requireContext(), binding.bannerAdContainer)

        binding.btnNotifications.setOnClickListener {
            startActivity(Intent(requireContext(), NotificationsActivity::class.java))
        }
        binding.btnHelpSupport.setOnClickListener {
            startActivity(Intent(requireContext(), HelpSupportActivity::class.java))
        }
        binding.btnPrivacy.setOnClickListener {
            startActivity(Intent(requireContext(), LegalDocumentActivity::class.java).putExtra("doc_type", "privacy"))
        }
        binding.btnTerms.setOnClickListener {
            startActivity(Intent(requireContext(), LegalDocumentActivity::class.java).putExtra("doc_type", "terms"))
        }
        binding.btnDeleteAccount.setOnClickListener {
            startActivity(Intent(requireContext(), DeleteAccountActivity::class.java))
        }
        binding.btnLogout.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch {
                try { ApiClient.getService(requireContext()).logout() } catch (_: Exception) {}
                session.clearSession()
                startActivity(Intent(requireContext(), LoginActivity::class.java))
                requireActivity().finishAffinity()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
