package com.spintoearn.app.ui.features

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.model.CashTransactionItem
import com.spintoearn.app.databinding.ActivityTransactionHistoryBinding
import com.spintoearn.app.databinding.ItemListRowBinding
import kotlinx.coroutines.launch

class TransactionHistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTransactionHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rvTransactions.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            try {
                val res = ApiClient.getService(this@TransactionHistoryActivity).getTransactions()
                if (res.success && res.data != null) {
                    binding.rvTransactions.adapter = TxAdapter(res.data.cashTransactions)
                }
            } catch (_: Exception) {}
        }
    }

    private class TxAdapter(private val items: List<CashTransactionItem>) : RecyclerView.Adapter<TxAdapter.VH>() {
        class VH(val b: ItemListRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val tx = items[position]
            holder.b.tvRowTitle.text = "${tx.referenceId} · ${tx.txType}"
            holder.b.tvRowSubtitle.text = "${tx.description} (${tx.createdAt})"
            holder.b.tvRowMeta.text = String.format("Rs. %.2f | Balance: Rs. %.2f", tx.amountPkr, tx.balanceAfterPkr)
        }
    }
}
