package com.spintoearn.app.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.FragmentSpinBinding
import kotlinx.coroutines.launch
import java.util.UUID

class SpinFragment : Fragment() {

    private var _binding: FragmentSpinBinding? = null
    private val binding get() = _binding!!
    private var isSpinning = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSpinBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AdMobManager.loadBanner(requireContext(), binding.bannerAdContainer)
        AdMobManager.preloadInterstitial(requireContext())

        binding.btnSpinNow.setOnClickListener { executeSpin() }
        loadWheel()
    }

    private fun loadWheel() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).getSpinWheel()
                if (res.success && res.data != null && _binding != null) {
                    val d = res.data
                    binding.spinWheelView.setSlices(d.slices)
                    binding.tvRemainingSpins.text = "Remaining spins today: ${d.remainingToday} / ${d.dailyLimit} (${d.serverDateUtc})"
                    binding.btnSpinNow.isEnabled = d.spinsEnabled && d.remainingToday > 0

                    binding.tvRecentSpins.text = if (d.recentSpins.isEmpty()) {
                        "No spins recorded yet."
                    } else {
                        d.recentSpins.joinToString("\n") { "• ${it.label} (+${it.pointsAwarded} pts) — ${it.spinDateUtc}" }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun executeSpin() {
        if (isSpinning) return
        isSpinning = true
        binding.btnSpinNow.isEnabled = false
        val idempotencyKey = "spin_${UUID.randomUUID()}"
        val fp = SessionManager(requireContext()).getDeviceFingerprint()

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).executeSpin(
                    mapOf("idempotency_key" to idempotencyKey, "device_fingerprint" to fp)
                )
                if (res.success && res.data != null && _binding != null) {
                    val result = res.data
                    binding.spinWheelView.spinToSliceIndex(result.sliceIndex) {
                        isSpinning = false
                        if (_binding != null && isAdded) {
                            AdMobManager.showInterstitialAfterSpin(requireActivity()) {
                                if (_binding != null && isAdded) {
                                    MaterialAlertDialogBuilder(requireContext())
                                        .setTitle("Spin Result")
                                        .setMessage("You received ${result.pointsAwarded} non-cash points!\nNew Non-Cash Balance: ${result.pointsBalance} pts")
                                        .setPositiveButton("OK", null)
                                        .show()
                                    loadWheel()
                                }
                            }
                        }
                    }
                } else {
                    isSpinning = false
                    binding.btnSpinNow.isEnabled = true
                    Toast.makeText(requireContext(), res.message, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                isSpinning = false
                binding.btnSpinNow.isEnabled = true
                Toast.makeText(requireContext(), "Spin failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
