package com.spintoearn.app.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.spintoearn.app.data.model.AppConfigData
import java.util.UUID

class SessionManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "spinreward_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        context.getSharedPreferences("spinreward_fallback_prefs", Context.MODE_PRIVATE)
    }

    private val gson = Gson()

    fun saveToken(token: String) {
        prefs.edit().putString("auth_token", token).apply()
    }

    fun getToken(): String? = prefs.getString("auth_token", null)

    fun saveUserInfo(name: String, email: String, referralCode: String) {
        prefs.edit()
            .putString("user_name", name)
            .putString("user_email", email)
            .putString("referral_code", referralCode)
            .apply()
    }

    fun getUserName(): String = prefs.getString("user_name", "User") ?: "User"
    fun getUserEmail(): String = prefs.getString("user_email", "") ?: ""
    fun getReferralCode(): String = prefs.getString("referral_code", "") ?: ""

    fun getDeviceFingerprint(): String {
        var fp = prefs.getString("device_fp", null)
        if (fp.isNullOrBlank()) {
            fp = UUID.randomUUID().toString()
            prefs.edit().putString("device_fp", fp).apply()
        }
        return fp
    }

    fun saveAppConfig(config: AppConfigData) {
        prefs.edit().putString("app_config_json", gson.toJson(config)).apply()
    }

    fun getAppConfig(): AppConfigData? {
        val raw = prefs.getString("app_config_json", null) ?: return null
        return try {
            gson.fromJson(raw, AppConfigData::class.java)
        } catch (_: Exception) {
            null
        }
    }

    fun clearSession() {
        val fp = getDeviceFingerprint()
        prefs.edit().clear().putString("device_fp", fp).apply()
    }
}
