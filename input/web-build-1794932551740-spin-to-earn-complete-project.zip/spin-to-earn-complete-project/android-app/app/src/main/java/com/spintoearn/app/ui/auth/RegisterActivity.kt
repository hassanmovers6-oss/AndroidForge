package com.spintoearn.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.data.local.SessionManager
import com.spintoearn.app.databinding.ActivityRegisterBinding
import com.spintoearn.app.ui.main.MainActivity
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val session = SessionManager(this)

        binding.btnGoLogin.setOnClickListener { finish() }

        binding.btnRegister.setOnClickListener {
            val name = binding.etFullName.text.toString().trim()
            val email = binding.etEmail.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val pass = binding.etPassword.text.toString()
            val ref = binding.etReferralCode.text.toString().trim()

            if (name.length < 2 || email.isEmpty() || pass.length < 8) {
                showError("Enter valid name, email, and password (min 8 chars).")
                return@setOnClickListener
            }

            binding.btnRegister.isEnabled = false
            binding.tvError.visibility = View.GONE

            lifecycleScope.launch {
                try {
                    val res = ApiClient.getService(this@RegisterActivity).register(
                        mapOf(
                            "full_name" to name,
                            "email" to email,
                            "phone" to phone,
                            "password" to pass,
                            "referral_code" to ref,
                            "device_fingerprint" to session.getDeviceFingerprint()
                        )
                    )
                    if (res.success && res.data != null) {
                        session.saveToken(res.data.token)
                        session.saveUserInfo(
                            res.data.user.fullName,
                            res.data.user.email,
                            res.data.user.referralCode
                        )
                        startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                        finishAffinity()
                    } else {
                        showError(res.message)
                    }
                } catch (e: Exception) {
                    showError("Network error: ${e.localizedMessage}")
                } finally {
                    binding.btnRegister.isEnabled = true
                }
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = View.VISIBLE
    }
}
