package com.spintoearn.app.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.spintoearn.app.ads.AdMobManager
import com.spintoearn.app.data.api.ApiClient
import com.spintoearn.app.databinding.FragmentReferralBinding
import kotlinx.coroutines.launch

class ReferralFragment : Fragment() {

    private var _binding: FragmentReferralBinding? = null
    private val binding get() = _binding!!
    private var currentCode = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReferralBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AdMobManager.loadNative(requireContext(), binding.nativeAdContainer)
        AdMobManager.loadBanner(requireContext(), binding.bannerAdContainer)

        binding.btnShareReferral.setOnClickListener {
            if (currentCode.isNotEmpty()) {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Join SpinReward Pro using my referral code: $currentCode")
                }
                startActivity(Intent.createChooser(share, "Share Referral Code"))
            }
        }
        loadReferrals()
    }

    private fun loadReferrals() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = ApiClient.getService(requireContext()).getReferralInfo()
                if (res.success && res.data != null && _binding != null) {
                    val r = res.data
                    currentCode = r.referralCode
                    binding.tvReferralCode.text = r.referralCode
                    binding.tvReferralStats.text =
                        "Total: ${r.totalReferrals} | Pending: ${r.pendingReferrals} | Approved: ${r.approvedReferrals}\n" +
                        "Referral Cash Program Earned: Rs. ${String.format("%.2f", r.totalCashEarnedPkr)}"
                }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
