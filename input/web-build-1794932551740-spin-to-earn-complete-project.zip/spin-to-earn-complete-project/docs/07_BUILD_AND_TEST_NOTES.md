# 07. Environment Verification & APK Build Status

## Verified in Container
- **Live Express + SQLite Simulation Server (`server.ts`)**: Mirrors all 18 tables from `database/spin_to_earn.sql` and all REST API & Admin flows.
- **Automated Integration Test Suite**: Verifies registration, login, UTC daily spin limit (5/day), server-side weighted spin calculation, duplicate spin idempotency rejection, Watch Video non-cash point separation, task submission & admin approval crediting, JazzCash/Easypaisa withdrawal balance hold & admin rejection refund, referral tracking & self-referral block, and account deletion.
- **ZIP Deliverable (`spin-to-earn-complete-project.zip`)**: Verified archive containing all Android Kotlin, XML, PHP 8+ backend, PHP Admin Panel, MySQL schema, and documentation files.

## Requires Target Runtime / CI Runner (Not Installed in Container)
- **APK Compilation (`assembleRelease`)**: JDK, Gradle CLI, and Android SDK are not installed in this cloud web container, so the `.apk` binary cannot be compiled locally inside this container. Complete Gradle build files (`android-app/settings.gradle.kts`, `android-app/gradlew`, `android-app/gradle/wrapper/gradle-wrapper.properties`, `android-app/app/build.gradle.kts`, `android-app/app/proguard-rules.pro`) and the CI workflow (`.github/workflows/android-release.yml`) are included—execute inside `android-app/` using AndroidForge, GitHub Actions, or Android Studio.
- **PHP 8+ / MySQL 8+ Deployment**: PHP and MySQL daemons are not installed in this Node.js web container; verify on your target LAMP/LEMP host following `01_DATABASE_INSTALLATION.md` and `02_BACKEND_HOSTING_GUIDE.md`.
