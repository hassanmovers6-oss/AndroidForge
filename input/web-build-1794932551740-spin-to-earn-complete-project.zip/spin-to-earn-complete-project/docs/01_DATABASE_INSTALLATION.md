# 01. MySQL / MariaDB Database Installation Instructions

## Prerequisites
- MySQL 8.0+ or MariaDB 10.4+ (XAMPP MariaDB 10.4.32 supported)
- PHP 8.2+ with `pdo_mysql`, `openssl`, `mbstring`, `fileinfo`, `json`

## Local Windows XAMPP Quick Setup (Pre-Imported `spin_to_earn`)
If you already imported `database/spin_to_earn.sql` into phpMyAdmin under database name `spin_to_earn`:
1. `backend-api/config.php` is preconfigured for XAMPP (`127.0.0.1:3306`, DB `spin_to_earn`, user `root`, blank password, `utf8mb4`).
2. Open **XAMPP Control Panel** -> click **Shell** (or Command Prompt) and run:
   ```bat
   cd C:\xampp\htdocs\spin-to-earn-complete-project\backend-api
   C:\xampp\php\php.exe setup.php
   ```
3. `setup.php` connects without dropping/altering your existing records, verifies all 18 tables exist, generates a unique 64-char hex `app_secret` in `backend-api/.app_secret`, and creates the initial `super_admin` once if `admins` is empty.
4. Log in via: `http://localhost/spin-to-earn-complete-project/admin-panel/login.php`.

## Fresh Production Server Setup
1. Import the schema:
   ```bash
   mysql -u root -p < database/spin_to_earn.sql
   ```
2. Create a dedicated least-privilege application user:
   ```sql
   CREATE USER 'spin_app'@'localhost' IDENTIFIED BY 'STRONG_RANDOM_PASSWORD';
   GRANT SELECT, INSERT, UPDATE, DELETE ON spin_to_earn.* TO 'spin_app'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. Copy `backend-api/config.production.example.php` to `backend-api/config.production.php` (or set `APP_ENV=production` and environment variables `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`, `APP_BASE_URL`, `APP_SECRET`).
4. Run `php backend-api/setup.php` once via CLI to generate `.app_secret` and create the initial Super Admin account.
