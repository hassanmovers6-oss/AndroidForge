# 06. Privacy Policy & Terms and Conditions Templates

## Privacy Policy Template
**Effective Date:** [INSERT DATE]  
**[YOUR COMPANY / APP NAME]** operates the SpinReward Pro mobile application.

1. **Information We Collect**: Account registration details (name, email, optional phone), device integrity identifier (to prevent duplicate accounts and spin/referral abuse), task proof submissions, and payout account information (JazzCash / Easypaisa number and holder name) solely for processing requested cash withdrawals.
2. **Advertising**: We use Google Mobile Ads (AdMob). Google may collect device advertising identifiers in accordance with Google's Privacy Policy. We never require ad viewing to unlock cash withdrawals.
3. **Data Retention & Account Deletion**: You can permanently delete your account inside the app (**Profile -> Delete Account**), which revokes sessions and anonymizes personal profile fields.
4. **Contact**: `[SUPPORT_EMAIL]`

---

## Terms and Conditions Template
1. **Non-Cash Spin & Ad Rewards**: Points earned from the Spin Wheel, Daily Check-In, or Watch Video & Earn are strictly non-cash, non-transferable in-app perks. They hold zero monetary value and can never be converted into cash, gift cards, or cryptocurrency.
2. **Genuine Cash Tasks**: Cash earnings accrue exclusively through admin-approved tasks and eligible referral program bonuses.
3. **Withdrawals**: Minimum withdrawal thresholds (default Rs. 100) and supported payment methods (JazzCash, Easypaisa) are governed by platform checks and administrator review.
4. **Prohibited Conduct**: Automated scripts, device clock manipulation, self-referrals, or submitting fabricated task proof will result in account suspension.
