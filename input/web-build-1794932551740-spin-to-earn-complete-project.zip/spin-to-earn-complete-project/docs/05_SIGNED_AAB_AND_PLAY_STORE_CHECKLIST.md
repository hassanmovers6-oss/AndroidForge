# 05. Signed Release AAB & Google Play Store Publishing Checklist

## Generating a Signed Release `.aab`
1. Create an upload keystore (store safely offline, never commit):
   ```bash
   keytool -genkey -v -keystore spinreward-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias spinreward
   ```
2. In Android Studio: **Build -> Generate Signed Bundle / APK -> Android App Bundle**.
3. Select `release` build variant (`isMinifyEnabled = true`, `isShrinkResources = true`).
4. Enroll in **Play App Signing** inside Google Play Console and upload `app-release.aab`.

## Play Store Policy & Technical Checklist
- [ ] Replace `API_BASE_URL` with production HTTPS domain.
- [ ] Replace test AdMob App ID & Ad Unit IDs with production IDs.
- [ ] Verify non-cash spin points and rewarded ad perks are clearly disclosed as non-cash, non-transferable in-app benefits.
- [ ] Verify cash tasks & withdrawals do not require ad views.
- [ ] Verify in-app **Delete Account** flow works and matches Play Data Safety form.
- [ ] Publish Privacy Policy & Terms URLs on your domain and link in Play Console.
- [ ] Complete Play Console Data Safety, Ads Declaration, and App Access instructions (provide a demo reviewer login).
