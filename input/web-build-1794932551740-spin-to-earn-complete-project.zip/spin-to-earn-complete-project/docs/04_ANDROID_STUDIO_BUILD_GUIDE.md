# 04. Android Studio & Gradle Build Instructions

## Prerequisites
- Android Studio Jellyfish / Koala or newer (AGP 8.5.2, Gradle Wrapper 8.7 included, JDK 17)
- Android SDK Platform 34 & Build-Tools 34.0.0

## Important: Gradle Project Root
The Android Gradle project resides inside **`android-app/`** (not the outer `spin-to-earn-complete-project/` folder, which also houses `backend-api/`, `admin-panel/`, `database/`, and `docs/`).

## Steps to Build Debug or Release APK
1. Open `android-app/` in Android Studio (or `cd android-app` in terminal).
2. Configure `API_BASE_URL`:
   - Default placeholder in `android-app/app/build.gradle.kts` is `https://your-domain.example.com/backend-api/api/v1/`.
   - Pass `-PAPI_BASE_URL="https://your-live-domain.com/backend-api/api/v1/"` (or set env var `API_BASE_URL`) before building for devices.
3. Build via Gradle Wrapper inside `android-app/`:
   ```bash
   cd android-app
   ./gradlew assembleDebug
   ./gradlew assembleRelease
   ```
4. Outputs:
   - Debug APK: `android-app/app/build/outputs/apk/debug/app-debug.apk`
   - Signed Release APK (when keystore configured): `android-app/app/build/outputs/apk/release/app-release.apk`
   - Unsigned Release APK (without keystore): `android-app/app/build/outputs/apk/release/app-release-unsigned.apk`
