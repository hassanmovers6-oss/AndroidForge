# 09. Windows XAMPP Setup Guide (Simple Roman Urdu)

Yeh guide aap ke Windows XAMPP (Apache + PHP 8.2.12 + MariaDB 10.4.32) ke liye step-by-step tayyar ki gayi hai.

## Step 1: Project Folder Extract Karein
- `spin-to-earn-complete-project.zip` ko extract karein taake folder is exact path par ho:
  `C:\xampp\htdocs\spin-to-earn-complete-project\`
- Is folder ke andar yeh sub-folders honge:
  `admin-panel/`, `backend-api/`, `database/`, `android-app/`, `docs/`

## Step 2: Apache aur MySQL Start Karein
- **XAMPP Control Panel** kholen.
- **Apache** aur **MySQL** dono ke samne **Start** button dabayein (dono green hone chahiye).
- Note: Aap ka `spin_to_earn` database pehle hi phpMyAdmin mein import ho chuka hai, is liye dobara import ya delete karne ki zaroorat nahi hai.

## Step 3: XAMPP Shell se `setup.php` Chalayein (Admin & Secret Banane ke liye)
- `setup.php` security ki wajah se **sirf local Shell / CLI** se chalta hai (browser mein open karne par `403 Forbidden` aayega).
- **XAMPP Control Panel** mein right side par **Shell** button par click karein, aur yeh commands chalayein:
  ```bat
  cd C:\xampp\htdocs\spin-to-earn-complete-project\backend-api
  C:\xampp\php\php.exe setup.php
  ```
- Yeh command kya karegi:
  1. `spin_to_earn` database se PDO connection check karegi (kisi existing record ko delete ya drop nahi karegi).
  2. Sab 18 tables ki mojoodgi verify karegi.
  3. Khud hi ek mehfooz 64-character hexadecimal `app_secret` bana kar `backend-api\.app_secret` file mein save karegi.
  4. Agar `admins` table khali hai to ek **Super Admin** banayegi aur screen par **Username** aur **Random Password** dikhayegi.
- **Zaroori:** CLI mein jo password print ho usay kahin safe jagah note kar lein. Agar aap dobara `setup.php` chalayenge to yeh naya duplicate admin nahi banayega.

## Step 4: Backend API aur Admin Panel Check Karein
- **Backend Public Config Test (Browser mein open karein):**
  `http://localhost/spin-to-earn-complete-project/backend-api/api/v1/config/app.php`
  (Aap ko JSON response `"success": true` nazar aana chahiye.)
- **Admin Panel Login URL:**
  `http://localhost/spin-to-earn-complete-project/admin-panel/login.php`
- Yahan step 3 wala **Username (`admin`)** aur **Password** daal kar login karein.

## Step 5: Live Hosting / Production Ke Liye Security Note
- Live server par `config.php` ke local XAMPP root settings na chalayein — `backend-api\config.production.example.php` ko copy kar ke `config.production.php` banayein aur apna live HTTPS URL + DB password us mein rakhein.
- Android APK jab mobile par chalana ho to `API_BASE_URL` live `https://...` hona chahiye (remote APK mein `localhost` kaam nahi karta aur `usesCleartextTraffic="false"` HTTP ko block karta hai).
