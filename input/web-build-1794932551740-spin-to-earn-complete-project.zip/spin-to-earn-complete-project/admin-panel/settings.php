<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

$keys = [
    'app_name', 'app_logo_url', 'support_email', 'minimum_withdrawal_pkr',
    'payment_methods', 'privacy_policy_url', 'terms_url', 'maintenance_mode',
    'app_version', 'announcement_message', 'daily_checkin_points'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $upd = $pdo->prepare('INSERT INTO app_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    foreach ($keys as $k) {
        $val = $k === 'maintenance_mode'
            ? (isset($_POST['maintenance_mode']) ? '1' : '0')
            : trim((string)($_POST[$k] ?? ''));
        $upd->execute([$k, $val]);
    }
    Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'app_settings_updated');
    $_SESSION['flash_success'] = 'Application settings updated.';
    header('Location: settings.php');
    exit;
}

$settings = Security::getAllSettings($pdo);
$pageTitle = 'App Settings';
$activeNav = 'settings';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <div><label>App Name</label><input name="app_name" value="<?= h($settings['app_name'] ?? '') ?>"></div>
    <div><label>App Logo URL</label><input name="app_logo_url" value="<?= h($settings['app_logo_url'] ?? '') ?>"></div>
    <div><label>Support Email</label><input name="support_email" value="<?= h($settings['support_email'] ?? '') ?>"></div>
    <div><label>Minimum Withdrawal (PKR)</label><input name="minimum_withdrawal_pkr" type="number" step="0.01" min="10" value="<?= h($settings['minimum_withdrawal_pkr'] ?? '100') ?>"></div>
    <div><label>Payment Methods (comma-separated)</label><input name="payment_methods" value="<?= h($settings['payment_methods'] ?? 'JazzCash,Easypaisa') ?>"></div>
    <div><label>App Version</label><input name="app_version" value="<?= h($settings['app_version'] ?? '1.0.0') ?>"></div>
    <div><label>Privacy Policy URL</label><input name="privacy_policy_url" value="<?= h($settings['privacy_policy_url'] ?? '') ?>"></div>
    <div><label>Terms URL</label><input name="terms_url" value="<?= h($settings['terms_url'] ?? '') ?>"></div>
    <div><label>Daily Check-in Non-Cash Points</label><input name="daily_checkin_points" type="number" min="1" value="<?= h($settings['daily_checkin_points'] ?? '40') ?>"></div>
    <div style="display:flex;align-items:center;padding-top:18px;">
      <label style="margin:0;"><input type="checkbox" name="maintenance_mode" <?= ($settings['maintenance_mode'] ?? '0') === '1' ? 'checked' : '' ?> style="width:auto;margin-right:6px;"> Enable Maintenance Mode</label>
    </div>
    <div style="grid-column:1 / -1;"><label>Announcement Message</label><textarea name="announcement_message" rows="2"><?= h($settings['announcement_message'] ?? '') ?></textarea></div>
    <div><button type="submit" class="btn">Save Settings</button></div>
  </form>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
