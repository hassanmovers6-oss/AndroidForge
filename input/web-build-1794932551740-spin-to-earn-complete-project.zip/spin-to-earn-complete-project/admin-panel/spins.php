<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $mode = $_POST['mode'] ?? '';
    if ($mode === 'global') {
        $enabled = isset($_POST['spins_enabled']) ? '1' : '0';
        $limit = max(1, min(50, (int)($_POST['daily_spin_limit'] ?? 5)));
        $pdo->prepare('UPDATE app_settings SET setting_value = ? WHERE setting_key = "spins_enabled"')->execute([$enabled]);
        $pdo->prepare('UPDATE app_settings SET setting_value = ? WHERE setting_key = "daily_spin_limit"')->execute([(string)$limit]);
        Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'spin_settings_updated', 'app_settings', null, ['enabled' => $enabled, 'limit' => $limit]);
        $_SESSION['flash_success'] = 'Global spin settings saved.';
    } elseif ($mode === 'slices') {
        $ids = $_POST['slice_id'] ?? [];
        $totalProb = 0.0;
        foreach ($ids as $idx => $sid) {
            $pts = (int)($_POST['points_value'][$idx] ?? 50);
            $prob = (float)($_POST['probability_weight'][$idx] ?? 0);
            if ($pts <= 0 || $pts >= 500) {
                $_SESSION['flash_error'] = 'All spin values must be strictly between 1 and 499 non-cash points.';
                header('Location: spins.php');
                exit;
            }
            $totalProb += $prob;
        }
        if (abs($totalProb - 100.0) > 0.5) {
            $_SESSION['flash_error'] = 'Probability weights must total 100%.';
            header('Location: spins.php');
            exit;
        }
        $upd = $pdo->prepare('UPDATE spin_reward_settings SET label = ?, points_value = ?, probability_weight = ?, is_active = ? WHERE id = ?');
        foreach ($ids as $idx => $sid) {
            $pts = (int)$_POST['points_value'][$idx];
            $prob = (float)$_POST['probability_weight'][$idx];
            $active = isset($_POST['is_active'][$sid]) ? 1 : 0;
            $upd->execute(["{$pts} pts", $pts, $prob, $active, (int)$sid]);
        }
        Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'spin_slices_updated');
        $_SESSION['flash_success'] = 'Spin wheel values and probabilities updated.';
    }
    header('Location: spins.php');
    exit;
}

$spinsEnabled = Security::getSetting($pdo, 'spins_enabled', '1') === '1';
$dailyLimit = (int)Security::getSetting($pdo, 'daily_spin_limit', '5');
$slices = $pdo->query('SELECT * FROM spin_reward_settings ORDER BY slice_index ASC')->fetchAll();
$suspicious = $pdo->query(
    'SELECT sh.*, u.email FROM spin_history sh INNER JOIN users u ON u.id = sh.user_id
     WHERE sh.flagged_suspicious = 1 ORDER BY sh.id DESC LIMIT 20'
)->fetchAll();

$pageTitle = 'Spin Management';
$activeNav = 'spins';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <h2 style="margin:0 0 14px;font-size:15px;">Global Spin Rules</h2>
  <form method="post" class="form-grid" style="align-items:end;">
    <?= csrf_field() ?>
    <input type="hidden" name="mode" value="global">
    <div>
      <label><input type="checkbox" name="spins_enabled" <?= $spinsEnabled ? 'checked' : '' ?> style="width:auto;margin-right:6px;"> Enable Spin Wheel</label>
    </div>
    <div>
      <label for="daily_spin_limit">Daily Free Spins Limit (Server UTC)</label>
      <input id="daily_spin_limit" name="daily_spin_limit" type="number" min="1" max="50" value="<?= $dailyLimit ?>">
    </div>
    <div><button type="submit" class="btn">Save Spin Rules</button></div>
  </form>
</div>

<div class="card">
  <h2 style="margin:0 0 14px;font-size:15px;">Reward Slices (&lt; 500 Non-Cash Points Only)</h2>
  <form method="post" class="table-wrap">
    <?= csrf_field() ?>
    <input type="hidden" name="mode" value="slices">
    <table>
      <thead><tr><th>Slice</th><th>Points (&lt; 500)</th><th>Probability %</th><th>Active</th></tr></thead>
      <tbody>
        <?php foreach ($slices as $i => $s): ?>
        <tr>
          <td>#<?= (int)$s['slice_index'] ?><input type="hidden" name="slice_id[<?= $i ?>]" value="<?= (int)$s['id'] ?>"></td>
          <td><input type="number" name="points_value[<?= $i ?>]" min="1" max="499" value="<?= (int)$s['points_value'] ?>"></td>
          <td><input type="number" step="0.01" name="probability_weight[<?= $i ?>]" min="0" max="100" value="<?= h($s['probability_weight']) ?>"></td>
          <td><input type="checkbox" name="is_active[<?= (int)$s['id'] ?>]" <?= (int)$s['is_active'] === 1 ? 'checked' : '' ?> style="width:auto;"></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div style="margin-top:14px;"><button type="submit" class="btn">Save Wheel Probabilities</button></div>
  </form>
</div>

<div class="card table-wrap">
  <h2 style="margin:0 0 10px;font-size:15px;">Suspicious Spin Activity</h2>
  <table>
    <thead><tr><th>User</th><th>Points</th><th>IP</th><th>Date</th></tr></thead>
    <tbody>
      <?php if (empty($suspicious)): ?>
        <tr><td colspan="4" style="color:#64748b;">No suspicious rapid-spin activity detected.</td></tr>
      <?php else: foreach ($suspicious as $row): ?>
        <tr><td><?= h($row['email']) ?></td><td><?= (int)$row['points_awarded'] ?></td><td><?= h($row['ip_address']) ?></td><td><?= h($row['created_at']) ?></td></tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
