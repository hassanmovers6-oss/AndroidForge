<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

$logs = $pdo->query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 120')->fetchAll();
$pageTitle = 'Security Audit Logs';
$activeNav = 'audit';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card table-wrap">
  <table>
    <thead><tr><th>ID</th><th>Actor</th><th>Action</th><th>Target</th><th>IP</th><th>Timestamp (UTC)</th></tr></thead>
    <tbody>
      <?php foreach ($logs as $l): ?>
      <tr>
        <td>#<?= (int)$l['id'] ?></td>
        <td><?= h($l['actor_type']) ?> #<?= (int)$l['actor_id'] ?></td>
        <td><?= h($l['action']) ?></td>
        <td><?= h($l['target_type']) ?> <?= $l['target_id'] ? '#' . (int)$l['target_id'] : '' ?></td>
        <td><?= h($l['ip_address']) ?></td>
        <td><?= h($l['created_at']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
