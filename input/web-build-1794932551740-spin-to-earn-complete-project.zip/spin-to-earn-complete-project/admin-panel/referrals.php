<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $enabled = isset($_POST['referral_program_enabled']) ? '1' : '0';
    $reward = number_format(max(0, (float)($_POST['referral_cash_reward_pkr'] ?? 25)), 2, '.', '');
    $reqTask = isset($_POST['referral_requires_approved_task']) ? '1' : '0';

    $upd = $pdo->prepare('UPDATE app_settings SET setting_value = ? WHERE setting_key = ?');
    $upd->execute([$enabled, 'referral_program_enabled']);
    $upd->execute([$reward, 'referral_cash_reward_pkr']);
    $upd->execute([$reqTask, 'referral_requires_approved_task']);
    Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], 'referral_rules_updated');
    $_SESSION['flash_success'] = 'Referral program rules updated.';
    header('Location: referrals.php');
    exit;
}

$refs = $pdo->query(
    'SELECT r.*, u1.email AS referrer_email, u2.email AS referred_email, u2.signup_ip
     FROM referrals r
     INNER JOIN users u1 ON u1.id = r.referrer_user_id
     INNER JOIN users u2 ON u2.id = r.referred_user_id
     ORDER BY r.id DESC LIMIT 60'
)->fetchAll();

$pageTitle = 'Referral Management';
$activeNav = 'referrals';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <h2 style="margin:0 0 12px;font-size:15px;">Referral Program Rules (Separate from Ad Views &amp; Spin Points)</h2>
  <form method="post" class="form-grid" style="align-items:end;">
    <?= csrf_field() ?>
    <div><label><input type="checkbox" name="referral_program_enabled" <?= Security::getSetting($pdo, 'referral_program_enabled', '1') === '1' ? 'checked' : '' ?> style="width:auto;margin-right:6px;"> Program Enabled</label></div>
    <div><label>Cash Program Reward (PKR)</label><input name="referral_cash_reward_pkr" type="number" step="0.01" min="0" value="<?= h(Security::getSetting($pdo, 'referral_cash_reward_pkr', '25.00')) ?>"></div>
    <div><label><input type="checkbox" name="referral_requires_approved_task" <?= Security::getSetting($pdo, 'referral_requires_approved_task', '1') === '1' ? 'checked' : '' ?> style="width:auto;margin-right:6px;"> Require 1st Approved Task</label></div>
    <div><button type="submit" class="btn">Save Referral Rules</button></div>
  </form>
</div>
<div class="card table-wrap">
  <h2 style="margin:0 0 12px;font-size:15px;">Referral Tracking &amp; Fraud Detection</h2>
  <table>
    <thead><tr><th>Referrer</th><th>Referred User</th><th>Status</th><th>Fraud / Notes</th><th>Date</th></tr></thead>
    <tbody>
      <?php foreach ($refs as $r): ?>
      <tr>
        <td><?= h($r['referrer_email']) ?></td>
        <td><?= h($r['referred_email']) ?> (<?= h($r['signup_ip']) ?>)</td>
        <td><?= h($r['status']) ?></td>
        <td><?= h($r['fraud_reason'] ?: 'Verified distinct') ?></td>
        <td><?= h($r['created_at']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
