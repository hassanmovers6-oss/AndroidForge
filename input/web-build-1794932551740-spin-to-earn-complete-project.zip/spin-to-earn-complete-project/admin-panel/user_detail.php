<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

$uid = (int)($_GET['id'] ?? 0);
$uStmt = $pdo->prepare(
    'SELECT u.*, p.points_balance, p.lifetime_points_earned,
            w.available_balance_pkr, w.pending_withdrawal_pkr, w.approved_task_earnings_pkr, w.total_withdrawn_pkr
     FROM users u
     LEFT JOIN user_non_cash_points p ON p.user_id = u.id
     LEFT JOIN cash_wallets w ON w.user_id = u.id
     WHERE u.id = ? LIMIT 1'
);
$uStmt->execute([$uid]);
$user = $uStmt->fetch();
if (!$user) {
    $_SESSION['flash_error'] = 'User not found.';
    header('Location: users.php');
    exit;
}

$spins = $pdo->prepare('SELECT sh.*, srs.label FROM spin_history sh INNER JOIN spin_reward_settings srs ON srs.id = sh.slice_id WHERE sh.user_id = ? ORDER BY sh.id DESC LIMIT 30');
$spins->execute([$uid]);

$tasks = $pdo->prepare('SELECT ts.*, t.title FROM task_submissions ts INNER JOIN tasks t ON t.id = ts.task_id WHERE ts.user_id = ? ORDER BY ts.id DESC LIMIT 30');
$tasks->execute([$uid]);

$txs = $pdo->prepare('SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 30');
$txs->execute([$uid]);

$pageTitle = 'User Profile #' . $uid;
$activeNav = 'users';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <h2 style="margin:0 0 10px;font-size:16px;"><?= h($user['full_name']) ?> (<?= h($user['email']) ?>)</h2>
  <p style="color:#64748b;margin:0 0 12px;">Status: <strong><?= h($user['status']) ?></strong> · Referral Code: <strong><?= h($user['referral_code']) ?></strong> · Signup IP: <?= h($user['signup_ip']) ?></p>
  <div class="kpi-grid" style="margin-bottom:0;">
    <div><div class="kpi-label">Non-Cash Points</div><div class="kpi-value"><?= number_format((int)$user['points_balance']) ?></div></div>
    <div><div class="kpi-label">Available Cash</div><div class="kpi-value">Rs. <?= number_format((float)$user['available_balance_pkr'], 2) ?></div></div>
    <div><div class="kpi-label">Approved Tasks</div><div class="kpi-value">Rs. <?= number_format((float)$user['approved_task_earnings_pkr'], 2) ?></div></div>
    <div><div class="kpi-label">Withdrawn</div><div class="kpi-value">Rs. <?= number_format((float)$user['total_withdrawn_pkr'], 2) ?></div></div>
  </div>
</div>

<div class="card table-wrap">
  <h3 style="margin:0 0 10px;font-size:14px;">Recent Spin History</h3>
  <table>
    <thead><tr><th>Date (UTC)</th><th>Slice</th><th>Points</th><th>Flagged</th></tr></thead>
    <tbody>
      <?php foreach ($spins->fetchAll() as $s): ?>
      <tr><td><?= h($s['created_at']) ?></td><td><?= h($s['label']) ?></td><td>+<?= (int)$s['points_awarded'] ?></td><td><?= (int)$s['flagged_suspicious'] === 1 ? 'Suspicious' : 'Clean' ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card table-wrap">
  <h3 style="margin:0 0 10px;font-size:14px;">Task Submissions</h3>
  <table>
    <thead><tr><th>Task</th><th>Reward</th><th>Status</th><th>Submitted</th></tr></thead>
    <tbody>
      <?php foreach ($tasks->fetchAll() as $t): ?>
      <tr><td><?= h($t['title']) ?></td><td>Rs. <?= number_format((float)$t['reward_snapshot_pkr'], 2) ?></td><td><?= h($t['status']) ?></td><td><?= h($t['created_at']) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card table-wrap">
  <h3 style="margin:0 0 10px;font-size:14px;">Cash Wallet Transactions</h3>
  <table>
    <thead><tr><th>Reference</th><th>Type</th><th>Amount</th><th>Balance After</th><th>Date</th></tr></thead>
    <tbody>
      <?php foreach ($txs->fetchAll() as $tx): ?>
      <tr><td><?= h($tx['reference_id']) ?></td><td><?= h($tx['tx_type']) ?></td><td>Rs. <?= number_format((float)$tx['amount_pkr'], 2) ?></td><td>Rs. <?= number_format((float)$tx['balance_after_pkr'], 2) ?></td><td><?= h($tx['created_at']) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
