<?php
/**
 * SpinReward Pro — Admin Dashboard
 * File: admin-panel/index.php
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Dashboard Overview';
$activeNav = 'dashboard';

$stats = [
    'total_users'           => (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status != 'deleted'")->fetchColumn(),
    'active_users'          => (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn(),
    'total_spins'           => (int)$pdo->query('SELECT COUNT(*) FROM spin_history')->fetchColumn(),
    'total_non_cash_pts'    => (int)$pdo->query('SELECT COALESCE(SUM(lifetime_points_earned),0) FROM user_non_cash_points')->fetchColumn(),
    'task_submissions'      => (int)$pdo->query('SELECT COUNT(*) FROM task_submissions')->fetchColumn(),
    'approved_tasks'        => (int)$pdo->query("SELECT COUNT(*) FROM task_submissions WHERE status = 'approved'")->fetchColumn(),
    'pending_withdrawals'   => (float)$pdo->query("SELECT COALESCE(SUM(amount_pkr),0) FROM withdrawal_requests WHERE status IN ('pending','approved')")->fetchColumn(),
    'paid_withdrawals'      => (float)$pdo->query("SELECT COALESCE(SUM(amount_pkr),0) FROM withdrawal_requests WHERE status = 'paid'")->fetchColumn(),
    'total_referrals'       => (int)$pdo->query('SELECT COUNT(*) FROM referrals')->fetchColumn(),
    'approved_referrals'    => (int)$pdo->query("SELECT COUNT(*) FROM referrals WHERE status = 'approved'")->fetchColumn(),
];

$ads = $pdo->query('SELECT ad_format, is_enabled, test_mode FROM advertisements_settings ORDER BY id ASC')->fetchAll();

require __DIR__ . '/includes/layout_top.php';
?>
<div class="kpi-grid">
  <div class="card"><div class="kpi-label">Total / Active Users</div><div class="kpi-value"><?= $stats['total_users'] ?> / <?= $stats['active_users'] ?></div></div>
  <div class="card"><div class="kpi-label">Total Spins Executed</div><div class="kpi-value"><?= number_format($stats['total_spins']) ?></div></div>
  <div class="card"><div class="kpi-label">Non-Cash Points Awarded</div><div class="kpi-value"><?= number_format($stats['total_non_cash_pts']) ?> pts</div></div>
  <div class="card"><div class="kpi-label">Task Submissions / Approved</div><div class="kpi-value"><?= $stats['task_submissions'] ?> / <?= $stats['approved_tasks'] ?></div></div>
  <div class="card"><div class="kpi-label">Pending Withdrawals</div><div class="kpi-value">Rs. <?= number_format($stats['pending_withdrawals'], 2) ?></div></div>
  <div class="card"><div class="kpi-label">Paid Withdrawals</div><div class="kpi-value">Rs. <?= number_format($stats['paid_withdrawals'], 2) ?></div></div>
  <div class="card"><div class="kpi-label">Referrals (Total / Approved)</div><div class="kpi-value"><?= $stats['total_referrals'] ?> / <?= $stats['approved_referrals'] ?></div></div>
</div>

<div class="card">
  <h2 style="margin:0 0 12px;font-size:15px;">AdMob 6-Format Status</h2>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Format</th><th>Enabled</th><th>Mode</th></tr></thead>
      <tbody>
        <?php foreach ($ads as $ad): ?>
        <tr>
          <td><?= h($ad['ad_format']) ?></td>
          <td><?= (int)$ad['is_enabled'] === 1 ? 'Enabled' : 'Disabled' ?></td>
          <td><?= (int)$ad['test_mode'] === 1 ? 'Google Test Mode' : 'Production Mode' ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
