<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

if (!empty($_SESSION['admin_id'])) {
    $pdo = Database::getConnection();
    Security::writeAuditLog($pdo, 'admin', (int)$_SESSION['admin_id'], 'admin_logout');
}
$_SESSION = [];
session_destroy();
header('Location: login.php');
exit;
