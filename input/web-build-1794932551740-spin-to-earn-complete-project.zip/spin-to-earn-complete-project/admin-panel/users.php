<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $uid = (int)($_POST['user_id'] ?? 0);
    $newStatus = ($_POST['action'] ?? '') === 'suspend' ? 'suspended' : 'active';
    if ($uid > 0) {
        $pdo->prepare('UPDATE users SET status = ? WHERE id = ? AND status != "deleted"')->execute([$newStatus, $uid]);
        if ($newStatus === 'suspended') {
            $pdo->prepare('UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP() WHERE user_id = ?')->execute([$uid]);
        }
        Security::writeAuditLog($pdo, 'admin', (int)$currentAdmin['id'], "user_{$newStatus}", 'user', $uid);
        $_SESSION['flash_success'] = "User #{$uid} updated to {$newStatus}.";
    }
    header('Location: users.php');
    exit;
}

$q = trim((string)($_GET['q'] ?? ''));
$sql = 'SELECT u.id, u.full_name, u.email, u.referral_code, u.status, u.created_at,
               COALESCE(p.points_balance, 0) AS points_balance,
               COALESCE(w.available_balance_pkr, 0) AS cash_balance
        FROM users u
        LEFT JOIN user_non_cash_points p ON p.user_id = u.id
        LEFT JOIN cash_wallets w ON w.user_id = u.id';
$params = [];
if ($q !== '') {
    $sql .= ' WHERE u.full_name LIKE ? OR u.email LIKE ? OR u.referral_code LIKE ?';
    $like = "%{$q}%";
    $params = [$like, $like, $like];
}
$sql .= ' ORDER BY u.id DESC LIMIT 100';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'User Management';
$activeNav = 'users';
require __DIR__ . '/includes/layout_top.php';
?>
<div class="card">
  <form method="get" style="display:flex;gap:10px;max-width:460px;">
    <input name="q" value="<?= h($q) ?>" placeholder="Search by name, email, or referral code">
    <button type="submit" class="btn">Search</button>
  </form>
</div>
<div class="card table-wrap">
  <table>
    <thead><tr><th>ID</th><th>User</th><th>Referral</th><th>Non-Cash Pts</th><th>Cash Balance</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ($users as $u): ?>
      <tr>
        <td>#<?= (int)$u['id'] ?></td>
        <td><strong><?= h($u['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= h($u['email']) ?></span></td>
        <td><?= h($u['referral_code']) ?></td>
        <td><?= number_format((int)$u['points_balance']) ?> pts</td>
        <td>Rs. <?= number_format((float)$u['cash_balance'], 2) ?></td>
        <td><?= h($u['status']) ?></td>
        <td style="display:flex;gap:6px;">
          <a href="user_detail.php?id=<?= (int)$u['id'] ?>" class="btn btn-sm">Inspect</a>
          <?php if ($u['status'] !== 'deleted'): ?>
          <form method="post" onsubmit="return confirmAction('Update account status?')">
            <?= csrf_field() ?>
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <input type="hidden" name="action" value="<?= $u['status'] === 'active' ? 'suspend' : 'activate' ?>">
            <button type="submit" class="btn btn-sm <?= $u['status'] === 'active' ? 'btn-red' : 'btn-green' ?>">
              <?= $u['status'] === 'active' ? 'Suspend' : 'Activate' ?>
            </button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/includes/layout_bottom.php'; ?>
