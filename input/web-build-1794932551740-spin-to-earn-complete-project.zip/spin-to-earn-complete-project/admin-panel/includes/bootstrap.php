<?php
/**
 * SpinReward Pro — Admin Session Bootstrap
 * File: admin-panel/includes/bootstrap.php
 */

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Strict');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }
    session_name('SPINREWARD_ADMIN_SESS');
    session_start();
}

require_once __DIR__ . '/../../backend-api/database.php';
require_once __DIR__ . '/../../backend-api/helpers/Security.php';

function h(string|int|float|null $val): string
{
    return htmlspecialchars((string)$val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
