-- ============================================================================
-- SpinReward Pro — Complete MySQL 8.0+ Database Schema
-- File: database/spin_to_earn.sql
-- Architecture: Strict separation of Non-Cash Spin/Ad Points & Genuine Cash Wallet
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `spin_to_earn`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `spin_to_earn`;

SET SQL_MODE = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
SET time_zone = '+00:00';

-- ----------------------------------------------------------------------------
-- 1. admins
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(60) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(120) NOT NULL,
  `role` ENUM('super_admin', 'moderator', 'finance') NOT NULL DEFAULT 'super_admin',
  `status` ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  `last_login_at` TIMESTAMP NULL DEFAULT NULL,
  `last_login_ip` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admins_username` (`username`),
  UNIQUE KEY `uq_admins_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. users
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `phone` VARCHAR(30) NULL DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `referral_code` VARCHAR(20) NOT NULL,
  `referred_by_user_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `device_fingerprint` VARCHAR(128) NULL DEFAULT NULL,
  `signup_ip` VARCHAR(45) NULL DEFAULT NULL,
  `last_checkin_date` DATE NULL DEFAULT NULL,
  `checkin_streak` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active', 'suspended', 'deleted') NOT NULL DEFAULT 'active',
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_referral_code` (`referral_code`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_referred_by` (`referred_by_user_id`),
  KEY `idx_users_device_fp` (`device_fingerprint`),
  CONSTRAINT `fk_users_referred_by`
    FOREIGN KEY (`referred_by_user_id`) REFERENCES `users` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. user_sessions (Token-based Android API auth)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `device_id` VARCHAR(128) NULL DEFAULT NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `user_agent` VARCHAR(255) NULL DEFAULT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `revoked_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_sessions_token_hash` (`token_hash`),
  KEY `idx_user_sessions_user_id` (`user_id`),
  KEY `idx_user_sessions_expires_at` (`expires_at`),
  CONSTRAINT `fk_user_sessions_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. spin_reward_settings (All values strictly < 500 non-cash points)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `spin_reward_settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slice_index` TINYINT UNSIGNED NOT NULL,
  `label` VARCHAR(40) NOT NULL,
  `points_value` INT UNSIGNED NOT NULL,
  `probability_weight` DECIMAL(5,2) NOT NULL,
  `slice_color` VARCHAR(16) NOT NULL DEFAULT '#1E40AF',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spin_slice_index` (`slice_index`),
  CONSTRAINT `chk_spin_points_under_500` CHECK (`points_value` > 0 AND `points_value` < 500)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. user_non_cash_points (Strict separation from cash_wallets)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_non_cash_points` (
  `user_id` BIGINT UNSIGNED NOT NULL,
  `points_balance` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `lifetime_points_earned` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `lifetime_points_spent` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_non_cash_points_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. spin_history
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `spin_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `spin_date_utc` DATE NOT NULL,
  `slice_id` INT UNSIGNED NOT NULL,
  `points_awarded` INT UNSIGNED NOT NULL,
  `idempotency_key` VARCHAR(80) NOT NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `device_id` VARCHAR(128) NULL DEFAULT NULL,
  `flagged_suspicious` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spin_idempotency` (`idempotency_key`),
  KEY `idx_spin_user_date` (`user_id`, `spin_date_utc`),
  KEY `idx_spin_created_at` (`created_at`),
  CONSTRAINT `fk_spin_history_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_spin_history_slice`
    FOREIGN KEY (`slice_id`) REFERENCES `spin_reward_settings` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. non_cash_reward_history (Spins, Watch Video & Earn, Check-ins, Perks)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `non_cash_reward_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `source_type` ENUM('spin_wheel', 'rewarded_ad', 'daily_checkin', 'perk_redemption', 'admin_adjustment') NOT NULL,
  `points_delta` BIGINT NOT NULL,
  `balance_after` BIGINT UNSIGNED NOT NULL,
  `reference_id` VARCHAR(80) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `ad_network_tx_id` VARCHAR(120) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ncrh_reference` (`reference_id`),
  UNIQUE KEY `uq_ncrh_ad_tx` (`ad_network_tx_id`),
  KEY `idx_ncrh_user_created` (`user_id`, `created_at`),
  CONSTRAINT `fk_ncrh_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. advertisements_settings (All 6 AdMob formats)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `advertisements_settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ad_format` ENUM('banner', 'interstitial', 'native', 'rewarded', 'rewarded_interstitial', 'app_open') NOT NULL,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `test_mode` TINYINT(1) NOT NULL DEFAULT 1,
  `test_ad_unit_id` VARCHAR(120) NOT NULL,
  `prod_ad_unit_id` VARCHAR(120) NOT NULL DEFAULT '',
  `placement_notes` VARCHAR(255) NOT NULL,
  `frequency_cap_per_hour` INT UNSIGNED NOT NULL DEFAULT 6,
  `cooldown_seconds` INT UNSIGNED NOT NULL DEFAULT 45,
  `rewarded_points` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ad_format` (`ad_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. tasks (Genuine cash-earning activities only)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(160) NOT NULL,
  `category` ENUM('survey', 'data_entry', 'website_testing', 'sponsor_task', 'assignment') NOT NULL,
  `instructions` TEXT NOT NULL,
  `reward_pkr` DECIMAL(10,2) NOT NULL,
  `requires_proof` TINYINT(1) NOT NULL DEFAULT 1,
  `proof_placeholder` VARCHAR(255) NOT NULL DEFAULT 'Provide screenshot link or confirmation code',
  `max_completions_per_user` INT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('active', 'paused', 'archived') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_status` (`status`),
  CONSTRAINT `chk_tasks_reward_positive` CHECK (`reward_pkr` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. task_submissions
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `task_submissions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `task_id` BIGINT UNSIGNED NOT NULL,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `proof_text` TEXT NULL,
  `proof_file_path` VARCHAR(255) NULL DEFAULT NULL,
  `reward_snapshot_pkr` DECIMAL(10,2) NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `admin_note` VARCHAR(255) NULL DEFAULT NULL,
  `reviewed_by_admin_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `reviewed_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ts_task_user` (`task_id`, `user_id`),
  KEY `idx_ts_status` (`status`),
  KEY `idx_ts_user_created` (`user_id`, `created_at`),
  CONSTRAINT `fk_ts_task`
    FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ts_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ts_admin`
    FOREIGN KEY (`reviewed_by_admin_id`) REFERENCES `admins` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. cash_wallets (PKR balance ONLY from approved tasks & legitimate referrals)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cash_wallets` (
  `user_id` BIGINT UNSIGNED NOT NULL,
  `available_balance_pkr` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `pending_withdrawal_pkr` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `approved_task_earnings_pkr` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `referral_cash_earnings_pkr` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total_withdrawn_pkr` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_cash_wallet_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_wallet_non_negative` CHECK (
    `available_balance_pkr` >= 0.00 AND
    `pending_withdrawal_pkr` >= 0.00 AND
    `total_withdrawn_pkr` >= 0.00
  )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. wallet_transactions
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `reference_id` VARCHAR(64) NOT NULL,
  `tx_type` ENUM('task_credit', 'referral_credit', 'withdrawal_hold', 'withdrawal_paid', 'withdrawal_refund', 'admin_adjustment') NOT NULL,
  `amount_pkr` DECIMAL(12,2) NOT NULL,
  `balance_after_pkr` DECIMAL(12,2) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `related_entity_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wt_reference_id` (`reference_id`),
  KEY `idx_wt_user_created` (`user_id`, `created_at`),
  CONSTRAINT `fk_wt_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. withdrawal_requests
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `withdrawal_requests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `reference_id` VARCHAR(64) NOT NULL,
  `payment_method` ENUM('JazzCash', 'Easypaisa') NOT NULL,
  `account_holder_name` VARCHAR(120) NOT NULL,
  `account_number` VARCHAR(40) NOT NULL,
  `amount_pkr` DECIMAL(12,2) NOT NULL,
  `status` ENUM('pending', 'approved', 'paid', 'rejected') NOT NULL DEFAULT 'pending',
  `payment_reference` VARCHAR(120) NULL DEFAULT NULL,
  `admin_note` VARCHAR(255) NULL DEFAULT NULL,
  `fraud_flag` TINYINT(1) NOT NULL DEFAULT 0,
  `idempotency_key` VARCHAR(80) NOT NULL,
  `processed_by_admin_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `processed_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wr_reference_id` (`reference_id`),
  UNIQUE KEY `uq_wr_idempotency` (`idempotency_key`),
  KEY `idx_wr_user_status` (`user_id`, `status`),
  KEY `idx_wr_status_created` (`status`, `created_at`),
  CONSTRAINT `fk_wr_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wr_admin`
    FOREIGN KEY (`processed_by_admin_id`) REFERENCES `admins` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. referrals
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `referrals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `referrer_user_id` BIGINT UNSIGNED NOT NULL,
  `referred_user_id` BIGINT UNSIGNED NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `fraud_reason` VARCHAR(190) NULL DEFAULT NULL,
  `approved_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_referrals_referred_user` (`referred_user_id`),
  KEY `idx_referrals_referrer_status` (`referrer_user_id`, `status`),
  CONSTRAINT `fk_ref_referrer`
    FOREIGN KEY (`referrer_user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ref_referred`
    FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 15. referral_rewards
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `referral_rewards` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `referral_id` BIGINT UNSIGNED NOT NULL,
  `referrer_user_id` BIGINT UNSIGNED NOT NULL,
  `reward_type` ENUM('cash_program', 'non_cash_bonus') NOT NULL DEFAULT 'cash_program',
  `amount_pkr` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `non_cash_points` INT UNSIGNED NOT NULL DEFAULT 0,
  `reference_id` VARCHAR(64) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rr_reference` (`reference_id`),
  KEY `idx_rr_referral` (`referral_id`),
  CONSTRAINT `fk_rr_referral`
    FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rr_user`
    FOREIGN KEY (`referrer_user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 16. notifications
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `title` VARCHAR(140) NOT NULL,
  `message` TEXT NOT NULL,
  `category` ENUM('system', 'wallet', 'task', 'spin', 'referral') NOT NULL DEFAULT 'system',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notif_user_read` (`user_id`, `is_read`),
  CONSTRAINT `fk_notif_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 17. app_settings
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `app_settings` (
  `setting_key` VARCHAR(80) NOT NULL,
  `setting_value` TEXT NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 18. audit_logs
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `actor_type` ENUM('admin', 'user', 'system') NOT NULL,
  `actor_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `action` VARCHAR(120) NOT NULL,
  `target_type` VARCHAR(80) NULL DEFAULT NULL,
  `target_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `details_json` JSON NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_actor` (`actor_type`, `actor_id`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- INITIAL SEED DATA (Safe configuration defaults; run setup.php for Admin)
-- ============================================================================

INSERT INTO `spin_reward_settings` (`slice_index`, `label`, `points_value`, `probability_weight`, `slice_color`, `is_active`) VALUES
(1, '50 pts',  50,  25.00, '#1D4ED8', 1),
(2, '100 pts', 100, 20.00, '#0F766E', 1),
(3, '150 pts', 150, 15.00, '#B45309', 1),
(4, '200 pts', 200, 12.00, '#7C3AED', 1),
(5, '250 pts', 250, 10.00, '#0369A1', 1),
(6, '300 pts', 300,  7.00, '#BE185D', 1),
(7, '350 pts', 350,  5.00, '#15803D', 1),
(8, '400 pts', 400,  4.00, '#C2410C', 1),
(9, '450 pts', 450,  2.00, '#4338CA', 1)
ON DUPLICATE KEY UPDATE `label` = VALUES(`label`);

-- Configured Google Mobile Ads Unit IDs (Test IDs retained in test_ad_unit_id for reference)
INSERT INTO `advertisements_settings` (`ad_format`, `is_enabled`, `test_mode`, `test_ad_unit_id`, `prod_ad_unit_id`, `placement_notes`, `frequency_cap_per_hour`, `cooldown_seconds`, `rewarded_points`) VALUES
('banner',                1, 0, 'ca-app-pub-3940256099942544/6300978111', 'ca-app-pub-3133971041724338/8119772283', 'Bottom reserved container on Home, Spin, Wallet, Referral, Profile (never near Submit buttons)', 0, 0, 0),
('interstitial',          1, 0, 'ca-app-pub-3940256099942544/1033173712', 'ca-app-pub-3133971041724338/2404411178', 'Immediately after every spin (5 spins = 5 interstitial ads) and natural transitions', 0, 0, 0),
('native',                1, 0, 'ca-app-pub-3940256099942544/2247696110', 'ca-app-pub-3133971041724338/2686327254', 'Clearly labelled Sponsored / Ad card on Home & Referral feeds', 0, 0, 0),
('rewarded',              1, 0, 'ca-app-pub-3940256099942544/5224354917', 'ca-app-pub-3133971041724338/6186588562', 'Optional non-cash bonus points reward (Rewards & Perks screen)', 6, 30, 75),
('rewarded_interstitial', 0, 0, 'ca-app-pub-3940256099942544/5354046379', '', 'Disabled (no separate unit configured)', 2, 180, 120),
('app_open',              1, 0, 'ca-app-pub-3940256099942544/9257395921', 'ca-app-pub-3133971041724338/6162537838', 'App launch / foreground resume with cooldown enforcement', 2, 300, 0)
ON DUPLICATE KEY UPDATE
  `is_enabled` = VALUES(`is_enabled`),
  `test_mode` = VALUES(`test_mode`),
  `prod_ad_unit_id` = VALUES(`prod_ad_unit_id`),
  `placement_notes` = VALUES(`placement_notes`),
  `frequency_cap_per_hour` = VALUES(`frequency_cap_per_hour`),
  `cooldown_seconds` = VALUES(`cooldown_seconds`);

INSERT INTO `app_settings` (`setting_key`, `setting_value`) VALUES
('app_name', 'SpinReward Pro'),
('app_logo_url', 'https://your-domain.example.com/assets/logo.png'),
('support_email', 'support@your-domain.example.com'),
('daily_spin_limit', '5'),
('spins_enabled', '1'),
('minimum_withdrawal_pkr', '100'),
('payment_methods', 'JazzCash,Easypaisa'),
('privacy_policy_url', 'https://your-domain.example.com/privacy-policy'),
('terms_url', 'https://your-domain.example.com/terms'),
('maintenance_mode', '0'),
('app_version', '1.0.0'),
('announcement_message', 'Welcome! Complete verified tasks to earn cash rewards. Spin points are non-cash in-app perks only.'),
('referral_cash_reward_pkr', '25.00'),
('referral_program_enabled', '1'),
('referral_requires_approved_task', '1'),
('daily_checkin_points', '40'),
('server_timezone', 'UTC')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

INSERT INTO `tasks` (`title`, `category`, `instructions`, `reward_pkr`, `requires_proof`, `proof_placeholder`, `max_completions_per_user`, `status`) VALUES
('Consumer Mobile Banking Usability Survey', 'survey', 'Complete the 12-question digital wallet survey accurately and submit your completion reference code.', 65.00, 1, 'Enter survey completion code (e.g., SRV-8842)', 1, 'active'),
('E-Commerce Product Category Tagging Batch', 'data_entry', 'Verify 15 product titles against their assigned categories and submit the batch confirmation hash.', 85.00, 1, 'Paste batch verification ID or screenshot URL', 2, 'active'),
('Retail Checkout Accessibility QA Audit', 'website_testing', 'Test the mobile checkout flow on staging, record any layout defects, and submit your QA summary.', 120.00, 1, 'Enter QA report summary and reference link', 1, 'active'),
('Sponsor App Onboarding Feedback Review', 'sponsor_task', 'Review the sponsor product guide and provide 3 concrete onboarding improvement notes.', 55.00, 1, 'Write 3 actionable feedback notes', 1, 'active');
