<?php
/**
 * SpinReward Pro — Secure CLI Setup & Verification Script
 * File: backend-api/setup.php
 *
 * Execute ONLY from local Windows XAMPP Shell / PHP CLI:
 *   cd C:\xampp\htdocs\spin-to-earn-complete-project\backend-api
 *   C:\xampp\php\php.exe setup.php
 *
 * Non-destructive: connects to existing `spin_to_earn` database, verifies all
 * required tables without dropping or overwriting data, ensures a 64-char hex
 * application secret exists, and creates the initial super_admin only if none exists.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit("Forbidden: setup.php can only be executed from local PHP CLI.\n");
}

if (PHP_VERSION_ID < 80100) {
    fwrite(STDERR, "[ERROR] PHP 8.1+ required. Detected PHP " . PHP_VERSION . PHP_EOL);
    exit(1);
}

$requiredExtensions = ['pdo_mysql', 'openssl', 'mbstring', 'fileinfo', 'json'];
$missingExtensions = array_filter($requiredExtensions, static fn(string $ext): bool => !extension_loaded($ext));
if (!empty($missingExtensions)) {
    fwrite(STDERR, '[ERROR] Missing required PHP extensions: ' . implode(', ', $missingExtensions) . PHP_EOL);
    exit(1);
}

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers/Security.php';

$config = require __DIR__ . '/config.php';
$rotateSecret = in_array('--rotate-secret', $argv ?? [], true);

echo "=================================================================\n";
echo " SpinReward Pro — Local CLI Setup & Schema Verification (PHP " . PHP_VERSION . ")\n";
echo "=================================================================\n";
echo "Environment : {$config['env']}\n";
echo "Database    : {$config['db']['host']}:{$config['db']['port']} / {$config['db']['name']} ({$config['db']['charset']})\n";
echo "Backend URL : {$config['app']['backend_url']}\n";
echo "Admin URL   : {$config['app']['admin_url']}\n\n";

// 1. Ensure a valid 64-character hexadecimal app_secret exists in backend-api/.app_secret
$secretFile = __DIR__ . DIRECTORY_SEPARATOR . '.app_secret';
if ($rotateSecret || !is_file($secretFile)) {
    $freshSecret = bin2hex(random_bytes(32));
    if (@file_put_contents($secretFile, $freshSecret . PHP_EOL, LOCK_EX) === false) {
        fwrite(STDERR, "[ERROR] Could not write 64-char hex secret to {$secretFile}\n");
        exit(1);
    }
    @chmod($secretFile, 0600);
    echo "[OK] Generated 64-character hex application secret in backend-api/.app_secret\n";
} else {
    $existingSecret = trim((string)file_get_contents($secretFile));
    if (!preg_match('/^[a-f0-9]{64}$/i', $existingSecret)) {
        $freshSecret = bin2hex(random_bytes(32));
        file_put_contents($secretFile, $freshSecret . PHP_EOL, LOCK_EX);
        @chmod($secretFile, 0600);
        echo "[OK] Replaced invalid secret with fresh 64-character hex secret in backend-api/.app_secret\n";
    } else {
        echo "[OK] Valid 64-character hex application secret already present in backend-api/.app_secret\n";
    }
}

// 2. Connect to existing MySQL / MariaDB database (non-destructive)
try {
    $pdo = Database::getConnection();
    $dbVersion = (string)$pdo->query('SELECT VERSION()')->fetchColumn();
    echo "[OK] PDO connected successfully (Server: {$dbVersion})\n";
} catch (Throwable $e) {
    fwrite(STDERR, '[ERROR] ' . $e->getMessage() . PHP_EOL);
    exit(1);
}

// 3. Verify all 18 required tables exist (never drop, create, or delete data)
$requiredTables = [
    'admins',
    'users',
    'user_sessions',
    'spin_reward_settings',
    'user_non_cash_points',
    'spin_history',
    'non_cash_reward_history',
    'advertisements_settings',
    'tasks',
    'task_submissions',
    'cash_wallets',
    'wallet_transactions',
    'withdrawal_requests',
    'referrals',
    'referral_rewards',
    'notifications',
    'app_settings',
    'audit_logs',
];

$existingTables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
$existingMap = array_flip(array_map('strtolower', array_map('strval', $existingTables)));
$missingTables = [];

foreach ($requiredTables as $tbl) {
    if (!isset($existingMap[$tbl])) {
        $missingTables[] = $tbl;
    }
}

if (!empty($missingTables)) {
    fwrite(
        STDERR,
        '[ERROR] Missing required tables in `' . $config['db']['name'] . '`: ' . implode(', ', $missingTables) . PHP_EOL .
        "        Import database/spin_to_earn.sql into phpMyAdmin first, then re-run php setup.php.\n"
    );
    exit(1);
}
echo '[OK] Verified all ' . count($requiredTables) . " required database tables exist (no records altered).\n";

// 4. Ensure upload proof directory exists and blocks PHP execution
$uploadDir = $config['app']['upload_dir'];
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
        fwrite(STDERR, "[ERROR] Unable to create upload directory: {$uploadDir}\n");
        exit(1);
    }
}
$uploadHtaccess = $uploadDir . DIRECTORY_SEPARATOR . '.htaccess';
if (!is_file($uploadHtaccess)) {
    file_put_contents(
        $uploadHtaccess,
        "Require all denied\nOptions -Indexes\n<IfModule mod_php.c>\n  php_flag engine off\n</IfModule>\n"
    );
}
echo "[OK] Proof upload directory verified: {$uploadDir}\n\n";

// 5. Create initial super_admin strictly when admins table is empty
$adminCount = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
if ($adminCount === 0) {
    $defaultUsername = 'admin';
    $defaultEmail    = 'admin@spinreward.local';

    // Generate cryptographically random 16-character password (unambiguous characters)
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*';
    $maxIdx = strlen($alphabet) - 1;
    $initialPassword = '';
    for ($i = 0; $i < 16; $i++) {
        $initialPassword .= $alphabet[random_int(0, $maxIdx)];
    }

    // Use Argon2id when supported by PHP build, otherwise strong Bcrypt on Windows XAMPP
    $hashAlgo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
    $hash = password_hash($initialPassword, $hashAlgo);

    $stmt = $pdo->prepare(
        'INSERT INTO admins (username, email, password_hash, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $defaultUsername,
        $defaultEmail,
        $hash,
        'Primary Administrator',
        'super_admin',
        'active',
    ]);
    $adminId = (int)$pdo->lastInsertId();

    Security::writeAuditLog($pdo, 'system', $adminId, 'initial_super_admin_created_cli', 'admin', $adminId);

    echo "-----------------------------------------------------------------\n";
    echo " INITIAL SUPER ADMIN CREATED (CLI ONLY)\n";
    echo "-----------------------------------------------------------------\n";
    echo " Admin Login URL : {$config['app']['admin_url']}login.php\n";
    echo " Username        : {$defaultUsername}\n";
    echo " Email           : {$defaultEmail}\n";
    echo " Password        : {$initialPassword}\n";
    echo "-----------------------------------------------------------------\n";
    echo " Save this password securely now; it will NOT be shown again.\n";
} else {
    echo "[SKIP] Admins table already initialized ({$adminCount} admin record(s) found).\n";
    echo "       No duplicate admin account was created.\n";
    echo "       Admin Login URL: {$config['app']['admin_url']}login.php\n";
}

echo "\nSetup verification complete.\n";
