<?php
/**
 * SpinReward Pro — Backend Configuration (Local XAMPP & Production Separated)
 * File: backend-api/config.php
 *
 * Local XAMPP defaults connect to 127.0.0.1:3306 (`spin_to_earn`, user `root`, blank password).
 * For live/production hosting, copy `config.production.example.php` to `config.production.php`
 * or set environment variables (`APP_ENV=production`, `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`,
 * `APP_BASE_URL`, `APP_SECRET`, `ADMOB_SSV_VERIFY`).
 */

declare(strict_types=1);

return (static function (): array {
    static $cachedConfig = null;
    if ($cachedConfig !== null) {
        return $cachedConfig;
    }

    $appEnv = strtolower((string)(getenv('APP_ENV') ?: ''));
    $prodOverrideFile = __DIR__ . '/config.production.php';
    $isProduction = ($appEnv === 'production') || ($appEnv === '' && is_file($prodOverrideFile));

    $envPass = getenv('DB_PASS');
    $localPass = ($envPass !== false) ? $envPass : '';

    // Local XAMPP URLs (override via APP_BASE_URL / config.production.php in production)
    $localBaseUrl = rtrim((string)(getenv('APP_BASE_URL') ?: 'http://localhost/spin-to-earn-complete-project'), '/');

    // Load or generate a cryptographically random 64-character hex application secret.
    // Never falls back to an insecure static placeholder.
    $secretFile = __DIR__ . '/.app_secret';
    $appSecret = trim((string)(getenv('APP_SECRET') ?: ''));

    if (!preg_match('/^[a-f0-9]{64}$/i', $appSecret)) {
        if (is_file($secretFile) && is_readable($secretFile)) {
            $fileSecret = trim((string)file_get_contents($secretFile));
            if (preg_match('/^[a-f0-9]{64}$/i', $fileSecret)) {
                $appSecret = $fileSecret;
            }
        }
    }

    if (!preg_match('/^[a-f0-9]{64}$/i', $appSecret)) {
        $appSecret = bin2hex(random_bytes(32));
        if (is_writable(__DIR__)) {
            @file_put_contents($secretFile, $appSecret . PHP_EOL, LOCK_EX);
            @chmod($secretFile, 0600);
        }
    }

    $config = [
        'env' => $isProduction ? 'production' : 'local',
        'db' => [
            'host'    => getenv('DB_HOST') ?: '127.0.0.1',
            'port'    => (int)(getenv('DB_PORT') ?: 3306),
            'name'    => getenv('DB_NAME') ?: 'spin_to_earn',
            'user'    => getenv('DB_USER') ?: 'root',
            'pass'    => $localPass,
            'charset' => 'utf8mb4',
        ],
        'app' => [
            'base_url'         => $localBaseUrl,
            'backend_url'      => $localBaseUrl . '/backend-api/',
            'admin_url'        => $localBaseUrl . '/admin-panel/',
            'timezone'         => 'UTC',
            'token_ttl_days'   => 30,
            'upload_dir'       => __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'proofs',
            'max_upload_bytes' => 5 * 1024 * 1024, // 5 MB
        ],
        'security' => [
            'app_secret'       => $appSecret,
            'rate_limit_dir'   => rtrim(sys_get_temp_dir(), "/\\") . DIRECTORY_SEPARATOR . 'spin_earn_rl',
            'admob_ssv_verify' => filter_var(getenv('ADMOB_SSV_VERIFY') ?: 'false', FILTER_VALIDATE_BOOLEAN),
        ],
    ];

    if ($isProduction && is_file($prodOverrideFile)) {
        $prodConfig = require $prodOverrideFile;
        if (is_array($prodConfig)) {
            $config = array_replace_recursive($config, $prodConfig);
        }
    }

    $cachedConfig = $config;
    return $cachedConfig;
})();
