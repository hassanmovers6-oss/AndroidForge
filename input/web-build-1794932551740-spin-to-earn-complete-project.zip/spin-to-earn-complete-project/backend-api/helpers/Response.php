<?php
/**
 * SpinReward Pro — JSON Response Helper
 * File: backend-api/helpers/Response.php
 */

declare(strict_types=1);

final class Response
{
    public static function json(int $status, bool $success, string $message, array $data = []): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        echo json_encode([
            'success'     => $success,
            'message'     => $message,
            'server_time' => gmdate('c'),
            'data'        => $data,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function readJsonBody(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw === false || trim($raw) === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            self::json(400, false, 'Invalid JSON request payload.');
        }
        return $decoded;
    }
}
