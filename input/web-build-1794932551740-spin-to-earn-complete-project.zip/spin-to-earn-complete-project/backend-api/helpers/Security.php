<?php
/**
 * SpinReward Pro — Security, Token Authentication & Settings Helper
 * File: backend-api/helpers/Security.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/Response.php';

final class Security
{
    public static function clientIp(): string
    {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public static function requireMethod(string $expected): void
    {
        if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== strtoupper($expected)) {
            Response::json(405, false, "Method {$expected} required.");
        }
    }

    public static function getBearerToken(): ?string
    {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if ($header === '' && function_exists('getallheaders')) {
            $headers = getallheaders();
            if (is_array($headers)) {
                foreach ($headers as $k => $v) {
                    if (strcasecmp((string)$k, 'Authorization') === 0) {
                        $header = (string)$v;
                        break;
                    }
                }
            }
        }
        if (preg_match('/^Bearer\s+([A-Za-z0-9\-_.=]+)$/i', trim((string)$header), $m)) {
            return $m[1];
        }
        return null;
    }

    public static function authenticateUser(PDO $pdo): array
    {
        $token = self::getBearerToken();
        if ($token === null) {
            Response::json(401, false, 'Authentication token missing.');
        }

        $tokenHash = hash('sha256', $token);
        $stmt = $pdo->prepare(
            'SELECT u.id, u.full_name, u.email, u.phone, u.referral_code, u.referred_by_user_id,
                    u.device_fingerprint, u.last_checkin_date, u.checkin_streak, u.status, u.created_at,
                    s.id AS session_id
             FROM user_sessions s
             INNER JOIN users u ON u.id = s.user_id
             WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > UTC_TIMESTAMP()
             LIMIT 1'
        );
        $stmt->execute([$tokenHash]);
        $user = $stmt->fetch();

        if (!$user) {
            Response::json(401, false, 'Session expired or invalid token.');
        }
        if ($user['status'] !== 'active') {
            Response::json(403, false, 'Your account is currently ' . $user['status'] . '.');
        }

        // Check maintenance mode
        $maint = self::getSetting($pdo, 'maintenance_mode', '0');
        if ($maint === '1') {
            Response::json(503, false, 'Application is undergoing scheduled maintenance.');
        }

        return $user;
    }

    public static function getSetting(PDO $pdo, string $key, string $default = ''): string
    {
        $stmt = $pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return $val === false ? $default : (string)$val;
    }

    public static function getAllSettings(PDO $pdo): array
    {
        $rows = $pdo->query('SELECT setting_key, setting_value FROM app_settings')->fetchAll();
        $map = [];
        foreach ($rows as $r) {
            $map[$r['setting_key']] = $r['setting_value'];
        }
        return $map;
    }

    public static function generateUniqueRefId(string $prefix = 'TXN'): string
    {
        return strtoupper($prefix) . '-' . gmdate('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(4)));
    }

    public static function generateReferralCode(PDO $pdo): string
    {
        for ($i = 0; $i < 10; $i++) {
            $code = 'SR' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
            $stmt = $pdo->prepare('SELECT 1 FROM users WHERE referral_code = ?');
            $stmt->execute([$code]);
            if (!$stmt->fetchColumn()) {
                return $code;
            }
        }
        return 'SR' . strtoupper(bin2hex(random_bytes(5)));
    }

    public static function writeAuditLog(
        PDO $pdo,
        string $actorType,
        ?int $actorId,
        string $action,
        ?string $targetType = null,
        ?int $targetId = null,
        array $details = []
    ): void {
        $stmt = $pdo->prepare(
            'INSERT INTO audit_logs (actor_type, actor_id, action, target_type, target_id, details_json, ip_address)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $actorType,
            $actorId,
            $action,
            $targetType,
            $targetId,
            empty($details) ? null : json_encode($details, JSON_UNESCAPED_UNICODE),
            self::clientIp(),
        ]);
    }
}
