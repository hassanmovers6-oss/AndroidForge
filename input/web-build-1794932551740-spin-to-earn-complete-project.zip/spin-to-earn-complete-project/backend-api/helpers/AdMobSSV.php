<?php
/**
 * SpinReward Pro — Google AdMob Server-Side Verification (SSV) Helper
 * File: backend-api/helpers/AdMobSSV.php
 *
 * Implements Google AdMob Rewarded Ad SSV ECDSA signature verification
 * using Google's public verifier keys:
 * https://www.gstatic.com/admob/reward/verifier-keys.json
 */

declare(strict_types=1);

final class AdMobSSV
{
    private const KEYS_URL = 'https://www.gstatic.com/admob/reward/verifier-keys.json';

    public static function verifyCallbackParams(array $queryParams): bool
    {
        if (empty($queryParams['signature']) || empty($queryParams['key_id'])) {
            return false;
        }

        $signature = self::base64UrlDecode((string)$queryParams['signature']);
        $keyId = (string)$queryParams['key_id'];

        $keysJson = @file_get_contents(self::KEYS_URL);
        if ($keysJson === false) {
            return false;
        }

        $keysData = json_decode($keysJson, true);
        $pemKey = null;
        foreach (($keysData['keys'] ?? []) as $entry) {
            if ((string)($entry['keyId'] ?? '') === $keyId) {
                $pemKey = $entry['pem'] ?? null;
                break;
            }
        }

        if (!$pemKey) {
            return false;
        }

        // Google signs the query string bytes up to "&signature="
        $rawQuery = $_SERVER['QUERY_STRING'] ?? '';
        $sigPos = strpos($rawQuery, '&signature=');
        if ($sigPos === false) {
            return false;
        }
        $signedPayload = substr($rawQuery, 0, $sigPos);

        $pubKey = openssl_pkey_get_public($pemKey);
        if ($pubKey === false) {
            return false;
        }

        $verified = openssl_verify($signedPayload, $signature, $pubKey, OPENSSL_ALGO_SHA256);
        return $verified === 1;
    }

    private static function base64UrlDecode(string $input): string
    {
        $remainder = strlen($input) % 4;
        if ($remainder) {
            $input .= str_repeat('=', 4 - $remainder);
        }
        return base64_decode(strtr($input, '-_', '+/')) ?: '';
    }
}
