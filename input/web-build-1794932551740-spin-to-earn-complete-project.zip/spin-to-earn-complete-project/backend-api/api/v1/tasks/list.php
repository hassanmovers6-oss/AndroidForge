<?php
/**
 * GET /api/v1/tasks/list.php
 * Lists genuine admin-approved cash-earning tasks and the user's submission history.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$tasks = $pdo->query(
    'SELECT id, title, category, instructions, reward_pkr, requires_proof, proof_placeholder, max_completions_per_user
     FROM tasks WHERE status = "active" ORDER BY id DESC'
)->fetchAll();

$subStmt = $pdo->prepare(
    'SELECT ts.id, ts.task_id, t.title AS task_title, ts.proof_text, ts.reward_snapshot_pkr,
            ts.status, ts.admin_note, ts.created_at, ts.reviewed_at
     FROM task_submissions ts
     INNER JOIN tasks t ON t.id = ts.task_id
     WHERE ts.user_id = ?
     ORDER BY ts.id DESC
     LIMIT 30'
);
$subStmt->execute([$userId]);
$submissions = $subStmt->fetchAll();

// Count completions per task
$counts = [];
foreach ($submissions as $sub) {
    if ($sub['status'] !== 'rejected') {
        $tid = (int)$sub['task_id'];
        $counts[$tid] = ($counts[$tid] ?? 0) + 1;
    }
}

$formattedTasks = array_map(static function ($t) use ($counts) {
    $tid = (int)$t['id'];
    $used = $counts[$tid] ?? 0;
    return [
        'id'                       => $tid,
        'title'                    => $t['title'],
        'category'                 => $t['category'],
        'instructions'             => $t['instructions'],
        'reward_pkr'               => (float)$t['reward_pkr'],
        'requires_proof'           => (int)$t['requires_proof'] === 1,
        'proof_placeholder'        => $t['proof_placeholder'],
        'max_completions_per_user' => (int)$t['max_completions_per_user'],
        'user_submissions_count'   => $used,
        'can_submit'               => $used < (int)$t['max_completions_per_user'],
    ];
}, $tasks);

Response::json(200, true, 'Genuine cash tasks loaded.', [
    'tasks'       => $formattedTasks,
    'submissions' => $submissions,
]);
