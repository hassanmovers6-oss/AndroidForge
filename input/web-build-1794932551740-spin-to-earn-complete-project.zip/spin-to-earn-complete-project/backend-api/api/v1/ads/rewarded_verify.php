<?php
/**
 * POST /api/v1/ads/rewarded_verify.php
 * Voluntary Watch Video & Earn verification endpoint.
 * Awards strictly non-cash in-app points. Never adds to cash wallet.
 * Prevents duplicate reward claims via ad_network_tx_id / reward_nonce.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';
require_once __DIR__ . '/../../../helpers/RateLimiter.php';
require_once __DIR__ . '/../../../helpers/AdMobSSV.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

RateLimiter::enforce('reward_ad_' . $userId, 10, 3600);

$body = Response::readJsonBody();
$adFormat = (string)($body['ad_format'] ?? 'rewarded');
$rewardNonce = trim((string)($body['reward_nonce'] ?? ''));

if (!in_array($adFormat, ['rewarded', 'rewarded_interstitial'], true)) {
    Response::json(422, false, 'Invalid rewarded ad format.');
}
if (strlen($rewardNonce) < 16 || strlen($rewardNonce) > 100) {
    Response::json(422, false, 'Valid reward_nonce is required to prevent duplicate claims.');
}

$config = require __DIR__ . '/../../../config.php';
if ($config['security']['admob_ssv_verify'] && !empty($_GET['signature'])) {
    if (!AdMobSSV::verifyCallbackParams($_GET)) {
        Response::json(403, false, 'AdMob SSV cryptographic signature verification failed.');
    }
}

$adStmt = $pdo->prepare('SELECT is_enabled, frequency_cap_per_hour, rewarded_points FROM advertisements_settings WHERE ad_format = ? LIMIT 1');
$adStmt->execute([$adFormat]);
$adRule = $adStmt->fetch();

if (!$adRule || (int)$adRule['is_enabled'] !== 1) {
    Response::json(403, false, 'This rewarded ad format is currently disabled.');
}

$rewardPoints = (int)$adRule['rewarded_points'];
if ($rewardPoints <= 0) {
    Response::json(422, false, 'Rewarded points value not configured.');
}

// Hourly frequency cap enforcement
$cap = (int)$adRule['frequency_cap_per_hour'];
if ($cap > 0) {
    $capStmt = $pdo->prepare(
        'SELECT COUNT(*) FROM non_cash_reward_history
         WHERE user_id = ? AND source_type = "rewarded_ad" AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 HOUR)'
    );
    $capStmt->execute([$userId]);
    if ((int)$capStmt->fetchColumn() >= $cap) {
        Response::json(429, false, 'Hourly rewarded video limit reached. Please try again later.');
    }
}

$pdo->beginTransaction();
try {
    $dupStmt = $pdo->prepare('SELECT id FROM non_cash_reward_history WHERE ad_network_tx_id = ? LIMIT 1');
    $dupStmt->execute([$rewardNonce]);
    if ($dupStmt->fetchColumn()) {
        $pdo->rollBack();
        Response::json(409, false, 'Duplicate ad reward claim rejected.');
    }

    $lockStmt = $pdo->prepare('SELECT points_balance FROM user_non_cash_points WHERE user_id = ? FOR UPDATE');
    $lockStmt->execute([$userId]);
    $currentPoints = (int)$lockStmt->fetchColumn();
    $newBalance = $currentPoints + $rewardPoints;

    $pdo->prepare(
        'UPDATE user_non_cash_points
         SET points_balance = points_balance + ?, lifetime_points_earned = lifetime_points_earned + ?
         WHERE user_id = ?'
    )->execute([$rewardPoints, $rewardPoints, $userId]);

    $refId = Security::generateUniqueRefId('ADPTS');
    $pdo->prepare(
        'INSERT INTO non_cash_reward_history (user_id, source_type, points_delta, balance_after, reference_id, description, ad_network_tx_id)
         VALUES (?, "rewarded_ad", ?, ?, ?, ?, ?)'
    )->execute([
        $userId,
        $rewardPoints,
        $newBalance,
        $refId,
        "Watch Video & Earn ({$adFormat}) — non-cash points",
        $rewardNonce,
    ]);

    $pdo->commit();

    Response::json(200, true, "Awarded {$rewardPoints} non-cash in-app points.", [
        'points_awarded' => $rewardPoints,
        'points_balance' => $newBalance,
        'reference_id'   => $refId,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    Response::json(500, false, 'Unable to credit ad reward.');
}
