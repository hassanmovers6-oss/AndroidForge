<?php
/**
 * GET /api/v1/wallet/transactions.php
 * Returns both cash wallet ledger and separate non-cash points ledger.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$cashStmt = $pdo->prepare(
    'SELECT id, reference_id, tx_type, amount_pkr, balance_after_pkr, description, created_at
     FROM wallet_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 100'
);
$cashStmt->execute([$userId]);

$pointsStmt = $pdo->prepare(
    'SELECT id, reference_id, source_type, points_delta, balance_after, description, created_at
     FROM non_cash_reward_history WHERE user_id = ? ORDER BY id DESC LIMIT 100'
);
$pointsStmt->execute([$userId]);

Response::json(200, true, 'Transactions loaded.', [
    'cash_transactions'      => $cashStmt->fetchAll(),
    'non_cash_point_history' => $pointsStmt->fetchAll(),
]);
