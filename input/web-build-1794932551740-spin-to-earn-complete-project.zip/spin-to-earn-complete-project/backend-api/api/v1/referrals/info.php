<?php
/**
 * GET /api/v1/referrals/info.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('GET');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$stmt = $pdo->prepare(
    'SELECT r.id, r.status, r.fraud_reason, r.created_at, r.approved_at, u.full_name AS referred_name
     FROM referrals r
     INNER JOIN users u ON u.id = r.referred_user_id
     WHERE r.referrer_user_id = ?
     ORDER BY r.id DESC'
);
$stmt->execute([$userId]);
$list = $stmt->fetchAll();

$total = count($list);
$pending = 0;
$approved = 0;
foreach ($list as $item) {
    if ($item['status'] === 'pending') {
        $pending++;
    } elseif ($item['status'] === 'approved') {
        $approved++;
    }
}

$rwStmt = $pdo->prepare('SELECT COALESCE(SUM(amount_pkr), 0) FROM referral_rewards WHERE referrer_user_id = ? AND reward_type = "cash_program"');
$rwStmt->execute([$userId]);

Response::json(200, true, 'Referral summary loaded.', [
    'referral_code'          => $user['referral_code'],
    'program_enabled'        => Security::getSetting($pdo, 'referral_program_enabled', '1') === '1',
    'reward_per_referral_pkr'=> (float)Security::getSetting($pdo, 'referral_cash_reward_pkr', '25.00'),
    'total_referrals'        => $total,
    'pending_referrals'      => $pending,
    'approved_referrals'     => $approved,
    'total_cash_earned_pkr'  => (float)$rwStmt->fetchColumn(),
    'referrals'              => $list,
]);
