<?php
/**
 * POST /api/v1/auth/delete_account.php
 * Verifies user password, revokes sessions, anonymizes PII, and marks account deleted.
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../helpers/Security.php';

Security::requireMethod('POST');
$pdo = Database::getConnection();
$user = Security::authenticateUser($pdo);
$userId = (int)$user['id'];

$body = Response::readJsonBody();
$password = (string)($body['password'] ?? '');
$reason   = substr(trim((string)($body['reason'] ?? 'User requested account deletion')), 0, 255);

$stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$userId]);
$hash = (string)$stmt->fetchColumn();

if (!password_verify($password, $hash)) {
    Response::json(401, false, 'Incorrect password. Account deletion cancelled.');
}

$pdo->beginTransaction();
try {
    $anonEmail = 'deleted_' . $userId . '_' . bin2hex(random_bytes(4)) . '@deleted.local';
    $pdo->prepare(
        'UPDATE users SET full_name = ?, email = ?, phone = NULL, status = "deleted", deleted_at = UTC_TIMESTAMP() WHERE id = ?'
    )->execute(['Deleted User', $anonEmail, $userId]);

    $pdo->prepare('UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP() WHERE user_id = ?')->execute([$userId]);

    Security::writeAuditLog($pdo, 'user', $userId, 'account_deleted', 'user', $userId, ['reason' => $reason]);
    $pdo->commit();

    Response::json(200, true, 'Your account has been permanently deleted and active sessions revoked.');
} catch (Throwable $e) {
    $pdo->rollBack();
    Response::json(500, false, 'Failed to delete account.');
}
