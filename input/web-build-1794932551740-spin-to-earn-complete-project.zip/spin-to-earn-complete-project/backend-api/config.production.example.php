<?php
/**
 * SpinReward Pro — Production Configuration Template
 * File: backend-api/config.production.example.php
 *
 * Copy this file to `backend-api/config.production.php` on your live HTTPS server
 * (or set APP_ENV=production + environment variables) so production credentials
 * remain strictly separate from local Windows XAMPP settings.
 *
 * NEVER commit `config.production.php` with real passwords to Git.
 */

declare(strict_types=1);

return [
    'env' => 'production',
    'db' => [
        'host'    => getenv('DB_HOST') ?: '127.0.0.1',
        'port'    => (int)(getenv('DB_PORT') ?: 3306),
        'name'    => getenv('DB_NAME') ?: 'spin_to_earn_prod',
        'user'    => getenv('DB_USER') ?: 'spin_app_user',
        'pass'    => getenv('DB_PASS') !== false ? (string)getenv('DB_PASS') : 'CHANGE_THIS_PRODUCTION_DB_PASSWORD',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'base_url'    => getenv('APP_BASE_URL') ?: 'https://api.your-domain.com',
        'backend_url' => (getenv('APP_BASE_URL') ?: 'https://api.your-domain.com') . '/backend-api/',
        'admin_url'   => (getenv('APP_BASE_URL') ?: 'https://api.your-domain.com') . '/admin-panel/',
    ],
    'security' => [
        // Set APP_SECRET env var or generate with: php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
        'admob_ssv_verify' => true,
    ],
];
