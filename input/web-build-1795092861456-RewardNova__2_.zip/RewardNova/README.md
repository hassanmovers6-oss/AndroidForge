# RewardNova — Complete Spin & Earn Platform

## Project Structure
- `android-app/` — Native Kotlin Android Gradle project (16 screens, Material 3, Retrofit + Gson, EncryptedSharedPreferences, AdMob, ProGuard/R8, AndroidForge-compatible).
- `backend-api/` — PHP 8+ REST API with PDO prepared statements, Bearer token auth, rate limiting, atomic reward transactions, and server-authoritative spin/task verification.
- `admin-panel/` — Responsive PHP + HTML + CSS + JavaScript admin console with secure login, user & points management, spin config, task approvals, withdrawals, AdMob settings, and audit logs.
- `database/` — MySQL 8+ / MariaDB schema (`schema.sql`), non-destructive upgrade script (`upgrade_v1_to_v2.sql`), and safe admin creation script (`setup_admin.php`).
- `docs/` — Step-by-step XAMPP, MySQL, Admin, API, Android, AndroidForge, and Testing guides.

Start with `docs/XAMPP_INSTALLATION.md`, `docs/DATABASE_IMPORT.md`, `docs/ADMIN_SETUP.md`, and `docs/ANDROIDFORGE_BUILD_AND_SIGNING.md`.
