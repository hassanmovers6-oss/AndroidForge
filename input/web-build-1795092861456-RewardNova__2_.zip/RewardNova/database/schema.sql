-- ============================================================================
-- RewardNova MySQL Database Schema (Compatible with MySQL 8.0+ / MariaDB 10.4+)
-- Import via phpMyAdmin or: mysql -u root -p < schema.sql
-- ============================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `rewardnova`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `rewardnova`;

-- 1. Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('super_admin', 'moderator', 'finance') NOT NULL DEFAULT 'super_admin',
  `status` ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
  `last_login_at` DATETIME NULL DEFAULT NULL,
  `last_login_ip` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admins_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `referral_code` VARCHAR(24) NOT NULL,
  `referred_by_user_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `account_status` ENUM('active', 'suspended', 'banned') NOT NULL DEFAULT 'active',
  `phone` VARCHAR(30) NULL DEFAULT NULL,
  `country` VARCHAR(80) NULL DEFAULT 'PK',
  `fcm_token` VARCHAR(255) NULL DEFAULT NULL,
  `last_active_at` DATETIME NULL DEFAULT NULL,
  `registered_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_referral_code` (`referral_code`),
  KEY `idx_users_status` (`account_status`),
  KEY `idx_users_registered_at` (`registered_at`),
  KEY `idx_users_referred_by` (`referred_by_user_id`),
  CONSTRAINT `fk_users_referred_by` FOREIGN KEY (`referred_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. User Sessions (Bearer Token Authentication)
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `device_name` VARCHAR(120) NULL DEFAULT NULL,
  `device_id` VARCHAR(128) NULL DEFAULT NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `revoked_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_sessions_token_hash` (`token_hash`),
  KEY `idx_user_sessions_user_id` (`user_id`),
  KEY `idx_user_sessions_expires_at` (`expires_at`),
  CONSTRAINT `fk_user_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. User Points (Non-cash reward points kept strictly separate from cash wallet)
CREATE TABLE IF NOT EXISTS `user_points` (
  `user_id` BIGINT UNSIGNED NOT NULL,
  `points_balance` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `lifetime_points_earned` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `lifetime_points_converted` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `spins_used_today` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_spin_date` DATE NULL DEFAULT NULL,
  `checkin_streak` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_checkin_date` DATE NULL DEFAULT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_points_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Cash Wallets (Converted INR/PKR/Rs cash balance, separate from points)
CREATE TABLE IF NOT EXISTS `cash_wallets` (
  `user_id` BIGINT UNSIGNED NOT NULL,
  `cash_balance` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total_withdrawn` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `pending_withdrawal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_cash_wallets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Tasks (Admin configurable)
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(160) NOT NULL,
  `description` TEXT NOT NULL,
  `task_type` ENUM('daily', 'social', 'visit', 'video', 'app_action', 'survey') NOT NULL DEFAULT 'visit',
  `action_url` VARCHAR(500) NULL DEFAULT NULL,
  `reward_points` INT UNSIGNED NOT NULL DEFAULT 50,
  `is_repeatable_daily` TINYINT(1) NOT NULL DEFAULT 0,
  `requires_proof` TINYINT(1) NOT NULL DEFAULT 0,
  `verification_keyword` VARCHAR(100) NULL DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_active_sort` (`is_active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Task Submissions (Auto-approved on valid backend verification, prevents duplicates)
CREATE TABLE IF NOT EXISTS `task_submissions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `task_id` BIGINT UNSIGNED NOT NULL,
  `submission_date` DATE NOT NULL,
  `proof_text` VARCHAR(500) NULL DEFAULT NULL,
  `status` ENUM('approved', 'rejected', 'pending') NOT NULL DEFAULT 'approved',
  `points_awarded` INT UNSIGNED NOT NULL DEFAULT 0,
  `approved_by_system` TINYINT(1) NOT NULL DEFAULT 1,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_task_submission_user_task_date` (`user_id`, `task_id`, `submission_date`),
  KEY `idx_task_submissions_task_id` (`task_id`),
  KEY `idx_task_submissions_status` (`status`),
  CONSTRAINT `fk_task_submissions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_task_submissions_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Spin Reward Settings (Admin configurable wheel segments & weights)
CREATE TABLE IF NOT EXISTS `spin_reward_settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `segment_index` TINYINT UNSIGNED NOT NULL,
  `label` VARCHAR(60) NOT NULL,
  `points_reward` INT UNSIGNED NOT NULL,
  `weight` INT UNSIGNED NOT NULL DEFAULT 10,
  `color_hex` CHAR(7) NOT NULL DEFAULT '#1E40AF',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spin_segment_index` (`segment_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Spin History (Server-authoritative spin records + idempotency key)
CREATE TABLE IF NOT EXISTS `spin_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `segment_id` INT UNSIGNED NOT NULL,
  `segment_label` VARCHAR(60) NOT NULL,
  `points_won` INT UNSIGNED NOT NULL,
  `request_nonce` VARCHAR(64) NOT NULL,
  `spin_date` DATE NOT NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_spin_history_nonce` (`user_id`, `request_nonce`),
  KEY `idx_spin_history_user_date` (`user_id`, `spin_date`),
  KEY `idx_spin_history_created` (`created_at`),
  CONSTRAINT `fk_spin_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_spin_history_segment` FOREIGN KEY (`segment_id`) REFERENCES `spin_reward_settings` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Wallet Transactions (Unified immutable ledger for points & cash)
CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `wallet_type` ENUM('points', 'cash') NOT NULL,
  `tx_type` ENUM('credit', 'debit') NOT NULL,
  `category` ENUM('spin', 'task', 'checkin', 'referral', 'ad_reward', 'points_conversion', 'withdrawal', 'withdrawal_refund', 'admin_adjustment') NOT NULL,
  `points_amount` BIGINT NOT NULL DEFAULT 0,
  `cash_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `balance_after_points` BIGINT UNSIGNED NULL DEFAULT NULL,
  `balance_after_cash` DECIMAL(12,2) NULL DEFAULT NULL,
  `reference_id` VARCHAR(100) NULL DEFAULT NULL,
  `description` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_wallet_tx_user_created` (`user_id`, `created_at`),
  KEY `idx_wallet_tx_category` (`category`),
  CONSTRAINT `fk_wallet_tx_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Withdrawal Requests (Minimum Rs 100 enforced server-side)
CREATE TABLE IF NOT EXISTS `withdrawal_requests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `amount_rs` DECIMAL(12,2) NOT NULL,
  `payment_method` ENUM('UPI', 'Bank Transfer', 'JazzCash', 'EasyPaisa', 'Paytm', 'PayPal') NOT NULL,
  `account_details` VARCHAR(255) NOT NULL,
  `account_holder_name` VARCHAR(120) NOT NULL,
  `status` ENUM('pending', 'approved', 'paid', 'rejected') NOT NULL DEFAULT 'pending',
  `admin_note` VARCHAR(255) NULL DEFAULT NULL,
  `processed_by_admin_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `processed_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_withdrawals_user` (`user_id`),
  KEY `idx_withdrawals_status` (`status`),
  CONSTRAINT `fk_withdrawals_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_withdrawals_admin` FOREIGN KEY (`processed_by_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Referrals
CREATE TABLE IF NOT EXISTS `referrals` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `referrer_user_id` BIGINT UNSIGNED NOT NULL,
  `referred_user_id` BIGINT UNSIGNED NOT NULL,
  `referral_code_used` VARCHAR(24) NOT NULL,
  `status` ENUM('registered', 'rewarded') NOT NULL DEFAULT 'rewarded',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_referrals_referred_user` (`referred_user_id`),
  KEY `idx_referrals_referrer` (`referrer_user_id`),
  CONSTRAINT `fk_referrals_referrer` FOREIGN KEY (`referrer_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_referrals_referred` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Referral Rewards
CREATE TABLE IF NOT EXISTS `referral_rewards` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `referral_id` BIGINT UNSIGNED NOT NULL,
  `beneficiary_user_id` BIGINT UNSIGNED NOT NULL,
  `reward_role` ENUM('referrer', 'referred') NOT NULL,
  `points_awarded` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_referral_reward_unique` (`referral_id`, `reward_role`),
  KEY `idx_referral_rewards_user` (`beneficiary_user_id`),
  CONSTRAINT `fk_referral_rewards_referral` FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_referral_rewards_user` FOREIGN KEY (`beneficiary_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL DEFAULT NULL COMMENT 'NULL means broadcast to all users',
  `title` VARCHAR(160) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('system', 'reward', 'withdrawal', 'promo', 'security') NOT NULL DEFAULT 'system',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_by_admin_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user_read` (`user_id`, `is_read`),
  KEY `idx_notifications_created` (`created_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notifications_admin` FOREIGN KEY (`created_by_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. App Settings (Key-Value business rules & app configuration)
CREATE TABLE IF NOT EXISTS `app_settings` (
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` TEXT NOT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. Advertisements Settings (AdMob configurable IDs — defaults are official Google Test IDs)
CREATE TABLE IF NOT EXISTS `advertisements_settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ad_format` ENUM('banner', 'interstitial', 'native', 'rewarded', 'rewarded_interstitial', 'app_open') NOT NULL,
  `ad_unit_id` VARCHAR(120) NOT NULL,
  `is_test_mode` TINYINT(1) NOT NULL DEFAULT 1,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `reward_points` INT UNSIGNED NOT NULL DEFAULT 0,
  `daily_cap` INT UNSIGNED NOT NULL DEFAULT 10,
  `notes` VARCHAR(255) NULL DEFAULT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ad_format` (`ad_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. Audit Logs (Immutable trail for admin & security events)
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `actor_type` ENUM('admin', 'user', 'system') NOT NULL,
  `actor_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `action` VARCHAR(120) NOT NULL,
  `target_type` VARCHAR(80) NULL DEFAULT NULL,
  `target_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `details` TEXT NULL DEFAULT NULL,
  `ip_address` VARCHAR(45) NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_actor` (`actor_type`, `actor_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. Supporting Table: Password Reset Codes
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `reset_code_hash` CHAR(64) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `used_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prt_user` (`user_id`),
  CONSTRAINT `fk_prt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 19. Supporting Table: Rewarded Ad Verification Nonces (prevents duplicate/forged ad claims)
CREATE TABLE IF NOT EXISTS `ad_reward_verifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `ad_format` ENUM('rewarded', 'rewarded_interstitial') NOT NULL DEFAULT 'rewarded',
  `nonce` VARCHAR(64) NOT NULL,
  `status` ENUM('issued', 'verified') NOT NULL DEFAULT 'issued',
  `points_awarded` INT UNSIGNED NOT NULL DEFAULT 0,
  `issued_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ad_nonce` (`nonce`),
  KEY `idx_ad_user_date` (`user_id`, `issued_at`),
  CONSTRAINT `fk_ad_verify_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 20. Supporting Table: API Rate Limiting Buckets
CREATE TABLE IF NOT EXISTS `api_rate_limits` (
  `bucket_key` VARCHAR(128) NOT NULL,
  `hit_count` INT UNSIGNED NOT NULL DEFAULT 1,
  `window_start` DATETIME NOT NULL,
  PRIMARY KEY (`bucket_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Seed Default Configuration (Safe INSERT IGNORE — non-destructive)
-- ============================================================================

INSERT IGNORE INTO `app_settings` (`setting_key`, `setting_value`, `description`) VALUES
('app_name', 'RewardNova', 'Public application name'),
('points_per_rupee', '1000', 'Number of non-cash reward points equal to Rs 1'),
('min_withdrawal_rs', '100', 'Minimum cash withdrawal threshold in Rs'),
('daily_spin_limit', '5', 'Maximum number of spins permitted per user per day'),
('daily_checkin_base_points', '25', 'Base points for Day 1 daily check-in'),
('daily_checkin_streak_bonus', '15', 'Additional points per consecutive streak day'),
('referral_referrer_points', '250', 'Points credited to referrer on valid new signup'),
('referral_referred_points', '100', 'Welcome bonus points credited to referred user'),
('support_email', 'support@rewardnova.local', 'Support contact email shown in Android app'),
('privacy_policy_url', 'https://rewardnova.example.com/privacy', 'Privacy policy URL'),
('terms_url', 'https://rewardnova.example.com/terms', 'Terms of service URL'),
('maintenance_mode', '0', '1 = maintenance active, 0 = operational');

INSERT IGNORE INTO `spin_reward_settings` (`id`, `segment_index`, `label`, `points_reward`, `weight`, `color_hex`, `is_active`) VALUES
(1, 0, '10 Pts', 10, 30, '#1E3A8A', 1),
(2, 1, '25 Pts', 25, 25, '#0F766E', 1),
(3, 2, '50 Pts', 50, 20, '#0369A1', 1),
(4, 3, '75 Pts', 75, 12, '#B45309', 1),
(5, 4, '100 Pts', 100, 8, '#047857', 1),
(6, 5, '150 Pts', 150, 3, '#4338CA', 1),
(7, 6, '250 Pts', 250, 1, '#BE123C', 1),
(8, 7, '500 Pts', 500, 1, '#D97706', 1);

INSERT IGNORE INTO `tasks` (`id`, `title`, `description`, `task_type`, `action_url`, `reward_points`, `is_repeatable_daily`, `requires_proof`, `verification_keyword`, `is_active`, `sort_order`) VALUES
(1, 'Daily Welcome Bonus Visit', 'Open our featured partner guide and spend a few seconds reviewing daily tips.', 'daily', 'https://rewardnova.example.com/daily-guide', 100, 1, 0, NULL, 1, 1),
(2, 'Complete Profile Verification', 'Confirm your profile details are up to date in your RewardNova account.', 'app_action', NULL, 150, 0, 0, NULL, 1, 2),
(3, 'Join Official Community Channel', 'Visit our official community updates page and submit your handle.', 'social', 'https://rewardnova.example.com/community', 200, 0, 1, NULL, 1, 3),
(4, 'Watch Daily Sponsor Highlight', 'Check out the daily sponsor highlight and claim your instant reward points.', 'video', 'https://rewardnova.example.com/sponsor', 120, 1, 0, NULL, 1, 4);

-- Official Google AdMob Android Test Ad Unit IDs (replace via Admin Panel before production release)
INSERT IGNORE INTO `advertisements_settings` (`id`, `ad_format`, `ad_unit_id`, `is_test_mode`, `is_enabled`, `reward_points`, `daily_cap`, `notes`) VALUES
(1, 'banner', 'ca-app-pub-3940256099942544/6300978111', 1, 1, 0, 0, 'Google Test Banner Ad Unit ID - Replace in Admin Panel for production'),
(2, 'interstitial', 'ca-app-pub-3940256099942544/1033173712', 1, 1, 0, 10, 'Google Test Interstitial Ad Unit ID - Replace in Admin Panel for production'),
(3, 'native', 'ca-app-pub-3940256099942544/2247696110', 1, 1, 0, 0, 'Google Test Native Advanced Ad Unit ID - Replace in Admin Panel for production'),
(4, 'rewarded', 'ca-app-pub-3940256099942544/5224354917', 1, 1, 50, 10, 'Google Test Rewarded Ad Unit ID - Replace in Admin Panel for production'),
(5, 'rewarded_interstitial', 'ca-app-pub-3940256099942544/5354046379', 1, 1, 40, 8, 'Google Test Rewarded Interstitial Ad Unit ID - Replace in Admin Panel for production'),
(6, 'app_open', 'ca-app-pub-3940256099942544/9257395921', 1, 1, 0, 5, 'Google Test App Open Ad Unit ID - Replace in Admin Panel for production');
