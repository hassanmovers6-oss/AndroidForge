<?php
/**
 * RewardNova Safe Initial Admin Account Setup Script
 *
 * Usage (CLI - Recommended):
 *   php setup_admin.php --name="Super Admin" --email="admin@rewardnova.local" --password="YourStrongPassword123!"
 *
 * Usage (Browser - One-time only when 0 admins exist):
 *   http://localhost/RewardNova/database/setup_admin.php
 *   Once an admin account exists, browser access is automatically locked.
 */

declare(strict_types=1);

require_once __DIR__ . '/../backend-api/config/database.php';

$pdo = Database::getConnection();

$adminCount = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();

if (PHP_SAPI === 'cli') {
    $options = getopt('', ['name:', 'email:', 'password:']);
    $name = trim((string)($options['name'] ?? ''));
    $email = strtolower(trim((string)($options['email'] ?? '')));
    $password = (string)($options['password'] ?? '');

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        fwrite(STDERR, "Usage: php setup_admin.php --name=\"Admin Name\" --email=\"admin@example.com\" --password=\"StrongPass8+\"\n");
        exit(1);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $stmt = $pdo->prepare("INSERT INTO admins (full_name, email, password_hash, role, status) VALUES (:name, :email, :hash, 'super_admin', 'active') ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), password_hash = VALUES(password_hash), status = 'active'");
    $stmt->execute([':name' => $name, ':email' => $email, ':hash' => $hash]);

    fwrite(STDOUT, "Admin account configured successfully for {$email}.\n");
    exit(0);
}

// Web browser one-time setup (strictly locked once an admin exists)
header('Content-Type: text/html; charset=UTF-8');

if ($adminCount > 0) {
    http_response_code(403);
    echo '<!doctype html><html><body style="font-family:sans-serif;max-width:520px;margin:60px auto;padding:24px;border:1px solid #e2e8f0;border-radius:12px;">';
    echo '<h2>Setup Locked</h2>';
    echo '<p>An administrator account already exists in the database. For security, web-based setup is disabled.</p>';
    echo '<p><a href="../admin-panel/login.php">Go to Admin Panel Login</a></p>';
    echo '</body></html>';
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string)($_POST['full_name'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if ($name === '' || strlen($name) < 2) {
        $error = 'Full name is required (at least 2 characters).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $stmt = $pdo->prepare("INSERT INTO admins (full_name, email, password_hash, role, status) VALUES (:name, :email, :hash, 'super_admin', 'active')");
        $stmt->execute([':name' => $name, ':email' => $email, ':hash' => $hash]);

        $adminId = (int)$pdo->lastInsertId();
        $audit = $pdo->prepare("INSERT INTO audit_logs (actor_type, actor_id, action, target_type, target_id, details, ip_address) VALUES ('system', :id, 'initial_admin_created', 'admin', :tid, :details, :ip)");
        $audit->execute([
            ':id' => $adminId,
            ':tid' => $adminId,
            ':details' => 'Initial super admin created via setup_admin.php',
            ':ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);

        $success = 'Super Admin account created successfully! This setup script is now locked.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RewardNova - Initial Admin Setup</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; margin: 0; padding: 32px 16px; }
    .card { max-width: 440px; margin: 40px auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 28px; }
    h1 { font-size: 20px; margin: 0 0 8px; }
    p { font-size: 14px; color: #475569; margin: 0 0 20px; }
    label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; }
    input { width: 100%; box-sizing: border-box; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; margin-bottom: 14px; font-size: 14px; }
    button { width: 100%; padding: 11px; background: #0f172a; color: #fff; border: 0; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; }
    .alert-err { background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; padding: 10px 12px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; }
    .alert-ok { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 10px 12px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>RewardNova Admin Setup</h1>
    <p>Create the initial Super Administrator account. This page locks permanently after creation.</p>
    <?php if ($error !== ''): ?>
      <div class="alert-err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>
    <?php if ($success !== ''): ?>
      <div class="alert-ok"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?> <br><br><a href="../admin-panel/login.php">Proceed to Admin Login &rarr;</a></div>
    <?php else: ?>
      <form method="post" autocomplete="off">
        <label for="full_name">Full Name</label>
        <input id="full_name" name="full_name" type="text" required placeholder="e.g. Alex Morgan">
        <label for="email">Admin Email</label>
        <input id="email" name="email" type="email" required placeholder="admin@yourdomain.com">
        <label for="password">Password (min 8 chars)</label>
        <input id="password" name="password" type="password" minlength="8" required>
        <label for="confirm_password">Confirm Password</label>
        <input id="confirm_password" name="confirm_password" type="password" minlength="8" required>
        <button type="submit">Create Super Admin</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
