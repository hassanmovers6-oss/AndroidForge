-- ============================================================================
-- RewardNova Non-Destructive Upgrade Script (v1 -> v2)
-- Safe to run repeatedly on an existing database. Never drops tables/columns.
-- ============================================================================

USE `rewardnova`;

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `reset_code_hash` CHAR(64) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `used_at` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_prt_user` (`user_id`),
  CONSTRAINT `fk_prt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ad_reward_verifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `ad_format` ENUM('rewarded', 'rewarded_interstitial') NOT NULL DEFAULT 'rewarded',
  `nonce` VARCHAR(64) NOT NULL,
  `status` ENUM('issued', 'verified') NOT NULL DEFAULT 'issued',
  `points_awarded` INT UNSIGNED NOT NULL DEFAULT 0,
  `issued_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ad_nonce` (`nonce`),
  KEY `idx_ad_user_date` (`user_id`, `issued_at`),
  CONSTRAINT `fk_ad_verify_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `api_rate_limits` (
  `bucket_key` VARCHAR(128) NOT NULL,
  `hit_count` INT UNSIGNED NOT NULL DEFAULT 1,
  `window_start` DATETIME NOT NULL,
  PRIMARY KEY (`bucket_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `app_settings` (`setting_key`, `setting_value`, `description`) VALUES
('schema_version', '2.0.0', 'Current non-destructive database schema version');
