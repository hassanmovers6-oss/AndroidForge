<?php
declare(strict_types=1);

function jsonSuccess(mixed $data = null, string $message = 'OK', int $statusCode = 200): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'success' => true,
        'message' => $message,
        'data' => $data,
        'timestamp' => gmdate('c'),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError(string $message, int $statusCode = 400, string $errorCode = 'BAD_REQUEST', mixed $errors = null): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=UTF-8');
    $payload = [
        'success' => false,
        'message' => $message,
        'error_code' => $errorCode,
        'timestamp' => gmdate('c'),
    ];
    if ($errors !== null) {
        $payload['errors'] = $errors;
    }
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function getJsonInput(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return $_POST ?: [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        jsonError('Invalid JSON request payload.', 400, 'INVALID_JSON');
    }
    return $decoded;
}

function getClientIp(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return substr((string)$ip, 0, 45);
}
