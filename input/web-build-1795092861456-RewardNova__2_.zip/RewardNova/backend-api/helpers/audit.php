<?php
declare(strict_types=1);

function writeAuditLog(
    PDO $pdo,
    string $actorType,
    ?int $actorId,
    string $action,
    ?string $targetType = null,
    ?int $targetId = null,
    ?string $details = null
): void {
    $stmt = $pdo->prepare('
        INSERT INTO audit_logs (actor_type, actor_id, action, target_type, target_id, details, ip_address)
        VALUES (:actor_type, :actor_id, :action, :target_type, :target_id, :details, :ip_address)
    ');
    $stmt->execute([
        ':actor_type' => $actorType,
        ':actor_id' => $actorId,
        ':action' => substr($action, 0, 120),
        ':target_type' => $targetType !== null ? substr($targetType, 0, 80) : null,
        ':target_id' => $targetId,
        ':details' => $details,
        ':ip_address' => getClientIp(),
    ]);
}
