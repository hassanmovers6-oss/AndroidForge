<?php
declare(strict_types=1);

function getBearerToken(): ?string
{
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+([A-Za-z0-9\-_]{32,128})$/i', trim((string)$authHeader), $matches)) {
        return $matches[1];
    }
    return null;
}

function issueSessionToken(PDO $pdo, int $userId, ?string $deviceName = null, ?string $deviceId = null): array
{
    $rawToken = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $cfg = Database::getConfig();
    $ttlDays = max(1, (int)$cfg['TOKEN_TTL_DAYS']);
    $expiresAt = gmdate('Y-m-d H:i:s', time() + ($ttlDays * 86400));

    $stmt = $pdo->prepare('
        INSERT INTO user_sessions (user_id, token_hash, device_name, device_id, ip_address, expires_at)
        VALUES (:user_id, :token_hash, :device_name, :device_id, :ip_address, :expires_at)
    ');
    $stmt->execute([
        ':user_id' => $userId,
        ':token_hash' => $tokenHash,
        ':device_name' => $deviceName !== null ? substr($deviceName, 0, 120) : null,
        ':device_id' => $deviceId !== null ? substr($deviceId, 0, 128) : null,
        ':ip_address' => getClientIp(),
        ':expires_at' => $expiresAt,
    ]);

    return [
        'token' => $rawToken,
        'expires_at' => $expiresAt,
    ];
}

function authenticateUser(PDO $pdo): array
{
    $rawToken = getBearerToken();
    if ($rawToken === null) {
        jsonError('Authentication token is missing.', 401, 'UNAUTHORIZED');
    }

    $tokenHash = hash('sha256', $rawToken);
    $stmt = $pdo->prepare('
        SELECT s.id AS session_id, s.expires_at, s.revoked_at,
               u.id, u.full_name, u.email, u.referral_code, u.account_status, u.phone, u.country, u.registered_at
        FROM user_sessions s
        INNER JOIN users u ON u.id = s.user_id
        WHERE s.token_hash = :token_hash
        LIMIT 1
    ');
    $stmt->execute([':token_hash' => $tokenHash]);
    $row = $stmt->fetch();

    if (!$row) {
        jsonError('Invalid authentication session.', 401, 'INVALID_TOKEN');
    }
    if ($row['revoked_at'] !== null) {
        jsonError('Session has been revoked. Please sign in again.', 401, 'TOKEN_REVOKED');
    }
    if (strtotime((string)$row['expires_at']) < time()) {
        jsonError('Session has expired. Please sign in again.', 401, 'TOKEN_EXPIRED');
    }
    if ($row['account_status'] !== 'active') {
        jsonError('Your account is currently ' . $row['account_status'] . '. Contact support.', 403, 'ACCOUNT_RESTRICTED');
    }

    // Update last_used_at & user last_active_at
    $updSession = $pdo->prepare('UPDATE user_sessions SET last_used_at = UTC_TIMESTAMP() WHERE id = :sid');
    $updSession->execute([':sid' => $row['session_id']]);

    $updUser = $pdo->prepare('UPDATE users SET last_active_at = UTC_TIMESTAMP() WHERE id = :uid');
    $updUser->execute([':uid' => $row['id']]);

    $row['raw_token_hash'] = $tokenHash;
    return $row;
}
