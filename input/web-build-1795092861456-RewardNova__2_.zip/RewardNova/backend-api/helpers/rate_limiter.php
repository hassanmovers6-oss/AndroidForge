<?php
declare(strict_types=1);

function enforceRateLimit(PDO $pdo, string $action, string $identifier, int $maxHits, int $windowSeconds): void
{
    $bucketKey = hash('sha256', $action . '|' . $identifier);
    $now = time();

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT hit_count, UNIX_TIMESTAMP(window_start) AS win_ts FROM api_rate_limits WHERE bucket_key = :k FOR UPDATE');
        $stmt->execute([':k' => $bucketKey]);
        $row = $stmt->fetch();

        if (!$row || ($now - (int)$row['win_ts']) >= $windowSeconds) {
            $upsert = $pdo->prepare('
                INSERT INTO api_rate_limits (bucket_key, hit_count, window_start)
                VALUES (:k, 1, FROM_UNIXTIME(:ts))
                ON DUPLICATE KEY UPDATE hit_count = 1, window_start = FROM_UNIXTIME(:ts2)
            ');
            $upsert->execute([':k' => $bucketKey, ':ts' => $now, ':ts2' => $now]);
            $pdo->commit();
            return;
        }

        if ((int)$row['hit_count'] >= $maxHits) {
            $pdo->rollBack();
            jsonError('Too many requests. Please wait a moment before trying again.', 429, 'RATE_LIMITED');
        }

        $inc = $pdo->prepare('UPDATE api_rate_limits SET hit_count = hit_count + 1 WHERE bucket_key = :k');
        $inc->execute([':k' => $bucketKey]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // Fail open only on unexpected lock errors so legitimate traffic is not blocked
        error_log('Rate limiter warning: ' . $e->getMessage());
    }
}
