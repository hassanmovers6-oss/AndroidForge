<?php
declare(strict_types=1);

final class AuthController
{
    public static function register(PDO $pdo): never
    {
        enforceRateLimit($pdo, 'auth_register', getClientIp(), 10, 300);
        $input = getJsonInput();

        $fullName = trim((string)($input['full_name'] ?? ''));
        $email = strtolower(trim((string)($input['email'] ?? '')));
        $password = (string)($input['password'] ?? '');
        $confirmPassword = (string)($input['confirm_password'] ?? '');
        $referralCodeInput = strtoupper(trim((string)($input['referral_code'] ?? '')));
        $deviceName = isset($input['device_name']) ? trim((string)$input['device_name']) : null;
        $deviceId = isset($input['device_id']) ? trim((string)$input['device_id']) : null;

        if (strlen($fullName) < 2 || strlen($fullName) > 120) {
            jsonError('Full name must be between 2 and 120 characters.', 422, 'VALIDATION_ERROR');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonError('Please provide a valid email address.', 422, 'VALIDATION_ERROR');
        }
        if (strlen($password) < 8) {
            jsonError('Password must be at least 8 characters long.', 422, 'VALIDATION_ERROR');
        }
        if ($password !== $confirmPassword) {
            jsonError('Password and confirm password do not match.', 422, 'VALIDATION_ERROR');
        }

        // Check duplicate email
        $dupStmt = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $dupStmt->execute([':email' => $email]);
        if ($dupStmt->fetch()) {
            jsonError('An account with this email address already exists.', 409, 'EMAIL_EXISTS');
        }

        $referrerUserId = null;
        if ($referralCodeInput !== '') {
            $refStmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = :code AND account_status = 'active' LIMIT 1");
            $refStmt->execute([':code' => $referralCodeInput]);
            $refRow = $refStmt->fetch();
            if (!$refRow) {
                jsonError('Invalid or inactive referral code.', 422, 'INVALID_REFERRAL_CODE');
            }
            $referrerUserId = (int)$refRow['id'];
        }

        $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $newReferralCode = self::generateUniqueReferralCode($pdo, $fullName);

        $pdo->beginTransaction();
        try {
            $insUser = $pdo->prepare('
                INSERT INTO users (full_name, email, password_hash, referral_code, referred_by_user_id, account_status, last_active_at)
                VALUES (:full_name, :email, :password_hash, :referral_code, :referred_by, "active", UTC_TIMESTAMP())
            ');
            $insUser->execute([
                ':full_name' => $fullName,
                ':email' => $email,
                ':password_hash' => $passwordHash,
                ':referral_code' => $newReferralCode,
                ':referred_by' => $referrerUserId,
            ]);
            $newUserId = (int)$pdo->lastInsertId();

            $pdo->prepare('INSERT INTO user_points (user_id, points_balance) VALUES (:uid, 0)')
                ->execute([':uid' => $newUserId]);

            $pdo->prepare('INSERT INTO cash_wallets (user_id, cash_balance) VALUES (:uid, 0.00)')
                ->execute([':uid' => $newUserId]);

            $welcomeNotification = $pdo->prepare('
                INSERT INTO notifications (user_id, title, message, type)
                VALUES (:uid, :title, :msg, "system")
            ');
            $welcomeNotification->execute([
                ':uid' => $newUserId,
                ':title' => 'Welcome to RewardNova',
                ':msg' => 'Your account is active. Spin the wheel, complete tasks, and check in daily to earn points.',
            ]);

            if ($referrerUserId !== null) {
                $referrerBonus = AppSettings::getInt($pdo, 'referral_referrer_points', 250);
                $referredBonus = AppSettings::getInt($pdo, 'referral_referred_points', 100);

                $insRef = $pdo->prepare('
                    INSERT INTO referrals (referrer_user_id, referred_user_id, referral_code_used, status)
                    VALUES (:referrer, :referred, :code, "rewarded")
                ');
                $insRef->execute([
                    ':referrer' => $referrerUserId,
                    ':referred' => $newUserId,
                    ':code' => $referralCodeInput,
                ]);
                $referralId = (int)$pdo->lastInsertId();

                if ($referrerBonus > 0) {
                    $lockReferrer = $pdo->prepare('SELECT points_balance FROM user_points WHERE user_id = :uid FOR UPDATE');
                    $lockReferrer->execute([':uid' => $referrerUserId]);
                    $curPts = (int)$lockReferrer->fetchColumn();
                    $newPts = $curPts + $referrerBonus;

                    $pdo->prepare('UPDATE user_points SET points_balance = :bal, lifetime_points_earned = lifetime_points_earned + :pts WHERE user_id = :uid')
                        ->execute([':bal' => $newPts, ':pts' => $referrerBonus, ':uid' => $referrerUserId]);

                    $pdo->prepare('INSERT INTO referral_rewards (referral_id, beneficiary_user_id, reward_role, points_awarded) VALUES (:rid, :uid, "referrer", :pts)')
                        ->execute([':rid' => $referralId, ':uid' => $referrerUserId, ':pts' => $referrerBonus]);

                    $pdo->prepare('
                        INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                        VALUES (:uid, "points", "credit", "referral", :pts, :bal, :ref, :desc)
                    ')->execute([
                        ':uid' => $referrerUserId,
                        ':pts' => $referrerBonus,
                        ':bal' => $newPts,
                        ':ref' => 'REF-' . $referralId,
                        ':desc' => 'Referral bonus for inviting ' . $fullName,
                    ]);

                    $pdo->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (:uid, :title, :msg, "reward")')
                        ->execute([
                            ':uid' => $referrerUserId,
                            ':title' => 'Referral Reward Credited',
                            ':msg' => "You earned {$referrerBonus} points because {$fullName} joined using your referral code.",
                        ]);
                }

                if ($referredBonus > 0) {
                    $lockReferred = $pdo->prepare('SELECT points_balance FROM user_points WHERE user_id = :uid FOR UPDATE');
                    $lockReferred->execute([':uid' => $newUserId]);
                    $curPts = (int)$lockReferred->fetchColumn();
                    $newPts = $curPts + $referredBonus;

                    $pdo->prepare('UPDATE user_points SET points_balance = :bal, lifetime_points_earned = lifetime_points_earned + :pts WHERE user_id = :uid')
                        ->execute([':bal' => $newPts, ':pts' => $referredBonus, ':uid' => $newUserId]);

                    $pdo->prepare('INSERT INTO referral_rewards (referral_id, beneficiary_user_id, reward_role, points_awarded) VALUES (:rid, :uid, "referred", :pts)')
                        ->execute([':rid' => $referralId, ':uid' => $newUserId, ':pts' => $referredBonus]);

                    $pdo->prepare('
                        INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                        VALUES (:uid, "points", "credit", "referral", :pts, :bal, :ref, :desc)
                    ')->execute([
                        ':uid' => $newUserId,
                        ':pts' => $referredBonus,
                        ':bal' => $newPts,
                        ':ref' => 'REF-' . $referralId,
                        ':desc' => 'Welcome referral signup bonus',
                    ]);
                }
            }

            writeAuditLog($pdo, 'user', $newUserId, 'user_registered', 'user', $newUserId, 'Registered email: ' . $email);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            error_log('Register error: ' . $e->getMessage());
            jsonError('Registration failed. Please try again.', 500, 'REGISTRATION_FAILED');
        }

        $session = issueSessionToken($pdo, $newUserId, $deviceName, $deviceId);
        $userSummary = self::fetchUserSummary($pdo, $newUserId);

        jsonSuccess([
            'token' => $session['token'],
            'expires_at' => $session['expires_at'],
            'user' => $userSummary,
        ], 'Account created successfully.', 201);
    }

    public static function login(PDO $pdo): never
    {
        enforceRateLimit($pdo, 'auth_login', getClientIp(), 20, 300);
        $input = getJsonInput();

        $email = strtolower(trim((string)($input['email'] ?? '')));
        $password = (string)($input['password'] ?? '');
        $deviceName = isset($input['device_name']) ? trim((string)$input['device_name']) : null;
        $deviceId = isset($input['device_id']) ? trim((string)$input['device_id']) : null;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            jsonError('Email and password are required.', 422, 'VALIDATION_ERROR');
        }

        $stmt = $pdo->prepare('SELECT id, password_hash, account_status FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, (string)$user['password_hash'])) {
            jsonError('Invalid email or password.', 401, 'INVALID_CREDENTIALS');
        }

        if ($user['account_status'] !== 'active') {
            jsonError('Your account is ' . $user['account_status'] . '. Please contact support.', 403, 'ACCOUNT_RESTRICTED');
        }

        $userId = (int)$user['id'];
        $pdo->prepare('UPDATE users SET last_active_at = UTC_TIMESTAMP() WHERE id = :id')->execute([':id' => $userId]);
        writeAuditLog($pdo, 'user', $userId, 'user_login', 'user', $userId, 'User signed in via API');

        $session = issueSessionToken($pdo, $userId, $deviceName, $deviceId);
        $userSummary = self::fetchUserSummary($pdo, $userId);

        jsonSuccess([
            'token' => $session['token'],
            'expires_at' => $session['expires_at'],
            'user' => $userSummary,
        ], 'Signed in successfully.');
    }

    public static function forgotPassword(PDO $pdo): never
    {
        enforceRateLimit($pdo, 'auth_forgot', getClientIp(), 8, 600);
        $input = getJsonInput();
        $email = strtolower(trim((string)($input['email'] ?? '')));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonError('Please provide a valid email address.', 422, 'VALIDATION_ERROR');
        }

        $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        $devCode = null;
        if ($user) {
            $code = (string)random_int(100000, 999999);
            $codeHash = hash('sha256', $code);
            $expiresAt = gmdate('Y-m-d H:i:s', time() + 900); // 15 mins

            $pdo->prepare('INSERT INTO password_reset_tokens (user_id, reset_code_hash, expires_at) VALUES (:uid, :hash, :exp)')
                ->execute([
                    ':uid' => (int)$user['id'],
                    ':hash' => $codeHash,
                    ':exp' => $expiresAt,
                ]);

            writeAuditLog($pdo, 'user', (int)$user['id'], 'password_reset_requested', 'user', (int)$user['id'], '6-digit reset code generated');

            $cfg = Database::getConfig();
            if (($cfg['APP_ENV'] ?? 'local') === 'local') {
                // Exposed only in local XAMPP dev mode so testing without an SMTP server works
                $devCode = $code;
            }
        }

        $responseData = ['email' => $email, 'expires_in_minutes' => 15];
        if ($devCode !== null) {
            $responseData['local_test_reset_code'] = $devCode;
        }

        jsonSuccess($responseData, 'If an account exists for that email, a 6-digit password reset code has been issued.');
    }

    public static function resetPassword(PDO $pdo): never
    {
        enforceRateLimit($pdo, 'auth_reset', getClientIp(), 10, 600);
        $input = getJsonInput();
        $email = strtolower(trim((string)($input['email'] ?? '')));
        $code = trim((string)($input['reset_code'] ?? ''));
        $newPassword = (string)($input['new_password'] ?? '');
        $confirmPassword = (string)($input['confirm_password'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $code === '' || strlen($newPassword) < 8 || $newPassword !== $confirmPassword) {
            jsonError('Valid email, 6-digit reset code, and matching passwords (min 8 chars) are required.', 422, 'VALIDATION_ERROR');
        }

        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        if (!$user) {
            jsonError('Invalid email or reset code.', 400, 'INVALID_RESET_CODE');
        }

        $userId = (int)$user['id'];
        $codeHash = hash('sha256', $code);

        $tokStmt = $pdo->prepare('
            SELECT id FROM password_reset_tokens
            WHERE user_id = :uid AND reset_code_hash = :hash AND used_at IS NULL AND expires_at >= UTC_TIMESTAMP()
            ORDER BY id DESC LIMIT 1
        ');
        $tokStmt->execute([':uid' => $userId, ':hash' => $codeHash]);
        $tok = $tokStmt->fetch();

        if (!$tok) {
            jsonError('Reset code is invalid or has expired.', 400, 'INVALID_RESET_CODE');
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
        $pdo->beginTransaction();
        try {
            $pdo->prepare('UPDATE users SET password_hash = :hash WHERE id = :uid')
                ->execute([':hash' => $newHash, ':uid' => $userId]);
            $pdo->prepare('UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() WHERE id = :tid')
                ->execute([':tid' => (int)$tok['id']]);
            // Revoke old active sessions for security
            $pdo->prepare('UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP() WHERE user_id = :uid AND revoked_at IS NULL')
                ->execute([':uid' => $userId]);
            writeAuditLog($pdo, 'user', $userId, 'password_reset_completed', 'user', $userId, 'Password updated via reset code');
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            jsonError('Failed to reset password.', 500, 'RESET_FAILED');
        }

        jsonSuccess(null, 'Password reset successfully. You can now sign in with your new password.');
    }

    public static function logout(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $pdo->prepare('UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP() WHERE id = :sid')
            ->execute([':sid' => $user['session_id']]);
        jsonSuccess(null, 'Logged out successfully.');
    }

    private static function generateUniqueReferralCode(PDO $pdo, string $name): string
    {
        $prefix = strtoupper(preg_replace('/[^A-Za-z]/', '', $name) ?: 'RN');
        $prefix = substr($prefix, 0, 4);
        if (strlen($prefix) < 2) {
            $prefix = 'RNVA';
        }
        for ($i = 0; $i < 10; $i++) {
            $candidate = $prefix . strtoupper(bin2hex(random_bytes(3)));
            $chk = $pdo->prepare('SELECT id FROM users WHERE referral_code = :c LIMIT 1');
            $chk->execute([':c' => $candidate]);
            if (!$chk->fetch()) {
                return $candidate;
            }
        }
        return 'RN' . strtoupper(bin2hex(random_bytes(4)));
    }

    public static function fetchUserSummary(PDO $pdo, int $userId): array
    {
        $stmt = $pdo->prepare('
            SELECT u.id, u.full_name, u.email, u.referral_code, u.account_status, u.phone, u.country, u.registered_at,
                   p.points_balance, p.lifetime_points_earned, p.spins_used_today, p.last_spin_date, p.checkin_streak, p.last_checkin_date,
                   w.cash_balance, w.total_withdrawn, w.pending_withdrawal
            FROM users u
            INNER JOIN user_points p ON p.user_id = u.id
            INNER JOIN cash_wallets w ON w.user_id = u.id
            WHERE u.id = :uid
            LIMIT 1
        ');
        $stmt->execute([':uid' => $userId]);
        $row = $stmt->fetch();
        if (!$row) {
            return [];
        }

        $today = gmdate('Y-m-d');
        $dailyLimit = AppSettings::getInt($pdo, 'daily_spin_limit', 5);
        $spinsUsedToday = ($row['last_spin_date'] === $today) ? (int)$row['spins_used_today'] : 0;

        return [
            'id' => (int)$row['id'],
            'full_name' => $row['full_name'],
            'email' => $row['email'],
            'referral_code' => $row['referral_code'],
            'account_status' => $row['account_status'],
            'phone' => $row['phone'],
            'country' => $row['country'],
            'registered_at' => $row['registered_at'],
            'points_balance' => (int)$row['points_balance'],
            'lifetime_points_earned' => (int)$row['lifetime_points_earned'],
            'cash_balance' => (float)$row['cash_balance'],
            'total_withdrawn' => (float)$row['total_withdrawn'],
            'pending_withdrawal' => (float)$row['pending_withdrawal'],
            'spins_used_today' => $spinsUsedToday,
            'daily_spin_limit' => $dailyLimit,
            'spins_remaining' => max(0, $dailyLimit - $spinsUsedToday),
            'checkin_streak' => (int)$row['checkin_streak'],
            'checked_in_today' => ($row['last_checkin_date'] === $today),
        ];
    }
}
