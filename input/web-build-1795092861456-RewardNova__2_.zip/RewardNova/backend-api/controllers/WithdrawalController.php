<?php
declare(strict_types=1);

final class WithdrawalController
{
    private const ALLOWED_METHODS = ['UPI', 'Bank Transfer', 'JazzCash', 'EasyPaisa', 'Paytm', 'PayPal'];

    public static function listWithdrawals(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];

        $stmt = $pdo->prepare('
            SELECT id, amount_rs, payment_method, account_details, account_holder_name, status, admin_note, processed_at, created_at
            FROM withdrawal_requests
            WHERE user_id = :uid
            ORDER BY id DESC
            LIMIT 50
        ');
        $stmt->execute([':uid' => $userId]);

        $cashStmt = $pdo->prepare('SELECT cash_balance, total_withdrawn, pending_withdrawal FROM cash_wallets WHERE user_id = :uid LIMIT 1');
        $cashStmt->execute([':uid' => $userId]);
        $cash = $cashStmt->fetch() ?: ['cash_balance' => 0, 'total_withdrawn' => 0, 'pending_withdrawal' => 0];

        jsonSuccess([
            'min_withdrawal_rs' => AppSettings::getFloat($pdo, 'min_withdrawal_rs', 100.0),
            'allowed_methods' => self::ALLOWED_METHODS,
            'cash_balance' => (float)$cash['cash_balance'],
            'pending_withdrawal' => (float)$cash['pending_withdrawal'],
            'total_withdrawn' => (float)$cash['total_withdrawn'],
            'withdrawals' => $stmt->fetchAll(),
        ], 'Withdrawals loaded.');
    }

    public static function requestWithdrawal(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'withdraw_' . $userId, getClientIp(), 5, 300);

        $input = getJsonInput();
        $amountRs = round((float)($input['amount_rs'] ?? 0), 2);
        $method = trim((string)($input['payment_method'] ?? ''));
        $accountDetails = trim((string)($input['account_details'] ?? ''));
        $accountHolder = trim((string)($input['account_holder_name'] ?? ''));

        $minWithdrawal = AppSettings::getFloat($pdo, 'min_withdrawal_rs', 100.0);

        if ($amountRs < $minWithdrawal) {
            jsonError("Minimum withdrawal amount is Rs {$minWithdrawal}.", 422, 'BELOW_MINIMUM_WITHDRAWAL');
        }
        if (!in_array($method, self::ALLOWED_METHODS, true)) {
            jsonError('Invalid payment method selected.', 422, 'INVALID_PAYMENT_METHOD');
        }
        if (strlen($accountDetails) < 4 || strlen($accountDetails) > 255) {
            jsonError('Valid payout account details are required.', 422, 'VALIDATION_ERROR');
        }
        if (strlen($accountHolder) < 2 || strlen($accountHolder) > 120) {
            jsonError('Account holder name is required.', 422, 'VALIDATION_ERROR');
        }

        $pdo->beginTransaction();
        try {
            $cashStmt = $pdo->prepare('SELECT cash_balance, pending_withdrawal FROM cash_wallets WHERE user_id = :uid FOR UPDATE');
            $cashStmt->execute([':uid' => $userId]);
            $wallet = $cashStmt->fetch();

            if (!$wallet || (float)$wallet['cash_balance'] < $amountRs) {
                $pdo->rollBack();
                jsonError('Insufficient cash wallet balance. Convert reward points to cash first.', 422, 'INSUFFICIENT_CASH_BALANCE');
            }

            $newCashBalance = round((float)$wallet['cash_balance'] - $amountRs, 2);
            $newPending = round((float)$wallet['pending_withdrawal'] + $amountRs, 2);

            $pdo->prepare('UPDATE cash_wallets SET cash_balance = :cb, pending_withdrawal = :pw WHERE user_id = :uid')
                ->execute([':cb' => $newCashBalance, ':pw' => $newPending, ':uid' => $userId]);

            $ins = $pdo->prepare('
                INSERT INTO withdrawal_requests (user_id, amount_rs, payment_method, account_details, account_holder_name, status)
                VALUES (:uid, :amt, :method, :details, :holder, "pending")
            ');
            $ins->execute([
                ':uid' => $userId,
                ':amt' => $amountRs,
                ':method' => $method,
                ':details' => $accountDetails,
                ':holder' => $accountHolder,
            ]);
            $withdrawalId = (int)$pdo->lastInsertId();

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, cash_amount, balance_after_cash, reference_id, description)
                VALUES (:uid, "cash", "debit", "withdrawal", :amt, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':amt' => $amountRs,
                ':bal' => $newCashBalance,
                ':ref' => 'WD-' . $withdrawalId,
                ':desc' => "Withdrawal request #{$withdrawalId} via {$method}",
            ]);

            $pdo->prepare('
                INSERT INTO notifications (user_id, title, message, type)
                VALUES (:uid, :title, :msg, "withdrawal")
            ')->execute([
                ':uid' => $userId,
                ':title' => 'Withdrawal Request Submitted',
                ':msg' => "Your withdrawal request for Rs {$amountRs} via {$method} is pending admin review.",
            ]);

            writeAuditLog($pdo, 'user', $userId, 'withdrawal_requested', 'withdrawal_request', $withdrawalId, "Requested Rs {$amountRs} via {$method}");
            $pdo->commit();

            jsonSuccess([
                'withdrawal_id' => $withdrawalId,
                'amount_rs' => $amountRs,
                'status' => 'pending',
                'new_cash_balance' => $newCashBalance,
                'pending_withdrawal' => $newPending,
            ], 'Withdrawal request submitted successfully.', 201);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Withdrawal error: ' . $e->getMessage());
            jsonError('Failed to submit withdrawal request.', 500, 'WITHDRAWAL_FAILED');
        }
    }
}
