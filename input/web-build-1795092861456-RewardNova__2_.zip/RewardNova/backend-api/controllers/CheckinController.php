<?php
declare(strict_types=1);

final class CheckinController
{
    public static function getStatus(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        $today = gmdate('Y-m-d');
        $yesterday = gmdate('Y-m-d', strtotime('-1 day'));

        $stmt = $pdo->prepare('SELECT points_balance, checkin_streak, last_checkin_date FROM user_points WHERE user_id = :uid LIMIT 1');
        $stmt->execute([':uid' => $userId]);
        $row = $stmt->fetch();

        $basePts = AppSettings::getInt($pdo, 'daily_checkin_base_points', 25);
        $streakBonus = AppSettings::getInt($pdo, 'daily_checkin_streak_bonus', 15);

        $checkedInToday = ($row && $row['last_checkin_date'] === $today);
        $rawStreak = (int)($row['checkin_streak'] ?? 0);
        $effectiveStreak = ($row && ($row['last_checkin_date'] === $today || $row['last_checkin_date'] === $yesterday)) ? $rawStreak : 0;

        $days = [];
        for ($d = 1; $d <= 7; $d++) {
            $reward = $basePts + (($d - 1) * $streakBonus);
            $cycleDay = $effectiveStreak % 7;
            if ($effectiveStreak > 0 && $cycleDay === 0 && $checkedInToday) {
                $cycleDay = 7;
            }
            $days[] = [
                'day' => $d,
                'reward_points' => $reward,
                'claimed' => $d <= $cycleDay,
            ];
        }

        $nextCycleIndex = ($effectiveStreak % 7);
        $todayReward = $basePts + ($nextCycleIndex * $streakBonus);

        jsonSuccess([
            'checked_in_today' => $checkedInToday,
            'current_streak' => $effectiveStreak,
            'today_reward_points' => $todayReward,
            'points_balance' => (int)($row['points_balance'] ?? 0),
            'days' => $days,
        ], 'Daily check-in status loaded.');
    }

    public static function claimDailyCheckin(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'checkin_' . $userId, getClientIp(), 10, 60);

        $today = gmdate('Y-m-d');
        $yesterday = gmdate('Y-m-d', strtotime('-1 day'));
        $basePts = AppSettings::getInt($pdo, 'daily_checkin_base_points', 25);
        $streakBonus = AppSettings::getInt($pdo, 'daily_checkin_streak_bonus', 15);

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT points_balance, checkin_streak, last_checkin_date FROM user_points WHERE user_id = :uid FOR UPDATE');
            $stmt->execute([':uid' => $userId]);
            $row = $stmt->fetch();

            if (!$row) {
                $pdo->rollBack();
                jsonError('User points account not found.', 500, 'POINTS_MISSING');
            }

            if ($row['last_checkin_date'] === $today) {
                $pdo->rollBack();
                jsonError('You have already claimed today\'s daily check-in bonus.', 409, 'ALREADY_CHECKED_IN');
            }

            $newStreak = ($row['last_checkin_date'] === $yesterday) ? ((int)$row['checkin_streak'] + 1) : 1;
            $cycleIndex = ($newStreak - 1) % 7;
            $pointsAwarded = $basePts + ($cycleIndex * $streakBonus);
            $newBalance = (int)$row['points_balance'] + $pointsAwarded;

            $pdo->prepare('
                UPDATE user_points
                SET points_balance = :bal,
                    lifetime_points_earned = lifetime_points_earned + :pts,
                    checkin_streak = :streak,
                    last_checkin_date = :dt
                WHERE user_id = :uid
            ')->execute([
                ':bal' => $newBalance,
                ':pts' => $pointsAwarded,
                ':streak' => $newStreak,
                ':dt' => $today,
                ':uid' => $userId,
            ]);

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                VALUES (:uid, "points", "credit", "checkin", :pts, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':pts' => $pointsAwarded,
                ':bal' => $newBalance,
                ':ref' => 'CHECKIN-' . $today,
                ':desc' => "Daily Check-in Day {$newStreak} bonus",
            ]);

            $pdo->commit();

            jsonSuccess([
                'checked_in_today' => true,
                'current_streak' => $newStreak,
                'points_awarded' => $pointsAwarded,
                'new_points_balance' => $newBalance,
            ], "Day {$newStreak} check-in bonus (+{$pointsAwarded} pts) credited!");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Check-in error: ' . $e->getMessage());
            jsonError('Daily check-in failed.', 500, 'CHECKIN_FAILED');
        }
    }
}
