<?php
declare(strict_types=1);

final class ConfigController
{
    public static function getPublicConfig(PDO $pdo): never
    {
        $settings = AppSettings::all($pdo);
        $adsRows = $pdo->query('
            SELECT ad_format, ad_unit_id, is_test_mode, is_enabled, reward_points, daily_cap
            FROM advertisements_settings
            ORDER BY id ASC
        ')->fetchAll();

        $adsMap = [];
        foreach ($adsRows as $ad) {
            $adsMap[$ad['ad_format']] = [
                'ad_unit_id' => $ad['ad_unit_id'],
                'is_test_mode' => ((int)$ad['is_test_mode']) === 1,
                'is_enabled' => ((int)$ad['is_enabled']) === 1,
                'reward_points' => (int)$ad['reward_points'],
                'daily_cap' => (int)$ad['daily_cap'],
            ];
        }

        jsonSuccess([
            'app_name' => $settings['app_name'] ?? 'RewardNova',
            'points_per_rupee' => (int)($settings['points_per_rupee'] ?? 1000),
            'min_withdrawal_rs' => (float)($settings['min_withdrawal_rs'] ?? 100),
            'daily_spin_limit' => (int)($settings['daily_spin_limit'] ?? 5),
            'daily_checkin_base_points' => (int)($settings['daily_checkin_base_points'] ?? 25),
            'daily_checkin_streak_bonus' => (int)($settings['daily_checkin_streak_bonus'] ?? 15),
            'referral_referrer_points' => (int)($settings['referral_referrer_points'] ?? 250),
            'referral_referred_points' => (int)($settings['referral_referred_points'] ?? 100),
            'support_email' => $settings['support_email'] ?? 'support@rewardnova.local',
            'privacy_policy_url' => $settings['privacy_policy_url'] ?? '',
            'terms_url' => $settings['terms_url'] ?? '',
            'maintenance_mode' => (($settings['maintenance_mode'] ?? '0') === '1'),
            'admob' => $adsMap,
        ], 'App configuration loaded.');
    }
}
