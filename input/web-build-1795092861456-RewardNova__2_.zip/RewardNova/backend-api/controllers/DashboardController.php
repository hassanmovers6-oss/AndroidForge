<?php
declare(strict_types=1);

final class DashboardController
{
    public static function getDashboard(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        $summary = AuthController::fetchUserSummary($pdo, $userId);

        $pointsPerRupee = max(1, AppSettings::getInt($pdo, 'points_per_rupee', 1000));
        $minWithdrawalRs = AppSettings::getFloat($pdo, 'min_withdrawal_rs', 100.0);

        $unreadStmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE (user_id = :uid OR user_id IS NULL) AND is_read = 0');
        $unreadStmt->execute([':uid' => $userId]);
        $unreadCount = (int)$unreadStmt->fetchColumn();

        $tasksCountStmt = $pdo->query('SELECT COUNT(*) FROM tasks WHERE is_active = 1');
        $activeTasksCount = (int)$tasksCountStmt->fetchColumn();

        $recentTxStmt = $pdo->prepare('
            SELECT id, wallet_type, tx_type, category, points_amount, cash_amount, description, created_at
            FROM wallet_transactions
            WHERE user_id = :uid
            ORDER BY id DESC
            LIMIT 5
        ');
        $recentTxStmt->execute([':uid' => $userId]);

        jsonSuccess([
            'user' => $summary,
            'rules' => [
                'points_per_rupee' => $pointsPerRupee,
                'min_withdrawal_rs' => $minWithdrawalRs,
                'daily_spin_limit' => $summary['daily_spin_limit'],
                'convertible_cash_estimate' => round($summary['points_balance'] / $pointsPerRupee, 2),
            ],
            'unread_notifications' => $unreadCount,
            'active_tasks_count' => $activeTasksCount,
            'recent_transactions' => $recentTxStmt->fetchAll(),
        ], 'Dashboard loaded.');
    }
}
