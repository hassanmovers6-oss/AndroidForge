<?php
declare(strict_types=1);

final class TaskController
{
    public static function listTasks(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        $today = gmdate('Y-m-d');

        $tasks = $pdo->query('
            SELECT id, title, description, task_type, action_url, reward_points, is_repeatable_daily, requires_proof
            FROM tasks
            WHERE is_active = 1
            ORDER BY sort_order ASC, id ASC
        ')->fetchAll();

        $subStmt = $pdo->prepare('SELECT task_id, submission_date, status, points_awarded, created_at FROM task_submissions WHERE user_id = :uid ORDER BY id DESC');
        $subStmt->execute([':uid' => $userId]);
        $submissions = $subStmt->fetchAll();

        $completedToday = [];
        $completedEver = [];
        foreach ($submissions as $s) {
            $tid = (int)$s['task_id'];
            if (!isset($completedEver[$tid])) {
                $completedEver[$tid] = $s;
            }
            if ($s['submission_date'] === $today) {
                $completedToday[$tid] = $s;
            }
        }

        $result = [];
        foreach ($tasks as $t) {
            $tid = (int)$t['id'];
            $isDaily = ((int)$t['is_repeatable_daily']) === 1;
            $matched = $isDaily ? ($completedToday[$tid] ?? null) : ($completedEver[$tid] ?? null);

            $result[] = [
                'id' => $tid,
                'title' => $t['title'],
                'description' => $t['description'],
                'task_type' => $t['task_type'],
                'action_url' => $t['action_url'],
                'reward_points' => (int)$t['reward_points'],
                'is_repeatable_daily' => $isDaily,
                'requires_proof' => ((int)$t['requires_proof']) === 1,
                'is_completed' => $matched !== null,
                'submission_status' => $matched ? $matched['status'] : 'available',
                'last_completed_at' => $matched ? $matched['created_at'] : null,
            ];
        }

        jsonSuccess(['tasks' => $result], 'Tasks retrieved.');
    }

    public static function submitTask(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'task_submit_' . $userId, getClientIp(), 20, 60);

        $input = getJsonInput();
        $taskId = (int)($input['task_id'] ?? 0);
        $proofText = isset($input['proof_text']) ? trim((string)$input['proof_text']) : '';

        if ($taskId <= 0) {
            jsonError('Valid task_id is required.', 422, 'VALIDATION_ERROR');
        }

        $today = gmdate('Y-m-d');
        $pdo->beginTransaction();

        try {
            $taskStmt = $pdo->prepare('SELECT * FROM tasks WHERE id = :tid AND is_active = 1 LIMIT 1');
            $taskStmt->execute([':tid' => $taskId]);
            $task = $taskStmt->fetch();

            if (!$task) {
                $pdo->rollBack();
                jsonError('Task not found or no longer active.', 404, 'TASK_NOT_FOUND');
            }

            // Lock user points row to serialize concurrent submissions by the same user
            $ptsStmt = $pdo->prepare('SELECT points_balance FROM user_points WHERE user_id = :uid FOR UPDATE');
            $ptsStmt->execute([':uid' => $userId]);
            $currentPoints = (int)$ptsStmt->fetchColumn();

            $isDaily = ((int)$task['is_repeatable_daily']) === 1;
            if ($isDaily) {
                $dupStmt = $pdo->prepare('SELECT id FROM task_submissions WHERE user_id = :uid AND task_id = :tid AND submission_date = :dt LIMIT 1');
                $dupStmt->execute([':uid' => $userId, ':tid' => $taskId, ':dt' => $today]);
            } else {
                $dupStmt = $pdo->prepare('SELECT id FROM task_submissions WHERE user_id = :uid AND task_id = :tid LIMIT 1');
                $dupStmt->execute([':uid' => $userId, ':tid' => $taskId]);
            }

            if ($dupStmt->fetch()) {
                $pdo->rollBack();
                jsonError(
                    $isDaily ? 'You have already completed this daily task today.' : 'You have already completed this task.',
                    409,
                    'DUPLICATE_TASK_SUBMISSION'
                );
            }

            if (((int)$task['requires_proof']) === 1) {
                if (strlen($proofText) < 2) {
                    $pdo->rollBack();
                    jsonError('Please enter valid verification details for this task.', 422, 'PROOF_REQUIRED');
                }
                $keyword = trim((string)($task['verification_keyword'] ?? ''));
                if ($keyword !== '' && stripos($proofText, $keyword) === false) {
                    $pdo->rollBack();
                    jsonError('Submitted verification details did not pass validation.', 422, 'PROOF_VALIDATION_FAILED');
                }
            }

            // Reward points come strictly from the database, never from client input
            $rewardPoints = (int)$task['reward_points'];
            $newBalance = $currentPoints + $rewardPoints;

            $insSub = $pdo->prepare('
                INSERT INTO task_submissions (user_id, task_id, submission_date, proof_text, status, points_awarded, approved_by_system, ip_address)
                VALUES (:uid, :tid, :dt, :proof, "approved", :pts, 1, :ip)
            ');
            $insSub->execute([
                ':uid' => $userId,
                ':tid' => $taskId,
                ':dt' => $today,
                ':proof' => $proofText !== '' ? substr($proofText, 0, 500) : null,
                ':pts' => $rewardPoints,
                ':ip' => getClientIp(),
            ]);
            $submissionId = (int)$pdo->lastInsertId();

            $pdo->prepare('UPDATE user_points SET points_balance = :bal, lifetime_points_earned = lifetime_points_earned + :pts WHERE user_id = :uid')
                ->execute([':bal' => $newBalance, ':pts' => $rewardPoints, ':uid' => $userId]);

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                VALUES (:uid, "points", "credit", "task", :pts, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':pts' => $rewardPoints,
                ':bal' => $newBalance,
                ':ref' => 'TASK-' . $submissionId,
                ':desc' => 'Auto-approved task: ' . $task['title'],
            ]);

            writeAuditLog($pdo, 'system', $userId, 'task_auto_approved', 'task_submission', $submissionId, "Awarded {$rewardPoints} pts for task #{$taskId}");
            $pdo->commit();

            jsonSuccess([
                'submission_id' => $submissionId,
                'task_id' => $taskId,
                'status' => 'approved',
                'points_awarded' => $rewardPoints,
                'new_points_balance' => $newBalance,
            ], 'Task approved and points credited immediately.');
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ((string)$e->getCode() === '23000') {
                jsonError('Duplicate task submission prevented.', 409, 'DUPLICATE_TASK_SUBMISSION');
            }
            error_log('Task submit error: ' . $e->getMessage());
            jsonError('Failed to submit task.', 500, 'TASK_SUBMIT_FAILED');
        }
    }
}
