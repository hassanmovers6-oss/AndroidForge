<?php
declare(strict_types=1);

final class AdRewardController
{
    public static function issueRewardNonce(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'ad_nonce_' . $userId, getClientIp(), 20, 60);

        $input = getJsonInput();
        $adFormat = ($input['ad_format'] ?? 'rewarded') === 'rewarded_interstitial'
            ? 'rewarded_interstitial'
            : 'rewarded';

        $adStmt = $pdo->prepare('SELECT is_enabled, reward_points, daily_cap FROM advertisements_settings WHERE ad_format = :fmt LIMIT 1');
        $adStmt->execute([':fmt' => $adFormat]);
        $adCfg = $adStmt->fetch();

        if (!$adCfg || ((int)$adCfg['is_enabled']) !== 1 || (int)$adCfg['reward_points'] <= 0) {
            jsonError('This rewarded ad format is currently disabled.', 403, 'AD_FORMAT_DISABLED');
        }

        $todayCountStmt = $pdo->prepare('
            SELECT COUNT(*) FROM ad_reward_verifications
            WHERE user_id = :uid AND ad_format = :fmt AND status = "verified" AND DATE(verified_at) = CURDATE()
        ');
        $todayCountStmt->execute([':uid' => $userId, ':fmt' => $adFormat]);
        $todayCount = (int)$todayCountStmt->fetchColumn();

        if ((int)$adCfg['daily_cap'] > 0 && $todayCount >= (int)$adCfg['daily_cap']) {
            jsonError('Daily rewarded ad limit reached for today.', 429, 'AD_DAILY_CAP_REACHED');
        }

        $nonce = bin2hex(random_bytes(24));
        $pdo->prepare('INSERT INTO ad_reward_verifications (user_id, ad_format, nonce, status) VALUES (:uid, :fmt, :nonce, "issued")')
            ->execute([':uid' => $userId, ':fmt' => $adFormat, ':nonce' => $nonce]);

        jsonSuccess([
            'ad_nonce' => $nonce,
            'ad_format' => $adFormat,
            'reward_points' => (int)$adCfg['reward_points'],
        ], 'Ad verification session issued.');
    }

    public static function verifyAndCreditAdReward(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'ad_verify_' . $userId, getClientIp(), 20, 60);

        $input = getJsonInput();
        $nonce = trim((string)($input['ad_nonce'] ?? ''));

        if ($nonce === '') {
            jsonError('ad_nonce is required for server-side ad reward verification.', 422, 'VALIDATION_ERROR');
        }

        $pdo->beginTransaction();
        try {
            $verStmt = $pdo->prepare('
                SELECT id, ad_format, status, issued_at
                FROM ad_reward_verifications
                WHERE user_id = :uid AND nonce = :nonce
                LIMIT 1 FOR UPDATE
            ');
            $verStmt->execute([':uid' => $userId, ':nonce' => $nonce]);
            $ver = $verStmt->fetch();

            if (!$ver) {
                $pdo->rollBack();
                jsonError('Invalid ad verification token.', 404, 'INVALID_AD_NONCE');
            }
            if ($ver['status'] === 'verified') {
                $pdo->rollBack();
                jsonError('Reward for this ad view was already credited.', 409, 'DUPLICATE_AD_CLAIM');
            }

            $adStmt = $pdo->prepare('SELECT is_enabled, reward_points, daily_cap FROM advertisements_settings WHERE ad_format = :fmt LIMIT 1');
            $adStmt->execute([':fmt' => $ver['ad_format']]);
            $adCfg = $adStmt->fetch();

            if (!$adCfg || ((int)$adCfg['is_enabled']) !== 1) {
                $pdo->rollBack();
                jsonError('Rewarded ad is disabled.', 403, 'AD_DISABLED');
            }

            $todayCountStmt = $pdo->prepare('
                SELECT COUNT(*) FROM ad_reward_verifications
                WHERE user_id = :uid AND ad_format = :fmt AND status = "verified" AND DATE(verified_at) = CURDATE()
            ');
            $todayCountStmt->execute([':uid' => $userId, ':fmt' => $ver['ad_format']]);
            if ((int)$adCfg['daily_cap'] > 0 && (int)$todayCountStmt->fetchColumn() >= (int)$adCfg['daily_cap']) {
                $pdo->rollBack();
                jsonError('Daily rewarded ad cap reached.', 429, 'AD_DAILY_CAP_REACHED');
            }

            // Server dictates reward amount strictly from advertisements_settings
            $rewardPoints = (int)$adCfg['reward_points'];

            $ptsStmt = $pdo->prepare('SELECT points_balance FROM user_points WHERE user_id = :uid FOR UPDATE');
            $ptsStmt->execute([':uid' => $userId]);
            $currentPoints = (int)$ptsStmt->fetchColumn();
            $newBalance = $currentPoints + $rewardPoints;

            $pdo->prepare('UPDATE ad_reward_verifications SET status = "verified", points_awarded = :pts, verified_at = UTC_TIMESTAMP() WHERE id = :id')
                ->execute([':pts' => $rewardPoints, ':id' => (int)$ver['id']]);

            $pdo->prepare('UPDATE user_points SET points_balance = :bal, lifetime_points_earned = lifetime_points_earned + :pts WHERE user_id = :uid')
                ->execute([':bal' => $newBalance, ':pts' => $rewardPoints, ':uid' => $userId]);

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                VALUES (:uid, "points", "credit", "ad_reward", :pts, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':pts' => $rewardPoints,
                ':bal' => $newBalance,
                ':ref' => 'AD-' . $ver['id'],
                ':desc' => 'Verified ' . str_replace('_', ' ', $ver['ad_format']) . ' completion',
            ]);

            $pdo->commit();

            jsonSuccess([
                'points_awarded' => $rewardPoints,
                'new_points_balance' => $newBalance,
            ], "Verified ad reward (+{$rewardPoints} pts) credited!");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Ad verify error: ' . $e->getMessage());
            jsonError('Ad verification failed.', 500, 'AD_VERIFY_FAILED');
        }
    }
}
