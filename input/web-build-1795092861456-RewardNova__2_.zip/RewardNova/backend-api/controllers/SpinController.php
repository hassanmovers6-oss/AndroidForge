<?php
declare(strict_types=1);

final class SpinController
{
    public static function getWheel(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        $today = gmdate('Y-m-d');
        $dailyLimit = AppSettings::getInt($pdo, 'daily_spin_limit', 5);

        $ptsStmt = $pdo->prepare('SELECT points_balance, spins_used_today, last_spin_date FROM user_points WHERE user_id = :uid LIMIT 1');
        $ptsStmt->execute([':uid' => $userId]);
        $ptsRow = $ptsStmt->fetch();

        $spinsUsedToday = ($ptsRow && $ptsRow['last_spin_date'] === $today) ? (int)$ptsRow['spins_used_today'] : 0;

        $segments = $pdo->query('
            SELECT id, segment_index, label, points_reward, color_hex
            FROM spin_reward_settings
            WHERE is_active = 1
            ORDER BY segment_index ASC
        ')->fetchAll();

        // Issue a fresh server nonce for the next spin request to guarantee idempotency
        $suggestedNonce = bin2hex(random_bytes(16));

        jsonSuccess([
            'segments' => array_map(static fn(array $s): array => [
                'id' => (int)$s['id'],
                'segment_index' => (int)$s['segment_index'],
                'label' => $s['label'],
                'points_reward' => (int)$s['points_reward'],
                'color_hex' => $s['color_hex'],
            ], $segments),
            'daily_spin_limit' => $dailyLimit,
            'spins_used_today' => $spinsUsedToday,
            'spins_remaining' => max(0, $dailyLimit - $spinsUsedToday),
            'points_balance' => (int)($ptsRow['points_balance'] ?? 0),
            'spin_nonce' => $suggestedNonce,
        ], 'Spin wheel configuration loaded.');
    }

    public static function executeSpin(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'spin_exec_' . $userId, getClientIp(), 15, 60);

        $input = getJsonInput();
        $requestNonce = trim((string)($input['request_nonce'] ?? ''));
        if ($requestNonce === '' || strlen($requestNonce) < 8 || strlen($requestNonce) > 64) {
            $requestNonce = bin2hex(random_bytes(16));
        }

        $today = gmdate('Y-m-d');
        $dailyLimit = AppSettings::getInt($pdo, 'daily_spin_limit', 5);

        $pdo->beginTransaction();
        try {
            // Lock user_points row to enforce strict daily spin limit & serialize parallel spin requests
            $ptsStmt = $pdo->prepare('SELECT points_balance, spins_used_today, last_spin_date FROM user_points WHERE user_id = :uid FOR UPDATE');
            $ptsStmt->execute([':uid' => $userId]);
            $ptsRow = $ptsStmt->fetch();

            if (!$ptsRow) {
                $pdo->rollBack();
                jsonError('User points account not initialized.', 500, 'POINTS_ACCOUNT_MISSING');
            }

            // Check duplicate request_nonce (prevents replay / double tap awarding duplicate points)
            $nonceChk = $pdo->prepare('SELECT id FROM spin_history WHERE user_id = :uid AND request_nonce = :nonce LIMIT 1');
            $nonceChk->execute([':uid' => $userId, ':nonce' => $requestNonce]);
            if ($nonceChk->fetch()) {
                $pdo->rollBack();
                jsonError('Duplicate spin request detected. No additional points awarded.', 409, 'DUPLICATE_SPIN_REQUEST');
            }

            $spinsUsedToday = ($ptsRow['last_spin_date'] === $today) ? (int)$ptsRow['spins_used_today'] : 0;
            if ($spinsUsedToday >= $dailyLimit) {
                $pdo->rollBack();
                jsonError("Daily spin limit of {$dailyLimit} spins reached. Come back tomorrow.", 429, 'DAILY_SPIN_LIMIT_REACHED');
            }

            $segments = $pdo->query('
                SELECT id, segment_index, label, points_reward, weight, color_hex
                FROM spin_reward_settings
                WHERE is_active = 1 AND weight > 0
                ORDER BY segment_index ASC
            ')->fetchAll();

            if (empty($segments)) {
                $pdo->rollBack();
                jsonError('Spin wheel rewards are not configured.', 500, 'SPIN_NOT_CONFIGURED');
            }

            // Server-authoritative weighted random selection
            $totalWeight = 0;
            foreach ($segments as $seg) {
                $totalWeight += (int)$seg['weight'];
            }
            $roll = random_int(1, $totalWeight);
            $cumulative = 0;
            $winningSegment = $segments[0];
            foreach ($segments as $seg) {
                $cumulative += (int)$seg['weight'];
                if ($roll <= $cumulative) {
                    $winningSegment = $seg;
                    break;
                }
            }

            $pointsWon = (int)$winningSegment['points_reward'];
            $newSpinsUsed = $spinsUsedToday + 1;
            $newPointsBalance = (int)$ptsRow['points_balance'] + $pointsWon;

            // Deduct 1 daily spin and credit points immediately
            $pdo->prepare('
                UPDATE user_points
                SET points_balance = :bal,
                    lifetime_points_earned = lifetime_points_earned + :won,
                    spins_used_today = :spins,
                    last_spin_date = :dt
                WHERE user_id = :uid
            ')->execute([
                ':bal' => $newPointsBalance,
                ':won' => $pointsWon,
                ':spins' => $newSpinsUsed,
                ':dt' => $today,
                ':uid' => $userId,
            ]);

            $insHistory = $pdo->prepare('
                INSERT INTO spin_history (user_id, segment_id, segment_label, points_won, request_nonce, spin_date, ip_address)
                VALUES (:uid, :seg_id, :label, :won, :nonce, :dt, :ip)
            ');
            $insHistory->execute([
                ':uid' => $userId,
                ':seg_id' => (int)$winningSegment['id'],
                ':label' => $winningSegment['label'],
                ':won' => $pointsWon,
                ':nonce' => $requestNonce,
                ':dt' => $today,
                ':ip' => getClientIp(),
            ]);
            $spinId = (int)$pdo->lastInsertId();

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                VALUES (:uid, "points", "credit", "spin", :pts, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':pts' => $pointsWon,
                ':bal' => $newPointsBalance,
                ':ref' => 'SPIN-' . $spinId,
                ':desc' => 'Spin & Earn reward: ' . $winningSegment['label'],
            ]);

            $pdo->commit();

            jsonSuccess([
                'spin_id' => $spinId,
                'winning_segment' => [
                    'id' => (int)$winningSegment['id'],
                    'segment_index' => (int)$winningSegment['segment_index'],
                    'label' => $winningSegment['label'],
                    'points_reward' => $pointsWon,
                    'color_hex' => $winningSegment['color_hex'],
                ],
                'points_won' => $pointsWon,
                'new_points_balance' => $newPointsBalance,
                'spins_used_today' => $newSpinsUsed,
                'daily_spin_limit' => $dailyLimit,
                'spins_remaining' => max(0, $dailyLimit - $newSpinsUsed),
                'next_spin_nonce' => bin2hex(random_bytes(16)),
            ], "You won {$pointsWon} points!");
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ((string)$e->getCode() === '23000') {
                jsonError('Duplicate spin request prevented.', 409, 'DUPLICATE_SPIN_REQUEST');
            }
            error_log('Spin error: ' . $e->getMessage());
            jsonError('Spin execution failed.', 500, 'SPIN_FAILED');
        }
    }

    public static function getHistory(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];

        $stmt = $pdo->prepare('
            SELECT id, segment_label, points_won, spin_date, created_at
            FROM spin_history
            WHERE user_id = :uid
            ORDER BY id DESC
            LIMIT 50
        ');
        $stmt->execute([':uid' => $userId]);

        jsonSuccess(['history' => $stmt->fetchAll()], 'Spin history loaded.');
    }
}
