<?php
declare(strict_types=1);

final class ReferralController
{
    public static function getReferrals(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];

        $listStmt = $pdo->prepare('
            SELECT r.id, u.full_name, u.registered_at, r.status, COALESCE(rr.points_awarded, 0) AS points_earned
            FROM referrals r
            INNER JOIN users u ON u.id = r.referred_user_id
            LEFT JOIN referral_rewards rr ON rr.referral_id = r.id AND rr.beneficiary_user_id = :uid_rr AND rr.reward_role = "referrer"
            WHERE r.referrer_user_id = :uid
            ORDER BY r.id DESC
            LIMIT 100
        ');
        $listStmt->execute([':uid_rr' => $userId, ':uid' => $userId]);
        $referredUsers = $listStmt->fetchAll();

        $totalPoints = 0;
        foreach ($referredUsers as $item) {
            $totalPoints += (int)$item['points_earned'];
        }

        jsonSuccess([
            'referral_code' => $user['referral_code'],
            'referrer_bonus_points' => AppSettings::getInt($pdo, 'referral_referrer_points', 250),
            'referred_bonus_points' => AppSettings::getInt($pdo, 'referral_referred_points', 100),
            'total_referrals' => count($referredUsers),
            'total_referral_points' => $totalPoints,
            'referrals' => $referredUsers,
        ], 'Referrals loaded.');
    }
}
