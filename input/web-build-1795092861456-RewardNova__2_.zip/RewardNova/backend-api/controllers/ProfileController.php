<?php
declare(strict_types=1);

final class ProfileController
{
    public static function getProfile(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $summary = AuthController::fetchUserSummary($pdo, (int)$user['id']);
        jsonSuccess($summary, 'Profile loaded.');
    }

    public static function updateProfile(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $input = getJsonInput();
        $userId = (int)$user['id'];

        $fullName = trim((string)($input['full_name'] ?? $user['full_name']));
        $phone = isset($input['phone']) ? trim((string)$input['phone']) : $user['phone'];
        $country = isset($input['country']) ? trim((string)$input['country']) : $user['country'];

        if (strlen($fullName) < 2 || strlen($fullName) > 120) {
            jsonError('Full name must be between 2 and 120 characters.', 422, 'VALIDATION_ERROR');
        }

        $stmt = $pdo->prepare('UPDATE users SET full_name = :name, phone = :phone, country = :country WHERE id = :uid');
        $stmt->execute([
            ':name' => $fullName,
            ':phone' => $phone !== '' ? substr((string)$phone, 0, 30) : null,
            ':country' => $country !== '' ? substr((string)$country, 0, 80) : 'PK',
            ':uid' => $userId,
        ]);

        writeAuditLog($pdo, 'user', $userId, 'profile_updated', 'user', $userId, 'Profile details updated');
        jsonSuccess(AuthController::fetchUserSummary($pdo, $userId), 'Profile updated successfully.');
    }

    public static function changePassword(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $input = getJsonInput();
        $userId = (int)$user['id'];

        $current = (string)($input['current_password'] ?? '');
        $newPass = (string)($input['new_password'] ?? '');
        $confirm = (string)($input['confirm_password'] ?? '');

        if ($current === '' || strlen($newPass) < 8 || $newPass !== $confirm) {
            jsonError('Provide current password and matching new passwords (min 8 chars).', 422, 'VALIDATION_ERROR');
        }

        $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = :uid LIMIT 1');
        $stmt->execute([':uid' => $userId]);
        $hash = (string)$stmt->fetchColumn();

        if (!password_verify($current, $hash)) {
            jsonError('Current password is incorrect.', 401, 'INVALID_PASSWORD');
        }

        $newHash = password_hash($newPass, PASSWORD_BCRYPT, ['cost' => 12]);
        $pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :uid')->execute([':h' => $newHash, ':uid' => $userId]);
        writeAuditLog($pdo, 'user', $userId, 'password_changed', 'user', $userId, 'User changed password');

        jsonSuccess(null, 'Password changed successfully.');
    }
}
