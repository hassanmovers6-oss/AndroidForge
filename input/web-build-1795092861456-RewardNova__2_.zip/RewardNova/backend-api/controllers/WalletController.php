<?php
declare(strict_types=1);

final class WalletController
{
    public static function getWallet(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];

        $ptsStmt = $pdo->prepare('SELECT points_balance, lifetime_points_earned, lifetime_points_converted FROM user_points WHERE user_id = :uid LIMIT 1');
        $ptsStmt->execute([':uid' => $userId]);
        $pts = $ptsStmt->fetch() ?: ['points_balance' => 0, 'lifetime_points_earned' => 0, 'lifetime_points_converted' => 0];

        $cashStmt = $pdo->prepare('SELECT cash_balance, total_withdrawn, pending_withdrawal FROM cash_wallets WHERE user_id = :uid LIMIT 1');
        $cashStmt->execute([':uid' => $userId]);
        $cash = $cashStmt->fetch() ?: ['cash_balance' => 0, 'total_withdrawn' => 0, 'pending_withdrawal' => 0];

        $pointsPerRupee = max(1, AppSettings::getInt($pdo, 'points_per_rupee', 1000));
        $minWithdrawalRs = AppSettings::getFloat($pdo, 'min_withdrawal_rs', 100.0);

        $pointsBalance = (int)$pts['points_balance'];
        $convertibleRupees = floor($pointsBalance / $pointsPerRupee);

        jsonSuccess([
            'points_wallet' => [
                'points_balance' => $pointsBalance,
                'lifetime_points_earned' => (int)$pts['lifetime_points_earned'],
                'lifetime_points_converted' => (int)$pts['lifetime_points_converted'],
                'convertible_rupees' => (float)$convertibleRupees,
                'convertible_points_needed' => (int)($convertibleRupees * $pointsPerRupee),
            ],
            'cash_wallet' => [
                'cash_balance' => (float)$cash['cash_balance'],
                'total_withdrawn' => (float)$cash['total_withdrawn'],
                'pending_withdrawal' => (float)$cash['pending_withdrawal'],
            ],
            'conversion_rules' => [
                'points_per_rupee' => $pointsPerRupee,
                'min_withdrawal_rs' => $minWithdrawalRs,
            ],
        ], 'Wallet loaded.');
    }

    public static function convertPointsToCash(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        enforceRateLimit($pdo, 'wallet_convert_' . $userId, getClientIp(), 10, 60);

        $input = getJsonInput();
        $pointsPerRupee = max(1, AppSettings::getInt($pdo, 'points_per_rupee', 1000));
        $requestedPoints = (int)($input['points'] ?? 0);

        if ($requestedPoints < $pointsPerRupee) {
            jsonError("Minimum {$pointsPerRupee} points (Rs 1) required to convert.", 422, 'INSUFFICIENT_CONVERSION_AMOUNT');
        }

        // Convert exact whole-rupee increments so no fractional points are lost
        $rupeesToCredit = intdiv($requestedPoints, $pointsPerRupee);
        $pointsToDeduct = $rupeesToCredit * $pointsPerRupee;

        $pdo->beginTransaction();
        try {
            $ptsStmt = $pdo->prepare('SELECT points_balance FROM user_points WHERE user_id = :uid FOR UPDATE');
            $ptsStmt->execute([':uid' => $userId]);
            $currentPoints = (int)$ptsStmt->fetchColumn();

            if ($currentPoints < $pointsToDeduct) {
                $pdo->rollBack();
                jsonError('Insufficient reward points balance for this conversion.', 422, 'INSUFFICIENT_POINTS');
            }

            $cashStmt = $pdo->prepare('SELECT cash_balance FROM cash_wallets WHERE user_id = :uid FOR UPDATE');
            $cashStmt->execute([':uid' => $userId]);
            $currentCash = (float)$cashStmt->fetchColumn();

            $newPoints = $currentPoints - $pointsToDeduct;
            $newCash = round($currentCash + $rupeesToCredit, 2);

            $pdo->prepare('
                UPDATE user_points
                SET points_balance = :bal, lifetime_points_converted = lifetime_points_converted + :ded
                WHERE user_id = :uid
            ')->execute([':bal' => $newPoints, ':ded' => $pointsToDeduct, ':uid' => $userId]);

            $pdo->prepare('UPDATE cash_wallets SET cash_balance = :cbal WHERE user_id = :uid')
                ->execute([':cbal' => $newCash, ':uid' => $userId]);

            $ref = 'CONV-' . time() . '-' . $userId;

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                VALUES (:uid, "points", "debit", "points_conversion", :pts, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':pts' => $pointsToDeduct,
                ':bal' => $newPoints,
                ':ref' => $ref,
                ':desc' => "Converted {$pointsToDeduct} pts to Rs {$rupeesToCredit}",
            ]);

            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, cash_amount, balance_after_cash, reference_id, description)
                VALUES (:uid, "cash", "credit", "points_conversion", :cash, :cbal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':cash' => $rupeesToCredit,
                ':cbal' => $newCash,
                ':ref' => $ref,
                ':desc' => "Credited Rs {$rupeesToCredit} from {$pointsToDeduct} reward points",
            ]);

            writeAuditLog($pdo, 'user', $userId, 'points_converted_to_cash', 'cash_wallet', $userId, "Converted {$pointsToDeduct} pts -> Rs {$rupeesToCredit}");
            $pdo->commit();

            jsonSuccess([
                'points_deducted' => $pointsToDeduct,
                'cash_credited_rs' => (float)$rupeesToCredit,
                'new_points_balance' => $newPoints,
                'new_cash_balance' => $newCash,
            ], "Successfully converted {$pointsToDeduct} points to Rs {$rupeesToCredit}.");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Conversion error: ' . $e->getMessage());
            jsonError('Failed to convert points.', 500, 'CONVERSION_FAILED');
        }
    }

    public static function getTransactions(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        $walletFilter = $_GET['wallet_type'] ?? 'all';

        $sql = '
            SELECT id, wallet_type, tx_type, category, points_amount, cash_amount, balance_after_points, balance_after_cash, reference_id, description, created_at
            FROM wallet_transactions
            WHERE user_id = :uid
        ';
        $params = [':uid' => $userId];
        if (in_array($walletFilter, ['points', 'cash'], true)) {
            $sql .= ' AND wallet_type = :wtype';
            $params[':wtype'] = $walletFilter;
        }
        $sql .= ' ORDER BY id DESC LIMIT 100';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        jsonSuccess(['transactions' => $stmt->fetchAll()], 'Transactions loaded.');
    }
}
