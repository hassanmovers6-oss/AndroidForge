<?php
declare(strict_types=1);

final class NotificationController
{
    public static function listNotifications(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];

        $stmt = $pdo->prepare('
            SELECT id, user_id, title, message, type, is_read, created_at
            FROM notifications
            WHERE user_id = :uid OR user_id IS NULL
            ORDER BY id DESC
            LIMIT 50
        ');
        $stmt->execute([':uid' => $userId]);

        jsonSuccess(['notifications' => $stmt->fetchAll()], 'Notifications loaded.');
    }

    public static function markAsRead(PDO $pdo): never
    {
        $user = authenticateUser($pdo);
        $userId = (int)$user['id'];
        $input = getJsonInput();
        $notificationId = isset($input['notification_id']) ? (int)$input['notification_id'] : 0;

        if ($notificationId > 0) {
            $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = :nid AND user_id = :uid')
                ->execute([':nid' => $notificationId, ':uid' => $userId]);
        } else {
            $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = :uid AND is_read = 0')
                ->execute([':uid' => $userId]);
        }

        jsonSuccess(null, 'Notifications marked as read.');
    }
}
