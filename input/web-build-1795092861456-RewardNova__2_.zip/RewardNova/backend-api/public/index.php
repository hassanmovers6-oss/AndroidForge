<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app_config.php';
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/rate_limiter.php';
require_once __DIR__ . '/../helpers/audit.php';

require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/ProfileController.php';
require_once __DIR__ . '/../controllers/DashboardController.php';
require_once __DIR__ . '/../controllers/TaskController.php';
require_once __DIR__ . '/../controllers/SpinController.php';
require_once __DIR__ . '/../controllers/CheckinController.php';
require_once __DIR__ . '/../controllers/WalletController.php';
require_once __DIR__ . '/../controllers/WithdrawalController.php';
require_once __DIR__ . '/../controllers/ReferralController.php';
require_once __DIR__ . '/../controllers/NotificationController.php';
require_once __DIR__ . '/../controllers/ConfigController.php';
require_once __DIR__ . '/../controllers/AdRewardController.php';

$pdo = Database::getConnection();

// Normalize path whether hosted at root or /RewardNova/backend-api/public
$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
if ($scriptDir !== '/' && $scriptDir !== '.' && str_starts_with($requestUri, $scriptDir)) {
    $requestUri = substr($requestUri, strlen($scriptDir));
}
// Also allow ?route=... fallback if mod_rewrite is disabled
if (isset($_GET['route']) && is_string($_GET['route'])) {
    $requestUri = $_GET['route'];
}

$path = '/' . trim($requestUri, '/');
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

// Maintenance mode check (except config & auth)
if (!str_starts_with($path, '/api/v1/config') && AppSettings::getString($pdo, 'maintenance_mode', '0') === '1') {
    jsonError('RewardNova is currently undergoing scheduled maintenance. Please check back shortly.', 503, 'MAINTENANCE_MODE');
}

match (true) {
    $method === 'GET' && ($path === '/' || $path === '/api/v1/health') =>
        jsonSuccess(['status' => 'operational', 'service' => 'RewardNova PHP API'], 'API is healthy.'),

    // Auth
    $method === 'POST' && $path === '/api/v1/auth/register' => AuthController::register($pdo),
    $method === 'POST' && $path === '/api/v1/auth/login' => AuthController::login($pdo),
    $method === 'POST' && $path === '/api/v1/auth/forgot-password' => AuthController::forgotPassword($pdo),
    $method === 'POST' && $path === '/api/v1/auth/reset-password' => AuthController::resetPassword($pdo),
    $method === 'POST' && $path === '/api/v1/auth/logout' => AuthController::logout($pdo),

    // Profile
    $method === 'GET' && $path === '/api/v1/profile' => ProfileController::getProfile($pdo),
    ($method === 'PUT' || $method === 'POST') && $path === '/api/v1/profile' => ProfileController::updateProfile($pdo),
    $method === 'POST' && $path === '/api/v1/profile/change-password' => ProfileController::changePassword($pdo),

    // Dashboard
    $method === 'GET' && $path === '/api/v1/dashboard' => DashboardController::getDashboard($pdo),

    // Tasks
    $method === 'GET' && $path === '/api/v1/tasks' => TaskController::listTasks($pdo),
    $method === 'POST' && $path === '/api/v1/tasks/submit' => TaskController::submitTask($pdo),

    // Spin Wheel
    $method === 'GET' && $path === '/api/v1/spin/wheel' => SpinController::getWheel($pdo),
    $method === 'POST' && $path === '/api/v1/spin/execute' => SpinController::executeSpin($pdo),
    $method === 'GET' && $path === '/api/v1/spin/history' => SpinController::getHistory($pdo),

    // Daily Check-in
    $method === 'GET' && $path === '/api/v1/checkin' => CheckinController::getStatus($pdo),
    $method === 'POST' && $path === '/api/v1/checkin' => CheckinController::claimDailyCheckin($pdo),

    // Wallet & Transactions
    $method === 'GET' && $path === '/api/v1/wallet' => WalletController::getWallet($pdo),
    $method === 'POST' && $path === '/api/v1/wallet/convert' => WalletController::convertPointsToCash($pdo),
    $method === 'GET' && $path === '/api/v1/transactions' => WalletController::getTransactions($pdo),

    // Withdrawals
    $method === 'GET' && $path === '/api/v1/withdrawals' => WithdrawalController::listWithdrawals($pdo),
    $method === 'POST' && $path === '/api/v1/withdrawals' => WithdrawalController::requestWithdrawal($pdo),

    // Referrals
    $method === 'GET' && $path === '/api/v1/referrals' => ReferralController::getReferrals($pdo),

    // Notifications
    $method === 'GET' && $path === '/api/v1/notifications' => NotificationController::listNotifications($pdo),
    $method === 'POST' && $path === '/api/v1/notifications/read' => NotificationController::markAsRead($pdo),

    // Public Config & AdMob Verification
    $method === 'GET' && $path === '/api/v1/config' => ConfigController::getPublicConfig($pdo),
    $method === 'POST' && $path === '/api/v1/ads/reward-nonce' => AdRewardController::issueRewardNonce($pdo),
    $method === 'POST' && $path === '/api/v1/ads/reward-verify' => AdRewardController::verifyAndCreditAdReward($pdo),

    default => jsonError("Endpoint not found: {$method} {$path}", 404, 'ROUTE_NOT_FOUND'),
};
