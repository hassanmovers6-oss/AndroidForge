<?php
/**
 * RewardNova Database Configuration Template
 * Copy this file to env.local.php and set your MySQL / API credentials,
 * or configure system environment variables (DB_HOST, DB_NAME, DB_USER, DB_PASS).
 */

return [
    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => '3306',
    'DB_NAME' => 'rewardnova',
    'DB_USER' => 'root',
    'DB_PASS' => '',
    'APP_ENV' => 'local',
    'TOKEN_TTL_DAYS' => 30,
    'API_BASE_URL' => 'http://10.0.2.2/RewardNova/backend-api/public',
];
