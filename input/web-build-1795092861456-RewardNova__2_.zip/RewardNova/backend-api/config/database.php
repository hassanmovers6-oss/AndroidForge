<?php
declare(strict_types=1);

final class Database
{
    private static ?PDO $instance = null;

    public static function getConfig(): array
    {
        $localPath = __DIR__ . '/env.local.php';
        $examplePath = __DIR__ . '/env.example.php';
        $defaults = file_exists($localPath)
            ? require $localPath
            : require $examplePath;

        return [
            'DB_HOST' => getenv('DB_HOST') ?: ($defaults['DB_HOST'] ?? '127.0.0.1'),
            'DB_PORT' => getenv('DB_PORT') ?: ($defaults['DB_PORT'] ?? '3306'),
            'DB_NAME' => getenv('DB_NAME') ?: ($defaults['DB_NAME'] ?? 'rewardnova'),
            'DB_USER' => getenv('DB_USER') ?: ($defaults['DB_USER'] ?? 'root'),
            'DB_PASS' => getenv('DB_PASS') !== false ? (string)getenv('DB_PASS') : (string)($defaults['DB_PASS'] ?? ''),
            'APP_ENV' => getenv('APP_ENV') ?: ($defaults['APP_ENV'] ?? 'local'),
            'TOKEN_TTL_DAYS' => (int)(getenv('TOKEN_TTL_DAYS') ?: ($defaults['TOKEN_TTL_DAYS'] ?? 30)),
        ];
    }

    public static function getConnection(): PDO
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $cfg = self::getConfig();
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            $cfg['DB_HOST'],
            $cfg['DB_PORT'],
            $cfg['DB_NAME']
        );

        try {
            self::$instance = new PDO($dsn, $cfg['DB_USER'], $cfg['DB_PASS'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ]);
        } catch (PDOException $e) {
            error_log('RewardNova DB Connection Error: ' . $e->getMessage());
            http_response_code(500);
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode([
                'success' => false,
                'message' => 'Database connection failed. Check backend-api/config/env.local.php.',
                'error_code' => 'DB_CONNECTION_ERROR',
            ]);
            exit;
        }

        return self::$instance;
    }
}
