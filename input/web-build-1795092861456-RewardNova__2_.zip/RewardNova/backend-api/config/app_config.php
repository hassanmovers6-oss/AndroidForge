<?php
declare(strict_types=1);

final class AppSettings
{
    private static ?array $cache = null;

    public static function all(PDO $pdo): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $stmt = $pdo->query('SELECT setting_key, setting_value FROM app_settings');
        $map = [];
        foreach ($stmt->fetchAll() as $row) {
            $map[$row['setting_key']] = $row['setting_value'];
        }
        self::$cache = $map;
        return self::$cache;
    }

    public static function getInt(PDO $pdo, string $key, int $default): int
    {
        $all = self::all($pdo);
        return isset($all[$key]) ? max(0, (int)$all[$key]) : $default;
    }

    public static function getFloat(PDO $pdo, string $key, float $default): float
    {
        $all = self::all($pdo);
        return isset($all[$key]) ? (float)$all[$key] : $default;
    }

    public static function getString(PDO $pdo, string $key, string $default): string
    {
        $all = self::all($pdo);
        return isset($all[$key]) ? (string)$all[$key] : $default;
    }
}
