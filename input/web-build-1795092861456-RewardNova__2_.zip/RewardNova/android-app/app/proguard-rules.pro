# ============================================================================
# RewardNova R8 / ProGuard Rules (Preserves Gson generic signatures & Retrofit)
# ============================================================================

# Preserve generic type signatures and annotations for Gson TypeToken & Retrofit
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Keep all API model classes and fields serialized by Gson
-keep class com.rewardnova.app.data.model.** { *; }
-keepclassmembers class com.rewardnova.app.data.model.** { *; }

# Keep Gson TypeToken subclasses
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken

# Retrofit 2
-keepattributes Exceptions
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
-dontwarn javax.annotation.**
-dontwarn kotlin.Unit
-dontwarn retrofit2.Platform$Java8

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.Nullable
-dontwarn javax.annotation.ParametersAreNonnullByDefault

# Google Mobile Ads
-keep class com.google.android.gms.ads.** { *; }
