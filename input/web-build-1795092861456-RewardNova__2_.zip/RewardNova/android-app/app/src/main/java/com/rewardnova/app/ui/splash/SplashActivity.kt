package com.rewardnova.app.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.rewardnova.app.RewardNovaApp
import com.rewardnova.app.ads.AdManager
import com.rewardnova.app.databinding.ActivitySplashBinding
import com.rewardnova.app.ui.auth.SignInActivity
import com.rewardnova.app.ui.main.MainActivity

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AdManager.refreshConfig()

        Handler(Looper.getMainLooper()).postDelayed({
            val next = if (RewardNovaApp.instance.tokenManager.isLoggedIn()) {
                MainActivity::class.java
            } else {
                SignInActivity::class.java
            }
            startActivity(Intent(this, next))
            finish()
        }, 1200L)
    }
}
