package com.rewardnova.app.ui.spin

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.rewardnova.app.data.model.SpinSegment
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class SpinWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var segments: List<SpinSegment> = emptyList()
    private val slicePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 5f
    }
    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#0F172A")
        strokeWidth = 12f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()
    private var currentRotation = 0f

    fun setSegments(items: List<SpinSegment>) {
        segments = items
        invalidate()
    }

    fun spinToSegmentIndex(targetIndex: Int, onAnimationEnd: () -> Unit) {
        if (segments.isEmpty()) {
            onAnimationEnd()
            return
        }
        val count = segments.size
        val sweep = 360f / count
        val safeIdx = targetIndex.coerceIn(0, count - 1)
        // Pointer sits at top (270 degrees). Align target segment center to 270 deg.
        val segmentCenter = (safeIdx * sweep) + (sweep / 2f)
        val desiredAngleMod = (270f - segmentCenter + 360f) % 360f
        val currentMod = currentRotation % 360f
        val delta = (desiredAngleMod - currentMod + 360f) % 360f
        val targetRotation = currentRotation + (360f * 5) + delta

        ObjectAnimator.ofFloat(this, "rotation", currentRotation, targetRotation).apply {
            duration = 3200L
            interpolator = DecelerateInterpolator(2.2f)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    currentRotation = targetRotation % 360f
                    rotation = currentRotation
                    onAnimationEnd()
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (segments.isEmpty()) return

        val cx = width / 2f
        val cy = height / 2f
        val radius = min(cx, cy) - 18f
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        val sweep = 360f / segments.size
        for (i in segments.indices) {
            val seg = segments[i]
            val startAngle = i * sweep
            slicePaint.color = try {
                Color.parseColor(seg.colorHex)
            } catch (_: Exception) {
                Color.parseColor("#0F766E")
            }
            canvas.drawArc(rect, startAngle, sweep, true, slicePaint)
            canvas.drawArc(rect, startAngle, sweep, true, borderPaint)

            val midAngleRad = Math.toRadians((startAngle + sweep / 2f).toDouble())
            val tx = cx + (radius * 0.64f * cos(midAngleRad)).toFloat()
            val ty = cy + (radius * 0.64f * sin(midAngleRad)).toFloat() + 12f
            canvas.drawText(seg.label, tx, ty, textPaint)
        }

        canvas.drawCircle(cx, cy, radius, outerRingPaint)
        slicePaint.color = Color.parseColor("#0F172A")
        canvas.drawCircle(cx, cy, 34f, slicePaint)
        canvas.drawCircle(cx, cy, 34f, borderPaint)
    }
}
