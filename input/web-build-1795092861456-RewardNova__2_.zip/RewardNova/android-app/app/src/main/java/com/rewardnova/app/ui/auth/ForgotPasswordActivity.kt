package com.rewardnova.app.ui.auth

import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.ForgotPasswordRequest
import com.rewardnova.app.data.model.ResetPasswordRequest
import com.rewardnova.app.databinding.ActivityForgotPasswordBinding
import kotlinx.coroutines.launch

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityForgotPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRequestCode.setOnClickListener { requestCode() }
        binding.btnConfirmReset.setOnClickListener { confirmReset() }
    }

    private fun requestCode() {
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Enter a valid email"
            return
        }
        binding.btnRequestCode.isEnabled = false
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().forgotPassword(ForgotPasswordRequest(email))
                val body = res.body()
                if (res.isSuccessful && body?.success == true) {
                    val codeNote = body.data?.localTestResetCode?.let { "\nLocal XAMPP Test Code: $it" } ?: ""
                    binding.tvResetStatus.visibility = View.VISIBLE
                    binding.tvResetStatus.text = "${body.message}$codeNote"
                } else {
                    Toast.makeText(this@ForgotPasswordActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ForgotPasswordActivity, "Network error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnRequestCode.isEnabled = true
            }
        }
    }

    private fun confirmReset() {
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        val code = binding.etResetCode.text?.toString()?.trim().orEmpty()
        val newPass = binding.etNewPassword.text?.toString().orEmpty()
        val confirmPass = binding.etConfirmPassword.text?.toString().orEmpty()

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || code.length < 4 || newPass.length < 8 || newPass != confirmPass) {
            Toast.makeText(this, "Enter valid email, code, and matching 8+ char passwords.", Toast.LENGTH_LONG).show()
            return
        }

        binding.btnConfirmReset.isEnabled = false
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().resetPassword(
                    ResetPasswordRequest(email, code, newPass, confirmPass)
                )
                if (res.isSuccessful && res.body()?.success == true) {
                    Toast.makeText(this@ForgotPasswordActivity, res.body()?.message ?: "Password reset!", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    Toast.makeText(this@ForgotPasswordActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ForgotPasswordActivity, "Network error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnConfirmReset.isEnabled = true
            }
        }
    }
}
