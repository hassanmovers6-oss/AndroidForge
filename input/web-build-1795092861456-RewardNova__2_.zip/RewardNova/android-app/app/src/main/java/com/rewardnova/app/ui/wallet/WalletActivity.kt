package com.rewardnova.app.ui.wallet

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.ConvertPointsRequest
import com.rewardnova.app.databinding.ActivityWalletBinding
import com.rewardnova.app.ui.withdrawals.WithdrawalsActivity
import kotlinx.coroutines.launch
import java.util.Locale

class WalletActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWalletBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWalletBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnConvertToCash.setOnClickListener { convertPoints() }
        binding.btnGoToWithdrawals.setOnClickListener {
            startActivity(Intent(this, WithdrawalsActivity::class.java))
        }
        loadWallet()
    }

    override fun onResume() {
        super.onResume()
        loadWallet()
    }

    private fun loadWallet() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getWallet()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    binding.tvWalletPoints.text = "${data.pointsWallet.pointsBalance} pts"
                    binding.tvWalletPointsMeta.text =
                        "${data.conversionRules.pointsPerRupee} points = Rs 1  |  Convertible: Rs ${data.pointsWallet.convertibleRupees.toInt()}"
                    binding.tvWalletCash.text = String.format(Locale.US, "Rs %.2f", data.cashWallet.cashBalance)
                    binding.tvWalletCashMeta.text = String.format(
                        Locale.US,
                        "Minimum Withdrawal: Rs %.0f  |  Pending: Rs %.2f",
                        data.conversionRules.minWithdrawalRs,
                        data.cashWallet.pendingWithdrawal
                    )
                }
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "Wallet error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun convertPoints() {
        val pts = binding.etConvertPoints.text?.toString()?.trim()?.toLongOrNull() ?: 0L
        if (pts < 1000L) {
            binding.etConvertPoints.error = "Minimum 1000 points required"
            return
        }
        binding.btnConvertToCash.isEnabled = false
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().convertPoints(ConvertPointsRequest(pts))
                if (res.isSuccessful && res.body()?.success == true) {
                    Toast.makeText(this@WalletActivity, res.body()?.message ?: "Converted!", Toast.LENGTH_LONG).show()
                    binding.etConvertPoints.setText("")
                    loadWallet()
                } else {
                    Toast.makeText(this@WalletActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "Conversion failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnConvertToCash.isEnabled = true
            }
        }
    }
}
