package com.rewardnova.app.ui.tasks

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.TaskItem
import com.rewardnova.app.data.model.TaskSubmitRequest
import com.rewardnova.app.databinding.ActivityTasksBinding
import com.rewardnova.app.databinding.ItemTaskBinding
import kotlinx.coroutines.launch

class TasksActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTasksBinding
    private val tasks = mutableListOf<TaskItem>()
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTasksBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        adapter = TaskAdapter(tasks) { task -> handleTaskClick(task) }
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        binding.rvTasks.adapter = adapter
        loadTasks()
    }

    private fun loadTasks() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getTasks()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    tasks.clear()
                    tasks.addAll(data.tasks)
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                Toast.makeText(this@TasksActivity, "Failed to load tasks: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleTaskClick(task: TaskItem) {
        if (task.isCompleted) return

        if (!task.actionUrl.isNullOrBlank()) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(task.actionUrl)))
            } catch (_: Exception) {
            }
        }

        if (task.requiresProof) {
            val input = EditText(this).apply { hint = "Enter verification handle or proof" }
            AlertDialog.Builder(this)
                .setTitle("Verify Task")
                .setMessage("Provide verification details for: ${task.title}")
                .setView(input)
                .setPositiveButton("Submit") { _, _ ->
                    submitTaskToServer(task.id, input.text.toString().trim())
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            submitTaskToServer(task.id, null)
        }
    }

    private fun submitTaskToServer(taskId: Long, proofText: String?) {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().submitTask(TaskSubmitRequest(taskId, proofText))
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    Toast.makeText(
                        this@TasksActivity,
                        "Status: ${data.status.uppercase()} (+${data.pointsAwarded} pts). New Balance: ${data.newPointsBalance} pts",
                        Toast.LENGTH_LONG
                    ).show()
                    loadTasks()
                } else {
                    Toast.makeText(this@TasksActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@TasksActivity, "Task error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private class TaskAdapter(
        private val items: List<TaskItem>,
        private val onClick: (TaskItem) -> Unit
    ) : RecyclerView.Adapter<TaskAdapter.VH>() {

        inner class VH(val b: ItemTaskBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(b)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.b.tvTaskTitle.text = item.title
            holder.b.tvTaskMeta.text =
                "+${item.rewardPoints} pts  |  ${if (item.isRepeatableDaily) "Daily" else "One-Time"}  |  ${item.submissionStatus.uppercase()}"
            holder.b.tvTaskDesc.text = item.description
            holder.b.btnTaskAction.isEnabled = !item.isCompleted
            holder.b.btnTaskAction.text = if (item.isCompleted) "Approved" else "Complete & Claim"
            holder.b.btnTaskAction.setOnClickListener { onClick(item) }
        }
    }
}
