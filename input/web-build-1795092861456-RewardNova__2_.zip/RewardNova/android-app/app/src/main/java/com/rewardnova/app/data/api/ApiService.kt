package com.rewardnova.app.data.api

import com.rewardnova.app.data.model.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {

    @GET("api/v1/config")
    suspend fun getPublicConfig(): Response<ApiResponse<PublicConfigData>>

    @POST("api/v1/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<ApiResponse<AuthData>>

    @POST("api/v1/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<ApiResponse<AuthData>>

    @POST("api/v1/auth/forgot-password")
    suspend fun forgotPassword(@Body request: ForgotPasswordRequest): Response<ApiResponse<ForgotPasswordData>>

    @POST("api/v1/auth/reset-password")
    suspend fun resetPassword(@Body request: ResetPasswordRequest): Response<ApiResponse<Any>>

    @POST("api/v1/auth/logout")
    suspend fun logout(): Response<ApiResponse<Any>>

    @GET("api/v1/dashboard")
    suspend fun getDashboard(): Response<ApiResponse<DashboardData>>

    @GET("api/v1/profile")
    suspend fun getProfile(): Response<ApiResponse<UserSummary>>

    @POST("api/v1/profile")
    suspend fun updateProfile(@Body request: UpdateProfileRequest): Response<ApiResponse<UserSummary>>

    @GET("api/v1/tasks")
    suspend fun getTasks(): Response<ApiResponse<TasksListData>>

    @POST("api/v1/tasks/submit")
    suspend fun submitTask(@Body request: TaskSubmitRequest): Response<ApiResponse<TaskSubmitData>>

    @GET("api/v1/spin/wheel")
    suspend fun getSpinWheel(): Response<ApiResponse<SpinWheelData>>

    @POST("api/v1/spin/execute")
    suspend fun executeSpin(@Body request: SpinExecuteRequest): Response<ApiResponse<SpinExecuteData>>

    @GET("api/v1/checkin")
    suspend fun getCheckInStatus(): Response<ApiResponse<CheckInStatusData>>

    @POST("api/v1/checkin")
    suspend fun claimDailyCheckIn(): Response<ApiResponse<CheckInClaimData>>

    @GET("api/v1/wallet")
    suspend fun getWallet(): Response<ApiResponse<WalletData>>

    @POST("api/v1/wallet/convert")
    suspend fun convertPoints(@Body request: ConvertPointsRequest): Response<ApiResponse<ConvertPointsData>>

    @GET("api/v1/transactions")
    suspend fun getTransactions(@Query("wallet_type") walletType: String = "all"): Response<ApiResponse<TransactionsData>>

    @GET("api/v1/withdrawals")
    suspend fun getWithdrawals(): Response<ApiResponse<WithdrawalsListData>>

    @POST("api/v1/withdrawals")
    suspend fun requestWithdrawal(@Body request: WithdrawalRequestPayload): Response<ApiResponse<WithdrawalSubmitData>>

    @GET("api/v1/referrals")
    suspend fun getReferrals(): Response<ApiResponse<ReferralsData>>

    @GET("api/v1/notifications")
    suspend fun getNotifications(): Response<ApiResponse<NotificationsData>>

    @POST("api/v1/notifications/read")
    suspend fun markNotificationsRead(@Body request: MarkReadRequest): Response<ApiResponse<Any>>

    @POST("api/v1/ads/reward-nonce")
    suspend fun issueAdNonce(@Body request: AdNonceRequest): Response<ApiResponse<AdNonceData>>

    @POST("api/v1/ads/reward-verify")
    suspend fun verifyAdReward(@Body request: AdVerifyRequest): Response<ApiResponse<AdVerifyData>>
}
