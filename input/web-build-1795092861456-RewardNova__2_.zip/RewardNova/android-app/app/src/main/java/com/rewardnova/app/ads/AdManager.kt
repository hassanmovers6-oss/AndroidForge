package com.rewardnova.app.ads

import android.app.Activity
import android.content.Context
import android.view.ViewGroup
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.AdNonceRequest
import com.rewardnova.app.data.model.AdPlacementConfig
import com.rewardnova.app.data.model.AdVerifyRequest
import com.rewardnova.app.data.model.PublicConfigData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Centralized AdMob Manager.
 * Reads all Ad Unit IDs (Banner, Interstitial, Native, Rewarded, Rewarded Interstitial, App Open)
 * dynamically from the PHP backend /api/v1/config endpoint.
 * Default seed values on the server are Google's official Test Ad Unit IDs.
 */
object AdManager {
    var config: PublicConfigData? = null
        private set

    private var cachedInterstitial: InterstitialAd? = null
    private var cachedRewarded: RewardedAd? = null

    fun refreshConfig(onComplete: (() -> Unit)? = null) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val res = RetrofitClient.getApiService().getPublicConfig()
                if (res.isSuccessful && res.body()?.success == true) {
                    config = res.body()?.data
                }
            } catch (_: Exception) {
            } finally {
                withContext(Dispatchers.Main) {
                    onComplete?.invoke()
                }
            }
        }
    }

    fun getPlacement(format: String): AdPlacementConfig? = config?.admob?.get(format)

    fun attachBanner(context: Context, container: ViewGroup) {
        val placement = getPlacement("banner")
        if (placement == null || !placement.isEnabled || placement.adUnitId.isBlank()) return

        container.removeAllViews()
        val adView = AdView(context).apply {
            adUnitId = placement.adUnitId
            setAdSize(AdSize.BANNER)
        }
        container.addView(adView)
        adView.loadAd(AdRequest.Builder().build())
    }

    fun preloadInterstitial(context: Context) {
        val placement = getPlacement("interstitial")
        if (placement == null || !placement.isEnabled || placement.adUnitId.isBlank()) return

        InterstitialAd.load(
            context,
            placement.adUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    cachedInterstitial = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedInterstitial = null
                }
            }
        )
    }

    fun showInterstitialIfReady(activity: Activity) {
        cachedInterstitial?.show(activity)
        cachedInterstitial = null
        preloadInterstitial(activity)
    }

    fun preloadRewarded(context: Context) {
        val placement = getPlacement("rewarded")
        if (placement == null || !placement.isEnabled || placement.adUnitId.isBlank()) return

        RewardedAd.load(
            context,
            placement.adUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    cachedRewarded = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    cachedRewarded = null
                }
            }
        )
    }

    /**
     * Shows a Rewarded Ad and ONLY credits points after server-side nonce verification.
     */
    fun showServerVerifiedRewardedAd(
        activity: Activity,
        onResult: (success: Boolean, message: String, newBalance: Long?) -> Unit
    ) {
        val ad = cachedRewarded
        if (ad == null) {
            preloadRewarded(activity)
            onResult(false, "Rewarded ad is still loading. Please try again in a moment.", null)
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val nonceRes = RetrofitClient.getApiService().issueAdNonce(AdNonceRequest("rewarded"))
                val nonceData = nonceRes.body()?.data
                if (!nonceRes.isSuccessful || nonceData == null) {
                    withContext(Dispatchers.Main) {
                        onResult(false, RetrofitClient.extractErrorMessage(nonceRes), null)
                    }
                    return@launch
                }

                withContext(Dispatchers.Main) {
                    var earned = false
                    ad.show(activity) {
                        earned = true
                    }
                    cachedRewarded = null
                    preloadRewarded(activity)

                    if (earned) {
                        CoroutineScope(Dispatchers.IO).launch {
                            val verifyRes = RetrofitClient.getApiService()
                                .verifyAdReward(AdVerifyRequest(nonceData.adNonce))
                            withContext(Dispatchers.Main) {
                                if (verifyRes.isSuccessful && verifyRes.body()?.success == true) {
                                    val data = verifyRes.body()?.data
                                    onResult(true, verifyRes.body()?.message ?: "Reward credited!", data?.newPointsBalance)
                                } else {
                                    onResult(false, RetrofitClient.extractErrorMessage(verifyRes), null)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onResult(false, e.message ?: "Unable to verify ad reward.", null)
                }
            }
        }
    }
}
