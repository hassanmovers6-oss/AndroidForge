package com.rewardnova.app.ui.referrals

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.ReferralItem
import com.rewardnova.app.databinding.ActivityReferralBinding
import com.rewardnova.app.databinding.ItemSimpleRowBinding
import kotlinx.coroutines.launch

class ReferralActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReferralBinding
    private val rows = mutableListOf<ReferralItem>()
    private lateinit var adapter: ReferralAdapter
    private var currentCode = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReferralBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        adapter = ReferralAdapter(rows)
        binding.rvReferrals.layoutManager = LinearLayoutManager(this)
        binding.rvReferrals.adapter = adapter

        binding.btnShareReferral.setOnClickListener {
            if (currentCode.isNotBlank()) {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Join RewardNova with my referral code $currentCode and earn bonus points!")
                }
                startActivity(Intent.createChooser(share, "Share Referral Code"))
            }
        }
        loadReferrals()
    }

    private fun loadReferrals() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getReferrals()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    currentCode = data.referralCode
                    binding.tvReferralCode.text = data.referralCode
                    binding.tvReferralStats.text =
                        "Total Referred: ${data.totalReferrals}  |  Earned: ${data.totalReferralPoints} pts (+${data.referrerBonusPoints} pts/invite)"
                    rows.clear()
                    rows.addAll(data.referrals)
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ReferralActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private class ReferralAdapter(private val items: List<ReferralItem>) : RecyclerView.Adapter<ReferralAdapter.VH>() {
        inner class VH(val b: ItemSimpleRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemSimpleRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val r = items[position]
            holder.b.tvRowTitle.text = "${r.fullName}  (+${r.pointsEarned} pts)"
            holder.b.tvRowSubtitle.text = "Status: ${r.status.uppercase()} · Joined ${r.registeredAt}"
        }
    }
}
