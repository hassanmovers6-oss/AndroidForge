package com.rewardnova.app.ui.transactions

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.TransactionItem
import com.rewardnova.app.databinding.ActivityTransactionsBinding
import com.rewardnova.app.databinding.ItemSimpleRowBinding
import kotlinx.coroutines.launch
import java.util.Locale

class TransactionHistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTransactionsBinding
    private val items = mutableListOf<TransactionItem>()
    private lateinit var adapter: TxAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        adapter = TxAdapter(items)
        binding.rvTransactions.layoutManager = LinearLayoutManager(this)
        binding.rvTransactions.adapter = adapter

        binding.btnFilterAll.setOnClickListener { loadTransactions("all") }
        binding.btnFilterPoints.setOnClickListener { loadTransactions("points") }
        binding.btnFilterCash.setOnClickListener { loadTransactions("cash") }

        loadTransactions("all")
    }

    private fun loadTransactions(filter: String) {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getTransactions(filter)
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    items.clear()
                    items.addAll(data.transactions)
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                Toast.makeText(this@TransactionHistoryActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private class TxAdapter(private val rows: List<TransactionItem>) : RecyclerView.Adapter<TxAdapter.VH>() {
        inner class VH(val b: ItemSimpleRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemSimpleRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount(): Int = rows.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val tx = rows[position]
            val sign = if (tx.txType == "credit") "+" else "-"
            val amountLabel = if (tx.walletType == "points") {
                "$sign${tx.pointsAmount} pts"
            } else {
                String.format(Locale.US, "%sRs %.2f", sign, tx.cashAmount)
            }
            holder.b.tvRowTitle.text = "$amountLabel  ·  ${tx.description}"
            holder.b.tvRowSubtitle.text = "${tx.walletType.uppercase()} (${tx.category}) · ${tx.createdAt}"
        }
    }
}
