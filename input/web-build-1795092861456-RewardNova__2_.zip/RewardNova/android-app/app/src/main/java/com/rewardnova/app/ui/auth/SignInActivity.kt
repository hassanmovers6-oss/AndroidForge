package com.rewardnova.app.ui.auth

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.RewardNovaApp
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.LoginRequest
import com.rewardnova.app.databinding.ActivitySignInBinding
import com.rewardnova.app.ui.main.MainActivity
import kotlinx.coroutines.launch

class SignInActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignInBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener { submitLogin() }
        binding.tvGoToSignUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
        binding.tvForgotPassword.setOnClickListener {
            startActivity(Intent(this, ForgotPasswordActivity::class.java))
        }
    }

    private fun submitLogin() {
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString().orEmpty()

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Enter a valid email"
            return
        }
        if (password.isEmpty()) {
            binding.etPassword.error = "Enter your password"
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnLogin.isEnabled = false

        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().login(
                    LoginRequest(
                        email = email,
                        password = password,
                        deviceName = "${Build.MANUFACTURER} ${Build.MODEL}"
                    )
                )
                val body = res.body()
                if (res.isSuccessful && body?.success == true && body.data != null) {
                    val tm = RewardNovaApp.instance.tokenManager
                    tm.saveToken(body.data.token)
                    tm.saveUserIdentity(
                        body.data.user.fullName,
                        body.data.user.email,
                        body.data.user.referralCode
                    )
                    startActivity(Intent(this@SignInActivity, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    })
                } else {
                    Toast.makeText(this@SignInActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@SignInActivity, "Network error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.progressBar.visibility = View.GONE
                binding.btnLogin.isEnabled = true
            }
        }
    }
}
