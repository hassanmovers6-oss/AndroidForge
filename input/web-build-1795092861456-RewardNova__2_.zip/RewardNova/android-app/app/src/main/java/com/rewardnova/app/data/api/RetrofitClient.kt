package com.rewardnova.app.data.api

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.rewardnova.app.BuildConfig
import com.rewardnova.app.RewardNovaApp
import com.rewardnova.app.data.model.ApiResponse
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    private val gson: Gson = GsonBuilder().create()
    private var cachedBaseUrl: String? = null
    private var cachedService: ApiService? = null

    fun getApiService(): ApiService {
        val baseUrl = RewardNovaApp.instance.tokenManager.getApiBaseUrl()
        if (cachedService != null && cachedBaseUrl == baseUrl) {
            return cachedService!!
        }

        val authInterceptor = Interceptor { chain ->
            val token = RewardNovaApp.instance.tokenManager.getToken()
            val builder = chain.request().newBuilder()
                .addHeader("Accept", "application/json")
            if (!token.isNullOrBlank()) {
                builder.addHeader("Authorization", "Bearer $token")
            }
            chain.proceed(builder.build())
        }

        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        cachedBaseUrl = baseUrl
        cachedService = retrofit.create(ApiService::class.java)
        return cachedService!!
    }

    fun resetClient() {
        cachedService = null
        cachedBaseUrl = null
    }

    fun <T> extractErrorMessage(response: Response<ApiResponse<T>>): String {
        return try {
            val raw = response.errorBody()?.string()
            if (!raw.isNullOrBlank()) {
                val parsed = gson.fromJson(raw, ApiResponse::class.java)
                parsed?.message ?: "Request failed (${response.code()})"
            } else {
                "Request failed (${response.code()})"
            }
        } catch (_: Exception) {
            "Request failed (${response.code()})"
        }
    }
}
