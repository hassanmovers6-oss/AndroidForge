package com.rewardnova.app.ui.auth

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.RewardNovaApp
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.RegisterRequest
import com.rewardnova.app.databinding.ActivitySignUpBinding
import com.rewardnova.app.ui.main.MainActivity
import kotlinx.coroutines.launch

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener { submitRegistration() }
        binding.tvGoToSignIn.setOnClickListener {
            startActivity(Intent(this, SignInActivity::class.java))
            finish()
        }
    }

    private fun submitRegistration() {
        val fullName = binding.etFullName.text?.toString()?.trim().orEmpty()
        val email = binding.etEmail.text?.toString()?.trim().orEmpty()
        val password = binding.etPassword.text?.toString().orEmpty()
        val confirmPassword = binding.etConfirmPassword.text?.toString().orEmpty()
        val referralCode = binding.etReferralCode.text?.toString()?.trim()?.uppercase().orEmpty()

        if (fullName.length < 2) {
            binding.etFullName.error = "Enter your full name"
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Enter a valid email address"
            return
        }
        if (password.length < 8) {
            binding.etPassword.error = "Password must be at least 8 characters"
            return
        }
        if (password != confirmPassword) {
            binding.etConfirmPassword.error = "Passwords do not match"
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().register(
                    RegisterRequest(
                        fullName = fullName,
                        email = email,
                        password = password,
                        confirmPassword = confirmPassword,
                        referralCode = referralCode.ifBlank { null },
                        deviceName = "${Build.MANUFACTURER} ${Build.MODEL}"
                    )
                )
                val body = res.body()
                if (res.isSuccessful && body?.success == true && body.data != null) {
                    val tm = RewardNovaApp.instance.tokenManager
                    tm.saveToken(body.data.token)
                    tm.saveUserIdentity(
                        body.data.user.fullName,
                        body.data.user.email,
                        body.data.user.referralCode
                    )
                    Toast.makeText(this@SignUpActivity, "Welcome to RewardNova!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@SignUpActivity, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    })
                } else {
                    Toast.makeText(this@SignUpActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@SignUpActivity, "Network error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !loading
    }
}
