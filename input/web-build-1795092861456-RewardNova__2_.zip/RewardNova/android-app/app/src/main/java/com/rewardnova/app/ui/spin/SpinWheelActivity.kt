package com.rewardnova.app.ui.spin

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.SpinExecuteRequest
import com.rewardnova.app.data.model.SpinSegment
import com.rewardnova.app.databinding.ActivitySpinWheelBinding
import kotlinx.coroutines.launch
import java.util.UUID

class SpinWheelActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySpinWheelBinding
    private var segments: List<SpinSegment> = emptyList()
    private var nextNonce: String = UUID.randomUUID().toString().replace("-", "")
    private var isSpinning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpinWheelBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnSpinNow.setOnClickListener { executeSpin() }
        loadWheelConfig()
    }

    private fun loadWheelConfig() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getSpinWheel()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    segments = data.segments
                    nextNonce = data.spinNonce
                    binding.spinWheelView.setSegments(segments)
                    binding.tvSpinStats.text =
                        "Remaining Spins: ${data.spinsRemaining} / ${data.dailySpinLimit}  |  Balance: ${data.pointsBalance} pts"
                    binding.btnSpinNow.isEnabled = data.spinsRemaining > 0
                }
            } catch (e: Exception) {
                Toast.makeText(this@SpinWheelActivity, "Failed to load wheel: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun executeSpin() {
        if (isSpinning || segments.isEmpty()) return
        isSpinning = true
        binding.btnSpinNow.isEnabled = false
        binding.tvSpinResult.text = "Spinning..."

        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().executeSpin(SpinExecuteRequest(nextNonce))
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    nextNonce = data.nextSpinNonce
                    val winIdx = segments.indexOfFirst { it.id == data.winningSegment.id }
                        .takeIf { it >= 0 } ?: data.winningSegment.segmentIndex

                    binding.spinWheelView.spinToSegmentIndex(winIdx) {
                        binding.tvSpinResult.text = "Won +${data.pointsWon} points (${data.winningSegment.label})!"
                        binding.tvSpinStats.text =
                            "Remaining Spins: ${data.spinsRemaining} / ${data.dailySpinLimit}  |  Balance: ${data.newPointsBalance} pts"
                        isSpinning = false
                        binding.btnSpinNow.isEnabled = data.spinsRemaining > 0
                    }
                } else {
                    isSpinning = false
                    binding.btnSpinNow.isEnabled = true
                    val msg = RetrofitClient.extractErrorMessage(res)
                    binding.tvSpinResult.text = msg
                    Toast.makeText(this@SpinWheelActivity, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                isSpinning = false
                binding.btnSpinNow.isEnabled = true
                Toast.makeText(this@SpinWheelActivity, "Spin error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
