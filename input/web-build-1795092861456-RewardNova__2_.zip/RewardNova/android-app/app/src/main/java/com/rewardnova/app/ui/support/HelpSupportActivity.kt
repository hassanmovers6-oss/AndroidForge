package com.rewardnova.app.ui.support

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.rewardnova.app.ads.AdManager
import com.rewardnova.app.databinding.ActivityHelpSupportBinding

class HelpSupportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHelpSupportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHelpSupportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        val supportEmail = AdManager.config?.supportEmail ?: "support@rewardnova.local"
        binding.tvSupportEmail.text = "Support Email: $supportEmail"

        binding.btnContactSupport.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$supportEmail")
                putExtra(Intent.EXTRA_SUBJECT, "RewardNova Support Request")
            }
            try {
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "No email app installed. Contact $supportEmail", Toast.LENGTH_LONG).show()
            }
        }
    }
}
