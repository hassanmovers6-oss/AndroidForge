package com.rewardnova.app

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.rewardnova.app.data.local.TokenManager

class RewardNovaApp : Application() {
    lateinit var tokenManager: TokenManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        tokenManager = TokenManager(this)
        MobileAds.initialize(this) {}
    }

    companion object {
        lateinit var instance: RewardNovaApp
            private set
    }
}
