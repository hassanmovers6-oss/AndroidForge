package com.rewardnova.app.ui.withdrawals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.WithdrawalItem
import com.rewardnova.app.data.model.WithdrawalRequestPayload
import com.rewardnova.app.databinding.ActivityWithdrawalsBinding
import com.rewardnova.app.databinding.ItemSimpleRowBinding
import kotlinx.coroutines.launch
import java.util.Locale

class WithdrawalsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWithdrawalsBinding
    private val items = mutableListOf<WithdrawalItem>()
    private lateinit var adapter: WithdrawalAdapter
    private var minWithdrawalRs = 100.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWithdrawalsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        adapter = WithdrawalAdapter(items)
        binding.rvWithdrawals.layoutManager = LinearLayoutManager(this)
        binding.rvWithdrawals.adapter = adapter
        binding.btnSubmitWithdrawal.setOnClickListener { submitWithdrawal() }

        loadWithdrawals()
    }

    private fun loadWithdrawals() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getWithdrawals()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    minWithdrawalRs = data.minWithdrawalRs
                    binding.tvCashSummary.text = String.format(
                        Locale.US,
                        "Available Cash: Rs %.2f (Min Rs %.0f)",
                        data.cashBalance,
                        minWithdrawalRs
                    )
                    val methods = data.allowedMethods.ifEmpty { listOf("UPI", "Bank Transfer", "JazzCash", "EasyPaisa") }
                    binding.spinnerMethod.adapter = ArrayAdapter(
                        this@WithdrawalsActivity,
                        android.R.layout.simple_spinner_dropdown_item,
                        methods
                    )
                    items.clear()
                    items.addAll(data.withdrawals)
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WithdrawalsActivity, "Load error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun submitWithdrawal() {
        val amount = binding.etAmountRs.text?.toString()?.trim()?.toDoubleOrNull() ?: 0.0
        val holder = binding.etAccountHolder.text?.toString()?.trim().orEmpty()
        val details = binding.etAccountDetails.text?.toString()?.trim().orEmpty()
        val method = binding.spinnerMethod.selectedItem?.toString() ?: "UPI"

        if (amount < minWithdrawalRs) {
            binding.etAmountRs.error = "Minimum withdrawal is Rs ${minWithdrawalRs.toInt()}"
            return
        }
        if (holder.length < 2 || details.length < 4) {
            Toast.makeText(this, "Enter valid account holder name and account details.", Toast.LENGTH_LONG).show()
            return
        }

        binding.btnSubmitWithdrawal.isEnabled = false
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().requestWithdrawal(
                    WithdrawalRequestPayload(amount, method, details, holder)
                )
                if (res.isSuccessful && res.body()?.success == true) {
                    Toast.makeText(this@WithdrawalsActivity, res.body()?.message ?: "Withdrawal submitted!", Toast.LENGTH_LONG).show()
                    binding.etAmountRs.setText("")
                    loadWithdrawals()
                } else {
                    Toast.makeText(this@WithdrawalsActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WithdrawalsActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnSubmitWithdrawal.isEnabled = true
            }
        }
    }

    private class WithdrawalAdapter(private val rows: List<WithdrawalItem>) : RecyclerView.Adapter<WithdrawalAdapter.VH>() {
        inner class VH(val b: ItemSimpleRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemSimpleRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount(): Int = rows.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val w = rows[position]
            holder.b.tvRowTitle.text = String.format(Locale.US, "Rs %.2f  -  %s (%s)", w.amountRs, w.paymentMethod, w.status.uppercase())
            holder.b.tvRowSubtitle.text = "${w.accountHolderName} · ${w.accountDetails} · ${w.createdAt}"
        }
    }
}
