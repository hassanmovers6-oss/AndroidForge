package com.rewardnova.app.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.rewardnova.app.BuildConfig

class TokenManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "rewardnova_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (_: Exception) {
        context.getSharedPreferences("rewardnova_fallback_prefs", Context.MODE_PRIVATE)
    }

    fun saveToken(token: String) {
        prefs.edit().putString(KEY_AUTH_TOKEN, token).apply()
    }

    fun getToken(): String? = prefs.getString(KEY_AUTH_TOKEN, null)

    fun isLoggedIn(): Boolean = !getToken().isNullOrBlank()

    fun saveUserIdentity(name: String, email: String, referralCode: String) {
        prefs.edit()
            .putString(KEY_USER_NAME, name)
            .putString(KEY_USER_EMAIL, email)
            .putString(KEY_REFERRAL_CODE, referralCode)
            .apply()
    }

    fun getUserName(): String = prefs.getString(KEY_USER_NAME, "RewardNova Member") ?: "RewardNova Member"
    fun getUserEmail(): String = prefs.getString(KEY_USER_EMAIL, "") ?: ""
    fun getReferralCode(): String = prefs.getString(KEY_REFERRAL_CODE, "") ?: ""

    fun setCustomApiBaseUrl(url: String?) {
        if (url.isNullOrBlank()) {
            prefs.edit().remove(KEY_API_BASE_URL).apply()
        } else {
            val normalized = if (url.endsWith("/")) url else "$url/"
            prefs.edit().putString(KEY_API_BASE_URL, normalized).apply()
        }
    }

    fun getApiBaseUrl(): String {
        return prefs.getString(KEY_API_BASE_URL, null) ?: BuildConfig.API_BASE_URL
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
    }

    fun isNotificationsEnabled(): Boolean = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_TOKEN)
            .remove(KEY_USER_NAME)
            .remove(KEY_USER_EMAIL)
            .remove(KEY_REFERRAL_CODE)
            .apply()
    }

    companion object {
        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_REFERRAL_CODE = "referral_code"
        private const val KEY_API_BASE_URL = "custom_api_base_url"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
    }
}
