package com.rewardnova.app.ui.checkin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.CheckInDay
import com.rewardnova.app.databinding.ActivityDailyCheckinBinding
import com.rewardnova.app.databinding.ItemSimpleRowBinding
import kotlinx.coroutines.launch

class DailyCheckInActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDailyCheckinBinding
    private val days = mutableListOf<CheckInDay>()
    private lateinit var adapter: DayAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDailyCheckinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        adapter = DayAdapter(days)
        binding.rvCheckinDays.layoutManager = LinearLayoutManager(this)
        binding.rvCheckinDays.adapter = adapter
        binding.btnClaimCheckin.setOnClickListener { claimCheckin() }

        loadStatus()
    }

    private fun loadStatus() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getCheckInStatus()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    binding.tvCheckinStreak.text = "Current Streak: ${data.currentStreak} days"
                    binding.tvTodayReward.text = "Today's Bonus: +${data.todayRewardPoints} pts"
                    binding.btnClaimCheckin.isEnabled = !data.checkedInToday
                    binding.btnClaimCheckin.text = if (data.checkedInToday) "Already Claimed Today" else "Claim +${data.todayRewardPoints} Points"
                    days.clear()
                    days.addAll(data.days)
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                Toast.makeText(this@DailyCheckInActivity, "Load error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun claimCheckin() {
        binding.btnClaimCheckin.isEnabled = false
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().claimDailyCheckIn()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    Toast.makeText(this@DailyCheckInActivity, res.body()?.message ?: "Check-in claimed!", Toast.LENGTH_LONG).show()
                    loadStatus()
                } else {
                    Toast.makeText(this@DailyCheckInActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                    loadStatus()
                }
            } catch (e: Exception) {
                Toast.makeText(this@DailyCheckInActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                binding.btnClaimCheckin.isEnabled = true
            }
        }
    }

    private class DayAdapter(private val items: List<CheckInDay>) : RecyclerView.Adapter<DayAdapter.VH>() {
        inner class VH(val b: ItemSimpleRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemSimpleRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val d = items[position]
            holder.b.tvRowTitle.text = "Day ${d.day}  -  +${d.rewardPoints} points"
            holder.b.tvRowSubtitle.text = if (d.claimed) "Claimed" else "Upcoming"
        }
    }
}
