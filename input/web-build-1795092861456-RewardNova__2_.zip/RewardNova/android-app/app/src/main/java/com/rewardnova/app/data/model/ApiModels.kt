package com.rewardnova.app.data.model

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("data") val data: T?,
    @SerializedName("error_code") val errorCode: String? = null
)

// Auth Requests
data class RegisterRequest(
    @SerializedName("full_name") val fullName: String,
    @SerializedName("email") val email: String,
    @SerializedName("password") val password: String,
    @SerializedName("confirm_password") val confirmPassword: String,
    @SerializedName("referral_code") val referralCode: String? = null,
    @SerializedName("device_name") val deviceName: String? = null
)

data class LoginRequest(
    @SerializedName("email") val email: String,
    @SerializedName("password") val password: String,
    @SerializedName("device_name") val deviceName: String? = null
)

data class ForgotPasswordRequest(
    @SerializedName("email") val email: String
)

data class ResetPasswordRequest(
    @SerializedName("email") val email: String,
    @SerializedName("reset_code") val resetCode: String,
    @SerializedName("new_password") val newPassword: String,
    @SerializedName("confirm_password") val confirmPassword: String
)

data class AuthData(
    @SerializedName("token") val token: String,
    @SerializedName("expires_at") val expiresAt: String,
    @SerializedName("user") val user: UserSummary
)

data class ForgotPasswordData(
    @SerializedName("email") val email: String,
    @SerializedName("expires_in_minutes") val expiresInMinutes: Int,
    @SerializedName("local_test_reset_code") val localTestResetCode: String? = null
)

data class UserSummary(
    @SerializedName("id") val id: Long,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("email") val email: String,
    @SerializedName("referral_code") val referralCode: String,
    @SerializedName("account_status") val accountStatus: String,
    @SerializedName("phone") val phone: String?,
    @SerializedName("country") val country: String?,
    @SerializedName("registered_at") val registeredAt: String,
    @SerializedName("points_balance") val pointsBalance: Long,
    @SerializedName("lifetime_points_earned") val lifetimePointsEarned: Long,
    @SerializedName("cash_balance") val cashBalance: Double,
    @SerializedName("total_withdrawn") val totalWithdrawn: Double,
    @SerializedName("pending_withdrawal") val pendingWithdrawal: Double,
    @SerializedName("spins_used_today") val spinsUsedToday: Int,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    @SerializedName("spins_remaining") val spinsRemaining: Int,
    @SerializedName("checkin_streak") val checkinStreak: Int,
    @SerializedName("checked_in_today") val checkedInToday: Boolean
)

// Dashboard
data class DashboardData(
    @SerializedName("user") val user: UserSummary,
    @SerializedName("rules") val rules: DashboardRules,
    @SerializedName("unread_notifications") val unreadNotifications: Int,
    @SerializedName("active_tasks_count") val activeTasksCount: Int,
    @SerializedName("recent_transactions") val recentTransactions: List<TransactionItem>
)

data class DashboardRules(
    @SerializedName("points_per_rupee") val pointsPerRupee: Int,
    @SerializedName("min_withdrawal_rs") val minWithdrawalRs: Double,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    @SerializedName("convertible_cash_estimate") val convertibleCashEstimate: Double
)

// Spin Wheel
data class SpinSegment(
    @SerializedName("id") val id: Int,
    @SerializedName("segment_index") val segmentIndex: Int,
    @SerializedName("label") val label: String,
    @SerializedName("points_reward") val pointsReward: Int,
    @SerializedName("color_hex") val colorHex: String
)

data class SpinWheelData(
    @SerializedName("segments") val segments: List<SpinSegment>,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    @SerializedName("spins_used_today") val spinsUsedToday: Int,
    @SerializedName("spins_remaining") val spinsRemaining: Int,
    @SerializedName("points_balance") val pointsBalance: Long,
    @SerializedName("spin_nonce") val spinNonce: String
)

data class SpinExecuteRequest(
    @SerializedName("request_nonce") val requestNonce: String
)

data class SpinExecuteData(
    @SerializedName("spin_id") val spinId: Long,
    @SerializedName("winning_segment") val winningSegment: SpinSegment,
    @SerializedName("points_won") val pointsWon: Int,
    @SerializedName("new_points_balance") val newPointsBalance: Long,
    @SerializedName("spins_used_today") val spinsUsedToday: Int,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    @SerializedName("spins_remaining") val spinsRemaining: Int,
    @SerializedName("next_spin_nonce") val nextSpinNonce: String
)

// Tasks
data class TaskItem(
    @SerializedName("id") val id: Long,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("task_type") val taskType: String,
    @SerializedName("action_url") val actionUrl: String?,
    @SerializedName("reward_points") val rewardPoints: Int,
    @SerializedName("is_repeatable_daily") val isRepeatableDaily: Boolean,
    @SerializedName("requires_proof") val requiresProof: Boolean,
    @SerializedName("is_completed") val isCompleted: Boolean,
    @SerializedName("submission_status") val submissionStatus: String
)

data class TasksListData(
    @SerializedName("tasks") val tasks: List<TaskItem>
)

data class TaskSubmitRequest(
    @SerializedName("task_id") val taskId: Long,
    @SerializedName("proof_text") val proofText: String? = null
)

data class TaskSubmitData(
    @SerializedName("submission_id") val submissionId: Long,
    @SerializedName("task_id") val taskId: Long,
    @SerializedName("status") val status: String,
    @SerializedName("points_awarded") val pointsAwarded: Int,
    @SerializedName("new_points_balance") val newPointsBalance: Long
)

// Daily Check-in
data class CheckInDay(
    @SerializedName("day") val day: Int,
    @SerializedName("reward_points") val rewardPoints: Int,
    @SerializedName("claimed") val claimed: Boolean
)

data class CheckInStatusData(
    @SerializedName("checked_in_today") val checkedInToday: Boolean,
    @SerializedName("current_streak") val currentStreak: Int,
    @SerializedName("today_reward_points") val todayRewardPoints: Int,
    @SerializedName("points_balance") val pointsBalance: Long,
    @SerializedName("days") val days: List<CheckInDay>
)

data class CheckInClaimData(
    @SerializedName("checked_in_today") val checkedInToday: Boolean,
    @SerializedName("current_streak") val currentStreak: Int,
    @SerializedName("points_awarded") val pointsAwarded: Int,
    @SerializedName("new_points_balance") val newPointsBalance: Long
)

// Wallet & Transactions
data class WalletData(
    @SerializedName("points_wallet") val pointsWallet: PointsWalletInfo,
    @SerializedName("cash_wallet") val cashWallet: CashWalletInfo,
    @SerializedName("conversion_rules") val conversionRules: ConversionRules
)

data class PointsWalletInfo(
    @SerializedName("points_balance") val pointsBalance: Long,
    @SerializedName("lifetime_points_earned") val lifetimePointsEarned: Long,
    @SerializedName("lifetime_points_converted") val lifetimePointsConverted: Long,
    @SerializedName("convertible_rupees") val convertibleRupees: Double,
    @SerializedName("convertible_points_needed") val convertiblePointsNeeded: Long
)

data class CashWalletInfo(
    @SerializedName("cash_balance") val cashBalance: Double,
    @SerializedName("total_withdrawn") val totalWithdrawn: Double,
    @SerializedName("pending_withdrawal") val pendingWithdrawal: Double
)

data class ConversionRules(
    @SerializedName("points_per_rupee") val pointsPerRupee: Int,
    @SerializedName("min_withdrawal_rs") val minWithdrawalRs: Double
)

data class ConvertPointsRequest(
    @SerializedName("points") val points: Long
)

data class ConvertPointsData(
    @SerializedName("points_deducted") val pointsDeducted: Long,
    @SerializedName("cash_credited_rs") val cashCreditedRs: Double,
    @SerializedName("new_points_balance") val newPointsBalance: Long,
    @SerializedName("new_cash_balance") val newCashBalance: Double
)

data class TransactionItem(
    @SerializedName("id") val id: Long,
    @SerializedName("wallet_type") val walletType: String,
    @SerializedName("tx_type") val txType: String,
    @SerializedName("category") val category: String,
    @SerializedName("points_amount") val pointsAmount: Long,
    @SerializedName("cash_amount") val cashAmount: Double,
    @SerializedName("description") val description: String,
    @SerializedName("created_at") val createdAt: String
)

data class TransactionsData(
    @SerializedName("transactions") val transactions: List<TransactionItem>
)

// Withdrawals
data class WithdrawalItem(
    @SerializedName("id") val id: Long,
    @SerializedName("amount_rs") val amountRs: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("account_details") val accountDetails: String,
    @SerializedName("account_holder_name") val accountHolderName: String,
    @SerializedName("status") val status: String,
    @SerializedName("admin_note") val adminNote: String?,
    @SerializedName("created_at") val createdAt: String
)

data class WithdrawalsListData(
    @SerializedName("min_withdrawal_rs") val minWithdrawalRs: Double,
    @SerializedName("allowed_methods") val allowedMethods: List<String>,
    @SerializedName("cash_balance") val cashBalance: Double,
    @SerializedName("pending_withdrawal") val pendingWithdrawal: Double,
    @SerializedName("total_withdrawn") val totalWithdrawn: Double,
    @SerializedName("withdrawals") val withdrawals: List<WithdrawalItem>
)

data class WithdrawalRequestPayload(
    @SerializedName("amount_rs") val amountRs: Double,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("account_details") val accountDetails: String,
    @SerializedName("account_holder_name") val accountHolderName: String
)

data class WithdrawalSubmitData(
    @SerializedName("withdrawal_id") val withdrawalId: Long,
    @SerializedName("amount_rs") val amountRs: Double,
    @SerializedName("status") val status: String,
    @SerializedName("new_cash_balance") val newCashBalance: Double
)

// Referrals
data class ReferralItem(
    @SerializedName("id") val id: Long,
    @SerializedName("full_name") val fullName: String,
    @SerializedName("registered_at") val registeredAt: String,
    @SerializedName("status") val status: String,
    @SerializedName("points_earned") val pointsEarned: Int
)

data class ReferralsData(
    @SerializedName("referral_code") val referralCode: String,
    @SerializedName("referrer_bonus_points") val referrerBonusPoints: Int,
    @SerializedName("referred_bonus_points") val referredBonusPoints: Int,
    @SerializedName("total_referrals") val totalReferrals: Int,
    @SerializedName("total_referral_points") val totalReferralPoints: Int,
    @SerializedName("referrals") val referrals: List<ReferralItem>
)

// Notifications
data class NotificationItem(
    @SerializedName("id") val id: Long,
    @SerializedName("title") val title: String,
    @SerializedName("message") val message: String,
    @SerializedName("type") val type: String,
    @SerializedName("is_read") val isRead: Int,
    @SerializedName("created_at") val createdAt: String
)

data class NotificationsData(
    @SerializedName("notifications") val notifications: List<NotificationItem>
)

data class MarkReadRequest(
    @SerializedName("notification_id") val notificationId: Long? = null
)

// Profile
data class UpdateProfileRequest(
    @SerializedName("full_name") val fullName: String,
    @SerializedName("phone") val phone: String?,
    @SerializedName("country") val country: String?
)

// Config & AdMob
data class AdPlacementConfig(
    @SerializedName("ad_unit_id") val adUnitId: String,
    @SerializedName("is_test_mode") val isTestMode: Boolean,
    @SerializedName("is_enabled") val isEnabled: Boolean,
    @SerializedName("reward_points") val rewardPoints: Int,
    @SerializedName("daily_cap") val dailyCap: Int
)

data class PublicConfigData(
    @SerializedName("app_name") val appName: String,
    @SerializedName("points_per_rupee") val pointsPerRupee: Int,
    @SerializedName("min_withdrawal_rs") val minWithdrawalRs: Double,
    @SerializedName("daily_spin_limit") val dailySpinLimit: Int,
    @SerializedName("support_email") val supportEmail: String,
    @SerializedName("privacy_policy_url") val privacyPolicyUrl: String,
    @SerializedName("terms_url") val termsUrl: String,
    @SerializedName("maintenance_mode") val maintenanceMode: Boolean,
    @SerializedName("admob") val admob: Map<String, AdPlacementConfig>
)

data class AdNonceRequest(
    @SerializedName("ad_format") val adFormat: String = "rewarded"
)

data class AdNonceData(
    @SerializedName("ad_nonce") val adNonce: String,
    @SerializedName("ad_format") val adFormat: String,
    @SerializedName("reward_points") val rewardPoints: Int
)

data class AdVerifyRequest(
    @SerializedName("ad_nonce") val adNonce: String
)

data class AdVerifyData(
    @SerializedName("points_awarded") val pointsAwarded: Int,
    @SerializedName("new_points_balance") val newPointsBalance: Long
)
