package com.rewardnova.app.ui.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.MarkReadRequest
import com.rewardnova.app.data.model.NotificationItem
import com.rewardnova.app.databinding.ActivityNotificationsBinding
import com.rewardnova.app.databinding.ItemSimpleRowBinding
import kotlinx.coroutines.launch

class NotificationsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationsBinding
    private val items = mutableListOf<NotificationItem>()
    private lateinit var adapter: NotifAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        adapter = NotifAdapter(items)
        binding.rvNotifications.layoutManager = LinearLayoutManager(this)
        binding.rvNotifications.adapter = adapter

        binding.btnMarkAllRead.setOnClickListener { markAllRead() }
        loadNotifications()
    }

    private fun loadNotifications() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getNotifications()
                val data = res.body()?.data
                if (res.isSuccessful && data != null) {
                    items.clear()
                    items.addAll(data.notifications)
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                Toast.makeText(this@NotificationsActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun markAllRead() {
        lifecycleScope.launch {
            try {
                RetrofitClient.getApiService().markNotificationsRead(MarkReadRequest(null))
                loadNotifications()
            } catch (_: Exception) {
            }
        }
    }

    private class NotifAdapter(private val rows: List<NotificationItem>) : RecyclerView.Adapter<NotifAdapter.VH>() {
        inner class VH(val b: ItemSimpleRowBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemSimpleRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount(): Int = rows.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val n = rows[position]
            holder.b.tvRowTitle.text = "${n.title}${if (n.isRead == 0) " (New)" else ""}"
            holder.b.tvRowSubtitle.text = "${n.message}\n${n.createdAt}"
        }
    }
}
