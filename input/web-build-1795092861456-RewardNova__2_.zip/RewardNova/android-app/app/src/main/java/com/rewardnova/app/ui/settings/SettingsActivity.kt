package com.rewardnova.app.ui.settings

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.rewardnova.app.BuildConfig
import com.rewardnova.app.RewardNovaApp
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        val tm = RewardNovaApp.instance.tokenManager
        binding.switchNotifications.isChecked = tm.isNotificationsEnabled()
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            tm.setNotificationsEnabled(isChecked)
        }

        binding.etApiBaseUrl.setText(tm.getApiBaseUrl())
        binding.tvAppVersion.text = "Version ${BuildConfig.VERSION_NAME} (${BuildConfig.APPLICATION_ID})"

        binding.btnSaveApiUrl.setOnClickListener {
            val url = binding.etApiBaseUrl.text?.toString()?.trim().orEmpty()
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                binding.etApiBaseUrl.error = "URL must start with http:// or https://"
                return@setOnClickListener
            }
            tm.setCustomApiBaseUrl(url)
            RetrofitClient.resetClient()
            Toast.makeText(this, "API endpoint updated.", Toast.LENGTH_SHORT).show()
        }

        binding.btnResetApiUrl.setOnClickListener {
            tm.setCustomApiBaseUrl(null)
            RetrofitClient.resetClient()
            binding.etApiBaseUrl.setText(BuildConfig.API_BASE_URL)
            Toast.makeText(this, "Reset to default API URL.", Toast.LENGTH_SHORT).show()
        }
    }
}
