package com.rewardnova.app.ui.main

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.R
import com.rewardnova.app.ads.AdManager
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.databinding.ActivityMainBinding
import com.rewardnova.app.ui.checkin.DailyCheckInActivity
import com.rewardnova.app.ui.notifications.NotificationsActivity
import com.rewardnova.app.ui.profile.ProfileActivity
import com.rewardnova.app.ui.referrals.ReferralActivity
import com.rewardnova.app.ui.settings.SettingsActivity
import com.rewardnova.app.ui.spin.SpinWheelActivity
import com.rewardnova.app.ui.support.HelpSupportActivity
import com.rewardnova.app.ui.tasks.TasksActivity
import com.rewardnova.app.ui.transactions.TransactionHistoryActivity
import com.rewardnova.app.ui.wallet.WalletActivity
import com.rewardnova.app.ui.withdrawals.WithdrawalsActivity
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AdManager.refreshConfig {
            AdManager.attachBanner(this, binding.adBannerContainer)
            AdManager.preloadInterstitial(this)
            AdManager.preloadRewarded(this)
        }

        setupClicks()
        loadDashboard()
    }

    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    private fun setupClicks() {
        binding.swipeRefresh.setOnRefreshListener { loadDashboard() }
        binding.btnSpin.setOnClickListener { startActivity(Intent(this, SpinWheelActivity::class.java)) }
        binding.btnCheckIn.setOnClickListener { startActivity(Intent(this, DailyCheckInActivity::class.java)) }
        binding.btnTasks.setOnClickListener { startActivity(Intent(this, TasksActivity::class.java)) }
        binding.btnWallet.setOnClickListener { startActivity(Intent(this, WalletActivity::class.java)) }
        binding.btnWithdrawals.setOnClickListener { startActivity(Intent(this, WithdrawalsActivity::class.java)) }
        binding.btnReferrals.setOnClickListener { startActivity(Intent(this, ReferralActivity::class.java)) }
        binding.btnTransactions.setOnClickListener { startActivity(Intent(this, TransactionHistoryActivity::class.java)) }
        binding.btnNotifications.setOnClickListener { startActivity(Intent(this, NotificationsActivity::class.java)) }
        binding.btnSupport.setOnClickListener { startActivity(Intent(this, HelpSupportActivity::class.java)) }
        binding.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        binding.btnWatchRewardedAd.setOnClickListener {
            AdManager.showServerVerifiedRewardedAd(this) { _, message, _ ->
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                loadDashboard()
            }
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_tasks -> {
                    startActivity(Intent(this, TasksActivity::class.java))
                    false
                }
                R.id.nav_wallet -> {
                    startActivity(Intent(this, WalletActivity::class.java))
                    false
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    false
                }
                else -> false
            }
        }
    }

    private fun loadDashboard() {
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getDashboard()
                val body = res.body()
                if (res.isSuccessful && body?.success == true && body.data != null) {
                    val user = body.data.user
                    val rules = body.data.rules
                    binding.tvWelcome.text = "Hello, ${user.fullName}"
                    binding.tvPointsBalance.text = "${user.pointsBalance} pts"
                    binding.tvCashBalance.text = String.format(
                        Locale.US,
                        "Cash Wallet: Rs %.2f  |  %d pts = Rs 1",
                        user.cashBalance,
                        rules.pointsPerRupee
                    )
                    binding.tvSpinsRemaining.text =
                        "Daily Spins Left: ${user.spinsRemaining} / ${user.dailySpinLimit}"
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Sync error: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }
}
