package com.rewardnova.app.ui.profile

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.rewardnova.app.RewardNovaApp
import com.rewardnova.app.data.api.RetrofitClient
import com.rewardnova.app.data.model.UpdateProfileRequest
import com.rewardnova.app.databinding.ActivityProfileBinding
import com.rewardnova.app.ui.auth.SignInActivity
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnSaveProfile.setOnClickListener { saveProfile() }
        binding.btnLogout.setOnClickListener { logout() }

        loadProfile()
    }

    private fun loadProfile() {
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().getProfile()
                val u = res.body()?.data
                if (res.isSuccessful && u != null) {
                    binding.tvProfileEmail.text = u.email
                    binding.tvProfileMeta.text = "Status: ${u.accountStatus.uppercase()}  |  Code: ${u.referralCode}"
                    binding.etFullName.setText(u.fullName)
                    binding.etPhone.setText(u.phone.orEmpty())
                    binding.etCountry.setText(u.country ?: "PK")
                }
            } catch (e: Exception) {
                Toast.makeText(this@ProfileActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveProfile() {
        val name = binding.etFullName.text?.toString()?.trim().orEmpty()
        val phone = binding.etPhone.text?.toString()?.trim()
        val country = binding.etCountry.text?.toString()?.trim()

        if (name.length < 2) {
            binding.etFullName.error = "Enter your full name"
            return
        }

        binding.btnSaveProfile.isEnabled = false
        lifecycleScope.launch {
            try {
                val res = RetrofitClient.getApiService().updateProfile(UpdateProfileRequest(name, phone, country))
                if (res.isSuccessful && res.body()?.success == true) {
                    Toast.makeText(this@ProfileActivity, "Profile updated.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@ProfileActivity, RetrofitClient.extractErrorMessage(res), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ProfileActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnSaveProfile.isEnabled = true
            }
        }
    }

    private fun logout() {
        lifecycleScope.launch {
            try {
                RetrofitClient.getApiService().logout()
            } catch (_: Exception) {
            } finally {
                RewardNovaApp.instance.tokenManager.clearSession()
                startActivity(Intent(this@ProfileActivity, SignInActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
            }
        }
    }
}
