# RewardNova AndroidForge APK Build & Release Signing Guide

## 1. Compatibility Summary
- **Gradle Version**: `8.7` (`gradle/wrapper/gradle-wrapper.properties`)
- **Android Gradle Plugin**: `8.5.2`
- **Kotlin**: `1.9.24`
- **JDK**: `17`
- **compileSdk / targetSdk**: `34`, **minSdk**: `24`
- **R8/ProGuard**: Enabled in `release` (`isMinifyEnabled = true`, `isShrinkResources = true`) with `app/proguard-rules.pro` preserving all Gson `@SerializedName` models, `TypeToken` signatures, and Retrofit interfaces.

## 2. Building in AndroidForge
1. Extract `RewardNova.zip` and upload or import the `RewardNova/android-app/` folder into **AndroidForge** (the directory containing `settings.gradle.kts`, `build.gradle.kts`, `gradlew`, and `app/`).
2. Confirm `gradle.properties` contains your desired `APP_APPLICATION_ID`, `API_BASE_URL_RELEASE`, and `ADMOB_APP_ID`.
3. Select JDK 17 in build settings if prompted and trigger the **Debug** or **Release** APK build.

## 3. Generating a Signed Release APK (CLI / Android Studio)
1. Generate a release keystore using JDK `keytool`:
   ```bash
   keytool -genkey -v -keystore android-app/app/rewardnova-release.jks \
     -alias rewardnova_key -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Copy `android-app/keystore.properties.example` to `android-app/keystore.properties` and fill in your keystore credentials:
   ```properties
   storeFile=rewardnova-release.jks
   storePassword=YOUR_STORE_PASSWORD
   keyAlias=rewardnova_key
   keyPassword=YOUR_KEY_PASSWORD
   ```
3. Build the signed Release APK:
   ```bash
   cd RewardNova/android-app
   ./gradlew assembleRelease
   ```
4. The signed APK output will be located at:
   `android-app/app/build/outputs/apk/release/app-release.apk`
