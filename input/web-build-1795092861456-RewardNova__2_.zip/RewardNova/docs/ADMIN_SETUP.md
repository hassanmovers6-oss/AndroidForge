# RewardNova Admin Account Setup & Login Guide

`schema.sql` intentionally does **not** insert a hardcoded default admin password.

## Option A: Create Admin via CLI (Recommended)
Run from the `RewardNova/database/` directory using XAMPP's PHP binary:
```bash
php setup_admin.php --name="Super Admin" --email="admin@yourdomain.com" --password="StrongPassword123!"
```

## Option B: One-Time Web Installer
1. Open `http://localhost/RewardNova/database/setup_admin.php` in your browser.
2. Enter your Full Name, Admin Email, and a strong password (minimum 8 characters).
3. Submit the form. Once created, `setup_admin.php` automatically locks browser access with HTTP 403 so nobody else can register an admin via the web.

## Logging Into Admin Panel
1. Open `http://localhost/RewardNova/admin-panel/login.php`.
2. Sign in with the email and password you configured above.
3. Newly registered Android app users will automatically appear under **Users & Points**.
