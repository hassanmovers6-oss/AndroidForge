# RewardNova MySQL Database Import Guide

## Option A: Import via phpMyAdmin (XAMPP)
1. Start **Apache** and **MySQL** in XAMPP Control Panel.
2. Open `http://localhost/phpmyadmin/` in your browser.
3. Click **Import** in the top navigation bar (you do not need to manually create the database first; `schema.sql` runs `CREATE DATABASE IF NOT EXISTS rewardnova`).
4. Click **Choose File** and select `RewardNova/database/schema.sql`.
5. Keep format set to **SQL** and click **Import** (or **Go**).
6. Confirm all 20 tables (`admins`, `users`, `user_sessions`, `user_points`, `cash_wallets`, `tasks`, `task_submissions`, `spin_reward_settings`, `spin_history`, `wallet_transactions`, `withdrawal_requests`, `referrals`, `referral_rewards`, `notifications`, `app_settings`, `advertisements_settings`, `audit_logs`, `password_reset_tokens`, `ad_reward_verifications`, `api_rate_limits`) appear under `rewardnova`.

## Option B: Import via MySQL Command Line
```bash
mysql -u root -p < RewardNova/database/schema.sql
```

## Non-Destructive Upgrades
To apply incremental schema updates later without dropping tables or data:
```bash
mysql -u root -p rewardnova < RewardNova/database/upgrade_v1_to_v2.sql
```
