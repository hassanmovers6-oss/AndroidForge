# RewardNova Verification & Testing Report

## 1. Tests Executed in This Environment
Because this sandbox environment does not include `php`, `mysql`, `java`, or `gradle` binaries, automated structural & static consistency checks were executed with Python 3 and `unzip`:

- **Android XML Well-Formedness**: Validated all Android XML files (`AndroidManifest.xml`, `res/layout/*.xml`, `res/values/*.xml`, `res/xml/*.xml`, `res/drawable/*.xml`, `res/mipmap-anydpi-v26/*.xml`, `res/menu/*.xml`) with `xml.etree.ElementTree`.
- **Android Manifest & Activity Cross-Check**: Verified all 16 Activities (`SplashActivity`, `SignUpActivity`, `SignInActivity`, `ForgotPasswordActivity`, `MainActivity`, `SpinWheelActivity`, `TasksActivity`, `DailyCheckInActivity`, `WalletActivity`, `WithdrawalsActivity`, `ReferralActivity`, `TransactionHistoryActivity`, `NotificationsActivity`, `ProfileActivity`, `HelpSupportActivity`, `SettingsActivity`) exist in Kotlin and are declared in `AndroidManifest.xml`.
- **SQL Schema & PHP Query Consistency**: Verified all 17 required MySQL tables exist in `database/schema.sql` and match table references in `backend-api` and `admin-panel`.
- **ZIP Archive Integrity**: Verified `public/RewardNova.zip` using `unzip -t`.
- **Web Delivery Console Build**: Verified via `npm run lint` (`tsc --noEmit`) and `npm run build`.

## 2. Runtime Tests Requiring Local XAMPP + AndroidForge Execution
The following end-to-end runtime flows were **not executed** in the cloud sandbox and must be verified locally on XAMPP + AndroidForge:
1. User registration (`POST /api/v1/auth/register`) & immediate visibility in Admin Panel `users.php`.
2. User login (`POST /api/v1/auth/login`) & Bearer token session persistence.
3. Task submission (`POST /api/v1/tasks/submit`), instant `approved` response, single-credit guarantee, and duplicate rejection (`409`).
4. Server-authoritative spin execution (`POST /api/v1/spin/execute`), single-credit guarantee, and daily limit (`5`) enforcement (`429`).
5. Separate Points vs Cash Wallet conversion (`1000 pts = Rs 1`) & minimum withdrawal (`Rs 100`) submission (`POST /api/v1/withdrawals`).
6. Referral code attribution & dual-sided bonus crediting.
7. Gradle `assembleRelease` APK build & release signing in AndroidForge / Android Studio.
