# RewardNova PHP REST API Configuration Guide

## Base URL Routing
The front-controller router lives at `backend-api/public/index.php` with `.htaccess` URL rewriting.
- **XAMPP Local URL**: `http://localhost/RewardNova/backend-api/public/`
- **Android Emulator URL**: `http://10.0.2.2/RewardNova/backend-api/public/`
- **Production URL (HTTPS required)**: `https://api.yourdomain.com/` (point your Apache/Nginx virtual host `DocumentRoot` directly to `backend-api/public/`).

## Core Endpoints (`api/v1/...`)
- `POST /api/v1/auth/register` — Full Name, Email, Password, Confirm Password, optional Referral Code
- `POST /api/v1/auth/login` — Email, Password (returns Bearer token)
- `POST /api/v1/auth/forgot-password` — Issues 6-digit recovery code
- `POST /api/v1/auth/reset-password` — Validates 6-digit code and resets password
- `POST /api/v1/auth/logout` — Revokes active session token
- `GET /api/v1/dashboard` — User balance, rules, unread notifications, recent transactions
- `GET /api/v1/tasks` & `POST /api/v1/tasks/submit` — Instant server-side task validation & auto-approval
- `GET /api/v1/spin/wheel`, `POST /api/v1/spin/execute`, `GET /api/v1/spin/history` — Server-weighted spin with daily limit & nonce idempotency
- `GET /api/v1/checkin` & `POST /api/v1/checkin` — 7-day streak daily check-in
- `GET /api/v1/wallet`, `POST /api/v1/wallet/convert`, `GET /api/v1/transactions` — Separate points & cash wallets (1000 pts = Rs 1)
- `GET /api/v1/withdrawals` & `POST /api/v1/withdrawals` — Minimum Rs 100 payout requests
- `GET /api/v1/referrals` — Referral code and invited users
- `GET /api/v1/notifications` & `POST /api/v1/notifications/read`
- `GET /api/v1/config` — Public business rules & AdMob placement unit IDs
- `POST /api/v1/ads/reward-nonce` & `POST /api/v1/ads/reward-verify` — Server-verified rewarded ad credit
