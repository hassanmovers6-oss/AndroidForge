# RewardNova Android App Configuration Guide

## 1. Final Chosen & Configurable Package Name
- Default package name: **`com.rewardnova.app`**
- To change the package name before release, update `APP_APPLICATION_ID` in `android-app/gradle.properties`:
  ```properties
  APP_APPLICATION_ID=com.yourcompany.rewardnova
  ```

## 2. Configurable API Base URL
Never hardcode `localhost` in production builds. Edit `android-app/gradle.properties`:
```properties
# Android Emulator connecting to local XAMPP
API_BASE_URL_DEBUG=http://10.0.2.2/RewardNova/backend-api/public/

# Production HTTPS API
API_BASE_URL_RELEASE=https://api.yourdomain.com/
```
For physical Android phones on the same Wi-Fi during local XAMPP testing, either set `API_BASE_URL_DEBUG` to `http://YOUR_PC_LAN_IP/RewardNova/backend-api/public/` (and add your LAN IP to `res/xml/network_security_config.xml`) or change the URL live inside the app's **Settings** screen.

## 3. AdMob Configuration
- `gradle.properties` sets `ADMOB_APP_ID=ca-app-pub-3940256099942544~3347511713` (Google's official Android Test App ID).
- Individual ad format unit IDs (`banner`, `interstitial`, `native`, `rewarded`, `rewarded_interstitial`, `app_open`) are stored in MySQL `advertisements_settings` and managed dynamically from the **Admin Panel -> AdMob Settings** page.
