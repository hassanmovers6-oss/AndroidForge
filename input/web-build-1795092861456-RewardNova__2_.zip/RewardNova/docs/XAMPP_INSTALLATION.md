# RewardNova Local XAMPP Installation Guide

## 1. Prerequisites
- **XAMPP** with **PHP 8.0+** (PHP 8.1 or 8.2 recommended) and **MariaDB / MySQL**.
- Apache `mod_rewrite` enabled (enabled by default in XAMPP).

## 2. Step-by-Step XAMPP Setup
1. Download and install XAMPP from the official Apache Friends distribution.
2. Open the **XAMPP Control Panel** and start **Apache** and **MySQL**.
3. Extract `RewardNova.zip` so the project folder resides inside XAMPP's web root:
   - Windows: `C:\xampp\htdocs\RewardNova\`
   - macOS: `/Applications/XAMPP/htdocs/RewardNova/`
   - Linux: `/opt/lampp/htdocs/RewardNova/`
4. Verify your directory layout matches:
   - `htdocs/RewardNova/backend-api/`
   - `htdocs/RewardNova/admin-panel/`
   - `htdocs/RewardNova/database/`
   - `htdocs/RewardNova/android-app/`
   - `htdocs/RewardNova/docs/`
5. Copy `backend-api/config/env.example.php` to `backend-api/config/env.local.php` and verify MySQL credentials:
   ```php
   return [
       'DB_HOST' => '127.0.0.1',
       'DB_PORT' => '3306',
       'DB_NAME' => 'rewardnova',
       'DB_USER' => 'root',
       'DB_PASS' => '',
       'APP_ENV' => 'local',
       'TOKEN_TTL_DAYS' => 30,
   ];
   ```
6. Test the health endpoint in your browser:
   `http://localhost/RewardNova/backend-api/public/api/v1/health`
   Expected JSON: `{"success":true,"message":"API is healthy.",...}`.
