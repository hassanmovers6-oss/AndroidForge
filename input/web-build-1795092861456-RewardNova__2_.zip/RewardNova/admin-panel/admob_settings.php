<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $adUnitId = trim((string)($_POST['ad_unit_id'] ?? ''));
    $isTestMode = isset($_POST['is_test_mode']) ? 1 : 0;
    $isEnabled = isset($_POST['is_enabled']) ? 1 : 0;
    $rewardPoints = max(0, (int)($_POST['reward_points'] ?? 0));
    $dailyCap = max(0, (int)($_POST['daily_cap'] ?? 0));
    $notes = trim((string)($_POST['notes'] ?? ''));

    if ($id > 0 && $adUnitId !== '') {
        $pdo->prepare('
            UPDATE advertisements_settings
            SET ad_unit_id = :unit, is_test_mode = :tm, is_enabled = :en, reward_points = :pts, daily_cap = :cap, notes = :notes
            WHERE id = :id
        ')->execute([
            ':unit' => $adUnitId,
            ':tm' => $isTestMode,
            ':en' => $isEnabled,
            ':pts' => $rewardPoints,
            ':cap' => $dailyCap,
            ':notes' => $notes,
            ':id' => $id,
        ]);
        adminAudit($pdo, (int)$admin['id'], 'admob_setting_updated', 'advertisements_settings', $id, "Updated unit {$adUnitId}, test={$isTestMode}, enabled={$isEnabled}");
        flashSet('success', 'AdMob placement settings updated.');
    }
    header('Location: admob_settings.php');
    exit;
}

$ads = $pdo->query('SELECT * FROM advertisements_settings ORDER BY id ASC')->fetchAll();

renderAdminHeader('AdMob Settings', 'admob', $admin);
?>
<div class="card" style="margin-bottom:20px;">
  <p style="margin:0;color:#475569;">
    Pre-populated with official <strong>Google Mobile Ads Test Unit IDs</strong>. Replace with your live AdMob Ad Unit IDs only after verifying your Android release build. Rewarded ad points are granted strictly after server-side nonce verification.
  </p>
</div>

<div class="card">
  <div class="section-header">
    <h2>AdMob Placement Configuration (All 6 Formats)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Ad Format</th>
          <th>Ad Unit ID</th>
          <th>Test Mode</th>
          <th>Enabled</th>
          <th>Reward Pts</th>
          <th>Daily Cap</th>
          <th>Notes</th>
          <th>Save</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($ads as $ad): ?>
          <tr>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
              <input type="hidden" name="id" value="<?= (int)$ad['id'] ?>">
              <td><strong><?= e(ucwords(str_replace('_', ' ', $ad['ad_format']))) ?></strong></td>
              <td><input type="text" name="ad_unit_id" value="<?= e($ad['ad_unit_id']) ?>" required style="width:270px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;font-family:monospace;font-size:12px;"></td>
              <td><input type="checkbox" name="is_test_mode" <?= ((int)$ad['is_test_mode']) === 1 ? 'checked' : '' ?>></td>
              <td><input type="checkbox" name="is_enabled" <?= ((int)$ad['is_enabled']) === 1 ? 'checked' : '' ?>></td>
              <td><input type="number" name="reward_points" min="0" value="<?= (int)$ad['reward_points'] ?>" style="width:76px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;"></td>
              <td><input type="number" name="daily_cap" min="0" value="<?= (int)$ad['daily_cap'] ?>" style="width:70px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;"></td>
              <td><input type="text" name="notes" value="<?= e($ad['notes'] ?? '') ?>" style="width:180px;padding:6px;border:1px solid #cbd5e1;border-radius:6px;"></td>
              <td><button type="submit" class="btn btn-primary btn-sm">Save</button></td>
            </form>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
