<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

$logs = $pdo->query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 250')->fetchAll();

renderAdminHeader('Audit Logs', 'audit_logs', $admin);
?>
<div class="card">
  <div class="section-header">
    <h2>Security & System Audit Trail (<?= count($logs) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Actor</th>
          <th>Action</th>
          <th>Target</th>
          <th>Details</th>
          <th>IP Address</th>
          <th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($logs)): ?>
          <tr><td colspan="7" style="color:#64748b;">No audit logs yet.</td></tr>
        <?php else: foreach ($logs as $log): ?>
          <tr>
            <td class="num">#<?= (int)$log['id'] ?></td>
            <td><?= e(ucfirst($log['actor_type'])) ?> #<?= e((string)($log['actor_id'] ?? '-')) ?></td>
            <td><code><?= e($log['action']) ?></code></td>
            <td><?= e(($log['target_type'] ?? '-') . ' #' . ($log['target_id'] ?? '-')) ?></td>
            <td><?= e($log['details'] ?? '') ?></td>
            <td><code><?= e($log['ip_address'] ?? '-') ?></code></td>
            <td><?= e($log['created_at']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
