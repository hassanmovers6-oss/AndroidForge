<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['user_id'] ?? 0);

    if ($action === 'update_status' && $userId > 0) {
        $newStatus = $_POST['account_status'] ?? 'active';
        if (in_array($newStatus, ['active', 'suspended', 'banned'], true)) {
            $pdo->prepare('UPDATE users SET account_status = :st WHERE id = :id')->execute([':st' => $newStatus, ':id' => $userId]);
            if ($newStatus !== 'active') {
                $pdo->prepare('UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP() WHERE user_id = :id AND revoked_at IS NULL')->execute([':id' => $userId]);
            }
            adminAudit($pdo, (int)$admin['id'], 'user_status_changed', 'user', $userId, "Changed status to {$newStatus}");
            flashSet('success', "User #{$userId} status updated to {$newStatus}.");
        }
        header('Location: users.php');
        exit;
    }

    if ($action === 'adjust_points' && $userId > 0) {
        $mode = ($_POST['mode'] ?? 'credit') === 'debit' ? 'debit' : 'credit';
        $amount = max(0, (int)($_POST['points_amount'] ?? 0));
        $reason = trim((string)($_POST['reason'] ?? 'Admin points adjustment'));

        if ($amount <= 0) {
            flashSet('error', 'Points amount must be greater than zero.');
            header('Location: users.php');
            exit;
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT points_balance FROM user_points WHERE user_id = :uid FOR UPDATE');
            $stmt->execute([':uid' => $userId]);
            $current = (int)$stmt->fetchColumn();

            $newBal = $mode === 'credit' ? $current + $amount : max(0, $current - $amount);
            $actualDelta = abs($newBal - $current);

            $pdo->prepare('UPDATE user_points SET points_balance = :bal WHERE user_id = :uid')->execute([':bal' => $newBal, ':uid' => $userId]);
            $pdo->prepare('
                INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, points_amount, balance_after_points, reference_id, description)
                VALUES (:uid, "points", :tx, "admin_adjustment", :pts, :bal, :ref, :desc)
            ')->execute([
                ':uid' => $userId,
                ':tx' => $mode,
                ':pts' => $actualDelta,
                ':bal' => $newBal,
                ':ref' => 'ADM-' . $admin['id'] . '-' . time(),
                ':desc' => $reason !== '' ? $reason : 'Admin points adjustment',
            ]);
            adminAudit($pdo, (int)$admin['id'], 'admin_points_' . $mode, 'user', $userId, "{$mode} {$actualDelta} pts: {$reason}");
            $pdo->commit();
            flashSet('success', "Points {$mode}ed successfully for User #{$userId}. New balance: {$newBal} pts.");
        } catch (Throwable $e) {
            $pdo->rollBack();
            flashSet('error', 'Failed to adjust points.');
        }
        header('Location: users.php');
        exit;
    }
}

$search = trim((string)($_GET['q'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));

$sql = '
    SELECT u.id, u.full_name, u.email, u.referral_code, u.account_status, u.registered_at, u.last_active_at,
           p.points_balance, p.lifetime_points_earned, p.spins_used_today, w.cash_balance
    FROM users u
    LEFT JOIN user_points p ON p.user_id = u.id
    LEFT JOIN cash_wallets w ON w.user_id = u.id
    WHERE 1=1
';
$params = [];
if ($search !== '') {
    $sql .= ' AND (u.full_name LIKE :q OR u.email LIKE :q2 OR u.referral_code LIKE :q3)';
    $params[':q'] = '%' . $search . '%';
    $params[':q2'] = '%' . $search . '%';
    $params[':q3'] = '%' . $search . '%';
}
if (in_array($statusFilter, ['active', 'suspended', 'banned'], true)) {
    $sql .= ' AND u.account_status = :st';
    $params[':st'] = $statusFilter;
}
$sql .= ' ORDER BY u.id DESC LIMIT 200';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

renderAdminHeader('Users & Points Management', 'users', $admin);
?>
<div class="card" style="margin-bottom:20px;">
  <form method="get" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;">
    <div class="field" style="flex:1;min-width:220px;">
      <label for="q">Search Name, Email, or Referral Code</label>
      <input id="q" name="q" type="text" value="<?= e($search) ?>" placeholder="Search users...">
    </div>
    <div class="field" style="width:180px;">
      <label for="status">Account Status</label>
      <select id="status" name="status">
        <option value="">All Statuses</option>
        <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
        <option value="suspended" <?= $statusFilter === 'suspended' ? 'selected' : '' ?>>Suspended</option>
        <option value="banned" <?= $statusFilter === 'banned' ? 'selected' : '' ?>>Banned</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Filter</button>
    <a href="users.php" class="btn btn-secondary">Reset</a>
  </form>
</div>

<div class="card">
  <div class="section-header">
    <h2>Registered Users (<?= count($users) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Referral Code</th>
          <th>Status</th>
          <th class="num">Points</th>
          <th class="num">Cash (Rs)</th>
          <th>Registered</th>
          <th>Account Actions</th>
          <th>Points Adjustment</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($users)): ?>
          <tr><td colspan="9" style="color:#64748b;">No matching users found.</td></tr>
        <?php else: foreach ($users as $u): ?>
          <tr>
            <td class="num">#<?= (int)$u['id'] ?></td>
            <td><strong><?= e($u['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($u['email']) ?></span></td>
            <td><code><?= e($u['referral_code']) ?></code></td>
            <td><span class="status status-<?= e($u['account_status']) ?>"><?= e(ucfirst($u['account_status'])) ?></span></td>
            <td class="num"><?= number_format((int)$u['points_balance']) ?></td>
            <td class="num"><?= number_format((float)$u['cash_balance'], 2) ?></td>
            <td><?= e($u['registered_at']) ?></td>
            <td>
              <form method="post" style="display:flex;gap:6px;align-items:center;">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <select name="account_status" style="padding:4px 6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">
                  <option value="active" <?= $u['account_status'] === 'active' ? 'selected' : '' ?>>Active</option>
                  <option value="suspended" <?= $u['account_status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                  <option value="banned" <?= $u['account_status'] === 'banned' ? 'selected' : '' ?>>Banned</option>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm">Save</button>
              </form>
            </td>
            <td>
              <form method="post" style="display:flex;gap:6px;align-items:center;">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="action" value="adjust_points">
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <select name="mode" style="padding:4px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">
                  <option value="credit">+ Add</option>
                  <option value="debit">- Deduct</option>
                </select>
                <input type="number" name="points_amount" min="1" placeholder="Pts" required style="width:72px;padding:4px 6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">
                <input type="text" name="reason" placeholder="Reason" style="width:100px;padding:4px 6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">
                <button type="submit" class="btn btn-primary btn-sm">Apply</button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
