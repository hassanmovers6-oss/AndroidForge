<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_limit') {
        $limit = max(1, min(100, (int)($_POST['daily_spin_limit'] ?? 5)));
        $pdo->prepare("UPDATE app_settings SET setting_value = :v WHERE setting_key = 'daily_spin_limit'")
            ->execute([':v' => (string)$limit]);
        adminAudit($pdo, (int)$admin['id'], 'spin_limit_updated', 'app_settings', null, "Set daily_spin_limit={$limit}");
        flashSet('success', "Daily spin limit updated to {$limit}.");
    } elseif ($action === 'save_segment') {
        $id = (int)($_POST['id'] ?? 0);
        $label = trim((string)($_POST['label'] ?? ''));
        $pts = max(0, (int)($_POST['points_reward'] ?? 0));
        $weight = max(0, (int)($_POST['weight'] ?? 1));
        $color = trim((string)($_POST['color_hex'] ?? '#1E3A8A'));
        $active = isset($_POST['is_active']) ? 1 : 0;

        if ($id > 0 && $label !== '') {
            $pdo->prepare('UPDATE spin_reward_settings SET label = :l, points_reward = :p, weight = :w, color_hex = :c, is_active = :a WHERE id = :id')
                ->execute([':l' => $label, ':p' => $pts, ':w' => $weight, ':c' => $color, ':a' => $active, ':id' => $id]);
            adminAudit($pdo, (int)$admin['id'], 'spin_segment_updated', 'spin_reward_settings', $id, "{$label} ({$pts} pts, weight {$weight})");
            flashSet('success', "Spin segment '{$label}' updated.");
        }
    }
    header('Location: spin_settings.php');
    exit;
}

$dailyLimit = (int)($pdo->query("SELECT setting_value FROM app_settings WHERE setting_key = 'daily_spin_limit'")->fetchColumn() ?: 5);
$segments = $pdo->query('SELECT * FROM spin_reward_settings ORDER BY segment_index ASC')->fetchAll();

renderAdminHeader('Spin Wheel Configuration', 'spin_settings', $admin);
?>
<div class="card" style="margin-bottom:20px;">
  <div class="section-header">
    <h2>Daily Spin Limit</h2>
  </div>
  <form method="post" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;">
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
    <input type="hidden" name="action" value="update_limit">
    <div class="field" style="width:220px;">
      <label for="daily_spin_limit">Spins Allowed Per User Per Day</label>
      <input id="daily_spin_limit" name="daily_spin_limit" type="number" min="1" max="100" value="<?= $dailyLimit ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Save Daily Limit</button>
  </form>
</div>

<div class="card">
  <div class="section-header">
    <h2>Wheel Segments & Server Probability Weights</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Index</th>
          <th>Label</th>
          <th>Points Reward</th>
          <th>Weight</th>
          <th>Color Hex</th>
          <th>Active</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($segments as $seg): ?>
          <tr>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
              <input type="hidden" name="action" value="save_segment">
              <input type="hidden" name="id" value="<?= (int)$seg['id'] ?>">
              <td class="num">#<?= (int)$seg['segment_index'] ?></td>
              <td><input type="text" name="label" value="<?= e($seg['label']) ?>" required style="padding:6px;border:1px solid #cbd5e1;border-radius:6px;width:120px;"></td>
              <td><input type="number" name="points_reward" min="0" value="<?= (int)$seg['points_reward'] ?>" required style="padding:6px;border:1px solid #cbd5e1;border-radius:6px;width:90px;"></td>
              <td><input type="number" name="weight" min="0" value="<?= (int)$seg['weight'] ?>" required style="padding:6px;border:1px solid #cbd5e1;border-radius:6px;width:80px;"></td>
              <td><input type="color" name="color_hex" value="<?= e($seg['color_hex']) ?>" style="height:32px;width:54px;border:1px solid #cbd5e1;border-radius:6px;"></td>
              <td><input type="checkbox" name="is_active" <?= ((int)$seg['is_active']) === 1 ? 'checked' : '' ?>></td>
              <td><button type="submit" class="btn btn-primary btn-sm">Update</button></td>
            </form>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
