<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

$pdo = adminDb();
$adminCount = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Valid email and password are required.';
    } else {
        $stmt = $pdo->prepare('SELECT id, full_name, email, password_hash, role, status FROM admins WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $admin = $stmt->fetch();

        if (!$admin || !password_verify($password, (string)$admin['password_hash'])) {
            $error = 'Invalid administrator email or password.';
        } elseif ($admin['status'] !== 'active') {
            $error = 'This administrator account is disabled.';
        } else {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$admin['id'];
            $_SESSION['admin_role'] = $admin['role'];

            $pdo->prepare('UPDATE admins SET last_login_at = UTC_TIMESTAMP(), last_login_ip = :ip WHERE id = :id')
                ->execute([':ip' => $_SERVER['REMOTE_ADDR'] ?? null, ':id' => (int)$admin['id']]);
            adminAudit($pdo, (int)$admin['id'], 'admin_login', 'admin', (int)$admin['id'], 'Admin signed in');

            header('Location: index.php');
            exit;
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In - RewardNova Admin</title>
  <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px;">
  <div class="card" style="width:100%;max-width:420px;padding:28px;">
    <h1 style="margin:0 0 6px;font-size:22px;">RewardNova Admin</h1>
    <p style="margin:0 0 20px;color:#64748b;font-size:13px;">Sign in to manage users, spin rewards, tasks, payouts, and AdMob configuration.</p>

    <?php if ($adminCount === 0): ?>
      <div class="flash flash-error">
        No administrator account exists yet. <a href="../database/setup_admin.php" style="color:#b91c1c;font-weight:700;">Run initial admin setup</a> first.
      </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
      <div class="flash flash-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
      <div class="field" style="margin-bottom:14px;">
        <label for="email">Admin Email</label>
        <input id="email" name="email" type="email" required placeholder="admin@yourdomain.com">
      </div>
      <div class="field" style="margin-bottom:18px;">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Sign In</button>
    </form>
  </div>
</body>
</html>
