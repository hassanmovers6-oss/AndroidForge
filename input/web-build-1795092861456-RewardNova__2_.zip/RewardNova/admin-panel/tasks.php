<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create_task') {
        $title = trim((string)($_POST['title'] ?? ''));
        $desc = trim((string)($_POST['description'] ?? ''));
        $type = $_POST['task_type'] ?? 'visit';
        $url = trim((string)($_POST['action_url'] ?? ''));
        $points = max(1, (int)($_POST['reward_points'] ?? 50));
        $daily = isset($_POST['is_repeatable_daily']) ? 1 : 0;
        $proof = isset($_POST['requires_proof']) ? 1 : 0;
        $keyword = trim((string)($_POST['verification_keyword'] ?? ''));

        if ($title !== '' && $desc !== '') {
            $pdo->prepare('
                INSERT INTO tasks (title, description, task_type, action_url, reward_points, is_repeatable_daily, requires_proof, verification_keyword, is_active)
                VALUES (:t, :d, :ty, :url, :pts, :daily, :proof, :kw, 1)
            ')->execute([
                ':t' => $title,
                ':d' => $desc,
                ':ty' => $type,
                ':url' => $url !== '' ? $url : null,
                ':pts' => $points,
                ':daily' => $daily,
                ':proof' => $proof,
                ':kw' => $keyword !== '' ? $keyword : null,
            ]);
            $tid = (int)$pdo->lastInsertId();
            adminAudit($pdo, (int)$admin['id'], 'task_created', 'task', $tid, "Created task '{$title}' ({$points} pts)");
            flashSet('success', "Task '{$title}' created.");
        }
    } elseif ($action === 'update_task') {
        $id = (int)($_POST['id'] ?? 0);
        $points = max(1, (int)($_POST['reward_points'] ?? 50));
        $active = isset($_POST['is_active']) ? 1 : 0;
        if ($id > 0) {
            $pdo->prepare('UPDATE tasks SET reward_points = :pts, is_active = :act WHERE id = :id')
                ->execute([':pts' => $points, ':act' => $active, ':id' => $id]);
            adminAudit($pdo, (int)$admin['id'], 'task_updated', 'task', $id, "Updated task #{$id}: {$points} pts, active={$active}");
            flashSet('success', "Task #{$id} updated.");
        }
    }
    header('Location: tasks.php');
    exit;
}

$tasks = $pdo->query('SELECT * FROM tasks ORDER BY sort_order ASC, id DESC')->fetchAll();

renderAdminHeader('Tasks Management', 'tasks', $admin);
?>
<div class="card" style="margin-bottom:20px;">
  <div class="section-header">
    <h2>Create New Task</h2>
  </div>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
    <input type="hidden" name="action" value="create_task">
    <div class="form-grid" style="margin-bottom:14px;">
      <div class="field">
        <label for="title">Task Title</label>
        <input id="title" name="title" type="text" required placeholder="e.g. Visit Daily Sponsor">
      </div>
      <div class="field">
        <label for="task_type">Task Type</label>
        <select id="task_type" name="task_type">
          <option value="visit">Visit</option>
          <option value="daily">Daily</option>
          <option value="social">Social</option>
          <option value="video">Video</option>
          <option value="app_action">App Action</option>
          <option value="survey">Survey</option>
        </select>
      </div>
      <div class="field">
        <label for="reward_points">Reward Points</label>
        <input id="reward_points" name="reward_points" type="number" min="1" value="100" required>
      </div>
      <div class="field">
        <label for="action_url">Action URL (optional)</label>
        <input id="action_url" name="action_url" type="url" placeholder="https://...">
      </div>
      <div class="field">
        <label for="verification_keyword">Verification Keyword (optional)</label>
        <input id="verification_keyword" name="verification_keyword" type="text" placeholder="Optional keyword match">
      </div>
    </div>
    <div class="field" style="margin-bottom:12px;">
      <label for="description">Description</label>
      <textarea id="description" name="description" rows="2" required placeholder="Instructions shown to Android users..."></textarea>
    </div>
    <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;">
      <label><input type="checkbox" name="is_repeatable_daily"> Repeatable Daily</label>
      <label><input type="checkbox" name="requires_proof"> Requires Proof Text</label>
      <button type="submit" class="btn btn-primary">Create Task</button>
    </div>
  </form>
</div>

<div class="card">
  <div class="section-header">
    <h2>Configured Tasks (<?= count($tasks) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Title & Type</th>
          <th>Daily</th>
          <th>Proof</th>
          <th>Reward Points</th>
          <th>Active</th>
          <th>Update</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($tasks as $t): ?>
          <tr>
            <form method="post">
              <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
              <input type="hidden" name="action" value="update_task">
              <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
              <td class="num">#<?= (int)$t['id'] ?></td>
              <td><strong><?= e($t['title']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($t['task_type']) ?> &middot; <?= e($t['description']) ?></span></td>
              <td><?= ((int)$t['is_repeatable_daily']) === 1 ? 'Yes' : 'One-time' ?></td>
              <td><?= ((int)$t['requires_proof']) === 1 ? 'Required' : 'Auto' ?></td>
              <td><input type="number" name="reward_points" min="1" value="<?= (int)$t['reward_points'] ?>" style="width:86px;padding:5px;border:1px solid #cbd5e1;border-radius:6px;"></td>
              <td><input type="checkbox" name="is_active" <?= ((int)$t['is_active']) === 1 ? 'checked' : '' ?>></td>
              <td><button type="submit" class="btn btn-secondary btn-sm">Save</button></td>
            </form>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
