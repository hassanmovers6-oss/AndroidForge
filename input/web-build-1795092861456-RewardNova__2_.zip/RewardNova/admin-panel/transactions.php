<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

$walletType = $_GET['wallet_type'] ?? '';
$sql = '
    SELECT wt.*, u.full_name, u.email
    FROM wallet_transactions wt
    INNER JOIN users u ON u.id = wt.user_id
    WHERE 1=1
';
$params = [];
if (in_array($walletType, ['points', 'cash'], true)) {
    $sql .= ' AND wt.wallet_type = :wt';
    $params[':wt'] = $walletType;
}
$sql .= ' ORDER BY wt.id DESC LIMIT 250';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$txs = $stmt->fetchAll();

renderAdminHeader('Transaction History', 'transactions', $admin);
?>
<div class="card" style="margin-bottom:16px;">
  <div style="display:flex;gap:10px;align-items:center;">
    <a href="transactions.php" class="btn <?= $walletType === '' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">All Ledger</a>
    <a href="transactions.php?wallet_type=points" class="btn <?= $walletType === 'points' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Points Wallet</a>
    <a href="transactions.php?wallet_type=cash" class="btn <?= $walletType === 'cash' ? 'btn-primary' : 'btn-secondary' ?> btn-sm">Cash Wallet</a>
  </div>
</div>

<div class="card">
  <div class="section-header">
    <h2>Wallet Ledger (<?= count($txs) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Wallet</th>
          <th>Category</th>
          <th>Type</th>
          <th class="num">Points</th>
          <th class="num">Cash (Rs)</th>
          <th>Description</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($txs)): ?>
          <tr><td colspan="9" style="color:#64748b;">No transactions yet.</td></tr>
        <?php else: foreach ($txs as $tx): ?>
          <tr>
            <td class="num">#<?= (int)$tx['id'] ?></td>
            <td><strong><?= e($tx['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($tx['email']) ?></span></td>
            <td><?= e(ucfirst($tx['wallet_type'])) ?></td>
            <td><code><?= e($tx['category']) ?></code></td>
            <td><span class="status status-<?= $tx['tx_type'] === 'credit' ? 'approved' : 'rejected' ?>"><?= e(ucfirst($tx['tx_type'])) ?></span></td>
            <td class="num"><?= (int)$tx['points_amount'] > 0 ? number_format((int)$tx['points_amount']) : '-' ?></td>
            <td class="num"><?= (float)$tx['cash_amount'] > 0 ? 'Rs ' . number_format((float)$tx['cash_amount'], 2) : '-' ?></td>
            <td><?= e($tx['description']) ?></td>
            <td><?= e($tx['created_at']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
