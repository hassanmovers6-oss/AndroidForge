<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $targetUserId = trim((string)($_POST['user_id'] ?? ''));
    $title = trim((string)($_POST['title'] ?? ''));
    $message = trim((string)($_POST['message'] ?? ''));
    $type = $_POST['type'] ?? 'system';

    if ($title !== '' && $message !== '' && in_array($type, ['system', 'reward', 'withdrawal', 'promo', 'security'], true)) {
        $uid = $targetUserId === '' ? null : (int)$targetUserId;
        $pdo->prepare('INSERT INTO notifications (user_id, title, message, type, created_by_admin_id) VALUES (:uid, :t, :m, :ty, :aid)')
            ->execute([':uid' => $uid, ':t' => $title, ':m' => $message, ':ty' => $type, ':aid' => (int)$admin['id']]);
        adminAudit($pdo, (int)$admin['id'], 'notification_sent', 'notification', (int)$pdo->lastInsertId(), $uid ? "To user #{$uid}: {$title}" : "Broadcast: {$title}");
        flashSet('success', 'Notification sent successfully.');
    } else {
        flashSet('error', 'Title and message are required.');
    }
    header('Location: notifications.php');
    exit;
}

$notifications = $pdo->query('
    SELECT n.*, u.email AS target_email
    FROM notifications n
    LEFT JOIN users u ON u.id = n.user_id
    ORDER BY n.id DESC
    LIMIT 100
')->fetchAll();

renderAdminHeader('Notifications', 'notifications', $admin);
?>
<div class="card" style="margin-bottom:20px;">
  <div class="section-header">
    <h2>Send Notification</h2>
  </div>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
    <div class="form-grid" style="margin-bottom:12px;">
      <div class="field">
        <label for="title">Title</label>
        <input id="title" name="title" type="text" required placeholder="Announcement title">
      </div>
      <div class="field">
        <label for="type">Category</label>
        <select id="type" name="type">
          <option value="system">System</option>
          <option value="promo">Promo</option>
          <option value="reward">Reward</option>
          <option value="security">Security</option>
        </select>
      </div>
      <div class="field">
        <label for="user_id">Target User ID (leave blank for Broadcast to all)</label>
        <input id="user_id" name="user_id" type="number" min="1" placeholder="Optional User ID">
      </div>
    </div>
    <div class="field" style="margin-bottom:14px;">
      <label for="message">Message</label>
      <textarea id="message" name="message" rows="3" required placeholder="Message body..."></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Dispatch Notification</button>
  </form>
</div>

<div class="card">
  <div class="section-header">
    <h2>Recent Notifications (<?= count($notifications) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Audience</th>
          <th>Category</th>
          <th>Title & Message</th>
          <th>Sent At</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($notifications as $n): ?>
          <tr>
            <td class="num">#<?= (int)$n['id'] ?></td>
            <td><?= $n['user_id'] ? e($n['target_email'] ?? ('User #' . $n['user_id'])) : '<strong>All Users (Broadcast)</strong>' ?></td>
            <td><?= e(ucfirst($n['type'])) ?></td>
            <td><strong><?= e($n['title']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($n['message']) ?></span></td>
            <td><?= e($n['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
