<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/../../backend-api/config/database.php';

function adminDb(): PDO
{
    return Database::getConnection();
}

function e(mixed $val): string
{
    return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
}

function csrfToken(): string
{
    if (empty($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['admin_csrf'];
}

function verifyCsrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || empty($_SESSION['admin_csrf']) || !hash_equals($_SESSION['admin_csrf'], $token)) {
        http_response_code(403);
        die('Invalid CSRF security token. Please refresh the page and try again.');
    }
}

function requireAdmin(): array
{
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }

    $pdo = adminDb();
    $stmt = $pdo->prepare("SELECT id, full_name, email, role, status FROM admins WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => (int)$_SESSION['admin_id']]);
    $admin = $stmt->fetch();

    if (!$admin || $admin['status'] !== 'active') {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    return $admin;
}

function adminAudit(PDO $pdo, int $adminId, string $action, ?string $targetType = null, ?int $targetId = null, ?string $details = null): void
{
    $stmt = $pdo->prepare('
        INSERT INTO audit_logs (actor_type, actor_id, action, target_type, target_id, details, ip_address)
        VALUES ("admin", :aid, :action, :ttype, :tid, :details, :ip)
    ');
    $stmt->execute([
        ':aid' => $adminId,
        ':action' => $action,
        ':ttype' => $targetType,
        ':tid' => $targetId,
        ':details' => $details,
        ':ip' => $_SERVER['REMOTE_ADDR'] ?? null,
    ]);
}

function flashSet(string $type, string $message): void
{
    $_SESSION['admin_flash'] = ['type' => $type, 'message' => $message];
}

function flashGet(): ?array
{
    if (!empty($_SESSION['admin_flash'])) {
        $f = $_SESSION['admin_flash'];
        unset($_SESSION['admin_flash']);
        return $f;
    }
    return null;
}
