<?php
declare(strict_types=1);

function renderAdminHeader(string $title, string $activeNav, array $admin): void
{
    $navItems = [
        'Overview' => [
            ['id' => 'dashboard', 'label' => 'Dashboard', 'href' => 'index.php'],
            ['id' => 'users', 'label' => 'Users & Points', 'href' => 'users.php'],
        ],
        'Earning Engines' => [
            ['id' => 'spin_settings', 'label' => 'Spin Wheel Config', 'href' => 'spin_settings.php'],
            ['id' => 'spin_history', 'label' => 'Spin History', 'href' => 'spin_history.php'],
            ['id' => 'tasks', 'label' => 'Tasks Manager', 'href' => 'tasks.php'],
            ['id' => 'task_submissions', 'label' => 'Task Approvals', 'href' => 'task_submissions.php'],
        ],
        'Finance & Growth' => [
            ['id' => 'withdrawals', 'label' => 'Withdrawals', 'href' => 'withdrawals.php'],
            ['id' => 'referrals', 'label' => 'Referrals', 'href' => 'referrals.php'],
            ['id' => 'transactions', 'label' => 'Transactions', 'href' => 'transactions.php'],
        ],
        'System' => [
            ['id' => 'notifications', 'label' => 'Notifications', 'href' => 'notifications.php'],
            ['id' => 'settings', 'label' => 'App & Rewards', 'href' => 'settings.php'],
            ['id' => 'admob', 'label' => 'AdMob Settings', 'href' => 'admob_settings.php'],
            ['id' => 'audit_logs', 'label' => 'Audit Logs', 'href' => 'audit_logs.php'],
        ],
    ];
    $flash = flashGet();
    ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($title) ?> - RewardNova Admin</title>
  <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
<div class="admin-shell">
  <aside class="sidebar" id="adminSidebar">
    <div class="sidebar-brand">
      <h1>RewardNova</h1>
      <span>Admin Console</span>
    </div>
    <nav class="sidebar-nav">
      <?php foreach ($navItems as $section => $links): ?>
        <div class="nav-section"><?= e($section) ?></div>
        <?php foreach ($links as $item): ?>
          <a class="nav-link <?= $activeNav === $item['id'] ? 'active' : '' ?>" href="<?= e($item['href']) ?>">
            <span><?= e($item['label']) ?></span>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
      <div class="nav-section">Session</div>
      <a class="nav-link" href="logout.php"><span>Sign Out</span></a>
    </nav>
  </aside>
  <div class="main-col">
    <header class="topbar">
      <div style="display:flex;align-items:center;gap:12px;">
        <button type="button" class="menu-toggle" id="menuToggle">Menu</button>
        <h2 class="topbar-title"><?= e($title) ?></h2>
      </div>
      <div class="topbar-right">
        <span><?= e($admin['full_name']) ?> (<?= e($admin['role']) ?>)</span>
        <a class="btn btn-secondary btn-sm" href="logout.php">Logout</a>
      </div>
    </header>
    <main class="content">
      <?php if ($flash): ?>
        <div class="flash flash-<?= $flash['type'] === 'error' ? 'error' : 'success' ?>">
          <?= e($flash['message']) ?>
        </div>
      <?php endif; ?>
    <?php
}

function renderAdminFooter(): void
{
    ?>
    </main>
  </div>
</div>
<script src="assets/js/admin.js"></script>
</body>
</html>
    <?php
}
