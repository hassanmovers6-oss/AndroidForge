<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $allowedKeys = [
        'app_name', 'points_per_rupee', 'min_withdrawal_rs', 'daily_spin_limit',
        'daily_checkin_base_points', 'daily_checkin_streak_bonus',
        'referral_referrer_points', 'referral_referred_points',
        'support_email', 'privacy_policy_url', 'terms_url', 'maintenance_mode',
    ];
    $stmt = $pdo->prepare('INSERT INTO app_settings (setting_key, setting_value) VALUES (:k, :v) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    foreach ($allowedKeys as $key) {
        if (isset($_POST[$key])) {
            $val = trim((string)$_POST[$key]);
            $stmt->execute([':k' => $key, ':v' => $val]);
        }
    }
    adminAudit($pdo, (int)$admin['id'], 'app_settings_updated', 'app_settings', null, 'Updated global reward & app settings');
    flashSet('success', 'App and reward settings saved successfully.');
    header('Location: settings.php');
    exit;
}

$rows = $pdo->query('SELECT setting_key, setting_value FROM app_settings')->fetchAll();
$cfg = [];
foreach ($rows as $r) {
    $cfg[$r['setting_key']] = $r['setting_value'];
}

renderAdminHeader('App & Reward Settings', 'settings', $admin);
?>
<div class="card">
  <div class="section-header">
    <h2>Global Business Rules & Application Configuration</h2>
  </div>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
    <div class="form-grid" style="margin-bottom:18px;">
      <div class="field">
        <label for="app_name">App Name</label>
        <input id="app_name" name="app_name" type="text" value="<?= e($cfg['app_name'] ?? 'RewardNova') ?>" required>
      </div>
      <div class="field">
        <label for="points_per_rupee">Points Equal to Rs 1 (Default: 1000)</label>
        <input id="points_per_rupee" name="points_per_rupee" type="number" min="1" value="<?= e($cfg['points_per_rupee'] ?? '1000') ?>" required>
      </div>
      <div class="field">
        <label for="min_withdrawal_rs">Minimum Withdrawal (Rs, Default: 100)</label>
        <input id="min_withdrawal_rs" name="min_withdrawal_rs" type="number" min="1" value="<?= e($cfg['min_withdrawal_rs'] ?? '100') ?>" required>
      </div>
      <div class="field">
        <label for="daily_spin_limit">Daily Spin Limit (Default: 5)</label>
        <input id="daily_spin_limit" name="daily_spin_limit" type="number" min="1" value="<?= e($cfg['daily_spin_limit'] ?? '5') ?>" required>
      </div>
      <div class="field">
        <label for="daily_checkin_base_points">Check-in Day 1 Points</label>
        <input id="daily_checkin_base_points" name="daily_checkin_base_points" type="number" min="1" value="<?= e($cfg['daily_checkin_base_points'] ?? '25') ?>" required>
      </div>
      <div class="field">
        <label for="daily_checkin_streak_bonus">Check-in Streak Increment</label>
        <input id="daily_checkin_streak_bonus" name="daily_checkin_streak_bonus" type="number" min="0" value="<?= e($cfg['daily_checkin_streak_bonus'] ?? '15') ?>" required>
      </div>
      <div class="field">
        <label for="referral_referrer_points">Referrer Bonus Points</label>
        <input id="referral_referrer_points" name="referral_referrer_points" type="number" min="0" value="<?= e($cfg['referral_referrer_points'] ?? '250') ?>" required>
      </div>
      <div class="field">
        <label for="referral_referred_points">Referred User Welcome Bonus</label>
        <input id="referral_referred_points" name="referral_referred_points" type="number" min="0" value="<?= e($cfg['referral_referred_points'] ?? '100') ?>" required>
      </div>
      <div class="field">
        <label for="support_email">Support Email</label>
        <input id="support_email" name="support_email" type="email" value="<?= e($cfg['support_email'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="privacy_policy_url">Privacy Policy URL</label>
        <input id="privacy_policy_url" name="privacy_policy_url" type="url" value="<?= e($cfg['privacy_policy_url'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="terms_url">Terms URL</label>
        <input id="terms_url" name="terms_url" type="url" value="<?= e($cfg['terms_url'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="maintenance_mode">Maintenance Mode</label>
        <select id="maintenance_mode" name="maintenance_mode">
          <option value="0" <?= ($cfg['maintenance_mode'] ?? '0') === '0' ? 'selected' : '' ?>>Operational (0)</option>
          <option value="1" <?= ($cfg['maintenance_mode'] ?? '0') === '1' ? 'selected' : '' ?>>Maintenance Active (1)</option>
        </select>
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Save Settings</button>
  </form>
</div>
<?php
renderAdminFooter();
