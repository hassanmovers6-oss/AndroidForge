<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $wdId = (int)($_POST['withdrawal_id'] ?? 0);
    $newStatus = $_POST['new_status'] ?? '';
    $note = trim((string)($_POST['admin_note'] ?? ''));

    if ($wdId > 0 && in_array($newStatus, ['approved', 'paid', 'rejected'], true)) {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM withdrawal_requests WHERE id = :id LIMIT 1 FOR UPDATE');
            $stmt->execute([':id' => $wdId]);
            $wd = $stmt->fetch();

            if (!$wd || in_array($wd['status'], ['paid', 'rejected'], true)) {
                $pdo->rollBack();
                flashSet('error', 'Withdrawal request already finalized or not found.');
                header('Location: withdrawals.php');
                exit;
            }

            $userId = (int)$wd['user_id'];
            $amountRs = (float)$wd['amount_rs'];

            $wStmt = $pdo->prepare('SELECT cash_balance, total_withdrawn, pending_withdrawal FROM cash_wallets WHERE user_id = :uid FOR UPDATE');
            $wStmt->execute([':uid' => $userId]);
            $wallet = $wStmt->fetch();

            if ($newStatus === 'paid') {
                $newPending = max(0.0, round((float)$wallet['pending_withdrawal'] - $amountRs, 2));
                $newTotalWd = round((float)$wallet['total_withdrawn'] + $amountRs, 2);
                $pdo->prepare('UPDATE cash_wallets SET pending_withdrawal = :pw, total_withdrawn = :tw WHERE user_id = :uid')
                    ->execute([':pw' => $newPending, ':tw' => $newTotalWd, ':uid' => $userId]);
            } elseif ($newStatus === 'rejected') {
                $newPending = max(0.0, round((float)$wallet['pending_withdrawal'] - $amountRs, 2));
                $newCash = round((float)$wallet['cash_balance'] + $amountRs, 2);
                $pdo->prepare('UPDATE cash_wallets SET pending_withdrawal = :pw, cash_balance = :cb WHERE user_id = :uid')
                    ->execute([':pw' => $newPending, ':cb' => $newCash, ':uid' => $userId]);

                $pdo->prepare('
                    INSERT INTO wallet_transactions (user_id, wallet_type, tx_type, category, cash_amount, balance_after_cash, reference_id, description)
                    VALUES (:uid, "cash", "credit", "withdrawal_refund", :amt, :bal, :ref, :desc)
                ')->execute([
                    ':uid' => $userId,
                    ':amt' => $amountRs,
                    ':bal' => $newCash,
                    ':ref' => 'WD-REFUND-' . $wdId,
                    ':desc' => "Refund for rejected withdrawal #{$wdId}",
                ]);
            }

            $pdo->prepare('
                UPDATE withdrawal_requests
                SET status = :st, admin_note = :note, processed_by_admin_id = :aid, processed_at = UTC_TIMESTAMP()
                WHERE id = :id
            ')->execute([
                ':st' => $newStatus,
                ':note' => $note !== '' ? $note : null,
                ':aid' => (int)$admin['id'],
                ':id' => $wdId,
            ]);

            $pdo->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (:uid, :title, :msg, "withdrawal")')
                ->execute([
                    ':uid' => $userId,
                    ':title' => 'Withdrawal ' . ucfirst($newStatus),
                    ':msg' => "Your withdrawal request #{$wdId} (Rs {$amountRs}) was marked as {$newStatus}." . ($note !== '' ? " Note: {$note}" : ''),
                ]);

            adminAudit($pdo, (int)$admin['id'], 'withdrawal_' . $newStatus, 'withdrawal_request', $wdId, "Rs {$amountRs} -> {$newStatus}");
            $pdo->commit();
            flashSet('success', "Withdrawal #{$wdId} updated to {$newStatus}.");
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            flashSet('error', 'Failed to update withdrawal request.');
        }
    }
    header('Location: withdrawals.php');
    exit;
}

$withdrawals = $pdo->query('
    SELECT wr.*, u.full_name, u.email
    FROM withdrawal_requests wr
    INNER JOIN users u ON u.id = wr.user_id
    ORDER BY wr.id DESC
    LIMIT 200
')->fetchAll();

renderAdminHeader('Withdrawal Requests', 'withdrawals', $admin);
?>
<div class="card">
  <div class="section-header">
    <h2>Cash Withdrawal Requests (<?= count($withdrawals) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Method & Account</th>
          <th class="num">Amount (Rs)</th>
          <th>Status</th>
          <th>Requested</th>
          <th>Process Payout</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($withdrawals)): ?>
          <tr><td colspan="7" style="color:#64748b;">No withdrawal requests submitted yet.</td></tr>
        <?php else: foreach ($withdrawals as $w): ?>
          <tr>
            <td class="num">#<?= (int)$w['id'] ?></td>
            <td><strong><?= e($w['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($w['email']) ?></span></td>
            <td><strong><?= e($w['payment_method']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($w['account_holder_name']) ?> &middot; <?= e($w['account_details']) ?></span></td>
            <td class="num">Rs <?= number_format((float)$w['amount_rs'], 2) ?></td>
            <td><span class="status status-<?= e($w['status']) ?>"><?= e(ucfirst($w['status'])) ?></span></td>
            <td><?= e($w['created_at']) ?></td>
            <td>
              <?php if (in_array($w['status'], ['pending', 'approved'], true)): ?>
                <form method="post" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
                  <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                  <input type="hidden" name="withdrawal_id" value="<?= (int)$w['id'] ?>">
                  <input type="text" name="admin_note" placeholder="Optional note" value="<?= e($w['admin_note'] ?? '') ?>" style="width:120px;padding:4px 6px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;">
                  <?php if ($w['status'] === 'pending'): ?>
                    <button type="submit" name="new_status" value="approved" class="btn btn-secondary btn-sm">Approve</button>
                  <?php endif; ?>
                  <button type="submit" name="new_status" value="paid" class="btn btn-primary btn-sm">Mark Paid</button>
                  <button type="submit" name="new_status" value="rejected" class="btn btn-danger btn-sm" data-confirm="Reject and refund cash balance back to user?">Reject</button>
                </form>
              <?php else: ?>
                <span style="color:#64748b;font-size:12px;"><?= e($w['admin_note'] ?: 'Processed') ?></span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
