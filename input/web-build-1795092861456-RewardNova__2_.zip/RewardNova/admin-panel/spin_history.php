<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

$history = $pdo->query('
    SELECT sh.id, u.full_name, u.email, sh.segment_label, sh.points_won, sh.spin_date, sh.ip_address, sh.created_at
    FROM spin_history sh
    INNER JOIN users u ON u.id = sh.user_id
    ORDER BY sh.id DESC
    LIMIT 200
')->fetchAll();

renderAdminHeader('Spin History', 'spin_history', $admin);
?>
<div class="card">
  <div class="section-header">
    <h2>Recent Server-Verified Spins (<?= count($history) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Segment</th>
          <th class="num">Points Won</th>
          <th>Spin Date</th>
          <th>IP Address</th>
          <th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($history)): ?>
          <tr><td colspan="7" style="color:#64748b;">No spin records yet.</td></tr>
        <?php else: foreach ($history as $row): ?>
          <tr>
            <td class="num">#<?= (int)$row['id'] ?></td>
            <td><strong><?= e($row['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($row['email']) ?></span></td>
            <td><?= e($row['segment_label']) ?></td>
            <td class="num">+<?= number_format((int)$row['points_won']) ?></td>
            <td><?= e($row['spin_date']) ?></td>
            <td><code><?= e($row['ip_address'] ?? '-') ?></code></td>
            <td><?= e($row['created_at']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
