<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

$totalUsers = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$newToday = (int)$pdo->query('SELECT COUNT(*) FROM users WHERE DATE(registered_at) = CURDATE()')->fetchColumn();
$new7d = (int)$pdo->query('SELECT COUNT(*) FROM users WHERE registered_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)')->fetchColumn();
$active24h = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE account_status = 'active' AND last_active_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)")->fetchColumn();
$totalPointsHeld = (int)$pdo->query('SELECT COALESCE(SUM(points_balance), 0) FROM user_points')->fetchColumn();
$spinsToday = (int)$pdo->query('SELECT COUNT(*) FROM spin_history WHERE spin_date = CURDATE()')->fetchColumn();
$autoApprovedTasks = (int)$pdo->query('SELECT COUNT(*) FROM task_submissions WHERE approved_by_system = 1 AND status = "approved"')->fetchColumn();
$pendingWdRow = $pdo->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(amount_rs), 0) AS total_rs FROM withdrawal_requests WHERE status = 'pending'")->fetch();

$recentUsers = $pdo->query('
    SELECT u.id, u.full_name, u.email, u.account_status, u.registered_at, p.points_balance, w.cash_balance
    FROM users u
    LEFT JOIN user_points p ON p.user_id = u.id
    LEFT JOIN cash_wallets w ON w.user_id = u.id
    ORDER BY u.id DESC
    LIMIT 10
')->fetchAll();

$recentPendingWd = $pdo->query("
    SELECT wr.id, u.full_name, u.email, wr.amount_rs, wr.payment_method, wr.created_at
    FROM withdrawal_requests wr
    INNER JOIN users u ON u.id = wr.user_id
    WHERE wr.status = 'pending'
    ORDER BY wr.id ASC
    LIMIT 8
")->fetchAll();

renderAdminHeader('Dashboard Overview', 'dashboard', $admin);
?>
<div class="kpi-grid">
  <div class="card">
    <p class="card-title">Total Registered Users</p>
    <p class="card-value"><?= number_format($totalUsers) ?></p>
    <p class="card-sub">+<?= number_format($new7d) ?> in last 7 days</p>
  </div>
  <div class="card">
    <p class="card-title">New Registrations Today</p>
    <p class="card-value"><?= number_format($newToday) ?></p>
    <p class="card-sub">Synced automatically from Android API</p>
  </div>
  <div class="card">
    <p class="card-title">Active Users (24h)</p>
    <p class="card-value"><?= number_format($active24h) ?></p>
    <p class="card-sub">Verified active sessions</p>
  </div>
  <div class="card">
    <p class="card-title">Pending Withdrawals</p>
    <p class="card-value">Rs <?= number_format((float)$pendingWdRow['total_rs'], 2) ?></p>
    <p class="card-sub"><?= (int)$pendingWdRow['cnt'] ?> request(s) awaiting review</p>
  </div>
  <div class="card">
    <p class="card-title">Circulating Reward Points</p>
    <p class="card-value"><?= number_format($totalPointsHeld) ?></p>
    <p class="card-sub">Non-cash points across users</p>
  </div>
  <div class="card">
    <p class="card-title">Spins Today / Auto-Approved Tasks</p>
    <p class="card-value"><?= number_format($spinsToday) ?> / <?= number_format($autoApprovedTasks) ?></p>
    <p class="card-sub">Server-verified reward events</p>
  </div>
</div>

<div class="two-col">
  <div class="card">
    <div class="section-header">
      <h2>Latest Registered Users</h2>
      <a class="btn btn-secondary btn-sm" href="users.php">View All Users</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Status</th>
            <th class="num">Points</th>
            <th class="num">Cash (Rs)</th>
            <th>Registered</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recentUsers)): ?>
            <tr><td colspan="5" style="color:#64748b;">No users registered yet.</td></tr>
          <?php else: foreach ($recentUsers as $u): ?>
            <tr>
              <td><strong><?= e($u['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($u['email']) ?></span></td>
              <td><span class="status status-<?= e($u['account_status']) ?>"><?= e(ucfirst($u['account_status'])) ?></span></td>
              <td class="num"><?= number_format((int)$u['points_balance']) ?></td>
              <td class="num"><?= number_format((float)$u['cash_balance'], 2) ?></td>
              <td><?= e($u['registered_at']) ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="section-header">
      <h2>Pending Withdrawal Queue</h2>
      <a class="btn btn-secondary btn-sm" href="withdrawals.php">Manage Payouts</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Method</th>
            <th class="num">Amount (Rs)</th>
            <th>Requested</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recentPendingWd)): ?>
            <tr><td colspan="4" style="color:#64748b;">No pending withdrawal requests.</td></tr>
          <?php else: foreach ($recentPendingWd as $wd): ?>
            <tr>
              <td><strong><?= e($wd['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($wd['email']) ?></span></td>
              <td><?= e($wd['payment_method']) ?></td>
              <td class="num">Rs <?= number_format((float)$wd['amount_rs'], 2) ?></td>
              <td><?= e($wd['created_at']) ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php
renderAdminFooter();
