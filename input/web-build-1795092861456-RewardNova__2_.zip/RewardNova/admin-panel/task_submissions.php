<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

$submissions = $pdo->query('
    SELECT ts.id, u.full_name, u.email, t.title AS task_title, ts.submission_date, ts.proof_text,
           ts.status, ts.points_awarded, ts.approved_by_system, ts.created_at
    FROM task_submissions ts
    INNER JOIN users u ON u.id = ts.user_id
    INNER JOIN tasks t ON t.id = ts.task_id
    ORDER BY ts.id DESC
    LIMIT 200
')->fetchAll();

renderAdminHeader('Task Submissions & Auto-Approvals', 'task_submissions', $admin);
?>
<div class="card">
  <div class="section-header">
    <h2>Task Submissions & Automatic Approval History (<?= count($submissions) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Task</th>
          <th>Proof</th>
          <th>Status</th>
          <th>Approval Mode</th>
          <th class="num">Points Credited</th>
          <th>Submitted At</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($submissions)): ?>
          <tr><td colspan="8" style="color:#64748b;">No task submissions yet.</td></tr>
        <?php else: foreach ($submissions as $s): ?>
          <tr>
            <td class="num">#<?= (int)$s['id'] ?></td>
            <td><strong><?= e($s['full_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($s['email']) ?></span></td>
            <td><?= e($s['task_title']) ?></td>
            <td><?= e($s['proof_text'] ?? '-') ?></td>
            <td><span class="status status-<?= e($s['status']) ?>"><?= e(ucfirst($s['status'])) ?></span></td>
            <td><?= ((int)$s['approved_by_system']) === 1 ? 'Auto-Approved' : 'Manual' ?></td>
            <td class="num">+<?= number_format((int)$s['points_awarded']) ?></td>
            <td><?= e($s['created_at']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
