<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$admin = requireAdmin();
$pdo = adminDb();

$referrals = $pdo->query('
    SELECT r.id, r.referral_code_used, r.status, r.created_at,
           u1.full_name AS referrer_name, u1.email AS referrer_email,
           u2.full_name AS referred_name, u2.email AS referred_email,
           COALESCE((SELECT SUM(points_awarded) FROM referral_rewards rr WHERE rr.referral_id = r.id), 0) AS total_points
    FROM referrals r
    INNER JOIN users u1 ON u1.id = r.referrer_user_id
    INNER JOIN users u2 ON u2.id = r.referred_user_id
    ORDER BY r.id DESC
    LIMIT 200
')->fetchAll();

renderAdminHeader('Referral Management', 'referrals', $admin);
?>
<div class="card">
  <div class="section-header">
    <h2>Referral Relationships & Rewards (<?= count($referrals) ?>)</h2>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Referrer</th>
          <th>Referred User</th>
          <th>Code Used</th>
          <th>Status</th>
          <th class="num">Total Pts Awarded</th>
          <th>Created</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($referrals)): ?>
          <tr><td colspan="7" style="color:#64748b;">No referrals recorded yet.</td></tr>
        <?php else: foreach ($referrals as $r): ?>
          <tr>
            <td class="num">#<?= (int)$r['id'] ?></td>
            <td><strong><?= e($r['referrer_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($r['referrer_email']) ?></span></td>
            <td><strong><?= e($r['referred_name']) ?></strong><br><span style="color:#64748b;font-size:12px;"><?= e($r['referred_email']) ?></span></td>
            <td><code><?= e($r['referral_code_used']) ?></code></td>
            <td><span class="status status-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
            <td class="num"><?= number_format((int)$r['total_points']) ?></td>
            <td><?= e($r['created_at']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
renderAdminFooter();
