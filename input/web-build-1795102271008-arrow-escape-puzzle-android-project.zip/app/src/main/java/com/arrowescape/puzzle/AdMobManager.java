package com.arrowescape.puzzle;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;

import org.json.JSONObject;

public class AdMobManager {

    private static final long INTERSTITIAL_COOLDOWN_MS = 45_000L;

    private static final class FormatDiag {
        String status = "IDLE";
        int lastErrorCode = 0;
        String lastErrorMessage = "";
        int impressions = 0;
        int failures = 0;
    }

    private final Activity activity;
    private final WebView webView;
    private final FrameLayout bannerContainer;
    private final FrameLayout nativeContainer;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    private AdView bannerAdView;
    @Nullable
    private InterstitialAd interstitialAd;
    @Nullable
    private RewardedAd rewardedAd;
    @Nullable
    private RewardedInterstitialAd rewardedInterstitialAd;
    @Nullable
    private NativeAd currentNativeAd;

    private boolean isLoadingInterstitial = false;
    private boolean isLoadingRewarded = false;
    private boolean isLoadingRewardedInterstitial = false;
    private boolean isLoadingNative = false;
    private boolean nativeVisibleRequested = false;
    private boolean nativeNeedsRefresh = false;
    private long lastInterstitialShowMs = 0L;

    private final FormatDiag bannerDiag = new FormatDiag();
    private final FormatDiag interstitialDiag = new FormatDiag();
    private final FormatDiag rewardedDiag = new FormatDiag();
    private final FormatDiag rewardedInterstitialDiag = new FormatDiag();
    private final FormatDiag nativeDiag = new FormatDiag();

    public AdMobManager(
            @NonNull Activity activity,
            @NonNull WebView webView,
            @NonNull FrameLayout bannerContainer,
            @NonNull FrameLayout nativeContainer
    ) {
        this.activity = activity;
        this.webView = webView;
        this.bannerContainer = bannerContainer;
        this.nativeContainer = nativeContainer;
    }

    public void initializeAndPreload() {
        activity.runOnUiThread(() -> {
            loadBanner();
            loadInterstitial();
            loadRewarded();
            loadRewardedInterstitial();
            loadNativeAd();
        });
    }

    private void suppressAppOpenOnFullscreen() {
        if (activity.getApplication() instanceof ArrowEscapeApplication app) {
            if (app.getAppOpenAdManager() != null) {
                app.getAppOpenAdManager().setSuppressNextShow(true);
            }
        }
    }

    private String classifyLoadError(@NonNull LoadAdError err) {
        int code = err.getCode();
        String tag;
        if (code == AdRequest.ERROR_CODE_NO_FILL) {
            tag = "NO_FILL (Code 3)";
        } else if (code == AdRequest.ERROR_CODE_NETWORK_ERROR) {
            tag = "NETWORK_ERROR (Code 2)";
        } else if (code == AdRequest.ERROR_CODE_INVALID_REQUEST) {
            tag = "INVALID_REQUEST (Code 1)";
        } else if (code == AdRequest.ERROR_CODE_APP_ID_MISSING) {
            tag = "APP_ID_MISSING (Code 8)";
        } else {
            tag = "ERROR (Code " + code + ")";
        }
        return tag + ": " + err.getMessage();
    }

    private void dispatchJsEvent(String eventType, String placement, boolean granted) {
        activity.runOnUiThread(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("type", eventType);
                payload.put("placement", placement);
                payload.put("granted", granted);
                String js = "if(window.__onAndroidAdEvent){window.__onAndroidAdEvent(" + payload + ");}";
                webView.evaluateJavascript(js, null);
            } catch (Exception ignored) {
            }
        });
    }

    private AdSize getAdaptiveBannerSize() {
        DisplayMetrics outMetrics = activity.getResources().getDisplayMetrics();
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public void loadBanner() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerContainer.removeAllViews();
        }
        bannerDiag.status = "LOADING";
        bannerAdView = new AdView(activity);
        bannerAdView.setAdUnitId(AdConfig.BANNER_AD_ID);
        bannerAdView.setAdSize(getAdaptiveBannerSize());
        bannerAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                bannerDiag.status = "LOADED";
                bannerDiag.lastErrorCode = 0;
                bannerDiag.lastErrorMessage = "";
            }

            @Override
            public void onAdImpression() {
                bannerDiag.impressions++;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError error) {
                bannerDiag.status = "FAILED";
                bannerDiag.failures++;
                bannerDiag.lastErrorCode = error.getCode();
                bannerDiag.lastErrorMessage = classifyLoadError(error);
                mainHandler.postDelayed(() -> {
                    if (!activity.isFinishing() && bannerAdView != null) {
                        bannerDiag.status = "LOADING";
                        bannerAdView.loadAd(new AdRequest.Builder().build());
                    }
                }, 12000L);
            }
        });
        bannerContainer.addView(bannerAdView);
        bannerAdView.loadAd(new AdRequest.Builder().build());
    }

    public void setBannerVisible(boolean visible) {
        activity.runOnUiThread(() ->
                bannerContainer.setVisibility(visible ? View.VISIBLE : View.GONE)
        );
    }

    public void loadInterstitial() {
        if (isLoadingInterstitial || interstitialAd != null) return;
        isLoadingInterstitial = true;
        interstitialDiag.status = "LOADING";
        InterstitialAd.load(
                activity,
                AdConfig.INTERSTITIAL_AD_ID,
                new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                        isLoadingInterstitial = false;
                        interstitialDiag.status = "LOADED";
                        interstitialDiag.lastErrorCode = 0;
                        interstitialDiag.lastErrorMessage = "";
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        interstitialAd = null;
                        isLoadingInterstitial = false;
                        interstitialDiag.status = "FAILED";
                        interstitialDiag.failures++;
                        interstitialDiag.lastErrorCode = error.getCode();
                        interstitialDiag.lastErrorMessage = classifyLoadError(error);
                        mainHandler.postDelayed(AdMobManager.this::loadInterstitial, 10000L);
                    }
                }
        );
    }

    public void showInterstitial(String placement) {
        activity.runOnUiThread(() -> {
            long now = System.currentTimeMillis();
            if (lastInterstitialShowMs > 0 && (now - lastInterstitialShowMs) < INTERSTITIAL_COOLDOWN_MS) {
                dispatchJsEvent("interstitial_closed", placement, false);
                return;
            }
            if (interstitialAd == null) {
                loadInterstitial();
                dispatchJsEvent("interstitial_closed", placement, false);
                return;
            }
            suppressAppOpenOnFullscreen();
            interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdShowedFullScreenContent() {
                    lastInterstitialShowMs = System.currentTimeMillis();
                    interstitialDiag.impressions++;
                    interstitialDiag.status = "SHOWING";
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    interstitialAd = null;
                    interstitialDiag.status = "IDLE";
                    loadInterstitial();
                    dispatchJsEvent("interstitial_closed", placement, true);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    interstitialAd = null;
                    interstitialDiag.status = "FAILED";
                    interstitialDiag.failures++;
                    interstitialDiag.lastErrorCode = adError.getCode();
                    interstitialDiag.lastErrorMessage = "Show failed (" + adError.getCode() + "): " + adError.getMessage();
                    loadInterstitial();
                    dispatchJsEvent("interstitial_closed", placement, false);
                }
            });
            interstitialAd.show(activity);
        });
    }

    public void loadRewarded() {
        if (isLoadingRewarded || rewardedAd != null) return;
        isLoadingRewarded = true;
        rewardedDiag.status = "LOADING";
        RewardedAd.load(
                activity,
                AdConfig.REWARDED_AD_ID,
                new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        isLoadingRewarded = false;
                        rewardedDiag.status = "LOADED";
                        rewardedDiag.lastErrorCode = 0;
                        rewardedDiag.lastErrorMessage = "";
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        rewardedAd = null;
                        isLoadingRewarded = false;
                        rewardedDiag.status = "FAILED";
                        rewardedDiag.failures++;
                        rewardedDiag.lastErrorCode = error.getCode();
                        rewardedDiag.lastErrorMessage = classifyLoadError(error);
                        mainHandler.postDelayed(AdMobManager.this::loadRewarded, 10000L);
                    }
                }
        );
    }

    public void showRewarded(String placement) {
        activity.runOnUiThread(() -> {
            if (rewardedAd == null) {
                loadRewarded();
                dispatchJsEvent("rewarded_unavailable", placement, false);
                return;
            }
            suppressAppOpenOnFullscreen();
            final boolean[] rewardGranted = {false};
            rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdShowedFullScreenContent() {
                    rewardedDiag.impressions++;
                    rewardedDiag.status = "SHOWING";
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    rewardedAd = null;
                    rewardedDiag.status = "IDLE";
                    loadRewarded();
                    dispatchJsEvent("rewarded_closed", placement, rewardGranted[0]);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    rewardedAd = null;
                    rewardedDiag.status = "FAILED";
                    rewardedDiag.failures++;
                    rewardedDiag.lastErrorCode = adError.getCode();
                    rewardedDiag.lastErrorMessage = "Show failed (" + adError.getCode() + "): " + adError.getMessage();
                    loadRewarded();
                    dispatchJsEvent("rewarded_failed", placement, false);
                }
            });
            rewardedAd.show(activity, rewardItem -> {
                rewardGranted[0] = true;
                dispatchJsEvent("rewarded_earned", placement, true);
            });
        });
    }

    public void loadRewardedInterstitial() {
        if (isLoadingRewardedInterstitial || rewardedInterstitialAd != null) return;
        isLoadingRewardedInterstitial = true;
        rewardedInterstitialDiag.status = "LOADING";
        RewardedInterstitialAd.load(
                activity,
                AdConfig.REWARDED_INTERSTITIAL_AD_ID,
                new AdRequest.Builder().build(),
                new RewardedInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedInterstitialAd ad) {
                        rewardedInterstitialAd = ad;
                        isLoadingRewardedInterstitial = false;
                        rewardedInterstitialDiag.status = "LOADED";
                        rewardedInterstitialDiag.lastErrorCode = 0;
                        rewardedInterstitialDiag.lastErrorMessage = "";
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        rewardedInterstitialAd = null;
                        isLoadingRewardedInterstitial = false;
                        rewardedInterstitialDiag.status = "FAILED";
                        rewardedInterstitialDiag.failures++;
                        rewardedInterstitialDiag.lastErrorCode = error.getCode();
                        rewardedInterstitialDiag.lastErrorMessage = classifyLoadError(error);
                        mainHandler.postDelayed(AdMobManager.this::loadRewardedInterstitial, 10000L);
                    }
                }
        );
    }

    public void showRewardedInterstitial(String placement) {
        activity.runOnUiThread(() -> {
            if (rewardedInterstitialAd == null) {
                loadRewardedInterstitial();
                dispatchJsEvent("rewarded_interstitial_unavailable", placement, false);
                return;
            }
            suppressAppOpenOnFullscreen();
            final boolean[] rewardGranted = {false};
            rewardedInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdShowedFullScreenContent() {
                    rewardedInterstitialDiag.impressions++;
                    rewardedInterstitialDiag.status = "SHOWING";
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    rewardedInterstitialAd = null;
                    rewardedInterstitialDiag.status = "IDLE";
                    loadRewardedInterstitial();
                    dispatchJsEvent("rewarded_interstitial_closed", placement, rewardGranted[0]);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                    rewardedInterstitialAd = null;
                    rewardedInterstitialDiag.status = "FAILED";
                    rewardedInterstitialDiag.failures++;
                    rewardedInterstitialDiag.lastErrorCode = adError.getCode();
                    rewardedInterstitialDiag.lastErrorMessage = "Show failed (" + adError.getCode() + "): " + adError.getMessage();
                    loadRewardedInterstitial();
                    dispatchJsEvent("rewarded_interstitial_failed", placement, false);
                }
            });
            rewardedInterstitialAd.show(activity, rewardItem -> {
                rewardGranted[0] = true;
                dispatchJsEvent("rewarded_interstitial_earned", placement, true);
            });
        });
    }

    public void loadNativeAd() {
        if (isLoadingNative) return;
        isLoadingNative = true;
        nativeDiag.status = "LOADING";

        AdLoader adLoader = new AdLoader.Builder(activity, AdConfig.NATIVE_ADVANCED_AD_ID)
                .forNativeAd(nativeAd -> {
                    if (activity.isDestroyed() || activity.isFinishing()) {
                        nativeAd.destroy();
                        return;
                    }
                    if (currentNativeAd != null) {
                        currentNativeAd.destroy();
                    }
                    currentNativeAd = nativeAd;
                    isLoadingNative = false;
                    nativeDiag.status = "LOADED";
                    nativeDiag.lastErrorCode = 0;
                    nativeDiag.lastErrorMessage = "";
                    if (nativeVisibleRequested) {
                        renderNativeAd();
                    }
                })
                .withAdListener(new AdListener() {
                    @Override
                    public void onAdImpression() {
                        nativeDiag.impressions++;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        isLoadingNative = false;
                        nativeDiag.status = "FAILED";
                        nativeDiag.failures++;
                        nativeDiag.lastErrorCode = error.getCode();
                        nativeDiag.lastErrorMessage = classifyLoadError(error);
                        mainHandler.postDelayed(AdMobManager.this::loadNativeAd, 14000L);
                    }
                })
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void renderNativeAd() {
        if (currentNativeAd == null) {
            nativeContainer.setVisibility(View.GONE);
            loadNativeAd();
            return;
        }
        NativeAdView adView = (NativeAdView) LayoutInflater.from(activity)
                .inflate(R.layout.native_ad_card, nativeContainer, false);

        TextView headline = adView.findViewById(R.id.ad_headline);
        TextView body = adView.findViewById(R.id.ad_body);
        TextView advertiser = adView.findViewById(R.id.ad_advertiser);
        Button cta = adView.findViewById(R.id.ad_call_to_action);
        ImageView icon = adView.findViewById(R.id.ad_app_icon);
        MediaView media = adView.findViewById(R.id.ad_media);

        adView.setHeadlineView(headline);
        adView.setBodyView(body);
        adView.setAdvertiserView(advertiser);
        adView.setCallToActionView(cta);
        adView.setIconView(icon);
        adView.setMediaView(media);

        headline.setText(currentNativeAd.getHeadline());

        if (currentNativeAd.getBody() != null) {
            body.setVisibility(View.VISIBLE);
            body.setText(currentNativeAd.getBody());
        } else {
            body.setVisibility(View.GONE);
        }

        if (currentNativeAd.getAdvertiser() != null) {
            advertiser.setVisibility(View.VISIBLE);
            advertiser.setText(currentNativeAd.getAdvertiser());
        } else {
            advertiser.setVisibility(View.GONE);
        }

        if (currentNativeAd.getCallToAction() != null) {
            cta.setVisibility(View.VISIBLE);
            cta.setText(currentNativeAd.getCallToAction());
        } else {
            cta.setVisibility(View.INVISIBLE);
        }

        if (currentNativeAd.getIcon() != null) {
            icon.setVisibility(View.VISIBLE);
            icon.setImageDrawable(currentNativeAd.getIcon().getDrawable());
        } else {
            icon.setVisibility(View.GONE);
        }

        if (currentNativeAd.getMediaContent() != null) {
            media.setMediaContent(currentNativeAd.getMediaContent());
        }

        adView.setNativeAd(currentNativeAd);
        nativeContainer.removeAllViews();
        nativeContainer.addView(adView);
        nativeContainer.setVisibility(View.VISIBLE);
        nativeNeedsRefresh = true;
    }

    public void showNativeAd() {
        activity.runOnUiThread(() -> {
            nativeVisibleRequested = true;
            if (currentNativeAd != null) {
                renderNativeAd();
            } else {
                loadNativeAd();
            }
        });
    }

    public void hideNativeAd() {
        activity.runOnUiThread(() -> {
            nativeVisibleRequested = false;
            nativeContainer.setVisibility(View.GONE);
            if (nativeNeedsRefresh) {
                nativeNeedsRefresh = false;
                loadNativeAd();
            }
        });
    }

    private JSONObject diagToJson(String format, String adUnitId, FormatDiag diag) throws Exception {
        JSONObject o = new JSONObject();
        o.put("format", format);
        o.put("adUnitId", adUnitId);
        o.put("status", diag.status);
        o.put("lastErrorCode", diag.lastErrorCode);
        o.put("lastErrorMessage", diag.lastErrorMessage);
        o.put("impressions", diag.impressions);
        o.put("failures", diag.failures);
        return o;
    }

    public String getAdDiagnosticsJson() {
        try {
            JSONObject root = new JSONObject();
            String sdkStatus = "UNKNOWN";
            String sdkDetail = "";
            AppOpenAdManager appOpen = null;
            if (activity.getApplication() instanceof ArrowEscapeApplication app) {
                sdkStatus = app.getSdkInitStatus();
                sdkDetail = app.getSdkInitDetail();
                appOpen = app.getAppOpenAdManager();
            }
            root.put("isNativeAndroid", true);
            root.put("sdkInitStatus", sdkStatus);
            root.put("sdkInitDetail", sdkDetail);
            root.put("appId", AdConfig.ADMOB_APP_ID);

            JSONObject appOpenJson = new JSONObject();
            appOpenJson.put("format", "App Open");
            appOpenJson.put("adUnitId", AdConfig.APP_OPEN_AD_ID);
            appOpenJson.put("status", appOpen != null ? appOpen.getStatus() : "UNAVAILABLE");
            appOpenJson.put("lastErrorCode", appOpen != null ? appOpen.getLastErrorCode() : 0);
            appOpenJson.put("lastErrorMessage", appOpen != null ? appOpen.getLastErrorMessage() : "");
            appOpenJson.put("impressions", appOpen != null ? appOpen.getImpressions() : 0);
            appOpenJson.put("failures", appOpen != null ? appOpen.getFailures() : 0);

            root.put("appOpen", appOpenJson);
            root.put("banner", diagToJson("Banner", AdConfig.BANNER_AD_ID, bannerDiag));
            root.put("interstitial", diagToJson("Interstitial", AdConfig.INTERSTITIAL_AD_ID, interstitialDiag));
            root.put("native", diagToJson("Native Advanced", AdConfig.NATIVE_ADVANCED_AD_ID, nativeDiag));
            root.put("rewarded", diagToJson("Rewarded", AdConfig.REWARDED_AD_ID, rewardedDiag));
            root.put("rewardedInterstitial", diagToJson("Rewarded Interstitial", AdConfig.REWARDED_INTERSTITIAL_AD_ID, rewardedInterstitialDiag));
            return root.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public void onPause() {
        if (bannerAdView != null) {
            bannerAdView.pause();
        }
    }

    public void onResume() {
        if (bannerAdView != null) {
            bannerAdView.resume();
        }
    }

    public void destroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        if (currentNativeAd != null) {
            currentNativeAd.destroy();
            currentNativeAd = null;
        }
    }

    public AdJsBridge createJsBridge() {
        return new AdJsBridge();
    }

    public class AdJsBridge {
        @JavascriptInterface
        public void setBannerVisible(boolean visible) {
            AdMobManager.this.setBannerVisible(visible);
        }

        @JavascriptInterface
        public void showInterstitial(String placement) {
            AdMobManager.this.showInterstitial(placement);
        }

        @JavascriptInterface
        public void showRewarded(String placement) {
            AdMobManager.this.showRewarded(placement);
        }

        @JavascriptInterface
        public void showRewardedInterstitial(String placement) {
            AdMobManager.this.showRewardedInterstitial(placement);
        }

        @JavascriptInterface
        public void showNativeAd() {
            AdMobManager.this.showNativeAd();
        }

        @JavascriptInterface
        public void hideNativeAd() {
            AdMobManager.this.hideNativeAd();
        }

        @JavascriptInterface
        public boolean isRewardedReady() {
            return rewardedAd != null;
        }

        @JavascriptInterface
        public boolean isRewardedInterstitialReady() {
            return rewardedInterstitialAd != null;
        }

        @JavascriptInterface
        public boolean isInterstitialReady() {
            return interstitialAd != null;
        }

        @JavascriptInterface
        public String getAdDiagnosticsJson() {
            return AdMobManager.this.getAdDiagnosticsJson();
        }
    }
}
