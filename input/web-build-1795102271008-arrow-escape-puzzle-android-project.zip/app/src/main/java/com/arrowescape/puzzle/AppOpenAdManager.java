package com.arrowescape.puzzle;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;

public class AppOpenAdManager implements Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    private static final long FOUR_HOURS_MS = 4L * 3600L * 1000L;
    private static final long SHOW_COOLDOWN_MS = 60_000L;

    private final Application application;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private AppOpenAd appOpenAd = null;
    private boolean isLoadingAd = false;
    private boolean isShowingAd = false;
    private long loadTimeMs = 0L;
    private long lastShowTimeMs = 0L;
    private Activity currentActivity = null;
    private volatile boolean suppressNextShow = false;

    // Live diagnostics state
    private volatile String status = "IDLE";
    private volatile int lastErrorCode = 0;
    private volatile String lastErrorMessage = "";
    private volatile int impressions = 0;
    private volatile int failures = 0;

    public AppOpenAdManager(@NonNull Application application) {
        this.application = application;
        application.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

    public void setSuppressNextShow(boolean suppress) {
        this.suppressNextShow = suppress;
    }

    public String getStatus() {
        return status;
    }

    public int getLastErrorCode() {
        return lastErrorCode;
    }

    public String getLastErrorMessage() {
        return lastErrorMessage;
    }

    public int getImpressions() {
        return impressions;
    }

    public int getFailures() {
        return failures;
    }

    public void loadAd() {
        if (isLoadingAd || isAdAvailable()) {
            return;
        }
        isLoadingAd = true;
        status = "LOADING";
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(
                application,
                AdConfig.APP_OPEN_AD_ID,
                request,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        appOpenAd = ad;
                        isLoadingAd = false;
                        loadTimeMs = new Date().getTime();
                        status = "LOADED";
                        lastErrorCode = 0;
                        lastErrorMessage = "";
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        isLoadingAd = false;
                        failures++;
                        lastErrorCode = loadAdError.getCode();
                        lastErrorMessage = classifyLoadError(loadAdError);
                        status = "FAILED";
                        mainHandler.postDelayed(AppOpenAdManager.this::loadAd, 12000L);
                    }
                }
        );
    }

    private String classifyLoadError(@NonNull LoadAdError err) {
        int code = err.getCode();
        String tag;
        if (code == AdRequest.ERROR_CODE_NO_FILL) {
            tag = "NO_FILL (Code 3)";
        } else if (code == AdRequest.ERROR_CODE_NETWORK_ERROR) {
            tag = "NETWORK_ERROR (Code 2)";
        } else if (code == AdRequest.ERROR_CODE_INVALID_REQUEST) {
            tag = "INVALID_REQUEST (Code 1)";
        } else if (code == AdRequest.ERROR_CODE_APP_ID_MISSING) {
            tag = "APP_ID_MISSING (Code 8)";
        } else {
            tag = "ERROR (Code " + code + ")";
        }
        return tag + ": " + err.getMessage();
    }

    private boolean wasLoadTimeLessThanNHoursAgo() {
        long dateDifference = new Date().getTime() - loadTimeMs;
        return dateDifference < FOUR_HOURS_MS;
    }

    private boolean isAdAvailable() {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo();
    }

    public void showAdIfAvailable() {
        if (isShowingAd || suppressNextShow || currentActivity == null) {
            suppressNextShow = false;
            return;
        }
        long now = System.currentTimeMillis();
        if (lastShowTimeMs > 0 && (now - lastShowTimeMs) < SHOW_COOLDOWN_MS) {
            return;
        }
        if (!isAdAvailable()) {
            loadAd();
            return;
        }

        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                appOpenAd = null;
                isShowingAd = false;
                status = "IDLE";
                loadAd();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                appOpenAd = null;
                isShowingAd = false;
                failures++;
                lastErrorCode = adError.getCode();
                lastErrorMessage = "Show failed (" + adError.getCode() + "): " + adError.getMessage();
                status = "FAILED";
                loadAd();
            }

            @Override
            public void onAdShowedFullScreenContent() {
                isShowingAd = true;
                lastShowTimeMs = System.currentTimeMillis();
                impressions++;
                status = "SHOWING";
            }
        });

        isShowingAd = true;
        appOpenAd.show(currentActivity);
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        showAdIfAvailable();
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        if (!isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {}

    @Override
    public void onActivityStopped(@NonNull Activity activity) {}

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        if (currentActivity == activity) {
            currentActivity = null;
        }
    }
}
