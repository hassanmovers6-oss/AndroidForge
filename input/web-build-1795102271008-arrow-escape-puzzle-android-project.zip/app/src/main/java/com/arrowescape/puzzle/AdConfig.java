package com.arrowescape.puzzle;

public final class AdConfig {
    private AdConfig() {}

    public static final String ADMOB_APP_ID = "ca-app-pub-3133971041724338~2576474017";
    public static final String APP_OPEN_AD_ID = "ca-app-pub-3133971041724338/3930964467";
    public static final String BANNER_AD_ID = "ca-app-pub-3133971041724338/6675501123";
    public static final String INTERSTITIAL_AD_ID = "ca-app-pub-3133971041724338/5362419458";
    public static final String NATIVE_ADVANCED_AD_ID = "ca-app-pub-3133971041724338/2736256113";
    public static final String REWARDED_AD_ID = "ca-app-pub-3133971041724338/6020895009";
    public static final String REWARDED_INTERSTITIAL_AD_ID = "ca-app-pub-3133971041724338/5052474440";
}
