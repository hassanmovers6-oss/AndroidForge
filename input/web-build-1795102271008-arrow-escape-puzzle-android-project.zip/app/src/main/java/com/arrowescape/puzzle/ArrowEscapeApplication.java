package com.arrowescape.puzzle;

import android.app.Application;

import com.google.android.gms.ads.MobileAds;

import java.util.concurrent.atomic.AtomicBoolean;

public class ArrowEscapeApplication extends Application {
    private final AtomicBoolean adsInitStarted = new AtomicBoolean(false);
    private volatile String sdkInitStatus = "INITIALIZING";
    private volatile String sdkInitDetail = "Starting Google Mobile Ads SDK...";
    private AppOpenAdManager appOpenAdManager;

    @Override
    public void onCreate() {
        super.onCreate();
        appOpenAdManager = new AppOpenAdManager(this);

        if (adsInitStarted.compareAndSet(false, true)) {
            try {
                MobileAds.initialize(this, initializationStatus -> {
                    sdkInitStatus = "INITIALIZED";
                    int adapterCount = initializationStatus != null
                            ? initializationStatus.getAdapterStatusMap().size()
                            : 0;
                    sdkInitDetail = "Initialized (" + adapterCount + " adapter(s))";
                    if (appOpenAdManager != null) {
                        appOpenAdManager.loadAd();
                    }
                });
            } catch (Exception e) {
                sdkInitStatus = "ERROR";
                sdkInitDetail = e.getMessage() != null ? e.getMessage() : "MobileAds.initialize failed";
            }
        }
    }

    public AppOpenAdManager getAppOpenAdManager() {
        return appOpenAdManager;
    }

    public String getSdkInitStatus() {
        return sdkInitStatus;
    }

    public String getSdkInitDetail() {
        return sdkInitDetail;
    }
}
