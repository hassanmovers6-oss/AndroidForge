package com.educationwithhassan.dukaansaathi.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.ads.NativeAdCard
import com.educationwithhassan.dukaansaathi.data.local.entity.ProductEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.BarcodeScannerDialog
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.components.formatTimestamp
import com.educationwithhassan.dukaansaathi.ui.theme.AmberWarning
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.theme.EmeraldSuccess
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel
import com.educationwithhassan.dukaansaathi.util.VoiceProductParser

@Composable
fun ProductsScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    openAddDialogInitially: Boolean = false,
    onConsumeOpenAdd: () -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var sortOption by remember { mutableStateOf("Name A-Z") }
    var sortMenuExpanded by remember { mutableStateOf(false) }

    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showFormDialog by remember(openAddDialogInitially) { mutableStateOf(openAddDialogInitially) }
    var detailProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<ProductEntity?>(null) }
    var showBarcodeSearch by remember { mutableStateOf(false) }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val categories = remember(state.products) {
        listOf("All", "Low Stock", "Out of Stock") + state.products.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()
    }

    val filteredProducts = remember(state.products, searchQuery, selectedCategory, sortOption) {
        state.products
            .filter { p ->
                val matchesSearch = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.sku.contains(searchQuery, ignoreCase = true) ||
                    p.barcode.contains(searchQuery, ignoreCase = true) ||
                    p.brand.contains(searchQuery, ignoreCase = true)

                val matchesCategory = when (selectedCategory) {
                    "All" -> true
                    "Low Stock" -> p.quantity in 1..p.minStockLevel
                    "Out of Stock" -> p.quantity <= 0
                    else -> p.category.equals(selectedCategory, ignoreCase = true)
                }
                matchesSearch && matchesCategory
            }
            .let { list ->
                when (sortOption) {
                    "Stock Low-High" -> list.sortedBy { it.quantity }
                    "Price High-Low" -> list.sortedByDescending { it.sellingPrice }
                    "Newest First" -> list.sortedByDescending { it.dateAdded }
                    else -> list.sortedBy { it.name.lowercase() }
                }
            }
    }

    val inventoryValueCost = state.products.sumOf { it.purchasePrice * it.quantity }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingProduct = null
                    showFormDialog = true
                },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Product")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Inventory", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        text = "${state.products.size} items · Cost Value: ${fmt(inventoryValueCost)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    OutlinedButton(onClick = { sortMenuExpanded = true }) {
                        Text(sortOption)
                    }
                    DropdownMenu(
                        expanded = sortMenuExpanded,
                        onDismissRequest = { sortMenuExpanded = false }
                    ) {
                        listOf("Name A-Z", "Stock Low-High", "Price High-Low", "Newest First").forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    sortOption = opt
                                    sortMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search name, SKU, brand, or barcode...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    IconButton(onClick = { showBarcodeSearch = true }) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Barcode")
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) }
                    )
                }
            }

            if (filteredProducts.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Inventory2,
                    title = if (state.products.isEmpty()) "No products in inventory" else "No matching products",
                    description = if (state.products.isEmpty()) {
                        "Add products manually, scan barcodes, or use optional voice product entry."
                    } else {
                        "Try clearing your search or category filter."
                    },
                    actionLabel = if (state.products.isEmpty()) "Add Product" else null,
                    onAction = if (state.products.isEmpty()) {
                        { editingProduct = null; showFormDialog = true }
                    } else null
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        val stockColor = when {
                            product.quantity <= 0 -> CrimsonError
                            product.quantity <= product.minStockLevel -> AmberWarning
                            else -> EmeraldSuccess
                        }
                        val stockStatus = when {
                            product.quantity <= 0 -> "Out of Stock"
                            product.quantity <= product.minStockLevel -> "Low Stock"
                            else -> "In Stock"
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { detailProduct = product }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        text = product.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${product.category}${if (product.brand.isNotBlank()) " · ${product.brand}" else ""}${if (product.sku.isNotBlank()) " · SKU ${product.sku}" else ""}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Cost ${fmt(product.purchasePrice)} · Sell ${fmt(product.sellingPrice)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${product.quantity} pcs",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = stockColor
                                    )
                                    Text(
                                        text = stockStatus,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = stockColor
                                    )
                                }
                            }
                        }
                    }

                    if (filteredProducts.size >= 3) {
                        item(key = "products_native_ad") {
                            Spacer(modifier = Modifier.height(4.dp))
                            NativeAdCard()
                        }
                    }
                }
            }
        }
    }

    if (showBarcodeSearch) {
        BarcodeScannerDialog(
            title = "Find Product by Barcode",
            onBarcodeDetected = { code ->
                showBarcodeSearch = false
                searchQuery = code
            },
            onDismiss = { showBarcodeSearch = false }
        )
    }

    if (showFormDialog) {
        ProductFormDialog(
            initial = editingProduct,
            suppliers = state.suppliers.map { it.id to it.name },
            defaultLowStock = cfg.lowStockThreshold,
            onDismiss = {
                showFormDialog = false
                onConsumeOpenAdd()
            },
            onSave = { entity ->
                viewModel.saveProduct(entity) {
                    showFormDialog = false
                    onConsumeOpenAdd()
                }
            }
        )
    }

    detailProduct?.let { product ->
        ProductDetailDialog(
            product = product,
            viewModel = viewModel,
            currencyCode = cfg.currencyCode,
            currencySymbol = cfg.currencySymbol,
            onEdit = {
                detailProduct = null
                editingProduct = product
                showFormDialog = true
            },
            onDelete = {
                detailProduct = null
                deleteCandidate = product
            },
            onDismiss = { detailProduct = null }
        )
    }

    deleteCandidate?.let { product ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete Product?") },
            text = { Text("Remove '${product.name}' from inventory? Past sales records will keep the product name.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteProduct(product)
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ProductFormDialog(
    initial: ProductEntity?,
    suppliers: List<Pair<Long, String>>,
    defaultLowStock: Int,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var sku by remember { mutableStateOf(initial?.sku.orEmpty()) }
    var barcode by remember { mutableStateOf(initial?.barcode.orEmpty()) }
    var category by remember { mutableStateOf(initial?.category ?: "General") }
    var brand by remember { mutableStateOf(initial?.brand.orEmpty()) }
    var purchasePrice by remember { mutableStateOf(initial?.purchasePrice?.toString().orEmpty()) }
    var sellingPrice by remember { mutableStateOf(initial?.sellingPrice?.toString().orEmpty()) }
    var quantity by remember { mutableStateOf(initial?.quantity?.toString() ?: "0") }
    var minStock by remember { mutableStateOf(initial?.minStockLevel?.toString() ?: defaultLowStock.toString()) }
    var taxOverride by remember { mutableStateOf(initial?.taxPercentOverride?.toString().orEmpty()) }
    var description by remember { mutableStateOf(initial?.description.orEmpty()) }
    var selectedSupplierId by remember { mutableStateOf(initial?.supplierId) }
    var selectedSupplierName by remember { mutableStateOf(initial?.supplierName.orEmpty()) }
    var supplierMenuOpen by remember { mutableStateOf(false) }

    var showScanner by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                val parsed = VoiceProductParser.parse(spoken)
                if (parsed.name.isNotBlank()) name = parsed.name
                if (parsed.quantity.isNotBlank()) quantity = parsed.quantity
                if (parsed.purchasePrice.isNotBlank()) purchasePrice = parsed.purchasePrice
                if (parsed.sellingPrice.isNotBlank()) sellingPrice = parsed.sellingPrice
                if (parsed.category.isNotBlank()) category = parsed.category
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (initial == null) "Add Product" else "Edit Product")
                IconButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say e.g. 'Sugar quantity 20 purchase price 110 selling price 130 category Grocery'")
                        }
                        try {
                            voiceLauncher.launch(intent)
                        } catch (_: Exception) {
                            errorText = "Speech recognition is not available on this device. Please type manually."
                        }
                    }
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice Entry")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("Product Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("Barcode") },
                    trailingIcon = {
                        IconButton(onClick = { showScanner = true }) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan")
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("Brand (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it; errorText = null },
                        label = { Text("Purchase Cost *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it; errorText = null },
                        label = { Text("Selling Price *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Stock Qty *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minStock,
                        onValueChange = { minStock = it },
                        label = { Text("Min Stock Alert") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = taxOverride,
                    onValueChange = { taxOverride = it },
                    label = { Text("Tax % Override (Blank = Shop Default)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (suppliers.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { supplierMenuOpen = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (selectedSupplierName.isNotBlank()) "Supplier: $selectedSupplierName" else "Select Supplier (Optional)")
                    }
                    DropdownMenu(
                        expanded = supplierMenuOpen,
                        onDismissRequest = { supplierMenuOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("None") },
                            onClick = {
                                selectedSupplierId = null
                                selectedSupplierName = ""
                                supplierMenuOpen = false
                            }
                        )
                        suppliers.forEach { (id, sName) ->
                            DropdownMenuItem(
                                text = { Text(sName) },
                                onClick = {
                                    selectedSupplierId = id
                                    selectedSupplierName = sName
                                    supplierMenuOpen = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Notes") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) {
                    Text(errorText!!, color = CrimsonError, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedName = name.trim()
                    val cost = purchasePrice.toDoubleOrNull()
                    val sell = sellingPrice.toDoubleOrNull()
                    val qty = quantity.toIntOrNull()
                    val minQty = minStock.toIntOrNull() ?: defaultLowStock
                    if (trimmedName.isEmpty() || cost == null || sell == null || qty == null) {
                        errorText = "Enter valid name, purchase cost, selling price, and quantity."
                        return@Button
                    }
                    onSave(
                        ProductEntity(
                            id = initial?.id ?: 0L,
                            name = trimmedName,
                            sku = sku.trim(),
                            barcode = barcode.trim(),
                            category = category.trim().ifBlank { "General" },
                            brand = brand.trim(),
                            purchasePrice = cost.coerceAtLeast(0.0),
                            sellingPrice = sell.coerceAtLeast(0.0),
                            quantity = qty,
                            minStockLevel = minQty.coerceAtLeast(0),
                            description = description.trim(),
                            supplierId = selectedSupplierId,
                            supplierName = selectedSupplierName,
                            taxPercentOverride = taxOverride.toDoubleOrNull()?.coerceAtLeast(0.0),
                            dateAdded = initial?.dateAdded ?: System.currentTimeMillis()
                        )
                    )
                }
            ) { Text("Save Product") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )

    if (showScanner) {
        BarcodeScannerDialog(
            title = "Assign Product Barcode",
            onBarcodeDetected = { code ->
                barcode = code
                showScanner = false
            },
            onDismiss = { showScanner = false }
        )
    }
}

@Composable
private fun ProductDetailDialog(
    product: ProductEntity,
    viewModel: ShopViewModel,
    currencyCode: String,
    currencySymbol: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val adjustments by viewModel.observeAdjustmentsForProduct(product.id).collectAsState(initial = emptyList())
    var newQtyInput by remember { mutableStateOf(product.quantity.toString()) }
    var adjReason by remember { mutableStateOf("Stock Count") }
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, currencyCode, currencySymbol) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(product.name, modifier = Modifier.weight(1f))
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonError)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SectionCard {
                    Text("Category: ${product.category} · Brand: ${product.brand.ifBlank { "-" }}")
                    Text("SKU: ${product.sku.ifBlank { "-" }} · Barcode: ${product.barcode.ifBlank { "-" }}")
                    Text("Purchase Cost: ${fmt(product.purchasePrice)} · Selling Price: ${fmt(product.sellingPrice)}")
                    Text(
                        text = "Current Stock: ${product.quantity} (Min Alert: ${product.minStockLevel})",
                        fontWeight = FontWeight.SemiBold
                    )
                    if (product.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(product.description, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Text("Quick Stock Adjustment", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newQtyInput,
                        onValueChange = { newQtyInput = it },
                        label = { Text("New Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.width(110.dp)
                    )
                    OutlinedTextField(
                        value = adjReason,
                        onValueChange = { adjReason = it },
                        label = { Text("Reason") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Button(
                    onClick = {
                        val qty = newQtyInput.toIntOrNull() ?: return@Button
                        viewModel.adjustStock(product.id, qty, adjReason.ifBlank { "Manual Stock Update" })
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Update Stock")
                }

                Text("Stock Adjustment History", fontWeight = FontWeight.SemiBold)
                if (adjustments.isEmpty()) {
                    Text("No stock changes logged yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    adjustments.take(10).forEach { adj ->
                        val sign = if (adj.deltaQty >= 0) "+" else ""
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(adj.reason, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(formatTimestamp(adj.createdAt), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                text = "$sign${adj.deltaQty} (${adj.previousQty} -> ${adj.newQty})",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
