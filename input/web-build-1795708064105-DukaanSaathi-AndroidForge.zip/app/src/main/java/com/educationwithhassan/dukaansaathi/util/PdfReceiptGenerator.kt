package com.educationwithhassan.dukaansaathi.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerPaymentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReceiptGenerator {

    private val dateFormatter = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)

    fun generateSaleReceiptPdf(
        context: Context,
        config: ShopConfigEntity,
        sale: SaleEntity,
        items: List<SaleItemEntity>
    ): File {
        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(dir, "Receipt_${sale.invoiceNumber}.pdf")

        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#0B192C")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val boldPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 10.5f
        }
        val mutedPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 9.5f
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }
        val rightBodyPaint = Paint(bodyPaint).apply { textAlign = Paint.Align.RIGHT }
        val rightBoldPaint = Paint(boldPaint).apply { textAlign = Paint.Align.RIGHT }

        var y = 48f
        val left = 40f
        val right = pageWidth - 40f

        // Header
        canvas.drawText(config.shopName.ifBlank { "Dukaan Saathi Shop" }, left, y, titlePaint)
        y += 18f
        if (config.shopAddress.isNotBlank()) {
            canvas.drawText(config.shopAddress, left, y, bodyPaint)
            y += 14f
        }
        val contactLine = listOfNotNull(
            config.phone.takeIf { it.isNotBlank() }?.let { "Tel: $it" },
            config.email.takeIf { it.isNotBlank() }
        ).joinToString("  |  ")
        if (contactLine.isNotBlank()) {
            canvas.drawText(contactLine, left, y, mutedPaint)
            y += 14f
        }
        if (config.receiptHeader.isNotBlank()) {
            canvas.drawText(config.receiptHeader, left, y, mutedPaint)
            y += 14f
        }

        y += 8f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 20f

        // Invoice Meta
        canvas.drawText("INVOICE: ${sale.invoiceNumber}", left, y, boldPaint)
        canvas.drawText("Date: ${dateFormatter.format(Date(sale.createdAt))}", right, y, rightBodyPaint)
        y += 16f
        canvas.drawText("Customer: ${sale.customerName}", left, y, bodyPaint)
        canvas.drawText("Payment: ${sale.paymentMethod}", right, y, rightBodyPaint)
        y += 14f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 18f

        // Table Header
        canvas.drawText("Item", left, y, boldPaint)
        canvas.drawText("Qty", 330f, y, rightBoldPaint)
        canvas.drawText("Rate", 425f, y, rightBoldPaint)
        canvas.drawText("Amount", right, y, rightBoldPaint)
        y += 8f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 16f

        val fmt = { v: Double -> CurrencyFormatter.format(v, sale.currencyCode, config.currencySymbol) }

        items.forEach { item ->
            if (y > pageHeight - 160) return@forEach
            val itemName = if (item.productName.length > 34) item.productName.take(31) + "..." else item.productName
            canvas.drawText(itemName, left, y, bodyPaint)
            canvas.drawText(item.quantity.toString(), 330f, y, rightBodyPaint)
            canvas.drawText(fmt(item.unitPrice), 425f, y, rightBodyPaint)
            canvas.drawText(fmt(item.lineTotal), right, y, rightBodyPaint)
            y += 18f
        }

        y += 6f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 18f

        fun drawSummaryRow(label: String, value: String, isBold: Boolean = false) {
            val pLeft = if (isBold) boldPaint else bodyPaint
            val pRight = if (isBold) rightBoldPaint else rightBodyPaint
            canvas.drawText(label, 310f, y, pLeft)
            canvas.drawText(value, right, y, pRight)
            y += 17f
        }

        drawSummaryRow("Subtotal", fmt(sale.subtotal))
        if (sale.discountAmount > 0.0) {
            drawSummaryRow("Discount", "-${fmt(sale.discountAmount)}")
        }
        if (sale.taxAmount > 0.0 || config.taxEnabled) {
            val taxLabel = if (sale.taxIncludedInPrice) "Tax (Included)" else "Tax (User-Configured)"
            drawSummaryRow(taxLabel, fmt(sale.taxAmount))
        }
        drawSummaryRow("Grand Total", fmt(sale.grandTotal), isBold = true)
        drawSummaryRow("Amount Paid", fmt(sale.paidAmount))
        if (sale.balanceDue > 0.009) {
            drawSummaryRow("Remaining Balance", fmt(sale.balanceDue), isBold = true)
        }

        y += 16f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 20f
        if (config.receiptFooter.isNotBlank()) {
            canvas.drawText(config.receiptFooter, left, y, mutedPaint)
            y += 14f
        }
        canvas.drawText("Generated by Dukaan Saathi", left, y, mutedPaint)

        document.finishPage(page)
        FileOutputStream(file).use { out ->
            document.writeTo(out)
        }
        document.close()
        return file
    }

    fun generateCustomerStatementPdf(
        context: Context,
        config: ShopConfigEntity,
        customer: CustomerEntity,
        sales: List<SaleEntity>,
        payments: List<CustomerPaymentEntity>
    ): File {
        val dir = File(context.cacheDir, "statements").apply { mkdirs() }
        val safeName = customer.fullName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "Statement_${safeName}.pdf")

        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#0B192C")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val boldPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 10f
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }
        val fmt = { v: Double -> CurrencyFormatter.format(v, config.currencyCode, config.currencySymbol) }

        var y = 46f
        val left = 40f
        val right = pageWidth - 40f

        canvas.drawText("${config.shopName} - Customer Statement", left, y, titlePaint)
        y += 20f
        canvas.drawText("Customer: ${customer.fullName}  |  Phone: ${customer.phone.ifBlank { "-" }}", left, y, bodyPaint)
        y += 16f
        canvas.drawText("Total Purchases: ${fmt(customer.totalPurchases)}   |   Outstanding Credit: ${fmt(customer.outstandingBalance)}", left, y, boldPaint)
        y += 12f
        canvas.drawLine(left, y, right, y, linePaint)
        y += 18f

        canvas.drawText("Sales & Payments History", left, y, boldPaint)
        y += 16f

        val entries = buildList {
            sales.forEach { add(Triple(it.createdAt, "Sale ${it.invoiceNumber} (${it.paymentMethod})", "Total ${fmt(it.grandTotal)} / Due ${fmt(it.balanceDue)}")) }
            payments.forEach { add(Triple(it.createdAt, "Payment (${it.paymentMethod})", "Paid ${fmt(it.amount)}")) }
        }.sortedByDescending { it.first }

        entries.take(30).forEach { (ts, label, amountText) ->
            if (y > pageHeight - 50) return@forEach
            canvas.drawText(dateFormatter.format(Date(ts)), left, y, bodyPaint)
            canvas.drawText(label, 175f, y, bodyPaint)
            canvas.drawText(amountText, 385f, y, bodyPaint)
            y += 16f
        }

        document.finishPage(page)
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        return file
    }

    fun sharePdfFile(context: Context, file: File, subject: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun printPdfFile(context: Context, file: File, jobName: String) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(file.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                try {
                    FileInputStream(file).use { input ->
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }
}
