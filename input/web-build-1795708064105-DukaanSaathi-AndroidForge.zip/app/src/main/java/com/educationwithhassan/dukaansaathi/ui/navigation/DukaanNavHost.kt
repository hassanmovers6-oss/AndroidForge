package com.educationwithhassan.dukaansaathi.ui.navigation

import android.app.Activity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.educationwithhassan.dukaansaathi.ads.AdMobManager
import com.educationwithhassan.dukaansaathi.ads.BannerAd
import com.educationwithhassan.dukaansaathi.ui.components.BarcodeScannerDialog
import com.educationwithhassan.dukaansaathi.ui.screens.AiAssistantScreen
import com.educationwithhassan.dukaansaathi.ui.screens.BackupRestoreScreen
import com.educationwithhassan.dukaansaathi.ui.screens.CustomersScreen
import com.educationwithhassan.dukaansaathi.ui.screens.DashboardScreen
import com.educationwithhassan.dukaansaathi.ui.screens.ExpensesScreen
import com.educationwithhassan.dukaansaathi.ui.screens.MoreHubScreen
import com.educationwithhassan.dukaansaathi.ui.screens.ProductsScreen
import com.educationwithhassan.dukaansaathi.ui.screens.ReportsScreen
import com.educationwithhassan.dukaansaathi.ui.screens.SalesPosScreen
import com.educationwithhassan.dukaansaathi.ui.screens.SettingsScreen
import com.educationwithhassan.dukaansaathi.ui.screens.SetupScreen
import com.educationwithhassan.dukaansaathi.ui.screens.SuppliersScreen
import com.educationwithhassan.dukaansaathi.ui.screens.UdhaarScreen
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel

private data class BottomTab(
    val route: String,
    val label: String,
    val icon: ImageVector
)

private val bottomTabs = listOf(
    BottomTab("dashboard", "Dashboard", Icons.Default.Dashboard),
    BottomTab("products", "Products", Icons.Default.Inventory2),
    BottomTab("sales", "Sales", Icons.Default.PointOfSale),
    BottomTab("customers", "Customers", Icons.Default.People),
    BottomTab("more", "More", Icons.Default.Menu)
)

@Composable
fun DukaanRootHost(
    viewModel: ShopViewModel,
    adMobManager: AdMobManager
) {
    val state by viewModel.uiState.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val activity = context as? Activity

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            snackbarHostState.showSnackbar(statusMessage!!)
            viewModel.clearStatusMessage()
        }
    }

    if (!state.isLoaded) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (!state.config.setupCompleted) {
        LaunchedEffect(Unit) {
            adMobManager.setSensitiveFlowActive(true)
        }
        SetupScreen(
            initialConfig = state.config,
            onCompleteSetup = { cfg -> viewModel.saveShopConfig(cfg) }
        )
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination
    val currentRoute = currentDest?.route
    val topLevelRoutes = bottomTabs.map { it.route }.toSet()
    val showBottomBar = currentRoute in topLevelRoutes
    val showBannerAd = currentRoute != null && currentRoute != "sales"

    LaunchedEffect(currentRoute) {
        // Never interrupt POS checkout, payment, or receipt screens with App Open / Interstitial ads
        adMobManager.setSensitiveFlowActive(currentRoute == "sales")
    }

    var pendingAddProduct by remember { mutableStateOf(false) }
    var pendingAddCustomer by remember { mutableStateOf(false) }
    var pendingAddExpense by remember { mutableStateOf(false) }
    var pendingSaleReceiptId by remember { mutableStateOf<Long?>(null) }
    var showDashboardScanner by remember { mutableStateOf(false) }

    fun switchTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar || showBannerAd) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (showBannerAd) {
                        BannerAd(
                            modifier = if (showBottomBar) {
                                Modifier.fillMaxWidth()
                            } else {
                                Modifier
                                    .fillMaxWidth()
                                    .navigationBarsPadding()
                            }
                        )
                    }
                    if (showBottomBar) {
                        NavigationBar {
                            bottomTabs.forEach { tab ->
                                val selected = currentDest?.hierarchy?.any { it.route == tab.route } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { switchTab(tab.route) },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label, maxLines = 1) }
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(padding)
        ) {
            composable("dashboard") {
                DashboardScreen(
                    state = state,
                    onNewSale = { switchTab("sales") },
                    onAddProduct = {
                        pendingAddProduct = true
                        switchTab("products")
                    },
                    onAddExpense = {
                        pendingAddExpense = true
                        navController.navigate("expenses")
                    },
                    onAddCustomer = {
                        pendingAddCustomer = true
                        switchTab("customers")
                    },
                    onViewReports = {
                        if (activity != null) {
                            adMobManager.showInterstitialAtNaturalBreak(activity) {
                                navController.navigate("reports")
                            }
                        } else {
                            navController.navigate("reports")
                        }
                    },
                    onScanBarcode = { showDashboardScanner = true },
                    onOpenSaleReceipt = { saleId ->
                        pendingSaleReceiptId = saleId
                        switchTab("sales")
                    },
                    onOpenProducts = { switchTab("products") },
                    onOpenCustomers = { switchTab("customers") }
                )
            }

            composable("products") {
                ProductsScreen(
                    state = state,
                    viewModel = viewModel,
                    openAddDialogInitially = pendingAddProduct,
                    onConsumeOpenAdd = { pendingAddProduct = false }
                )
            }

            composable("sales") {
                SalesPosScreen(
                    state = state,
                    viewModel = viewModel,
                    initialSaleIdToView = pendingSaleReceiptId,
                    onConsumeSaleIdToView = { pendingSaleReceiptId = null }
                )
            }

            composable("customers") {
                CustomersScreen(
                    state = state,
                    viewModel = viewModel,
                    openAddInitially = pendingAddCustomer,
                    onConsumeOpenAdd = { pendingAddCustomer = false }
                )
            }

            composable("more") {
                MoreHubScreen(
                    state = state,
                    viewModel = viewModel,
                    adMobManager = adMobManager,
                    onNavigate = { route -> navController.navigate(route) }
                )
            }

            composable("expenses") {
                ExpensesScreen(
                    state = state,
                    viewModel = viewModel,
                    openAddInitially = pendingAddExpense,
                    onConsumeOpenAdd = { pendingAddExpense = false },
                    onBack = { navController.popBackStack() }
                )
            }

            composable("suppliers") {
                SuppliersScreen(
                    state = state,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("reports") {
                ReportsScreen(
                    state = state,
                    viewModel = viewModel,
                    adMobManager = adMobManager,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("udhaar") {
                UdhaarScreen(
                    state = state,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("ai_assistant") {
                AiAssistantScreen(
                    state = state,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("backup") {
                BackupRestoreScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("settings") {
                SettingsScreen(
                    state = state,
                    viewModel = viewModel,
                    onOpenBackup = { navController.navigate("backup") },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }

    if (showDashboardScanner) {
        BarcodeScannerDialog(
            title = "Scan Barcode for POS",
            onBarcodeDetected = { code ->
                showDashboardScanner = false
                viewModel.addBarcodeToCart(code) {
                    viewModel.emitMessage("No product found with barcode '$code'.")
                }
                switchTab("sales")
            },
            onDismiss = { showDashboardScanner = false }
        )
    }
}
