package com.educationwithhassan.dukaansaathi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.educationwithhassan.dukaansaathi.ui.navigation.DukaanRootHost
import com.educationwithhassan.dukaansaathi.ui.theme.DukaanSaathiTheme
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel

class MainActivity : ComponentActivity() {

    private val app: DukaanSaathiApp
        get() = application as DukaanSaathiApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        app.adMobManager.attachActivity(this)

        setContent {
            val viewModel: ShopViewModel = viewModel(
                factory = ShopViewModel.Factory(app.repository)
            )
            val uiState by viewModel.uiState.collectAsState()

            DukaanSaathiTheme(themeMode = uiState.config.themeMode) {
                DukaanRootHost(
                    viewModel = viewModel,
                    adMobManager = app.adMobManager
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        app.adMobManager.attachActivity(this)
    }

    override fun onDestroy() {
        app.adMobManager.detachActivity(this)
        super.onDestroy()
    }
}
