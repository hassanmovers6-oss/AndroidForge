package com.educationwithhassan.dukaansaathi.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.components.formatTimestamp
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel
import com.educationwithhassan.dukaansaathi.util.BackupManager
import com.educationwithhassan.dukaansaathi.util.BackupPayload
import com.educationwithhassan.dukaansaathi.util.ReminderWorker
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: ShopViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingRestore by remember { mutableStateOf<BackupPayload?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = BackupManager.exportToUri(context, viewModel.repository.db, uri)
                res.onSuccess { count ->
                    viewModel.emitMessage("Backup exported successfully ($count core records).")
                }.onFailure { err ->
                    viewModel.emitMessage(err.message ?: "Backup export failed.")
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = BackupManager.validateBackupUri(context, uri)
                res.onSuccess { payload ->
                    pendingRestore = payload
                }.onFailure { err ->
                    viewModel.emitMessage(err.message ?: "Invalid backup file.")
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Backup & Restore") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard {
                Text("Offline Data Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Your shop data is stored locally in an encrypted-partition SQLite/Room database on this device. Dukaan Saathi does not claim automatic cloud sync — always export a backup file to your phone or Drive manually.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { exportLauncher.launch("DukaanSaathi_Backup_${System.currentTimeMillis()}.json") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Export Shop Backup (.json)")
                }
            }

            SectionCard {
                Text("Restore from Backup File", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Select a previously exported Dukaan Saathi .json backup file. The file checksum and schema version will be verified before asking for confirmation.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Select Backup File to Restore")
                }
            }
        }
    }

    pendingRestore?.let { payload ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Overwrite Current Shop Data?") },
            text = {
                Text(
                    "Backup from ${formatTimestamp(payload.metadata.exportedAt)}\n" +
                        "Contains ${payload.products.size} products, ${payload.customers.size} customers, ${payload.sales.size} sales, and ${payload.expenses.size} expenses.\n\n" +
                        "Restoring will replace all current records on this device."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            BackupManager.restorePayload(viewModel.repository.db, payload)
                                .onSuccess { viewModel.emitMessage("Backup restored successfully.") }
                                .onFailure { viewModel.emitMessage(it.message ?: "Restore failed.") }
                            pendingRestore = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError)
                ) { Text("Restore & Replace") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestore = null }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    onOpenBackup: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val cfg = state.config

    var shopName by remember(cfg) { mutableStateOf(cfg.shopName) }
    var address by remember(cfg) { mutableStateOf(cfg.shopAddress) }
    var phone by remember(cfg) { mutableStateOf(cfg.phone) }
    var email by remember(cfg) { mutableStateOf(cfg.email) }
    var currency by remember(cfg) { mutableStateOf(CurrencyFormatter.findByCode(cfg.currencyCode)) }
    var currencyOpen by remember { mutableStateOf(false) }

    var taxEnabled by remember(cfg) { mutableStateOf(cfg.taxEnabled) }
    var taxRate by remember(cfg) { mutableStateOf(cfg.defaultTaxPercent.toString()) }
    var taxInclusive by remember(cfg) { mutableStateOf(cfg.taxInclusive) }

    var receiptHeader by remember(cfg) { mutableStateOf(cfg.receiptHeader) }
    var receiptFooter by remember(cfg) { mutableStateOf(cfg.receiptFooter) }
    var lowStockThreshold by remember(cfg) { mutableStateOf(cfg.lowStockThreshold.toString()) }
    var allowNegative by remember(cfg) { mutableStateOf(cfg.allowNegativeInventory) }
    var themeMode by remember(cfg) { mutableStateOf(cfg.themeMode) }
    var remindersEnabled by remember(cfg) { mutableStateOf(cfg.paymentRemindersEnabled) }

    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        remindersEnabled = granted
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard {
                Text("Shop Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = shopName, onValueChange = { shopName = it }, label = { Text("Shop Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Shop Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }

            SectionCard {
                Text("Currency & User-Configured Tax", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                ExposedDropdownMenuBox(expanded = currencyOpen, onExpandedChange = { currencyOpen = !currencyOpen }) {
                    OutlinedTextField(
                        value = "${currency.code} (${currency.symbol.trim()}) — ${currency.name}",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Display Currency") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = currencyOpen) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = currencyOpen, onDismissRequest = { currencyOpen = false }) {
                        CurrencyFormatter.supportedCurrencies.forEach { info ->
                            DropdownMenuItem(
                                text = { Text("${info.code} (${info.symbol.trim()}) — ${info.name}") },
                                onClick = { currency = info; currencyOpen = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Note: Changing currency updates display symbols without altering historical recorded amounts.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Enable Tax (User-Configured)", fontWeight = FontWeight.Medium)
                    Switch(checked = taxEnabled, onCheckedChange = { taxEnabled = it })
                }
                if (taxEnabled) {
                    OutlinedTextField(
                        value = taxRate,
                        onValueChange = { taxRate = it },
                        label = { Text("Default Tax %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Tax-Inclusive Pricing", fontWeight = FontWeight.Medium)
                        Switch(checked = taxInclusive, onCheckedChange = { taxInclusive = it })
                    }
                }
            }

            SectionCard {
                Text("Inventory, Receipts & Notifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = receiptHeader, onValueChange = { receiptHeader = it }, label = { Text("Receipt Header") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = receiptFooter, onValueChange = { receiptFooter = it }, label = { Text("Receipt Footer") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = lowStockThreshold,
                    onValueChange = { lowStockThreshold = it },
                    label = { Text("Default Low-Stock Threshold") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allow Negative Inventory", fontWeight = FontWeight.Medium)
                        Text("Disabled by default to prevent overselling.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = allowNegative, onCheckedChange = { allowNegative = it })
                }
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Daily Udhaar & Low-Stock Reminders", fontWeight = FontWeight.Medium)
                        Text("Local Android notification summary.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = remindersEnabled,
                        onCheckedChange = { enabled ->
                            if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            ) {
                                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                remindersEnabled = enabled
                            }
                        }
                    )
                }
            }

            SectionCard {
                Text("Appearance Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("SYSTEM" to "System", "LIGHT" to "Light", "DARK" to "Dark").forEach { (key, label) ->
                        FilterChip(
                            selected = themeMode == key,
                            onClick = { themeMode = key },
                            label = { Text(label) }
                        )
                    }
                }
            }

            Button(
                onClick = {
                    val updated = cfg.copy(
                        shopName = shopName.trim().ifBlank { cfg.shopName },
                        shopAddress = address.trim(),
                        phone = phone.trim(),
                        email = email.trim(),
                        currencyCode = currency.code,
                        currencySymbol = currency.symbol,
                        taxEnabled = taxEnabled,
                        defaultTaxPercent = taxRate.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0,
                        taxInclusive = taxInclusive,
                        receiptHeader = receiptHeader.trim(),
                        receiptFooter = receiptFooter.trim(),
                        lowStockThreshold = lowStockThreshold.toIntOrNull()?.coerceAtLeast(0) ?: 5,
                        allowNegativeInventory = allowNegative,
                        themeMode = themeMode,
                        paymentRemindersEnabled = remindersEnabled
                    )
                    ReminderWorker.scheduleDailyReminder(context, remindersEnabled)
                    viewModel.saveShopConfig(updated) {
                        viewModel.emitMessage("Settings saved.")
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Save Settings", fontWeight = FontWeight.SemiBold)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpenBackup, modifier = Modifier.weight(1f)) { Text("Backup / Export") }
                OutlinedButton(onClick = { showPrivacyDialog = true }, modifier = Modifier.weight(1f)) { Text("Privacy Policy") }
            }
            OutlinedButton(onClick = { showAboutDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text("About Dukaan Saathi")
            }
        }
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy") },
            text = {
                Text(
                    "Dukaan Saathi is an offline-first shop management application. Your products, sales, customers, suppliers, and financial ledger are stored locally on your device using Android Room database.\n\n" +
                        "We do not upload your business or customer records to external servers. Camera permission is used solely for barcode scanning, and microphone permission is used solely for optional voice product entry.\n\n" +
                        "Google AdMob is used to display non-intrusive ads in non-checkout areas; AdMob may process standard advertising device identifiers according to Google's privacy policy."
                )
            },
            confirmButton = { TextButton(onClick = { showPrivacyDialog = false }) { Text("OK") } }
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("About Dukaan Saathi") },
            text = {
                Text("Dukaan Saathi – Smart Shop Manager\nVersion 1.0.0\nPackage: com.educationwithhassan.dukaansaathi\n\nBuilt for small retail shops, groceries, mini-markets, pharmacies (inventory), and local businesses worldwide.")
            },
            confirmButton = { TextButton(onClick = { showAboutDialog = false }) { Text("Close") } }
        )
    }
}
