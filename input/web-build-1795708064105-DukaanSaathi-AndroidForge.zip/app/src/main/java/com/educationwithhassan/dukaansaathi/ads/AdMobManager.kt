package com.educationwithhassan.dukaansaathi.ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.educationwithhassan.dukaansaathi.R
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Internal Ad Unit Registry using only the exact Dukaan Saathi AdMob IDs.
 * Never exposed to any user-facing screen.
 */
private object DukaanAdIds {
    const val BANNER = "ca-app-pub-3133971041724338/4228656986"
    const val INTERSTITIAL = "ca-app-pub-3133971041724338/7976330301"
    const val REWARDED = "ca-app-pub-3133971041724338/2724003629"
    const val NATIVE = "ca-app-pub-3133971041724338/6990551699"
    const val APP_OPEN = "ca-app-pub-3133971041724338/5158595277"
}

/**
 * Shared full-screen ad coordinator preventing back-to-back or overlapping
 * Interstitial, Rewarded, and App Open ads.
 */
internal class FullScreenAdCoordinator {
    var isShowingAnyFullScreenAd: Boolean = false
    var lastFullScreenAdClosedAtMs: Long = 0L

    fun canShowAutoFullScreenAd(minGapMs: Long): Boolean {
        if (isShowingAnyFullScreenAd) return false
        val elapsed = System.currentTimeMillis() - lastFullScreenAdClosedAtMs
        return elapsed >= minGapMs
    }
}

/**
 * Reusable Interstitial Ad manager with preload, 120s cooldown,
 * exponential retry backoff, and non-blocking navigation callbacks.
 */
class InterstitialAdManager internal constructor(
    private val context: Context,
    private val scope: CoroutineScope,
    private val coordinator: FullScreenAdCoordinator
) {
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var retryAttempt = 0
    private var lastShownAtMs = 0L

    fun preload() {
        if (isLoading || interstitialAd != null) return
        isLoading = true
        InterstitialAd.load(
            context,
            DukaanAdIds.INTERSTITIAL,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                    retryAttempt = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isLoading = false
                    if (retryAttempt < 3) {
                        retryAttempt++
                        val backoffMs = 8_000L * retryAttempt
                        scope.launch {
                            delay(backoffMs)
                            preload()
                        }
                    }
                }
            }
        )
    }

    fun showAtNaturalBreak(activity: Activity, onProceed: () -> Unit) {
        val now = System.currentTimeMillis()
        val interstitialCooldownPassed = (now - lastShownAtMs) >= 120_000L
        val globalGapPassed = coordinator.canShowAutoFullScreenAd(minGapMs = 60_000L)
        val ad = interstitialAd

        if (!interstitialCooldownPassed || !globalGapPassed || ad == null) {
            if (ad == null) preload()
            onProceed()
            return
        }

        var proceeded = false
        fun proceedOnce() {
            if (!proceeded) {
                proceeded = true
                onProceed()
            }
        }

        coordinator.isShowingAnyFullScreenAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                coordinator.isShowingAnyFullScreenAd = false
                val closedAt = System.currentTimeMillis()
                lastShownAtMs = closedAt
                coordinator.lastFullScreenAdClosedAtMs = closedAt
                preload()
                proceedOnce()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitialAd = null
                coordinator.isShowingAnyFullScreenAd = false
                preload()
                proceedOnce()
            }
        }
        ad.show(activity)
    }
}

/**
 * Reusable Rewarded Ad manager granting optional rewards strictly inside
 * the official Google Mobile Ads SDK OnUserEarnedRewardListener callback.
 */
class RewardedAdManager internal constructor(
    private val context: Context,
    private val scope: CoroutineScope,
    private val coordinator: FullScreenAdCoordinator
) {
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false
    private var retryAttempt = 0

    fun isReady(): Boolean = rewardedAd != null

    fun preload() {
        if (isLoading || rewardedAd != null) return
        isLoading = true
        RewardedAd.load(
            context,
            DukaanAdIds.REWARDED,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isLoading = false
                    retryAttempt = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    isLoading = false
                    if (retryAttempt < 3) {
                        retryAttempt++
                        val backoffMs = 8_000L * retryAttempt
                        scope.launch {
                            delay(backoffMs)
                            preload()
                        }
                    }
                }
            }
        )
    }

    fun showOptInRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onClosedWithoutReward: () -> Unit,
        onUnavailable: () -> Unit
    ) {
        if (coordinator.isShowingAnyFullScreenAd) {
            onUnavailable()
            return
        }
        val ad = rewardedAd
        if (ad == null) {
            preload()
            onUnavailable()
            return
        }

        var rewardGranted = false
        coordinator.isShowingAnyFullScreenAd = true

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                coordinator.isShowingAnyFullScreenAd = false
                coordinator.lastFullScreenAdClosedAtMs = System.currentTimeMillis()
                preload()
                if (!rewardGranted) {
                    onClosedWithoutReward()
                }
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewardedAd = null
                coordinator.isShowingAnyFullScreenAd = false
                preload()
                onUnavailable()
            }
        }

        ad.show(activity) {
            // Reward granted ONLY when official SDK confirms completion
            rewardGranted = true
            onRewardEarned()
        }
    }
}

/**
 * Lifecycle-aware App Open Ad manager respecting 4-hour freshness,
 * 4-minute cooldown, and global full-screen gap rules.
 */
class AppOpenAdManager internal constructor(
    private val context: Context,
    private val scope: CoroutineScope,
    private val coordinator: FullScreenAdCoordinator
) {
    private var appOpenAd: AppOpenAd? = null
    private var isLoading = false
    private var loadedAtMs = 0L
    private var lastShownAtMs = 0L
    private var retryAttempt = 0

    fun preload() {
        if (isLoading || isFreshAdAvailable()) return
        isLoading = true
        AppOpenAd.load(
            context,
            DukaanAdIds.APP_OPEN,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    loadedAtMs = System.currentTimeMillis()
                    isLoading = false
                    retryAttempt = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenAd = null
                    isLoading = false
                    if (retryAttempt < 2) {
                        retryAttempt++
                        scope.launch {
                            delay(10_000L * retryAttempt)
                            preload()
                        }
                    }
                }
            }
        )
    }

    private fun isFreshAdAvailable(): Boolean {
        if (appOpenAd == null) return false
        val fourHoursMs = 4L * 60 * 60 * 1000
        return (System.currentTimeMillis() - loadedAtMs) < fourHoursMs
    }

    fun showIfEligible(activity: Activity) {
        val now = System.currentTimeMillis()
        if ((now - lastShownAtMs) < 240_000L) return
        if (!coordinator.canShowAutoFullScreenAd(minGapMs = 60_000L)) return
        if (!isFreshAdAvailable()) {
            preload()
            return
        }

        val ad = appOpenAd ?: return
        coordinator.isShowingAnyFullScreenAd = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                coordinator.isShowingAnyFullScreenAd = false
                val closedAt = System.currentTimeMillis()
                lastShownAtMs = closedAt
                coordinator.lastFullScreenAdClosedAtMs = closedAt
                preload()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                appOpenAd = null
                coordinator.isShowingAnyFullScreenAd = false
                preload()
            }
        }
        ad.show(activity)
    }
}

/**
 * Centralized Google Mobile Ads coordinator for Dukaan Saathi.
 */
class AdMobManager(private val application: Application) : DefaultLifecycleObserver {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val coordinator = FullScreenAdCoordinator()

    val interstitialManager = InterstitialAdManager(application, scope, coordinator)
    val rewardedManager = RewardedAdManager(application, scope, coordinator)
    val appOpenManager = AppOpenAdManager(application, scope, coordinator)

    private var currentActivity: Activity? = null
    private var isInitialized = false
    @Volatile
    private var sensitiveFlowActive = false

    fun initialize() {
        if (isInitialized) return
        isInitialized = true
        MobileAds.initialize(application) {
            interstitialManager.preload()
            rewardedManager.preload()
            appOpenManager.preload()
        }
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    fun attachActivity(activity: Activity) {
        currentActivity = activity
    }

    fun detachActivity(activity: Activity) {
        if (currentActivity === activity) {
            currentActivity = null
        }
    }

    fun setSensitiveFlowActive(active: Boolean) {
        sensitiveFlowActive = active
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        if (sensitiveFlowActive) return
        val activity = currentActivity ?: return
        appOpenManager.showIfEligible(activity)
    }

    fun showInterstitialAtNaturalBreak(activity: Activity, onProceed: () -> Unit) {
        if (sensitiveFlowActive) {
            onProceed()
            return
        }
        interstitialManager.showAtNaturalBreak(activity, onProceed)
    }

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onClosedWithoutReward: () -> Unit = {},
        onUnavailable: () -> Unit
    ) {
        rewardedManager.showOptInRewardedAd(
            activity = activity,
            onRewardEarned = onRewardEarned,
            onClosedWithoutReward = onClosedWithoutReward,
            onUnavailable = onUnavailable
        )
    }
}

/**
 * Shared reusable Adaptive Banner Ad composable.
 * Handles adaptive sizing, loading, failure retry, and clean disposal.
 * Collapses cleanly when no ad is loaded so layout is never obstructed.
 */
@Composable
fun BannerAd(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val adWidthDp = configuration.screenWidthDp.coerceAtLeast(320)
    val scope = rememberCoroutineScope()

    var isAdLoaded by remember { mutableStateOf(false) }
    var adViewRef by remember { mutableStateOf<AdView?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            adViewRef?.destroy()
            adViewRef = null
        }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    val adaptiveSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(ctx, adWidthDp)
                    var retryCount = 0
                    AdView(ctx).apply {
                        setAdSize(adaptiveSize)
                        adUnitId = DukaanAdIds.BANNER
                        visibility = View.GONE
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                isAdLoaded = true
                                visibility = View.VISIBLE
                                retryCount = 0
                            }

                            override fun onAdFailedToLoad(error: LoadAdError) {
                                isAdLoaded = false
                                visibility = View.GONE
                                if (retryCount < 2) {
                                    retryCount++
                                    scope.launch {
                                        delay(15_000L * retryCount)
                                        loadAd(AdRequest.Builder().build())
                                    }
                                }
                            }
                        }
                        loadAd(AdRequest.Builder().build())
                        adViewRef = this
                    }
                },
                update = { view ->
                    view.visibility = if (isAdLoaded) View.VISIBLE else View.GONE
                }
            )
        }
    }
}

/**
 * Reusable Native Ad card with mandatory explicit "Ad" attribution badge,
 * non-blocking load/no-fill handling, and proper lifecycle disposal.
 */
@Composable
fun NativeAdCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loadedNativeAd by remember { mutableStateOf<NativeAd?>(null) }

    val headlineColor = MaterialTheme.colorScheme.onSurface.toArgb()
    val bodyColor = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()

    DisposableEffect(Unit) {
        var disposed = false
        var retried = false

        fun loadNative() {
            if (disposed) return
            val loader = AdLoader.Builder(context, DukaanAdIds.NATIVE)
                .forNativeAd { ad ->
                    if (disposed) {
                        ad.destroy()
                    } else {
                        loadedNativeAd?.destroy()
                        loadedNativeAd = ad
                    }
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        if (!disposed && !retried) {
                            retried = true
                            scope.launch {
                                delay(12_000L)
                                loadNative()
                            }
                        }
                    }
                })
                .withNativeAdOptions(NativeAdOptions.Builder().build())
                .build()
            loader.loadAd(AdRequest.Builder().build())
        }

        loadNative()

        onDispose {
            disposed = true
            loadedNativeAd?.destroy()
            loadedNativeAd = null
        }
    }

    val currentAd = loadedNativeAd ?: return

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(2.dp),
            factory = { ctx ->
                LayoutInflater.from(ctx).inflate(R.layout.native_ad_layout, null) as NativeAdView
            },
            update = { adView ->
                val headline = adView.findViewById<TextView>(R.id.ad_headline)
                val body = adView.findViewById<TextView>(R.id.ad_body)
                val cta = adView.findViewById<Button>(R.id.ad_call_to_action)
                val icon = adView.findViewById<ImageView>(R.id.ad_app_icon)
                val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)

                headline.setTextColor(headlineColor)
                body.setTextColor(bodyColor)
                advertiser.setTextColor(bodyColor)

                headline.text = currentAd.headline ?: ""
                body.text = currentAd.body ?: ""
                cta.text = currentAd.callToAction ?: "Learn More"
                advertiser.text = currentAd.advertiser ?: "Sponsored"
                if (currentAd.icon != null) {
                    icon.visibility = View.VISIBLE
                    icon.setImageDrawable(currentAd.icon?.drawable)
                } else {
                    icon.visibility = View.GONE
                }

                adView.headlineView = headline
                adView.bodyView = body
                adView.callToActionView = cta
                adView.iconView = icon
                adView.advertiserView = advertiser
                adView.setNativeAd(currentAd)
            }
        )
    }
}
