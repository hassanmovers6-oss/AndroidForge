package com.educationwithhassan.dukaansaathi.data.repository

import androidx.room.withTransaction
import com.educationwithhassan.dukaansaathi.data.local.DukaanDatabase
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerPaymentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ExpenseEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ProductEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseOrderEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.StockAdjustmentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierPaymentEntity
import com.educationwithhassan.dukaansaathi.domain.AccountingCalculator
import com.educationwithhassan.dukaansaathi.domain.CartLineInput
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

data class CompleteSaleRequest(
    val items: List<CartLineInput>,
    val orderDiscountAmount: Double,
    val customerId: Long?,
    val paymentMethod: String,
    val paidAmount: Double,
    val splitCashAmount: Double = 0.0,
    val splitCardAmount: Double = 0.0,
    val splitOtherAmount: Double = 0.0,
    val notes: String = ""
)

data class PurchaseLineRequest(
    val productId: Long,
    val quantity: Int,
    val unitCost: Double
)

class ShopRepository(val db: DukaanDatabase) {

    private val configDao = db.shopConfigDao()
    private val productDao = db.productDao()
    private val adjustmentDao = db.stockAdjustmentDao()
    private val customerDao = db.customerDao()
    private val saleDao = db.saleDao()
    private val customerPaymentDao = db.customerPaymentDao()
    private val expenseDao = db.expenseDao()
    private val supplierDao = db.supplierDao()
    private val purchaseDao = db.purchaseDao()

    val shopConfig: Flow<ShopConfigEntity> = configDao.observeConfig().map { it ?: ShopConfigEntity() }
    val products: Flow<List<ProductEntity>> = productDao.observeAllProducts()
    val lowStockProducts: Flow<List<ProductEntity>> = productDao.observeLowStockProducts()
    val recentStockAdjustments: Flow<List<StockAdjustmentEntity>> = adjustmentDao.observeRecentAdjustments()
    val customers: Flow<List<CustomerEntity>> = customerDao.observeAllCustomers()
    val customersWithCredit: Flow<List<CustomerEntity>> = customerDao.observeCustomersWithCredit()
    val sales: Flow<List<SaleEntity>> = saleDao.observeAllSales()
    val saleItems: Flow<List<SaleItemEntity>> = saleDao.observeAllSaleItems()
    val customerPayments: Flow<List<CustomerPaymentEntity>> = customerPaymentDao.observeAllPayments()
    val expenses: Flow<List<ExpenseEntity>> = expenseDao.observeAllExpenses()
    val suppliers: Flow<List<SupplierEntity>> = supplierDao.observeAllSuppliers()
    val purchases: Flow<List<PurchaseOrderEntity>> = purchaseDao.observeAllPurchases()
    val supplierPayments: Flow<List<SupplierPaymentEntity>> = purchaseDao.observeAllSupplierPayments()

    suspend fun getConfigOnce(): ShopConfigEntity = configDao.getConfigOnce() ?: ShopConfigEntity()

    suspend fun saveShopConfig(config: ShopConfigEntity) {
        configDao.upsertConfig(config)
    }

    suspend fun findProductByBarcode(barcode: String): ProductEntity? =
        productDao.getProductByBarcode(barcode.trim())

    fun observeAdjustmentsForProduct(productId: Long): Flow<List<StockAdjustmentEntity>> =
        adjustmentDao.observeForProduct(productId)

    fun observeSalesForCustomer(customerId: Long): Flow<List<SaleEntity>> =
        saleDao.observeSalesForCustomer(customerId)

    fun observePaymentsForCustomer(customerId: Long): Flow<List<CustomerPaymentEntity>> =
        customerPaymentDao.observePaymentsForCustomer(customerId)

    fun observePurchasesForSupplier(supplierId: Long): Flow<List<PurchaseOrderEntity>> =
        purchaseDao.observePurchasesForSupplier(supplierId)

    fun observePaymentsForSupplier(supplierId: Long): Flow<List<SupplierPaymentEntity>> =
        purchaseDao.observePaymentsForSupplier(supplierId)

    suspend fun getSaleWithItems(saleId: Long): Pair<SaleEntity, List<SaleItemEntity>>? {
        val sale = saleDao.getSaleById(saleId) ?: return null
        val items = saleDao.getItemsForSale(saleId)
        return sale to items
    }

    suspend fun saveProduct(product: ProductEntity, adjustmentReason: String = "Manual Update"): Long {
        return db.withTransaction {
            val now = System.currentTimeMillis()
            if (product.id == 0L) {
                val newId = productDao.insertProduct(product.copy(dateAdded = now, updatedAt = now))
                adjustmentDao.insert(
                    StockAdjustmentEntity(
                        productId = newId,
                        productName = product.name,
                        previousQty = 0,
                        newQty = product.quantity,
                        deltaQty = product.quantity,
                        reason = "Initial Stock",
                        createdAt = now
                    )
                )
                newId
            } else {
                val existing = productDao.getProductById(product.id)
                productDao.updateProduct(product.copy(updatedAt = now))
                if (existing != null && existing.quantity != product.quantity) {
                    adjustmentDao.insert(
                        StockAdjustmentEntity(
                            productId = product.id,
                            productName = product.name,
                            previousQty = existing.quantity,
                            newQty = product.quantity,
                            deltaQty = product.quantity - existing.quantity,
                            reason = adjustmentReason,
                            createdAt = now
                        )
                    )
                }
                product.id
            }
        }
    }

    suspend fun adjustProductStock(productId: Long, newQuantity: Int, reason: String): Result<Unit> =
        runCatching {
            val config = getConfigOnce()
            if (!config.allowNegativeInventory && newQuantity < 0) {
                error("Negative inventory is disabled in Settings.")
            }
            db.withTransaction {
                val product = productDao.getProductById(productId) ?: error("Product not found.")
                val now = System.currentTimeMillis()
                productDao.updateProduct(product.copy(quantity = newQuantity, updatedAt = now))
                adjustmentDao.insert(
                    StockAdjustmentEntity(
                        productId = product.id,
                        productName = product.name,
                        previousQty = product.quantity,
                        newQty = newQuantity,
                        deltaQty = newQuantity - product.quantity,
                        reason = reason,
                        createdAt = now
                    )
                )
            }
        }

    suspend fun deleteProduct(product: ProductEntity) {
        productDao.deleteProduct(product)
    }

    /**
     * Atomically completes a POS sale:
     * 1. Validates stock (prevents negative inventory unless explicitly allowed)
     * 2. Calculates tax (inclusive/exclusive), discount, COGS, and exact gross profit
     * 3. Saves SaleEntity & SaleItemEntity records
     * 4. Decrements product quantities & records StockAdjustmentEntity entries
     * 5. Updates customer totalPurchases & outstandingBalance if applicable
     * 6. Records CustomerPaymentEntity for paid portion
     */
    suspend fun completeSale(request: CompleteSaleRequest): Result<SaleEntity> = runCatching {
        require(request.items.isNotEmpty()) { "Cart cannot be empty." }

        val config = getConfigOnce()
        val summary = AccountingCalculator.calculateCart(
            items = request.items,
            orderDiscountAmount = request.orderDiscountAmount,
            taxEnabled = config.taxEnabled,
            defaultTaxPercent = config.defaultTaxPercent,
            taxInclusive = config.taxInclusive
        )

        val actualPaid = request.paidAmount.coerceIn(0.0, summary.grandTotal)
        val balanceDue = AccountingCalculator.calculateRemainingBalance(summary.grandTotal, actualPaid)

        if (balanceDue > 0.009 && request.customerId == null) {
            error("Please select a customer before completing a credit or partial-payment sale.")
        }

        db.withTransaction {
            val now = System.currentTimeMillis()

            // 1. Validate & decrement inventory
            for (line in summary.lines) {
                val product = productDao.getProductById(line.productId)
                    ?: error("Product '${line.productName}' no longer exists.")
                val nextQty = product.quantity - line.quantity
                if (!config.allowNegativeInventory && nextQty < 0) {
                    error("Insufficient stock for '${product.name}'. Available: ${product.quantity}, Requested: ${line.quantity}.")
                }
                productDao.updateProduct(product.copy(quantity = nextQty, updatedAt = now))
                adjustmentDao.insert(
                    StockAdjustmentEntity(
                        productId = product.id,
                        productName = product.name,
                        previousQty = product.quantity,
                        newQty = nextQty,
                        deltaQty = -line.quantity,
                        reason = "POS Sale",
                        createdAt = now
                    )
                )
            }

            // 2. Resolve customer
            val customer = request.customerId?.let { customerDao.getCustomerById(it) }
            val customerName = customer?.fullName ?: "Walk-in Customer"

            // 3. Save Sale header
            val invoiceNo = "INV-${SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))}-${(now % 1000).toString().padStart(3, '0')}"
            val sale = SaleEntity(
                invoiceNumber = invoiceNo,
                customerId = customer?.id,
                customerName = customerName,
                subtotal = summary.subtotalBeforeDiscount,
                discountAmount = summary.totalDiscount,
                taxAmount = summary.totalTax,
                grandTotal = summary.grandTotal,
                totalCost = summary.totalCost,
                grossProfit = summary.grossProfit,
                paidAmount = AccountingCalculator.roundMoney(actualPaid),
                balanceDue = balanceDue,
                paymentMethod = request.paymentMethod,
                splitCashAmount = AccountingCalculator.roundMoney(request.splitCashAmount),
                splitCardAmount = AccountingCalculator.roundMoney(request.splitCardAmount),
                splitOtherAmount = AccountingCalculator.roundMoney(request.splitOtherAmount),
                taxIncludedInPrice = config.taxInclusive && config.taxEnabled,
                currencyCode = config.currencyCode,
                notes = request.notes,
                createdAt = now
            )
            val saleId = saleDao.insertSale(sale)

            // 4. Save Sale Items
            val saleItemEntities = summary.lines.map { line ->
                SaleItemEntity(
                    saleId = saleId,
                    productId = line.productId,
                    productName = line.productName,
                    quantity = line.quantity,
                    unitPrice = line.unitPrice,
                    unitCost = line.unitCost,
                    discountAmount = line.discountAmount,
                    taxAmount = line.taxAmount,
                    lineTotal = line.lineTotal,
                    lineProfit = line.lineProfit
                )
            }
            saleDao.insertSaleItems(saleItemEntities)

            // 5. Update Customer balance & payment history
            if (customer != null) {
                val updatedCustomer = customer.copy(
                    totalPurchases = AccountingCalculator.roundMoney(customer.totalPurchases + summary.grandTotal),
                    outstandingBalance = AccountingCalculator.roundMoney(customer.outstandingBalance + balanceDue)
                )
                customerDao.updateCustomer(updatedCustomer)

                if (actualPaid > 0.009) {
                    customerPaymentDao.insertPayment(
                        CustomerPaymentEntity(
                            customerId = customer.id,
                            customerName = customer.fullName,
                            saleId = saleId,
                            amount = AccountingCalculator.roundMoney(actualPaid),
                            paymentMethod = request.paymentMethod,
                            notes = "Payment at checkout ($invoiceNo)",
                            createdAt = now
                        )
                    )
                }
            }

            sale.copy(id = saleId)
        }
    }

    suspend fun saveCustomer(customer: CustomerEntity): Long {
        return if (customer.id == 0L) {
            customerDao.insertCustomer(customer)
        } else {
            customerDao.updateCustomer(customer)
            customer.id
        }
    }

    suspend fun deleteCustomer(customer: CustomerEntity) {
        customerDao.deleteCustomer(customer)
    }

    /**
     * Records a full or partial Udhaar payment without erasing any historical sale or payment records.
     */
    suspend fun recordCustomerPayment(
        customerId: Long,
        amount: Double,
        paymentMethod: String,
        notes: String
    ): Result<Unit> = runCatching {
        require(amount > 0.0) { "Payment amount must be greater than zero." }
        db.withTransaction {
            val customer = customerDao.getCustomerById(customerId) ?: error("Customer not found.")
            val applied = minOf(amount, max(0.0, customer.outstandingBalance))
            require(applied > 0.0) { "Customer has no outstanding credit balance." }

            val newBalance = AccountingCalculator.roundMoney(max(0.0, customer.outstandingBalance - applied))
            customerDao.updateCustomer(customer.copy(outstandingBalance = newBalance))
            customerPaymentDao.insertPayment(
                CustomerPaymentEntity(
                    customerId = customer.id,
                    customerName = customer.fullName,
                    saleId = null,
                    amount = AccountingCalculator.roundMoney(applied),
                    paymentMethod = paymentMethod,
                    notes = notes.ifBlank { "Credit ledger payment" },
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun saveExpense(expense: ExpenseEntity): Long {
        return if (expense.id == 0L) {
            expenseDao.insertExpense(expense)
        } else {
            expenseDao.updateExpense(expense)
            expense.id
        }
    }

    suspend fun deleteExpense(expense: ExpenseEntity) {
        expenseDao.deleteExpense(expense)
    }

    suspend fun saveSupplier(supplier: SupplierEntity): Long {
        return if (supplier.id == 0L) {
            supplierDao.insertSupplier(supplier)
        } else {
            supplierDao.updateSupplier(supplier)
            supplier.id
        }
    }

    suspend fun deleteSupplier(supplier: SupplierEntity) {
        supplierDao.deleteSupplier(supplier)
    }

    /**
     * Atomically records a supplier stock purchase:
     * - Updates product stock & purchase cost
     * - Logs stock adjustment
     * - Saves PurchaseOrderEntity & PurchaseItemEntity
     * - Updates supplier totals & outstanding payable balance
     */
    suspend fun recordSupplierPurchase(
        supplierId: Long,
        invoiceRef: String,
        lines: List<PurchaseLineRequest>,
        paidAmount: Double,
        paymentMethod: String,
        notes: String
    ): Result<PurchaseOrderEntity> = runCatching {
        require(lines.isNotEmpty()) { "Add at least one product to record a purchase." }
        val total = AccountingCalculator.roundMoney(lines.sumOf { it.quantity * it.unitCost })
        val actualPaid = AccountingCalculator.roundMoney(paidAmount.coerceIn(0.0, total))
        val balanceDue = AccountingCalculator.calculateRemainingBalance(total, actualPaid)

        db.withTransaction {
            val now = System.currentTimeMillis()
            val supplier = supplierDao.getSupplierById(supplierId) ?: error("Supplier not found.")
            val ref = invoiceRef.ifBlank { "PO-${now % 100000}" }

            val po = PurchaseOrderEntity(
                supplierId = supplier.id,
                supplierName = supplier.name,
                invoiceRef = ref,
                totalAmount = total,
                paidAmount = actualPaid,
                balanceDue = balanceDue,
                notes = notes,
                createdAt = now
            )
            val poId = purchaseDao.insertPurchase(po)

            val itemEntities = mutableListOf<PurchaseItemEntity>()
            for (line in lines) {
                val product = productDao.getProductById(line.productId) ?: error("Product not found.")
                val newQty = product.quantity + line.quantity
                productDao.updateProduct(
                    product.copy(
                        quantity = newQty,
                        purchasePrice = line.unitCost,
                        supplierId = supplier.id,
                        supplierName = supplier.name,
                        updatedAt = now
                    )
                )
                adjustmentDao.insert(
                    StockAdjustmentEntity(
                        productId = product.id,
                        productName = product.name,
                        previousQty = product.quantity,
                        newQty = newQty,
                        deltaQty = line.quantity,
                        reason = "Supplier Purchase ($ref)",
                        referenceId = ref,
                        createdAt = now
                    )
                )
                itemEntities.add(
                    PurchaseItemEntity(
                        purchaseId = poId,
                        productId = product.id,
                        productName = product.name,
                        quantity = line.quantity,
                        unitCost = line.unitCost,
                        lineTotal = AccountingCalculator.roundMoney(line.quantity * line.unitCost)
                    )
                )
            }
            purchaseDao.insertPurchaseItems(itemEntities)

            supplierDao.updateSupplier(
                supplier.copy(
                    totalPurchased = AccountingCalculator.roundMoney(supplier.totalPurchased + total),
                    outstandingBalance = AccountingCalculator.roundMoney(supplier.outstandingBalance + balanceDue)
                )
            )

            if (actualPaid > 0.009) {
                purchaseDao.insertSupplierPayment(
                    SupplierPaymentEntity(
                        supplierId = supplier.id,
                        supplierName = supplier.name,
                        purchaseId = poId,
                        amount = actualPaid,
                        paymentMethod = paymentMethod,
                        notes = "Initial payment ($ref)",
                        createdAt = now
                    )
                )
            }

            po.copy(id = poId)
        }
    }

    suspend fun recordSupplierPayment(
        supplierId: Long,
        amount: Double,
        paymentMethod: String,
        notes: String
    ): Result<Unit> = runCatching {
        require(amount > 0.0) { "Payment amount must be greater than zero." }
        db.withTransaction {
            val supplier = supplierDao.getSupplierById(supplierId) ?: error("Supplier not found.")
            val applied = minOf(amount, max(0.0, supplier.outstandingBalance))
            require(applied > 0.0) { "Supplier has no outstanding balance." }

            supplierDao.updateSupplier(
                supplier.copy(
                    outstandingBalance = AccountingCalculator.roundMoney(supplier.outstandingBalance - applied)
                )
            )
            purchaseDao.insertSupplierPayment(
                SupplierPaymentEntity(
                    supplierId = supplier.id,
                    supplierName = supplier.name,
                    purchaseId = null,
                    amount = AccountingCalculator.roundMoney(applied),
                    paymentMethod = paymentMethod,
                    notes = notes.ifBlank { "Supplier ledger payment" },
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }
}
