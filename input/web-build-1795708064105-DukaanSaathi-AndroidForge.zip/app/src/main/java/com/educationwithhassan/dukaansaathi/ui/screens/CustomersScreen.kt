package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.components.formatTimestamp
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.theme.EmeraldSuccess
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel
import com.educationwithhassan.dukaansaathi.util.PdfReceiptGenerator

@Composable
fun CustomersScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    openAddInitially: Boolean = false,
    onConsumeOpenAdd: () -> Unit = {}
) {
    var search by remember { mutableStateOf("") }
    var onlyWithCredit by remember { mutableStateOf(false) }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var showForm by remember(openAddInitially) { mutableStateOf(openAddInitially) }
    var detailCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<CustomerEntity?>(null) }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val filtered = remember(state.customers, search, onlyWithCredit) {
        state.customers.filter { c ->
            val matchText = search.isBlank() ||
                c.fullName.contains(search, ignoreCase = true) ||
                c.phone.contains(search, ignoreCase = true)
            val matchCredit = !onlyWithCredit || c.outstandingBalance > 0.009
            matchText && matchCredit
        }
    }

    val totalOutstanding = state.customers.sumOf { it.outstandingBalance }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editingCustomer = null; showForm = true },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Customer")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column {
                Text("Customers & Credit Ledger", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "${state.customers.size} customers · Total Udhaar Due: ${fmt(totalOutstanding)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (totalOutstanding > 0.0) CrimsonError else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Search customer name or phone...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !onlyWithCredit,
                    onClick = { onlyWithCredit = false },
                    label = { Text("All Customers") }
                )
                FilterChip(
                    selected = onlyWithCredit,
                    onClick = { onlyWithCredit = true },
                    label = { Text("Credit Due (${state.customers.count { it.outstandingBalance > 0.009 }})") }
                )
            }

            if (filtered.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.People,
                    title = if (state.customers.isEmpty()) "No customers added yet" else "No matching customers",
                    description = "Add customers to track purchase history, Udhaar credit balances, and share account statements.",
                    actionLabel = if (state.customers.isEmpty()) "Add Customer" else null,
                    onAction = if (state.customers.isEmpty()) {
                        { editingCustomer = null; showForm = true }
                    } else null
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(filtered, key = { it.id }) { customer ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { detailCustomer = customer }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(customer.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        customer.phone.ifBlank { "No phone number" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        "Purchases: ${fmt(customer.totalPurchases)}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = fmt(customer.outstandingBalance),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (customer.outstandingBalance > 0.009) CrimsonError else EmeraldSuccess
                                    )
                                    Text(
                                        text = if (customer.outstandingBalance > 0.009) "Credit Due" else "Settled",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (customer.outstandingBalance > 0.009) CrimsonError else EmeraldSuccess
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        CustomerFormDialog(
            initial = editingCustomer,
            onDismiss = {
                showForm = false
                onConsumeOpenAdd()
            },
            onSave = { cust ->
                viewModel.saveCustomer(cust) {
                    showForm = false
                    onConsumeOpenAdd()
                }
            }
        )
    }

    detailCustomer?.let { selected ->
        val freshCustomer = state.customers.firstOrNull { it.id == selected.id } ?: selected
        CustomerLedgerDialog(
            customer = freshCustomer,
            state = state,
            viewModel = viewModel,
            onEdit = {
                detailCustomer = null
                editingCustomer = freshCustomer
                showForm = true
            },
            onDelete = {
                detailCustomer = null
                deleteCandidate = freshCustomer
            },
            onDismiss = { detailCustomer = null }
        )
    }

    deleteCandidate?.let { cust ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete Customer?") },
            text = { Text("Delete '${cust.fullName}'? Historical invoices will remain intact.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(cust)
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CustomerFormDialog(
    initial: CustomerEntity?,
    onDismiss: () -> Unit,
    onSave: (CustomerEntity) -> Unit
) {
    var fullName by remember { mutableStateOf(initial?.fullName.orEmpty()) }
    var phone by remember { mutableStateOf(initial?.phone.orEmpty()) }
    var email by remember { mutableStateOf(initial?.email.orEmpty()) }
    var address by remember { mutableStateOf(initial?.address.orEmpty()) }
    var notes by remember { mutableStateOf(initial?.notes.orEmpty()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Customer" else "Edit Customer") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it; errorMsg = null },
                    label = { Text("Full Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonError)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = fullName.trim()
                    if (trimmed.isEmpty()) {
                        errorMsg = "Customer name is required."
                        return@Button
                    }
                    onSave(
                        CustomerEntity(
                            id = initial?.id ?: 0L,
                            fullName = trimmed,
                            phone = phone.trim(),
                            email = email.trim(),
                            address = address.trim(),
                            notes = notes.trim(),
                            totalPurchases = initial?.totalPurchases ?: 0.0,
                            outstandingBalance = initial?.outstandingBalance ?: 0.0,
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun CustomerLedgerDialog(
    customer: CustomerEntity,
    state: ShopUiState,
    viewModel: ShopViewModel,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sales by viewModel.observeSalesForCustomer(customer.id).collectAsState(initial = emptyList())
    val payments by viewModel.observePaymentsForCustomer(customer.id).collectAsState(initial = emptyList())

    var paymentAmount by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var paymentNotes by remember { mutableStateOf("") }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(customer.fullName, modifier = Modifier.weight(1f))
                Row {
                    IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonError) }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SectionCard {
                    Text("Phone: ${customer.phone.ifBlank { "-" }}")
                    Text("Email: ${customer.email.ifBlank { "-" }}")
                    Text("Total Purchases: ${fmt(customer.totalPurchases)}")
                    Text(
                        "Outstanding Udhaar Balance: ${fmt(customer.outstandingBalance)}",
                        fontWeight = FontWeight.Bold,
                        color = if (customer.outstandingBalance > 0.009) CrimsonError else EmeraldSuccess
                    )
                }

                if (customer.outstandingBalance > 0.009) {
                    Text("Record Credit Payment (Partial or Full)", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = paymentAmount,
                        onValueChange = { paymentAmount = it },
                        label = { Text("Amount Received (${cfg.currencySymbol.trim()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Cash", "Card", "Other").forEach { m ->
                            FilterChip(
                                selected = paymentMethod == m,
                                onClick = { paymentMethod = m },
                                label = { Text(m) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = paymentNotes,
                        onValueChange = { paymentNotes = it },
                        label = { Text("Notes (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { paymentAmount = String.format("%.2f", customer.outstandingBalance) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Full Balance") }
                        Button(
                            onClick = {
                                val amt = paymentAmount.toDoubleOrNull() ?: return@Button
                                viewModel.recordCustomerPayment(customer.id, amt, paymentMethod, paymentNotes)
                                paymentAmount = ""
                                paymentNotes = ""
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) { Text("Save Payment") }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val file = PdfReceiptGenerator.generateCustomerStatementPdf(context, cfg, customer, sales, payments)
                            PdfReceiptGenerator.printPdfFile(context, file, "Statement ${customer.fullName}")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = "Print")
                        Spacer(Modifier.width(4.dp))
                        Text("Print")
                    }
                    OutlinedButton(
                        onClick = {
                            val file = PdfReceiptGenerator.generateCustomerStatementPdf(context, cfg, customer, sales, payments)
                            PdfReceiptGenerator.sharePdfFile(context, file, "Customer Statement - ${customer.fullName}")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share")
                        Spacer(Modifier.width(4.dp))
                        Text("Statement")
                    }
                }

                Text("Ledger History (${sales.size} Sales · ${payments.size} Payments)", fontWeight = FontWeight.SemiBold)
                val combined = buildList {
                    sales.forEach { add(Triple(it.createdAt, "Sale ${it.invoiceNumber} (${it.paymentMethod})", "Total ${fmt(it.grandTotal)} · Due ${fmt(it.balanceDue)}")) }
                    payments.forEach { add(Triple(it.createdAt, "Payment (${it.paymentMethod})", "Paid ${fmt(it.amount)}")) }
                }.sortedByDescending { it.first }

                if (combined.isEmpty()) {
                    Text("No ledger activity yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    combined.take(20).forEach { (ts, title, rightText) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(formatTimestamp(ts), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(rightText, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
