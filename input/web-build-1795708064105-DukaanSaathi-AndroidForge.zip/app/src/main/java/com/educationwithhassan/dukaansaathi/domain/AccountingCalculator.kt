package com.educationwithhassan.dukaansaathi.domain

import kotlin.math.max
import kotlin.math.roundToLong

data class CartLineInput(
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double,
    val lineDiscount: Double = 0.0,
    val taxPercentOverride: Double? = null
)

data class CalculatedLineResult(
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double,
    val grossPriceBeforeDiscount: Double,
    val discountAmount: Double,
    val netRevenueExclTax: Double,
    val taxAmount: Double,
    val lineTotal: Double,
    val lineCost: Double,
    val lineProfit: Double
)

data class CartCalculationSummary(
    val lines: List<CalculatedLineResult>,
    val subtotalBeforeDiscount: Double,
    val totalDiscount: Double,
    val netSalesExclTax: Double,
    val totalTax: Double,
    val grandTotal: Double,
    val totalCost: Double,
    val grossProfit: Double
)

object AccountingCalculator {

    fun roundMoney(value: Double): Double {
        return (value * 100.0).roundToLong() / 100.0
    }

    /**
     * Computes exact POS totals, tax, COGS, and profit.
     *
     * Accounting rules:
     * - Revenue (netSalesExclTax) = completed sales after discounts, excluding collected tax.
     * - Gross profit = netSalesExclTax - totalCostOfGoodsSold.
     * - Inclusive tax extracts tax from the discounted shelf price so collected tax never inflates profit.
     * - Exclusive tax adds tax on top of the discounted net price.
     */
    fun calculateCart(
        items: List<CartLineInput>,
        orderDiscountAmount: Double,
        taxEnabled: Boolean,
        defaultTaxPercent: Double,
        taxInclusive: Boolean
    ): CartCalculationSummary {
        if (items.isEmpty()) {
            return CartCalculationSummary(
                lines = emptyList(),
                subtotalBeforeDiscount = 0.0,
                totalDiscount = 0.0,
                netSalesExclTax = 0.0,
                totalTax = 0.0,
                grandTotal = 0.0,
                totalCost = 0.0,
                grossProfit = 0.0
            )
        }

        val grossLines = items.map { max(0.0, it.unitPrice * it.quantity) }
        val totalGrossBeforeDiscounts = grossLines.sum()
        val lineDiscountsSum = items.sumOf { max(0.0, it.lineDiscount) }
        val baseAfterLineDiscounts = max(0.0, totalGrossBeforeDiscounts - lineDiscountsSum)
        val clampedOrderDiscount = max(0.0, minOf(orderDiscountAmount, baseAfterLineDiscounts))

        val calculatedLines = items.mapIndexed { index, item ->
            val grossLine = grossLines[index]
            val afterLineDisc = max(0.0, grossLine - max(0.0, item.lineDiscount))

            // Pro-rate order-level discount proportionally across lines so per-item tax & profit remain exact
            val orderShare = if (baseAfterLineDiscounts > 0.0) {
                clampedOrderDiscount * (afterLineDisc / baseAfterLineDiscounts)
            } else {
                0.0
            }

            val totalLineDiscount = roundMoney(max(0.0, item.lineDiscount) + orderShare)
            val effectiveShelfAfterDiscount = max(0.0, grossLine - totalLineDiscount)
            val rate = if (taxEnabled) max(0.0, item.taxPercentOverride ?: defaultTaxPercent) else 0.0

            val netExclTax: Double
            val taxAmount: Double
            val lineTotal: Double

            if (rate > 0.0) {
                if (taxInclusive) {
                    netExclTax = roundMoney(effectiveShelfAfterDiscount / (1.0 + rate / 100.0))
                    taxAmount = roundMoney(effectiveShelfAfterDiscount - netExclTax)
                    lineTotal = roundMoney(effectiveShelfAfterDiscount)
                } else {
                    netExclTax = roundMoney(effectiveShelfAfterDiscount)
                    taxAmount = roundMoney(netExclTax * (rate / 100.0))
                    lineTotal = roundMoney(netExclTax + taxAmount)
                }
            } else {
                netExclTax = roundMoney(effectiveShelfAfterDiscount)
                taxAmount = 0.0
                lineTotal = netExclTax
            }

            val lineCost = roundMoney(max(0.0, item.unitCost) * item.quantity)
            val lineProfit = roundMoney(netExclTax - lineCost)

            CalculatedLineResult(
                productId = item.productId,
                productName = item.productName,
                quantity = item.quantity,
                unitPrice = item.unitPrice,
                unitCost = item.unitCost,
                grossPriceBeforeDiscount = roundMoney(grossLine),
                discountAmount = totalLineDiscount,
                netRevenueExclTax = netExclTax,
                taxAmount = taxAmount,
                lineTotal = lineTotal,
                lineCost = lineCost,
                lineProfit = lineProfit
            )
        }

        val subtotal = roundMoney(totalGrossBeforeDiscounts)
        val totalDiscount = roundMoney(lineDiscountsSum + clampedOrderDiscount)
        val netSalesExclTax = roundMoney(calculatedLines.sumOf { it.netRevenueExclTax })
        val totalTax = roundMoney(calculatedLines.sumOf { it.taxAmount })
        val grandTotal = roundMoney(calculatedLines.sumOf { it.lineTotal })
        val totalCost = roundMoney(calculatedLines.sumOf { it.lineCost })
        val grossProfit = roundMoney(netSalesExclTax - totalCost)

        return CartCalculationSummary(
            lines = calculatedLines,
            subtotalBeforeDiscount = subtotal,
            totalDiscount = totalDiscount,
            netSalesExclTax = netSalesExclTax,
            totalTax = totalTax,
            grandTotal = grandTotal,
            totalCost = totalCost,
            grossProfit = grossProfit
        )
    }

    fun calculateNetProfit(grossProfit: Double, totalOperatingExpenses: Double): Double {
        return roundMoney(grossProfit - totalOperatingExpenses)
    }

    fun calculateRemainingBalance(grandTotal: Double, paidAmount: Double): Double {
        return roundMoney(max(0.0, grandTotal - max(0.0, paidAmount)))
    }
}
