package com.educationwithhassan.dukaansaathi.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.educationwithhassan.dukaansaathi.data.local.dao.CustomerDao
import com.educationwithhassan.dukaansaathi.data.local.dao.CustomerPaymentDao
import com.educationwithhassan.dukaansaathi.data.local.dao.ExpenseDao
import com.educationwithhassan.dukaansaathi.data.local.dao.ProductDao
import com.educationwithhassan.dukaansaathi.data.local.dao.PurchaseDao
import com.educationwithhassan.dukaansaathi.data.local.dao.SaleDao
import com.educationwithhassan.dukaansaathi.data.local.dao.ShopConfigDao
import com.educationwithhassan.dukaansaathi.data.local.dao.StockAdjustmentDao
import com.educationwithhassan.dukaansaathi.data.local.dao.SupplierDao
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerPaymentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ExpenseEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ProductEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseOrderEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.StockAdjustmentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierPaymentEntity

@Database(
    entities = [
        ShopConfigEntity::class,
        ProductEntity::class,
        StockAdjustmentEntity::class,
        CustomerEntity::class,
        SaleEntity::class,
        SaleItemEntity::class,
        CustomerPaymentEntity::class,
        ExpenseEntity::class,
        SupplierEntity::class,
        PurchaseOrderEntity::class,
        PurchaseItemEntity::class,
        SupplierPaymentEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class DukaanDatabase : RoomDatabase() {
    abstract fun shopConfigDao(): ShopConfigDao
    abstract fun productDao(): ProductDao
    abstract fun stockAdjustmentDao(): StockAdjustmentDao
    abstract fun customerDao(): CustomerDao
    abstract fun saleDao(): SaleDao
    abstract fun customerPaymentDao(): CustomerPaymentDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun supplierDao(): SupplierDao
    abstract fun purchaseDao(): PurchaseDao

    companion object {
        const val DATABASE_NAME = "dukaan_saathi.db"

        /**
         * Explicit non-destructive migration path from v1 to v2.
         * Never use fallbackToDestructiveMigration() in production business software.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE shop_config ADD COLUMN analyticsPackUnlockedUntilMs INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        @Volatile
        private var INSTANCE: DukaanDatabase? = null

        fun getInstance(context: Context): DukaanDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DukaanDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
