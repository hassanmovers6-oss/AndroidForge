package com.educationwithhassan.dukaansaathi.util

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.educationwithhassan.dukaansaathi.data.local.DukaanDatabase
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerPaymentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ExpenseEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ProductEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseOrderEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.StockAdjustmentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierPaymentEntity
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class BackupMetadata(
    val appId: String = "com.educationwithhassan.dukaansaathi",
    val schemaVersion: Int = 2,
    val exportedAt: Long = System.currentTimeMillis(),
    val recordCount: Int = 0,
    val checksumSha256: String = ""
)

data class BackupPayload(
    val metadata: BackupMetadata,
    val shopConfig: ShopConfigEntity?,
    val products: List<ProductEntity>,
    val stockAdjustments: List<StockAdjustmentEntity>,
    val customers: List<CustomerEntity>,
    val sales: List<SaleEntity>,
    val saleItems: List<SaleItemEntity>,
    val customerPayments: List<CustomerPaymentEntity>,
    val expenses: List<ExpenseEntity>,
    val suppliers: List<SupplierEntity>,
    val purchaseOrders: List<PurchaseOrderEntity>,
    val purchaseItems: List<PurchaseItemEntity>,
    val supplierPayments: List<SupplierPaymentEntity>
)

object BackupManager {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    suspend fun exportToUri(context: Context, db: DukaanDatabase, uri: Uri): Result<Int> =
        withContext(Dispatchers.IO) {
            runCatching {
                val config = db.shopConfigDao().getConfigOnce()
                val products = db.productDao().getAllProductsOnce()
                val adjustments = db.stockAdjustmentDao().getAllOnce()
                val customers = db.customerDao().getAllCustomersOnce()
                val sales = db.saleDao().getAllSalesOnce()
                val saleItems = db.saleDao().getAllSaleItemsOnce()
                val custPayments = db.customerPaymentDao().getAllPaymentsOnce()
                val expenses = db.expenseDao().getAllExpensesOnce()
                val suppliers = db.supplierDao().getAllSuppliersOnce()
                val purchases = db.purchaseDao().getAllPurchasesOnce()
                val purchaseItems = db.purchaseDao().getAllPurchaseItemsOnce()
                val suppPayments = db.purchaseDao().getAllSupplierPaymentsOnce()

                val count = products.size + customers.size + sales.size + expenses.size + suppliers.size
                val digestSource = "${products.size}:${customers.size}:${sales.size}:${expenses.size}:${suppliers.size}:${config?.shopName.orEmpty()}"
                val checksum = sha256(digestSource)

                val payload = BackupPayload(
                    metadata = BackupMetadata(
                        recordCount = count,
                        checksumSha256 = checksum
                    ),
                    shopConfig = config,
                    products = products,
                    stockAdjustments = adjustments,
                    customers = customers,
                    sales = sales,
                    saleItems = saleItems,
                    customerPayments = custPayments,
                    expenses = expenses,
                    suppliers = suppliers,
                    purchaseOrders = purchases,
                    purchaseItems = purchaseItems,
                    supplierPayments = suppPayments
                )

                val json = gson.toJson(payload)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                } ?: error("Unable to open destination file.")

                count
            }
        }

    suspend fun validateBackupUri(context: Context, uri: Uri): Result<BackupPayload> =
        withContext(Dispatchers.IO) {
            runCatching {
                val json = context.contentResolver.openInputStream(uri)?.use { input ->
                    input.bufferedReader(Charsets.UTF_8).readText()
                } ?: error("Unable to read backup file.")

                val payload = gson.fromJson(json, BackupPayload::class.java)
                    ?: error("Invalid backup JSON format.")

                require(payload.metadata.appId == "com.educationwithhassan.dukaansaathi") {
                    "This file is not a valid Dukaan Saathi backup."
                }
                require(payload.metadata.schemaVersion in 1..2) {
                    "Unsupported backup schema version: ${payload.metadata.schemaVersion}"
                }
                val digestSource = "${payload.products.size}:${payload.customers.size}:${payload.sales.size}:${payload.expenses.size}:${payload.suppliers.size}:${payload.shopConfig?.shopName.orEmpty()}"
                val expectedChecksum = sha256(digestSource)
                require(payload.metadata.checksumSha256 == expectedChecksum) {
                    "Backup checksum verification failed. File may be corrupted or modified."
                }
                payload
            }
        }

    suspend fun restorePayload(db: DukaanDatabase, payload: BackupPayload): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                db.withTransaction {
                    db.saleDao().clearSaleItems()
                    db.saleDao().clearSales()
                    db.customerPaymentDao().clearAll()
                    db.purchaseDao().clearPurchaseItems()
                    db.purchaseDao().clearPurchases()
                    db.purchaseDao().clearSupplierPayments()
                    db.stockAdjustmentDao().clearAll()
                    db.productDao().clearAll()
                    db.customerDao().clearAll()
                    db.expenseDao().clearAll()
                    db.supplierDao().clearAll()

                    payload.shopConfig?.let { db.shopConfigDao().upsertConfig(it.copy(setupCompleted = true)) }
                    if (payload.products.isNotEmpty()) db.productDao().insertProducts(payload.products)
                    if (payload.stockAdjustments.isNotEmpty()) db.stockAdjustmentDao().insertAll(payload.stockAdjustments)
                    if (payload.customers.isNotEmpty()) db.customerDao().insertCustomers(payload.customers)
                    if (payload.sales.isNotEmpty()) db.saleDao().insertSales(payload.sales)
                    if (payload.saleItems.isNotEmpty()) db.saleDao().insertSaleItems(payload.saleItems)
                    if (payload.customerPayments.isNotEmpty()) db.customerPaymentDao().insertPayments(payload.customerPayments)
                    if (payload.expenses.isNotEmpty()) db.expenseDao().insertExpenses(payload.expenses)
                    if (payload.suppliers.isNotEmpty()) db.supplierDao().insertSuppliers(payload.suppliers)
                    if (payload.purchaseOrders.isNotEmpty()) db.purchaseDao().insertPurchases(payload.purchaseOrders)
                    if (payload.purchaseItems.isNotEmpty()) db.purchaseDao().insertPurchaseItems(payload.purchaseItems)
                    if (payload.supplierPayments.isNotEmpty()) db.purchaseDao().insertSupplierPayments(payload.supplierPayments)
                }
            }
        }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
