package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    initialConfig: ShopConfigEntity,
    onCompleteSetup: (ShopConfigEntity) -> Unit
) {
    var shopName by remember { mutableStateOf(if (initialConfig.shopName == "My Shop") "" else initialConfig.shopName) }
    var shopAddress by remember { mutableStateOf(initialConfig.shopAddress) }
    var phone by remember { mutableStateOf(initialConfig.phone) }
    var selectedCurrency by remember { mutableStateOf(CurrencyFormatter.findByCode(initialConfig.currencyCode)) }
    var currencyMenuExpanded by remember { mutableStateOf(false) }

    var taxEnabled by remember { mutableStateOf(initialConfig.taxEnabled) }
    var defaultTaxPercent by remember { mutableStateOf(if (initialConfig.defaultTaxPercent > 0) initialConfig.defaultTaxPercent.toString() else "0") }
    var taxInclusive by remember { mutableStateOf(initialConfig.taxInclusive) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Welcome to Dukaan Saathi",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Set up your shop profile in seconds. All records stay offline on your device — no cloud account or login required.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionCard {
                Text(
                    text = "Shop Details",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it; errorMsg = null },
                    label = { Text("Shop / Business Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number (Optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = shopAddress,
                    onValueChange = { shopAddress = it },
                    label = { Text("Address / City (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard {
                Text(
                    text = "Currency & User-Configured Tax",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(
                    expanded = currencyMenuExpanded,
                    onExpandedChange = { currencyMenuExpanded = !currencyMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = "${selectedCurrency.code} (${selectedCurrency.symbol.trim()}) — ${selectedCurrency.name}",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Primary Currency") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = currencyMenuExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = currencyMenuExpanded,
                        onDismissRequest = { currencyMenuExpanded = false }
                    ) {
                        CurrencyFormatter.supportedCurrencies.forEach { info ->
                            DropdownMenuItem(
                                text = { Text("${info.code} (${info.symbol.trim()}) — ${info.name}") },
                                onClick = {
                                    selectedCurrency = info
                                    currencyMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Sales Tax", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                        Text(
                            "User-configured rate (you can override per product later).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = taxEnabled, onCheckedChange = { taxEnabled = it })
                }

                if (taxEnabled) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = defaultTaxPercent,
                        onValueChange = { defaultTaxPercent = it },
                        label = { Text("Default Tax Rate (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Prices Include Tax", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            Text(
                                "Extract tax from shelf price instead of adding on top.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = taxInclusive, onCheckedChange = { taxInclusive = it })
                    }
                }
            }

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Button(
                onClick = {
                    val trimmedName = shopName.trim()
                    if (trimmedName.isEmpty()) {
                        errorMsg = "Please enter your shop name to continue."
                        return@Button
                    }
                    val taxRate = defaultTaxPercent.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                    onCompleteSetup(
                        initialConfig.copy(
                            shopName = trimmedName,
                            shopAddress = shopAddress.trim(),
                            phone = phone.trim(),
                            currencyCode = selectedCurrency.code,
                            currencySymbol = selectedCurrency.symbol,
                            taxEnabled = taxEnabled,
                            defaultTaxPercent = taxRate,
                            taxInclusive = taxInclusive,
                            setupCompleted = true
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Start Managing My Shop", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
