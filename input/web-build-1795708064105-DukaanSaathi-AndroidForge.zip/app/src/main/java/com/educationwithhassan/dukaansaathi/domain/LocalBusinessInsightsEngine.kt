package com.educationwithhassan.dukaansaathi.domain

import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ExpenseEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ProductEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import java.util.Calendar

data class BusinessInsightAnswer(
    val question: String,
    val headline: String,
    val details: List<String>,
    val dataSourceNote: String = "Calculated offline from your local Room database records. No customer data leaves your device."
)

object LocalBusinessInsightsEngine {

    val suggestedPrompts = listOf(
        "Which products sell most?",
        "Which products have low stock?",
        "Which products are not selling?",
        "What were this month's expenses?",
        "How did this month compare with last month?",
        "Which customers have outstanding balances?",
        "What are the most important business trends?"
    )

    fun answerQuestion(
        query: String,
        config: ShopConfigEntity,
        products: List<ProductEntity>,
        sales: List<SaleEntity>,
        saleItems: List<SaleItemEntity>,
        expenses: List<ExpenseEntity>,
        customers: List<CustomerEntity>
    ): BusinessInsightAnswer {
        val q = query.lowercase().trim()
        val fmt = { amount: Double -> CurrencyFormatter.format(amount, config.currencyCode, config.currencySymbol) }

        return when {
            q.contains("sell most") || q.contains("best") || q.contains("top product") -> {
                val grouped = saleItems.groupBy { it.productName }
                    .map { (name, items) ->
                        Triple(name, items.sumOf { it.quantity }, items.sumOf { it.lineTotal })
                    }
                    .sortedByDescending { it.second }
                    .take(5)

                if (grouped.isEmpty()) {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "No sales recorded yet.",
                        details = listOf("Complete at least one sale in the POS screen to identify your top-selling products.")
                    )
                } else {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "Top ${grouped.size} best-selling products by units sold:",
                        details = grouped.mapIndexed { idx, (name, qty, rev) ->
                            "${idx + 1}. $name — $qty units sold (${fmt(rev)} total)"
                        }
                    )
                }
            }

            q.contains("low stock") || q.contains("out of stock") || q.contains("restock") -> {
                val outOfStock = products.filter { it.quantity <= 0 }
                val lowStock = products.filter { it.quantity > 0 && it.quantity <= it.minStockLevel }
                if (outOfStock.isEmpty() && lowStock.isEmpty()) {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "All ${products.size} products are above minimum stock levels.",
                        details = listOf("Inventory health looks good right now.")
                    )
                } else {
                    val lines = mutableListOf<String>()
                    outOfStock.take(5).forEach { lines.add("OUT OF STOCK: ${it.name} (0 left, min ${it.minStockLevel})") }
                    lowStock.take(8).forEach { lines.add("LOW STOCK: ${it.name} (${it.quantity} left, min ${it.minStockLevel})") }
                    BusinessInsightAnswer(
                        question = query,
                        headline = "${outOfStock.size} out of stock and ${lowStock.size} low-stock products found.",
                        details = lines
                    )
                }
            }

            q.contains("not selling") || q.contains("slow") -> {
                val thirtyDaysAgo = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
                val recentSaleIds = sales.filter { it.createdAt >= thirtyDaysAgo }.map { it.id }.toSet()
                val soldQtyByProduct = saleItems
                    .filter { it.saleId in recentSaleIds }
                    .groupBy { it.productId }
                    .mapValues { entry -> entry.value.sumOf { it.quantity } }

                val slowProducts = products
                    .filter { (soldQtyByProduct[it.id] ?: 0) == 0 && it.quantity > 0 }
                    .sortedByDescending { it.purchasePrice * it.quantity }
                    .take(6)

                if (products.isEmpty()) {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "No products in inventory yet.",
                        details = listOf("Add products in the Products tab to track movement.")
                    )
                } else if (slowProducts.isEmpty()) {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "Every stocked product had at least one sale in the last 30 days.",
                        details = listOf("No stagnant stock detected.")
                    )
                } else {
                    val tiedCapital = slowProducts.sumOf { it.purchasePrice * it.quantity }
                    BusinessInsightAnswer(
                        question = query,
                        headline = "${slowProducts.size} stocked items had 0 sales in the last 30 days.",
                        details = slowProducts.map {
                            "${it.name}: ${it.quantity} in stock (Cost value: ${fmt(it.purchasePrice * it.quantity)})"
                        } + "Tied-up purchase cost across these items: ${fmt(tiedCapital)}"
                    )
                }
            }

            q.contains("expense") -> {
                val (startMonth, endMonth) = monthRange(0)
                val monthExpenses = expenses.filter { it.expenseDate in startMonth..endMonth }
                val total = monthExpenses.sumOf { it.amount }
                val byCategory = monthExpenses.groupBy { it.category }
                    .mapValues { e -> e.value.sumOf { it.amount } }
                    .entries.sortedByDescending { it.value }

                if (monthExpenses.isEmpty()) {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "No operating expenses recorded for the current month.",
                        details = listOf("Total this month: ${fmt(0.0)}")
                    )
                } else {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "This month's operating expenses total ${fmt(total)}.",
                        details = byCategory.map { (cat, amt) -> "$cat: ${fmt(amt)}" }
                    )
                }
            }

            q.contains("compare") || q.contains("last month") -> {
                val (curStart, curEnd) = monthRange(0)
                val (prevStart, prevEnd) = monthRange(-1)

                val curSales = sales.filter { it.createdAt in curStart..curEnd }
                val prevSales = sales.filter { it.createdAt in prevStart..prevEnd }

                val curRev = curSales.sumOf { it.grandTotal - it.taxAmount }
                val prevRev = prevSales.sumOf { it.grandTotal - it.taxAmount }
                val curProfit = curSales.sumOf { it.grossProfit }
                val prevProfit = prevSales.sumOf { it.grossProfit }

                val pctText = if (prevRev > 0.0) {
                    val pct = ((curRev - prevRev) / prevRev) * 100.0
                    val sign = if (pct >= 0) "+" else ""
                    "$sign${String.format("%.1f", pct)}% vs last month"
                } else {
                    "No sales recorded last month for percentage comparison"
                }

                BusinessInsightAnswer(
                    question = query,
                    headline = "This month's net sales: ${fmt(curRev)} ($pctText).",
                    details = listOf(
                        "Current month: ${curSales.size} sales · Net revenue ${fmt(curRev)} · Gross profit ${fmt(curProfit)}",
                        "Last month: ${prevSales.size} sales · Net revenue ${fmt(prevRev)} · Gross profit ${fmt(prevProfit)}"
                    )
                )
            }

            q.contains("customer") || q.contains("balance") || q.contains("credit") || q.contains("udhaar") -> {
                val debtors = customers.filter { it.outstandingBalance > 0.009 }
                    .sortedByDescending { it.outstandingBalance }
                val totalOutstanding = debtors.sumOf { it.outstandingBalance }
                if (debtors.isEmpty()) {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "Zero outstanding customer credit balances.",
                        details = listOf("All customer accounts are settled.")
                    )
                } else {
                    BusinessInsightAnswer(
                        question = query,
                        headline = "${debtors.size} customers owe a combined ${fmt(totalOutstanding)}.",
                        details = debtors.take(6).map {
                            "${it.fullName}${if (it.phone.isNotBlank()) " (${it.phone})" else ""}: ${fmt(it.outstandingBalance)} due"
                        }
                    )
                }
            }

            else -> {
                val totalNetRev = sales.sumOf { it.grandTotal - it.taxAmount }
                val totalGrossProfit = sales.sumOf { it.grossProfit }
                val totalExp = expenses.sumOf { it.amount }
                val netProfit = AccountingCalculator.calculateNetProfit(totalGrossProfit, totalExp)
                val inventoryCost = products.sumOf { it.purchasePrice * it.quantity }
                val receivable = customers.sumOf { it.outstandingBalance }
                val lowCount = products.count { it.quantity <= it.minStockLevel }

                BusinessInsightAnswer(
                    question = query,
                    headline = "Overall Business Snapshot (${sales.size} sales, ${products.size} products)",
                    details = listOf(
                        "Net Revenue (excl. tax): ${fmt(totalNetRev)}",
                        "Gross Profit (after COGS): ${fmt(totalGrossProfit)}",
                        "Operating Expenses: ${fmt(totalExp)}",
                        "Net Profit: ${fmt(netProfit)}",
                        "Inventory Valuation (at purchase cost): ${fmt(inventoryCost)}",
                        "Customer Credit Receivable: ${fmt(receivable)}",
                        "Low / Out-of-Stock Items: $lowCount"
                    )
                )
            }
        }
    }

    private fun monthRange(monthOffset: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, monthOffset)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis

        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.MILLISECOND, -1)
        val end = cal.timeInMillis
        return start to end
    }
}
