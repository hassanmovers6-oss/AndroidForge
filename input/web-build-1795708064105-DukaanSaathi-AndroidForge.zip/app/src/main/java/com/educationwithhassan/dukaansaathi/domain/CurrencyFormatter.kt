package com.educationwithhassan.dukaansaathi.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs

data class CurrencyInfo(
    val code: String,
    val symbol: String,
    val name: String,
    val decimals: Int = 2
)

object CurrencyFormatter {
    val supportedCurrencies: List<CurrencyInfo> = listOf(
        CurrencyInfo("USD", "$", "US Dollar", 2),
        CurrencyInfo("EUR", "€", "Euro", 2),
        CurrencyInfo("GBP", "£", "British Pound", 2),
        CurrencyInfo("PKR", "Rs.", "Pakistani Rupee", 2),
        CurrencyInfo("INR", "₹", "Indian Rupee", 2),
        CurrencyInfo("AED", "AED ", "UAE Dirham", 2),
        CurrencyInfo("SAR", "SAR ", "Saudi Riyal", 2),
        CurrencyInfo("CAD", "CA$", "Canadian Dollar", 2),
        CurrencyInfo("AUD", "A$", "Australian Dollar", 2),
        CurrencyInfo("BDT", "৳", "Bangladeshi Taka", 2),
        CurrencyInfo("MYR", "RM ", "Malaysian Ringgit", 2),
        CurrencyInfo("SGD", "S$", "Singapore Dollar", 2),
        CurrencyInfo("NGN", "₦", "Nigerian Naira", 2),
        CurrencyInfo("ZAR", "R ", "South African Rand", 2),
        CurrencyInfo("KES", "KSh ", "Kenyan Shilling", 2),
        CurrencyInfo("JPY", "¥", "Japanese Yen", 0),
        CurrencyInfo("CNY", "¥", "Chinese Yuan", 2)
    )

    fun findByCode(code: String): CurrencyInfo {
        return supportedCurrencies.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: CurrencyInfo("USD", "$", "US Dollar", 2)
    }

    fun format(amount: Double, currencyCode: String, customSymbol: String? = null): String {
        val info = findByCode(currencyCode)
        val symbol = customSymbol?.takeIf { it.isNotBlank() } ?: info.symbol
        val symbols = DecimalFormatSymbols(Locale.US)
        val pattern = if (info.decimals == 0) "#,##0" else "#,##0.00"
        val formatter = DecimalFormat(pattern, symbols)
        val absFormatted = formatter.format(abs(amount))
        return if (amount < -0.004) "-$symbol$absFormatted" else "$symbol$absFormatted"
    }
}
