package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.data.local.entity.ExpenseEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.formatDateOnly
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel
import java.util.Calendar

private val EXPENSE_CATEGORIES = listOf(
    "Rent", "Electricity", "Water", "Internet",
    "Transport", "Salaries", "Purchases", "Maintenance", "Other expenses"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    openAddInitially: Boolean = false,
    onConsumeOpenAdd: () -> Unit = {},
    onBack: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("All") } // Today, Month, All
    var categoryFilter by remember { mutableStateOf("All") }
    var sortDesc by remember { mutableStateOf(true) }

    var editingExpense by remember { mutableStateOf<ExpenseEntity?>(null) }
    var showForm by remember(openAddInitially) { mutableStateOf(openAddInitially) }
    var deleteCandidate by remember { mutableStateOf<ExpenseEntity?>(null) }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val startOfDay = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val startOfMonth = remember {
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val filtered = remember(state.expenses, search, dateFilter, categoryFilter, sortDesc) {
        state.expenses.filter { e ->
            val matchText = search.isBlank() ||
                e.title.contains(search, ignoreCase = true) ||
                e.category.contains(search, ignoreCase = true) ||
                e.notes.contains(search, ignoreCase = true)
            val matchCat = categoryFilter == "All" || e.category.equals(categoryFilter, ignoreCase = true)
            val matchDate = when (dateFilter) {
                "Today" -> e.expenseDate >= startOfDay
                "This Month" -> e.expenseDate >= startOfMonth
                else -> true
            }
            matchText && matchCat && matchDate
        }.let { list ->
            if (sortDesc) list.sortedByDescending { it.expenseDate } else list.sortedByDescending { it.amount }
        }
    }

    val filteredTotal = filtered.sumOf { it.amount }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Expenses") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { sortDesc = !sortDesc }) {
                        Text(if (sortDesc) "Newest" else "Highest")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editingExpense = null; showForm = true },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ) { Icon(Icons.Default.Add, contentDescription = "Add Expense") }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Filtered Total: ${fmt(filteredTotal)} (${filtered.size} items)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = CrimsonError
            )

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Search expenses...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("All", "Today", "This Month")) { period ->
                    FilterChip(
                        selected = dateFilter == period,
                        onClick = { dateFilter = period },
                        label = { Text(period) }
                    )
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("All") + EXPENSE_CATEGORIES) { cat ->
                    FilterChip(
                        selected = categoryFilter == cat,
                        onClick = { categoryFilter = cat },
                        label = { Text(cat) }
                    )
                }
            }

            if (filtered.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.ReceiptLong,
                    title = "No expenses recorded",
                    description = "Track rent, electricity, salaries, and maintenance to calculate accurate net profit.",
                    actionLabel = "Add Expense",
                    onAction = { editingExpense = null; showForm = true }
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(filtered, key = { it.id }) { exp ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { editingExpense = exp; showForm = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(exp.title, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${exp.category} · ${formatDateOnly(exp.expenseDate)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(fmt(exp.amount), fontWeight = FontWeight.Bold, color = CrimsonError)
                                    IconButton(onClick = { deleteCandidate = exp }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonError)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        ExpenseFormDialog(
            initial = editingExpense,
            onDismiss = { showForm = false; onConsumeOpenAdd() },
            onSave = { exp ->
                viewModel.saveExpense(exp) {
                    showForm = false
                    onConsumeOpenAdd()
                }
            }
        )
    }

    deleteCandidate?.let { exp ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete Expense?") },
            text = { Text("Delete '${exp.title}' (${fmt(exp.amount)})?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteExpense(exp)
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError)
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteCandidate = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ExpenseFormDialog(
    initial: ExpenseEntity?,
    onDismiss: () -> Unit,
    onSave: (ExpenseEntity) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var category by remember { mutableStateOf(initial?.category ?: EXPENSE_CATEGORIES.first()) }
    var amount by remember { mutableStateOf(initial?.amount?.toString().orEmpty()) }
    var notes by remember { mutableStateOf(initial?.notes.orEmpty()) }
    var catMenuOpen by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Expense" else "Edit Expense") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; err = null },
                    label = { Text("Expense Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { catMenuOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Category: $category") }
                DropdownMenu(expanded = catMenuOpen, onDismissRequest = { catMenuOpen = false }) {
                    EXPENSE_CATEGORIES.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat) },
                            onClick = { category = cat; catMenuOpen = false }
                        )
                    }
                }
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it; err = null },
                    label = { Text("Amount *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (err != null) Text(err!!, color = CrimsonError)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull()
                    if (title.isBlank() || amt == null || amt <= 0.0) {
                        err = "Enter a valid expense title and amount."
                        return@Button
                    }
                    onSave(
                        ExpenseEntity(
                            id = initial?.id ?: 0L,
                            title = title.trim(),
                            category = category,
                            amount = amt,
                            notes = notes.trim(),
                            expenseDate = initial?.expenseDate ?: System.currentTimeMillis(),
                            createdAt = initial?.createdAt ?: System.currentTimeMillis()
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
