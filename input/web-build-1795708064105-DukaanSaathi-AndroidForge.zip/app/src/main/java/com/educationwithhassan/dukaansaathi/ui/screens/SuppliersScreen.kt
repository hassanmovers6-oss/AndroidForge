package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierEntity
import com.educationwithhassan.dukaansaathi.data.repository.PurchaseLineRequest
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.components.formatTimestamp
import com.educationwithhassan.dukaansaathi.ui.theme.AmberWarning
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.theme.EmeraldSuccess
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuppliersScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    onBack: () -> Unit
) {
    var editingSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var detailSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var purchaseSupplier by remember { mutableStateOf<SupplierEntity?>(null) }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }
    val totalPayable = state.suppliers.sumOf { it.outstandingBalance }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Suppliers & Purchases") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editingSupplier = null; showForm = true },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ) { Icon(Icons.Default.Add, contentDescription = "Add Supplier") }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "${state.suppliers.size} suppliers · Payable Balance: ${fmt(totalPayable)}",
                style = MaterialTheme.typography.titleMedium,
                color = if (totalPayable > 0.009) AmberWarning else MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (state.suppliers.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.LocalShipping,
                    title = "No suppliers added yet",
                    description = "Add suppliers to record stock purchase orders, auto-update inventory quantities, and track supplier balances.",
                    actionLabel = "Add Supplier",
                    onAction = { editingSupplier = null; showForm = true }
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 84.dp)
                ) {
                    items(state.suppliers, key = { it.id }) { supplier ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { detailSupplier = supplier }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(supplier.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        supplier.phone.ifBlank { "No phone" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text("Total Purchased: ${fmt(supplier.totalPurchased)}", style = MaterialTheme.typography.bodyMedium)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        fmt(supplier.outstandingBalance),
                                        fontWeight = FontWeight.Bold,
                                        color = if (supplier.outstandingBalance > 0.009) AmberWarning else EmeraldSuccess
                                    )
                                    TextButton(onClick = { purchaseSupplier = supplier }) {
                                        Text("+ Buy Stock")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        SupplierFormDialog(
            initial = editingSupplier,
            onDismiss = { showForm = false },
            onSave = { sup ->
                viewModel.saveSupplier(sup) { showForm = false }
            }
        )
    }

    detailSupplier?.let { sel ->
        val fresh = state.suppliers.firstOrNull { it.id == sel.id } ?: sel
        SupplierLedgerDialog(
            supplier = fresh,
            state = state,
            viewModel = viewModel,
            onNewPurchase = {
                detailSupplier = null
                purchaseSupplier = fresh
            },
            onEdit = {
                detailSupplier = null
                editingSupplier = fresh
                showForm = true
            },
            onDelete = {
                viewModel.deleteSupplier(fresh)
                detailSupplier = null
            },
            onDismiss = { detailSupplier = null }
        )
    }

    purchaseSupplier?.let { sup ->
        RecordPurchaseDialog(
            supplier = sup,
            state = state,
            viewModel = viewModel,
            onDismiss = { purchaseSupplier = null }
        )
    }
}

@Composable
private fun SupplierFormDialog(
    initial: SupplierEntity?,
    onDismiss: () -> Unit,
    onSave: (SupplierEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var phone by remember { mutableStateOf(initial?.phone.orEmpty()) }
    var email by remember { mutableStateOf(initial?.email.orEmpty()) }
    var address by remember { mutableStateOf(initial?.address.orEmpty()) }
    var notes by remember { mutableStateOf(initial?.notes.orEmpty()) }
    var err by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Supplier" else "Edit Supplier") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it; err = null }, label = { Text("Supplier Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, maxLines = 2, modifier = Modifier.fillMaxWidth())
                if (err != null) Text(err!!, color = CrimsonError)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isBlank()) { err = "Supplier name is required."; return@Button }
                onSave(
                    SupplierEntity(
                        id = initial?.id ?: 0L,
                        name = name.trim(),
                        phone = phone.trim(),
                        email = email.trim(),
                        address = address.trim(),
                        notes = notes.trim(),
                        totalPurchased = initial?.totalPurchased ?: 0.0,
                        outstandingBalance = initial?.outstandingBalance ?: 0.0,
                        createdAt = initial?.createdAt ?: System.currentTimeMillis()
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun RecordPurchaseDialog(
    supplier: SupplierEntity,
    state: ShopUiState,
    viewModel: ShopViewModel,
    onDismiss: () -> Unit
) {
    val lines = remember { mutableStateListOf<PurchaseLineRequest>() }
    var selectedProductIdx by remember { mutableStateOf(0) }
    var productMenuOpen by remember { mutableStateOf(false) }
    var qtyText by remember { mutableStateOf("10") }
    var costText by remember { mutableStateOf(state.products.firstOrNull()?.purchasePrice?.toString() ?: "") }
    var invoiceRef by remember { mutableStateOf("") }
    var paidText by remember { mutableStateOf("0") }
    var paymentMethod by remember { mutableStateOf("Cash") }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }
    val totalAmount = lines.sumOf { it.quantity * it.unitCost }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Purchase Stock · ${supplier.name}") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (state.products.isEmpty()) {
                    Text("Please add at least one product in the Products tab before recording a stock purchase.", color = CrimsonError)
                } else {
                    val chosen = state.products.getOrElse(selectedProductIdx) { state.products.first() }
                    OutlinedButton(onClick = { productMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Product: ${chosen.name}")
                    }
                    DropdownMenu(expanded = productMenuOpen, onDismissRequest = { productMenuOpen = false }) {
                        state.products.forEachIndexed { idx, p ->
                            DropdownMenuItem(
                                text = { Text("${p.name} (Stock: ${p.quantity})") },
                                onClick = {
                                    selectedProductIdx = idx
                                    costText = p.purchasePrice.toString()
                                    productMenuOpen = false
                                }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qtyText,
                            onValueChange = { qtyText = it },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = costText,
                            onValueChange = { costText = it },
                            label = { Text("Unit Cost") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val q = qtyText.toIntOrNull() ?: return@OutlinedButton
                            val c = costText.toDoubleOrNull() ?: return@OutlinedButton
                            if (q > 0 && c >= 0) {
                                lines.add(PurchaseLineRequest(chosen.id, q, c))
                                val nextTotal = lines.sumOf { it.quantity * it.unitCost }
                                paidText = String.format("%.2f", nextTotal)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("+ Add Line to Purchase") }

                    lines.forEachIndexed { idx, l ->
                        val pName = state.products.firstOrNull { it.id == l.productId }?.name ?: "Product"
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("$pName (${l.quantity} x ${fmt(l.unitCost)})")
                            Text(fmt(l.quantity * l.unitCost), fontWeight = FontWeight.SemiBold)
                        }
                    }

                    HorizontalDivider()
                    Text("Total Purchase: ${fmt(totalAmount)}", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = invoiceRef,
                        onValueChange = { invoiceRef = it },
                        label = { Text("Supplier Invoice Ref (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = paidText,
                        onValueChange = { paidText = it },
                        label = { Text("Amount Paid Now") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Cash", "Card", "Other").forEach { m ->
                            FilterChip(selected = paymentMethod == m, onClick = { paymentMethod = m }, label = { Text(m) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paid = paidText.toDoubleOrNull() ?: 0.0
                    viewModel.recordSupplierPurchase(
                        supplierId = supplier.id,
                        invoiceRef = invoiceRef.trim(),
                        lines = lines.toList(),
                        paidAmount = paid,
                        paymentMethod = paymentMethod,
                        notes = ""
                    ) { onDismiss() }
                },
                enabled = lines.isNotEmpty()
            ) { Text("Save & Restock") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SupplierLedgerDialog(
    supplier: SupplierEntity,
    state: ShopUiState,
    viewModel: ShopViewModel,
    onNewPurchase: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val purchases by viewModel.observePurchasesForSupplier(supplier.id).collectAsState(initial = emptyList())
    val payments by viewModel.observePaymentsForSupplier(supplier.id).collectAsState(initial = emptyList())
    var payAmount by remember { mutableStateOf("") }
    var payMethod by remember { mutableStateOf("Cash") }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(supplier.name, modifier = Modifier.weight(1f))
                Row {
                    IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonError) }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SectionCard {
                    Text("Total Purchased: ${fmt(supplier.totalPurchased)}")
                    Text(
                        "Outstanding Payable: ${fmt(supplier.outstandingBalance)}",
                        fontWeight = FontWeight.Bold,
                        color = if (supplier.outstandingBalance > 0.009) AmberWarning else EmeraldSuccess
                    )
                }

                Button(onClick = onNewPurchase, modifier = Modifier.fillMaxWidth()) {
                    Text("Record Stock Purchase")
                }

                if (supplier.outstandingBalance > 0.009) {
                    Text("Record Supplier Payment", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = payAmount,
                        onValueChange = { payAmount = it },
                        label = { Text("Payment Amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Cash", "Card", "Other").forEach { m ->
                            FilterChip(selected = payMethod == m, onClick = { payMethod = m }, label = { Text(m) })
                        }
                    }
                    Button(
                        onClick = {
                            val amt = payAmount.toDoubleOrNull() ?: return@Button
                            viewModel.recordSupplierPayment(supplier.id, amt, payMethod, "")
                            payAmount = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Pay Supplier") }
                }

                Text("Purchase & Payment Ledger", fontWeight = FontWeight.SemiBold)
                val combined = buildList {
                    purchases.forEach { add(Triple(it.createdAt, "PO ${it.invoiceRef}", "Total ${fmt(it.totalAmount)} · Due ${fmt(it.balanceDue)}")) }
                    payments.forEach { add(Triple(it.createdAt, "Payment (${it.paymentMethod})", "Paid ${fmt(it.amount)}")) }
                }.sortedByDescending { it.first }

                if (combined.isEmpty()) {
                    Text("No purchase records yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    combined.take(20).forEach { (ts, label, amt) ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(label, fontWeight = FontWeight.Medium)
                                Text(formatTimestamp(ts), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(amt, fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
