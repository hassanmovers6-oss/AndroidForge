package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UdhaarScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    onBack: () -> Unit
) {
    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val debtors = remember(state.customers) {
        state.customers.filter { it.outstandingBalance > 0.009 }.sortedByDescending { it.outstandingBalance }
    }
    val totalReceivable = debtors.sumOf { it.outstandingBalance }
    var paymentTarget by remember { mutableStateOf<CustomerEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Udhaar / Credit Ledger") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionCard {
                Text("Total Outstanding Credit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(fmt(totalReceivable), style = MaterialTheme.typography.headlineMedium, color = CrimsonError)
                Text("${debtors.size} customer(s) with pending credit balances", style = MaterialTheme.typography.bodyMedium)
            }

            if (debtors.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.AccountBalanceWallet,
                    title = "No outstanding credit balances",
                    description = "All customer accounts are fully settled."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(debtors, key = { it.id }) { cust ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cust.fullName, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                                    Text(cust.phone.ifBlank { "No phone" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Due: ${fmt(cust.outstandingBalance)}", color = CrimsonError, fontWeight = FontWeight.Bold)
                                }
                                Button(onClick = { paymentTarget = cust }) {
                                    Text("Receive")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    paymentTarget?.let { customer ->
        var amountText by remember { mutableStateOf(String.format("%.2f", customer.outstandingBalance)) }
        var method by remember { mutableStateOf("Cash") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { paymentTarget = null },
            title = { Text("Receive Payment · ${customer.fullName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Remaining Balance: ${fmt(customer.outstandingBalance)}", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Payment Amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Cash", "Card", "Other").forEach { m ->
                            FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) })
                        }
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: return@Button
                        viewModel.recordCustomerPayment(customer.id, amt, method, notes)
                        paymentTarget = null
                    }
                ) { Text("Record Payment") }
            },
            dismissButton = {
                OutlinedButton(onClick = { paymentTarget = null }) { Text("Cancel") }
            }
        )
    }
}
