package com.educationwithhassan.dukaansaathi.ui.screens

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.ads.AdMobManager
import com.educationwithhassan.dukaansaathi.ads.NativeAdCard
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel

data class MoreDestinationItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val route: String
)

@Composable
fun MoreHubScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    adMobManager: AdMobManager,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val itemsList = listOf(
        MoreDestinationItem(
            "Expenses",
            "Track rent, utilities, salaries & daily costs",
            Icons.Default.ReceiptLong,
            "expenses"
        ),
        MoreDestinationItem(
            "Suppliers & Purchases",
            "Manage suppliers, stock purchases & payables",
            Icons.Default.LocalShipping,
            "suppliers"
        ),
        MoreDestinationItem(
            "Reports & Analytics",
            "Revenue, COGS gross profit, net profit & CSV export",
            Icons.Default.Analytics,
            "reports"
        ),
        MoreDestinationItem(
            "Udhaar Credit Overview",
            "All outstanding customer credit balances",
            Icons.Default.AccountBalanceWallet,
            "udhaar"
        ),
        MoreDestinationItem(
            "AI Business Insights",
            "Offline Q&A from your actual shop database",
            Icons.Default.AutoAwesome,
            "ai_assistant"
        ),
        MoreDestinationItem(
            "Backup & Restore",
            "Export & validate offline JSON shop backups",
            Icons.Default.Backup,
            "backup"
        ),
        MoreDestinationItem(
            "Settings",
            "Shop profile, currency, tax, theme & reminders",
            Icons.Default.Settings,
            "settings"
        )
    )

    val now = System.currentTimeMillis()
    val remainingMs = (state.config.analyticsPackUnlockedUntilMs - now).coerceAtLeast(0L)
    val rewardActive = remainingMs > 0L
    val remainingHours = remainingMs / (60L * 60 * 1000)
    val remainingMins = (remainingMs % (60L * 60 * 1000)) / (60L * 1000)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text("More Tools", style = MaterialTheme.typography.headlineMedium)
                Text(
                    text = "${state.config.shopName} · All essential features work offline",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(itemsList) { item ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (activity != null && (item.route == "reports" || item.route == "suppliers" || item.route == "ai_assistant")) {
                            adMobManager.showInterstitialAtNaturalBreak(activity) {
                                onNavigate(item.route)
                            }
                        } else {
                            onNavigate(item.route)
                        }
                    }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            item.subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Optional Rewarded Ad Card (never locks core business features!)
        item {
            SectionCard {
                Text(
                    text = "Optional Supporter Bonus",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (rewardActive) {
                        "Extended Margin Comparison Highlight is active in Reports (${remainingHours}h ${remainingMins}m remaining)."
                    } else {
                        "Watch an optional short video ad to unlock the 24-hour Margin Comparison Highlight card in Reports. All core shop tools remain 100% free."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!rewardActive) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (activity == null) {
                                viewModel.emitMessage("Unable to open video ad right now. All core reports remain available.")
                                return@Button
                            }
                            adMobManager.showRewardedAd(
                                activity = activity,
                                onRewardEarned = { viewModel.unlockAnalyticsPack24h() },
                                onClosedWithoutReward = {
                                    viewModel.emitMessage("Watch the full video to earn the 24-hour Margin Highlight bonus. Standard reports remain unlocked.")
                                },
                                onUnavailable = {
                                    viewModel.emitMessage("Video ad is unavailable offline or still loading. You can continue using all Reports without it.")
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Icon(Icons.Default.PlayCircleOutline, contentDescription = null)
                        Spacer(Modifier.size(6.dp))
                        Text("Watch Ad for 24h Bonus")
                    }
                }
            }
        }

        // Native Ad clearly labeled "Ad" in non-critical More hub
        item {
            NativeAdCard()
        }
    }
}
