package com.educationwithhassan.dukaansaathi.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.CustomerPaymentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ExpenseEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ProductEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.PurchaseOrderEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.StockAdjustmentEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SupplierPaymentEntity
import com.educationwithhassan.dukaansaathi.data.repository.CompleteSaleRequest
import com.educationwithhassan.dukaansaathi.data.repository.PurchaseLineRequest
import com.educationwithhassan.dukaansaathi.data.repository.ShopRepository
import com.educationwithhassan.dukaansaathi.domain.AccountingCalculator
import com.educationwithhassan.dukaansaathi.domain.CartCalculationSummary
import com.educationwithhassan.dukaansaathi.domain.CartLineInput
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PosCartItem(
    val product: ProductEntity,
    val quantity: Int,
    val lineDiscount: Double = 0.0
)

data class PosState(
    val items: List<PosCartItem> = emptyList(),
    val orderDiscount: Double = 0.0,
    val selectedCustomerId: Long? = null,
    val paymentMethod: String = "Cash",
    val paidAmountText: String = "",
    val splitCashText: String = "",
    val splitCardText: String = "",
    val splitOtherText: String = "",
    val notes: String = ""
)

data class ShopUiState(
    val config: ShopConfigEntity = ShopConfigEntity(),
    val products: List<ProductEntity> = emptyList(),
    val lowStockProducts: List<ProductEntity> = emptyList(),
    val stockAdjustments: List<StockAdjustmentEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val sales: List<SaleEntity> = emptyList(),
    val saleItems: List<SaleItemEntity> = emptyList(),
    val customerPayments: List<CustomerPaymentEntity> = emptyList(),
    val expenses: List<ExpenseEntity> = emptyList(),
    val suppliers: List<SupplierEntity> = emptyList(),
    val purchases: List<PurchaseOrderEntity> = emptyList(),
    val supplierPayments: List<SupplierPaymentEntity> = emptyList(),
    val isLoaded: Boolean = false
)

class ShopViewModel(val repository: ShopRepository) : ViewModel() {

    private val firstBatch = combine(
        repository.shopConfig,
        repository.products,
        repository.lowStockProducts,
        repository.recentStockAdjustments,
        repository.customers
    ) { config, products, lowStock, adjustments, customers ->
        listOf(config, products, lowStock, adjustments, customers)
    }

    private val secondBatch = combine(
        repository.sales,
        repository.saleItems,
        repository.customerPayments,
        repository.expenses,
        repository.suppliers
    ) { sales, saleItems, custPayments, expenses, suppliers ->
        listOf(sales, saleItems, custPayments, expenses, suppliers)
    }

    private val thirdBatch = combine(
        repository.purchases,
        repository.supplierPayments
    ) { purchases, suppPayments ->
        purchases to suppPayments
    }

    @Suppress("UNCHECKED_CAST")
    val uiState: StateFlow<ShopUiState> = combine(firstBatch, secondBatch, thirdBatch) { b1, b2, b3 ->
        ShopUiState(
            config = b1[0] as ShopConfigEntity,
            products = b1[1] as List<ProductEntity>,
            lowStockProducts = b1[2] as List<ProductEntity>,
            stockAdjustments = b1[3] as List<StockAdjustmentEntity>,
            customers = b1[4] as List<CustomerEntity>,
            sales = b2[0] as List<SaleEntity>,
            saleItems = b2[1] as List<SaleItemEntity>,
            customerPayments = b2[2] as List<CustomerPaymentEntity>,
            expenses = b2[3] as List<ExpenseEntity>,
            suppliers = b2[4] as List<SupplierEntity>,
            purchases = b3.first,
            supplierPayments = b3.second,
            isLoaded = true
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ShopUiState())

    private val _posState = MutableStateFlow(PosState())
    val posState: StateFlow<PosState> = _posState.asStateFlow()

    val posSummary: StateFlow<CartCalculationSummary> = combine(_posState, repository.shopConfig) { pos, cfg ->
        val lines = pos.items.map { item ->
            CartLineInput(
                productId = item.product.id,
                productName = item.product.name,
                quantity = item.quantity,
                unitPrice = item.product.sellingPrice,
                unitCost = item.product.purchasePrice,
                lineDiscount = item.lineDiscount,
                taxPercentOverride = item.product.taxPercentOverride
            )
        }
        AccountingCalculator.calculateCart(
            items = lines,
            orderDiscountAmount = pos.orderDiscount,
            taxEnabled = cfg.taxEnabled,
            defaultTaxPercent = cfg.defaultTaxPercent,
            taxInclusive = cfg.taxInclusive
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AccountingCalculator.calculateCart(emptyList(), 0.0, false, 0.0, false)
    )

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun emitMessage(msg: String) {
        _statusMessage.value = msg
    }

    // Setup & Settings
    fun saveShopConfig(config: ShopConfigEntity, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveShopConfig(config)
            onDone?.invoke()
        }
    }

    fun unlockAnalyticsPack24h() {
        viewModelScope.launch {
            val current = repository.getConfigOnce()
            val until = System.currentTimeMillis() + 24L * 60 * 60 * 1000
            repository.saveShopConfig(current.copy(analyticsPackUnlockedUntilMs = until))
            emitMessage("Reward granted: Detailed Export & Insights Card unlocked for 24 hours.")
        }
    }

    // Products & Inventory
    fun saveProduct(product: ProductEntity, reason: String = "Manual Edit", onSaved: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveProduct(product, reason)
            emitMessage("Saved product '${product.name}'.")
            onSaved?.invoke()
        }
    }

    fun adjustStock(productId: Long, newQuantity: Int, reason: String) {
        viewModelScope.launch {
            val res = repository.adjustProductStock(productId, newQuantity, reason)
            res.onSuccess { emitMessage("Stock updated successfully.") }
            res.onFailure { emitMessage(it.message ?: "Failed to update stock.") }
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            emitMessage("Deleted '${product.name}'.")
        }
    }

    fun observeAdjustmentsForProduct(productId: Long): Flow<List<StockAdjustmentEntity>> =
        repository.observeAdjustmentsForProduct(productId)

    // POS Cart Operations
    fun addProductToCart(product: ProductEntity) {
        val cfg = uiState.value.config
        _posState.update { state ->
            val existing = state.items.firstOrNull { it.product.id == product.id }
            val nextQty = (existing?.quantity ?: 0) + 1
            if (!cfg.allowNegativeInventory && nextQty > product.quantity) {
                emitMessage("Only ${product.quantity} unit(s) of '${product.name}' in stock.")
                return@update state
            }
            val updatedList = if (existing != null) {
                state.items.map {
                    if (it.product.id == product.id) it.copy(quantity = nextQty, product = product) else it
                }
            } else {
                state.items + PosCartItem(product = product, quantity = 1)
            }
            state.copy(items = updatedList)
        }
    }

    fun addBarcodeToCart(barcode: String, onNotFound: () -> Unit) {
        viewModelScope.launch {
            val product = repository.findProductByBarcode(barcode)
            if (product != null) {
                addProductToCart(product)
                emitMessage("Added '${product.name}' to cart.")
            } else {
                onNotFound()
            }
        }
    }

    fun updateCartItemQuantity(productId: Long, newQty: Int) {
        val cfg = uiState.value.config
        _posState.update { state ->
            if (newQty <= 0) {
                state.copy(items = state.items.filterNot { it.product.id == productId })
            } else {
                val target = state.items.firstOrNull { it.product.id == productId } ?: return@update state
                if (!cfg.allowNegativeInventory && newQty > target.product.quantity) {
                    emitMessage("Insufficient stock. Available: ${target.product.quantity}.")
                    return@update state
                }
                state.copy(
                    items = state.items.map {
                        if (it.product.id == productId) it.copy(quantity = newQty) else it
                    }
                )
            }
        }
    }

    fun updateOrderDiscount(discount: Double) {
        _posState.update { it.copy(orderDiscount = discount.coerceAtLeast(0.0)) }
    }

    fun selectPosCustomer(customerId: Long?) {
        _posState.update { it.copy(selectedCustomerId = customerId) }
    }

    fun updatePaymentDetails(
        method: String,
        paidAmountText: String? = null,
        splitCash: String? = null,
        splitCard: String? = null,
        splitOther: String? = null,
        notes: String? = null
    ) {
        _posState.update { state ->
            state.copy(
                paymentMethod = method,
                paidAmountText = paidAmountText ?: state.paidAmountText,
                splitCashText = splitCash ?: state.splitCashText,
                splitCardText = splitCard ?: state.splitCardText,
                splitOtherText = splitOther ?: state.splitOtherText,
                notes = notes ?: state.notes
            )
        }
    }

    fun clearCart() {
        _posState.value = PosState()
    }

    fun completeCheckout(onSaleCompleted: (SaleEntity, List<SaleItemEntity>) -> Unit) {
        val pos = _posState.value
        val summary = posSummary.value
        if (pos.items.isEmpty()) {
            emitMessage("Add items to the cart before checking out.")
            return
        }

        val splitCash = pos.splitCashText.toDoubleOrNull() ?: 0.0
        val splitCard = pos.splitCardText.toDoubleOrNull() ?: 0.0
        val splitOther = pos.splitOtherText.toDoubleOrNull() ?: 0.0

        val paidAmount = when (pos.paymentMethod) {
            "Credit" -> pos.paidAmountText.toDoubleOrNull() ?: 0.0
            "Split" -> splitCash + splitCard + splitOther
            else -> pos.paidAmountText.toDoubleOrNull() ?: summary.grandTotal
        }

        val lines = pos.items.map { item ->
            CartLineInput(
                productId = item.product.id,
                productName = item.product.name,
                quantity = item.quantity,
                unitPrice = item.product.sellingPrice,
                unitCost = item.product.purchasePrice,
                lineDiscount = item.lineDiscount,
                taxPercentOverride = item.product.taxPercentOverride
            )
        }

        viewModelScope.launch {
            val result = repository.completeSale(
                CompleteSaleRequest(
                    items = lines,
                    orderDiscountAmount = pos.orderDiscount,
                    customerId = pos.selectedCustomerId,
                    paymentMethod = pos.paymentMethod,
                    paidAmount = paidAmount,
                    splitCashAmount = splitCash,
                    splitCardAmount = splitCard,
                    splitOtherAmount = splitOther,
                    notes = pos.notes
                )
            )
            result.onSuccess { savedSale ->
                val pair = repository.getSaleWithItems(savedSale.id)
                clearCart()
                if (pair != null) {
                    onSaleCompleted(pair.first, pair.second)
                }
            }.onFailure { err ->
                emitMessage(err.message ?: "Checkout failed.")
            }
        }
    }

    // Customers & Udhaar Credit Ledger
    fun saveCustomer(customer: CustomerEntity, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveCustomer(customer)
            emitMessage("Saved customer '${customer.fullName}'.")
            onDone?.invoke()
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            emitMessage("Deleted customer '${customer.fullName}'.")
        }
    }

    fun recordCustomerPayment(customerId: Long, amount: Double, method: String, notes: String) {
        viewModelScope.launch {
            repository.recordCustomerPayment(customerId, amount, method, notes)
                .onSuccess { emitMessage("Customer payment recorded.") }
                .onFailure { emitMessage(it.message ?: "Failed to record payment.") }
        }
    }

    fun observeSalesForCustomer(customerId: Long): Flow<List<SaleEntity>> =
        repository.observeSalesForCustomer(customerId)

    fun observePaymentsForCustomer(customerId: Long): Flow<List<CustomerPaymentEntity>> =
        repository.observePaymentsForCustomer(customerId)

    // Expenses
    fun saveExpense(expense: ExpenseEntity, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveExpense(expense)
            emitMessage("Saved expense '${expense.title}'.")
            onDone?.invoke()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
            emitMessage("Deleted expense '${expense.title}'.")
        }
    }

    // Suppliers & Purchases
    fun saveSupplier(supplier: SupplierEntity, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.saveSupplier(supplier)
            emitMessage("Saved supplier '${supplier.name}'.")
            onDone?.invoke()
        }
    }

    fun deleteSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repository.deleteSupplier(supplier)
            emitMessage("Deleted supplier '${supplier.name}'.")
        }
    }

    fun recordSupplierPurchase(
        supplierId: Long,
        invoiceRef: String,
        lines: List<PurchaseLineRequest>,
        paidAmount: Double,
        paymentMethod: String,
        notes: String,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            repository.recordSupplierPurchase(supplierId, invoiceRef, lines, paidAmount, paymentMethod, notes)
                .onSuccess {
                    emitMessage("Stock purchase recorded and inventory updated.")
                    onDone()
                }
                .onFailure { emitMessage(it.message ?: "Failed to record purchase.") }
        }
    }

    fun recordSupplierPayment(supplierId: Long, amount: Double, method: String, notes: String) {
        viewModelScope.launch {
            repository.recordSupplierPayment(supplierId, amount, method, notes)
                .onSuccess { emitMessage("Supplier payment recorded.") }
                .onFailure { emitMessage(it.message ?: "Failed to record payment.") }
        }
    }

    fun observePurchasesForSupplier(supplierId: Long): Flow<List<PurchaseOrderEntity>> =
        repository.observePurchasesForSupplier(supplierId)

    fun observePaymentsForSupplier(supplierId: Long): Flow<List<SupplierPaymentEntity>> =
        repository.observePaymentsForSupplier(supplierId)

    suspend fun getSaleWithItems(saleId: Long): Pair<SaleEntity, List<SaleItemEntity>>? =
        repository.getSaleWithItems(saleId)

    class Factory(private val repository: ShopRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ShopViewModel(repository) as T
        }
    }
}
