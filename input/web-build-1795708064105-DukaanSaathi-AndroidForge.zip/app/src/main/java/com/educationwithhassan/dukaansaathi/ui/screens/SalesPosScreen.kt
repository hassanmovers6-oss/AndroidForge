package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.SaleItemEntity
import com.educationwithhassan.dukaansaathi.data.local.entity.ShopConfigEntity
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.BarcodeScannerDialog
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.components.formatTimestamp
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.theme.EmeraldSuccess
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel
import com.educationwithhassan.dukaansaathi.util.PdfReceiptGenerator
import kotlinx.coroutines.launch

@Composable
fun SalesPosScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    initialSaleIdToView: Long? = null,
    onConsumeSaleIdToView: () -> Unit = {}
) {
    val pos by viewModel.posState.collectAsState()
    val summary by viewModel.posSummary.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeTab by remember { mutableIntStateOf(0) } // 0 = POS Checkout, 1 = Sales History
    var productSearch by remember { mutableStateOf("") }
    var showScanner by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var receiptData by remember { mutableStateOf<Pair<SaleEntity, List<SaleItemEntity>>?>(null) }

    LaunchedEffect(initialSaleIdToView) {
        if (initialSaleIdToView != null) {
            receiptData = viewModel.getSaleWithItems(initialSaleIdToView)
            onConsumeSaleIdToView()
        }
    }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val matchingProducts = remember(state.products, productSearch) {
        state.products.filter {
            productSearch.isBlank() ||
                it.name.contains(productSearch, ignoreCase = true) ||
                it.barcode.contains(productSearch, ignoreCase = true) ||
                it.sku.contains(productSearch, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Point of Sale", style = MaterialTheme.typography.headlineMedium)
            SingleChoiceSegmentedButtonRow {
                SegmentedButton(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(0, 2)
                ) { Text("Register") }
                SegmentedButton(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    shape = SegmentedButtonDefaults.itemShape(1, 2)
                ) { Text("Invoices") }
            }
        }

        if (activeTab == 0) {
            OutlinedTextField(
                value = productSearch,
                onValueChange = { productSearch = it },
                placeholder = { Text("Search product or scan barcode...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    IconButton(onClick = { showScanner = true }) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Barcode")
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Quick horizontal product picker
            if (matchingProducts.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(matchingProducts.take(25), key = { it.id }) { p ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            onClick = { viewModel.addProductToCart(p) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .width(150.dp)
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = p.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${fmt(p.sellingPrice)} · Qty ${p.quantity}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }

            // Cart items
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (pos.items.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.Receipt,
                            title = "Cart is empty",
                            description = "Tap any product above or scan a barcode to start billing."
                        )
                    }
                } else {
                    items(pos.items, key = { it.product.id }) { item ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.product.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${fmt(item.product.sellingPrice)} x ${item.quantity} = ${fmt(item.product.sellingPrice * item.quantity)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { viewModel.updateCartItemQuantity(item.product.id, item.quantity - 1) }) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease")
                                    }
                                    Text(
                                        text = item.quantity.toString(),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp)
                                    )
                                    IconButton(onClick = { viewModel.updateCartItemQuantity(item.product.id, item.quantity + 1) }) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase")
                                    }
                                    IconButton(onClick = { viewModel.updateCartItemQuantity(item.product.id, 0) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = CrimsonError)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Totals & Checkout Bar (Zero Ads anywhere near POS controls!)
            SectionCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fmt(summary.subtotalBeforeDiscount))
                }
                if (summary.totalDiscount > 0.0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Discount", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("-${fmt(summary.totalDiscount)}", color = CrimsonError)
                    }
                }
                if (cfg.taxEnabled || summary.totalTax > 0.0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            if (cfg.taxInclusive) "Tax (Included)" else "Tax (User-Configured)",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(fmt(summary.totalTax))
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Grand Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(fmt(summary.grandTotal), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
                Text(
                    text = "Estimated Gross Profit (excl. tax & COGS): ${fmt(summary.grossProfit)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = EmeraldSuccess
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { viewModel.clearCart() },
                        enabled = pos.items.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) { Text("Clear") }
                    Button(
                        onClick = { showCheckoutDialog = true },
                        enabled = pos.items.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.weight(2f)
                    ) { Text("Proceed to Pay", fontWeight = FontWeight.SemiBold) }
                }
            }
        } else {
            // Sales History / Invoices list
            if (state.sales.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Receipt,
                    title = "No completed sales yet",
                    description = "Completed POS transactions and printable PDF invoices will appear here."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(state.sales, key = { it.id }) { sale ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch {
                                        receiptData = viewModel.getSaleWithItems(sale.id)
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${sale.invoiceNumber} · ${sale.customerName}", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${formatTimestamp(sale.createdAt)} · ${sale.paymentMethod}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        "Profit: ${fmt(sale.grossProfit)}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = EmeraldSuccess
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(fmt(sale.grandTotal), fontWeight = FontWeight.Bold)
                                    if (sale.balanceDue > 0.009) {
                                        Text("Due: ${fmt(sale.balanceDue)}", color = CrimsonError, style = MaterialTheme.typography.labelMedium)
                                    } else {
                                        Text("Paid", color = EmeraldSuccess, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showScanner) {
        BarcodeScannerDialog(
            title = "Scan Product for Sale",
            onBarcodeDetected = { code ->
                showScanner = false
                viewModel.addBarcodeToCart(code) {
                    viewModel.emitMessage("No product matched barcode '$code'. Add it in Products first.")
                }
            },
            onDismiss = { showScanner = false }
        )
    }

    if (showCheckoutDialog) {
        CheckoutPaymentDialog(
            state = state,
            viewModel = viewModel,
            grandTotal = summary.grandTotal,
            onDismiss = { showCheckoutDialog = false },
            onComplete = {
                viewModel.completeCheckout { sale, items ->
                    showCheckoutDialog = false
                    receiptData = sale to items
                }
            }
        )
    }

    receiptData?.let { (sale, items) ->
        ReceiptModalDialog(
            config = cfg,
            sale = sale,
            items = items,
            onDismiss = { receiptData = null },
            onPrint = {
                val pdf = PdfReceiptGenerator.generateSaleReceiptPdf(context, cfg, sale, items)
                PdfReceiptGenerator.printPdfFile(context, pdf, "Receipt ${sale.invoiceNumber}")
            },
            onShare = {
                val pdf = PdfReceiptGenerator.generateSaleReceiptPdf(context, cfg, sale, items)
                PdfReceiptGenerator.sharePdfFile(context, pdf, "Invoice ${sale.invoiceNumber}")
            }
        )
    }
}

@Composable
private fun CheckoutPaymentDialog(
    state: ShopUiState,
    viewModel: ShopViewModel,
    grandTotal: Double,
    onDismiss: () -> Unit,
    onComplete: () -> Unit
) {
    val pos by viewModel.posState.collectAsState()
    var discountInput by remember { mutableStateOf(if (pos.orderDiscount > 0) pos.orderDiscount.toString() else "") }
    var paidInput by remember { mutableStateOf(String.format("%.2f", grandTotal)) }
    var splitCash by remember { mutableStateOf(pos.splitCashText) }
    var splitCard by remember { mutableStateOf(pos.splitCardText) }
    var splitOther by remember { mutableStateOf(pos.splitOtherText) }
    var customerMenuOpen by remember { mutableStateOf(false) }

    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }
    val selectedCustomer = state.customers.firstOrNull { it.id == pos.selectedCustomerId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Complete Payment") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Payable Total: ${fmt(grandTotal)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = discountInput,
                    onValueChange = {
                        discountInput = it
                        viewModel.updateOrderDiscount(it.toDoubleOrNull() ?: 0.0)
                    },
                    label = { Text("Order Discount (${cfg.currencySymbol.trim()})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Customer Selector
                OutlinedButton(
                    onClick = { customerMenuOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(selectedCustomer?.fullName ?: "Walk-in Customer (Tap to select)")
                }
                DropdownMenu(
                    expanded = customerMenuOpen,
                    onDismissRequest = { customerMenuOpen = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Walk-in Customer") },
                        onClick = {
                            viewModel.selectPosCustomer(null)
                            customerMenuOpen = false
                        }
                    )
                    state.customers.forEach { cust ->
                        DropdownMenuItem(
                            text = { Text("${cust.fullName} (Due: ${fmt(cust.outstandingBalance)})") },
                            onClick = {
                                viewModel.selectPosCustomer(cust.id)
                                customerMenuOpen = false
                            }
                        )
                    }
                }

                Text("Payment Method", fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("Cash", "Card", "Other", "Split", "Credit")) { method ->
                        FilterChip(
                            selected = pos.paymentMethod == method,
                            onClick = {
                                val nextPaid = if (method == "Credit") "0" else String.format("%.2f", grandTotal)
                                paidInput = nextPaid
                                viewModel.updatePaymentDetails(method = method, paidAmountText = nextPaid)
                            },
                            label = { Text(method) }
                        )
                    }
                }

                if (pos.paymentMethod == "Split") {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = splitCash,
                            onValueChange = {
                                splitCash = it
                                viewModel.updatePaymentDetails("Split", splitCash = it, splitCard = splitCard, splitOther = splitOther)
                            },
                            label = { Text("Cash") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = splitCard,
                            onValueChange = {
                                splitCard = it
                                viewModel.updatePaymentDetails("Split", splitCash = splitCash, splitCard = it, splitOther = splitOther)
                            },
                            label = { Text("Card") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = splitOther,
                            onValueChange = {
                                splitOther = it
                                viewModel.updatePaymentDetails("Split", splitCash = splitCash, splitCard = splitCard, splitOther = it)
                            },
                            label = { Text("Other") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = paidInput,
                        onValueChange = {
                            paidInput = it
                            viewModel.updatePaymentDetails(pos.paymentMethod, paidAmountText = it)
                        },
                        label = { Text("Amount Paid Now (Less = Credit Balance)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (pos.paymentMethod == "Credit" && pos.selectedCustomerId == null) {
                    Text(
                        "Select a customer above to record credit (Udhaar) balance.",
                        color = CrimsonError,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onComplete,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) { Text("Complete Sale") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ReceiptModalDialog(
    config: ShopConfigEntity,
    sale: SaleEntity,
    items: List<SaleItemEntity>,
    onDismiss: () -> Unit,
    onPrint: () -> Unit,
    onShare: () -> Unit
) {
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, sale.currencyCode, config.currencySymbol) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receipt · ${sale.invoiceNumber}") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(config.shopName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (config.shopAddress.isNotBlank()) Text(config.shopAddress, style = MaterialTheme.typography.bodyMedium)
                Text("Date: ${formatTimestamp(sale.createdAt)}", style = MaterialTheme.typography.bodyMedium)
                Text("Customer: ${sale.customerName} · ${sale.paymentMethod}", style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                items.forEach { item ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${item.productName} x${item.quantity}", modifier = Modifier.weight(1f))
                        Text(fmt(item.lineTotal), fontWeight = FontWeight.Medium)
                    }
                }
                HorizontalDivider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal")
                    Text(fmt(sale.subtotal))
                }
                if (sale.discountAmount > 0.0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Discount")
                        Text("-${fmt(sale.discountAmount)}")
                    }
                }
                if (sale.taxAmount > 0.0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (sale.taxIncludedInPrice) "Tax (Included)" else "Tax")
                        Text(fmt(sale.taxAmount))
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Grand Total", fontWeight = FontWeight.Bold)
                    Text(fmt(sale.grandTotal), fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Paid")
                    Text(fmt(sale.paidAmount))
                }
                if (sale.balanceDue > 0.009) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Remaining Balance", color = CrimsonError, fontWeight = FontWeight.SemiBold)
                        Text(fmt(sale.balanceDue), color = CrimsonError, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPrint) {
                    Icon(Icons.Default.Print, contentDescription = "Print")
                    Spacer(Modifier.width(4.dp))
                    Text("Print")
                }
                Button(onClick = onShare) {
                    Icon(Icons.Default.Share, contentDescription = "Share PDF")
                    Spacer(Modifier.width(4.dp))
                    Text("PDF")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
