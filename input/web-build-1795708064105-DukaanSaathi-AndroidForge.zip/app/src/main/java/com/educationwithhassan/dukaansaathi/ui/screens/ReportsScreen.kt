package com.educationwithhassan.dukaansaathi.ui.screens

import android.app.Activity
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.educationwithhassan.dukaansaathi.ads.AdMobManager
import com.educationwithhassan.dukaansaathi.ads.NativeAdCard
import com.educationwithhassan.dukaansaathi.domain.AccountingCalculator
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.KpiCard
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.theme.AmberWarning
import com.educationwithhassan.dukaansaathi.ui.theme.BlueAccent
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.theme.EmeraldSuccess
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopViewModel
import java.io.File
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    state: ShopUiState,
    viewModel: ShopViewModel,
    adMobManager: AdMobManager,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var period by remember { mutableStateOf("Monthly") } // Daily, Weekly, Monthly, Yearly, All Time
    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val rangeStart = remember(period) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        when (period) {
            "Daily" -> cal.timeInMillis
            "Weekly" -> { cal.add(Calendar.DAY_OF_YEAR, -6); cal.timeInMillis }
            "Monthly" -> { cal.set(Calendar.DAY_OF_MONTH, 1); cal.timeInMillis }
            "Yearly" -> { cal.set(Calendar.DAY_OF_YEAR, 1); cal.timeInMillis }
            else -> 0L
        }
    }

    val filteredSales = remember(state.sales, rangeStart) {
        state.sales.filter { it.createdAt >= rangeStart }
    }
    val filteredExpenses = remember(state.expenses, rangeStart) {
        state.expenses.filter { it.expenseDate >= rangeStart }
    }

    // Strict Accounting Rules:
    // Revenue = completed sales after discounts, excluding collected tax
    val netRevenueExclTax = filteredSales.sumOf { AccountingCalculator.roundMoney(it.grandTotal - it.taxAmount) }
    val taxCollected = filteredSales.sumOf { it.taxAmount }
    val cogs = filteredSales.sumOf { it.totalCost }
    val grossProfit = filteredSales.sumOf { it.grossProfit }
    val totalExpenses = filteredExpenses.sumOf { it.amount }
    val netProfit = AccountingCalculator.calculateNetProfit(grossProfit, totalExpenses)

    // Cash collected vs unpaid credit (no double-counting)
    val cashCollectedAtCheckout = filteredSales.sumOf { it.paidAmount }
    val creditIssued = filteredSales.sumOf { it.balanceDue }
    val inventoryValuationCost = state.products.sumOf { it.purchasePrice * it.quantity }
    val totalCustomerReceivable = state.customers.sumOf { it.outstandingBalance }
    val totalSupplierPayable = state.suppliers.sumOf { it.outstandingBalance }

    val saleIdsInPeriod = remember(filteredSales) { filteredSales.map { it.id }.toSet() }
    val bestSellers = remember(state.saleItems, saleIdsInPeriod) {
        state.saleItems.filter { it.saleId in saleIdsInPeriod }
            .groupBy { it.productName }
            .map { (name, lines) -> Triple(name, lines.sumOf { it.quantity }, lines.sumOf { it.lineProfit }) }
            .sortedByDescending { it.second }
            .take(5)
    }

    val soldQtyByProduct = remember(state.saleItems, saleIdsInPeriod) {
        state.saleItems.filter { it.saleId in saleIdsInPeriod }
            .groupBy { it.productId }
            .mapValues { e -> e.value.sumOf { it.quantity } }
    }
    val slowMovers = remember(state.products, soldQtyByProduct) {
        state.products.filter { (soldQtyByProduct[it.id] ?: 0) == 0 && it.quantity > 0 }.take(5)
    }

    val paymentBreakdown = remember(filteredSales) {
        filteredSales.groupBy { it.paymentMethod }
            .mapValues { e -> e.value.sumOf { it.grandTotal } }
            .entries.sortedByDescending { it.value }
    }

    val remainingMs = (cfg.analyticsPackUnlockedUntilMs - System.currentTimeMillis()).coerceAtLeast(0L)
    val rewardActive = remainingMs > 0L
    val remainingHours = remainingMs / (60L * 60 * 1000)
    val remainingMins = (remainingMs % (60L * 60 * 1000)) / (60L * 1000)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reports & Analytics") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
                            val csvFile = File(dir, "DukaanSaathi_Report_${period}.csv")
                            val csv = buildString {
                                appendLine("Metric,Amount (${cfg.currencyCode})")
                                appendLine("Period,$period")
                                appendLine("Net Revenue (Excl Tax),$netRevenueExclTax")
                                appendLine("Tax Collected,$taxCollected")
                                appendLine("Cost of Goods Sold,$cogs")
                                appendLine("Gross Profit,$grossProfit")
                                appendLine("Operating Expenses,$totalExpenses")
                                appendLine("Net Profit,$netProfit")
                                appendLine("Cash Collected at Checkout,$cashCollectedAtCheckout")
                                appendLine("Unpaid Credit Issued,$creditIssued")
                                appendLine("Inventory Valuation (Cost),$inventoryValuationCost")
                                appendLine("Customer Outstanding Credit,$totalCustomerReceivable")
                                appendLine("Supplier Outstanding Payable,$totalSupplierPayable")
                            }
                            csvFile.writeText(csv)
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", csvFile)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Export Report CSV"))
                        }
                    ) {
                        Icon(Icons.Default.IosShare, contentDescription = "Export CSV")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("Daily", "Weekly", "Monthly", "Yearly", "All Time")) { p ->
                        FilterChip(
                            selected = period == p,
                            onClick = { period = p },
                            label = { Text(p) }
                        )
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    KpiCard(
                        title = "Net Revenue (Excl. Tax)",
                        value = fmt(netRevenueExclTax),
                        subtitle = "${filteredSales.size} sales · Tax ${fmt(taxCollected)}",
                        accentColor = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Gross Profit",
                        value = fmt(grossProfit),
                        subtitle = "COGS: ${fmt(cogs)}",
                        accentColor = EmeraldSuccess,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    KpiCard(
                        title = "Operating Expenses",
                        value = fmt(totalExpenses),
                        subtitle = "${filteredExpenses.size} entries",
                        accentColor = CrimsonError,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Net Profit",
                        value = fmt(netProfit),
                        subtitle = "Gross Profit - Expenses",
                        accentColor = if (netProfit >= 0) EmeraldSuccess else CrimsonError,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                SectionCard {
                    Text("Accounting & Balance Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    ReportRow("Cash Collected at Checkout", fmt(cashCollectedAtCheckout))
                    ReportRow("Unpaid Credit Issued (Period)", fmt(creditIssued))
                    ReportRow("Inventory Valuation (at Cost)", fmt(inventoryValuationCost))
                    ReportRow("Customer Credit Receivable (All-Time)", fmt(totalCustomerReceivable))
                    ReportRow("Supplier Payable Balance (All-Time)", fmt(totalSupplierPayable))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Accounting note: Net revenue excludes user-configured collected taxes. Gross profit subtracts actual purchase COGS and discounts. Unpaid credit is tracked separately from cash receipts to avoid double-counting.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                if (rewardActive) {
                    SectionCard {
                        Text("Bonus Margin Highlight (${remainingHours}h ${remainingMins}m left)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = BlueAccent)
                        Spacer(Modifier.height(6.dp))
                        if (netRevenueExclTax > 0) {
                            val grossMarginPct = (grossProfit / netRevenueExclTax) * 100.0
                            val netMarginPct = (netProfit / netRevenueExclTax) * 100.0
                            ReportRow("Gross Margin %", "${String.format(Locale.US, "%.1f", grossMarginPct)}%")
                            ReportRow("Net Margin %", "${String.format(Locale.US, "%.1f", netMarginPct)}%")
                        } else {
                            Text(
                                text = "Bonus active — record sales in this period to view Gross & Net Margin %.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    SectionCard {
                        Text("Optional Margin % Highlight", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Watch an optional video ad to highlight Gross & Net Margin % for 24 hours. All revenue, profit, and CSV exports remain free offline.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (activity == null) {
                                    viewModel.emitMessage("Video ad unavailable right now. All core reports remain accessible.")
                                    return@Button
                                }
                                adMobManager.showRewardedAd(
                                    activity = activity,
                                    onRewardEarned = { viewModel.unlockAnalyticsPack24h() },
                                    onClosedWithoutReward = {
                                        viewModel.emitMessage("Watch the full video to unlock the 24-hour Margin % Highlight card.")
                                    },
                                    onUnavailable = {
                                        viewModel.emitMessage("No video ad available offline or right now. Core revenue, profit & CSV export remain free.")
                                    }
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.PlayCircleOutline, contentDescription = null)
                            Spacer(Modifier.size(6.dp))
                            Text("Watch Ad to Unlock (24h)")
                        }
                    }
                }
            }

            if (paymentBreakdown.isNotEmpty()) {
                item {
                    SectionCard {
                        Text("Payment Method Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        paymentBreakdown.forEach { (method, amt) ->
                            ReportRow(method, fmt(amt))
                        }
                    }
                }
            }

            if (bestSellers.isNotEmpty()) {
                item {
                    SectionCard {
                        Text("Best-Selling Products ($period)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        bestSellers.forEach { (name, qty, profit) ->
                            ReportRow("$name ($qty pcs)", "Profit ${fmt(profit)}")
                        }
                    }
                }
            }

            if (slowMovers.isNotEmpty()) {
                item {
                    SectionCard {
                        Text("Slow-Moving Stock (0 sales in $period)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = AmberWarning)
                        Spacer(Modifier.height(8.dp))
                        slowMovers.forEach { p ->
                            ReportRow("${p.name} (${p.quantity} pcs)", fmt(p.purchasePrice * p.quantity))
                        }
                    }
                }
            }

            // Non-intrusive Native Ad separated cleanly from financial figures
            item {
                NativeAdCard()
            }
        }
    }
}

@Composable
private fun ReportRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}
