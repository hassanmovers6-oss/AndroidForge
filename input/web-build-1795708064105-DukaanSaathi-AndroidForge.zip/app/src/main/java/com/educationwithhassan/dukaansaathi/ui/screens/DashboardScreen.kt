package com.educationwithhassan.dukaansaathi.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.educationwithhassan.dukaansaathi.ads.NativeAdCard
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.ui.components.ChartBarPoint
import com.educationwithhassan.dukaansaathi.ui.components.EmptyStateView
import com.educationwithhassan.dukaansaathi.ui.components.KpiCard
import com.educationwithhassan.dukaansaathi.ui.components.SectionCard
import com.educationwithhassan.dukaansaathi.ui.components.SimpleBarChart
import com.educationwithhassan.dukaansaathi.ui.components.formatTimestamp
import com.educationwithhassan.dukaansaathi.ui.theme.AmberWarning
import com.educationwithhassan.dukaansaathi.ui.theme.BlueAccent
import com.educationwithhassan.dukaansaathi.ui.theme.CrimsonError
import com.educationwithhassan.dukaansaathi.ui.theme.EmeraldSuccess
import com.educationwithhassan.dukaansaathi.ui.viewmodel.ShopUiState
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    state: ShopUiState,
    onNewSale: () -> Unit,
    onAddProduct: () -> Unit,
    onAddExpense: () -> Unit,
    onAddCustomer: () -> Unit,
    onViewReports: () -> Unit,
    onScanBarcode: () -> Unit,
    onOpenSaleReceipt: (Long) -> Unit,
    onOpenProducts: () -> Unit,
    onOpenCustomers: () -> Unit
) {
    val cfg = state.config
    val fmt = { amount: Double -> CurrencyFormatter.format(amount, cfg.currencyCode, cfg.currencySymbol) }

    val startOfToday = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val todaySales = state.sales.filter { it.createdAt >= startOfToday }
    val todaySalesTotal = todaySales.sumOf { it.grandTotal }
    val todayProfit = todaySales.sumOf { it.grossProfit }
    val totalExpenses = state.expenses.sumOf { it.amount }
    val totalCreditDue = state.customers.sumOf { it.outstandingBalance }

    var chartPeriod by remember { mutableIntStateOf(0) } // 0 = Weekly (7 days), 1 = Monthly (6 months)

    val weeklyPoints = remember(state.sales) {
        val dayFmt = SimpleDateFormat("EEE", Locale.US)
        (6 downTo 0).map { offset ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -offset)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val dayStart = cal.timeInMillis
            val dayEnd = dayStart + 24L * 60 * 60 * 1000 - 1
            val sum = state.sales.filter { it.createdAt in dayStart..dayEnd }.sumOf { it.grandTotal }
            ChartBarPoint(dayFmt.format(Date(dayStart)), sum)
        }
    }

    val monthlyPoints = remember(state.sales) {
        val monthFmt = SimpleDateFormat("MMM", Locale.US)
        (5 downTo 0).map { offset ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.MONTH, -offset)
            cal.set(Calendar.DAY_OF_MONTH, 1)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val mStart = cal.timeInMillis
            cal.add(Calendar.MONTH, 1)
            val mEnd = cal.timeInMillis - 1
            val sum = state.sales.filter { it.createdAt in mStart..mEnd }.sumOf { it.grandTotal }
            ChartBarPoint(monthFmt.format(Date(mStart)), sum)
        }
    }

    val bestSellers = remember(state.saleItems) {
        state.saleItems.groupBy { it.productName }
            .map { (name, lines) -> Triple(name, lines.sumOf { it.quantity }, lines.sumOf { it.lineTotal }) }
            .sortedByDescending { it.second }
            .take(5)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = cfg.shopName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Offline Business Dashboard · ${cfg.currencyCode}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Quick Actions Row
        item {
            val actions = listOf(
                Triple("New Sale", Icons.Default.PointOfSale, onNewSale),
                Triple("Add Product", Icons.Default.AddBox, onAddProduct),
                Triple("Add Expense", Icons.Default.ReceiptLong, onAddExpense),
                Triple("Add Customer", Icons.Default.PersonAdd, onAddCustomer),
                Triple("Reports", Icons.Default.Assessment, onViewReports),
                Triple("Scan Barcode", Icons.Default.QrCodeScanner, onScanBarcode)
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(actions) { (label, icon, onClick) ->
                    QuickActionButton(label = label, icon = icon, onClick = onClick)
                }
            }
        }

        // KPI Grid Row 1
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Today's Sales",
                    value = fmt(todaySalesTotal),
                    subtitle = "${todaySales.size} invoice(s)",
                    accentColor = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f),
                    onClick = onNewSale
                )
                KpiCard(
                    title = "Today's Gross Profit",
                    value = fmt(todayProfit),
                    subtitle = "After COGS & discounts",
                    accentColor = EmeraldSuccess,
                    modifier = Modifier.weight(1f),
                    onClick = onViewReports
                )
            }
        }

        // KPI Grid Row 2
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Expenses",
                    value = fmt(totalExpenses),
                    subtitle = "${state.expenses.size} entries",
                    accentColor = CrimsonError,
                    modifier = Modifier.weight(1f),
                    onClick = onAddExpense
                )
                KpiCard(
                    title = "Customer Credit Due",
                    value = fmt(totalCreditDue),
                    subtitle = "${state.customers.size} total customers",
                    accentColor = AmberWarning,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenCustomers
                )
            }
        }

        // KPI Grid Row 3
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Products",
                    value = state.products.size.toString(),
                    subtitle = "${state.products.sumOf { it.quantity }} units in stock",
                    accentColor = BlueAccent,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenProducts
                )
                KpiCard(
                    title = "Low-Stock Alerts",
                    value = state.lowStockProducts.size.toString(),
                    subtitle = if (state.lowStockProducts.isEmpty()) "All stocked" else "Needs restock",
                    accentColor = if (state.lowStockProducts.isNotEmpty()) CrimsonError else EmeraldSuccess,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenProducts
                )
            }
        }

        // Empty state for brand new user
        if (state.products.isEmpty() && state.sales.isEmpty() && state.customers.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.Storefront,
                    title = "Your shop ledger is ready",
                    description = "Add your first product or customer to start recording sales, tracking inventory, and viewing real profit analytics.",
                    actionLabel = "Add First Product",
                    onAction = onAddProduct
                )
            }
        } else {
            // Weekly & Monthly Sales Chart
            item {
                SectionCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (chartPeriod == 0) "Weekly Sales" else "Monthly Sales",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        SingleChoiceSegmentedButtonRow {
                            SegmentedButton(
                                selected = chartPeriod == 0,
                                onClick = { chartPeriod = 0 },
                                shape = SegmentedButtonDefaults.itemShape(0, 2)
                            ) { Text("7D") }
                            SegmentedButton(
                                selected = chartPeriod == 1,
                                onClick = { chartPeriod = 1 },
                                shape = SegmentedButtonDefaults.itemShape(1, 2)
                            ) { Text("6M") }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    SimpleBarChart(
                        points = if (chartPeriod == 0) weeklyPoints else monthlyPoints,
                        barColor = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            // Best-Selling Products
            if (bestSellers.isNotEmpty()) {
                item {
                    SectionCard {
                        Text(
                            text = "Best-Selling Products",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        bestSellers.forEachIndexed { idx, (name, qty, total) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${idx + 1}. $name",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "$qty units sold",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = fmt(total),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            if (idx < bestSellers.lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                        }
                    }
                }
            }

            // Recent Transactions
            if (state.sales.isNotEmpty()) {
                item {
                    SectionCard {
                        Text(
                            text = "Recent Transactions",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        state.sales.take(6).forEachIndexed { idx, sale ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenSaleReceipt(sale.id) }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${sale.invoiceNumber} · ${sale.customerName}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${formatTimestamp(sale.createdAt)} · ${sale.paymentMethod}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = fmt(sale.grandTotal),
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (sale.balanceDue > 0.009) {
                                        Text(
                                            text = "Due ${fmt(sale.balanceDue)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = CrimsonError
                                        )
                                    }
                                }
                            }
                            if (idx < minOf(5, state.sales.lastIndex)) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                        }
                    }
                }
            }
        }

        // Non-intrusive Native Ad separated from primary controls & KPIs
        item {
            NativeAdCard()
        }
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
