package com.educationwithhassan.dukaansaathi.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.educationwithhassan.dukaansaathi.R
import com.educationwithhassan.dukaansaathi.data.local.DukaanDatabase
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import java.util.concurrent.TimeUnit

class ReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = DukaanDatabase.getInstance(applicationContext)
        val config = db.shopConfigDao().getConfigOnce() ?: return Result.success()
        if (!config.paymentRemindersEnabled) return Result.success()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                applicationContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return Result.success()
        }

        val customers = db.customerDao().getAllCustomersOnce()
        val dueCustomers = customers.filter { it.outstandingBalance > 0.009 }
        val lowStockCount = db.productDao().getAllProductsOnce().count { it.quantity <= it.minStockLevel }

        if (dueCustomers.isEmpty() && lowStockCount == 0) return Result.success()

        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Shop Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }

        val totalDue = dueCustomers.sumOf { it.outstandingBalance }
        val parts = mutableListOf<String>()
        if (dueCustomers.isNotEmpty()) {
            val formatted = CurrencyFormatter.format(totalDue, config.currencyCode, config.currencySymbol)
            parts.add("${dueCustomers.size} customer(s) owe $formatted")
        }
        if (lowStockCount > 0) {
            parts.add("$lowStockCount product(s) low on stock")
        }

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("${config.shopName} Daily Summary")
            .setContentText(parts.joinToString(" · "))
            .setAutoCancel(true)
            .build()

        manager.notify(1001, notification)
        return Result.success()
    }

    companion object {
        private const val CHANNEL_ID = "dukaan_saathi_reminders"
        private const val WORK_NAME = "dukaan_daily_reminder"

        fun scheduleDailyReminder(context: Context, enabled: Boolean) {
            val wm = WorkManager.getInstance(context)
            if (!enabled) {
                wm.cancelUniqueWork(WORK_NAME)
                return
            }
            val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
            wm.enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
