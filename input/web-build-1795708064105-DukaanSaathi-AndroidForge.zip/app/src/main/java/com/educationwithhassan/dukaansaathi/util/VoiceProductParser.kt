package com.educationwithhassan.dukaansaathi.util

data class ParsedVoiceProduct(
    val name: String = "",
    val quantity: String = "",
    val purchasePrice: String = "",
    val sellingPrice: String = "",
    val category: String = ""
)

object VoiceProductParser {

    /**
     * Parses spoken phrases such as:
     * "Basmati Rice quantity 25 purchase price 180 selling price 220 category Grocery"
     * Users can always review and manually edit every field before saving.
     */
    fun parse(transcript: String): ParsedVoiceProduct {
        val cleaned = transcript.trim()
        if (cleaned.isEmpty()) return ParsedVoiceProduct()

        val qtyRegex = Regex("""(?:quantity|qty|stock|count)\s+(\d+)""", RegexOption.IGNORE_CASE)
        val purchaseRegex = Regex("""(?:purchase\s*price|cost\s*price|cost|buy\s*price|bought\s*for)\s+(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
        val sellingRegex = Regex("""(?:selling\s*price|sell\s*price|sale\s*price|price)\s+(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
        val categoryRegex = Regex("""(?:category|group|type)\s+([A-Za-z0-9 &/-]+)""", RegexOption.IGNORE_CASE)

        val quantity = qtyRegex.find(cleaned)?.groupValues?.getOrNull(1).orEmpty()
        val purchasePrice = purchaseRegex.find(cleaned)?.groupValues?.getOrNull(1).orEmpty()
        val sellingPrice = sellingRegex.find(cleaned)?.groupValues?.getOrNull(1).orEmpty()
        val categoryRaw = categoryRegex.find(cleaned)?.groupValues?.getOrNull(1)?.trim().orEmpty()

        // Name is everything before the first recognized keyword
        val keywordStarts = listOfNotNull(
            qtyRegex.find(cleaned)?.range?.first,
            purchaseRegex.find(cleaned)?.range?.first,
            sellingRegex.find(cleaned)?.range?.first,
            categoryRegex.find(cleaned)?.range?.first
        )
        val firstKeywordIdx = keywordStarts.minOrNull() ?: cleaned.length
        val name = cleaned.substring(0, firstKeywordIdx).trim()
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }

        val category = categoryRaw.split(Regex("""\s+(?:quantity|qty|purchase|selling|price|cost)\b""", RegexOption.IGNORE_CASE))
            .firstOrNull()?.trim().orEmpty()
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }

        return ParsedVoiceProduct(
            name = name,
            quantity = quantity,
            purchasePrice = purchasePrice,
            sellingPrice = sellingPrice,
            category = category
        )
    }
}
