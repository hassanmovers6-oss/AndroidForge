package com.educationwithhassan.dukaansaathi.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "shop_config")
data class ShopConfigEntity(
    @PrimaryKey val id: Int = 1,
    val shopName: String = "My Shop",
    val shopAddress: String = "",
    val phone: String = "",
    val email: String = "",
    val currencyCode: String = "USD",
    val currencySymbol: String = "$",
    val taxEnabled: Boolean = false,
    val defaultTaxPercent: Double = 0.0,
    val taxInclusive: Boolean = false,
    val receiptHeader: String = "Thank you for shopping with us!",
    val receiptFooter: String = "Please keep this receipt for your records.",
    val lowStockThreshold: Int = 5,
    val allowNegativeInventory: Boolean = false,
    val themeMode: String = "SYSTEM", // SYSTEM, LIGHT, DARK
    val paymentRemindersEnabled: Boolean = true,
    val setupCompleted: Boolean = false,
    val logoPath: String = "",
    val analyticsPackUnlockedUntilMs: Long = 0L
)

@Entity(
    tableName = "products",
    indices = [
        Index(value = ["barcode"]),
        Index(value = ["sku"]),
        Index(value = ["category"])
    ]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val sku: String = "",
    val barcode: String = "",
    val category: String = "General",
    val brand: String = "",
    val purchasePrice: Double,
    val sellingPrice: Double,
    val quantity: Int,
    val minStockLevel: Int = 5,
    val description: String = "",
    val imageUri: String = "",
    val supplierId: Long? = null,
    val supplierName: String = "",
    val taxPercentOverride: Double? = null,
    val dateAdded: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_adjustments",
    indices = [Index(value = ["productId"])]
)
data class StockAdjustmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val productId: Long,
    val productName: String,
    val previousQty: Int,
    val newQty: Int,
    val deltaQty: Int,
    val reason: String,
    val referenceId: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "customers",
    indices = [Index(value = ["fullName"]), Index(value = ["phone"])]
)
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val fullName: String,
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val totalPurchases: Double = 0.0,
    val outstandingBalance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sales",
    indices = [
        Index(value = ["invoiceNumber"], unique = true),
        Index(value = ["customerId"]),
        Index(value = ["createdAt"])
    ]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val invoiceNumber: String,
    val customerId: Long? = null,
    val customerName: String = "Walk-in Customer",
    val subtotal: Double,
    val discountAmount: Double,
    val taxAmount: Double,
    val grandTotal: Double,
    val totalCost: Double,
    val grossProfit: Double,
    val paidAmount: Double,
    val balanceDue: Double,
    val paymentMethod: String, // Cash, Card, Other, Split, Credit
    val splitCashAmount: Double = 0.0,
    val splitCardAmount: Double = 0.0,
    val splitOtherAmount: Double = 0.0,
    val taxIncludedInPrice: Boolean = false,
    val currencyCode: String = "USD",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(
            entity = SaleEntity::class,
            parentColumns = ["id"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["saleId"]), Index(value = ["productId"])]
)
data class SaleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double,
    val discountAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val lineTotal: Double,
    val lineProfit: Double
)

@Entity(
    tableName = "customer_payments",
    indices = [Index(value = ["customerId"]), Index(value = ["saleId"])]
)
data class CustomerPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val customerId: Long,
    val customerName: String,
    val saleId: Long? = null,
    val amount: Double,
    val paymentMethod: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "expenses",
    indices = [Index(value = ["category"]), Index(value = ["expenseDate"])]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val category: String,
    val amount: Double,
    val notes: String = "",
    val expenseDate: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "suppliers",
    indices = [Index(value = ["name"])]
)
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val totalPurchased: Double = 0.0,
    val outstandingBalance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "purchase_orders",
    indices = [Index(value = ["supplierId"]), Index(value = ["createdAt"])]
)
data class PurchaseOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val supplierId: Long,
    val supplierName: String,
    val invoiceRef: String,
    val totalAmount: Double,
    val paidAmount: Double,
    val balanceDue: Double,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "purchase_items",
    foreignKeys = [
        ForeignKey(
            entity = PurchaseOrderEntity::class,
            parentColumns = ["id"],
            childColumns = ["purchaseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["purchaseId"]), Index(value = ["productId"])]
)
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val purchaseId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val unitCost: Double,
    val lineTotal: Double
)

@Entity(
    tableName = "supplier_payments",
    indices = [Index(value = ["supplierId"]), Index(value = ["purchaseId"])]
)
data class SupplierPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val supplierId: Long,
    val supplierName: String,
    val purchaseId: Long? = null,
    val amount: Double,
    val paymentMethod: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
