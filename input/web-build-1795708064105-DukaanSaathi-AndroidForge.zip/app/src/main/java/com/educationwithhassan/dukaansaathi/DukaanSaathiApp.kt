package com.educationwithhassan.dukaansaathi

import android.app.Application
import com.educationwithhassan.dukaansaathi.ads.AdMobManager
import com.educationwithhassan.dukaansaathi.data.local.DukaanDatabase
import com.educationwithhassan.dukaansaathi.data.repository.ShopRepository
import com.educationwithhassan.dukaansaathi.util.ReminderWorker

class DukaanSaathiApp : Application() {

    val database: DukaanDatabase by lazy { DukaanDatabase.getInstance(this) }
    val repository: ShopRepository by lazy { ShopRepository(database) }
    val adMobManager: AdMobManager by lazy { AdMobManager(this) }

    override fun onCreate() {
        super.onCreate()
        adMobManager.initialize()
        ReminderWorker.scheduleDailyReminder(this, enabled = true)
    }
}
