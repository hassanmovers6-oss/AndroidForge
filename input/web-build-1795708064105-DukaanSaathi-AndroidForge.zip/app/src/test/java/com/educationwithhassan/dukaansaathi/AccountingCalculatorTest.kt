package com.educationwithhassan.dukaansaathi

import com.educationwithhassan.dukaansaathi.domain.AccountingCalculator
import com.educationwithhassan.dukaansaathi.domain.CartLineInput
import com.educationwithhassan.dukaansaathi.domain.CurrencyFormatter
import com.educationwithhassan.dukaansaathi.util.VoiceProductParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AccountingCalculatorTest {

    @Test
    fun exclusiveTaxAndDiscountCalculatesExactProfit() {
        // 2 units @ selling 100, cost 60 -> gross 200, cost 120
        // order discount = 20 -> net sales excl tax = 180
        // exclusive tax 10% = 18 -> grand total = 198
        // gross profit = 180 - 120 = 60 (tax never inflates profit)
        val summary = AccountingCalculator.calculateCart(
            items = listOf(
                CartLineInput(
                    productId = 1L,
                    productName = "Rice Bag",
                    quantity = 2,
                    unitPrice = 100.0,
                    unitCost = 60.0
                )
            ),
            orderDiscountAmount = 20.0,
            taxEnabled = true,
            defaultTaxPercent = 10.0,
            taxInclusive = false
        )

        assertEquals(200.0, summary.subtotalBeforeDiscount, 0.01)
        assertEquals(20.0, summary.totalDiscount, 0.01)
        assertEquals(180.0, summary.netSalesExclTax, 0.01)
        assertEquals(18.0, summary.totalTax, 0.01)
        assertEquals(198.0, summary.grandTotal, 0.01)
        assertEquals(120.0, summary.totalCost, 0.01)
        assertEquals(60.0, summary.grossProfit, 0.01)
    }

    @Test
    fun inclusiveTaxExtractsTaxFromShelfPrice() {
        // 1 unit @ 110 shelf price (inclusive of 10% tax), cost 70
        // net sales = 100, tax = 10, grand total = 110, gross profit = 100 - 70 = 30
        val summary = AccountingCalculator.calculateCart(
            items = listOf(
                CartLineInput(
                    productId = 2L,
                    productName = "Cooking Oil",
                    quantity = 1,
                    unitPrice = 110.0,
                    unitCost = 70.0
                )
            ),
            orderDiscountAmount = 0.0,
            taxEnabled = true,
            defaultTaxPercent = 10.0,
            taxInclusive = true
        )

        assertEquals(100.0, summary.netSalesExclTax, 0.01)
        assertEquals(10.0, summary.totalTax, 0.01)
        assertEquals(110.0, summary.grandTotal, 0.01)
        assertEquals(30.0, summary.grossProfit, 0.01)
    }

    @Test
    fun netProfitSubtractsOperatingExpenses() {
        val netProfit = AccountingCalculator.calculateNetProfit(grossProfit = 500.0, totalOperatingExpenses = 175.50)
        assertEquals(324.50, netProfit, 0.01)
    }

    @Test
    fun creditBalanceCalculatesRemainingCorrectly() {
        val remaining = AccountingCalculator.calculateRemainingBalance(grandTotal = 250.0, paidAmount = 100.0)
        assertEquals(150.0, remaining, 0.01)
    }

    @Test
    fun currencyFormattingSupportsWorldwideCurrencies() {
        assertEquals("$1,250.50", CurrencyFormatter.format(1250.5, "USD"))
        assertEquals("Rs.1,250.00", CurrencyFormatter.format(1250.0, "PKR"))
        assertEquals("¥1,250", CurrencyFormatter.format(1250.0, "JPY"))
    }

    @Test
    fun voiceProductParserExtractsSpokenFields() {
        val parsed = VoiceProductParser.parse(
            "Basmati Rice quantity 25 purchase price 180 selling price 220 category Grocery"
        )
        assertTrue(parsed.name.contains("Basmati Rice"))
        assertEquals("25", parsed.quantity)
        assertEquals("180", parsed.purchasePrice)
        assertEquals("220", parsed.sellingPrice)
        assertEquals("Grocery", parsed.category)
    }
}
