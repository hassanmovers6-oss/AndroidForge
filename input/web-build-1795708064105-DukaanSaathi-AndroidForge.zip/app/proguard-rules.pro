# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Gson backup models
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.educationwithhassan.dukaansaathi.data.local.entity.** { *; }
-keep class com.educationwithhassan.dukaansaathi.util.BackupPayload { *; }
-keep class com.educationwithhassan.dukaansaathi.util.BackupMetadata { *; }

# Google Mobile Ads
-keep class com.google.android.gms.ads.** { *; }

# ML Kit Barcode
-keep class com.google.mlkit.vision.barcode.** { *; }
