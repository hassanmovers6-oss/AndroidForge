# Dukaan Saathi – Smart Shop Manager (Android)

**Package:** `com.educationwithhassan.dukaansaathi`  
**App Name:** `Dukaan Saathi`  
**Stack:** Kotlin 2.0.21 · Jetpack Compose · Material 3 · Room Database · Navigation Compose · CameraX + ML Kit · Google AdMob · WorkManager

## Features Implemented
- **Offline-First Room Database** (`DukaanDatabase.kt`) with 12 entities, explicit `MIGRATION_1_2`, and atomic `@Transaction` operations.
- **First-Launch Setup Wizard**: Shop profile, 17 worldwide currencies, and user-configured tax rules (inclusive/exclusive + per-product override). No compulsory login.
- **Dashboard**: Real-time KPIs from Room, Weekly (7D) & Monthly (6M) Compose Canvas charts, Best-Sellers, Recent Transactions, Quick Actions, and non-intrusive Banner Ad.
- **Inventory Management**: Full CRUD, search, category filters, sorting, CameraX + ML Kit barcode scanner, optional Voice Product Entry (`RecognizerIntent`), low/out-of-stock alerts, stock adjustment history, and inventory cost valuation.
- **Point of Sale (POS)**: Fast cart, line/order discounts, tax calculation, Cash/Card/Other/Split/Credit payments, atomic inventory deduction, accurate COGS gross profit, and PDF receipt generation/printing/sharing (`PdfDocument` + `PrintManager` + `FileProvider`).
- **Customers & Udhaar Credit Ledger**: Customer profiles, credit sales, partial/full payment collection (preserving full history), and shareable/printable PDF customer statements.
- **Expenses & Suppliers**: Categorized expenses with date/search filters; Supplier purchase orders that atomically restock inventory and track supplier payables.
- **Reports & Analytics**: Daily/Weekly/Monthly/Yearly/All-Time reports, strict accounting rules (revenue excludes collected tax; unpaid credit is never double-counted as cash), and CSV export.
- **Offline Business Insights Assistant**: Answers questions directly from local Room records with zero external PII exposure.
- **Backup & Restore**: Checksum-verified JSON export and atomic transactional restore with overwrite confirmation.
- **Google AdMob Integration**: Centralized internal `AdMobManager` with Banner, Interstitial (120s cooldown), Rewarded (opt-in), Native (labeled "Ad"), and App Open ads, with zero user-facing AdMob settings or ID exposure.

## Building an APK with AndroidForge (ZIP-to-APK)
1. Download the `DukaanSaathi-AndroidForge.zip` archive.
2. Upload the ZIP directly to **AndroidForge** and select **Build Release APK**.
3. Wait for Gradle to resolve dependencies and produce `app-release.apk`.

## Building Locally via Gradle CLI (Optional)
```bash
# Run unit tests
./gradlew testDebugUnitTest

# Build debug APK
./gradlew assembleDebug

# Build release APK (configure signingConfig in app/build.gradle.kts for Play Store distribution)
./gradlew assembleRelease
```
