# Keep Math vs Bat data models, WebView JS bridge, & AdMob callbacks
-keepattributes *Annotation*,JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.educationwithhassan.mathvsbat.MainActivity$* { *; }
-keep class com.educationwithhassan.mathvsbat.model.** { *; }
-keep class com.educationwithhassan.mathvsbat.ads.** { *; }
-keep class com.google.android.gms.ads.** { *; }
