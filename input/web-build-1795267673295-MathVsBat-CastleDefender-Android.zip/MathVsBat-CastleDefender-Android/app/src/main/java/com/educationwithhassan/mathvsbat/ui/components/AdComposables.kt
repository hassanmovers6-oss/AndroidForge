package com.educationwithhassan.mathvsbat.ui.components

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button as AndroidNativeButton
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.mathvsbat.R
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import kotlinx.coroutines.delay

private enum class BannerLoadState { LOADING, LOADED, FAILED }

@Composable
fun AdaptiveBannerAd(modifier: Modifier = Modifier) {
    val isAdsReady by AdMobManager.isAdsSdkReady.collectAsState()
    val canRequestAds by AdMobManager.canRequestAdsFlow.collectAsState()
    if (!isAdsReady || !canRequestAds) return

    val context = LocalContext.current
    val widthDp = LocalConfiguration.current.screenWidthDp.coerceAtLeast(320)
    var bannerState by remember(widthDp) { mutableStateOf(BannerLoadState.LOADING) }
    var retryCount by remember(widthDp) { mutableIntStateOf(0) }

    val adView = remember(widthDp) {
        AdView(context).apply {
            adUnitId = AdMobManager.bannerUnitId()
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp))
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d("MathVsBatAds", "Banner ad loaded")
                    bannerState = BannerLoadState.LOADED
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    Log.e("MathVsBatAds", "Banner failed (${err.code} / ${err.domain}): ${err.message}")
                    bannerState = BannerLoadState.FAILED
                }
            }
            loadAd(AdRequest.Builder().build())
        }
    }

    LaunchedEffect(bannerState, retryCount) {
        if (bannerState == BannerLoadState.FAILED && retryCount < 2) {
            delay(15_000L)
            retryCount++
            bannerState = BannerLoadState.LOADING
            adView.loadAd(AdRequest.Builder().build())
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    if (bannerState == BannerLoadState.FAILED) {
        return
    }

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        if (bannerState == BannerLoadState.LOADED) {
            AndroidView(factory = { adView }, modifier = Modifier.fillMaxWidth())
        } else {
            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}

@Composable
fun NativeAdBanner(modifier: Modifier = Modifier) {
    val isAdsReady by AdMobManager.isAdsSdkReady.collectAsState()
    val canRequestAds by AdMobManager.canRequestAdsFlow.collectAsState()
    if (!isAdsReady || !canRequestAds) return

    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(isAdsReady, canRequestAds) {
        var disposed = false
        AdMobManager.loadNativeAd(
            context = context,
            onLoaded = { ad ->
                if (disposed) {
                    ad.destroy()
                } else {
                    nativeAd?.destroy()
                    nativeAd = ad
                }
            },
            onFailed = { /* Keep UI clean when native fill unavailable */ }
        )
        onDispose {
            disposed = true
            nativeAd?.destroy()
            nativeAd = null
        }
    }

    val ad = nativeAd ?: return
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            val view = LayoutInflater.from(ctx).inflate(R.layout.native_ad_layout, null) as NativeAdView
            val headlineView = view.findViewById<TextView>(R.id.ad_headline)
            val bodyView = view.findViewById<TextView>(R.id.ad_body)
            val ctaView = view.findViewById<AndroidNativeButton>(R.id.ad_call_to_action)
            val iconView = view.findViewById<ImageView>(R.id.ad_app_icon)

            headlineView.text = ad.headline
            val bodyText = ad.body
            if (bodyText.isNullOrBlank()) {
                bodyView.visibility = View.GONE
            } else {
                bodyView.visibility = View.VISIBLE
                bodyView.text = bodyText
            }
            ctaView.text = ad.callToAction ?: "Learn More"
            val iconDrawable = ad.icon?.drawable
            if (iconDrawable != null) {
                iconView.visibility = View.VISIBLE
                iconView.setImageDrawable(iconDrawable)
            } else {
                iconView.visibility = View.GONE
            }

            view.headlineView = headlineView
            view.bodyView = bodyView
            view.callToActionView = ctaView
            view.iconView = iconView
            view.setNativeAd(ad)
            view
        }
    )
}
