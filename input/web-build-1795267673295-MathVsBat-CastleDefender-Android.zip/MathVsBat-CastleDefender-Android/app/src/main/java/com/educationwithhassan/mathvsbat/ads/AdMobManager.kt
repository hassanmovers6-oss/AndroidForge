package com.educationwithhassan.mathvsbat.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.educationwithhassan.mathvsbat.BuildConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Centralized AdMob Manager for com.educationwithhassan.mathvsbat.
 * Implements all 5 formats: App Open, Adaptive Banner, Interstitial, Native Advanced, and Rewarded.
 * Debug builds automatically select Google's official Test IDs; Release builds use supplied Production IDs.
 */
object AdMobManager : DefaultLifecycleObserver {

    private const val TAG = "MathVsBatAds"

    // Supplied Production Ad Unit IDs (Release builds)
    private const val PROD_APP_OPEN_ID = "ca-app-pub-3133971041724338/8379002010"
    private const val PROD_BANNER_ID = "ca-app-pub-3133971041724338/9142781786"
    private const val PROD_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/7638128425"
    private const val PROD_NATIVE_ID = "ca-app-pub-3133971041724338/7520999346"
    private const val PROD_REWARDED_ID = "ca-app-pub-3133971041724338/1281884898"

    // Official Google AdMob Test Ad Unit IDs (Debug builds)
    private const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    private const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    private const val APP_OPEN_COOLDOWN_MS = 4L * 60L * 60L * 1000L // 4 hours
    private const val INTERSTITIAL_COOLDOWN_MS = 3L * 60L * 1000L // 3 minutes
    private const val INTERSTITIAL_EVERY_N_LEVELS = 3

    private val handler = Handler(Looper.getMainLooper())
    private val isMobileAdsInitialized = AtomicBoolean(false)
    private val isShowingFullscreen = AtomicBoolean(false)

    private val _isAdsSdkReady = MutableStateFlow(false)
    val isAdsSdkReady: StateFlow<Boolean> = _isAdsSdkReady.asStateFlow()

    private val _canRequestAdsFlow = MutableStateFlow(false)
    val canRequestAdsFlow: StateFlow<Boolean> = _canRequestAdsFlow.asStateFlow()

    private val _adStatusLog = MutableStateFlow("Waiting for UMP consent check")
    val adStatusLog: StateFlow<String> = _adStatusLog.asStateFlow()

    private var currentActivityRef: WeakReference<Activity>? = null
    private var isGameplayActive: Boolean = false
    private var consentInformation: ConsentInformation? = null

    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadedAtMs: Long = 0L
    private var lastAppOpenShownAtMs: Long = 0L
    private var appOpenLoading: Boolean = false

    private var interstitialAd: InterstitialAd? = null
    private var lastInterstitialShownAtMs: Long = 0L
    private var levelsCompletedCounter: Int = 0
    private var interstitialRetryCount: Int = 0
    private var interstitialLoading: Boolean = false

    private var rewardedAd: RewardedAd? = null
    private var rewardedRetryCount: Int = 0
    private var rewardedLoading: Boolean = false
    private var lastFullscreenEndedAtMs: Long = 0L

    fun appOpenUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_APP_OPEN_ID else PROD_APP_OPEN_ID
    fun bannerUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_BANNER_ID else PROD_BANNER_ID
    fun interstitialUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_INTERSTITIAL_ID else PROD_INTERSTITIAL_ID
    fun nativeUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_NATIVE_ID else PROD_NATIVE_ID
    fun rewardedUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_REWARDED_ID else PROD_REWARDED_ID

    fun setCurrentActivity(activity: Activity?) {
        currentActivityRef = if (activity != null) WeakReference(activity) else null
    }

    fun setGameplayActive(active: Boolean) {
        isGameplayActive = active
    }

    fun canRequestAds(): Boolean = _canRequestAdsFlow.value

    fun initialize(activity: Activity) {
        setCurrentActivity(activity)
        val appContext = activity.applicationContext
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()
        val info = UserMessagingPlatform.getConsentInformation(activity)
        consentInformation = info

        if (info.canRequestAds()) {
            _canRequestAdsFlow.value = true
            startMobileAdsSdk(appContext)
        }

        info.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w(TAG, "UMP form error (${formError.errorCode}): ${formError.message}")
                    }
                    val allowed = info.canRequestAds()
                    _canRequestAdsFlow.value = allowed
                    _adStatusLog.value = if (allowed) "Consent granted" else "Consent blocked ads"
                    if (allowed) {
                        startMobileAdsSdk(appContext)
                    }
                }
            },
            { formError ->
                Log.e(TAG, "UMP consent update failed (${formError.errorCode}): ${formError.message}")
                // On offline cold start or when no UMP message is published yet (UNKNOWN status),
                // allow AdMob SDK initialization instead of permanently blocking all ads.
                val allowFallback = info.canRequestAds() ||
                    info.consentStatus == ConsentInformation.ConsentStatus.UNKNOWN
                _canRequestAdsFlow.value = allowFallback
                _adStatusLog.value = "UMP fallback (${formError.errorCode}): allow=$allowFallback"
                if (allowFallback) {
                    startMobileAdsSdk(appContext)
                }
            }
        )
    }

    fun showPrivacyOptionsForm(activity: Activity, onComplete: () -> Unit) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
            if (formError != null) {
                Log.w(TAG, "Privacy options error (${formError.errorCode}): ${formError.message}")
            }
            val allowed = consentInformation?.canRequestAds() ?: true
            _canRequestAdsFlow.value = allowed
            if (allowed) {
                startMobileAdsSdk(activity.applicationContext)
            }
            onComplete()
        }
    }

    private fun startMobileAdsSdk(context: Context) {
        if (!isMobileAdsInitialized.compareAndSet(false, true)) return
        val appContext = context.applicationContext
        try {
            Log.d(TAG, "Initializing MobileAds SDK (USE_TEST_ADS=${BuildConfig.USE_TEST_ADS})")
            MobileAds.initialize(appContext) { initStatus ->
                Log.d(TAG, "MobileAds initialized adapters: ${initStatus.adapterStatusMap.keys}")
                handler.post {
                    _isAdsSdkReady.value = true
                    _adStatusLog.value = "MobileAds ready"
                    loadAppOpen(appContext)
                    loadInterstitial(appContext)
                    loadRewarded(appContext)
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "MobileAds.initialize exception", t)
            isMobileAdsInitialized.set(false)
            _adStatusLog.value = "MobileAds init error: ${t.message}"
        }
    }

    // ---------------- APP OPEN ----------------
    fun loadAppOpen(context: Context) {
        if (!_isAdsSdkReady.value || !canRequestAds() || appOpenAd != null || appOpenLoading) return
        appOpenLoading = true
        AppOpenAd.load(
            context.applicationContext,
            appOpenUnitId(),
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenLoading = false
                    appOpenAd = ad
                    appOpenLoadedAtMs = System.currentTimeMillis()
                    Log.d(TAG, "AppOpen ad loaded")
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    appOpenLoading = false
                    appOpenAd = null
                    Log.e(TAG, "AppOpen failed (${err.code} / ${err.domain}): ${err.message}")
                }
            }
        )
    }

    override fun onStart(owner: LifecycleOwner) {
        val activity = currentActivityRef?.get() ?: return
        showAppOpenIfEligible(activity)
    }

    fun showAppOpenIfEligible(activity: Activity) {
        if (!_isAdsSdkReady.value || !canRequestAds()) return
        val now = System.currentTimeMillis()
        if (isGameplayActive || isShowingFullscreen.get()) return
        if (now - lastAppOpenShownAtMs < APP_OPEN_COOLDOWN_MS) return
        if (now - lastFullscreenEndedAtMs < 60_000L) return

        val ad = appOpenAd
        if (ad == null || now - appOpenLoadedAtMs > APP_OPEN_COOLDOWN_MS) {
            appOpenAd = null
            loadAppOpen(activity.applicationContext)
            return
        }

        isShowingFullscreen.set(true)
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isShowingFullscreen.set(false)
                lastAppOpenShownAtMs = System.currentTimeMillis()
                lastFullscreenEndedAtMs = System.currentTimeMillis()
                loadAppOpen(activity.applicationContext)
            }

            override fun onAdFailedToShowFullScreenContent(err: AdError) {
                Log.e(TAG, "AppOpen show failed (${err.code}): ${err.message}")
                appOpenAd = null
                isShowingFullscreen.set(false)
                loadAppOpen(activity.applicationContext)
            }
        }
        ad.show(activity)
    }

    // ---------------- INTERSTITIAL ----------------
    fun loadInterstitial(context: Context) {
        if (!_isAdsSdkReady.value || !canRequestAds() || interstitialAd != null || interstitialLoading) return
        interstitialLoading = true
        val appContext = context.applicationContext
        InterstitialAd.load(
            appContext,
            interstitialUnitId(),
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialLoading = false
                    interstitialAd = ad
                    interstitialRetryCount = 0
                    Log.d(TAG, "Interstitial ad loaded")
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    interstitialLoading = false
                    interstitialAd = null
                    Log.e(TAG, "Interstitial failed (${err.code} / ${err.domain}): ${err.message}")
                    val delayMs = (5000L * (1 shl interstitialRetryCount.coerceAtMost(4)))
                    interstitialRetryCount++
                    handler.postDelayed({ loadInterstitial(appContext) }, delayMs)
                }
            }
        )
    }

    fun maybeShowInterstitialAfterLevelWin(activity: Activity?, onDone: () -> Unit) {
        maybeShowInterstitial(activity, countLevelWin = true, onDone = onDone)
    }

    fun maybeShowInterstitial(activity: Activity?, countLevelWin: Boolean, onDone: () -> Unit) {
        if (countLevelWin) {
            levelsCompletedCounter++
        }
        val now = System.currentTimeMillis()
        val ad = interstitialAd
        if (
            activity == null ||
            !_isAdsSdkReady.value ||
            !canRequestAds() ||
            ad == null ||
            isShowingFullscreen.get() ||
            (countLevelWin && levelsCompletedCounter < INTERSTITIAL_EVERY_N_LEVELS) ||
            now - lastInterstitialShownAtMs < INTERSTITIAL_COOLDOWN_MS ||
            now - lastFullscreenEndedAtMs < 45_000L
        ) {
            if (activity != null && ad == null && _isAdsSdkReady.value) {
                loadInterstitial(activity.applicationContext)
            }
            onDone()
            return
        }

        levelsCompletedCounter = 0
        isShowingFullscreen.set(true)
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                isShowingFullscreen.set(false)
                lastInterstitialShownAtMs = System.currentTimeMillis()
                lastFullscreenEndedAtMs = System.currentTimeMillis()
                loadInterstitial(activity.applicationContext)
                onDone()
            }

            override fun onAdFailedToShowFullScreenContent(err: AdError) {
                Log.e(TAG, "Interstitial show failed (${err.code}): ${err.message}")
                interstitialAd = null
                isShowingFullscreen.set(false)
                loadInterstitial(activity.applicationContext)
                onDone()
            }
        }
        ad.show(activity)
    }

    // ---------------- REWARDED ----------------
    fun isRewardedReady(): Boolean = rewardedAd != null

    fun loadRewarded(context: Context) {
        if (!_isAdsSdkReady.value || !canRequestAds() || rewardedAd != null || rewardedLoading) return
        rewardedLoading = true
        val appContext = context.applicationContext
        RewardedAd.load(
            appContext,
            rewardedUnitId(),
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedLoading = false
                    rewardedAd = ad
                    rewardedRetryCount = 0
                    Log.d(TAG, "Rewarded ad loaded")
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    rewardedLoading = false
                    rewardedAd = null
                    Log.e(TAG, "Rewarded failed (${err.code} / ${err.domain}): ${err.message}")
                    val delayMs = (5000L * (1 shl rewardedRetryCount.coerceAtMost(4)))
                    rewardedRetryCount++
                    handler.postDelayed({ loadRewarded(appContext) }, delayMs)
                }
            }
        )
    }

    /**
     * Grants reward strictly once inside OnUserEarnedRewardListener.
     * Never grants reward on open, failure, or early dismissal.
     */
    fun showRewarded(
        activity: Activity?,
        onRewardEarnedOnce: () -> Unit,
        onClosedWithoutReward: () -> Unit,
        onUnavailable: () -> Unit
    ) {
        val ad = rewardedAd
        if (activity == null || !_isAdsSdkReady.value || !canRequestAds() || ad == null || isShowingFullscreen.get()) {
            Log.w(TAG, "Rewarded ad not ready (sdkReady=${_isAdsSdkReady.value}, ad=${ad != null})")
            activity?.let { loadRewarded(it.applicationContext) }
            onUnavailable()
            return
        }

        val rewardDelivered = AtomicBoolean(false)
        isShowingFullscreen.set(true)

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                isShowingFullscreen.set(false)
                lastFullscreenEndedAtMs = System.currentTimeMillis()
                loadRewarded(activity.applicationContext)
                if (!rewardDelivered.get()) {
                    onClosedWithoutReward()
                }
            }

            override fun onAdFailedToShowFullScreenContent(err: AdError) {
                Log.e(TAG, "Rewarded show failed (${err.code}): ${err.message}")
                rewardedAd = null
                isShowingFullscreen.set(false)
                loadRewarded(activity.applicationContext)
                onUnavailable()
            }
        }

        ad.show(activity) { _ ->
            if (rewardDelivered.compareAndSet(false, true)) {
                onRewardEarnedOnce()
            }
        }
    }

    // ---------------- NATIVE ADVANCED ----------------
    fun loadNativeAd(
        context: Context,
        onLoaded: (NativeAd) -> Unit,
        onFailed: (LoadAdError?) -> Unit
    ) {
        if (!_isAdsSdkReady.value || !canRequestAds()) {
            onFailed(null)
            return
        }
        val loader = AdLoader.Builder(context.applicationContext, nativeUnitId())
            .forNativeAd { nativeAd ->
                Log.d(TAG, "Native ad loaded")
                onLoaded(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(err: LoadAdError) {
                    Log.e(TAG, "Native ad failed (${err.code} / ${err.domain}): ${err.message}")
                    onFailed(err)
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build()
            )
            .build()
        loader.loadAd(AdRequest.Builder().build())
    }
}
