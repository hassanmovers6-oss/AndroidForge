package com.educationwithhassan.mathvsbat

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.webkit.WebResourceErrorCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.webkit.WebViewFeature
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.educationwithhassan.mathvsbat.ui.components.AdaptiveBannerAd
import com.educationwithhassan.mathvsbat.ui.components.NativeAdBanner
import com.educationwithhassan.mathvsbat.ui.theme.ArcaneCyan
import com.educationwithhassan.mathvsbat.ui.theme.CastleDarkBg
import com.educationwithhassan.mathvsbat.ui.theme.CastlePanel
import com.educationwithhassan.mathvsbat.ui.theme.EmeraldAction
import com.educationwithhassan.mathvsbat.ui.theme.MathVsBatTheme
import kotlinx.coroutines.delay
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    companion object {
        private const val TAG = "MathVsBatWeb"
        private const val GAME_ENTRY_URL = "https://appassets.androidplatform.net/assets/www/index.html"
    }

    private lateinit var gameWebView: WebView
    private var showNativeAdSlot by mutableStateOf(false)
    private var isGameReady by mutableStateOf(false)
    private var loadProgress by mutableIntStateOf(0)
    private var loadErrorMessage by mutableStateOf<String?>(null)
    private var lastWebConsoleError by mutableStateOf<String?>(null)
    private var bootAttempt by mutableIntStateOf(0)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ProcessLifecycleOwner.get().lifecycle.addObserver(AdMobManager)
        AdMobManager.initialize(this)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        gameWebView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(AndroidColor.parseColor("#0E1529"))
            overScrollMode = WebView.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                useWideViewPort = true
                loadWithOverviewMode = true
                textZoom = 100
                cacheMode = WebSettings.LOAD_DEFAULT
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    loadProgress = newProgress.coerceIn(0, 100)
                }

                override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                    val msg = "[JS ${consoleMessage.messageLevel()}] ${consoleMessage.message()} (${consoleMessage.sourceId()}:${consoleMessage.lineNumber()})"
                    if (consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                        Log.e(TAG, msg)
                        if (!isGameReady) {
                            lastWebConsoleError = consoleMessage.message()
                        }
                    } else {
                        Log.d(TAG, msg)
                    }
                    return super.onConsoleMessage(consoleMessage)
                }
            }

            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    val url = request.url
                    if (url.host != "appassets.androidplatform.net") {
                        return null
                    }
                    val response = assetLoader.shouldInterceptRequest(url) ?: run {
                        Log.e(TAG, "Missing bundled asset for URL: $url")
                        return null
                    }
                    val path = url.path?.lowercase() ?: ""
                    val resolvedMime = when {
                        path.endsWith(".js") || path.endsWith(".mjs") -> "application/javascript"
                        path.endsWith(".css") -> "text/css"
                        path.endsWith(".html") || path.endsWith(".htm") -> "text/html"
                        path.endsWith(".json") -> "application/json"
                        path.endsWith(".svg") -> "image/svg+xml"
                        path.endsWith(".png") -> "image/png"
                        path.endsWith(".jpg") || path.endsWith(".jpeg") -> "image/jpeg"
                        path.endsWith(".webp") -> "image/webp"
                        path.endsWith(".woff2") -> "font/woff2"
                        else -> response.mimeType ?: "application/octet-stream"
                    }
                    response.mimeType = resolvedMime
                    if (
                        response.encoding == null &&
                        (resolvedMime.startsWith("text/") ||
                            resolvedMime == "application/javascript" ||
                            resolvedMime == "application/json" ||
                            resolvedMime == "image/svg+xml")
                    ) {
                        response.encoding = "utf-8"
                    }
                    val headers = HashMap(response.responseHeaders ?: emptyMap())
                    headers["Access-Control-Allow-Origin"] = "*"
                    response.responseHeaders = headers
                    return response
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val host = request.url.host ?: return true
                    return host != "appassets.androidplatform.net"
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    Log.d(TAG, "WebView onPageFinished: $url")
                    view.evaluateJavascript(
                        "(function(){ return Boolean(window.__MATHVSBAT_READY); })()"
                    ) { ready ->
                        if (ready == "true") {
                            isGameReady = true
                            loadErrorMessage = null
                        }
                    }
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceErrorCompat
                ) {
                    val description = if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_RESOURCE_ERROR_GET_DESCRIPTION)) {
                        error.description.toString()
                    } else {
                        "WebView asset error"
                    }
                    val code = if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_RESOURCE_ERROR_GET_CODE)) {
                        error.errorCode
                    } else {
                        -1
                    }
                    Log.e(TAG, "WebView error ($code) for ${request.url}: $description")
                    if (request.isForMainFrame) {
                        loadErrorMessage = "Failed to load game shell ($code): $description"
                    }
                }

                override fun onReceivedHttpError(
                    view: WebView,
                    request: WebResourceRequest,
                    errorResponse: WebResourceResponse
                ) {
                    Log.e(TAG, "HTTP ${errorResponse.statusCode} for ${request.url}")
                    if (request.isForMainFrame) {
                        loadErrorMessage = "Missing game assets (HTTP ${errorResponse.statusCode})."
                    }
                }

                override fun onRenderProcessGone(
                    view: WebView,
                    detail: RenderProcessGoneDetail
                ): Boolean {
                    Log.e(TAG, "WebView render process gone (didCrash=${detail.didCrash()})")
                    isGameReady = false
                    loadErrorMessage = "Graphics renderer restarted. Tap Retry to resume."
                    return true
                }
            }

            addJavascriptInterface(AndroidBridge(), "AndroidNativeBridge")
            loadUrl(GAME_ENTRY_URL)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::gameWebView.isInitialized && isGameReady) {
                    gameWebView.evaluateJavascript(
                        "(function(){ return window.__onAndroidBackPressed ? window.__onAndroidBackPressed() : false; })()"
                    ) { result ->
                        if (result != "true") {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        }
                    }
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })

        setContent {
            MathVsBatTheme {
                LaunchedEffect(bootAttempt, isGameReady, loadErrorMessage) {
                    if (!isGameReady && loadErrorMessage == null) {
                        delay(12_000L)
                        if (!isGameReady && loadErrorMessage == null && ::gameWebView.isInitialized) {
                            gameWebView.evaluateJavascript(
                                "(function(){ return Boolean(window.__MATHVSBAT_READY); })()"
                            ) { ready ->
                                if (ready == "true") {
                                    isGameReady = true
                                } else {
                                    loadErrorMessage = lastWebConsoleError
                                        ?: "Game engine timed out while starting on this WebView."
                                }
                            }
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(CastleDarkBg)
                        .safeDrawingPadding(),
                    color = CastleDarkBg
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (showNativeAdSlot && isGameReady) {
                            NativeAdBanner(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            AndroidView(
                                factory = { gameWebView },
                                modifier = Modifier.fillMaxSize()
                            )

                            if (!isGameReady || loadErrorMessage != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(CastleDarkBg)
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(CastlePanel, RoundedCornerShape(20.dp))
                                            .padding(24.dp)
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.ic_castle_crest),
                                            contentDescription = "Castle Crest",
                                            modifier = Modifier.size(84.dp)
                                        )
                                        Spacer(modifier = Modifier.height(14.dp))
                                        Text(
                                            text = "Math vs Bat – Castle Defender",
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))

                                        if (loadErrorMessage != null) {
                                            Text(
                                                text = loadErrorMessage ?: "Unable to start game.",
                                                color = Color(0xFFFCA5A5),
                                                fontSize = 13.sp,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(16.dp))
                                            Button(
                                                onClick = { reloadGameWebView() },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = EmeraldAction,
                                                    contentColor = Color.White
                                                )
                                            ) {
                                                Text("Retry Loading Game", fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            Text(
                                                text = "Preparing Castle Defenses... ${loadProgress}%",
                                                color = ArcaneCyan,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))
                                            LinearProgressIndicator(
                                                progress = { (loadProgress / 100f).coerceIn(0.08f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(8.dp),
                                                color = ArcaneCyan,
                                                trackColor = CastleDarkBg
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        AdaptiveBannerAd()
                    }
                }
            }
        }
    }

    private fun reloadGameWebView() {
        loadErrorMessage = null
        lastWebConsoleError = null
        isGameReady = false
        loadProgress = 0
        bootAttempt++
        if (::gameWebView.isInitialized) {
            gameWebView.loadUrl(GAME_ENTRY_URL)
        }
    }

    private fun dispatchJs(script: String) {
        runOnUiThread {
            if (::gameWebView.isInitialized) {
                gameWebView.evaluateJavascript(script, null)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun triggerVibration(durationMs: Long) {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator.vibrate(durationMs)
            }
        } catch (_: Throwable) {
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun isNativeAndroid(): Boolean = true

        @JavascriptInterface
        fun setRoute(route: String) {
            runOnUiThread {
                AdMobManager.setGameplayActive(route == "gameplay")
                showNativeAdSlot = route == "levels" || route == "modes" || route == "daily" || route == "profile"
            }
        }

        @JavascriptInterface
        fun onGameReady() {
            runOnUiThread {
                Log.d(TAG, "JS bridge reported onGameReady()")
                isGameReady = true
                loadErrorMessage = null
            }
        }

        @JavascriptInterface
        fun onGameError(message: String) {
            runOnUiThread {
                val clean = message.ifBlank { "Runtime error in game bundle." }
                Log.e(TAG, "JS bridge reported onGameError: $clean")
                if (!isGameReady) {
                    loadErrorMessage = clean
                }
            }
        }

        @JavascriptInterface
        fun showRewardedAd(callbackId: String) {
            val safeId = JSONObject.quote(callbackId)
            runOnUiThread {
                AdMobManager.showRewarded(
                    activity = this@MainActivity,
                    onRewardEarnedOnce = {
                        dispatchJs("window.__onAndroidRewardedResult && window.__onAndroidRewardedResult($safeId, true, '')")
                    },
                    onClosedWithoutReward = {
                        dispatchJs("window.__onAndroidRewardedResult && window.__onAndroidRewardedResult($safeId, false, 'Ad closed before completion — reward not granted.')")
                    },
                    onUnavailable = {
                        dispatchJs("window.__onAndroidRewardedResult && window.__onAndroidRewardedResult($safeId, false, 'No rewarded ad available right now. Continue playing!')")
                    }
                )
            }
        }

        @JavascriptInterface
        fun maybeShowInterstitial(callbackId: String, countLevelWin: Boolean) {
            val safeId = JSONObject.quote(callbackId)
            runOnUiThread {
                AdMobManager.maybeShowInterstitial(this@MainActivity, countLevelWin) {
                    dispatchJs("window.__onAndroidInterstitialDone && window.__onAndroidInterstitialDone($safeId)")
                }
            }
        }

        @JavascriptInterface
        fun showPrivacyOptions() {
            runOnUiThread {
                AdMobManager.showPrivacyOptionsForm(this@MainActivity) {}
            }
        }

        @JavascriptInterface
        fun vibrate(durationMs: Long) {
            triggerVibration(durationMs.coerceIn(15L, 400L))
        }
    }

    override fun onPause() {
        super.onPause()
        if (::gameWebView.isInitialized) {
            dispatchJs("window.__onAndroidLifecycle && window.__onAndroidLifecycle('pause')")
            gameWebView.onPause()
        }
    }

    override fun onResume() {
        super.onResume()
        AdMobManager.setCurrentActivity(this)
        if (::gameWebView.isInitialized) {
            gameWebView.onResume()
            dispatchJs("window.__onAndroidLifecycle && window.__onAndroidLifecycle('resume')")
        }
    }

    override fun onDestroy() {
        if (::gameWebView.isInitialized) {
            gameWebView.removeJavascriptInterface("AndroidNativeBridge")
            gameWebView.destroy()
        }
        super.onDestroy()
    }
}
