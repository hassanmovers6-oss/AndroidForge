# Privacy Policy – Shadow Ninja – Dark Quest

**Developer:** Rana Hassan  
**Package Name:** `com.educationwithhassan.shadowninja`  

## 1. Local Data Storage
Shadow Ninja – Dark Quest is an offline single-player game. Game progress (unlocked levels, stars, scores, coins, crystals, costumes, upgrades, and audio/control settings) is stored locally on your device using `localStorage` and Android `SharedPreferences`. No user account is required and no personal gameplay files are transmitted to private developer servers.

## 2. Advertising & Consent (Google AdMob & UMP SDK)
This application integrates the official Google Mobile Ads SDK (`com.google.android.gms:play-services-ads`) and Google User Messaging Platform (`com.google.android.ump:user-messaging-platform`).
- Depending on your region (such as EEA/UK), a consent dialog is presented before personalized ads are requested.
- You may update your ad consent preferences at any time from **Settings → Privacy & Ads**.
- Rewarded ads are strictly optional and initiated only by explicit user choice.
- Google's Advertising ID (`AD_ID`) may be used by Google AdMob in accordance with Google's Privacy Policy and Google Play Data Safety guidelines.

## 3. Contact
For privacy or support inquiries regarding Shadow Ninja – Dark Quest, contact the developer **Rana Hassan**.
