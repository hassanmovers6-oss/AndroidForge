package com.educationwithhassan.shadowninja

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner

/**
 * Application entry point wiring process-level lifecycle observation
 * for App Open ads and centralized single-instance AdMob state.
 */
class ShadowNinjaApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        AdMobManager.initApplication(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(AdMobManager)
    }
}
