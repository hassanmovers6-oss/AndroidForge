package com.educationwithhassan.shadowninja

/**
 * Centralized Google AdMob Configuration for Shadow Ninja – Dark Quest.
 * Package: com.educationwithhassan.shadowninja
 *
 * Development builds (BuildConfig.DEBUG == true) strictly use Google's official
 * test ad unit IDs so live ads are never requested or clicked during development.
 *
 * Production release builds (BuildConfig.DEBUG == false) strictly use the six
 * exact production AdMob IDs configured for Shadow Ninja – Dark Quest.
 */
object AdConfig {

    const val LOG_TAG = "ShadowNinja-AdMob"

    // =========================================================================
    // PRODUCTION ADMOB IDS (EXACT SUPPLIED IDS FOR RELEASE BUILDS)
    // =========================================================================
    const val ADMOB_APP_ID = "ca-app-pub-3133971041724338~5461456996"
    const val APP_OPEN_AD_UNIT_ID = "ca-app-pub-3133971041724338/3363962603"
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3133971041724338/8121465266"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3133971041724338/3613188701"
    const val NATIVE_AD_UNIT_ID = "ca-app-pub-3133971041724338/2076745751"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3133971041724338/2300107036"

    // =========================================================================
    // OFFICIAL GOOGLE TEST AD UNIT IDS (STRICTLY FOR DEBUG / DEV BUILDS)
    // =========================================================================
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // Frequency & Cache Windows
    const val APP_OPEN_COOLDOWN_MS = 4L * 60L * 60L * 1000L // 4 hours minimum
    const val APP_OPEN_EXPIRATION_MS = 4L * 60L * 60L * 1000L // 4 hours Google AdMob limit
    const val INTERSTITIAL_COOLDOWN_MS = 3L * 60L * 1000L // 3 minutes minimum
    const val LEVELS_BETWEEN_INTERSTITIAL = 3

    val isTestMode: Boolean
        get() = BuildConfig.DEBUG

    val activeAppOpenId: String
        get() = if (isTestMode) TEST_APP_OPEN_ID else APP_OPEN_AD_UNIT_ID

    val activeBannerId: String
        get() = if (isTestMode) TEST_BANNER_ID else BANNER_AD_UNIT_ID

    val activeInterstitialId: String
        get() = if (isTestMode) TEST_INTERSTITIAL_ID else INTERSTITIAL_AD_UNIT_ID

    val activeNativeId: String
        get() = if (isTestMode) TEST_NATIVE_ID else NATIVE_AD_UNIT_ID

    val activeRewardedId: String
        get() = if (isTestMode) TEST_REWARDED_ID else REWARDED_AD_UNIT_ID
}
