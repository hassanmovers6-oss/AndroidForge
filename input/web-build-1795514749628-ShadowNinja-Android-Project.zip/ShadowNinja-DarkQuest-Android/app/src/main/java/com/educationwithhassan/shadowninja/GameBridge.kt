package com.educationwithhassan.shadowninja

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Safe WebView-to-Native AdMob & Device Bridge.
 * Zero HTML ad simulation: routes all Banner, Interstitial, Rewarded, Native,
 * App Open, and UMP Consent calls directly to native AdMobManager.
 */
class GameBridge(
    private val activity: Activity,
    private val webView: WebView,
) {
    private val prefs = activity.getSharedPreferences("shadow_ninja_backup", Context.MODE_PRIVATE)

    @JavascriptInterface
    fun isRunningNative(): Boolean = true

    @JavascriptInterface
    fun isDebugBuild(): Boolean = BuildConfig.DEBUG

    @JavascriptInterface
    fun getAdMobStatusJson(): String = AdMobManager.getDebugStatusJson()

    @JavascriptInterface
    fun updateScreenState(screen: String, inGameplay: Boolean, inBoss: Boolean) {
        AdMobManager.updateGameState(screen, inGameplay, inBoss)
    }

    @JavascriptInterface
    fun showBanner(screen: String) {
        AdMobManager.showBanner()
    }

    @JavascriptInterface
    fun hideBanner() {
        AdMobManager.hideBanner()
    }

    @JavascriptInterface
    fun showInterstitialIfReady(runToken: String): Boolean {
        return AdMobManager.showInterstitialIfReady(runToken)
    }

    @JavascriptInterface
    fun showInterstitialForTransition(runToken: String) {
        AdMobManager.showInterstitialForTransition(runToken)
    }

    @JavascriptInterface
    fun isRewardedReady(): Boolean = AdMobManager.isRewardedReady()

    @JavascriptInterface
    fun showRewarded(placement: String) {
        AdMobManager.showRewarded(placement) { earned ->
            webView.post {
                val safePlacement = placement.replace(Regex("[^a-zA-Z0-9_-]"), "")
                webView.evaluateJavascript(
                    "window.onNativeRewardDismissed && window.onNativeRewardDismissed('$safePlacement', $earned);",
                    null
                )
            }
        }
    }

    @JavascriptInterface
    fun isNativeLoaded(): Boolean = AdMobManager.isNativeLoaded()

    @JavascriptInterface
    fun bindNativeAdSlot(xRatio: Float, yRatio: Float, wRatio: Float, hRatio: Float) {
        AdMobManager.bindNativeAdOverlay(xRatio, yRatio, wRatio, hRatio)
    }

    @JavascriptInterface
    fun hideNativeAdSlot() {
        AdMobManager.hideNativeAdOverlay()
    }

    @JavascriptInterface
    fun showAppOpenIfReady() {
        AdMobManager.showAppOpenIfAppropriate()
    }

    @JavascriptInterface
    fun isPrivacyOptionsRequired(): Boolean {
        return AdMobManager.consentManager?.isPrivacyOptionsRequired ?: false
    }

    @JavascriptInterface
    fun requestConsentUpdate() {
        webView.post {
            AdMobManager.consentManager?.showPrivacyOptionsForm(activity) { canRequest ->
                if (canRequest) {
                    AdMobManager.initializeSdkAfterConsent(activity)
                }
            }
        }
    }

    @JavascriptInterface
    fun saveBackup(json: String) {
        prefs.edit().putString("save_v1", json).apply()
    }

    @JavascriptInterface
    fun loadBackup(): String {
        return prefs.getString("save_v1", "") ?: ""
    }

    @JavascriptInterface
    fun vibrate(ms: Long) {
        val vibrator = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(ms)
        }
    }
}
