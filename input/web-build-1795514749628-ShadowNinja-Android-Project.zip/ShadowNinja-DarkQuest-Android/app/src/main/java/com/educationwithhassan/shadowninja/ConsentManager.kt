package com.educationwithhassan.shadowninja

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Manages Google User Messaging Platform (UMP) consent updates,
 * non-personalized ad compliance, and privacy options re-entry.
 */
class ConsentManager(private val appContext: Context) {

    private val consentInformation: ConsentInformation =
        UserMessagingPlatform.getConsentInformation(appContext)

    val canRequestAds: Boolean
        get() = consentInformation.canRequestAds()

    val isPrivacyOptionsRequired: Boolean
        get() = consentInformation.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    val statusLabel: String
        get() = when (consentInformation.consentStatus) {
            ConsentInformation.ConsentStatus.OBTAINED -> "OBTAINED"
            ConsentInformation.ConsentStatus.NOT_REQUIRED -> "NOT_REQUIRED"
            ConsentInformation.ConsentStatus.REQUIRED -> "REQUIRED"
            else -> "UNKNOWN"
        }

    fun gatherConsent(activity: Activity, onConsentComplete: (canRequestAds: Boolean) -> Unit) {
        // Shadow Ninja – Dark Quest is a dark fantasy action game for teen/general audiences.
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        Log.d(AdConfig.LOG_TAG, "UMP consent update requested (cached canRequest=${consentInformation.canRequestAds()})")

        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w(
                            AdConfig.LOG_TAG,
                            "UMP form warning code=${formError.errorCode}: ${formError.message}"
                        )
                    } else {
                        Log.d(
                            AdConfig.LOG_TAG,
                            "UMP consent resolved status=$statusLabel canRequest=$canRequestAds"
                        )
                    }
                    onConsentComplete(consentInformation.canRequestAds())
                }
            },
            { requestError ->
                Log.w(
                    AdConfig.LOG_TAG,
                    "UMP info update skipped/offline code=${requestError.errorCode}: ${requestError.message}"
                )
                // Do not block gameplay if offline or consent endpoint fails
                onConsentComplete(consentInformation.canRequestAds())
            }
        )
    }

    fun showPrivacyOptionsForm(activity: Activity, onDismissed: (Boolean) -> Unit = {}) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
            if (formError != null) {
                Log.w(
                    AdConfig.LOG_TAG,
                    "UMP privacy options error code=${formError.errorCode}: ${formError.message}"
                )
            }
            onDismissed(consentInformation.canRequestAds())
        }
    }
}
