package com.educationwithhassan.shadowninja

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min
import kotlin.math.roundToInt

enum class AdFormatState {
    NOT_INITIALIZED,
    LOADING,
    LOADED,
    SHOWING,
    FAILED,
    NOT_AVAILABLE,
}

/**
 * Centralized, process-scoped Google AdMob Manager for Shadow Ninja – Dark Quest.
 * Manages all six AdMob formats (App ID, App Open, Anchored Adaptive Banner,
 * Interstitial, Native Advanced, Rewarded) with strict lifecycle coordination,
 * retry backoff, consent compliance, and debug diagnostics.
 */
object AdMobManager : DefaultLifecycleObserver {

    interface HostCallbacks {
        fun onFullscreenAdWillShow()
        fun onFullscreenAdDismissed()
        fun onTransitionInterstitialFinished(shown: Boolean)
        fun onNativeAdAvailabilityChanged(loaded: Boolean)
        fun onColdLaunchOverlayVisibility(visible: Boolean)
    }

    private const val PREFS_NAME = "shadow_ninja_admob_prefs"
    private const val KEY_LAST_APP_OPEN_MS = "last_app_open_ms"
    private const val MAX_RETRY_ATTEMPTS = 3

    private val mainHandler = Handler(Looper.getMainLooper())
    private val sdkInitStarted = AtomicBoolean(false)

    @Volatile
    var isSdkInitialized: Boolean = false
        private set

    @Volatile
    var consentManager: ConsentManager? = null
        private set

    private lateinit var appContext: Context
    private lateinit var prefs: SharedPreferences

    private var activityRef: WeakReference<Activity>? = null
    private var bannerContainerRef: WeakReference<FrameLayout>? = null
    private var nativeContainerRef: WeakReference<FrameLayout>? = null
    private var hostCallbacksRef: WeakReference<HostCallbacks>? = null

    // Format states
    @Volatile var appOpenState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var bannerState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var interstitialState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var nativeState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var rewardedState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var lastLoadError: String = "None"; private set

    // Active gameplay / screen safety guards
    @Volatile var currentScreen: String = "SPLASH"; private set
    @Volatile var isInActiveGameplay: Boolean = false; private set
    @Volatile var isInBossFight: Boolean = false; private set
    @Volatile private var isFullscreenShowing: Boolean = false
    @Volatile private var externalAdClickInProgress: Boolean = false
    @Volatile private var coldLaunchAttempted: Boolean = false
    @Volatile private var coldLaunchWaitingOverlay: Boolean = false

    // Banner
    private var bannerView: AdView? = null
    private var bannerShouldBeVisible: Boolean = false
    private var bannerRetryCount = 0
    private var lastBannerWidthDp = 0

    // Interstitial
    @Volatile private var interstitialAd: InterstitialAd? = null
    private var interstitialRetryCount = 0
    private var lastInterstitialShownMs = 0L
    private var lastCompletedLevelToken: String = ""

    // Rewarded
    @Volatile private var rewardedAd: RewardedAd? = null
    private var rewardedRetryCount = 0

    // App Open
    @Volatile private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadTimeMs = 0L
    private var appOpenRetryCount = 0
    private var lastAppOpenShownMs = 0L

    // Native Advanced
    @Volatile private var cachedNativeAd: NativeAd? = null
    private var nativeRetryCount = 0
    private var nativeSlotBounds: SlotBounds? = null

    private data class SlotBounds(
        val xRatio: Float,
        val yRatio: Float,
        val wRatio: Float,
        val hRatio: Float,
    )

    fun initApplication(context: Context) {
        appContext = context.applicationContext
        prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        lastAppOpenShownMs = prefs.getLong(KEY_LAST_APP_OPEN_MS, 0L)
        consentManager = ConsentManager(appContext)
        Log.i(
            AdConfig.LOG_TAG,
            "AdMobManager initialized (${if (AdConfig.isTestMode) "TEST MODE" else "PRODUCTION MODE"})"
        )
    }

    fun attachActivity(
        activity: Activity,
        bannerHolder: FrameLayout,
        nativeHolder: FrameLayout,
        callbacks: HostCallbacks,
    ) {
        activityRef = WeakReference(activity)
        bannerContainerRef = WeakReference(bannerHolder)
        nativeContainerRef = WeakReference(nativeHolder)
        hostCallbacksRef = WeakReference(callbacks)

        if (isSdkInitialized && canRequestAds()) {
            if (bannerShouldBeVisible) showBanner()
            renderBoundNativeAd()
        }
    }

    fun detachActivity(activity: Activity) {
        if (activityRef?.get() === activity) {
            bannerView?.destroy()
            bannerView = null
            bannerContainerRef?.get()?.removeAllViews()
            nativeContainerRef?.get()?.removeAllViews()
            activityRef = null
            bannerContainerRef = null
            nativeContainerRef = null
            hostCallbacksRef = null
        }
    }

    fun initializeSdkAfterConsent(activity: Activity) {
        if (!canRequestAds()) {
            Log.w(AdConfig.LOG_TAG, "Consent does not permit ad requests yet; delaying SDK load.")
            return
        }
        if (sdkInitStarted.getAndSet(true)) {
            if (isSdkInitialized) {
                preloadAllFormats()
            }
            return
        }

        Log.d(AdConfig.LOG_TAG, "Initializing Google Mobile Ads SDK...")
        MobileAds.initialize(appContext) { initStatus ->
            isSdkInitialized = true
            Log.i(AdConfig.LOG_TAG, "MobileAds initialized: ${initStatus.adapterStatusMap.keys}")
            mainHandler.post {
                preloadAllFormats()
                if (bannerShouldBeVisible) {
                    showBanner()
                }
            }
        }
    }

    private fun canRequestAds(): Boolean = consentManager?.canRequestAds == true

    private fun preloadAllFormats() {
        if (!isSdkInitialized || !canRequestAds()) return
        preloadAppOpen()
        preloadInterstitial()
        preloadRewarded()
        preloadNativeAd()
    }

    fun updateGameState(screen: String, inGameplay: Boolean, inBoss: Boolean) {
        currentScreen = screen
        isInActiveGameplay = inGameplay
        isInBossFight = inBoss
        if (screen == "SPLASH") {
            hideBanner()
        }
        if (inGameplay) {
            hideNativeAdOverlay()
            // Warm up interstitial asynchronously while the player plays
            if (isSdkInitialized && canRequestAds()) {
                preloadInterstitial()
            }
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        if (!coldLaunchAttempted) {
            return
        }
        if (externalAdClickInProgress) {
            externalAdClickInProgress = false
            Log.d(AdConfig.LOG_TAG, "AppOpen skipped: returning from ad click.")
            return
        }
        showAppOpenIfAppropriate()
    }

    // =========================================================================
    // 1. APP OPEN AD (4-hour freshness & frequency gate)
    // =========================================================================

    fun tryColdLaunchAppOpen() {
        if (coldLaunchAttempted) return
        coldLaunchAttempted = true
        if (!canRequestAds()) return

        val now = System.currentTimeMillis()
        if (now - lastAppOpenShownMs < AdConfig.APP_OPEN_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "Cold launch AppOpen skipped (4h frequency limit active).")
            return
        }

        // Brief non-blocking cold-launch loading veil (max 1.5s) if ad is still warming
        if (isAppOpenAvailable()) {
            showAppOpenIfAppropriate()
            return
        }

        coldLaunchWaitingOverlay = true
        hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(true)
        if (isSdkInitialized) preloadAppOpen()

        mainHandler.postDelayed({
            if (coldLaunchWaitingOverlay) {
                coldLaunchWaitingOverlay = false
                hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
                if (currentScreen == "SPLASH" || currentScreen == "MAIN_MENU") {
                    showAppOpenIfAppropriate()
                }
            }
        }, 1450L)
    }

    fun preloadAppOpen() {
        if (!isSdkInitialized || !canRequestAds()) return
        if (appOpenState == AdFormatState.LOADING || isAppOpenAvailable()) return

        appOpenState = AdFormatState.LOADING
        if (AdConfig.isTestMode) {
            Log.d(AdConfig.LOG_TAG, "AppOpen load started (${AdConfig.activeAppOpenId})")
        } else {
            Log.d(AdConfig.LOG_TAG, "AppOpen load started")
        }

        AppOpenAd.load(
            appContext,
            AdConfig.activeAppOpenId,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    appOpenLoadTimeMs = System.currentTimeMillis()
                    appOpenState = AdFormatState.LOADED
                    appOpenRetryCount = 0
                    Log.i(AdConfig.LOG_TAG, "AppOpen loaded successfully.")
                    if (coldLaunchWaitingOverlay && (currentScreen == "SPLASH" || currentScreen == "MAIN_MENU")) {
                        coldLaunchWaitingOverlay = false
                        mainHandler.post {
                            hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
                            showAppOpenIfAppropriate()
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenAd = null
                    appOpenState = AdFormatState.FAILED
                    lastLoadError = "AppOpen(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "AppOpen load failed code=${error.code}: ${error.message}")
                    scheduleRetry(appOpenRetryCount++) { preloadAppOpen() }
                }
            }
        )
    }

    private fun isAppOpenAvailable(): Boolean {
        if (appOpenAd == null) return false
        val ageMs = System.currentTimeMillis() - appOpenLoadTimeMs
        val fresh = ageMs < AdConfig.APP_OPEN_EXPIRATION_MS
        if (!fresh) {
            appOpenAd = null
            appOpenState = AdFormatState.NOT_AVAILABLE
        }
        return fresh
    }

    fun showAppOpenIfAppropriate(): Boolean {
        val activity = activityRef?.get() ?: return false
        if (isInActiveGameplay || isInBossFight || currentScreen == "PLAYING" || currentScreen == "PAUSED") {
            Log.d(AdConfig.LOG_TAG, "AppOpen blocked during active gameplay/boss encounter.")
            return false
        }
        if (isFullscreenShowing) {
            Log.d(AdConfig.LOG_TAG, "AppOpen blocked: another full-screen ad is active.")
            return false
        }
        val now = System.currentTimeMillis()
        if (now - lastAppOpenShownMs < AdConfig.APP_OPEN_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "AppOpen skipped: 4-hour frequency window active.")
            return false
        }
        val ad = appOpenAd?.takeIf { isAppOpenAvailable() } ?: run {
            preloadAppOpen()
            return false
        }

        isFullscreenShowing = true
        appOpenState = AdFormatState.SHOWING
        hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
        hostCallbacksRef?.get()?.onFullscreenAdWillShow()

        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                isFullscreenShowing = false
                appOpenState = AdFormatState.LOADED
                hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                return@post
            }
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "AppOpen displayed.")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "AppOpen impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "AppOpen clicked.")
                }

                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    appOpenState = AdFormatState.NOT_AVAILABLE
                    isFullscreenShowing = false
                    val shownAt = System.currentTimeMillis()
                    lastAppOpenShownMs = shownAt
                    prefs.edit().putLong(KEY_LAST_APP_OPEN_MS, shownAt).apply()
                    Log.i(AdConfig.LOG_TAG, "AppOpen dismissed.")
                    hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                    preloadAppOpen()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    appOpenAd = null
                    appOpenState = AdFormatState.FAILED
                    isFullscreenShowing = false
                    lastLoadError = "AppOpenShow(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "AppOpen show failed code=${error.code}: ${error.message}")
                    hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                    preloadAppOpen()
                }
            }
            ad.show(activity)
        }
        return true
    }

    // =========================================================================
    // 2. ANCHORED ADAPTIVE BANNER AD
    // =========================================================================

    private fun computeAdaptiveAdSize(activity: Activity, container: FrameLayout): AdSize {
        var adWidthPx = container.width.toFloat()
        if (adWidthPx <= 0f) {
            adWidthPx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = activity.windowManager.currentWindowMetrics.bounds
                bounds.width().toFloat()
            } else {
                val outMetrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                activity.windowManager.defaultDisplay.getMetrics(outMetrics)
                outMetrics.widthPixels.toFloat()
            }
        }
        val density = activity.resources.displayMetrics.density.coerceAtLeast(1f)
        val adWidthDp = (adWidthPx / density).roundToInt().coerceAtLeast(320)
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidthDp)
    }

    fun showBanner() {
        if (currentScreen == "SPLASH") {
            hideBanner()
            return
        }
        bannerShouldBeVisible = true
        if (!isSdkInitialized || !canRequestAds()) return

        mainHandler.post {
            val activity = activityRef?.get() ?: return@post
            val container = bannerContainerRef?.get() ?: return@post

            val adaptiveSize = computeAdaptiveAdSize(activity, container)
            val widthChanged = lastBannerWidthDp != 0 && lastBannerWidthDp != adaptiveSize.width

            if (bannerView == null || widthChanged) {
                bannerView?.destroy()
                container.removeAllViews()
                lastBannerWidthDp = adaptiveSize.width

                val adView = AdView(activity).apply {
                    adUnitId = AdConfig.activeBannerId
                    setAdSize(adaptiveSize)
                }
                bannerView = adView
                container.addView(
                    adView,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )

                bannerState = AdFormatState.LOADING
                if (AdConfig.isTestMode) {
                    Log.d(
                        AdConfig.LOG_TAG,
                        "Banner load started widthDp=${adaptiveSize.width} (${AdConfig.activeBannerId})"
                    )
                } else {
                    Log.d(AdConfig.LOG_TAG, "Banner load started widthDp=${adaptiveSize.width}")
                }

                adView.adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        bannerState = AdFormatState.LOADED
                        bannerRetryCount = 0
                        if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                            container.visibility = View.VISIBLE
                        } else {
                            container.visibility = View.GONE
                        }
                        Log.i(AdConfig.LOG_TAG, "Banner loaded.")
                    }

                    override fun onAdImpression() {
                        Log.i(AdConfig.LOG_TAG, "Banner impression recorded.")
                    }

                    override fun onAdClicked() {
                        externalAdClickInProgress = true
                        Log.i(AdConfig.LOG_TAG, "Banner clicked.")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        bannerState = AdFormatState.FAILED
                        container.visibility = View.GONE
                        lastLoadError = "Banner(${error.code}): ${error.message}"
                        Log.w(AdConfig.LOG_TAG, "Banner load failed code=${error.code}: ${error.message}")
                        if (bannerRetryCount < MAX_RETRY_ATTEMPTS) {
                            val delayMs = (++bannerRetryCount) * 12_000L
                            mainHandler.postDelayed({
                                if (bannerShouldBeVisible && bannerView != null) {
                                    bannerState = AdFormatState.LOADING
                                    bannerView?.loadAd(AdRequest.Builder().build())
                                }
                            }, delayMs)
                        }
                    }
                }
                adView.loadAd(AdRequest.Builder().build())
            } else if (bannerState == AdFormatState.LOADED) {
                container.visibility = View.VISIBLE
            } else if (bannerState == AdFormatState.FAILED || bannerState == AdFormatState.NOT_AVAILABLE) {
                bannerRetryCount = 0
                bannerState = AdFormatState.LOADING
                bannerView?.loadAd(AdRequest.Builder().build())
            }
        }
    }

    fun hideBanner() {
        bannerShouldBeVisible = false
        mainHandler.post {
            bannerContainerRef?.get()?.visibility = View.GONE
        }
    }

    fun refreshBannerLayout() {
        mainHandler.post {
            if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                lastBannerWidthDp = -1 // Trigger adaptive resize on config change
                showBanner()
            }
        }
    }

    // =========================================================================
    // 3. INTERSTITIAL AD
    // =========================================================================

    fun preloadInterstitial() {
        if (!isSdkInitialized || !canRequestAds()) return
        if (interstitialState == AdFormatState.LOADING || interstitialAd != null) return

        interstitialState = AdFormatState.LOADING
        if (AdConfig.isTestMode) {
            Log.d(AdConfig.LOG_TAG, "Interstitial load started (${AdConfig.activeInterstitialId})")
        } else {
            Log.d(AdConfig.LOG_TAG, "Interstitial load started")
        }

        InterstitialAd.load(
            appContext,
            AdConfig.activeInterstitialId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    interstitialState = AdFormatState.LOADED
                    interstitialRetryCount = 0
                    Log.i(AdConfig.LOG_TAG, "Interstitial loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    interstitialState = AdFormatState.FAILED
                    lastLoadError = "Interstitial(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "Interstitial load failed code=${error.code}: ${error.message}")
                    scheduleRetry(interstitialRetryCount++) { preloadInterstitial() }
                }
            }
        )
    }

    fun showInterstitialIfReady(runToken: String = ""): Boolean {
        val activity = activityRef?.get() ?: return false
        if (isInActiveGameplay || isInBossFight || currentScreen == "PLAYING" || currentScreen == "PAUSED") {
            Log.d(AdConfig.LOG_TAG, "Interstitial blocked during gameplay/boss fight.")
            return false
        }
        if (isFullscreenShowing) {
            Log.d(AdConfig.LOG_TAG, "Interstitial blocked: another full-screen ad is showing.")
            return false
        }
        if (runToken.isNotEmpty() && runToken == lastCompletedLevelToken) {
            Log.d(AdConfig.LOG_TAG, "Interstitial blocked: duplicate request for same level completion.")
            return false
        }

        val now = System.currentTimeMillis()
        if (now - lastInterstitialShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "Interstitial skipped: 3-minute cooldown active.")
            return false
        }
        if (now - lastAppOpenShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "Interstitial skipped: too soon after App Open ad.")
            return false
        }

        val ad = interstitialAd ?: run {
            preloadInterstitial()
            return false
        }

        if (runToken.isNotEmpty()) {
            lastCompletedLevelToken = runToken
        }
        isFullscreenShowing = true
        interstitialState = AdFormatState.SHOWING
        hostCallbacksRef?.get()?.onFullscreenAdWillShow()

        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                isFullscreenShowing = false
                interstitialState = AdFormatState.LOADED
                hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                return@post
            }
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "Interstitial displayed.")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "Interstitial impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "Interstitial clicked.")
                }

                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    interstitialState = AdFormatState.NOT_AVAILABLE
                    isFullscreenShowing = false
                    lastInterstitialShownMs = System.currentTimeMillis()
                    Log.i(AdConfig.LOG_TAG, "Interstitial dismissed.")
                    hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                    preloadInterstitial()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    interstitialState = AdFormatState.FAILED
                    isFullscreenShowing = false
                    lastLoadError = "InterstitialShow(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "Interstitial show failed code=${error.code}: ${error.message}")
                    hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                    preloadInterstitial()
                }
            }
            ad.show(activity)
        }
        return true
    }

    fun showInterstitialForTransition(runToken: String = "") {
        val activity = activityRef?.get()
        if (activity == null ||
            isInActiveGameplay ||
            isInBossFight ||
            currentScreen == "PLAYING" ||
            currentScreen == "PAUSED" ||
            isFullscreenShowing
        ) {
            hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
            return
        }
        if (runToken.isNotEmpty() && runToken == lastCompletedLevelToken) {
            hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastInterstitialShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS ||
            now - lastAppOpenShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS
        ) {
            hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
            return
        }
        val ad = interstitialAd ?: run {
            preloadInterstitial()
            hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
            return
        }

        if (runToken.isNotEmpty()) {
            lastCompletedLevelToken = runToken
        }
        isFullscreenShowing = true
        interstitialState = AdFormatState.SHOWING
        var finished = false
        fun completeTransition(shown: Boolean) {
            if (finished) return
            finished = true
            isFullscreenShowing = false
            hostCallbacksRef?.get()?.onFullscreenAdDismissed()
            hostCallbacksRef?.get()?.onTransitionInterstitialFinished(shown)
            preloadInterstitial()
        }

        hostCallbacksRef?.get()?.onFullscreenAdWillShow()
        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                interstitialState = AdFormatState.LOADED
                completeTransition(false)
                return@post
            }
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "Transition Interstitial displayed.")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "Transition Interstitial impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "Transition Interstitial clicked.")
                }

                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    interstitialState = AdFormatState.NOT_AVAILABLE
                    lastInterstitialShownMs = System.currentTimeMillis()
                    Log.i(AdConfig.LOG_TAG, "Transition Interstitial dismissed.")
                    completeTransition(true)
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    interstitialState = AdFormatState.FAILED
                    lastLoadError = "InterstitialShow(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "Transition Interstitial show failed code=${error.code}: ${error.message}")
                    completeTransition(false)
                }
            }
            ad.show(activity)
        }
    }

    // =========================================================================
    // 4. NATIVE ADVANCED AD (Genuine NativeAdView with Media & AdChoices)
    // =========================================================================

    fun preloadNativeAd() {
        if (!isSdkInitialized || !canRequestAds()) return
        if (nativeState == AdFormatState.LOADING || cachedNativeAd != null) return

        nativeState = AdFormatState.LOADING
        if (AdConfig.isTestMode) {
            Log.d(AdConfig.LOG_TAG, "NativeAd load started (${AdConfig.activeNativeId})")
        } else {
            Log.d(AdConfig.LOG_TAG, "NativeAd load started")
        }

        val options = NativeAdOptions.Builder()
            .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
            .build()

        val loader = AdLoader.Builder(appContext, AdConfig.activeNativeId)
            .forNativeAd { nativeAd ->
                cachedNativeAd?.destroy()
                cachedNativeAd = nativeAd
                nativeState = AdFormatState.LOADED
                nativeRetryCount = 0
                Log.i(AdConfig.LOG_TAG, "NativeAd loaded (${nativeAd.headline}).")
                mainHandler.post {
                    hostCallbacksRef?.get()?.onNativeAdAvailabilityChanged(true)
                    renderBoundNativeAd()
                }
            }
            .withAdListener(object : AdListener() {
                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "NativeAd impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "NativeAd clicked.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    nativeState = AdFormatState.FAILED
                    lastLoadError = "Native(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "NativeAd load failed code=${error.code}: ${error.message}")
                    mainHandler.post {
                        hostCallbacksRef?.get()?.onNativeAdAvailabilityChanged(false)
                    }
                    scheduleRetry(nativeRetryCount++) { preloadNativeAd() }
                }
            })
            .withNativeAdOptions(options)
            .build()

        loader.loadAd(AdRequest.Builder().build())
    }

    fun bindNativeAdOverlay(xRatio: Float, yRatio: Float, wRatio: Float, hRatio: Float) {
        nativeSlotBounds = SlotBounds(xRatio, yRatio, wRatio, hRatio)
        mainHandler.post { renderBoundNativeAd() }
    }

    fun hideNativeAdOverlay() {
        nativeSlotBounds = null
        mainHandler.post {
            nativeContainerRef?.get()?.let { container ->
                container.visibility = View.GONE
                container.isClickable = false
                container.isFocusable = false
                container.removeAllViews()
            }
        }
    }

    private fun renderBoundNativeAd() {
        val bounds = nativeSlotBounds ?: run {
            nativeContainerRef?.get()?.let { container ->
                container.visibility = View.GONE
                container.isClickable = false
                container.isFocusable = false
            }
            return
        }
        val activity = activityRef?.get() ?: return
        val container = nativeContainerRef?.get() ?: return
        val ad = cachedNativeAd ?: run {
            container.visibility = View.GONE
            container.isClickable = false
            container.isFocusable = false
            preloadNativeAd()
            return
        }
        if (isInActiveGameplay || bounds.wRatio <= 0.05f || bounds.hRatio <= 0.05f) {
            container.visibility = View.GONE
            container.isClickable = false
            container.isFocusable = false
            return
        }

        val parent = container.parent as? View ?: return
        val parentW = parent.width
        val parentH = parent.height
        if (parentW <= 0 || parentH <= 0) {
            parent.post { renderBoundNativeAd() }
            return
        }

        val pxX = (bounds.xRatio * parentW).roundToInt().coerceAtLeast(0)
        val pxY = (bounds.yRatio * parentH).roundToInt().coerceAtLeast(0)
        val pxW = (bounds.wRatio * parentW).roundToInt().coerceIn(min(200, parentW), parentW)
        val pxH = (bounds.hRatio * parentH).roundToInt().coerceIn(min(70, parentH), parentH)

        val lp = FrameLayout.LayoutParams(pxW, pxH).apply {
            leftMargin = pxX
            topMargin = pxY
        }
        container.layoutParams = lp

        container.removeAllViews()
        val adView = LayoutInflater.from(activity)
            .inflate(R.layout.native_ad_layout, container, false) as NativeAdView

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)
        val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)
        val iconView = adView.findViewById<ImageView>(R.id.ad_app_icon)
        val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
        val choicesView = adView.findViewById<AdChoicesView>(R.id.ad_choices_view)

        adView.headlineView = headlineView
        adView.bodyView = bodyView
        adView.advertiserView = advertiserView
        adView.callToActionView = ctaView
        adView.iconView = iconView
        adView.mediaView = mediaView
        adView.adChoicesView = choicesView

        headlineView.text = ad.headline ?: ""
        bodyView.text = ad.body ?: ""
        bodyView.visibility = if (ad.body.isNullOrBlank()) View.GONE else View.VISIBLE
        advertiserView.text = ad.advertiser ?: "Sponsored"

        if (ad.callToAction.isNullOrBlank()) {
            ctaView.visibility = View.GONE
        } else {
            ctaView.visibility = View.VISIBLE
            ctaView.text = ad.callToAction
        }

        if (ad.icon != null) {
            iconView.setImageDrawable(ad.icon?.drawable)
            iconView.visibility = View.VISIBLE
        } else {
            iconView.visibility = View.GONE
        }

        if (ad.mediaContent != null && pxW >= 360) {
            mediaView.mediaContent = ad.mediaContent
            mediaView.visibility = View.VISIBLE
        } else {
            mediaView.visibility = View.GONE
        }

        adView.setNativeAd(ad)
        container.addView(adView)
        container.visibility = View.VISIBLE
    }

    fun isNativeLoaded(): Boolean = cachedNativeAd != null && nativeState == AdFormatState.LOADED

    // =========================================================================
    // 5. REWARDED AD (Strictly opt-in, earned callback guarded)
    // =========================================================================

    fun preloadRewarded() {
        if (!isSdkInitialized || !canRequestAds()) return
        if (rewardedState == AdFormatState.LOADING || rewardedAd != null) return

        rewardedState = AdFormatState.LOADING
        if (AdConfig.isTestMode) {
            Log.d(AdConfig.LOG_TAG, "Rewarded load started (${AdConfig.activeRewardedId})")
        } else {
            Log.d(AdConfig.LOG_TAG, "Rewarded load started")
        }

        RewardedAd.load(
            appContext,
            AdConfig.activeRewardedId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    rewardedState = AdFormatState.LOADED
                    rewardedRetryCount = 0
                    Log.i(AdConfig.LOG_TAG, "Rewarded loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    rewardedState = AdFormatState.FAILED
                    lastLoadError = "Rewarded(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "Rewarded load failed code=${error.code}: ${error.message}")
                    scheduleRetry(rewardedRetryCount++) { preloadRewarded() }
                }
            }
        )
    }

    fun isRewardedReady(): Boolean = rewardedAd != null && rewardedState == AdFormatState.LOADED

    fun showRewarded(placement: String, onCompleted: (Boolean) -> Unit) {
        val activity = activityRef?.get()
        if (activity == null || isFullscreenShowing) {
            Log.d(AdConfig.LOG_TAG, "Rewarded unavailable/busy for $placement.")
            onCompleted(false)
            return
        }

        val ad = rewardedAd ?: run {
            preloadRewarded()
            Log.w(AdConfig.LOG_TAG, "Rewarded not loaded when requested ($placement).")
            onCompleted(false)
            return
        }

        isFullscreenShowing = true
        rewardedState = AdFormatState.SHOWING
        var rewardEarned = false
        var callbackDispatched = false

        fun finishOnce(granted: Boolean) {
            if (callbackDispatched) return
            callbackDispatched = true
            isFullscreenShowing = false
            hostCallbacksRef?.get()?.onFullscreenAdDismissed()
            onCompleted(granted)
            preloadRewarded()
        }

        hostCallbacksRef?.get()?.onFullscreenAdWillShow()

        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                rewardedState = AdFormatState.LOADED
                finishOnce(false)
                return@post
            }
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "Rewarded displayed ($placement).")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "Rewarded impression recorded ($placement).")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "Rewarded clicked ($placement).")
                }

                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    rewardedState = AdFormatState.NOT_AVAILABLE
                    Log.i(AdConfig.LOG_TAG, "Rewarded dismissed ($placement), earned=$rewardEarned")
                    finishOnce(rewardEarned)
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    rewardedState = AdFormatState.FAILED
                    lastLoadError = "RewardedShow(${error.code}): ${error.message}"
                    Log.w(AdConfig.LOG_TAG, "Rewarded show failed code=${error.code}: ${error.message}")
                    finishOnce(false)
                }
            }

            ad.show(activity) { rewardItem ->
                rewardEarned = true
                Log.i(
                    AdConfig.LOG_TAG,
                    "Rewarded user earned reward ($placement): ${rewardItem.amount} ${rewardItem.type}"
                )
            }
        }
    }

    // =========================================================================
    // RETRY, LIFECYCLE & DEBUG DIAGNOSTICS
    // =========================================================================

    private fun scheduleRetry(attempt: Int, action: () -> Unit) {
        if (attempt >= MAX_RETRY_ATTEMPTS) return
        val delayMs = (min(4, attempt + 1) * 15_000L)
        mainHandler.postDelayed({
            if (isSdkInitialized && canRequestAds()) {
                action()
            }
        }, delayMs)
    }

    fun getDebugStatusJson(): String {
        if (!BuildConfig.DEBUG) return "{}"
        val obj = JSONObject()
        obj.put("mode", if (AdConfig.isTestMode) "TEST_ADS" else "PRODUCTION")
        obj.put("sdkInitialized", isSdkInitialized)
        obj.put("consentStatus", consentManager?.statusLabel ?: "UNKNOWN")
        obj.put("canRequestAds", canRequestAds())
        obj.put("privacyOptionsRequired", consentManager?.isPrivacyOptionsRequired ?: false)
        obj.put("appOpenState", appOpenState.name)
        obj.put("bannerState", bannerState.name)
        obj.put("interstitialState", interstitialState.name)
        obj.put("nativeState", nativeState.name)
        obj.put("rewardedState", rewardedState.name)
        obj.put("lastLoadError", lastLoadError)
        return obj.toString()
    }

    fun onActivityPaused() {
        bannerView?.pause()
    }

    fun onActivityResumed() {
        bannerView?.resume()
    }

    fun releaseCachedNative() {
        cachedNativeAd?.destroy()
        cachedNativeAd = null
    }
}
