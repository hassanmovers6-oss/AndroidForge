-keepclassmembers class com.educationwithhassan.shadowninja.GameBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.educationwithhassan.shadowninja.AdFormatState { *; }
-keep class com.educationwithhassan.shadowninja.AdConfig { *; }
-keep class com.educationwithhassan.shadowninja.AdMobManager { *; }
-keep class com.educationwithhassan.shadowninja.ShadowNinjaApplication { *; }
-keepattributes *Annotation*
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.ump.** { *; }
