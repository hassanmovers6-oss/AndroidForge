# Shadow Ninja – Dark Quest (Android Project)

**Package:** `com.educationwithhassan.shadowninja`  
**Developer:** Rana Hassan  
**Orientation:** Sensor Landscape

## Centralized Six-Format Google AdMob Configuration
All six AdMob identifiers are pre-configured in `AdConfig.kt`, `AndroidManifest.xml`, and `res/values/strings.xml`:

- **App ID:** `ca-app-pub-3133971041724338~5461456996`
- **App Open:** `ca-app-pub-3133971041724338/3363962603`
- **Banner (Anchored Adaptive):** `ca-app-pub-3133971041724338/8121465266`
- **Interstitial:** `ca-app-pub-3133971041724338/3613188701`
- **Native Advanced:** `ca-app-pub-3133971041724338/2076745751`
- **Rewarded:** `ca-app-pub-3133971041724338/2300107036`

### Debug vs. Release Safety
- **`BuildConfig.DEBUG == true` (`./gradlew assembleDebug`):** `AdConfig` automatically routes all requests to Google's official Test Ad Unit IDs (`ca-app-pub-3940256099942544/...`) and unlocks the Logcat + in-app **AdMob SDK Diagnostics** report under Settings.
- **`BuildConfig.DEBUG == false` (`./gradlew assembleRelease`):** `AdConfig` strictly uses the six production IDs above and hides all debug inspection panels.
- Never click live ads during testing.

## Building the APK (Android Studio / AndroidForge)
- Import `ShadowNinja-DarkQuest-Android/` into Android Studio or upload the exported ZIP from `/api/export-android-zip` into AndroidForge.
- Web assets under `app/src/main/assets/` are generated from `npm run build` (`dist/`).
- Gradle sync requires network access to Google Maven (`com.google.android.gms:play-services-ads:23.6.0`, `com.google.android.ump:user-messaging-platform:3.1.0`).
