package com.arrowmaze.nightmare.ads

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AdFrequencyControllerTest {

    @Test
    fun `production admob app id matches verified id`() {
        assertEquals("ca-app-pub-3133971041724338~2576474017", AdConfig.PROD_APP_ID)
        assertNotEquals(AdConfig.PROD_APP_ID, AdConfig.TEST_APP_ID)
    }

    @Test
    fun `interstitial respects level interval and gameplay lock`() {
        val controller = AdFrequencyController()
        controller.setCriticalLoadingScreen(false)
        controller.setGameplayActive(false)
        controller.setArrowAnimationRunning(false)

        // Requires 3 completed levels by default
        controller.recordLevelCompleted()
        assertFalse(controller.canShowInterstitial())
        controller.recordLevelCompleted()
        assertFalse(controller.canShowInterstitial())
        controller.recordLevelCompleted()
        assertTrue(controller.canShowInterstitial())

        // Suppressed during active gameplay or ongoing arrow animation
        controller.setGameplayActive(true)
        assertFalse(controller.canShowInterstitial())
        controller.setGameplayActive(false)
        controller.setArrowAnimationRunning(true)
        assertFalse(controller.canShowInterstitial())
        controller.setArrowAnimationRunning(false)

        // Cannot show immediately again after dismissal (120s cooldown + counter reset)
        controller.onInterstitialDismissed()
        assertFalse(controller.canShowInterstitial())
    }

    @Test
    fun `rewarded ad suppresses immediate subsequent interstitial`() {
        val controller = AdFrequencyController()
        controller.setCriticalLoadingScreen(false)
        controller.recordLevelCompleted()
        controller.recordLevelCompleted()
        controller.recordLevelCompleted()
        assertTrue(controller.canShowInterstitial())

        controller.onRewardedDismissed(rewardGranted = true)
        assertFalse(controller.canShowInterstitial())
    }

    @Test
    fun `fullscreen lock prevents simultaneous overlapping ads`() {
        val controller = AdFrequencyController()
        assertTrue(controller.tryAcquireFullscreenLock())
        assertFalse(controller.tryAcquireFullscreenLock())
        assertFalse(controller.canShowRewarded())
        controller.releaseFullscreenLock()
        assertTrue(controller.canShowRewarded())
    }
}
