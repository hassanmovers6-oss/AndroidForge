package com.arrowmaze.nightmare.engine

import org.junit.Assert.assertTrue
import org.junit.Test

class ArrowMazeGeneratorTest {

    @Test
    fun all600LevelsAreDenseAndSolvable() {
        for (levelNum in 1..DifficultyCategory.TOTAL_LEVELS) {
            val level = ArrowMazeGenerator.generateLevel(levelNum)
            assertTrue("Level $levelNum must contain multi-segment arrow paths", level.paths.size >= 25)
            assertTrue("Level $levelNum must be 100% solvable", ArrowMazeGenerator.verifySolvable(level))
        }
    }
}
