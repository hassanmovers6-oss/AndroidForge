package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ActivityGameplayBinding
import com.arrowmaze.nightmare.engine.ArrowMazeCollision
import com.arrowmaze.nightmare.engine.ArrowMazeGenerator
import com.arrowmaze.nightmare.engine.ArrowMazeLevel
import com.arrowmaze.nightmare.engine.ArrowPath
import com.arrowmaze.nightmare.engine.DifficultyCategory
import com.arrowmaze.nightmare.ui.view.ArrowMazeCanvasView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameplayActivity : AppCompatActivity(), ArrowMazeCanvasView.OnPathTapListener {

    companion object {
        const val EXTRA_LEVEL_NUMBER = "extra_level_number"
        private const val KEY_LEVEL = "state_level"
        private const val KEY_HEARTS = "state_hearts"
        private const val KEY_REMAINING_IDS = "state_remaining_ids"
        private const val KEY_MOVES = "state_moves"
        private const val KEY_ELAPSED = "state_elapsed"
        private const val KEY_EXTRA_LIVES_USED = "state_extra_lives_used"
    }

    private lateinit var binding: ActivityGameplayBinding
    private lateinit var app: ArrowMazeApplication

    private var levelNumber: Int = 1
    private var levelData: ArrowMazeLevel? = null
    private var remainingPaths: MutableList<ArrowPath> = ArrayList()
    private var gridLookup: IntArray = IntArray(0)

    private var hearts: Int = 3
    private var movesCount: Int = 0
    private var extraLivesUsedThisAttempt: Int = 0
    private var activeHintPath: ArrowPath? = null
    private var sessionStartMs: Long = 0L
    private var accumulatedElapsedMs: Long = 0L
    private var isLevelFinished: Boolean = false

    private val pauseLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == PauseActivity.RESULT_RESTART) {
            restartLevel()
        } else if (result.resultCode == PauseActivity.RESULT_QUIT_HOME) {
            finish()
        } else {
            sessionStartMs = System.currentTimeMillis()
        }
    }

    private val gameOverLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        when (result.resultCode) {
            GameOverActivity.RESULT_EXTRA_LIFE -> {
                hearts = 1
                extraLivesUsedThisAttempt++
                isLevelFinished = false
                app.adManager.frequencyController.setGameplayActive(true)
                sessionStartMs = System.currentTimeMillis()
                updateHeartsUi()
                binding.tvStatusHint.text = "Extra red heart restored! Clear remaining arrow paths."
            }
            GameOverActivity.RESULT_RESTART -> restartLevel()
            else -> finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameplayBinding.inflate(layoutInflater)
        setContentView(binding.root)
        app = application as ArrowMazeApplication

        levelNumber = savedInstanceState?.getInt(KEY_LEVEL)
            ?: intent.getIntExtra(EXTRA_LEVEL_NUMBER, 1).coerceIn(1, DifficultyCategory.TOTAL_LEVELS)

        binding.arrowCanvas.onPathTapListener = this
        binding.btnBack.setOnClickListener { finish() }
        binding.btnRestart.setOnClickListener { restartLevel() }
        binding.btnPause.setOnClickListener { openPauseScreen() }
        binding.btnHint.setOnClickListener { handleHintPressed() }

        loadLevel(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (!isLevelFinished) {
            sessionStartMs = System.currentTimeMillis()
            app.adManager.frequencyController.setGameplayActive(true)
        }
    }

    override fun onPause() {
        app.adManager.frequencyController.setGameplayActive(false)
        app.adManager.frequencyController.setArrowAnimationRunning(false)
        if (!isLevelFinished && sessionStartMs > 0L) {
            accumulatedElapsedMs += (System.currentTimeMillis() - sessionStartMs)
            sessionStartMs = 0L
        }
        super.onPause()
    }

    override fun onDestroy() {
        app.adManager.frequencyController.setGameplayActive(false)
        app.adManager.frequencyController.setArrowAnimationRunning(false)
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_LEVEL, levelNumber)
        outState.putInt(KEY_HEARTS, hearts)
        outState.putInt(KEY_MOVES, movesCount)
        outState.putInt(KEY_EXTRA_LIVES_USED, extraLivesUsedThisAttempt)
        outState.putIntArray(KEY_REMAINING_IDS, remainingPaths.map { it.id }.toIntArray())
        outState.putLong(KEY_ELAPSED, accumulatedElapsedMs)
    }

    private fun loadLevel(savedState: Bundle?) {
        lifecycleScope.launch {
            val generated = withContext(Dispatchers.Default) {
                ArrowMazeGenerator.generateLevel(levelNumber)
            }
            withContext(Dispatchers.IO) {
                app.repository.recordAttempt(levelNumber)
            }

            levelData = generated
            isLevelFinished = false
            activeHintPath = null

            if (savedState != null) {
                hearts = savedState.getInt(KEY_HEARTS, 3).coerceIn(1, 3)
                movesCount = savedState.getInt(KEY_MOVES, 0)
                extraLivesUsedThisAttempt = savedState.getInt(KEY_EXTRA_LIVES_USED, 0)
                accumulatedElapsedMs = savedState.getLong(KEY_ELAPSED, 0L)
                val savedIds = savedState.getIntArray(KEY_REMAINING_IDS)?.toHashSet()
                remainingPaths = if (savedIds != null && savedIds.isNotEmpty()) {
                    generated.paths.filter { it.id in savedIds }.toMutableList()
                } else {
                    generated.paths.toMutableList()
                }
            } else {
                hearts = 3
                movesCount = 0
                extraLivesUsedThisAttempt = 0
                accumulatedElapsedMs = 0L
                remainingPaths = generated.paths.toMutableList()
            }

            rebuildGridLookup()
            sessionStartMs = System.currentTimeMillis()
            app.adManager.frequencyController.setGameplayActive(true)
            renderBoard()
        }
    }

    private fun restartLevel() {
        val lvl = levelData ?: return
        hearts = 3
        movesCount = 0
        extraLivesUsedThisAttempt = 0
        accumulatedElapsedMs = 0L
        sessionStartMs = System.currentTimeMillis()
        isLevelFinished = false
        activeHintPath = null
        remainingPaths = lvl.paths.toMutableList()
        rebuildGridLookup()
        binding.arrowCanvas.clearTransientAnimations()
        app.adManager.frequencyController.setGameplayActive(true)
        app.adManager.frequencyController.setArrowAnimationRunning(false)
        binding.tvStatusHint.text = "Tap an arrow path with a clear exit route"
        renderBoard()
    }

    private fun rebuildGridLookup() {
        val lvl = levelData ?: return
        gridLookup = IntArray(lvl.rows * lvl.cols) { -1 }
        for (p in remainingPaths) {
            for (c in p.cells) {
                gridLookup[c.row * lvl.cols + c.col] = p.id
            }
        }
    }

    override fun onPathTapped(path: ArrowPath) {
        val lvl = levelData ?: return
        if (isLevelFinished) return

        val blocker = ArrowMazeCollision.findPathBlocker(
            grid = gridLookup,
            rows = lvl.rows,
            cols = lvl.cols,
            path = path
        )

        if (blocker == null) {
            // Unobstructed: clear all cells of this path from occupancy grid & animate slithering escape
            for (c in path.cells) {
                gridLookup[c.row * lvl.cols + c.col] = -1
            }
            remainingPaths.removeAll { it.id == path.id }
            movesCount++
            if (activeHintPath?.id == path.id) {
                activeHintPath = null
            }

            app.feedbackManager.playMove()
            app.adManager.frequencyController.setArrowAnimationRunning(true)
            binding.arrowCanvas.launchEscapingPath(path)
            binding.tvStatusHint.text = "${remainingPaths.size} arrow path${if (remainingPaths.size == 1) "" else "s"} remaining"
            renderBoard()

            if (remainingPaths.isEmpty()) {
                onLevelCleared()
            }
        } else {
            // Blocked: keep on board, lose 1 red heart & show collision visual feedback
            app.feedbackManager.playError()
            binding.arrowCanvas.triggerBlockedFeedback(path, blocker)
            hearts = (hearts - 1).coerceAtLeast(0)
            updateHeartsUi()
            binding.tvStatusHint.text = "Path blocked by another arrow! (-1 Heart)"

            lifecycleScope.launch(Dispatchers.IO) {
                app.repository.prefs.recordMistake()
                if (hearts == 0) {
                    app.repository.prefs.recordLevelLoss()
                }
            }

            if (hearts <= 0) {
                isLevelFinished = true
                app.adManager.frequencyController.setGameplayActive(false)
                accumulatedElapsedMs += (System.currentTimeMillis() - sessionStartMs).coerceAtLeast(0L)
                val intent = Intent(this, GameOverActivity::class.java).apply {
                    putExtra(GameOverActivity.EXTRA_LEVEL_NUMBER, levelNumber)
                    putExtra(GameOverActivity.EXTRA_EXTRA_LIVES_USED, extraLivesUsedThisAttempt)
                }
                gameOverLauncher.launch(intent)
            }
        }
    }

    private fun onLevelCleared() {
        isLevelFinished = true
        app.feedbackManager.playWin()
        app.adManager.frequencyController.recordLevelCompleted()
        val totalElapsedMs = accumulatedElapsedMs + (System.currentTimeMillis() - sessionStartMs).coerceAtLeast(0L)

        lifecycleScope.launch {
            val coinsEarned = withContext(Dispatchers.IO) {
                app.repository.markLevelCompleted(levelNumber, movesCount, totalElapsedMs, hearts)
            }
            waitForAnimationsAndNavigateToCleared(totalElapsedMs, coinsEarned, attempts = 0)
        }
    }

    private fun waitForAnimationsAndNavigateToCleared(
        totalElapsedMs: Long,
        coinsEarned: Int,
        attempts: Int
    ) {
        if (isFinishing || isDestroyed) return
        val delayMs = if (attempts == 0) 750L else 220L
        binding.arrowCanvas.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            if (binding.arrowCanvas.hasActiveAnimations() && attempts < 10) {
                waitForAnimationsAndNavigateToCleared(totalElapsedMs, coinsEarned, attempts + 1)
                return@postDelayed
            }
            app.adManager.frequencyController.setArrowAnimationRunning(false)
            app.adManager.frequencyController.setGameplayActive(false)
            val intent = Intent(this@GameplayActivity, LevelCompletedActivity::class.java).apply {
                putExtra(LevelCompletedActivity.EXTRA_LEVEL_NUMBER, levelNumber)
                putExtra(LevelCompletedActivity.EXTRA_MOVES, movesCount)
                putExtra(LevelCompletedActivity.EXTRA_TIME_MS, totalElapsedMs)
                putExtra(LevelCompletedActivity.EXTRA_COINS_EARNED, coinsEarned)
            }
            startActivity(intent)
            finish()
        }, delayMs)
    }

    /**
     * Pressing Hint shows a clear opt-in explanation before launching a Rewarded Ad.
     * Only upon verified OnUserEarnedRewardListener completion does it highlight one currently
     * escapable arrow path and its exit direction — without auto-clearing the path.
     */
    private fun handleHintPressed() {
        if (isLevelFinished) return

        AlertDialog.Builder(this)
            .setTitle(R.string.hint_dialog_title)
            .setMessage(R.string.hint_dialog_desc)
            .setPositiveButton(R.string.hint_dialog_watch) { _, _ ->
                if (!app.adManager.isRewardedAdReady()) {
                    Toast.makeText(this, getString(R.string.ad_unavailable_hint), Toast.LENGTH_SHORT).show()
                    app.adManager.loadRewardedAd()
                    return@setPositiveButton
                }

                app.adManager.showRewardedAd(
                    activity = this,
                    onRewardEarned = {
                        lifecycleScope.launch(Dispatchers.IO) {
                            app.repository.prefs.recordHintUsedDirect()
                        }
                        revealEscapableHintPath()
                    },
                    onAdClosedWithoutReward = {
                        Toast.makeText(this, getString(R.string.ad_failed_no_reward), Toast.LENGTH_SHORT).show()
                    },
                    onAdUnavailable = {
                        Toast.makeText(this, getString(R.string.ad_unavailable_hint), Toast.LENGTH_SHORT).show()
                    }
                )
            }
            .setNegativeButton(R.string.hint_dialog_cancel, null)
            .show()
    }

    private fun revealEscapableHintPath() {
        val lvl = levelData ?: return
        val hint = ArrowMazeCollision.findBestHintPath(remainingPaths, lvl.rows, lvl.cols)
        if (hint != null) {
            activeHintPath = hint
            app.feedbackManager.playHint()
            binding.tvStatusHint.text = "Hint: Tap the green path (${hint.dir.symbol} exit clear)"
            renderBoard()
        }
    }

    private fun openPauseScreen() {
        if (isLevelFinished) return
        accumulatedElapsedMs += (System.currentTimeMillis() - sessionStartMs).coerceAtLeast(0L)
        sessionStartMs = 0L
        val intent = Intent(this, PauseActivity::class.java).apply {
            putExtra(PauseActivity.EXTRA_LEVEL_NUMBER, levelNumber)
        }
        pauseLauncher.launch(intent)
    }

    private fun renderBoard() {
        val lvl = levelData ?: return
        binding.arrowCanvas.setMazeState(lvl.rows, lvl.cols, remainingPaths, activeHintPath)
        updateHeartsUi()

        val total = lvl.paths.size.coerceAtLeast(1)
        val cleared = (total - remainingPaths.size).coerceAtLeast(0)
        binding.tvLevelInfo.text = "Level $levelNumber · ${lvl.category.title}"
        binding.tvProgressInfo.text = "${remainingPaths.size} / $total paths left"
        binding.levelProgressBar.progress = ((cleared.toFloat() / total) * 100f).toInt().coerceIn(0, 100)
    }

    private fun updateHeartsUi() {
        binding.ivHeart1.setImageResource(if (hearts >= 1) R.drawable.ic_heart_filled else R.drawable.ic_heart_empty)
        binding.ivHeart2.setImageResource(if (hearts >= 2) R.drawable.ic_heart_filled else R.drawable.ic_heart_empty)
        binding.ivHeart3.setImageResource(if (hearts >= 3) R.drawable.ic_heart_filled else R.drawable.ic_heart_empty)
    }
}
