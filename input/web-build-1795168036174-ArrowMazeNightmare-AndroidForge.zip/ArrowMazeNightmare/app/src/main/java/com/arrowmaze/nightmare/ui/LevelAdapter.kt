package com.arrowmaze.nightmare.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.data.LevelProgressEntity
import com.arrowmaze.nightmare.databinding.ItemLevelCardBinding

class LevelAdapter(
    private val onLevelSelected: (Int) -> Unit
) : RecyclerView.Adapter<LevelAdapter.LevelViewHolder>() {

    private var items: List<LevelProgressEntity> = emptyList()

    fun submitList(list: List<LevelProgressEntity>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LevelViewHolder {
        val binding = ItemLevelCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LevelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LevelViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class LevelViewHolder(
        private val binding: ItemLevelCardBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: LevelProgressEntity) {
            val ctx = binding.root.context
            binding.tvLevelNumber.text = item.levelNumber.toString()

            when {
                item.completed -> {
                    binding.tvLevelNumber.setTextColor(ContextCompat.getColor(ctx, R.color.success_emerald))
                    binding.ivLevelStatus.setImageResource(R.drawable.ic_check)
                    binding.root.alpha = 1f
                    binding.root.setOnClickListener { onLevelSelected(item.levelNumber) }
                }
                item.unlocked -> {
                    binding.tvLevelNumber.setTextColor(ContextCompat.getColor(ctx, R.color.nightmare_pink))
                    binding.ivLevelStatus.setImageResource(R.drawable.ic_heart_filled)
                    binding.root.alpha = 1f
                    binding.root.setOnClickListener { onLevelSelected(item.levelNumber) }
                }
                else -> {
                    binding.tvLevelNumber.setTextColor(ContextCompat.getColor(ctx, R.color.text_muted))
                    binding.ivLevelStatus.setImageResource(R.drawable.ic_lock)
                    binding.root.alpha = 0.65f
                    binding.root.setOnClickListener(null)
                }
            }
        }
    }
}
