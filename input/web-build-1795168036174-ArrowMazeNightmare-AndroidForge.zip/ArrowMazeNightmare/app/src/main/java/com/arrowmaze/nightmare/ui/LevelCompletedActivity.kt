package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ActivityLevelCompletedBinding
import com.arrowmaze.nightmare.engine.DifficultyCategory
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LevelCompletedActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LEVEL_NUMBER = "extra_level_number"
        const val EXTRA_MOVES = "extra_moves"
        const val EXTRA_TIME_MS = "extra_time_ms"
        const val EXTRA_COINS_EARNED = "extra_coins_earned"
    }

    private lateinit var binding: ActivityLevelCompletedBinding
    private var bannerAdView: AdView? = null
    private var bonusClaimed = false
    private var isNavigating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLevelCompletedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        val levelNumber = intent.getIntExtra(EXTRA_LEVEL_NUMBER, 1)
        val moves = intent.getIntExtra(EXTRA_MOVES, 0)
        val timeMs = intent.getLongExtra(EXTRA_TIME_MS, 0L)
        val coins = intent.getIntExtra(EXTRA_COINS_EARNED, 10)
        val category = DifficultyCategory.forLevel(levelNumber)

        binding.tvCompletedSubtitle.text = "Level $levelNumber · ${category.title}"
        binding.tvStatMoves.text = moves.toString()
        binding.tvStatTime.text = "${(timeMs / 1000L).coerceAtLeast(1L)}s"
        binding.tvStatCoins.text = "+$coins"

        if (levelNumber >= DifficultyCategory.TOTAL_LEVELS) {
            binding.btnNextLevel.text = "All 600 Levels Completed!"
            binding.btnNextLevel.setOnClickListener {
                navigateAfterEligibleInterstitial(app) {
                    startActivity(Intent(this, LevelSelectActivity::class.java))
                    finish()
                }
            }
        } else {
            binding.btnNextLevel.setOnClickListener {
                navigateAfterEligibleInterstitial(app) {
                    val intent = Intent(this, GameplayActivity::class.java)
                    intent.putExtra(GameplayActivity.EXTRA_LEVEL_NUMBER, levelNumber + 1)
                    startActivity(intent)
                    finish()
                }
            }
        }

        binding.btnReplay.setOnClickListener {
            navigateAfterEligibleInterstitial(app) {
                val intent = Intent(this, GameplayActivity::class.java)
                intent.putExtra(GameplayActivity.EXTRA_LEVEL_NUMBER, levelNumber)
                startActivity(intent)
                finish()
            }
        }

        binding.btnHome.setOnClickListener {
            navigateAfterEligibleInterstitial(app) {
                finish()
            }
        }

        // Rewarded Interstitial Ad with explicit user opt-in intro & skip option
        binding.btnBonusCoins.setOnClickListener {
            if (bonusClaimed) return@setOnClickListener
            if (!app.adManager.isRewardedInterstitialReady()) {
                Toast.makeText(this, "Bonus ad is not ready right now.", Toast.LENGTH_SHORT).show()
                app.adManager.loadRewardedInterstitialAd()
                return@setOnClickListener
            }

            AlertDialog.Builder(this)
                .setTitle(R.string.rewarded_interstitial_title)
                .setMessage(R.string.rewarded_interstitial_desc)
                .setPositiveButton(R.string.rewarded_interstitial_watch) { _, _ ->
                    app.adManager.showRewardedInterstitialAd(
                        activity = this,
                        onRewardEarned = {
                            bonusClaimed = true
                            binding.btnBonusCoins.visibility = View.GONE
                            binding.tvStatCoins.text = "+${coins + 30}"
                            lifecycleScope.launch(Dispatchers.IO) {
                                app.repository.prefs.addCoins(30)
                            }
                            Toast.makeText(this, "+30 Bonus Coins added!", Toast.LENGTH_SHORT).show()
                        },
                        onClosedWithoutReward = {
                            Toast.makeText(this, getString(R.string.ad_failed_no_reward), Toast.LENGTH_SHORT).show()
                        },
                        onUnavailable = {
                            Toast.makeText(this, "Bonus ad unavailable right now.", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                .setNegativeButton(R.string.rewarded_interstitial_skip, null)
                .show()
        }

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
    }

    private fun navigateAfterEligibleInterstitial(
        app: ArrowMazeApplication,
        action: () -> Unit
    ) {
        if (isNavigating || isFinishing || isDestroyed) return
        isNavigating = true
        app.adManager.showInterstitialOnMenuTransitionIfEligible(this) {
            if (!isFinishing && !isDestroyed) {
                action()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        super.onDestroy()
    }
}
