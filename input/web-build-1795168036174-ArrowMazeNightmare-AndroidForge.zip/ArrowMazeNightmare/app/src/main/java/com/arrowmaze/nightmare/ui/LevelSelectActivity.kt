package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ActivityLevelSelectBinding
import com.arrowmaze.nightmare.engine.DifficultyCategory
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LevelSelectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLevelSelectBinding
    private lateinit var adapter: LevelAdapter
    private var selectedCategory: DifficultyCategory = DifficultyCategory.HARD
    private var bannerAdView: AdView? = null
    private var loadedNativeAd: NativeAd? = null
    private val tabButtons = ArrayList<Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLevelSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication

        binding.btnBack.setOnClickListener { finish() }

        adapter = LevelAdapter { levelNumber ->
            val intent = Intent(this, GameplayActivity::class.java)
            intent.putExtra(GameplayActivity.EXTRA_LEVEL_NUMBER, levelNumber)
            startActivity(intent)
        }

        binding.rvLevels.layoutManager = GridLayoutManager(this, 5)
        binding.rvLevels.adapter = adapter

        buildCategoryTabs()

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
        app.adManager.loadNativeAd(this, binding.nativeAdContainer) { nativeAd ->
            loadedNativeAd?.destroy()
            loadedNativeAd = nativeAd
        }
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
        loadSelectedCategory()
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        loadedNativeAd?.destroy()
        loadedNativeAd = null
        super.onDestroy()
    }

    private fun buildCategoryTabs() {
        binding.tierTabsContainer.removeAllViews()
        tabButtons.clear()

        for (cat in DifficultyCategory.entries) {
            val btn = Button(this).apply {
                text = cat.title
                isAllCaps = false
                textSize = 13f
                setPadding(34, 14, 34, 14)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = 12 }
                layoutParams = lp
                setOnClickListener {
                    selectedCategory = cat
                    updateTabVisuals()
                    loadSelectedCategory()
                }
            }
            tabButtons.add(btn)
            binding.tierTabsContainer.addView(btn)
        }
        updateTabVisuals()
    }

    private fun updateTabVisuals() {
        for (i in DifficultyCategory.entries.indices) {
            val cat = DifficultyCategory.entries[i]
            val btn = tabButtons[i]
            if (cat == selectedCategory) {
                btn.setBackgroundResource(R.drawable.bg_button_pink)
                btn.setTextColor(ContextCompat.getColor(this, R.color.white_pure))
            } else {
                btn.setBackgroundResource(R.drawable.bg_card_white)
                btn.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            }
        }
    }

    private fun loadSelectedCategory() {
        val app = application as ArrowMazeApplication
        lifecycleScope.launch {
            val (levels, completedTotal) = withContext(Dispatchers.IO) {
                Pair(
                    app.repository.getLevelsInCategory(selectedCategory),
                    app.repository.getCompletedCount()
                )
            }
            binding.tvOverallProgress.text = "Completed: $completedTotal / 600"
            adapter.submitList(levels)
        }
    }
}
