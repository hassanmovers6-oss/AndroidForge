package com.arrowmaze.nightmare.data

import android.content.Context
import com.arrowmaze.nightmare.engine.DifficultyCategory
import kotlinx.coroutines.flow.Flow

class GameRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val dao = db.levelProgressDao()
    val prefs = PreferencesManager(context)

    fun observeAllLevels(): Flow<List<LevelProgressEntity>> = dao.observeAllProgress()

    suspend fun ensureInitialized() {
        try {
            val existing = dao.getLevel(1)
            val lastExisting = dao.getLevel(DifficultyCategory.TOTAL_LEVELS)
            if (existing == null || lastExisting == null) {
                val initial = (1..DifficultyCategory.TOTAL_LEVELS).map { lvl ->
                    LevelProgressEntity(
                        levelNumber = lvl,
                        unlocked = (lvl == 1)
                    )
                }
                dao.insertAllIgnore(initial)
            }
        } catch (_: Exception) {
            // Safe guard against database initialization errors
        }
    }

    suspend fun getLevelsInCategory(category: DifficultyCategory): List<LevelProgressEntity> {
        ensureInitialized()
        return dao.getLevelsInRange(category.startLevel, category.endLevel)
    }

    suspend fun getCompletedCount(): Int {
        ensureInitialized()
        return dao.getCompletedCount()
    }

    suspend fun getHighestUnlockedLevel(): Int {
        ensureInitialized()
        return (dao.getHighestUnlockedLevel() ?: 1).coerceIn(1, DifficultyCategory.TOTAL_LEVELS)
    }

    suspend fun markLevelCompleted(
        levelNumber: Int,
        moves: Int,
        elapsedMs: Long,
        heartsRemaining: Int
    ): Int {
        ensureInitialized()
        val existing = dao.getLevel(levelNumber) ?: LevelProgressEntity(levelNumber = levelNumber, unlocked = true)
        val stars = heartsRemaining.coerceIn(1, 3)
        val bestMoves = if (existing.bestMoves == 0) moves else minOf(existing.bestMoves, moves)
        val bestTime = if (existing.bestTimeMs == 0L) elapsedMs else minOf(existing.bestTimeMs, elapsedMs)

        dao.upsert(
            existing.copy(
                unlocked = true,
                completed = true,
                bestMoves = bestMoves,
                bestTimeMs = bestTime,
                stars = maxOf(existing.stars, stars),
                attempts = existing.attempts + 1
            )
        )

        if (levelNumber < DifficultyCategory.TOTAL_LEVELS) {
            val next = dao.getLevel(levelNumber + 1)
                ?: LevelProgressEntity(levelNumber = levelNumber + 1)
            if (!next.unlocked) {
                dao.upsert(next.copy(unlocked = true))
            }
            prefs.setCurrentLevel(levelNumber + 1)
        }

        val category = DifficultyCategory.forLevel(levelNumber)
        val coinReward = category.rewardCoins + (stars * 3)
        prefs.recordLevelWin(elapsedMs, coinReward)
        return coinReward
    }

    suspend fun recordAttempt(levelNumber: Int) {
        ensureInitialized()
        val existing = dao.getLevel(levelNumber) ?: LevelProgressEntity(levelNumber = levelNumber, unlocked = true)
        dao.upsert(existing.copy(attempts = existing.attempts + 1))
        prefs.recordLevelStart()
    }
}
