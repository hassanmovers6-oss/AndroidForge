package com.arrowmaze.nightmare.ads

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Centralized Smart Ad Frequency Controller.
 * Prevents ad stacking, respects cooldowns, protects active gameplay and ongoing arrow animations,
 * and ensures rewarded ads never trigger an immediate interstitial afterwards.
 */
class AdFrequencyController {

    data class FrequencySettings(
        val interstitialLevelInterval: Int = AdConfig.DEFAULT_INTERSTITIAL_LEVEL_INTERVAL,
        val interstitialCooldownMs: Long = AdConfig.DEFAULT_INTERSTITIAL_COOLDOWN_MS,
        val postRewardedBufferMs: Long = AdConfig.DEFAULT_POST_REWARDED_BUFFER_MS,
        val minFullscreenGapMs: Long = AdConfig.DEFAULT_MIN_FULLSCREEN_GAP_MS,
        val rewardedInterstitialCooldownMs: Long = AdConfig.DEFAULT_REWARDED_INTERSTITIAL_COOLDOWN_MS,
        val appOpenCooldownMs: Long = AdConfig.DEFAULT_APP_OPEN_COOLDOWN_MS,
        val maxExtraLivesPerAttempt: Int = AdConfig.MAX_EXTRA_LIVES_PER_ATTEMPT
    )

    @Volatile
    var settings: FrequencySettings = FrequencySettings()
        private set

    private val lastFullscreenAdMs = AtomicLong(0L)
    private val lastInterstitialMs = AtomicLong(0L)
    private val lastAppOpenMs = AtomicLong(0L)
    private val lastRewardedMs = AtomicLong(0L)
    private val lastRewardedInterstitialMs = AtomicLong(0L)
    private val completedLevelsSinceInterstitial = AtomicInteger(0)

    private val showingFullscreen = AtomicBoolean(false)
    private val gameplayActive = AtomicBoolean(false)
    private val animationRunning = AtomicBoolean(false)
    private val criticalLoadingScreen = AtomicBoolean(true)

    fun updateSettings(newSettings: FrequencySettings) {
        settings = newSettings.copy(
            interstitialLevelInterval = newSettings.interstitialLevelInterval.coerceAtLeast(1),
            interstitialCooldownMs = newSettings.interstitialCooldownMs.coerceAtLeast(30_000L),
            appOpenCooldownMs = newSettings.appOpenCooldownMs.coerceAtLeast(60_000L),
            maxExtraLivesPerAttempt = newSettings.maxExtraLivesPerAttempt.coerceAtLeast(1)
        )
    }

    fun isShowingFullscreenAd(): Boolean = showingFullscreen.get()
    fun isGameplayActive(): Boolean = gameplayActive.get()
    fun isArrowAnimationRunning(): Boolean = animationRunning.get()
    fun isCriticalLoadingScreen(): Boolean = criticalLoadingScreen.get()

    fun setGameplayActive(active: Boolean) {
        gameplayActive.set(active)
    }

    fun setArrowAnimationRunning(running: Boolean) {
        animationRunning.set(running)
    }

    fun setCriticalLoadingScreen(loading: Boolean) {
        criticalLoadingScreen.set(loading)
    }

    fun recordLevelCompleted() {
        completedLevelsSinceInterstitial.incrementAndGet()
    }

    fun tryAcquireFullscreenLock(): Boolean = showingFullscreen.compareAndSet(false, true)

    fun releaseFullscreenLock() {
        showingFullscreen.set(false)
    }

    fun canShowInterstitial(): Boolean {
        if (showingFullscreen.get() || gameplayActive.get() || animationRunning.get() || criticalLoadingScreen.get()) {
            return false
        }
        val cfg = settings
        if (completedLevelsSinceInterstitial.get() < cfg.interstitialLevelInterval) return false

        val now = System.currentTimeMillis()
        val lastInter = lastInterstitialMs.get()
        if (lastInter > 0L && (now - lastInter) < cfg.interstitialCooldownMs) return false

        val lastFull = lastFullscreenAdMs.get()
        if (lastFull > 0L && (now - lastFull) < cfg.minFullscreenGapMs) return false

        val lastRew = maxOf(lastRewardedMs.get(), lastRewardedInterstitialMs.get())
        if (lastRew > 0L && (now - lastRew) < cfg.postRewardedBufferMs) return false

        return true
    }

    fun onInterstitialDismissed() {
        val now = System.currentTimeMillis()
        lastInterstitialMs.set(now)
        lastFullscreenAdMs.set(now)
        completedLevelsSinceInterstitial.set(0)
        showingFullscreen.set(false)
    }

    fun canShowRewarded(): Boolean = !showingFullscreen.get()

    fun onRewardedDismissed(rewardGranted: Boolean) {
        val now = System.currentTimeMillis()
        lastFullscreenAdMs.set(now)
        if (rewardGranted) {
            lastRewardedMs.set(now)
        }
        showingFullscreen.set(false)
    }

    fun canShowRewardedInterstitial(): Boolean {
        if (showingFullscreen.get() || gameplayActive.get() || animationRunning.get() || criticalLoadingScreen.get()) {
            return false
        }
        val now = System.currentTimeMillis()
        val lastRi = lastRewardedInterstitialMs.get()
        if (lastRi > 0L && (now - lastRi) < settings.rewardedInterstitialCooldownMs) {
            return false
        }
        return true
    }

    fun onRewardedInterstitialDismissed(rewardGranted: Boolean) {
        val now = System.currentTimeMillis()
        lastFullscreenAdMs.set(now)
        if (rewardGranted) {
            lastRewardedInterstitialMs.set(now)
        }
        showingFullscreen.set(false)
    }

    fun canShowAppOpen(): Boolean {
        if (showingFullscreen.get() || gameplayActive.get() || animationRunning.get() || criticalLoadingScreen.get()) {
            return false
        }
        val now = System.currentTimeMillis()
        val lastOpen = lastAppOpenMs.get()
        if (lastOpen > 0L && (now - lastOpen) < settings.appOpenCooldownMs) return false

        val lastFull = lastFullscreenAdMs.get()
        if (lastFull > 0L && (now - lastFull) < settings.minFullscreenGapMs) return false

        return true
    }

    fun onAppOpenDismissed() {
        val now = System.currentTimeMillis()
        lastAppOpenMs.set(now)
        lastFullscreenAdMs.set(now)
        showingFullscreen.set(false)
    }
}
