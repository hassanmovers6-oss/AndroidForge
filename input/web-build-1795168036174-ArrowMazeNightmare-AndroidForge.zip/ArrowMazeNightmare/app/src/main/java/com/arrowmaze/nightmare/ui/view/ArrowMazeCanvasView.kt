package com.arrowmaze.nightmare.ui.view

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.arrowmaze.nightmare.engine.ArrowPath
import com.arrowmaze.nightmare.engine.BlockerHit
import com.arrowmaze.nightmare.engine.Direction
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * 60 FPS Android Canvas renderer for dense, irregular multi-segment Arrow Maze puzzles.
 * Draws continuous black rounded arrow paths + sharp arrowheads on a pure white canvas,
 * animates escaping paths slithering smoothly around corners and out of the maze,
 * and supports forgiving nearest-segment touch detection.
 */
class ArrowMazeCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface OnPathTapListener {
        fun onPathTapped(path: ArrowPath)
    }

    private class EscapingPath(
        val path: ArrowPath,
        var travelPx: Float,
        val speedPxPerSec: Float
    )

    var onPathTapListener: OnPathTapListener? = null

    private var rows: Int = 18
    private var cols: Int = 18
    private var activePaths: List<ArrowPath> = emptyList()
    private val escapingPaths = ArrayList<EscapingPath>(12)

    private var hintPath: ArrowPath? = null
    private var blockedPath: ArrowPath? = null
    private var blockerHit: BlockerHit? = null
    private var blockedShakeOffset: Float = 0f
    private var hintPulsePhase: Float = 0f

    private var cellSize: Float = 0f
    private var gridLeft: Float = 0f
    private var gridTop: Float = 0f
    private var lastFrameNanos: Long = 0L
    private var lastTapMs: Long = 0L
    private var isAnimatingFlight = false

    // Pre-allocated Paints (zero allocation in onDraw)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val blackStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val blackHeadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }
    private val escapingStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EC4899")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val escapingHeadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EC4899")
        style = Paint.Style.FILL
    }
    private val blockedStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EF4444")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val blockedHeadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EF4444")
        style = Paint.Style.FILL
    }
    private val blockedRayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EF4444")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(12f, 10f), 0f)
    }
    private val hintStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val hintHeadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        style = Paint.Style.FILL
    }
    private val hintRayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }

    private val reusablePath = Path()
    private val headPath = Path()

    private var shakeAnimator: ValueAnimator? = null
    private var hintAnimator: ValueAnimator? = null

    private val frameRunnable = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = if (lastFrameNanos == 0L) 0.016f else ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            lastFrameNanos = now

            val maxExtent = maxOf(width, height).toFloat() + cellSize * 6f
            val iter = escapingPaths.iterator()
            while (iter.hasNext()) {
                val ep = iter.next()
                ep.travelPx += ep.speedPxPerSec * dt
                val totalPathLen = (ep.path.cells.size - 1) * cellSize
                if (ep.travelPx > totalPathLen + maxExtent) {
                    iter.remove()
                }
            }

            invalidate()
            if (escapingPaths.isNotEmpty()) {
                postOnAnimation(this)
            } else {
                isAnimatingFlight = false
                lastFrameNanos = 0L
            }
        }
    }

    fun setMazeState(rows: Int, cols: Int, paths: List<ArrowPath>, hint: ArrowPath?) {
        this.rows = rows
        this.cols = cols
        this.activePaths = paths
        this.hintPath = hint
        recalculateGeometry()
        if (hint != null) startHintPulse() else stopHintPulse()
        invalidate()
    }

    fun hasActiveAnimations(): Boolean = escapingPaths.isNotEmpty() || blockedPath != null

    fun clearTransientAnimations() {
        escapingPaths.clear()
        blockedPath = null
        blockerHit = null
        blockedShakeOffset = 0f
        isAnimatingFlight = false
        removeCallbacks(frameRunnable)
        invalidate()
    }

    fun launchEscapingPath(path: ArrowPath) {
        if (cellSize <= 0f) recalculateGeometry()
        val speed = maxOf(width, height).toFloat().coerceAtLeast(900f) * 0.55f
        escapingPaths.add(EscapingPath(path, 0f, speed))
        if (!isAnimatingFlight) {
            isAnimatingFlight = true
            lastFrameNanos = System.nanoTime()
            postOnAnimation(frameRunnable)
        }
    }

    fun triggerBlockedFeedback(tapped: ArrowPath, blocker: BlockerHit) {
        blockedPath = tapped
        blockerHit = blocker
        shakeAnimator?.cancel()
        shakeAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                val t = anim.animatedValue as Float
                blockedShakeOffset = sin(t * Math.PI * 4.0).toFloat() * (1f - t) * (cellSize * 0.25f)
                invalidate()
            }
            start()
        }
        postDelayed({
            blockedPath = null
            blockerHit = null
            blockedShakeOffset = 0f
            invalidate()
        }, 360L)
    }

    private fun startHintPulse() {
        if (hintAnimator?.isRunning == true) return
        hintAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 850L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                hintPulsePhase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopHintPulse() {
        hintAnimator?.cancel()
        hintAnimator = null
        hintPulsePhase = 0f
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(frameRunnable)
        shakeAnimator?.cancel()
        hintAnimator?.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recalculateGeometry()
    }

    private fun recalculateGeometry() {
        val availW = (width - paddingLeft - paddingRight).toFloat().coerceAtLeast(1f)
        val availH = (height - paddingTop - paddingBottom).toFloat().coerceAtLeast(1f)
        cellSize = min(availW / cols, availH / rows)
        val gridW = cellSize * cols
        val gridH = cellSize * rows
        gridLeft = paddingLeft + (availW - gridW) / 2f
        gridTop = paddingTop + (availH - gridH) / 2f

        val strokeW = (cellSize * 0.26f).coerceIn(2.2f, 9f)
        blackStrokePaint.strokeWidth = strokeW
        escapingStrokePaint.strokeWidth = strokeW * 1.15f
        blockedStrokePaint.strokeWidth = strokeW * 1.15f
        hintStrokePaint.strokeWidth = strokeW * 1.2f
        blockedRayPaint.strokeWidth = (strokeW * 0.7f).coerceIn(2f, 5f)
        hintRayPaint.strokeWidth = (strokeW * 0.75f).coerceIn(2f, 5f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (cellSize <= 0f) return

        // 1. Draw all active multi-segment black arrow paths (pure white background, zero grid clutter)
        val blk = blockedPath
        val hnt = hintPath

        for (p in activePaths) {
            if (blk != null && p.id == blk.id) continue
            if (hnt != null && p.id == hnt.id) continue
            drawArrowPath(canvas, p, 0f, 0f, blackStrokePaint, blackHeadPaint)
        }

        // 2. Draw blocked collision ray & bumped red path
        val hit = blockerHit
        if (blk != null && hit != null) {
            val head = blk.cells.last()
            val sx = gridLeft + (head.col + 0.5f) * cellSize
            val sy = gridTop + (head.row + 0.5f) * cellSize
            val ex = gridLeft + (hit.col + 0.5f) * cellSize
            val ey = gridTop + (hit.row + 0.5f) * cellSize
            canvas.drawLine(sx, sy, ex, ey, blockedRayPaint)

            val dx = blk.dir.dc * blockedShakeOffset + (if (blk.dir.dc == 0) blockedShakeOffset else 0f)
            val dy = blk.dir.dr * blockedShakeOffset
            drawArrowPath(canvas, blk, dx, dy, blockedStrokePaint, blockedHeadPaint)
        }

        // 3. Draw active Hint path + dashed exit ray
        if (hnt != null) {
            val head = hnt.cells.last()
            val hx = gridLeft + (head.col + 0.5f) * cellSize
            val hy = gridTop + (head.row + 0.5f) * cellSize
            val edgeX = when (hnt.dir) {
                Direction.LEFT -> 0f
                Direction.RIGHT -> width.toFloat()
                else -> hx
            }
            val edgeY = when (hnt.dir) {
                Direction.UP -> 0f
                Direction.DOWN -> height.toFloat()
                else -> hy
            }
            hintRayPaint.alpha = (150 + hintPulsePhase * 105).toInt()
            canvas.drawLine(hx, hy, edgeX, edgeY, hintRayPaint)
            drawArrowPath(canvas, hnt, 0f, 0f, hintStrokePaint, hintHeadPaint)
        }

        // 4. Draw slithering escaping paths at 60 FPS
        for (ep in escapingPaths) {
            drawSlitheringEscape(canvas, ep)
        }
    }

    private fun drawArrowPath(
        canvas: Canvas,
        p: ArrowPath,
        offsetX: Float,
        offsetY: Float,
        strokePaint: Paint,
        headPaint: Paint
    ) {
        if (p.cells.size < 2) return
        reusablePath.reset()
        for (i in p.cells.indices) {
            val c = p.cells[i]
            val x = gridLeft + (c.col + 0.5f) * cellSize + offsetX
            val y = gridTop + (c.row + 0.5f) * cellSize + offsetY
            if (i == 0) reusablePath.moveTo(x, y) else reusablePath.lineTo(x, y)
        }
        canvas.drawPath(reusablePath, strokePaint)

        val head = p.cells.last()
        val hx = gridLeft + (head.col + 0.5f) * cellSize + offsetX
        val hy = gridTop + (head.row + 0.5f) * cellSize + offsetY
        drawArrowhead(canvas, hx, hy, p.dir, headPaint)
    }

    private fun drawSlitheringEscape(canvas: Canvas, ep: EscapingPath) {
        val cells = ep.path.cells
        if (cells.size < 2) return

        val segLen = cellSize
        val totalBodyLen = (cells.size - 1) * segLen
        val startDist = ep.travelPx
        val endDist = startDist + totalBodyLen

        // Sample points from polyline + infinite exit ray
        reusablePath.reset()
        var started = false
        var tipX = 0f
        var tipY = 0f

        fun samplePointAt(dist: Float): Pair<Float, Float> {
            return if (dist <= totalBodyLen) {
                val segIdx = (dist / segLen).toInt().coerceIn(0, cells.size - 2)
                val frac = (dist - segIdx * segLen) / segLen
                val a = cells[segIdx]
                val b = cells[segIdx + 1]
                val ax = gridLeft + (a.col + 0.5f) * cellSize
                val ay = gridTop + (a.row + 0.5f) * cellSize
                val bx = gridLeft + (b.col + 0.5f) * cellSize
                val by = gridTop + (b.row + 0.5f) * cellSize
                Pair(ax + (bx - ax) * frac, ay + (by - ay) * frac)
            } else {
                val extra = dist - totalBodyLen
                val head = cells.last()
                val hx = gridLeft + (head.col + 0.5f) * cellSize
                val hy = gridTop + (head.row + 0.5f) * cellSize
                Pair(hx + ep.path.dir.dc * extra, hy + ep.path.dir.dr * extra)
            }
        }

        val (sx, sy) = samplePointAt(startDist)
        reusablePath.moveTo(sx, sy)
        started = true

        // Include intermediate corner vertices strictly between startDist and endDist
        for (i in 1 until cells.size) {
            val vDist = i * segLen
            if (vDist > startDist && vDist < endDist) {
                val c = cells[i]
                reusablePath.lineTo(
                    gridLeft + (c.col + 0.5f) * cellSize,
                    gridTop + (c.row + 0.5f) * cellSize
                )
            }
        }

        val (ex, ey) = samplePointAt(endDist)
        if (started) {
            reusablePath.lineTo(ex, ey)
        }
        tipX = ex
        tipY = ey

        canvas.drawPath(reusablePath, escapingStrokePaint)
        drawArrowhead(canvas, tipX, tipY, ep.path.dir, escapingHeadPaint)
    }

    private fun drawArrowhead(
        canvas: Canvas,
        hx: Float,
        hy: Float,
        dir: Direction,
        paint: Paint
    ) {
        val tipReach = cellSize * 0.42f
        val baseBack = cellSize * 0.14f
        val halfWing = cellSize * 0.34f

        headPath.reset()
        when (dir) {
            Direction.UP -> {
                headPath.moveTo(hx, hy - tipReach)
                headPath.lineTo(hx - halfWing, hy + baseBack)
                headPath.lineTo(hx + halfWing, hy + baseBack)
            }
            Direction.DOWN -> {
                headPath.moveTo(hx, hy + tipReach)
                headPath.lineTo(hx - halfWing, hy - baseBack)
                headPath.lineTo(hx + halfWing, hy - baseBack)
            }
            Direction.LEFT -> {
                headPath.moveTo(hx - tipReach, hy)
                headPath.lineTo(hx + baseBack, hy - halfWing)
                headPath.lineTo(hx + baseBack, hy + halfWing)
            }
            Direction.RIGHT -> {
                headPath.moveTo(hx + tipReach, hy)
                headPath.lineTo(hx - baseBack, hy - halfWing)
                headPath.lineTo(hx - baseBack, hy + halfWing)
            }
        }
        headPath.close()
        canvas.drawPath(headPath, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_DOWN) return true
        val now = System.currentTimeMillis()
        if (now - lastTapMs < 65L) return true
        lastTapMs = now

        if (cellSize <= 0f) return true

        // Smart nearest-segment touch detection so dense thin paths feel crisp on fingers
        var bestPath: ArrowPath? = null
        var bestDist = cellSize * 0.85f

        for (p in activePaths) {
            for (c in p.cells) {
                val cx = gridLeft + (c.col + 0.5f) * cellSize
                val cy = gridTop + (c.row + 0.5f) * cellSize
                val d = hypot((event.x - cx).toDouble(), (event.y - cy).toDouble()).toFloat()
                if (d < bestDist) {
                    bestDist = d
                    bestPath = p
                }
            }
        }

        if (bestPath != null) {
            onPathTapListener?.onPathTapped(bestPath)
        }
        return true
    }
}
