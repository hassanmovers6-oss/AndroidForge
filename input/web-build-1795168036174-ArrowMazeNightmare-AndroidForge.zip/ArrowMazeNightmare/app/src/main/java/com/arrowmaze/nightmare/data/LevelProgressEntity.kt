package com.arrowmaze.nightmare.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "level_progress")
data class LevelProgressEntity(
    @PrimaryKey val levelNumber: Int,
    val unlocked: Boolean = false,
    val completed: Boolean = false,
    val bestMoves: Int = 0,
    val bestTimeMs: Long = 0L,
    val stars: Int = 0,
    val attempts: Int = 0
)
