package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import com.arrowmaze.nightmare.ui.GameplayActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages Rewarded Interstitial ads for opt-in bonus coins/rewards at level transitions.
 * Strictly requires user confirmation before display, never interrupts active gameplay,
 * enforces frequency caps, and verifies rewards solely inside OnUserEarnedRewardListener.
 */
class RewardedInterstitialAdManager(
    private val app: Application,
    private val frequency: AdFrequencyController,
    private val canServeAds: () -> Boolean
) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var isLoading = false

    private val timeoutRunnable = Runnable {
        if (isLoading) {
            AdConfig.logWarning("RewardedInterstitial", "Load timed out after ${AdConfig.AD_LOAD_TIMEOUT_MS}ms")
            isLoading = false
        }
    }

    fun isReady(): Boolean = rewardedInterstitialAd != null && frequency.canShowRewardedInterstitial()

    fun preload() {
        mainHandler.post {
            if (!canServeAds() || isLoading || rewardedInterstitialAd != null) return@post
            isLoading = true
            mainHandler.removeCallbacks(timeoutRunnable)
            mainHandler.postDelayed(timeoutRunnable, AdConfig.AD_LOAD_TIMEOUT_MS)

            RewardedInterstitialAd.load(
                app,
                AdConfig.rewardedInterstitialAdUnitId,
                AdRequest.Builder().build(),
                object : RewardedInterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedInterstitialAd) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        rewardedInterstitialAd = ad
                        isLoading = false
                        AdConfig.logDebug("RewardedInterstitial", "Loaded and ready")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        rewardedInterstitialAd = null
                        isLoading = false
                        AdConfig.logWarning("RewardedInterstitial", "Failed to load (${error.code}): ${error.message}")
                    }
                }
            )
        }
    }

    fun show(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onClosedWithoutReward: () -> Unit,
        onUnavailable: () -> Unit
    ) {
        if (activity.isFinishing || activity.isDestroyed || activity is GameplayActivity) {
            onUnavailable()
            return
        }

        val ad = rewardedInterstitialAd
        if (ad == null || !frequency.canShowRewardedInterstitial() || !frequency.tryAcquireFullscreenLock()) {
            preload()
            onUnavailable()
            return
        }

        val rewardEarned = AtomicBoolean(false)
        val rewardDispatched = AtomicBoolean(false)

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedInterstitialAd = null
                val granted = rewardEarned.get()
                frequency.onRewardedInterstitialDismissed(granted)
                preload()

                if (granted) {
                    if (rewardDispatched.compareAndSet(false, true)) {
                        onRewardEarned()
                    }
                } else {
                    onClosedWithoutReward()
                }
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                AdConfig.logWarning("RewardedInterstitial", "Show failed (${error.code}): ${error.message}")
                rewardedInterstitialAd = null
                frequency.releaseFullscreenLock()
                preload()
                onUnavailable()
            }
        }

        ad.show(activity) { _ ->
            rewardEarned.set(true)
        }
    }

    fun clear() {
        mainHandler.removeCallbacks(timeoutRunnable)
        rewardedInterstitialAd = null
        isLoading = false
    }
}
