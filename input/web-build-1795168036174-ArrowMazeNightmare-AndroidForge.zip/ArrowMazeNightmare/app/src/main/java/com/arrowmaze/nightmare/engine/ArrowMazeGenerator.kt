package com.arrowmaze.nightmare.engine

import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Generates dense, irregular, interconnected multi-segment Arrow Maze puzzles
 * using Reverse Construction with topological tail-extension invariance.
 */
object ArrowMazeGenerator {

    private class SeededRng(seed: Long) {
        private var state: Long = (seed xor 0x5DEECE66L) and 0xFFFFFFFFL

        fun nextUint(): Long {
            state = (state * 1664525L + 1013904223L) and 0xFFFFFFFFL
            return state
        }

        fun nextInt(bound: Int): Int = (nextUint() % bound.toLong()).toInt()

        fun nextFloat(): Float = nextUint().toFloat() / 4294967296f
    }

    private data class Lobe(val ly: Float, val lx: Float, val ry: Float, val rx: Float)
    private data class Notch(val r0: Int, val r1: Int, val c0: Int, val c1: Int)
    private data class MutableReversePath(val cells: MutableList<CellCoord>, val dir: Direction)

    private fun buildIrregularMask(rows: Int, cols: Int, rng: SeededRng): IntArray {
        val mask = IntArray(rows * cols)
        val cy = (rows - 1) / 2f
        val cx = (cols - 1) / 2f

        val lobes = 3 + rng.nextInt(3)
        val lobeList = ArrayList<Lobe>(lobes)
        for (i in 0 until lobes) {
            lobeList.add(
                Lobe(
                    ly = cy + (rng.nextFloat() - 0.5f) * rows * 0.36f,
                    lx = cx + (rng.nextFloat() - 0.5f) * cols * 0.36f,
                    ry = rows * (0.28f + rng.nextFloat() * 0.16f),
                    rx = cols * (0.28f + rng.nextFloat() * 0.16f)
                )
            )
        }

        val notchCount = 3 + rng.nextInt(3)
        val notches = ArrayList<Notch>(notchCount)
        for (i in 0 until notchCount) {
            val side = rng.nextInt(4)
            val nw = maxOf(2, (cols * (0.16f + rng.nextFloat() * 0.14f)).toInt())
            val nh = maxOf(2, (rows * (0.16f + rng.nextFloat() * 0.14f)).toInt())
            when (side) {
                0 -> {
                    val c0 = rng.nextInt(maxOf(1, cols - nw))
                    notches.add(Notch(0, nh - 1, c0, c0 + nw - 1))
                }
                1 -> {
                    val c0 = rng.nextInt(maxOf(1, cols - nw))
                    notches.add(Notch(rows - nh, rows - 1, c0, c0 + nw - 1))
                }
                2 -> {
                    val r0 = rng.nextInt(maxOf(1, rows - nh))
                    notches.add(Notch(r0, r0 + nh - 1, 0, nw - 1))
                }
                else -> {
                    val r0 = rng.nextInt(maxOf(1, rows - nh))
                    notches.add(Notch(r0, r0 + nh - 1, cols - nw, cols - 1))
                }
            }
        }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                var inside = false
                val dy = (r - cy) / (rows * 0.48f)
                val dx = (c - cx) / (cols * 0.48f)
                if (dx * dx + dy * dy <= 0.92f) inside = true

                if (!inside) {
                    for (l in lobeList) {
                        val ldy = (r - l.ly) / l.ry
                        val ldx = (c - l.lx) / l.rx
                        if (ldx * ldx + ldy * ldy <= 1.0f) {
                            inside = true
                            break
                        }
                    }
                }

                if (inside) {
                    for (n in notches) {
                        if (r in n.r0..n.r1 && c in n.c0..n.c1) {
                            inside = false
                            break
                        }
                    }
                }
                mask[r * cols + c] = if (inside) 1 else 0
            }
        }

        // Keep largest connected component
        val visited = BooleanArray(rows * cols)
        var bestComp = emptyList<Int>()
        val dirs = Direction.entries.toTypedArray()

        for (i in 0 until rows * cols) {
            if (mask[i] == 1 && !visited[i]) {
                val comp = ArrayList<Int>()
                val stack = ArrayList<Int>()
                stack.add(i)
                visited[i] = true
                while (stack.isNotEmpty()) {
                    val curr = stack.removeAt(stack.lastIndex)
                    comp.add(curr)
                    val r = curr / cols
                    val c = curr % cols
                    for (d in dirs) {
                        val nr = r + d.dr
                        val nc = c + d.dc
                        if (nr in 0 until rows && nc in 0 until cols) {
                            val nIdx = nr * cols + nc
                            if (mask[nIdx] == 1 && !visited[nIdx]) {
                                visited[nIdx] = true
                                stack.add(nIdx)
                            }
                        }
                    }
                }
                if (comp.size > bestComp.size) bestComp = comp
            }
        }

        mask.fill(0)
        for (idx in bestComp) mask[idx] = 1
        return mask
    }

    fun generateLevel(levelNumber: Int): ArrowMazeLevel {
        val level = levelNumber.coerceIn(1, DifficultyCategory.TOTAL_LEVELS)
        val category = DifficultyCategory.forLevel(level)
        val span = maxOf(1, category.endLevel - category.startLevel)
        val progress = (level - category.startLevel).toFloat() / span.toFloat()

        val size = category.minSize + ((category.maxSize - category.minSize) * progress).roundToInt()
        val rows = size
        val cols = size
        val totalCells = rows * cols

        val rng = SeededRng(level.toLong() * 2654435761L + 48271L)
        val mask = buildIrregularMask(rows, cols, rng)
        val nightmareMode = level >= 11
        val hardScale = if (nightmareMode) min(1f, (level - 10).toFloat() / 140f) else 0f

        val occupied = BooleanArray(totalCells)
        val blockerPotential = IntArray(totalCells)
        val uncoveredRayMap: Array<ArrayList<Int>> = if (nightmareMode) {
            Array(totalCells) { ArrayList() }
        } else {
            emptyArray()
        }
        val stillUncovered = ArrayList<Boolean>()

        fun markCellOccupied(cellIdx: Int) {
            occupied[cellIdx] = true
            if (nightmareMode) {
                for (pathIdx in uncoveredRayMap[cellIdx]) {
                    stillUncovered[pathIdx] = false
                }
            }
        }

        fun countUncoveredHits(cellIdx: Int): Int {
            if (!nightmareMode) return 0
            var count = 0
            val list = uncoveredRayMap[cellIdx]
            for (i in list.indices) {
                if (stillUncovered[list[i]]) count++
            }
            return count
        }

        val activeMaskCells = ArrayList<Int>(totalCells)
        for (i in 0 until totalCells) {
            if (mask[i] == 1) activeMaskCells.add(i)
        }

        val reversePaths = ArrayList<MutableReversePath>()
        val dirs = Direction.entries.toTypedArray()
        var guard = 0
        val maxPathsGuard = if (nightmareMode) 420 else 220

        while (guard < maxPathsGuard) {
            val candidates = ArrayList<Int>(activeMaskCells.size)
            for (idx in activeMaskCells) {
                if (!occupied[idx]) candidates.add(idx)
            }
            if (candidates.size < 2) break

            val sampleCount = min(candidates.size, if (nightmareMode) 180 else 44)
            var bestScore = -1e9f
            var bestHeadIdx = -1
            var bestNeckIdx = -1
            var bestDir = Direction.UP

            for (s in 0 until sampleCount) {
                val rp = s + rng.nextInt(candidates.size - s)
                val tmp = candidates[s]
                candidates[s] = candidates[rp]
                candidates[rp] = tmp

                val hIdx = candidates[s]
                val hr = hIdx / cols
                val hc = hIdx % cols

                val dStart = rng.nextInt(4)
                for (dOff in 0 until 4) {
                    val dMeta = dirs[(dStart + dOff) % 4]
                    val nr = hr - dMeta.dr
                    val nc = hc - dMeta.dc
                    if (nr !in 0 until rows || nc !in 0 until cols) continue
                    val nIdx = nr * cols + nc
                    if (mask[nIdx] == 0 || occupied[nIdx]) continue

                    var rr = hr + dMeta.dr
                    var rc = hc + dMeta.dc
                    var blocked = false
                    var rayLen = 0
                    while (rr in 0 until rows && rc in 0 until cols) {
                        if (occupied[rr * cols + rc]) {
                            blocked = true
                            break
                        }
                        if (mask[rr * cols + rc] == 1) rayLen++
                        rr += dMeta.dr
                        rc += dMeta.dc
                    }
                    if (blocked) continue

                    val centerDist = abs(hr - (rows - 1) / 2f) / rows + abs(hc - (cols - 1) / 2f) / cols
                    val score: Float
                    if (!nightmareMode) {
                        val blockScore = (blockerPotential[hIdx] + blockerPotential[nIdx]) * 2.4f
                        val inwardScore = min(rayLen, 6) * 0.45f
                        score = blockScore + inwardScore - centerDist * 1.1f + rng.nextFloat() * 0.8f
                    } else {
                        val denom = maxOf(18, activeMaskCells.size / category.minPathLen).toFloat()
                        val progressRatio = reversePaths.size.toFloat() / denom
                        if (progressRatio < 0.35f) {
                            score = centerDist * 8.5f + min(rayLen, 14) * 0.75f + rng.nextFloat() * 0.6f
                        } else {
                            if (rayLen <= (if (hardScale > 0.35f) 3 else 2)) continue
                            val uncoveredHits = countUncoveredHits(hIdx) + countUncoveredHits(nIdx)
                            val totalPot = blockerPotential[hIdx] + blockerPotential[nIdx]
                            score = uncoveredHits * 14.0f +
                                totalPot * 2.0f +
                                min(rayLen, 24) * (0.9f + hardScale * 0.45f) -
                                centerDist * 2.6f +
                                rng.nextFloat() * 0.45f
                        }
                    }

                    if (score > bestScore) {
                        bestScore = score
                        bestHeadIdx = hIdx
                        bestNeckIdx = nIdx
                        bestDir = dMeta
                    }
                }
            }

            if (bestHeadIdx == -1) {
                if (nightmareMode && reversePaths.size >= 16) {
                    break
                }
                var found = false
                for (hIdx in candidates) {
                    val hr = hIdx / cols
                    val hc = hIdx % cols
                    for (dMeta in dirs) {
                        val nr = hr - dMeta.dr
                        val nc = hc - dMeta.dc
                        if (nr !in 0 until rows || nc !in 0 until cols) continue
                        val nIdx = nr * cols + nc
                        if (mask[nIdx] == 0 || occupied[nIdx]) continue

                        var rr = hr + dMeta.dr
                        var rc = hc + dMeta.dc
                        var blocked = false
                        while (rr in 0 until rows && rc in 0 until cols) {
                            if (occupied[rr * cols + rc]) {
                                blocked = true
                                break
                            }
                            rr += dMeta.dr
                            rc += dMeta.dc
                        }
                        if (!blocked) {
                            bestHeadIdx = hIdx
                            bestNeckIdx = nIdx
                            bestDir = dMeta
                            found = true
                            break
                        }
                    }
                    if (found) break
                }
                if (!found) break
            }

            val hr = bestHeadIdx / cols
            val hc = bestHeadIdx % cols
            val raySet = HashSet<Int>()
            run {
                var rr = hr + bestDir.dr
                var rc = hc + bestDir.dc
                while (rr in 0 until rows && rc in 0 until cols) {
                    raySet.add(rr * cols + rc)
                    rr += bestDir.dr
                    rc += bestDir.dc
                }
            }

            val targetLen = category.minPathLen + rng.nextInt(category.maxPathLen - category.minPathLen + 1)
            val bodyRev = ArrayList<CellCoord>(targetLen)
            bodyRev.add(CellCoord(hr, hc))
            bodyRev.add(CellCoord(bestNeckIdx / cols, bestNeckIdx % cols))
            markCellOccupied(bestHeadIdx)
            markCellOccupied(bestNeckIdx)

            var prevStepDir = when (bestDir) {
                Direction.UP -> Direction.DOWN
                Direction.DOWN -> Direction.UP
                Direction.LEFT -> Direction.RIGHT
                Direction.RIGHT -> Direction.LEFT
            }

            while (bodyRev.size < targetLen) {
                val tip = bodyRev.last()
                var bestNextRow = -1
                var bestNextCol = -1
                var bestNextDir = Direction.UP
                var bestWeight = -1f
                var secondRow = -1
                var secondCol = -1
                var secondDir = Direction.UP
                var secondWeight = -1f

                for (optDir in dirs) {
                    val nr = tip.row + optDir.dr
                    val nc = tip.col + optDir.dc
                    if (nr !in 0 until rows || nc !in 0 until cols) continue
                    val nIdx = nr * cols + nc
                    if (mask[nIdx] == 0 || occupied[nIdx] || nIdx in raySet) continue

                    val w: Float
                    if (!nightmareMode) {
                        val isTurn = if (optDir != prevStepDir) 1.8f else 0.7f
                        val blocksExisting = 1.0f + blockerPotential[nIdx] * 1.6f
                        w = isTurn * blocksExisting + rng.nextFloat() * 0.6f
                    } else {
                        val isTurn = if (optDir != prevStepDir) 2.8f else 0.55f
                        val uncoveredHit = countUncoveredHits(nIdx)
                        val blocksExisting = 1.0f + blockerPotential[nIdx] * 1.9f + uncoveredHit * 8.5f
                        w = isTurn * blocksExisting + rng.nextFloat() * 0.45f
                    }
                    if (w > bestWeight) {
                        secondWeight = bestWeight
                        secondRow = bestNextRow
                        secondCol = bestNextCol
                        secondDir = bestNextDir
                        bestWeight = w
                        bestNextRow = nr
                        bestNextCol = nc
                        bestNextDir = optDir
                    } else if (w > secondWeight) {
                        secondWeight = w
                        secondRow = nr
                        secondCol = nc
                        secondDir = optDir
                    }
                }

                if (bestNextRow == -1) break
                val secondChance = if (nightmareMode) 0.14f else 0.28f
                val useSecond = secondRow != -1 && rng.nextFloat() < secondChance
                val chosenR = if (useSecond) secondRow else bestNextRow
                val chosenC = if (useSecond) secondCol else bestNextCol
                val chosenD = if (useSecond) secondDir else bestNextDir

                bodyRev.add(CellCoord(chosenR, chosenC))
                markCellOccupied(chosenR * cols + chosenC)
                prevStepDir = chosenD
            }

            val thisPathIdx = reversePaths.size
            if (nightmareMode) {
                stillUncovered.add(true)
            }
            for (rIdx in raySet) {
                blockerPotential[rIdx] += 1
                if (nightmareMode) {
                    uncoveredRayMap[rIdx].add(thisPathIdx)
                }
            }

            bodyRev.reverse()
            reversePaths.add(MutableReversePath(bodyRev, bestDir))
            guard++
        }

        // Topological tail-extension pass
        val pathForwardRays = reversePaths.map { p ->
            val set = HashSet<Int>()
            val h = p.cells.last()
            var rr = h.row + p.dir.dr
            var rc = h.col + p.dir.dc
            while (rr in 0 until rows && rc in 0 until cols) {
                set.add(rr * cols + rc)
                rr += p.dir.dr
                rc += p.dir.dc
            }
            set
        }

        var extended = true
        var extPasses = 0
        val maxExtPasses = if (nightmareMode) 10 else 4
        val maxExtLen = category.maxPathLen + if (nightmareMode) 10 else 3
        while (extended && extPasses < maxExtPasses) {
            extended = false
            extPasses++
            for (pIdx in reversePaths.indices) {
                val p = reversePaths[pIdx]
                if (p.cells.size >= maxExtLen) continue
                val tail = p.cells[0]

                var bestNr = -1
                var bestNc = -1
                var bestTailScore = -1e9f

                for (d in dirs) {
                    val nr = tail.row + d.dr
                    val nc = tail.col + d.dc
                    if (nr !in 0 until rows || nc !in 0 until cols) continue
                    val nIdx = nr * cols + nc
                    if (mask[nIdx] == 0 || occupied[nIdx]) continue

                    var conflicts = nIdx in pathForwardRays[pIdx]
                    if (!conflicts) {
                        for (q in pIdx + 1 until reversePaths.size) {
                            if (nIdx in pathForwardRays[q]) {
                                conflicts = true
                                break
                            }
                        }
                    }
                    if (conflicts) continue

                    if (!nightmareMode) {
                        bestNr = nr
                        bestNc = nc
                        break
                    } else {
                        val score = (countUncoveredHits(nIdx) * 10 + blockerPotential[nIdx]).toFloat()
                        if (score > bestTailScore) {
                            bestTailScore = score
                            bestNr = nr
                            bestNc = nc
                        }
                    }
                }

                if (bestNr != -1) {
                    p.cells.add(0, CellCoord(bestNr, bestNc))
                    markCellOccupied(bestNr * cols + bestNc)
                    extended = true
                }
            }
        }

        reversePaths.reverse()
        val paths = reversePaths.mapIndexed { idx, p ->
            ArrowPath(id = idx, cells = p.cells.toList(), dir = p.dir)
        }

        return ArrowMazeLevel(
            levelNumber = level,
            category = category,
            rows = rows,
            cols = cols,
            mask = mask,
            paths = paths,
            solutionOrder = paths.map { it.id }
        )
    }

    fun verifySolvable(level: ArrowMazeLevel): Boolean {
        val grid = IntArray(level.rows * level.cols) { -1 }
        for (p in level.paths) {
            for (c in p.cells) {
                grid[c.row * level.cols + c.col] = p.id
            }
        }

        var remaining = level.paths.size
        val active = BooleanArray(level.paths.size) { true }

        while (remaining > 0) {
            var removedAny = false
            for (i in level.paths.indices) {
                if (!active[i]) continue
                val p = level.paths[i]
                if (ArrowMazeCollision.isPathClear(grid, level.rows, level.cols, p)) {
                    for (c in p.cells) {
                        grid[c.row * level.cols + c.col] = -1
                    }
                    active[i] = false
                    remaining--
                    removedAny = true
                }
            }
            if (!removedAny) return false
        }
        return true
    }
}
