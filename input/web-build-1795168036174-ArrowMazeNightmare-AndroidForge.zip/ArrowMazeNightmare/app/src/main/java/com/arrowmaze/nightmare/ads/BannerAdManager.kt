package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

/**
 * Manages Adaptive Anchored Banner ads on non-gameplay screens.
 * Reuses an already-attached AdView to avoid redundant requests across orientation/rebuilds,
 * respects safe boundaries, and handles offline/load errors silently.
 */
class BannerAdManager(
    private val canServeAds: () -> Boolean
) {

    fun attachAdaptiveBanner(activity: Activity, container: ViewGroup): AdView? {
        if (activity.isFinishing || activity.isDestroyed) return null
        if (!canServeAds()) {
            container.visibility = View.GONE
            return null
        }

        // Reuse existing AdView if already present in this container
        if (container.childCount == 1 && container.getChildAt(0) is AdView) {
            return container.getChildAt(0) as AdView
        }

        return try {
            container.removeAllViews()
            val adView = AdView(activity).apply {
                adUnitId = AdConfig.bannerAdUnitId
                setAdSize(computeAdaptiveSize(activity, container))
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        if (!activity.isFinishing && !activity.isDestroyed) {
                            container.visibility = View.VISIBLE
                        }
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        AdConfig.logWarning("Banner", "Failed to load (${error.code}): ${error.message}")
                        container.visibility = View.GONE
                    }
                }
            }
            container.addView(adView)
            adView.loadAd(AdRequest.Builder().build())
            adView
        } catch (t: Throwable) {
            AdConfig.logWarning("Banner", "Attach error: ${t.message}")
            container.visibility = View.GONE
            null
        }
    }

    private fun computeAdaptiveSize(activity: Activity, container: ViewGroup): AdSize {
        val metrics = activity.resources.displayMetrics
        val density = metrics.density.coerceAtLeast(1f)
        val widthPx = if (container.width > 0) container.width else metrics.widthPixels
        val adWidthDp = (widthPx / density).toInt().coerceAtLeast(320)
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidthDp)
    }

    fun resume(adView: AdView?) {
        try {
            adView?.resume()
        } catch (_: Throwable) {}
    }

    fun pause(adView: AdView?) {
        try {
            adView?.pause()
        } catch (_: Throwable) {}
    }

    fun destroy(adView: AdView?) {
        try {
            adView?.adListener = object : AdListener() {}
            (adView?.parent as? ViewGroup)?.removeView(adView)
            adView?.destroy()
        } catch (_: Throwable) {}
    }
}
