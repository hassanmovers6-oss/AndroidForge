package com.arrowmaze.nightmare.ads

import android.util.Log
import com.arrowmaze.nightmare.BuildConfig

/**
 * Centralized Google AdMob configuration separating Development (Test IDs)
 * and Production (exact verified AdMob Console IDs).
 *
 * `BuildConfig.USE_PRODUCTION_ADS` is automatically `true` in `release` builds
 * and `false` in `debug` builds (configured in `app/build.gradle.kts`).
 */
object AdConfig {

    val useProductionIds: Boolean
        get() = BuildConfig.USE_PRODUCTION_ADS

    val debugLoggingEnabled: Boolean
        get() = BuildConfig.AD_DEBUG_LOGGING

    // App IDs (injected into AndroidManifest.xml via manifestPlaceholders)
    const val PROD_APP_ID = "ca-app-pub-3133971041724338~2576474017"
    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"

    // 1. Adaptive Banner Ad Unit IDs
    private const val PROD_BANNER_ID = "ca-app-pub-3133971041724338/6675501123"
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741"

    // 2. Interstitial Ad Unit IDs
    private const val PROD_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/5362419458"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"

    // 3. Native Advanced Ad Unit IDs
    private const val PROD_NATIVE_ID = "ca-app-pub-3133971041724338/2736256113"
    private const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"

    // 4. Rewarded Ad Unit IDs
    private const val PROD_REWARDED_ID = "ca-app-pub-3133971041724338/6020895009"
    private const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // 5. Rewarded Interstitial Ad Unit IDs
    private const val PROD_REWARDED_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/5052474440"
    private const val TEST_REWARDED_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/5354046379"

    // 6. App Open Ad Unit IDs
    private const val PROD_APP_OPEN_ID = "ca-app-pub-3133971041724338/3930964467"
    private const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"

    val bannerAdUnitId: String
        get() = if (useProductionIds) PROD_BANNER_ID else TEST_BANNER_ID

    val interstitialAdUnitId: String
        get() = if (useProductionIds) PROD_INTERSTITIAL_ID else TEST_INTERSTITIAL_ID

    val nativeAdUnitId: String
        get() = if (useProductionIds) PROD_NATIVE_ID else TEST_NATIVE_ID

    val rewardedAdUnitId: String
        get() = if (useProductionIds) PROD_REWARDED_ID else TEST_REWARDED_ID

    val rewardedInterstitialAdUnitId: String
        get() = if (useProductionIds) PROD_REWARDED_INTERSTITIAL_ID else TEST_REWARDED_INTERSTITIAL_ID

    val appOpenAdUnitId: String
        get() = if (useProductionIds) PROD_APP_OPEN_ID else TEST_APP_OPEN_ID

    // Default Configurable Policy & Frequency Constants
    const val DEFAULT_INTERSTITIAL_LEVEL_INTERVAL = 3
    const val DEFAULT_INTERSTITIAL_COOLDOWN_MS = 120_000L // 120 seconds minimum between interstitials
    const val DEFAULT_POST_REWARDED_BUFFER_MS = 45_000L // Never stack interstitial right after rewarded ad
    const val DEFAULT_MIN_FULLSCREEN_GAP_MS = 30_000L // Prevent back-to-back full-screen ads
    const val DEFAULT_REWARDED_INTERSTITIAL_COOLDOWN_MS = 60_000L
    const val DEFAULT_APP_OPEN_COOLDOWN_MS = 4L * 3_600_000L // 4 hours cooldown between App Open displays
    const val APP_OPEN_EXPIRY_MS = 4L * 3_600_000L // Google Mobile Ads App Open cache limit: 4 hours
    const val AD_LOAD_TIMEOUT_MS = 15_000L
    const val MAX_EXTRA_LIVES_PER_ATTEMPT = 2

    fun logDebug(tag: String, message: String) {
        if (debugLoggingEnabled) {
            Log.d("AdMob/$tag", message)
        }
    }

    fun logWarning(tag: String, message: String) {
        if (debugLoggingEnabled) {
            Log.w("AdMob/$tag", message)
        }
    }
}
