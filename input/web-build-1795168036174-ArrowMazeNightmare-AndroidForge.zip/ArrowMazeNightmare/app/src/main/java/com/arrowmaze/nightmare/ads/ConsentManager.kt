package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.content.Context
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Google User Messaging Platform (UMP) Consent Manager.
 * Requests consent info at startup, shows consent forms only when required,
 * exposes privacy options for EU/EEA/UK settings, and handles errors safely.
 */
class ConsentManager(context: Context) {

    private val consentInformation: ConsentInformation =
        UserMessagingPlatform.getConsentInformation(context.applicationContext)

    private val isGathering = AtomicBoolean(false)

    val canRequestAds: Boolean
        get() = consentInformation.canRequestAds()

    val isPrivacyOptionsRequired: Boolean
        get() = consentInformation.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun gatherConsent(activity: Activity, onComplete: (canRequestAds: Boolean) -> Unit) {
        if (!isGathering.compareAndSet(false, true)) {
            onComplete(consentInformation.canRequestAds())
            return
        }

        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                if (activity.isFinishing || activity.isDestroyed) {
                    isGathering.set(false)
                    onComplete(consentInformation.canRequestAds())
                    return@requestConsentInfoUpdate
                }
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        AdConfig.logWarning("UMP", "Consent form error (${formError.errorCode}): ${formError.message}")
                    }
                    isGathering.set(false)
                    onComplete(consentInformation.canRequestAds())
                }
            },
            { requestError ->
                AdConfig.logWarning("UMP", "Consent update error (${requestError.errorCode}): ${requestError.message}")
                isGathering.set(false)
                // Fall back safely to cached consent state (never crash or block offline play)
                onComplete(consentInformation.canRequestAds())
            }
        )
    }

    fun showPrivacyOptionsForm(activity: Activity, onDismissed: () -> Unit) {
        if (activity.isFinishing || activity.isDestroyed) {
            onDismissed()
            return
        }
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
            if (formError != null) {
                AdConfig.logWarning("UMP", "Privacy options error (${formError.errorCode}): ${formError.message}")
            }
            onDismissed()
        }
    }
}
