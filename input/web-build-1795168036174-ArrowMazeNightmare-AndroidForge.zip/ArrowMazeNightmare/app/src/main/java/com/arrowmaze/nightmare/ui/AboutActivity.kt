package com.arrowmaze.nightmare.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.BuildConfig
import com.arrowmaze.nightmare.databinding.ActivityAboutBinding
import com.google.android.gms.ads.AdView

class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding
    private var bannerAdView: AdView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        binding.btnBack.setOnClickListener { finish() }
        binding.tvVersionInfo.text = "Version ${BuildConfig.VERSION_NAME} · 600 Verified Levels"

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        super.onDestroy()
    }
}
