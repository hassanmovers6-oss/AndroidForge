package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import com.arrowmaze.nightmare.ui.GameplayActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Manages Interstitial ads at natural transitions (e.g., level completions or menu returns).
 * Enforces AdFrequencyController intervals, cooldowns, active gameplay/animation protection,
 * timeout recovery, and automatic preloading.
 */
class InterstitialAdManager(
    private val app: Application,
    private val frequency: AdFrequencyController,
    private val canServeAds: () -> Boolean
) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false

    private val timeoutRunnable = Runnable {
        if (isLoading) {
            AdConfig.logWarning("Interstitial", "Load timed out after ${AdConfig.AD_LOAD_TIMEOUT_MS}ms")
            isLoading = false
        }
    }

    fun isReady(): Boolean = interstitialAd != null

    fun preload() {
        mainHandler.post {
            if (!canServeAds() || isLoading || interstitialAd != null) return@post
            isLoading = true
            mainHandler.removeCallbacks(timeoutRunnable)
            mainHandler.postDelayed(timeoutRunnable, AdConfig.AD_LOAD_TIMEOUT_MS)

            InterstitialAd.load(
                app,
                AdConfig.interstitialAdUnitId,
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        interstitialAd = ad
                        isLoading = false
                        AdConfig.logDebug("Interstitial", "Loaded and ready")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        interstitialAd = null
                        isLoading = false
                        AdConfig.logWarning("Interstitial", "Failed to load (${error.code}): ${error.message}")
                    }
                }
            )
        }
    }

    fun showIfEligible(activity: Activity, onFinished: () -> Unit) {
        if (activity.isFinishing || activity.isDestroyed || activity is GameplayActivity) {
            onFinished()
            return
        }

        val ad = interstitialAd
        if (ad == null || !frequency.canShowInterstitial()) {
            preload()
            onFinished()
            return
        }

        if (!frequency.tryAcquireFullscreenLock()) {
            onFinished()
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                frequency.onInterstitialDismissed()
                preload()
                onFinished()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                AdConfig.logWarning("Interstitial", "Show failed (${adError.code}): ${adError.message}")
                interstitialAd = null
                frequency.releaseFullscreenLock()
                preload()
                onFinished()
            }
        }
        ad.show(activity)
    }

    fun clear() {
        mainHandler.removeCallbacks(timeoutRunnable)
        interstitialAd = null
        isLoading = false
    }
}
