package com.arrowmaze.nightmare.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ActivityDailyRewardsBinding
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DailyRewardsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDailyRewardsBinding
    private val adapter = DailyRewardAdapter()
    private var bannerAdView: AdView? = null
    private var loadedNativeAd: NativeAd? = null

    private val rewardSchedule = listOf(
        DailyRewardTier(1, 25, 0),
        DailyRewardTier(2, 35, 1),
        DailyRewardTier(3, 50, 0),
        DailyRewardTier(4, 65, 1),
        DailyRewardTier(5, 80, 1),
        DailyRewardTier(6, 100, 1),
        DailyRewardTier(7, 150, 3)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDailyRewardsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        binding.btnBack.setOnClickListener { finish() }

        binding.rvDailyRewards.layoutManager = LinearLayoutManager(this)
        binding.rvDailyRewards.adapter = adapter

        binding.btnClaimDaily.setOnClickListener { claimTodayReward() }

        binding.btnDoubleRewardAd.setOnClickListener {
            if (!app.adManager.isRewardedAdReady()) {
                Toast.makeText(this, "Rewarded ad not ready right now.", Toast.LENGTH_SHORT).show()
                app.adManager.loadRewardedAd()
                return@setOnClickListener
            }

            app.adManager.showRewardedAd(
                activity = this,
                onRewardEarned = {
                    lifecycleScope.launch(Dispatchers.IO) {
                        app.repository.prefs.addHints(1)
                        app.repository.prefs.addCoins(25)
                    }
                    Toast.makeText(this, "Earned +1 Hint & +25 Coins!", Toast.LENGTH_SHORT).show()
                },
                onAdClosedWithoutReward = {
                    Toast.makeText(this, getString(R.string.ad_failed_no_reward), Toast.LENGTH_SHORT).show()
                },
                onAdUnavailable = {
                    Toast.makeText(this, "Ad unavailable right now.", Toast.LENGTH_SHORT).show()
                }
            )
        }

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
        app.adManager.loadNativeAd(this, binding.nativeAdContainer) { nativeAd ->
            loadedNativeAd?.destroy()
            loadedNativeAd = nativeAd
        }
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
        refreshUi()
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        loadedNativeAd?.destroy()
        loadedNativeAd = null
        super.onDestroy()
    }

    private fun currentEpochDay(): Long = System.currentTimeMillis() / 86_400_000L

    private fun refreshUi() {
        val app = application as ArrowMazeApplication
        lifecycleScope.launch {
            val profile = withContext(Dispatchers.IO) { app.repository.prefs.getProfile() }
            val today = currentEpochDay()
            val canClaim = profile.lastDailyClaimEpochDay < today
            val streak = if (profile.lastDailyClaimEpochDay == today || profile.lastDailyClaimEpochDay == today - 1L) {
                profile.dailyStreak % 7
            } else {
                0
            }
            val displayStreak = if (profile.lastDailyClaimEpochDay == today) profile.dailyStreak else streak

            binding.tvStreakSummary.text = "Current Login Streak: Day $displayStreak / 7"
            binding.btnClaimDaily.isEnabled = canClaim
            binding.btnClaimDaily.alpha = if (canClaim) 1f else 0.5f
            binding.btnClaimDaily.text = if (canClaim) "Claim Day ${displayStreak + 1} Reward" else "Claimed Today"
            adapter.update(rewardSchedule, displayStreak, canClaim)
        }
    }

    private fun claimTodayReward() {
        val app = application as ArrowMazeApplication
        lifecycleScope.launch {
            val profile = withContext(Dispatchers.IO) { app.repository.prefs.getProfile() }
            val today = currentEpochDay()
            if (profile.lastDailyClaimEpochDay >= today) return@launch

            val nextStreak = if (profile.lastDailyClaimEpochDay == today - 1L) {
                (profile.dailyStreak % 7) + 1
            } else {
                1
            }
            val tier = rewardSchedule[nextStreak - 1]
            withContext(Dispatchers.IO) {
                app.repository.prefs.claimDailyReward(today, nextStreak, tier.coins, tier.hints)
            }
            app.feedbackManager.playWin()
            Toast.makeText(
                this@DailyRewardsActivity,
                "Claimed +${tier.coins} Coins${if (tier.hints > 0) " & +${tier.hints} Hint(s)" else ""}!",
                Toast.LENGTH_SHORT
            ).show()
            refreshUi()
        }
    }
}
