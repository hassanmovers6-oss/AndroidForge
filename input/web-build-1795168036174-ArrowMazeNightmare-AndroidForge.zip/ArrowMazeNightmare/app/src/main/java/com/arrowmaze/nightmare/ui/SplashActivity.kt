package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.databinding.ActivitySplashBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private var navigated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        app.adManager.frequencyController.setCriticalLoadingScreen(true)

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                app.repository.ensureInitialized()
            }

            // Gather Google UMP Consent before initializing Mobile Ads SDK
            app.adManager.consentManager.gatherConsent(this@SplashActivity) { canRequestAds ->
                if (canRequestAds) {
                    app.adManager.initializeMobileAdsIfConsented()
                }
                proceedToHome()
            }

            // Safety timeout so offline players never wait on splash
            delay(2500L)
            proceedToHome()
        }
    }

    private fun proceedToHome() {
        if (navigated || isFinishing || isDestroyed) return
        navigated = true
        (application as ArrowMazeApplication).adManager.frequencyController.setCriticalLoadingScreen(false)
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
