package com.arrowmaze.nightmare.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LevelProgressDao {

    @Query("SELECT * FROM level_progress ORDER BY levelNumber ASC")
    fun observeAllProgress(): Flow<List<LevelProgressEntity>>

    @Query("SELECT * FROM level_progress WHERE levelNumber = :levelNumber LIMIT 1")
    suspend fun getLevel(levelNumber: Int): LevelProgressEntity?

    @Query("SELECT * FROM level_progress WHERE levelNumber BETWEEN :start AND :end ORDER BY levelNumber ASC")
    suspend fun getLevelsInRange(start: Int, end: Int): List<LevelProgressEntity>

    @Query("SELECT COUNT(*) FROM level_progress WHERE completed = 1")
    suspend fun getCompletedCount(): Int

    @Query("SELECT MAX(levelNumber) FROM level_progress WHERE unlocked = 1")
    suspend fun getHighestUnlockedLevel(): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: LevelProgressEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(entities: List<LevelProgressEntity>)
}
