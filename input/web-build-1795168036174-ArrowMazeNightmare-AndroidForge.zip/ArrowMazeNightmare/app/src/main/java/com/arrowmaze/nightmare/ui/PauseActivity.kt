package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.arrowmaze.nightmare.databinding.ActivityPauseBinding
import com.arrowmaze.nightmare.engine.DifficultyCategory

class PauseActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LEVEL_NUMBER = "extra_level_number"
        const val RESULT_RESTART = 101
        const val RESULT_QUIT_HOME = 102
    }

    private lateinit var binding: ActivityPauseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPauseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val level = intent.getIntExtra(EXTRA_LEVEL_NUMBER, 1)
        val cat = DifficultyCategory.forLevel(level)
        binding.tvPauseLevelInfo.text = "Level $level · ${cat.title}"

        binding.btnResume.setOnClickListener {
            setResult(RESULT_OK)
            finish()
        }

        binding.btnRestart.setOnClickListener {
            setResult(RESULT_RESTART)
            finish()
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnQuitHome.setOnClickListener {
            setResult(RESULT_QUIT_HOME)
            finish()
        }
    }
}
