package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages Rewarded Ads for optional Hints, Extra Lives, and Bonus Rewards.
 * Strictly verifies reward completion via OnUserEarnedRewardListener with a single-grant guard,
 * never granting rewards on dismissal alone.
 */
class RewardedAdManager(
    private val app: Application,
    private val frequency: AdFrequencyController,
    private val canServeAds: () -> Boolean
) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false

    private val timeoutRunnable = Runnable {
        if (isLoading) {
            AdConfig.logWarning("Rewarded", "Load timed out after ${AdConfig.AD_LOAD_TIMEOUT_MS}ms")
            isLoading = false
        }
    }

    fun isReady(): Boolean = rewardedAd != null

    fun preload(onResult: ((Boolean) -> Unit)? = null) {
        mainHandler.post {
            if (!canServeAds()) {
                onResult?.invoke(false)
                return@post
            }
            if (rewardedAd != null) {
                onResult?.invoke(true)
                return@post
            }
            if (isLoading) return@post

            isLoading = true
            mainHandler.removeCallbacks(timeoutRunnable)
            mainHandler.postDelayed(timeoutRunnable, AdConfig.AD_LOAD_TIMEOUT_MS)

            RewardedAd.load(
                app,
                AdConfig.rewardedAdUnitId,
                AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        rewardedAd = ad
                        isLoading = false
                        AdConfig.logDebug("Rewarded", "Loaded and ready")
                        onResult?.invoke(true)
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        rewardedAd = null
                        isLoading = false
                        AdConfig.logWarning("Rewarded", "Failed to load (${error.code}): ${error.message}")
                        onResult?.invoke(false)
                    }
                }
            )
        }
    }

    fun show(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdClosedWithoutReward: () -> Unit,
        onAdUnavailable: () -> Unit
    ) {
        if (activity.isFinishing || activity.isDestroyed) {
            onAdUnavailable()
            return
        }

        val ad = rewardedAd
        if (ad == null || !frequency.canShowRewarded() || !frequency.tryAcquireFullscreenLock()) {
            preload()
            onAdUnavailable()
            return
        }

        val rewardEarned = AtomicBoolean(false)
        val rewardDispatched = AtomicBoolean(false)

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                val granted = rewardEarned.get()
                frequency.onRewardedDismissed(granted)
                preload()

                if (granted) {
                    if (rewardDispatched.compareAndSet(false, true)) {
                        onRewardEarned()
                    }
                } else {
                    onAdClosedWithoutReward()
                }
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                AdConfig.logWarning("Rewarded", "Show failed (${error.code}): ${error.message}")
                rewardedAd = null
                frequency.releaseFullscreenLock()
                preload()
                onAdUnavailable()
            }
        }

        ad.show(activity) { _ ->
            // Verified solely through official OnUserEarnedRewardListener callback
            rewardEarned.set(true)
        }
    }

    fun clear() {
        mainHandler.removeCallbacks(timeoutRunnable)
        rewardedAd = null
        isLoading = false
    }
}
