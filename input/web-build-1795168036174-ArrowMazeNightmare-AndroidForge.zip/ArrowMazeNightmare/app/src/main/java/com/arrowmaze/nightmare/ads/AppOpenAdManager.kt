package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.arrowmaze.nightmare.ui.GameplayActivity
import com.arrowmaze.nightmare.ui.HomeActivity
import com.arrowmaze.nightmare.ui.PauseActivity
import com.arrowmaze.nightmare.ui.SplashActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages App Open ads across ProcessLifecycleOwner foreground returns and eligible cold launches.
 * Enforces 4-hour cooldown, 4-hour expiration checks, and strictly suppresses display during
 * Splash/loading screens, active gameplay, or while another full-screen ad is active.
 */
class AppOpenAdManager(
    private val app: Application,
    private val frequency: AdFrequencyController,
    private val canServeAds: () -> Boolean
) : Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var appOpenAd: AppOpenAd? = null
    private var isLoading = false
    private var loadTimeMs = 0L
    private var currentActivity: Activity? = null

    private val coldLaunchWindowStartMs = System.currentTimeMillis()
    private val coldLaunchHandled = AtomicBoolean(false)

    private val timeoutRunnable = Runnable {
        if (isLoading) {
            AdConfig.logWarning("AppOpen", "Load timed out after ${AdConfig.AD_LOAD_TIMEOUT_MS}ms")
            isLoading = false
        }
    }

    init {
        app.registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    fun preload() {
        mainHandler.post {
            if (!canServeAds() || isLoading || isAdValid()) return@post
            isLoading = true
            mainHandler.removeCallbacks(timeoutRunnable)
            mainHandler.postDelayed(timeoutRunnable, AdConfig.AD_LOAD_TIMEOUT_MS)

            AppOpenAd.load(
                app,
                AdConfig.appOpenAdUnitId,
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        appOpenAd = ad
                        loadTimeMs = System.currentTimeMillis()
                        isLoading = false
                        AdConfig.logDebug("AppOpen", "Loaded and ready")

                        // Eligible cold-launch display shortly after startup once Home is active
                        val act = currentActivity
                        if (act is HomeActivity &&
                            (System.currentTimeMillis() - coldLaunchWindowStartMs) <= 8_000L &&
                            coldLaunchHandled.compareAndSet(false, true)
                        ) {
                            showIfEligible(act)
                        }
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        mainHandler.removeCallbacks(timeoutRunnable)
                        appOpenAd = null
                        isLoading = false
                        AdConfig.logWarning("AppOpen", "Failed to load (${error.code}): ${error.message}")
                    }
                }
            )
        }
    }

    private fun isAdValid(): Boolean {
        return appOpenAd != null &&
            (System.currentTimeMillis() - loadTimeMs) < AdConfig.APP_OPEN_EXPIRY_MS
    }

    private fun isSuppressedScreen(activity: Activity): Boolean {
        return activity is SplashActivity ||
            activity is GameplayActivity ||
            activity is PauseActivity ||
            activity.isFinishing ||
            activity.isDestroyed
    }

    fun showIfEligible(activity: Activity) {
        if (isSuppressedScreen(activity)) return
        if (!frequency.canShowAppOpen()) return

        val ad = appOpenAd
        if (ad == null || !isAdValid()) {
            appOpenAd = null
            preload()
            return
        }

        if (!frequency.tryAcquireFullscreenLock()) return

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                frequency.onAppOpenDismissed()
                preload()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                AdConfig.logWarning("AppOpen", "Show failed (${error.code}): ${error.message}")
                appOpenAd = null
                frequency.releaseFullscreenLock()
                preload()
            }
        }
        ad.show(activity)
    }

    override fun onStart(owner: LifecycleOwner) {
        // Triggered when app transitions from background to foreground
        val act = currentActivity ?: return
        showIfEligible(act)
    }

    override fun onActivityStarted(activity: Activity) {
        if (!frequency.isShowingFullscreenAd()) {
            currentActivity = activity
        }
    }

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
        if (activity is HomeActivity &&
            (System.currentTimeMillis() - coldLaunchWindowStartMs) <= 8_000L &&
            isAdValid() &&
            coldLaunchHandled.compareAndSet(false, true)
        ) {
            showIfEligible(activity)
        }
    }

    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivity == activity) {
            currentActivity = null
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
}
