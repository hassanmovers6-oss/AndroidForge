package com.arrowmaze.nightmare

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.arrowmaze.nightmare.ads.AdManager
import com.arrowmaze.nightmare.data.GameRepository
import com.arrowmaze.nightmare.util.FeedbackManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ArrowMazeApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var repository: GameRepository
        private set

    lateinit var feedbackManager: FeedbackManager
        private set

    lateinit var adManager: AdManager
        private set

    override fun onCreate() {
        super.onCreate()
        // Enforce Strict White Theme Only — disable all dark/night modes system-wide
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        repository = GameRepository(this)
        feedbackManager = FeedbackManager(this)
        adManager = AdManager(this)

        appScope.launch {
            repository.ensureInitialized()
            val profile = repository.prefs.getProfile()
            feedbackManager.soundEnabled = profile.soundEnabled
            feedbackManager.vibrationEnabled = profile.vibrationEnabled
        }
    }
}
