package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.databinding.ActivitySettingsBinding
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var bannerAdView: AdView? = null
    private var isBindingState = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        binding.btnBack.setOnClickListener { finish() }

        lifecycleScope.launch {
            val profile = withContext(Dispatchers.IO) { app.repository.prefs.getProfile() }
            isBindingState = true
            binding.switchSound.isChecked = profile.soundEnabled
            binding.switchVibration.isChecked = profile.vibrationEnabled
            isBindingState = false
        }

        binding.switchSound.setOnCheckedChangeListener { _, checked ->
            if (isBindingState) return@setOnCheckedChangeListener
            app.feedbackManager.soundEnabled = checked
            lifecycleScope.launch(Dispatchers.IO) {
                app.repository.prefs.setSoundEnabled(checked)
            }
        }

        binding.switchVibration.setOnCheckedChangeListener { _, checked ->
            if (isBindingState) return@setOnCheckedChangeListener
            app.feedbackManager.vibrationEnabled = checked
            lifecycleScope.launch(Dispatchers.IO) {
                app.repository.prefs.setVibrationEnabled(checked)
            }
        }

        binding.btnPrivacyConsent.visibility =
            if (app.adManager.consentManager.isPrivacyOptionsRequired) View.VISIBLE else View.GONE

        binding.btnPrivacyConsent.setOnClickListener {
            app.adManager.consentManager.showPrivacyOptionsForm(this) {
                if (app.adManager.consentManager.canRequestAds) {
                    app.adManager.initializeMobileAdsIfConsented()
                    if (bannerAdView == null) {
                        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
                    }
                }
                Toast.makeText(this, "Privacy consent preferences updated.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnPrivacyPolicy.setOnClickListener {
            startActivity(Intent(this, PrivacyPolicyActivity::class.java))
        }

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        super.onDestroy()
    }
}
