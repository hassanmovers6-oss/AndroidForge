package com.arrowmaze.nightmare.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Zero-bloat procedural audio & tactile haptic engine.
 * Respects user Sound and Vibration toggles and avoids audio asset bloat.
 */
class FeedbackManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(Dispatchers.Default)

    var soundEnabled: Boolean = true
    var vibrationEnabled: Boolean = true

    fun playMove() {
        if (soundEnabled) playTone(560.0, 55, 0.25f)
        if (vibrationEnabled) vibrateMs(18L)
    }

    fun playError() {
        if (soundEnabled) playTone(180.0, 140, 0.35f)
        if (vibrationEnabled) vibrateMs(75L)
    }

    fun playHint() {
        if (soundEnabled) playTone(780.0, 90, 0.28f)
        if (vibrationEnabled) vibrateMs(25L)
    }

    fun playWin() {
        if (soundEnabled) {
            scope.launch {
                playToneSync(523.25, 80, 0.30f)
                playToneSync(659.25, 80, 0.30f)
                playToneSync(783.99, 160, 0.32f)
            }
        }
        if (vibrationEnabled) vibrateMs(50L)
    }

    private fun playTone(freqHz: Double, durationMs: Int, volume: Float) {
        scope.launch {
            playToneSync(freqHz, durationMs, volume)
        }
    }

    private fun playToneSync(freqHz: Double, durationMs: Int, volume: Float) {
        try {
            val sampleRate = 22050
            val count = (sampleRate * (durationMs / 1000.0)).toInt().coerceAtLeast(1)
            val samples = ShortArray(count)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val envelope = exp(-4.5 * i / count)
                val wave = sin(2.0 * PI * freqHz * t) * envelope * volume
                samples[i] = (wave * Short.MAX_VALUE).toInt().toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(samples.size * 2)
                .build()

            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 15L)
            track.release()
        } catch (_: Exception) {
            // Safe ignore if audio hardware is busy
        }
    }

    private fun vibrateMs(durationMs: Long) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {
            // Safe ignore
        }
    }
}
