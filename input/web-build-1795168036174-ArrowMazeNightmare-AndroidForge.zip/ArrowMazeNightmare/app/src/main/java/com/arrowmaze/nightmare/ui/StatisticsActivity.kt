package com.arrowmaze.nightmare.ui

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ActivityStatisticsBinding
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StatisticsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatisticsBinding
    private var bannerAdView: AdView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatisticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        binding.btnBack.setOnClickListener { finish() }

        lifecycleScope.launch {
            val (profile, completedCount) = withContext(Dispatchers.IO) {
                Pair(app.repository.prefs.getProfile(), app.repository.getCompletedCount())
            }

            val fastestText = if (profile.fastestWinMs > 0L) {
                "${(profile.fastestWinMs / 1000.0).let { String.format("%.1fs", it) }}"
            } else {
                "--"
            }

            val winRate = if (profile.totalGamesPlayed > 0) {
                "${((profile.totalWins * 100f) / profile.totalGamesPlayed).toInt()}%"
            } else {
                "0%"
            }

            val rows = listOf(
                "Levels Cleared" to "$completedCount / 600",
                "Current Level" to "Level ${profile.currentLevel}",
                "Coin Balance" to "${profile.coins}",
                "Hint Inventory" to "${profile.hints}",
                "Total Wins" to "${profile.totalWins}",
                "Games Started" to "${profile.totalGamesPlayed}",
                "Completion Rate" to winRate,
                "Best Win Streak" to "${profile.bestWinStreak}",
                "Fastest Clear" to fastestText,
                "Total Mistakes" to "${profile.totalMistakes}",
                "Hints Used" to "${profile.totalHintsUsed}"
            )

            binding.statsContainer.removeAllViews()
            for ((label, value) in rows) {
                val card = LinearLayout(this@StatisticsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setBackgroundResource(R.drawable.bg_card_white)
                    setPadding(40, 34, 40, 34)
                    val lp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = 20 }
                    layoutParams = lp
                }
                val tvLabel = TextView(this@StatisticsActivity).apply {
                    text = label
                    textSize = 15f
                    setTextColor(ContextCompat.getColor(this@StatisticsActivity, R.color.text_secondary))
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val tvValue = TextView(this@StatisticsActivity).apply {
                    text = value
                    textSize = 16f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(ContextCompat.getColor(this@StatisticsActivity, R.color.text_primary))
                }
                card.addView(tvLabel)
                card.addView(tvValue)
                binding.statsContainer.addView(card)
            }
        }

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        super.onDestroy()
    }
}
