package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.view.ViewGroup
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Centralized Google AdMob Orchestrator owning UMP Consent, AdFrequencyController,
 * and all six dedicated Ad Format Managers:
 * 1. BannerAdManager
 * 2. InterstitialAdManager
 * 3. NativeAdManager
 * 4. RewardedAdManager
 * 5. RewardedInterstitialAdManager
 * 6. AppOpenAdManager
 */
class AdManager(private val app: Application) {

    val consentManager = ConsentManager(app)
    val frequencyController = AdFrequencyController()

    private val sdkInitialized = AtomicBoolean(false)
    private val sdkInitializing = AtomicBoolean(false)

    private val canServeAdsLambda: () -> Boolean = { canServeAds() }

    val bannerManager = BannerAdManager(canServeAdsLambda)
    val interstitialManager = InterstitialAdManager(app, frequencyController, canServeAdsLambda)
    val nativeManager = NativeAdManager(canServeAdsLambda)
    val rewardedManager = RewardedAdManager(app, frequencyController, canServeAdsLambda)
    val rewardedInterstitialManager = RewardedInterstitialAdManager(app, frequencyController, canServeAdsLambda)
    val appOpenManager = AppOpenAdManager(app, frequencyController, canServeAdsLambda)

    fun initializeMobileAdsIfConsented() {
        if (!consentManager.canRequestAds) {
            AdConfig.logDebug("Init", "Skipping MobileAds init: UMP consent not granted yet")
            return
        }
        if (sdkInitialized.get()) {
            preloadAllEligibleFormats()
            return
        }
        if (!sdkInitializing.compareAndSet(false, true)) return

        try {
            MobileAds.initialize(app) { initStatus ->
                sdkInitializing.set(false)
                sdkInitialized.set(true)
                AdConfig.logDebug(
                    "Init",
                    "MobileAds initialized (prod=${AdConfig.useProductionIds}, adapters=${initStatus.adapterStatusMap.size})"
                )
                preloadAllEligibleFormats()
            }
        } catch (t: Throwable) {
            sdkInitializing.set(false)
            AdConfig.logWarning("Init", "MobileAds initialization error: ${t.message}")
        }
    }

    fun preloadAllEligibleFormats() {
        if (!canServeAds()) return
        interstitialManager.preload()
        rewardedManager.preload()
        rewardedInterstitialManager.preload()
        appOpenManager.preload()
    }

    fun canServeAds(): Boolean =
        sdkInitialized.get() && consentManager.canRequestAds && isNetworkAvailable()

    fun isNetworkAvailable(): Boolean {
        return try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Throwable) {
            false
        }
    }

    // 1. Adaptive Banner Delegation
    fun attachAdaptiveBanner(activity: Activity, container: ViewGroup): AdView? =
        bannerManager.attachAdaptiveBanner(activity, container)

    fun resumeBanner(adView: AdView?) = bannerManager.resume(adView)
    fun pauseBanner(adView: AdView?) = bannerManager.pause(adView)
    fun destroyBanner(adView: AdView?) = bannerManager.destroy(adView)

    // 2. Interstitial Delegation
    fun onLevelCompletedMaybeShowInterstitial(activity: Activity, onFinished: () -> Unit) {
        frequencyController.recordLevelCompleted()
        interstitialManager.showIfEligible(activity, onFinished)
    }

    fun showInterstitialOnMenuTransitionIfEligible(activity: Activity, onFinished: () -> Unit) {
        interstitialManager.showIfEligible(activity, onFinished)
    }

    // 3. Native Ad Delegation
    fun loadNativeAd(
        activity: Activity,
        container: ViewGroup,
        onLoaded: ((NativeAd) -> Unit)? = null
    ) = nativeManager.loadNativeAd(activity, container, onLoaded)

    // 4. Rewarded Ad Delegation
    fun isRewardedAdReady(): Boolean = rewardedManager.isReady()

    fun loadRewardedAd(onResult: ((Boolean) -> Unit)? = null) =
        rewardedManager.preload(onResult)

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdClosedWithoutReward: () -> Unit,
        onAdUnavailable: () -> Unit
    ) = rewardedManager.show(activity, onRewardEarned, onAdClosedWithoutReward, onAdUnavailable)

    // 5. Rewarded Interstitial Delegation
    fun isRewardedInterstitialReady(): Boolean = rewardedInterstitialManager.isReady()

    fun loadRewardedInterstitialAd() = rewardedInterstitialManager.preload()

    fun showRewardedInterstitialAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onClosedWithoutReward: () -> Unit = {},
        onUnavailable: () -> Unit = {}
    ) = rewardedInterstitialManager.show(activity, onRewardEarned, onClosedWithoutReward, onUnavailable)
}
