package com.arrowmaze.nightmare.engine

data class CellCoord(val row: Int, val col: Int)

data class ArrowPath(
    val id: Int,
    /** Ordered from tail [0] to head [cells.lastIndex] */
    val cells: List<CellCoord>,
    /** Exit direction at the head cell */
    val dir: Direction
)

data class BlockerHit(
    val row: Int,
    val col: Int,
    val arrowId: Int
)

data class ArrowMazeLevel(
    val levelNumber: Int,
    val category: DifficultyCategory,
    val rows: Int,
    val cols: Int,
    val mask: IntArray,
    val paths: List<ArrowPath>,
    val solutionOrder: List<Int>
)

object ArrowMazeCollision {

    fun findPathBlocker(
        grid: IntArray,
        rows: Int,
        cols: Int,
        path: ArrowPath
    ): BlockerHit? {
        val head = path.cells.last()
        var r = head.row + path.dir.dr
        var c = head.col + path.dir.dc
        while (r in 0 until rows && c in 0 until cols) {
            val id = grid[r * cols + c]
            if (id != -1 && id != path.id) {
                return BlockerHit(r, c, id)
            }
            r += path.dir.dr
            c += path.dir.dc
        }
        return null
    }

    fun isPathClear(
        grid: IntArray,
        rows: Int,
        cols: Int,
        path: ArrowPath
    ): Boolean = findPathBlocker(grid, rows, cols, path) == null

    fun findBestHintPath(
        paths: List<ArrowPath>,
        rows: Int,
        cols: Int
    ): ArrowPath? {
        val grid = IntArray(rows * cols) { -1 }
        for (p in paths) {
            for (c in p.cells) {
                grid[c.row * cols + c.col] = p.id
            }
        }

        var best: ArrowPath? = null
        var bestUnlocks = -1

        for (candidate in paths) {
            if (!isPathClear(grid, rows, cols, candidate)) continue
            var unlocks = 0
            for (other in paths) {
                if (other.id == candidate.id) continue
                val hit = findPathBlocker(grid, rows, cols, other)
                if (hit != null && hit.arrowId == candidate.id) {
                    unlocks++
                }
            }
            if (unlocks > bestUnlocks) {
                bestUnlocks = unlocks
                best = candidate
            }
        }
        return best
    }
}
