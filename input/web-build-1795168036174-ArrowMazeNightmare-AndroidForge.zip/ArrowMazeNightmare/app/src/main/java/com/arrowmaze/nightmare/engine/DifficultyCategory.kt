package com.arrowmaze.nightmare.engine

enum class DifficultyCategory(
    val index: Int,
    val title: String,
    val startLevel: Int,
    val endLevel: Int,
    val minSize: Int,
    val maxSize: Int,
    val minPathLen: Int,
    val maxPathLen: Int,
    val rewardCoins: Int
) {
    HARD(0, "Hard", 1, 10, 18, 21, 3, 7, 15),
    VERY_HARD(1, "Very Hard", 11, 50, 22, 25, 4, 9, 20),
    EXPERT(2, "Expert", 51, 100, 25, 28, 5, 11, 26),
    INSANE(3, "Insane", 101, 200, 28, 32, 5, 13, 34),
    NIGHTMARE(4, "Nightmare", 201, 350, 32, 35, 6, 15, 42),
    IMPOSSIBLE(5, "Impossible", 351, 475, 35, 38, 6, 17, 52),
    EXTREME(6, "Extreme", 476, 600, 38, 42, 7, 20, 65);

    companion object {
        const val TOTAL_LEVELS = 600

        fun forLevel(levelNumber: Int): DifficultyCategory {
            val clamped = levelNumber.coerceIn(1, TOTAL_LEVELS)
            return entries.first { clamped in it.startLevel..it.endLevel }
        }
    }
}
