package com.arrowmaze.nightmare.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ItemDailyRewardBinding

data class DailyRewardTier(
    val day: Int,
    val coins: Int,
    val hints: Int
)

class DailyRewardAdapter : RecyclerView.Adapter<DailyRewardAdapter.DailyViewHolder>() {

    private var rewards: List<DailyRewardTier> = emptyList()
    private var claimedCount: Int = 0
    private var canClaimToday: Boolean = false

    fun update(list: List<DailyRewardTier>, claimed: Int, claimable: Boolean) {
        rewards = list
        claimedCount = claimed
        canClaimToday = claimable
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DailyViewHolder {
        val binding = ItemDailyRewardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DailyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DailyViewHolder, position: Int) {
        holder.bind(rewards[position])
    }

    override fun getItemCount(): Int = rewards.size

    inner class DailyViewHolder(
        private val binding: ItemDailyRewardBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: DailyRewardTier) {
            val ctx = binding.root.context
            binding.tvDayLabel.text = "Day ${item.day}"
            binding.tvRewardDetail.text = buildString {
                append("+${item.coins} Coins")
                if (item.hints > 0) append(" · +${item.hints} Hint${if (item.hints > 1) "s" else ""}")
            }

            when {
                item.day <= claimedCount -> {
                    binding.tvClaimStatus.text = "Claimed"
                    binding.tvClaimStatus.setTextColor(ContextCompat.getColor(ctx, R.color.success_emerald))
                }
                item.day == claimedCount + 1 && canClaimToday -> {
                    binding.tvClaimStatus.text = "Available"
                    binding.tvClaimStatus.setTextColor(ContextCompat.getColor(ctx, R.color.nightmare_pink))
                }
                else -> {
                    binding.tvClaimStatus.text = "Locked"
                    binding.tvClaimStatus.setTextColor(ContextCompat.getColor(ctx, R.color.text_muted))
                }
            }
        }
    }
}
