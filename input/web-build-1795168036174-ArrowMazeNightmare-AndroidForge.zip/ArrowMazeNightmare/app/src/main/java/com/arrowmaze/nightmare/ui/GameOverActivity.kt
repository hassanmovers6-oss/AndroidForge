package com.arrowmaze.nightmare.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.R
import com.arrowmaze.nightmare.databinding.ActivityGameOverBinding
import com.arrowmaze.nightmare.engine.DifficultyCategory
import com.google.android.gms.ads.AdView

class GameOverActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LEVEL_NUMBER = "extra_level_number"
        const val EXTRA_EXTRA_LIVES_USED = "extra_extra_lives_used"
        const val RESULT_EXTRA_LIFE = 201
        const val RESULT_RESTART = 202
    }

    private lateinit var binding: ActivityGameOverBinding
    private var bannerAdView: AdView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameOverBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication
        val levelNumber = intent.getIntExtra(EXTRA_LEVEL_NUMBER, 1)
        val extraLivesUsed = intent.getIntExtra(EXTRA_EXTRA_LIVES_USED, 0)
        val maxExtraLives = app.adManager.frequencyController.settings.maxExtraLivesPerAttempt
        val category = DifficultyCategory.forLevel(levelNumber)

        binding.tvGameOverLevel.text = "Level $levelNumber · ${category.title}"

        if (extraLivesUsed >= maxExtraLives) {
            binding.btnWatchAdExtraLife.visibility = View.GONE
            binding.tvExtraLifeStatus.text =
                "Extra life limit reached for this attempt ($maxExtraLives max). Restart the maze to restore 3 hearts."
        } else {
            binding.btnWatchAdExtraLife.setOnClickListener {
                if (!app.adManager.isRewardedAdReady()) {
                    Toast.makeText(this, getString(R.string.ad_extra_life_unavailable), Toast.LENGTH_SHORT).show()
                    app.adManager.loadRewardedAd()
                    return@setOnClickListener
                }

                app.adManager.showRewardedAd(
                    activity = this,
                    onRewardEarned = {
                        setResult(RESULT_EXTRA_LIFE)
                        finish()
                    },
                    onAdClosedWithoutReward = {
                        Toast.makeText(this, getString(R.string.ad_failed_no_reward), Toast.LENGTH_SHORT).show()
                    },
                    onAdUnavailable = {
                        Toast.makeText(this, getString(R.string.ad_extra_life_unavailable), Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        binding.btnRestartLevel.setOnClickListener {
            setResult(RESULT_RESTART)
            finish()
        }

        binding.btnHome.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }

        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        super.onDestroy()
    }
}
