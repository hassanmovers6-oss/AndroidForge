package com.arrowmaze.nightmare.data

import android.content.Context
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore(
    name = "arrow_maze_prefs",
    corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() }
)

data class PlayerProfile(
    val currentLevel: Int = 1,
    val coins: Int = 50,
    val hints: Int = 2,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val dailyStreak: Int = 0,
    val lastDailyClaimEpochDay: Long = -1L,
    val totalGamesPlayed: Int = 0,
    val totalWins: Int = 0,
    val totalMistakes: Int = 0,
    val totalHintsUsed: Int = 0,
    val currentWinStreak: Int = 0,
    val bestWinStreak: Int = 0,
    val fastestWinMs: Long = 0L
)

class PreferencesManager(private val context: Context) {

    private object Keys {
        val CURRENT_LEVEL = intPreferencesKey("current_level")
        val COINS = intPreferencesKey("coins")
        val HINTS = intPreferencesKey("hints")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val DAILY_STREAK = intPreferencesKey("daily_streak")
        val LAST_DAILY_CLAIM = longPreferencesKey("last_daily_claim_epoch_day")
        val TOTAL_GAMES_PLAYED = intPreferencesKey("total_games_played")
        val TOTAL_WINS = intPreferencesKey("total_wins")
        val TOTAL_MISTAKES = intPreferencesKey("total_mistakes")
        val TOTAL_HINTS_USED = intPreferencesKey("total_hints_used")
        val CURRENT_WIN_STREAK = intPreferencesKey("current_win_streak")
        val BEST_WIN_STREAK = intPreferencesKey("best_win_streak")
        val FASTEST_WIN_MS = longPreferencesKey("fastest_win_ms")
    }

    val profileFlow: Flow<PlayerProfile> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                emit(emptyPreferences())
            }
        }
        .map { prefs -> mapProfile(prefs) }

    suspend fun getProfile(): PlayerProfile = profileFlow.first()

    private fun mapProfile(prefs: Preferences): PlayerProfile {
        return PlayerProfile(
            currentLevel = (prefs[Keys.CURRENT_LEVEL] ?: 1).coerceIn(1, 600),
            coins = (prefs[Keys.COINS] ?: 50).coerceAtLeast(0),
            hints = (prefs[Keys.HINTS] ?: 2).coerceAtLeast(0),
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION_ENABLED] ?: true,
            dailyStreak = (prefs[Keys.DAILY_STREAK] ?: 0).coerceIn(0, 7),
            lastDailyClaimEpochDay = prefs[Keys.LAST_DAILY_CLAIM] ?: -1L,
            totalGamesPlayed = (prefs[Keys.TOTAL_GAMES_PLAYED] ?: 0).coerceAtLeast(0),
            totalWins = (prefs[Keys.TOTAL_WINS] ?: 0).coerceAtLeast(0),
            totalMistakes = (prefs[Keys.TOTAL_MISTAKES] ?: 0).coerceAtLeast(0),
            totalHintsUsed = (prefs[Keys.TOTAL_HINTS_USED] ?: 0).coerceAtLeast(0),
            currentWinStreak = (prefs[Keys.CURRENT_WIN_STREAK] ?: 0).coerceAtLeast(0),
            bestWinStreak = (prefs[Keys.BEST_WIN_STREAK] ?: 0).coerceAtLeast(0),
            fastestWinMs = (prefs[Keys.FASTEST_WIN_MS] ?: 0L).coerceAtLeast(0L)
        )
    }

    suspend fun setCurrentLevel(level: Int) {
        context.dataStore.edit { it[Keys.CURRENT_LEVEL] = level.coerceIn(1, 500) }
    }

    suspend fun addCoins(amount: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.COINS] ?: 50
            prefs[Keys.COINS] = (current + amount).coerceAtLeast(0)
        }
    }

    suspend fun addHints(amount: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HINTS] ?: 2
            prefs[Keys.HINTS] = (current + amount).coerceAtLeast(0)
        }
    }

    suspend fun consumeHint(): Boolean {
        var consumed = false
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HINTS] ?: 2
            if (current > 0) {
                prefs[Keys.HINTS] = current - 1
                prefs[Keys.TOTAL_HINTS_USED] = (prefs[Keys.TOTAL_HINTS_USED] ?: 0) + 1
                consumed = true
            }
        }
        return consumed
    }

    suspend fun recordHintUsedDirect() {
        context.dataStore.edit { prefs ->
            prefs[Keys.TOTAL_HINTS_USED] = (prefs[Keys.TOTAL_HINTS_USED] ?: 0) + 1
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VIBRATION_ENABLED] = enabled }
    }

    suspend fun recordMistake() {
        context.dataStore.edit { prefs ->
            prefs[Keys.TOTAL_MISTAKES] = (prefs[Keys.TOTAL_MISTAKES] ?: 0) + 1
        }
    }

    suspend fun recordLevelStart() {
        context.dataStore.edit { prefs ->
            prefs[Keys.TOTAL_GAMES_PLAYED] = (prefs[Keys.TOTAL_GAMES_PLAYED] ?: 0) + 1
        }
    }

    suspend fun recordLevelLoss() {
        context.dataStore.edit { prefs ->
            prefs[Keys.CURRENT_WIN_STREAK] = 0
        }
    }

    suspend fun recordLevelWin(elapsedMs: Long, coinReward: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.TOTAL_WINS] = (prefs[Keys.TOTAL_WINS] ?: 0) + 1
            prefs[Keys.COINS] = (prefs[Keys.COINS] ?: 50) + coinReward
            val newStreak = (prefs[Keys.CURRENT_WIN_STREAK] ?: 0) + 1
            prefs[Keys.CURRENT_WIN_STREAK] = newStreak
            val best = prefs[Keys.BEST_WIN_STREAK] ?: 0
            if (newStreak > best) prefs[Keys.BEST_WIN_STREAK] = newStreak

            val fastest = prefs[Keys.FASTEST_WIN_MS] ?: 0L
            if (elapsedMs > 0L && (fastest == 0L || elapsedMs < fastest)) {
                prefs[Keys.FASTEST_WIN_MS] = elapsedMs
            }
        }
    }

    suspend fun claimDailyReward(epochDay: Long, newStreak: Int, coinBonus: Int, hintBonus: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_DAILY_CLAIM] = epochDay
            prefs[Keys.DAILY_STREAK] = newStreak.coerceIn(1, 7)
            prefs[Keys.COINS] = (prefs[Keys.COINS] ?: 50) + coinBonus
            prefs[Keys.HINTS] = (prefs[Keys.HINTS] ?: 2) + hintBonus
        }
    }
}
