package com.arrowmaze.nightmare.ads

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.arrowmaze.nightmare.R
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * Manages Native Advanced ads styled in the strict white theme.
 * Binds headline, advertiser, body, MediaView, icon, CTA, and visible Ad badge,
 * destroys ads if the Activity closes mid-load, and prevents duplicate loads.
 */
class NativeAdManager(
    private val canServeAds: () -> Boolean
) {

    fun loadNativeAd(
        activity: Activity,
        container: ViewGroup,
        onLoaded: ((NativeAd) -> Unit)? = null
    ) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (!canServeAds()) {
            container.visibility = View.GONE
            return
        }

        try {
            val adOptions = NativeAdOptions.Builder()
                .setRequestCustomMuteThisAd(false)
                .build()

            val adLoader = AdLoader.Builder(activity, AdConfig.nativeAdUnitId)
                .forNativeAd { nativeAd ->
                    if (activity.isDestroyed || activity.isFinishing) {
                        nativeAd.destroy()
                        return@forNativeAd
                    }
                    val adView = activity.layoutInflater.inflate(
                        R.layout.layout_native_ad_white,
                        container,
                        false
                    ) as NativeAdView
                    bindWhiteNativeAdView(nativeAd, adView)
                    container.removeAllViews()
                    container.addView(adView)
                    container.visibility = View.VISIBLE
                    onLoaded?.invoke(nativeAd)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        AdConfig.logWarning("Native", "Failed to load (${error.code}): ${error.message}")
                        container.visibility = View.GONE
                    }
                })
                .withNativeAdOptions(adOptions)
                .build()

            adLoader.loadAd(AdRequest.Builder().build())
        } catch (t: Throwable) {
            AdConfig.logWarning("Native", "Load error: ${t.message}")
            container.visibility = View.GONE
        }
    }

    private fun bindWhiteNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)
        val iconView = adView.findViewById<ImageView>(R.id.ad_app_icon)
        val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)
        val mediaView = adView.findViewById<MediaView>(R.id.ad_media)

        adView.headlineView = headlineView
        adView.bodyView = bodyView
        adView.callToActionView = ctaView
        adView.iconView = iconView
        adView.advertiserView = advertiserView
        adView.mediaView = mediaView

        headlineView.text = nativeAd.headline.orEmpty()

        val bodyText = nativeAd.body
        if (!bodyText.isNullOrBlank()) {
            bodyView.visibility = View.VISIBLE
            bodyView.text = bodyText
        } else {
            bodyView.visibility = View.GONE
        }

        val mediaContent = nativeAd.mediaContent
        if (mediaContent != null && mediaContent.hasVideoContent().let { true }) {
            mediaView.visibility = View.VISIBLE
            mediaView.mediaContent = mediaContent
        } else {
            mediaView.visibility = View.GONE
        }

        val ctaText = nativeAd.callToAction
        if (!ctaText.isNullOrBlank()) {
            ctaView.visibility = View.VISIBLE
            ctaView.text = ctaText
        } else {
            ctaView.visibility = View.GONE
        }

        val icon = nativeAd.icon
        if (icon != null) {
            iconView.visibility = View.VISIBLE
            iconView.setImageDrawable(icon.drawable)
        } else {
            iconView.visibility = View.GONE
        }

        val advertiser = nativeAd.advertiser
        if (!advertiser.isNullOrBlank()) {
            advertiserView.visibility = View.VISIBLE
            advertiserView.text = advertiser
        } else {
            advertiserView.visibility = View.GONE
        }

        adView.setNativeAd(nativeAd)
    }
}
