package com.arrowmaze.nightmare.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arrowmaze.nightmare.ArrowMazeApplication
import com.arrowmaze.nightmare.databinding.ActivityHomeBinding
import com.arrowmaze.nightmare.engine.DifficultyCategory
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.nativead.NativeAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private var bannerAdView: AdView? = null
    private var loadedNativeAd: NativeAd? = null
    private var currentPlayLevel = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as ArrowMazeApplication

        binding.btnPlayCurrent.setOnClickListener {
            val intent = Intent(this, GameplayActivity::class.java)
            intent.putExtra(GameplayActivity.EXTRA_LEVEL_NUMBER, currentPlayLevel)
            startActivity(intent)
        }

        binding.btnLevels.setOnClickListener {
            startActivity(Intent(this, LevelSelectActivity::class.java))
        }

        binding.btnDailyRewards.setOnClickListener {
            startActivity(Intent(this, DailyRewardsActivity::class.java))
        }

        binding.btnStatistics.setOnClickListener {
            startActivity(Intent(this, StatisticsActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        binding.btnPrivacy.setOnClickListener {
            startActivity(Intent(this, PrivacyPolicyActivity::class.java))
        }

        // Load Adaptive Banner & White-Theme Native Ad
        bannerAdView = app.adManager.attachAdaptiveBanner(this, binding.bannerAdContainer)
        app.adManager.loadNativeAd(this, binding.nativeAdContainer) { nativeAd ->
            loadedNativeAd?.destroy()
            loadedNativeAd = nativeAd
        }
    }

    override fun onResume() {
        super.onResume()
        (application as ArrowMazeApplication).adManager.resumeBanner(bannerAdView)
        refreshDashboard()
    }

    override fun onPause() {
        (application as ArrowMazeApplication).adManager.pauseBanner(bannerAdView)
        super.onPause()
    }

    override fun onDestroy() {
        (application as ArrowMazeApplication).adManager.destroyBanner(bannerAdView)
        bannerAdView = null
        loadedNativeAd?.destroy()
        loadedNativeAd = null
        super.onDestroy()
    }

    private fun refreshDashboard() {
        val app = application as ArrowMazeApplication
        lifecycleScope.launch {
            val (profile, completedCount, highestUnlocked) = withContext(Dispatchers.IO) {
                Triple(
                    app.repository.prefs.getProfile(),
                    app.repository.getCompletedCount(),
                    app.repository.getHighestUnlockedLevel()
                )
            }
            currentPlayLevel = profile.currentLevel.coerceIn(1, highestUnlocked)
            val category = DifficultyCategory.forLevel(currentPlayLevel)

            binding.tvCoins.text = profile.coins.toString()
            binding.tvHints.text = "${profile.hints} Hints"
            binding.tvCurrentTier.text = "${category.title} · Level $currentPlayLevel of 600 ($completedCount Cleared)"
            binding.progressMastery.max = DifficultyCategory.TOTAL_LEVELS
            binding.progressMastery.progress = completedCount.coerceAtLeast(1)
            binding.btnPlayCurrent.text = "Play Level $currentPlayLevel"
        }
    }
}
