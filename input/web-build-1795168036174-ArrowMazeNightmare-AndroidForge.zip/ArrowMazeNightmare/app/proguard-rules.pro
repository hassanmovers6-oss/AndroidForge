# Arrow Maze: Nightmare ProGuard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Room entities & DAOs
-keep class com.arrowmaze.nightmare.data.** { *; }

# Keep Google Mobile Ads & UMP classes
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.ump.** { *; }
-dontwarn com.google.android.gms.ads.**
