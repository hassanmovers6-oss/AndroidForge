# Arrow Maze: Nightmare (Native Android Kotlin Project)

**Arrow Maze: Nightmare** is a complete, offline-first, strict White-Theme **Arrow Escape / Arrow Out** puzzle game built in **Kotlin** for Android, configured for **AndroidForge** cloud APK generation and **Google Play** publishing.

## Core Architecture
- **100% Pure White Theme**: `Theme.Material3.Light.NoActionBar` (`forceDarkAllowed="false"`, `AppCompatDelegate.MODE_NIGHT_NO`), pure `#FFFFFF` background, dense `#000000` multi-segment black arrow paths and arrowheads, `#EC4899` pink Nightmare heading, `#EF4444` three-heart indicators, and `#F1F5F9` light grey circular action buttons.
- **Irregular Multi-Segment Arrow Maze Mechanics**: Level 1 starts directly with an `18x18` organic irregular labyrinth packed with ~35+ bent multi-turn arrow paths (~180+ connected segments). Players tap any arrow path; unobstructed paths slither around their corners and exit the maze at 60 FPS (`ArrowMazeCanvasView`), opening exit lanes for deeper paths. Tapping a blocked path triggers collision ray feedback and deducts 1 red heart.
- **600 Verified Solvable Levels**: Reverse-construction `ArrowMazeGenerator` with topological tail-extension invariance spanning 7 escalating difficulty categories (`Hard`, `Very Hard`, `Expert`, `Insane`, `Nightmare`, `Impossible`, `Extreme`), verified with `ArrowMazeGeneratorTest.kt`.
- **Offline-First Local Storage**: Android **Room** (`AppDatabase`) tracks all 600 levels' unlock/completion/best-move/best-time records; **DataStore Preferences** (`PreferencesManager`) persists coins, hint inventory, daily streak, statistics, and audio/haptic preferences with corruption fallback.
- **Complete 6-Format Production Google AdMob + UMP Integration**:
  - `AdConfig.kt` + `app/build.gradle.kts` separate `debug` (Google Test IDs + debug logs) from `release` (production App ID `ca-app-pub-3133971041724338~2576474017` and all 6 production Ad Unit IDs with debug logs disabled).
  - `ConsentManager.kt` runs Google User Messaging Platform (UMP) before SDK initialization.
  - `AdFrequencyController.kt` enforces level intervals (every 3 levels), 120s interstitial cooldown, 4h App Open cooldown, active gameplay & arrow-animation suppression, and anti-stacking gaps after rewarded ads.
  - Dedicated format managers: `BannerAdManager`, `InterstitialAdManager`, `NativeAdManager`, `RewardedAdManager`, `RewardedInterstitialAdManager`, and `AppOpenAdManager`, orchestrated by `AdManager.kt`.

## Building an APK (Gradle / AndroidForge)
1. Upload the `android/` directory to **AndroidForge** or open `android/` in **Android Studio**.
2. Run the unit test verifying all 600 levels:
   ```bash
   ./gradlew test
   ```
3. Build the release APK:
   ```bash
   gradle assembleRelease
   ```
   Output APK path: `app/build/outputs/apk/release/app-release.apk`.
