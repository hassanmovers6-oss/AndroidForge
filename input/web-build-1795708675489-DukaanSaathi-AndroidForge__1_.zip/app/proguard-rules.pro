# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Gson backup models
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.educationwithhassan.dukaansaathi.data.local.entity.** { *; }
-keep class com.educationwithhassan.dukaansaathi.util.BackupPayload { *; }
-keep class com.educationwithhassan.dukaansaathi.util.BackupMetadata { *; }

# Google Mobile Ads
-keep class com.google.android.gms.ads.** { *; }

# ML Kit Barcode
-keep class com.google.mlkit.vision.barcode.** { *; }

# Guava Android compile-only annotation references for R8 release builds
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.checkerframework.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
-dontwarn javax.annotation.**
