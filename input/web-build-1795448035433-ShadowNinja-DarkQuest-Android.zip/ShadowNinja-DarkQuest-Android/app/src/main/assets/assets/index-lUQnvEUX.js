// \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod, mod.exports), cb = null), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
// \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
// node_modules/scheduler/cjs/scheduler.production.js
/**
* @license React
* scheduler.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_scheduler_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	function push(heap, node) {
		var index = heap.length;
		heap.push(node);
		a: for (; 0 < index;) {
			var parentIndex = index - 1 >>> 1, parent = heap[parentIndex];
			if (0 < compare(parent, node)) heap[parentIndex] = node, heap[index] = parent, index = parentIndex;
			else break a;
		}
	}
	function peek(heap) {
		return 0 === heap.length ? null : heap[0];
	}
	function pop(heap) {
		if (0 === heap.length) return null;
		var first = heap[0], last = heap.pop();
		if (last !== first) {
			heap[0] = last;
			a: for (var index = 0, length = heap.length, halfLength = length >>> 1; index < halfLength;) {
				var leftIndex = 2 * (index + 1) - 1, left = heap[leftIndex], rightIndex = leftIndex + 1, right = heap[rightIndex];
				if (0 > compare(left, last)) rightIndex < length && 0 > compare(right, left) ? (heap[index] = right, heap[rightIndex] = last, index = rightIndex) : (heap[index] = left, heap[leftIndex] = last, index = leftIndex);
				else if (rightIndex < length && 0 > compare(right, last)) heap[index] = right, heap[rightIndex] = last, index = rightIndex;
				else break a;
			}
		}
		return first;
	}
	function compare(a, b) {
		var diff = a.sortIndex - b.sortIndex;
		return 0 !== diff ? diff : a.id - b.id;
	}
	exports.unstable_now = void 0;
	if ("object" === typeof performance && "function" === typeof performance.now) {
		var localPerformance = performance;
		exports.unstable_now = function() {
			return localPerformance.now();
		};
	} else {
		var localDate = Date, initialTime = localDate.now();
		exports.unstable_now = function() {
			return localDate.now() - initialTime;
		};
	}
	var taskQueue = [];
	var timerQueue = [];
	var taskIdCounter = 1;
	var currentTask = null;
	var currentPriorityLevel = 3;
	var isPerformingWork = !1;
	var isHostCallbackScheduled = !1;
	var isHostTimeoutScheduled = !1;
	var needsPaint = !1;
	var localSetTimeout = "function" === typeof setTimeout ? setTimeout : null;
	var localClearTimeout = "function" === typeof clearTimeout ? clearTimeout : null;
	var localSetImmediate = "undefined" !== typeof setImmediate ? setImmediate : null;
	function advanceTimers(currentTime) {
		for (var timer = peek(timerQueue); null !== timer;) {
			if (null === timer.callback) pop(timerQueue);
			else if (timer.startTime <= currentTime) pop(timerQueue), timer.sortIndex = timer.expirationTime, push(taskQueue, timer);
			else break;
			timer = peek(timerQueue);
		}
	}
	function handleTimeout(currentTime) {
		isHostTimeoutScheduled = !1;
		advanceTimers(currentTime);
		if (!isHostCallbackScheduled) if (null !== peek(taskQueue)) isHostCallbackScheduled = !0, isMessageLoopRunning || (isMessageLoopRunning = !0, schedulePerformWorkUntilDeadline());
		else {
			var firstTimer = peek(timerQueue);
			null !== firstTimer && requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
		}
	}
	var isMessageLoopRunning = !1;
	var taskTimeoutID = -1;
	var frameInterval = 5;
	var startTime = -1;
	function shouldYieldToHost() {
		return needsPaint ? !0 : exports.unstable_now() - startTime < frameInterval ? !1 : !0;
	}
	function performWorkUntilDeadline() {
		needsPaint = !1;
		if (isMessageLoopRunning) {
			var currentTime = exports.unstable_now();
			startTime = currentTime;
			var hasMoreWork = !0;
			try {
				a: {
					isHostCallbackScheduled = !1;
					isHostTimeoutScheduled && (isHostTimeoutScheduled = !1, localClearTimeout(taskTimeoutID), taskTimeoutID = -1);
					isPerformingWork = !0;
					var previousPriorityLevel = currentPriorityLevel;
					try {
						b: {
							advanceTimers(currentTime);
							for (currentTask = peek(taskQueue); null !== currentTask && !(currentTask.expirationTime > currentTime && shouldYieldToHost());) {
								var callback = currentTask.callback;
								if ("function" === typeof callback) {
									currentTask.callback = null;
									currentPriorityLevel = currentTask.priorityLevel;
									var continuationCallback = callback(currentTask.expirationTime <= currentTime);
									currentTime = exports.unstable_now();
									if ("function" === typeof continuationCallback) {
										currentTask.callback = continuationCallback;
										advanceTimers(currentTime);
										hasMoreWork = !0;
										break b;
									}
									currentTask === peek(taskQueue) && pop(taskQueue);
									advanceTimers(currentTime);
								} else pop(taskQueue);
								currentTask = peek(taskQueue);
							}
							if (null !== currentTask) hasMoreWork = !0;
							else {
								var firstTimer = peek(timerQueue);
								null !== firstTimer && requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
								hasMoreWork = !1;
							}
						}
						break a;
					} finally {
						currentTask = null, currentPriorityLevel = previousPriorityLevel, isPerformingWork = !1;
					}
					hasMoreWork = void 0;
				}
			} finally {
				hasMoreWork ? schedulePerformWorkUntilDeadline() : isMessageLoopRunning = !1;
			}
		}
	}
	var schedulePerformWorkUntilDeadline;
	if ("function" === typeof localSetImmediate) schedulePerformWorkUntilDeadline = function() {
		localSetImmediate(performWorkUntilDeadline);
	};
	else if ("undefined" !== typeof MessageChannel) {
		var channel = new MessageChannel(), port = channel.port2;
		channel.port1.onmessage = performWorkUntilDeadline;
		schedulePerformWorkUntilDeadline = function() {
			port.postMessage(null);
		};
	} else schedulePerformWorkUntilDeadline = function() {
		localSetTimeout(performWorkUntilDeadline, 0);
	};
	function requestHostTimeout(callback, ms) {
		taskTimeoutID = localSetTimeout(function() {
			callback(exports.unstable_now());
		}, ms);
	}
	exports.unstable_IdlePriority = 5;
	exports.unstable_ImmediatePriority = 1;
	exports.unstable_LowPriority = 4;
	exports.unstable_NormalPriority = 3;
	exports.unstable_Profiling = null;
	exports.unstable_UserBlockingPriority = 2;
	exports.unstable_cancelCallback = function(task) {
		task.callback = null;
	};
	exports.unstable_forceFrameRate = function(fps) {
		0 > fps || 125 < fps ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : frameInterval = 0 < fps ? Math.floor(1e3 / fps) : 5;
	};
	exports.unstable_getCurrentPriorityLevel = function() {
		return currentPriorityLevel;
	};
	exports.unstable_next = function(eventHandler) {
		switch (currentPriorityLevel) {
			case 1:
			case 2:
			case 3:
				var priorityLevel = 3;
				break;
			default: priorityLevel = currentPriorityLevel;
		}
		var previousPriorityLevel = currentPriorityLevel;
		currentPriorityLevel = priorityLevel;
		try {
			return eventHandler();
		} finally {
			currentPriorityLevel = previousPriorityLevel;
		}
	};
	exports.unstable_requestPaint = function() {
		needsPaint = !0;
	};
	exports.unstable_runWithPriority = function(priorityLevel, eventHandler) {
		switch (priorityLevel) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5: break;
			default: priorityLevel = 3;
		}
		var previousPriorityLevel = currentPriorityLevel;
		currentPriorityLevel = priorityLevel;
		try {
			return eventHandler();
		} finally {
			currentPriorityLevel = previousPriorityLevel;
		}
	};
	exports.unstable_scheduleCallback = function(priorityLevel, callback, options) {
		var currentTime = exports.unstable_now();
		"object" === typeof options && null !== options ? (options = options.delay, options = "number" === typeof options && 0 < options ? currentTime + options : currentTime) : options = currentTime;
		switch (priorityLevel) {
			case 1:
				var timeout = -1;
				break;
			case 2:
				timeout = 250;
				break;
			case 5:
				timeout = 1073741823;
				break;
			case 4:
				timeout = 1e4;
				break;
			default: timeout = 5e3;
		}
		timeout = options + timeout;
		priorityLevel = {
			id: taskIdCounter++,
			callback,
			priorityLevel,
			startTime: options,
			expirationTime: timeout,
			sortIndex: -1
		};
		options > currentTime ? (priorityLevel.sortIndex = options, push(timerQueue, priorityLevel), null === peek(taskQueue) && priorityLevel === peek(timerQueue) && (isHostTimeoutScheduled ? (localClearTimeout(taskTimeoutID), taskTimeoutID = -1) : isHostTimeoutScheduled = !0, requestHostTimeout(handleTimeout, options - currentTime))) : (priorityLevel.sortIndex = timeout, push(taskQueue, priorityLevel), isHostCallbackScheduled || isPerformingWork || (isHostCallbackScheduled = !0, isMessageLoopRunning || (isMessageLoopRunning = !0, schedulePerformWorkUntilDeadline())));
		return priorityLevel;
	};
	exports.unstable_shouldYield = shouldYieldToHost;
	exports.unstable_wrapCallback = function(callback) {
		var parentPriorityLevel = currentPriorityLevel;
		return function() {
			var previousPriorityLevel = currentPriorityLevel;
			currentPriorityLevel = parentPriorityLevel;
			try {
				return callback.apply(this, arguments);
			} finally {
				currentPriorityLevel = previousPriorityLevel;
			}
		};
	};
}));
// node_modules/scheduler/index.js
var require_scheduler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_scheduler_production();
}));
// node_modules/react/cjs/react.production.js
/**
* @license React
* react.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
	var REACT_PORTAL_TYPE = Symbol.for("react.portal");
	var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
	var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
	var REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
	var REACT_CONTEXT_TYPE = Symbol.for("react.context");
	var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
	var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
	var REACT_MEMO_TYPE = Symbol.for("react.memo");
	var REACT_LAZY_TYPE = Symbol.for("react.lazy");
	var REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
	var REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition");
	var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
	function getIteratorFn(maybeIterable) {
		if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
		maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
		return "function" === typeof maybeIterable ? maybeIterable : null;
	}
	var ReactNoopUpdateQueue = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	};
	var assign = Object.assign;
	var emptyObject = {};
	function Component(props, context, updater) {
		this.props = props;
		this.context = context;
		this.refs = emptyObject;
		this.updater = updater || ReactNoopUpdateQueue;
	}
	Component.prototype.isReactComponent = {};
	Component.prototype.setState = function(partialState, callback) {
		if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, partialState, callback, "setState");
	};
	Component.prototype.forceUpdate = function(callback) {
		this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
	};
	function ComponentDummy() {}
	ComponentDummy.prototype = Component.prototype;
	function PureComponent(props, context, updater) {
		this.props = props;
		this.context = context;
		this.refs = emptyObject;
		this.updater = updater || ReactNoopUpdateQueue;
	}
	var pureComponentPrototype = PureComponent.prototype = new ComponentDummy();
	pureComponentPrototype.constructor = PureComponent;
	assign(pureComponentPrototype, Component.prototype);
	pureComponentPrototype.isPureReactComponent = !0;
	var isArrayImpl = Array.isArray;
	function noop() {}
	var ReactSharedInternals = {
		H: null,
		A: null,
		T: null,
		S: null
	};
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	function ReactElement(type, key, props) {
		var refProp = props.ref;
		return {
			$$typeof: REACT_ELEMENT_TYPE,
			type,
			key,
			ref: void 0 !== refProp ? refProp : null,
			props
		};
	}
	function cloneAndReplaceKey(oldElement, newKey) {
		return ReactElement(oldElement.type, newKey, oldElement.props);
	}
	function isValidElement(object) {
		return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
	}
	function escape(key) {
		var escaperLookup = {
			"=": "=0",
			":": "=2"
		};
		return "$" + key.replace(/[=:]/g, function(match) {
			return escaperLookup[match];
		});
	}
	var userProvidedKeyEscapeRegex = /\/+/g;
	function getElementKey(element, index) {
		return "object" === typeof element && null !== element && null != element.key ? escape("" + element.key) : index.toString(36);
	}
	function resolveThenable(thenable) {
		switch (thenable.status) {
			case "fulfilled": return thenable.value;
			case "rejected": throw thenable.reason;
			default: switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function(fulfilledValue) {
				"pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
			}, function(error) {
				"pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
			})), thenable.status) {
				case "fulfilled": return thenable.value;
				case "rejected": throw thenable.reason;
			}
		}
		throw thenable;
	}
	function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
		var type = typeof children;
		if ("undefined" === type || "boolean" === type) children = null;
		var invokeCallback = !1;
		if (null === children) invokeCallback = !0;
		else switch (type) {
			case "bigint":
			case "string":
			case "number":
				invokeCallback = !0;
				break;
			case "object": switch (children.$$typeof) {
				case REACT_ELEMENT_TYPE:
				case REACT_PORTAL_TYPE:
					invokeCallback = !0;
					break;
				case REACT_LAZY_TYPE: return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
			}
		}
		if (invokeCallback) return callback = callback(children), invokeCallback = "" === nameSoFar ? "." + getElementKey(children, 0) : nameSoFar, isArrayImpl(callback) ? (escapedPrefix = "", null != invokeCallback && (escapedPrefix = invokeCallback.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
			return c;
		})) : null != callback && (isValidElement(callback) && (callback = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || children && children.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + invokeCallback)), array.push(callback)), 1;
		invokeCallback = 0;
		var nextNamePrefix = "" === nameSoFar ? "." : nameSoFar + ":";
		if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = nextNamePrefix + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
		else if (i = getIteratorFn(children), "function" === typeof i) for (children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = nextNamePrefix + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
		else if ("object" === type) {
			if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
			array = String(children);
			throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
		}
		return invokeCallback;
	}
	function mapChildren(children, func, context) {
		if (null == children) return children;
		var result = [], count = 0;
		mapIntoArray(children, result, "", "", function(child) {
			return func.call(context, child, count++);
		});
		return result;
	}
	function lazyInitializer(payload) {
		if (-1 === payload._status) {
			var ctor = payload._result, thenable = ctor();
			thenable.then(function(moduleObject) {
				if (0 === payload._status || -1 === payload._status) payload._status = 1, payload._result = moduleObject, void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
			}, function(error) {
				if (0 === payload._status || -1 === payload._status) payload._status = 2, payload._result = error, void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
			});
			-1 === payload._status && (payload._status = 0, payload._result = thenable);
		}
		if (1 === payload._status) return payload._result.default;
		throw payload._result;
	}
	var reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
		if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
			var event = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
				error
			});
			if (!window.dispatchEvent(event)) return;
		} else if ("object" === typeof process && "function" === typeof process.emit) {
			process.emit("uncaughtException", error);
			return;
		}
		console.error(error);
	};
	function startTransition(scope) {
		var prevTransition = ReactSharedInternals.T, currentTransition = {};
		currentTransition.types = null !== prevTransition ? prevTransition.types : null;
		ReactSharedInternals.T = currentTransition;
		try {
			var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
			null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
			"object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
		} catch (error) {
			reportGlobalError(error);
		} finally {
			null !== prevTransition && null !== currentTransition.types && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
		}
	}
	function addTransitionType(type) {
		var transition = ReactSharedInternals.T;
		if (null !== transition) {
			var transitionTypes = transition.types;
			null === transitionTypes ? transition.types = [type] : -1 === transitionTypes.indexOf(type) && transitionTypes.push(type);
		} else startTransition(addTransitionType.bind(null, type));
	}
	var Children = {
		map: mapChildren,
		forEach: function(children, forEachFunc, forEachContext) {
			mapChildren(children, function() {
				forEachFunc.apply(this, arguments);
			}, forEachContext);
		},
		count: function(children) {
			var n = 0;
			mapChildren(children, function() {
				n++;
			});
			return n;
		},
		toArray: function(children) {
			return mapChildren(children, function(child) {
				return child;
			}) || [];
		},
		only: function(children) {
			if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
			return children;
		}
	};
	exports.Activity = REACT_ACTIVITY_TYPE;
	exports.Children = Children;
	exports.Component = Component;
	exports.Fragment = REACT_FRAGMENT_TYPE;
	exports.Profiler = REACT_PROFILER_TYPE;
	exports.PureComponent = PureComponent;
	exports.StrictMode = REACT_STRICT_MODE_TYPE;
	exports.Suspense = REACT_SUSPENSE_TYPE;
	exports.ViewTransition = REACT_VIEW_TRANSITION_TYPE;
	exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
	exports.__COMPILER_RUNTIME = {
		__proto__: null,
		c: function(size) {
			return ReactSharedInternals.H.useMemoCache(size);
		}
	};
	exports.addTransitionType = addTransitionType;
	exports.cache = function(fn) {
		return function() {
			return fn.apply(null, arguments);
		};
	};
	exports.cacheSignal = function() {
		return null;
	};
	exports.cloneElement = function(element, config, children) {
		if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
		var props = assign({}, element.props), key = element.key;
		if (null != config) for (propName in void 0 !== config.key && (key = "" + config.key), config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
		var propName = arguments.length - 2;
		if (1 === propName) props.children = children;
		else if (1 < propName) {
			for (var childArray = Array(propName), i = 0; i < propName; i++) childArray[i] = arguments[i + 2];
			props.children = childArray;
		}
		return ReactElement(element.type, key, props);
	};
	exports.createContext = function(defaultValue) {
		defaultValue = {
			$$typeof: REACT_CONTEXT_TYPE,
			_currentValue: defaultValue,
			_currentValue2: defaultValue,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		};
		defaultValue.Provider = defaultValue;
		defaultValue.Consumer = {
			$$typeof: REACT_CONSUMER_TYPE,
			_context: defaultValue
		};
		return defaultValue;
	};
	exports.createElement = function(type, config, children) {
		var propName, props = {}, key = null;
		if (null != config) for (propName in void 0 !== config.key && (key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (props[propName] = config[propName]);
		var childrenLength = arguments.length - 2;
		if (1 === childrenLength) props.children = children;
		else if (1 < childrenLength) {
			for (var childArray = Array(childrenLength), i = 0; i < childrenLength; i++) childArray[i] = arguments[i + 2];
			props.children = childArray;
		}
		if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === props[propName] && (props[propName] = childrenLength[propName]);
		return ReactElement(type, key, props);
	};
	exports.createRef = function() {
		return { current: null };
	};
	exports.forwardRef = function(render) {
		return {
			$$typeof: REACT_FORWARD_REF_TYPE,
			render
		};
	};
	exports.isValidElement = isValidElement;
	exports.lazy = function(ctor) {
		return {
			$$typeof: REACT_LAZY_TYPE,
			_payload: {
				_status: -1,
				_result: ctor
			},
			_init: lazyInitializer
		};
	};
	exports.memo = function(type, compare) {
		return {
			$$typeof: REACT_MEMO_TYPE,
			type,
			compare: void 0 === compare ? null : compare
		};
	};
	exports.startTransition = startTransition;
	exports.unstable_useCacheRefresh = function() {
		return ReactSharedInternals.H.useCacheRefresh();
	};
	exports.use = function(usable) {
		return ReactSharedInternals.H.use(usable);
	};
	exports.useActionState = function(action, initialState, permalink) {
		return ReactSharedInternals.H.useActionState(action, initialState, permalink);
	};
	exports.useCallback = function(callback, deps) {
		return ReactSharedInternals.H.useCallback(callback, deps);
	};
	exports.useContext = function(Context) {
		return ReactSharedInternals.H.useContext(Context);
	};
	exports.useDebugValue = function() {};
	exports.useDeferredValue = function(value, initialValue) {
		return ReactSharedInternals.H.useDeferredValue(value, initialValue);
	};
	exports.useEffect = function(create, deps) {
		return ReactSharedInternals.H.useEffect(create, deps);
	};
	exports.useEffectEvent = function(callback) {
		return ReactSharedInternals.H.useEffectEvent(callback);
	};
	exports.useId = function() {
		return ReactSharedInternals.H.useId();
	};
	exports.useImperativeHandle = function(ref, create, deps) {
		return ReactSharedInternals.H.useImperativeHandle(ref, create, deps);
	};
	exports.useInsertionEffect = function(create, deps) {
		return ReactSharedInternals.H.useInsertionEffect(create, deps);
	};
	exports.useLayoutEffect = function(create, deps) {
		return ReactSharedInternals.H.useLayoutEffect(create, deps);
	};
	exports.useMemo = function(create, deps) {
		return ReactSharedInternals.H.useMemo(create, deps);
	};
	exports.useOptimistic = function(passthrough, reducer) {
		return ReactSharedInternals.H.useOptimistic(passthrough, reducer);
	};
	exports.useReducer = function(reducer, initialArg, init) {
		return ReactSharedInternals.H.useReducer(reducer, initialArg, init);
	};
	exports.useRef = function(initialValue) {
		return ReactSharedInternals.H.useRef(initialValue);
	};
	exports.useState = function(initialState) {
		return ReactSharedInternals.H.useState(initialState);
	};
	exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
		return ReactSharedInternals.H.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
	};
	exports.useTransition = function() {
		return ReactSharedInternals.H.useTransition();
	};
	exports.version = "19.3.1";
}));
// node_modules/react/index.js
var require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_production();
}));
// node_modules/react-dom/cjs/react-dom.production.js
/**
* @license React
* react-dom.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var React = require_react();
	function formatProdErrorMessage(code) {
		var url = "https://react.dev/errors/" + code;
		if (1 < arguments.length) {
			url += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var i = 2; i < arguments.length; i++) url += "&args[]=" + encodeURIComponent(arguments[i]);
		}
		return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	function noop() {}
	var Internals = {
		d: {
			f: noop,
			r: function() {
				throw Error(formatProdErrorMessage(522));
			},
			D: noop,
			C: noop,
			L: noop,
			m: noop,
			X: noop,
			S: noop,
			M: noop
		},
		p: 0,
		findDOMNode: null
	};
	var REACT_PORTAL_TYPE = Symbol.for("react.portal");
	var REACT_RECOVERABLE_TYPE = Symbol.for("react.recoverable");
	var REACT_OPTIMISTIC_KEY = Symbol.for("react.optimistic_key");
	function createPortal$1(children, containerInfo, implementation) {
		var key = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
		return {
			$$typeof: REACT_PORTAL_TYPE,
			key: null == key ? null : key === REACT_OPTIMISTIC_KEY ? REACT_OPTIMISTIC_KEY : "" + key,
			children,
			containerInfo,
			implementation
		};
	}
	var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
	function getCrossOriginStringAs(as, input) {
		if ("font" === as) return "";
		if ("string" === typeof input) return "use-credentials" === input ? input : "";
	}
	exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Internals;
	exports.browser = function(reason) {
		return {
			$$typeof: REACT_RECOVERABLE_TYPE,
			_reason: reason
		};
	};
	exports.createPortal = function(children, container) {
		var key = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
		if (!container || 1 !== container.nodeType && 9 !== container.nodeType && 11 !== container.nodeType) throw Error(formatProdErrorMessage(299));
		return createPortal$1(children, container, null, key);
	};
	exports.flushSync = function(fn) {
		var previousTransition = ReactSharedInternals.T, previousUpdatePriority = Internals.p;
		try {
			if (ReactSharedInternals.T = null, Internals.p = 2, fn) return fn();
		} finally {
			ReactSharedInternals.T = previousTransition, Internals.p = previousUpdatePriority, Internals.d.f();
		}
	};
	exports.preconnect = function(href, options) {
		"string" === typeof href && (options ? (options = options.crossOrigin, options = "string" === typeof options ? "use-credentials" === options ? options : "" : void 0) : options = null, Internals.d.C(href, options));
	};
	exports.prefetchDNS = function(href) {
		"string" === typeof href && Internals.d.D(href);
	};
	exports.preinit = function(href, options) {
		if ("string" === typeof href && options && "string" === typeof options.as) {
			var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin), integrity = "string" === typeof options.integrity ? options.integrity : void 0, fetchPriority = "string" === typeof options.fetchPriority ? options.fetchPriority : void 0;
			"style" === as ? Internals.d.S(href, "string" === typeof options.precedence ? options.precedence : void 0, {
				crossOrigin,
				integrity,
				fetchPriority
			}) : "script" === as && Internals.d.X(href, {
				crossOrigin,
				integrity,
				fetchPriority,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0
			});
		}
	};
	exports.preinitModule = function(href, options) {
		if ("string" === typeof href) if ("object" === typeof options && null !== options) {
			if (null == options.as || "script" === options.as) {
				var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
				Internals.d.M(href, {
					crossOrigin,
					integrity: "string" === typeof options.integrity ? options.integrity : void 0,
					nonce: "string" === typeof options.nonce ? options.nonce : void 0,
					fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0
				});
			}
		} else options ?? Internals.d.M(href);
	};
	exports.preload = function(href, options) {
		if ("string" === typeof href && "object" === typeof options && null !== options && "string" === typeof options.as) {
			var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
			Internals.d.L(href, as, {
				crossOrigin,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0,
				type: "string" === typeof options.type ? options.type : void 0,
				fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0,
				referrerPolicy: "string" === typeof options.referrerPolicy ? options.referrerPolicy : void 0,
				imageSrcSet: "string" === typeof options.imageSrcSet ? options.imageSrcSet : void 0,
				imageSizes: "string" === typeof options.imageSizes ? options.imageSizes : void 0,
				media: "string" === typeof options.media ? options.media : void 0
			});
		}
	};
	exports.preloadModule = function(href, options) {
		if ("string" === typeof href) if (options) {
			var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
			Internals.d.m(href, {
				as: "string" === typeof options.as && "script" !== options.as ? options.as : void 0,
				crossOrigin,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0,
				fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0
			});
		} else Internals.d.m(href);
	};
	exports.requestFormReset = function(form) {
		Internals.d.r(form);
	};
	exports.unstable_batchedUpdates = function(fn, a) {
		return fn(a);
	};
	exports.useFormState = function(action, initialState, permalink) {
		return ReactSharedInternals.H.useFormState(action, initialState, permalink);
	};
	exports.useFormStatus = function() {
		return ReactSharedInternals.H.useHostTransitionStatus();
	};
	exports.version = "19.3.1";
}));
// node_modules/react-dom/index.js
var require_react_dom = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function checkDCE() {
		if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") return;
		try {
			__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
		} catch (err) {
			console.error(err);
		}
	}
	checkDCE();
	module.exports = require_react_dom_production();
}));
// node_modules/react-dom/cjs/react-dom-client.production.js
/**
* @license React
* react-dom-client.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_client_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var Scheduler = require_scheduler();
	var React = require_react();
	var ReactDOM = require_react_dom();
	function formatProdErrorMessage(code) {
		var url = "https://react.dev/errors/" + code;
		if (1 < arguments.length) {
			url += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var i = 2; i < arguments.length; i++) url += "&args[]=" + encodeURIComponent(arguments[i]);
		}
		return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	function isValidContainer(node) {
		return !(!node || 1 !== node.nodeType && 9 !== node.nodeType && 11 !== node.nodeType);
	}
	function getNearestMountedFiber(fiber) {
		for (var node = fiber, nextNode = node; nextNode && !nextNode.alternate;) node = nextNode, 0 !== (node.flags & 4098) && (fiber = node.return), nextNode = node.return;
		for (; node.return;) node = node.return;
		return 3 === node.tag ? fiber : null;
	}
	function getSuspenseInstanceFromFiber(fiber) {
		if (13 === fiber.tag) {
			var suspenseState = fiber.memoizedState;
			null === suspenseState && (fiber = fiber.alternate, null !== fiber && (suspenseState = fiber.memoizedState));
			if (null !== suspenseState) return suspenseState.dehydrated;
		}
		return null;
	}
	function getActivityInstanceFromFiber(fiber) {
		if (31 === fiber.tag) {
			var activityState = fiber.memoizedState;
			null === activityState && (fiber = fiber.alternate, null !== fiber && (activityState = fiber.memoizedState));
			if (null !== activityState) return activityState.dehydrated;
		}
		return null;
	}
	function assertIsMounted(fiber) {
		if (getNearestMountedFiber(fiber) !== fiber) throw Error(formatProdErrorMessage(188));
	}
	function findCurrentFiberUsingSlowPath(fiber) {
		var alternate = fiber.alternate;
		if (!alternate) {
			alternate = getNearestMountedFiber(fiber);
			if (null === alternate) throw Error(formatProdErrorMessage(188));
			return alternate !== fiber ? null : fiber;
		}
		for (var a = fiber, b = alternate;;) {
			var parentA = a.return;
			if (null === parentA) break;
			var parentB = parentA.alternate;
			if (null === parentB) {
				b = parentA.return;
				if (null !== b) {
					a = b;
					continue;
				}
				break;
			}
			if (parentA.child === parentB.child) {
				for (parentB = parentA.child; parentB;) {
					if (parentB === a) return assertIsMounted(parentA), fiber;
					if (parentB === b) return assertIsMounted(parentA), alternate;
					parentB = parentB.sibling;
				}
				throw Error(formatProdErrorMessage(188));
			}
			if (a.return !== b.return) a = parentA, b = parentB;
			else {
				for (var didFindChild = !1, child$0 = parentA.child; child$0;) {
					if (child$0 === a) {
						didFindChild = !0;
						a = parentA;
						b = parentB;
						break;
					}
					if (child$0 === b) {
						didFindChild = !0;
						b = parentA;
						a = parentB;
						break;
					}
					child$0 = child$0.sibling;
				}
				if (!didFindChild) {
					for (child$0 = parentB.child; child$0;) {
						if (child$0 === a) {
							didFindChild = !0;
							a = parentB;
							b = parentA;
							break;
						}
						if (child$0 === b) {
							didFindChild = !0;
							b = parentB;
							a = parentA;
							break;
						}
						child$0 = child$0.sibling;
					}
					if (!didFindChild) throw Error(formatProdErrorMessage(189));
				}
			}
			if (a.alternate !== b) throw Error(formatProdErrorMessage(190));
		}
		if (3 !== a.tag) throw Error(formatProdErrorMessage(188));
		return a.stateNode.current === a ? fiber : alternate;
	}
	function findCurrentHostFiberImpl(node) {
		var tag = node.tag;
		if (5 === tag || 26 === tag || 27 === tag || 6 === tag) return node;
		for (node = node.child; null !== node;) {
			tag = findCurrentHostFiberImpl(node);
			if (null !== tag) return tag;
			node = node.sibling;
		}
		return null;
	}
	function traverseVisibleInstancesAndTextInstances(child, searchWithinHosts, fn, a, b, c) {
		for (; null !== child;) {
			if ((5 === child.tag || 27 === child.tag || 6 === child.tag) && fn(child, a, b, c) || (22 !== child.tag || null === child.memoizedState) && (searchWithinHosts || 5 !== child.tag && 27 !== child.tag) && traverseVisibleInstancesAndTextInstances(child.child, searchWithinHosts, fn, a, b, c)) return !0;
			child = child.sibling;
		}
		return !1;
	}
	function getFragmentParentInstanceOrContainerFiber(fiber) {
		for (fiber = fiber.return; null !== fiber;) {
			if (3 === fiber.tag || 5 === fiber.tag || 27 === fiber.tag) return fiber;
			fiber = fiber.return;
		}
		return null;
	}
	function fiberIsPortaledIntoHost(fiber) {
		var foundPortalParent = !1;
		for (fiber = fiber.return; null !== fiber;) {
			4 === fiber.tag && (foundPortalParent = !0);
			if (3 === fiber.tag || 5 === fiber.tag || 27 === fiber.tag) break;
			fiber = fiber.return;
		}
		return foundPortalParent;
	}
	function getFragmentInstanceOrTextInstanceSiblings(fiber) {
		var result = [null, null], parentHostFiber = getFragmentParentInstanceOrContainerFiber(fiber);
		if (null === parentHostFiber) return result;
		findFragmentInstanceOrTextInstanceSiblings(result, fiber, parentHostFiber.child, { foundSelf: !1 });
		return result;
	}
	function findFragmentInstanceOrTextInstanceSiblings(result, self, child, state) {
		for (; null !== child;) {
			if (child === self) state.foundSelf = !0;
			else if (5 === child.tag || 27 === child.tag || 6 === child.tag) {
				if (state.foundSelf) return result[1] = child, !0;
				result[0] = child;
			} else if ((22 !== child.tag || null === child.memoizedState) && findFragmentInstanceOrTextInstanceSiblings(result, self, child.child, state)) return !0;
			child = child.sibling;
		}
		return !1;
	}
	function getInstanceFromHostFiber(fiber) {
		switch (fiber.tag) {
			case 5:
			case 27:
			case 6: return fiber.stateNode;
			case 3: return fiber.stateNode.containerInfo;
			default: throw Error(formatProdErrorMessage(559));
		}
	}
	var searchTarget = null;
	var searchBoundary = null;
	function isFiberPrecedingCheck(child, target, boundary) {
		return child === boundary ? !0 : child === target ? (searchTarget = child, !0) : !1;
	}
	function isFiberFollowingCheck(child, target, boundary) {
		return child === boundary ? (searchBoundary = child, !1) : child === target ? (null !== searchBoundary && (searchTarget = child), !0) : !1;
	}
	function getParentForFragmentAncestors(inst) {
		if (null === inst) return null;
		do
			inst = null === inst ? null : inst.return;
		while (inst && 5 !== inst.tag && 27 !== inst.tag && 3 !== inst.tag);
		return inst ? inst : null;
	}
	function getLowestCommonAncestor(instA, instB, getParent) {
		for (var depthA = 0, tempA = instA; tempA; tempA = getParent(tempA)) depthA++;
		tempA = 0;
		for (var tempB = instB; tempB; tempB = getParent(tempB)) tempA++;
		for (; 0 < depthA - tempA;) instA = getParent(instA), depthA--;
		for (; 0 < tempA - depthA;) instB = getParent(instB), tempA--;
		for (; depthA--;) {
			if (instA === instB || null !== instB && instA === instB.alternate) return instA;
			instA = getParent(instA);
			instB = getParent(instB);
		}
		return null;
	}
	var assign = Object.assign;
	var REACT_LEGACY_ELEMENT_TYPE = Symbol.for("react.element");
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
	var REACT_PORTAL_TYPE = Symbol.for("react.portal");
	var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
	var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
	var REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
	var REACT_CONTEXT_TYPE = Symbol.for("react.context");
	var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
	var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
	var REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list");
	var REACT_MEMO_TYPE = Symbol.for("react.memo");
	var REACT_LAZY_TYPE = Symbol.for("react.lazy");
	var REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
	var REACT_LEGACY_HIDDEN_TYPE = Symbol.for("react.legacy_hidden");
	var REACT_MEMO_CACHE_SENTINEL = Symbol.for("react.memo_cache_sentinel");
	var REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition");
	var REACT_RECOVERABLE_TYPE = Symbol.for("react.recoverable");
	var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
	function getIteratorFn(maybeIterable) {
		if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
		maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
		return "function" === typeof maybeIterable ? maybeIterable : null;
	}
	var REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
	function getComponentNameFromType(type) {
		if (null == type) return null;
		if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
		if ("string" === typeof type) return type;
		switch (type) {
			case REACT_FRAGMENT_TYPE: return "Fragment";
			case REACT_PROFILER_TYPE: return "Profiler";
			case REACT_STRICT_MODE_TYPE: return "StrictMode";
			case REACT_SUSPENSE_TYPE: return "Suspense";
			case REACT_SUSPENSE_LIST_TYPE: return "SuspenseList";
			case REACT_ACTIVITY_TYPE: return "Activity";
			case REACT_VIEW_TRANSITION_TYPE: return "ViewTransition";
		}
		if ("object" === typeof type) switch (type.$$typeof) {
			case REACT_PORTAL_TYPE: return "Portal";
			case REACT_CONTEXT_TYPE: return type.displayName || "Context";
			case REACT_CONSUMER_TYPE: return (type._context.displayName || "Context") + ".Consumer";
			case REACT_FORWARD_REF_TYPE:
				var innerType = type.render;
				type = type.displayName;
				type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
				return type;
			case REACT_MEMO_TYPE: return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
			case REACT_LAZY_TYPE:
				innerType = type._payload;
				type = type._init;
				try {
					return getComponentNameFromType(type(innerType));
				} catch (x) {}
		}
		return null;
	}
	var isArrayImpl = Array.isArray;
	var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
	var ReactDOMSharedInternals = ReactDOM.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
	var sharedNotPendingObject = {
		pending: !1,
		data: null,
		method: null,
		action: null
	};
	var valueStack = [];
	var index = -1;
	function createCursor(defaultValue) {
		return { current: defaultValue };
	}
	function pop(cursor) {
		0 > index || (cursor.current = valueStack[index], valueStack[index] = null, index--);
	}
	function push(cursor, value) {
		index++;
		valueStack[index] = cursor.current;
		cursor.current = value;
	}
	var contextStackCursor = createCursor(null);
	var contextFiberStackCursor = createCursor(null);
	var rootInstanceStackCursor = createCursor(null);
	var hostTransitionProviderCursor = createCursor(null);
	function pushHostContainer(fiber, nextRootInstance) {
		push(rootInstanceStackCursor, nextRootInstance);
		push(contextFiberStackCursor, fiber);
		push(contextStackCursor, null);
		switch (nextRootInstance.nodeType) {
			case 9:
			case 11:
				fiber = (fiber = nextRootInstance.documentElement) ? (fiber = fiber.namespaceURI) ? getOwnHostContext(fiber) : 0 : 0;
				break;
			default: if (fiber = nextRootInstance.tagName, nextRootInstance = nextRootInstance.namespaceURI) nextRootInstance = getOwnHostContext(nextRootInstance), fiber = getChildHostContextProd(nextRootInstance, fiber);
			else switch (fiber) {
				case "svg":
					fiber = 1;
					break;
				case "math":
					fiber = 2;
					break;
				default: fiber = 0;
			}
		}
		pop(contextStackCursor);
		push(contextStackCursor, fiber);
	}
	function popHostContainer() {
		pop(contextStackCursor);
		pop(contextFiberStackCursor);
		pop(rootInstanceStackCursor);
	}
	function pushHostContext(fiber) {
		var stateHook = fiber.memoizedState;
		null !== stateHook && (HostTransitionContext._currentValue = stateHook.memoizedState, push(hostTransitionProviderCursor, fiber));
		stateHook = contextStackCursor.current;
		var JSCompiler_inline_result = getChildHostContextProd(stateHook, fiber.type);
		stateHook !== JSCompiler_inline_result && (push(contextFiberStackCursor, fiber), push(contextStackCursor, JSCompiler_inline_result));
	}
	function popHostContext(fiber) {
		contextFiberStackCursor.current === fiber && (pop(contextStackCursor), pop(contextFiberStackCursor));
		hostTransitionProviderCursor.current === fiber && (pop(hostTransitionProviderCursor), HostTransitionContext._currentValue = sharedNotPendingObject);
	}
	var prefix;
	var suffix;
	function describeBuiltInComponentFrame(name) {
		if (void 0 === prefix) try {
			throw Error();
		} catch (x) {
			var match = x.stack.trim().match(/\n( *(at )?)/);
			prefix = match && match[1] || "";
			suffix = -1 < x.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < x.stack.indexOf("@") ? "@unknown:0:0" : "";
		}
		return "\n" + prefix + name + suffix;
	}
	var reentry = !1;
	function describeNativeComponentFrame(fn, construct) {
		if (!fn || reentry) return "";
		reentry = !0;
		var previousPrepareStackTrace = Error.prepareStackTrace;
		Error.prepareStackTrace = void 0;
		try {
			var RunInRootFrame = { DetermineComponentFrameRoot: function() {
				try {
					if (construct) {
						var Fake = function() {
							throw Error();
						};
						Object.defineProperty(Fake.prototype, "props", { set: function() {
							throw Error();
						} });
						if ("object" === typeof Reflect && Reflect.construct) {
							try {
								Reflect.construct(Fake, []);
							} catch (x) {
								var control = x;
							}
							Reflect.construct(fn, [], Fake);
						} else {
							try {
								Fake.call();
							} catch (x$1) {
								control = x$1;
							}
							Fake = !1;
							try {
								var prevProps = Object.getOwnPropertyDescriptor(fn.prototype, "props");
								Object.defineProperty(fn.prototype, "props", {
									configurable: !0,
									set: function() {
										throw Error();
									}
								});
								Fake = !0;
								new fn();
							} finally {
								Fake && (void 0 !== prevProps ? Object.defineProperty(fn.prototype, "props", prevProps) : delete fn.prototype.props);
							}
						}
					} else {
						try {
							throw Error();
						} catch (x$2) {
							control = x$2;
						}
						(Fake = fn()) && "function" === typeof Fake.catch && Fake.catch(function() {});
					}
				} catch (sample) {
					if (sample && control && "string" === typeof sample.stack) return [sample.stack, control.stack];
				}
				return [null, null];
			} };
			RunInRootFrame.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var namePropDescriptor = Object.getOwnPropertyDescriptor(RunInRootFrame.DetermineComponentFrameRoot, "name");
			namePropDescriptor && namePropDescriptor.configurable && Object.defineProperty(RunInRootFrame.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
			var _RunInRootFrame$Deter = RunInRootFrame.DetermineComponentFrameRoot(), sampleStack = _RunInRootFrame$Deter[0], controlStack = _RunInRootFrame$Deter[1];
			if (sampleStack && controlStack) {
				var sampleLines = sampleStack.split("\n"), controlLines = controlStack.split("\n");
				for (namePropDescriptor = RunInRootFrame = 0; RunInRootFrame < sampleLines.length && !sampleLines[RunInRootFrame].includes("DetermineComponentFrameRoot");) RunInRootFrame++;
				for (; namePropDescriptor < controlLines.length && !controlLines[namePropDescriptor].includes("DetermineComponentFrameRoot");) namePropDescriptor++;
				if (RunInRootFrame === sampleLines.length || namePropDescriptor === controlLines.length) for (RunInRootFrame = sampleLines.length - 1, namePropDescriptor = controlLines.length - 1; 1 <= RunInRootFrame && 0 <= namePropDescriptor && sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor];) namePropDescriptor--;
				for (; 1 <= RunInRootFrame && 0 <= namePropDescriptor; RunInRootFrame--, namePropDescriptor--) if (sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
					if (1 !== RunInRootFrame || 1 !== namePropDescriptor) do
						if (RunInRootFrame--, namePropDescriptor--, 0 > namePropDescriptor || sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
							var frame = "\n" + sampleLines[RunInRootFrame].replace(" at new ", " at ");
							fn.displayName && frame.includes("<anonymous>") && (frame = frame.replace("<anonymous>", fn.displayName));
							return frame;
						}
					while (1 <= RunInRootFrame && 0 <= namePropDescriptor);
					break;
				}
			}
		} finally {
			reentry = !1, Error.prepareStackTrace = previousPrepareStackTrace;
		}
		return (previousPrepareStackTrace = fn ? fn.displayName || fn.name : "") ? describeBuiltInComponentFrame(previousPrepareStackTrace) : "";
	}
	function describeFiber(fiber, childFiber) {
		switch (fiber.tag) {
			case 26:
			case 27:
			case 5: return describeBuiltInComponentFrame(fiber.type);
			case 16: return describeBuiltInComponentFrame("Lazy");
			case 13: return fiber.child !== childFiber && null !== childFiber ? describeBuiltInComponentFrame("Suspense Fallback") : describeBuiltInComponentFrame("Suspense");
			case 19: return describeBuiltInComponentFrame("SuspenseList");
			case 0:
			case 15: return describeNativeComponentFrame(fiber.type, !1);
			case 11: return describeNativeComponentFrame(fiber.type.render, !1);
			case 1: return describeNativeComponentFrame(fiber.type, !0);
			case 31: return describeBuiltInComponentFrame("Activity");
			case 30: return describeBuiltInComponentFrame("ViewTransition");
			default: return "";
		}
	}
	function getStackByFiberInDevAndProd(workInProgress) {
		try {
			var info = "", previous = null;
			do
				info += describeFiber(workInProgress, previous), previous = workInProgress, workInProgress = workInProgress.return;
			while (workInProgress);
			return info;
		} catch (x) {
			return "\nError generating stack: " + x.message + "\n" + x.stack;
		}
	}
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	var scheduleCallback$3 = Scheduler.unstable_scheduleCallback;
	var cancelCallback$1 = Scheduler.unstable_cancelCallback;
	var shouldYield = Scheduler.unstable_shouldYield;
	var requestPaint = Scheduler.unstable_requestPaint;
	var now = Scheduler.unstable_now;
	var getCurrentPriorityLevel = Scheduler.unstable_getCurrentPriorityLevel;
	var ImmediatePriority = Scheduler.unstable_ImmediatePriority;
	var UserBlockingPriority = Scheduler.unstable_UserBlockingPriority;
	var NormalPriority$1 = Scheduler.unstable_NormalPriority;
	var LowPriority = Scheduler.unstable_LowPriority;
	var IdlePriority = Scheduler.unstable_IdlePriority;
	var log$1 = Scheduler.log;
	var unstable_setDisableYieldValue = Scheduler.unstable_setDisableYieldValue;
	var rendererID = null;
	var injectedHook = null;
	function setIsStrictModeForDevtools(newIsStrictMode) {
		"function" === typeof log$1 && unstable_setDisableYieldValue(newIsStrictMode);
		if (injectedHook && "function" === typeof injectedHook.setStrictMode) try {
			injectedHook.setStrictMode(rendererID, newIsStrictMode);
		} catch (err) {}
	}
	var clz32 = Math.clz32 ? Math.clz32 : clz32Fallback;
	var log = Math.log;
	var LN2 = Math.LN2;
	function clz32Fallback(x) {
		x >>>= 0;
		return 0 === x ? 32 : 31 - (log(x) / LN2 | 0) | 0;
	}
	var nextTransitionUpdateLane = 256;
	var nextTransitionDeferredLane = 262144;
	var nextRetryLane = 4194304;
	function getHighestPriorityLanes(lanes) {
		var pendingSyncLanes = lanes & 42;
		if (0 !== pendingSyncLanes) return pendingSyncLanes;
		switch (lanes & -lanes) {
			case 1: return 1;
			case 2: return 2;
			case 4: return 4;
			case 8: return 8;
			case 16: return 16;
			case 32: return 32;
			case 64: return 64;
			case 128: return 128;
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072: return lanes & -lanes;
			case 262144:
			case 524288:
			case 1048576:
			case 2097152: return lanes & 3932160;
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432: return lanes & 62914560;
			case 67108864: return 67108864;
			case 134217728: return 134217728;
			case 268435456: return 268435456;
			case 536870912: return 536870912;
			case 1073741824: return 0;
			default: return lanes;
		}
	}
	function getNextLanes(root, wipLanes, rootHasPendingCommit) {
		var pendingLanes = root.pendingLanes;
		if (0 === pendingLanes) return 0;
		var nextLanes = 0, suspendedLanes = root.suspendedLanes, pingedLanes = root.pingedLanes;
		root = root.warmLanes;
		var nonIdlePendingLanes = pendingLanes & 134217727;
		0 !== nonIdlePendingLanes ? (pendingLanes = nonIdlePendingLanes & ~suspendedLanes, 0 !== pendingLanes ? nextLanes = getHighestPriorityLanes(pendingLanes) : (pingedLanes &= nonIdlePendingLanes, 0 !== pingedLanes ? nextLanes = getHighestPriorityLanes(pingedLanes) : rootHasPendingCommit || (rootHasPendingCommit = nonIdlePendingLanes & ~root, 0 !== rootHasPendingCommit && (nextLanes = getHighestPriorityLanes(rootHasPendingCommit))))) : (nonIdlePendingLanes = pendingLanes & ~suspendedLanes, 0 !== nonIdlePendingLanes ? nextLanes = getHighestPriorityLanes(nonIdlePendingLanes) : 0 !== pingedLanes ? nextLanes = getHighestPriorityLanes(pingedLanes) : rootHasPendingCommit || (rootHasPendingCommit = pendingLanes & ~root, 0 !== rootHasPendingCommit && (nextLanes = getHighestPriorityLanes(rootHasPendingCommit))));
		return 0 === nextLanes ? 0 : 0 !== wipLanes && wipLanes !== nextLanes && 0 === (wipLanes & suspendedLanes) && (suspendedLanes = nextLanes & -nextLanes, rootHasPendingCommit = wipLanes & -wipLanes, suspendedLanes >= rootHasPendingCommit || 32 === suspendedLanes && 0 !== (rootHasPendingCommit & 4194048)) ? wipLanes : nextLanes;
	}
	function checkIfRootIsPrerendering(root, renderLanes) {
		return 0 === (root.pendingLanes & ~(root.suspendedLanes & ~root.pingedLanes) & renderLanes);
	}
	function getEntangledLanes(root, renderLanes) {
		0 !== (renderLanes & 8) && (renderLanes |= renderLanes & 32);
		var allEntangledLanes = root.entangledLanes;
		if (0 !== allEntangledLanes) for (root = root.entanglements, allEntangledLanes &= renderLanes; 0 < allEntangledLanes;) {
			var index$4 = 31 - clz32(allEntangledLanes), lane = 1 << index$4;
			renderLanes |= root[index$4];
			allEntangledLanes &= ~lane;
		}
		return renderLanes;
	}
	function computeExpirationTime(lane, currentTime) {
		switch (lane) {
			case 1:
			case 2:
			case 4:
			case 8:
			case 64: return currentTime + 250;
			case 16:
			case 32:
			case 128:
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
			case 262144:
			case 524288:
			case 1048576:
			case 2097152: return currentTime + 5e3;
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432: return -1;
			case 67108864:
			case 134217728:
			case 268435456:
			case 536870912:
			case 1073741824: return -1;
			default: return -1;
		}
	}
	function claimNextRetryLane() {
		var lane = nextRetryLane;
		nextRetryLane <<= 1;
		0 === (nextRetryLane & 62914560) && (nextRetryLane = 4194304);
		return lane;
	}
	function createLaneMap(initial) {
		for (var laneMap = [], i = 0; 31 > i; i++) laneMap.push(initial);
		return laneMap;
	}
	function markRootUpdated$1(root, updateLane) {
		root.pendingLanes |= updateLane;
		268435456 !== updateLane && (root.suspendedLanes = 0, root.pingedLanes = 0, root.warmLanes = 0);
	}
	function markRootFinished(root, finishedLanes, remainingLanes, spawnedLane, updatedLanes, suspendedRetryLanes) {
		var previouslyPendingLanes = root.pendingLanes;
		root.pendingLanes = remainingLanes;
		root.suspendedLanes = 0;
		root.pingedLanes = 0;
		root.warmLanes = 0;
		root.expiredLanes &= remainingLanes;
		root.entangledLanes &= remainingLanes;
		root.errorRecoveryDisabledLanes &= remainingLanes;
		root.shellSuspendCounter = 0;
		var entanglements = root.entanglements, expirationTimes = root.expirationTimes, hiddenUpdates = root.hiddenUpdates;
		for (remainingLanes = previouslyPendingLanes & ~remainingLanes; 0 < remainingLanes;) {
			var index$7 = 31 - clz32(remainingLanes), lane = 1 << index$7;
			entanglements[index$7] = 0;
			expirationTimes[index$7] = -1;
			var hiddenUpdatesForLane = hiddenUpdates[index$7];
			if (null !== hiddenUpdatesForLane) for (hiddenUpdates[index$7] = null, index$7 = 0; index$7 < hiddenUpdatesForLane.length; index$7++) {
				var update = hiddenUpdatesForLane[index$7];
				null !== update && (update.lane &= -536870913);
			}
			remainingLanes &= ~lane;
		}
		0 !== spawnedLane && markSpawnedDeferredLane(root, spawnedLane, 0);
		0 !== suspendedRetryLanes && 0 === updatedLanes && 0 !== root.tag && (root.suspendedLanes |= suspendedRetryLanes & ~(previouslyPendingLanes & ~finishedLanes));
	}
	function markSpawnedDeferredLane(root, spawnedLane, entangledLanes) {
		root.pendingLanes |= spawnedLane;
		root.suspendedLanes &= ~spawnedLane;
		var spawnedLaneIndex = 31 - clz32(spawnedLane);
		root.entangledLanes |= spawnedLane;
		root.entanglements[spawnedLaneIndex] = root.entanglements[spawnedLaneIndex] | 1073741824 | entangledLanes & 261930;
	}
	function markRootEntangled(root, entangledLanes) {
		var rootEntangledLanes = root.entangledLanes |= entangledLanes;
		for (root = root.entanglements; rootEntangledLanes;) {
			var index$8 = 31 - clz32(rootEntangledLanes), lane = 1 << index$8;
			lane & entangledLanes | root[index$8] & entangledLanes && (root[index$8] |= entangledLanes);
			rootEntangledLanes &= ~lane;
		}
	}
	function getBumpedLaneForHydration(root, renderLanes) {
		var renderLane = renderLanes & -renderLanes;
		renderLane = 0 !== (renderLane & 42) ? 1 : getBumpedLaneForHydrationByLane(renderLane);
		return 0 !== (renderLane & (root.suspendedLanes | renderLanes)) ? 0 : renderLane;
	}
	function getBumpedLaneForHydrationByLane(lane) {
		switch (lane) {
			case 2:
				lane = 1;
				break;
			case 8:
				lane = 4;
				break;
			case 32:
				lane = 16;
				break;
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
			case 262144:
			case 524288:
			case 1048576:
			case 2097152:
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432:
				lane = 128;
				break;
			case 268435456:
				lane = 134217728;
				break;
			default: lane = 0;
		}
		return lane;
	}
	function lanesToEventPriority(lanes) {
		lanes &= -lanes;
		return 2 < lanes ? 8 < lanes ? 0 !== (lanes & 134217727) ? 32 : 268435456 : 8 : 2;
	}
	function resolveUpdatePriority() {
		var updatePriority = ReactDOMSharedInternals.p;
		if (0 !== updatePriority) return updatePriority;
		updatePriority = window.event;
		return void 0 === updatePriority ? 32 : getEventPriority(updatePriority.type);
	}
	function runWithPriority(priority, fn) {
		var previousPriority = ReactDOMSharedInternals.p;
		try {
			return ReactDOMSharedInternals.p = priority, fn();
		} finally {
			ReactDOMSharedInternals.p = previousPriority;
		}
	}
	var randomKey = Math.random().toString(36).slice(2);
	var internalInstanceKey = "__reactFiber$" + randomKey;
	var internalPropsKey = "__reactProps$" + randomKey;
	var internalContainerInstanceKey = "__reactContainer$" + randomKey;
	var internalEventHandlersKey = "__reactEvents$" + randomKey;
	var internalEventHandlerListenersKey = "__reactListeners$" + randomKey;
	var internalEventHandlesSetKey = "__reactHandles$" + randomKey;
	var internalRootNodeResourcesKey = "__reactResources$" + randomKey;
	var internalHoistableMarker = "__reactMarker$" + randomKey;
	var internalLoadPendingKey = "__reactLoad$" + randomKey;
	function detachDeletedInstance(node) {
		delete node[internalInstanceKey];
		delete node[internalPropsKey];
		delete node[internalEventHandlerListenersKey];
		delete node[internalEventHandlesSetKey];
	}
	function getClosestInstanceFromNode(targetNode) {
		var targetInst;
		if (targetInst = targetNode[internalInstanceKey]) return targetInst;
		for (var parentNode = targetNode.parentNode; parentNode;) {
			if (targetInst = parentNode[internalContainerInstanceKey] || parentNode[internalInstanceKey]) {
				parentNode = targetInst.alternate;
				if (null !== targetInst.child || null !== parentNode && null !== parentNode.child) for (targetNode = getParentHydrationBoundary(targetNode); null !== targetNode;) {
					if (parentNode = targetNode[internalInstanceKey]) return parentNode;
					targetNode = getParentHydrationBoundary(targetNode);
				}
				return targetInst;
			}
			targetNode = parentNode;
			parentNode = targetNode.parentNode;
		}
		return null;
	}
	function getInstanceFromNode(node) {
		if (node = node[internalInstanceKey] || node[internalContainerInstanceKey]) {
			var tag = node.tag;
			if (5 === tag || 6 === tag || 13 === tag || 31 === tag || 26 === tag || 27 === tag || 3 === tag) return node;
		}
		return null;
	}
	function getNodeFromInstance(inst) {
		var tag = inst.tag;
		if (5 === tag || 26 === tag || 27 === tag || 6 === tag) return inst.stateNode;
		throw Error(formatProdErrorMessage(33));
	}
	function getResourcesFromRoot(root) {
		var resources = root[internalRootNodeResourcesKey];
		resources || (resources = root[internalRootNodeResourcesKey] = {
			hoistableStyles: /* @__PURE__ */ new Map(),
			hoistableScripts: /* @__PURE__ */ new Map()
		});
		return resources;
	}
	function markNodeAsHoistable(node) {
		node[internalHoistableMarker] = !0;
	}
	function clearPendingLoadOnNode(node) {
		node[internalLoadPendingKey] = void 0;
	}
	var allNativeEvents = /* @__PURE__ */ new Set();
	var registrationNameDependencies = {};
	function registerTwoPhaseEvent(registrationName, dependencies) {
		registerDirectEvent(registrationName, dependencies);
		registerDirectEvent(registrationName + "Capture", dependencies);
	}
	function registerDirectEvent(registrationName, dependencies) {
		registrationNameDependencies[registrationName] = dependencies;
		for (registrationName = 0; registrationName < dependencies.length; registrationName++) allNativeEvents.add(dependencies[registrationName]);
	}
	var VALID_ATTRIBUTE_NAME_REGEX = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$");
	var illegalAttributeNameCache = {};
	var validatedAttributeNameCache = {};
	function isAttributeNameSafe(attributeName) {
		if (hasOwnProperty.call(validatedAttributeNameCache, attributeName)) return !0;
		if (hasOwnProperty.call(illegalAttributeNameCache, attributeName)) return !1;
		if (VALID_ATTRIBUTE_NAME_REGEX.test(attributeName)) return validatedAttributeNameCache[attributeName] = !0;
		illegalAttributeNameCache[attributeName] = !0;
		return !1;
	}
	var viewTransitionMutationContext = !1;
	function pushMutationContext() {
		var prev = viewTransitionMutationContext;
		viewTransitionMutationContext = !1;
		return prev;
	}
	function setValueForAttribute(node, name, value) {
		if (isAttributeNameSafe(name)) if (null === value) node.removeAttribute(name);
		else {
			switch (typeof value) {
				case "undefined":
				case "function":
				case "symbol":
					node.removeAttribute(name);
					return;
				case "boolean":
					var prefix$10 = name.toLowerCase().slice(0, 5);
					if ("data-" !== prefix$10 && "aria-" !== prefix$10) {
						node.removeAttribute(name);
						return;
					}
			}
			node.setAttribute(name, value);
		}
	}
	function setValueForKnownAttribute(node, name, value) {
		if (null === value) node.removeAttribute(name);
		else {
			switch (typeof value) {
				case "undefined":
				case "function":
				case "symbol":
				case "boolean":
					node.removeAttribute(name);
					return;
			}
			node.setAttribute(name, value);
		}
	}
	function setValueForNamespacedAttribute(node, namespace, name, value) {
		if (null === value) node.removeAttribute(name);
		else {
			switch (typeof value) {
				case "undefined":
				case "function":
				case "symbol":
				case "boolean":
					node.removeAttribute(name);
					return;
			}
			node.setAttributeNS(namespace, name, value);
		}
	}
	function getToStringValue(value) {
		switch (typeof value) {
			case "bigint":
			case "boolean":
			case "number":
			case "string":
			case "undefined": return value;
			case "object": return value;
			default: return "";
		}
	}
	function isCheckable(elem) {
		var type = elem.type;
		return (elem = elem.nodeName) && "input" === elem.toLowerCase() && ("checkbox" === type || "radio" === type);
	}
	function trackValueOnNode(node, valueField, currentValue) {
		var descriptor = Object.getOwnPropertyDescriptor(node.constructor.prototype, valueField);
		if (!node.hasOwnProperty(valueField) && "undefined" !== typeof descriptor && "function" === typeof descriptor.get && "function" === typeof descriptor.set) {
			var get = descriptor.get, set = descriptor.set;
			Object.defineProperty(node, valueField, {
				configurable: !0,
				get: function() {
					return get.call(this);
				},
				set: function(value) {
					currentValue = "" + value;
					set.call(this, value);
				}
			});
			Object.defineProperty(node, valueField, { enumerable: descriptor.enumerable });
			return {
				getValue: function() {
					return currentValue;
				},
				setValue: function(value) {
					currentValue = "" + value;
				},
				stopTracking: function() {
					node._valueTracker = null;
					delete node[valueField];
				}
			};
		}
	}
	function track(node) {
		if (!node._valueTracker) {
			var valueField = isCheckable(node) ? "checked" : "value";
			node._valueTracker = trackValueOnNode(node, valueField, "" + node[valueField]);
		}
	}
	function updateValueIfChanged(node) {
		if (!node) return !1;
		var tracker = node._valueTracker;
		if (!tracker) return !0;
		var lastValue = tracker.getValue();
		var value = "";
		node && (value = isCheckable(node) ? node.checked ? "true" : "false" : node.value);
		node = value;
		return node !== lastValue ? (tracker.setValue(node), !0) : !1;
	}
	var escapeSelectorAttributeValueInsideDoubleQuotesRegex = /[\n"\\]/g;
	function escapeSelectorAttributeValueInsideDoubleQuotes(value) {
		return value.replace(escapeSelectorAttributeValueInsideDoubleQuotesRegex, function(ch) {
			return "\\" + ch.charCodeAt(0).toString(16) + " ";
		});
	}
	function updateInput(element, value, defaultValue, lastDefaultValue, checked, defaultChecked, type, name) {
		element.name = "";
		null != type && "function" !== typeof type && "symbol" !== typeof type && "boolean" !== typeof type ? element.type = type : element.removeAttribute("type");
		if (null != value) if ("number" === type) {
			if (0 === value && "" === element.value || element.value != value) element.value = "" + getToStringValue(value);
		} else element.value !== "" + getToStringValue(value) && (element.value = "" + getToStringValue(value));
		else "submit" !== type && "reset" !== type || element.removeAttribute("value");
		null != value ? "number" === type && element.value == value ? setDefaultValue(element, getToStringValue(element.value)) : setDefaultValue(element, getToStringValue(value)) : null != defaultValue ? setDefaultValue(element, getToStringValue(defaultValue)) : null != lastDefaultValue && element.removeAttribute("value");
		null == checked && null != defaultChecked && (element.defaultChecked = !!defaultChecked);
		null != checked && (element.checked = checked && "function" !== typeof checked && "symbol" !== typeof checked);
		null != name && "function" !== typeof name && "symbol" !== typeof name && "boolean" !== typeof name ? element.name = "" + getToStringValue(name) : element.removeAttribute("name");
	}
	function initInput(element, value, defaultValue, checked, defaultChecked, type, name, isHydrating) {
		null != type && "function" !== typeof type && "symbol" !== typeof type && "boolean" !== typeof type && (element.type = type);
		if (null != value || null != defaultValue) {
			if (!("submit" !== type && "reset" !== type || void 0 !== value && null !== value)) {
				track(element);
				return;
			}
			defaultValue = null != defaultValue ? "" + getToStringValue(defaultValue) : "";
			value = null != value ? "" + getToStringValue(value) : defaultValue;
			isHydrating || value === element.value || (element.value = value);
			element.defaultValue = value;
		}
		checked = null != checked ? checked : defaultChecked;
		checked = "function" !== typeof checked && "symbol" !== typeof checked && !!checked;
		element.checked = isHydrating ? element.checked : !!checked;
		element.defaultChecked = !!checked;
		null != name && "function" !== typeof name && "symbol" !== typeof name && "boolean" !== typeof name && (element.name = name);
		track(element);
	}
	function setDefaultValue(node, value) {
		node.defaultValue !== "" + value && (node.defaultValue = "" + value);
	}
	function updateOptions(node, multiple, propValue, setDefaultSelected) {
		node = node.options;
		if (multiple) {
			multiple = {};
			for (var i = 0; i < propValue.length; i++) multiple["$" + propValue[i]] = !0;
			for (propValue = 0; propValue < node.length; propValue++) i = multiple.hasOwnProperty("$" + node[propValue].value), node[propValue].selected !== i && (node[propValue].selected = i), i && setDefaultSelected && (node[propValue].defaultSelected = !0);
		} else {
			propValue = "" + getToStringValue(propValue);
			multiple = null;
			for (i = 0; i < node.length; i++) {
				if (node[i].value === propValue) {
					node[i].selected = !0;
					setDefaultSelected && (node[i].defaultSelected = !0);
					return;
				}
				null !== multiple || node[i].disabled || (multiple = node[i]);
			}
			null !== multiple && (multiple.selected = !0);
		}
	}
	function updateTextarea(element, value, defaultValue) {
		if (null != value && (value = "" + getToStringValue(value), value !== element.value && (element.value = value), null == defaultValue)) {
			element.defaultValue !== value && (element.defaultValue = value);
			return;
		}
		element.defaultValue = null != defaultValue ? "" + getToStringValue(defaultValue) : "";
	}
	function initTextarea(element, value, defaultValue, children) {
		if (null == value) {
			if (null != children) {
				if (null != defaultValue) throw Error(formatProdErrorMessage(92));
				if (isArrayImpl(children)) {
					if (1 < children.length) throw Error(formatProdErrorMessage(93));
					children = children[0];
				}
				defaultValue = children;
			}
			defaultValue ??= "";
			value = defaultValue;
		}
		defaultValue = getToStringValue(value);
		element.defaultValue = defaultValue;
		children = element.textContent;
		children === defaultValue && "" !== children && null !== children && (element.value = children);
		track(element);
	}
	function setTextContent(node, text) {
		if (text) {
			var firstChild = node.firstChild;
			if (firstChild && firstChild === node.lastChild && 3 === firstChild.nodeType) {
				firstChild.nodeValue = text;
				return;
			}
		}
		node.textContent = text;
	}
	var unitlessNumbers = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
	function setValueForStyle(style, styleName, value) {
		var isCustomProperty = 0 === styleName.indexOf("--");
		null == value || "boolean" === typeof value || "" === value ? isCustomProperty ? style.setProperty(styleName, "") : "float" === styleName ? style.cssFloat = "" : style[styleName] = "" : isCustomProperty ? style.setProperty(styleName, value) : "number" !== typeof value || 0 === value || unitlessNumbers.has(styleName) ? "float" === styleName ? style.cssFloat = value : style[styleName] = ("" + value).trim() : style[styleName] = value + "px";
	}
	function setValueForStyles(node, styles, prevStyles) {
		if (null != styles && "object" !== typeof styles) throw Error(formatProdErrorMessage(62));
		node = node.style;
		if (null != prevStyles) {
			for (var styleName in prevStyles) !prevStyles.hasOwnProperty(styleName) || null != styles && styles.hasOwnProperty(styleName) || (0 === styleName.indexOf("--") ? node.setProperty(styleName, "") : "float" === styleName ? node.cssFloat = "" : node[styleName] = "", viewTransitionMutationContext = !0);
			for (var styleName$16 in styles) styleName = styles[styleName$16], styles.hasOwnProperty(styleName$16) && prevStyles[styleName$16] !== styleName && (setValueForStyle(node, styleName$16, styleName), viewTransitionMutationContext = !0);
		} else for (var styleName$17 in styles) styles.hasOwnProperty(styleName$17) && setValueForStyle(node, styleName$17, styles[styleName$17]);
	}
	function isCustomElement(tagName) {
		if (-1 === tagName.indexOf("-")) return !1;
		switch (tagName) {
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph": return !1;
			default: return !0;
		}
	}
	var aliases = /* @__PURE__ */ new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["maskType", "mask-type"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]);
	var isJavaScriptProtocol = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
	function sanitizeURL(url) {
		return isJavaScriptProtocol.test("" + url) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : url;
	}
	function noop$1() {}
	var currentReplayingEvent = null;
	function getEventTarget(nativeEvent) {
		nativeEvent = nativeEvent.target || nativeEvent.srcElement || window;
		nativeEvent.correspondingUseElement && (nativeEvent = nativeEvent.correspondingUseElement);
		return 3 === nativeEvent.nodeType ? nativeEvent.parentNode : nativeEvent;
	}
	var restoreTarget = null;
	var restoreQueue = null;
	function restoreStateOfTarget(target) {
		var internalInstance = getInstanceFromNode(target);
		if (internalInstance && (target = internalInstance.stateNode)) {
			var props = target[internalPropsKey] || null;
			a: switch (target = internalInstance.stateNode, internalInstance.type) {
				case "input":
					updateInput(target, props.value, props.defaultValue, props.defaultValue, props.checked, props.defaultChecked, props.type, props.name);
					internalInstance = props.name;
					if ("radio" === props.type && null != internalInstance) {
						for (props = target; props.parentNode;) props = props.parentNode;
						props = props.querySelectorAll("input[name=\"" + escapeSelectorAttributeValueInsideDoubleQuotes("" + internalInstance) + "\"][type=\"radio\"]");
						for (internalInstance = 0; internalInstance < props.length; internalInstance++) {
							var otherNode = props[internalInstance];
							if (otherNode !== target && otherNode.form === target.form) {
								var otherProps = otherNode[internalPropsKey] || null;
								if (!otherProps) throw Error(formatProdErrorMessage(90));
								updateInput(otherNode, otherProps.value, otherProps.defaultValue, otherProps.defaultValue, otherProps.checked, otherProps.defaultChecked, otherProps.type, otherProps.name);
							}
						}
						for (internalInstance = 0; internalInstance < props.length; internalInstance++) otherNode = props[internalInstance], otherNode.form === target.form && updateValueIfChanged(otherNode);
					}
					break a;
				case "textarea":
					updateTextarea(target, props.value, props.defaultValue);
					break a;
				case "select": internalInstance = props.value, null != internalInstance && updateOptions(target, !!props.multiple, internalInstance, !1);
			}
		}
	}
	var isInsideEventHandler = !1;
	function batchedUpdates$1(fn, a, b) {
		if (isInsideEventHandler) return fn(a, b);
		isInsideEventHandler = !0;
		try {
			return fn(a);
		} finally {
			if (isInsideEventHandler = !1, null !== restoreTarget || null !== restoreQueue) {
				if (flushSyncWork$1(), restoreTarget && (a = restoreTarget, fn = restoreQueue, restoreQueue = restoreTarget = null, restoreStateOfTarget(a), fn)) for (a = 0; a < fn.length; a++) restoreStateOfTarget(fn[a]);
			}
		}
	}
	function getListener(inst, registrationName) {
		var stateNode = inst.stateNode;
		if (null === stateNode) return null;
		var props = stateNode[internalPropsKey] || null;
		if (null === props) return null;
		stateNode = props[registrationName];
		a: switch (registrationName) {
			case "onClick":
			case "onClickCapture":
			case "onDoubleClick":
			case "onDoubleClickCapture":
			case "onMouseDown":
			case "onMouseDownCapture":
			case "onMouseMove":
			case "onMouseMoveCapture":
			case "onMouseUp":
			case "onMouseUpCapture":
			case "onMouseEnter":
				(props = !props.disabled) || (inst = inst.type, props = !("button" === inst || "input" === inst || "select" === inst || "textarea" === inst));
				inst = !props;
				break a;
			default: inst = !1;
		}
		if (inst) return null;
		if (stateNode && "function" !== typeof stateNode) throw Error(formatProdErrorMessage(231, registrationName, typeof stateNode));
		return stateNode;
	}
	var canUseDOM = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement);
	var passiveBrowserEventsSupported = !1;
	if (canUseDOM) try {
		var options = {};
		Object.defineProperty(options, "passive", { get: function() {
			passiveBrowserEventsSupported = !0;
		} });
		window.addEventListener("test", options, options);
		window.removeEventListener("test", options, options);
	} catch (e) {
		passiveBrowserEventsSupported = !1;
	}
	var root = null;
	var startText = null;
	var fallbackText = null;
	function getData() {
		if (fallbackText) return fallbackText;
		var start, startValue = startText, startLength = startValue.length, end, endValue = "value" in root ? root.value : root.textContent, endLength = endValue.length;
		for (start = 0; start < startLength && startValue[start] === endValue[start]; start++);
		var minEnd = startLength - start;
		for (end = 1; end <= minEnd && startValue[startLength - end] === endValue[endLength - end]; end++);
		return fallbackText = endValue.slice(start, 1 < end ? 1 - end : void 0);
	}
	function getEventCharCode(nativeEvent) {
		var keyCode = nativeEvent.keyCode;
		"charCode" in nativeEvent ? (nativeEvent = nativeEvent.charCode, 0 === nativeEvent && 13 === keyCode && (nativeEvent = 13)) : nativeEvent = keyCode;
		10 === nativeEvent && (nativeEvent = 13);
		return 32 <= nativeEvent || 13 === nativeEvent ? nativeEvent : 0;
	}
	function functionThatReturnsTrue() {
		return !0;
	}
	function functionThatReturnsFalse() {
		return !1;
	}
	function createSyntheticEvent(Interface) {
		function SyntheticBaseEvent(reactName, reactEventType, targetInst, nativeEvent, nativeEventTarget) {
			this._reactName = reactName;
			this._targetInst = targetInst;
			this.type = reactEventType;
			this.nativeEvent = nativeEvent;
			this.target = nativeEventTarget;
			this.currentTarget = null;
			for (var propName in Interface) Interface.hasOwnProperty(propName) && (reactName = Interface[propName], this[propName] = reactName ? reactName(nativeEvent) : nativeEvent[propName]);
			this.isDefaultPrevented = (null != nativeEvent.defaultPrevented ? nativeEvent.defaultPrevented : !1 === nativeEvent.returnValue) ? functionThatReturnsTrue : functionThatReturnsFalse;
			this.isPropagationStopped = functionThatReturnsFalse;
			return this;
		}
		assign(SyntheticBaseEvent.prototype, {
			preventDefault: function() {
				this.defaultPrevented = !0;
				var event = this.nativeEvent;
				event && (event.preventDefault ? event.preventDefault() : "unknown" !== typeof event.returnValue && (event.returnValue = !1), this.isDefaultPrevented = functionThatReturnsTrue);
			},
			stopPropagation: function() {
				var event = this.nativeEvent;
				event && (event.stopPropagation ? event.stopPropagation() : "unknown" !== typeof event.cancelBubble && (event.cancelBubble = !0), this.isPropagationStopped = functionThatReturnsTrue);
			},
			persist: function() {},
			isPersistent: functionThatReturnsTrue
		});
		return SyntheticBaseEvent;
	}
	var EventInterface = {
		eventPhase: 0,
		bubbles: 0,
		cancelable: 0,
		timeStamp: function(event) {
			return event.timeStamp || Date.now();
		},
		defaultPrevented: 0,
		isTrusted: 0
	};
	var SyntheticEvent = createSyntheticEvent(EventInterface);
	var UIEventInterface = assign({}, EventInterface, {
		view: 0,
		detail: 0
	});
	var SyntheticUIEvent = createSyntheticEvent(UIEventInterface);
	var lastMovementX;
	var lastMovementY;
	var lastMouseEvent;
	var MouseEventInterface = assign({}, UIEventInterface, {
		screenX: 0,
		screenY: 0,
		clientX: 0,
		clientY: 0,
		pageX: 0,
		pageY: 0,
		ctrlKey: 0,
		shiftKey: 0,
		altKey: 0,
		metaKey: 0,
		getModifierState: getEventModifierState,
		button: 0,
		buttons: 0,
		relatedTarget: function(event) {
			return void 0 === event.relatedTarget ? event.fromElement === event.srcElement ? event.toElement : event.fromElement : event.relatedTarget;
		},
		movementX: function(event) {
			if ("movementX" in event) return event.movementX;
			event !== lastMouseEvent && (lastMouseEvent && "mousemove" === event.type ? (lastMovementX = event.screenX - lastMouseEvent.screenX, lastMovementY = event.screenY - lastMouseEvent.screenY) : lastMovementY = lastMovementX = 0, lastMouseEvent = event);
			return lastMovementX;
		},
		movementY: function(event) {
			return "movementY" in event ? event.movementY : lastMovementY;
		}
	});
	var SyntheticMouseEvent = createSyntheticEvent(MouseEventInterface);
	var SyntheticDragEvent = createSyntheticEvent(assign({}, MouseEventInterface, { dataTransfer: 0 }));
	var SyntheticFocusEvent = createSyntheticEvent(assign({}, UIEventInterface, { relatedTarget: 0 }));
	var SyntheticAnimationEvent = createSyntheticEvent(assign({}, EventInterface, {
		animationName: 0,
		elapsedTime: 0,
		pseudoElement: 0
	}));
	var SyntheticClipboardEvent = createSyntheticEvent(assign({}, EventInterface, { clipboardData: function(event) {
		return "clipboardData" in event ? event.clipboardData : window.clipboardData;
	} }));
	var SyntheticCompositionEvent = createSyntheticEvent(assign({}, EventInterface, { data: 0 }));
	var normalizeKey = {
		Esc: "Escape",
		Spacebar: " ",
		Left: "ArrowLeft",
		Up: "ArrowUp",
		Right: "ArrowRight",
		Down: "ArrowDown",
		Del: "Delete",
		Win: "OS",
		Menu: "ContextMenu",
		Apps: "ContextMenu",
		Scroll: "ScrollLock",
		MozPrintableKey: "Unidentified"
	};
	var translateToKey = {
		8: "Backspace",
		9: "Tab",
		12: "Clear",
		13: "Enter",
		16: "Shift",
		17: "Control",
		18: "Alt",
		19: "Pause",
		20: "CapsLock",
		27: "Escape",
		32: " ",
		33: "PageUp",
		34: "PageDown",
		35: "End",
		36: "Home",
		37: "ArrowLeft",
		38: "ArrowUp",
		39: "ArrowRight",
		40: "ArrowDown",
		45: "Insert",
		46: "Delete",
		112: "F1",
		113: "F2",
		114: "F3",
		115: "F4",
		116: "F5",
		117: "F6",
		118: "F7",
		119: "F8",
		120: "F9",
		121: "F10",
		122: "F11",
		123: "F12",
		144: "NumLock",
		145: "ScrollLock",
		224: "Meta"
	};
	var modifierKeyToProp = {
		Alt: "altKey",
		Control: "ctrlKey",
		Meta: "metaKey",
		Shift: "shiftKey"
	};
	function modifierStateGetter(keyArg) {
		var nativeEvent = this.nativeEvent;
		return nativeEvent.getModifierState ? nativeEvent.getModifierState(keyArg) : (keyArg = modifierKeyToProp[keyArg]) ? !!nativeEvent[keyArg] : !1;
	}
	function getEventModifierState() {
		return modifierStateGetter;
	}
	var SyntheticKeyboardEvent = createSyntheticEvent(assign({}, UIEventInterface, {
		key: function(nativeEvent) {
			if (nativeEvent.key) {
				var key = normalizeKey[nativeEvent.key] || nativeEvent.key;
				if ("Unidentified" !== key) return key;
			}
			return "keypress" === nativeEvent.type ? (nativeEvent = getEventCharCode(nativeEvent), 13 === nativeEvent ? "Enter" : String.fromCharCode(nativeEvent)) : "keydown" === nativeEvent.type || "keyup" === nativeEvent.type ? translateToKey[nativeEvent.keyCode] || "Unidentified" : "";
		},
		code: 0,
		location: 0,
		ctrlKey: 0,
		shiftKey: 0,
		altKey: 0,
		metaKey: 0,
		repeat: 0,
		locale: 0,
		getModifierState: getEventModifierState,
		charCode: function(event) {
			return "keypress" === event.type ? getEventCharCode(event) : 0;
		},
		keyCode: function(event) {
			return "keydown" === event.type || "keyup" === event.type ? event.keyCode : 0;
		},
		which: function(event) {
			return "keypress" === event.type ? getEventCharCode(event) : "keydown" === event.type || "keyup" === event.type ? event.keyCode : 0;
		}
	}));
	var SyntheticPointerEvent = createSyntheticEvent(assign({}, MouseEventInterface, {
		pointerId: 0,
		width: 0,
		height: 0,
		pressure: 0,
		tangentialPressure: 0,
		tiltX: 0,
		tiltY: 0,
		twist: 0,
		pointerType: 0,
		isPrimary: 0
	}));
	var SyntheticSubmitEvent = createSyntheticEvent(assign({}, EventInterface, { submitter: 0 }));
	var SyntheticTouchEvent = createSyntheticEvent(assign({}, UIEventInterface, {
		touches: 0,
		targetTouches: 0,
		changedTouches: 0,
		altKey: 0,
		metaKey: 0,
		ctrlKey: 0,
		shiftKey: 0,
		getModifierState: getEventModifierState
	}));
	var SyntheticTransitionEvent = createSyntheticEvent(assign({}, EventInterface, {
		propertyName: 0,
		elapsedTime: 0,
		pseudoElement: 0
	}));
	var SyntheticWheelEvent = createSyntheticEvent(assign({}, MouseEventInterface, {
		deltaX: function(event) {
			return "deltaX" in event ? event.deltaX : "wheelDeltaX" in event ? -event.wheelDeltaX : 0;
		},
		deltaY: function(event) {
			return "deltaY" in event ? event.deltaY : "wheelDeltaY" in event ? -event.wheelDeltaY : "wheelDelta" in event ? -event.wheelDelta : 0;
		},
		deltaZ: 0,
		deltaMode: 0
	}));
	var SyntheticToggleEvent = createSyntheticEvent(assign({}, EventInterface, {
		newState: 0,
		oldState: 0,
		source: 0
	}));
	var END_KEYCODES = [
		9,
		13,
		27,
		32
	];
	var canUseCompositionEvent = canUseDOM && "CompositionEvent" in window;
	var documentMode = null;
	canUseDOM && "documentMode" in document && (documentMode = document.documentMode);
	var canUseTextInputEvent = canUseDOM && "TextEvent" in window && !documentMode;
	var useFallbackCompositionData = canUseDOM && (!canUseCompositionEvent || documentMode && 8 < documentMode && 11 >= documentMode);
	var SPACEBAR_CHAR = String.fromCharCode(32);
	var hasSpaceKeypress = !1;
	function isFallbackCompositionEnd(domEventName, nativeEvent) {
		switch (domEventName) {
			case "keyup": return -1 !== END_KEYCODES.indexOf(nativeEvent.keyCode);
			case "keydown": return 229 !== nativeEvent.keyCode;
			case "keypress":
			case "mousedown":
			case "focusout": return !0;
			default: return !1;
		}
	}
	function getDataFromCustomEvent(nativeEvent) {
		nativeEvent = nativeEvent.detail;
		return "object" === typeof nativeEvent && "data" in nativeEvent ? nativeEvent.data : null;
	}
	var isComposing = !1;
	function getNativeBeforeInputChars(domEventName, nativeEvent) {
		switch (domEventName) {
			case "compositionend": return getDataFromCustomEvent(nativeEvent);
			case "keypress":
				if (32 !== nativeEvent.which) return null;
				hasSpaceKeypress = !0;
				return SPACEBAR_CHAR;
			case "textInput": return domEventName = nativeEvent.data, domEventName === SPACEBAR_CHAR && hasSpaceKeypress ? null : domEventName;
			default: return null;
		}
	}
	function getFallbackBeforeInputChars(domEventName, nativeEvent) {
		if (isComposing) return "compositionend" === domEventName || !canUseCompositionEvent && isFallbackCompositionEnd(domEventName, nativeEvent) ? (domEventName = getData(), fallbackText = startText = root = null, isComposing = !1, domEventName) : null;
		switch (domEventName) {
			case "paste": return null;
			case "keypress":
				if (!(nativeEvent.ctrlKey || nativeEvent.altKey || nativeEvent.metaKey) || nativeEvent.ctrlKey && nativeEvent.altKey) {
					if (nativeEvent.char && 1 < nativeEvent.char.length) return nativeEvent.char;
					if (nativeEvent.which) return String.fromCharCode(nativeEvent.which);
				}
				return null;
			case "compositionend": return useFallbackCompositionData && "ko" !== nativeEvent.locale ? null : nativeEvent.data;
			default: return null;
		}
	}
	var supportedInputTypes = {
		color: !0,
		date: !0,
		datetime: !0,
		"datetime-local": !0,
		email: !0,
		month: !0,
		number: !0,
		password: !0,
		range: !0,
		search: !0,
		tel: !0,
		text: !0,
		time: !0,
		url: !0,
		week: !0
	};
	function isTextInputElement(elem) {
		var nodeName = elem && elem.nodeName && elem.nodeName.toLowerCase();
		return "input" === nodeName ? !!supportedInputTypes[elem.type] : "textarea" === nodeName ? !0 : !1;
	}
	function createAndAccumulateChangeEvent(dispatchQueue, inst, nativeEvent, target) {
		restoreTarget ? restoreQueue ? restoreQueue.push(target) : restoreQueue = [target] : restoreTarget = target;
		inst = accumulateTwoPhaseListeners(inst, "onChange");
		0 < inst.length && (nativeEvent = new SyntheticEvent("onChange", "change", null, nativeEvent, target), dispatchQueue.push({
			event: nativeEvent,
			listeners: inst
		}));
	}
	var activeElement$1 = null;
	var activeElementInst$1 = null;
	function runEventInBatch(dispatchQueue) {
		processDispatchQueue(dispatchQueue, 0);
	}
	function getInstIfValueChanged(targetInst) {
		if (updateValueIfChanged(getNodeFromInstance(targetInst))) return targetInst;
	}
	function getTargetInstForChangeEvent(domEventName, targetInst) {
		if ("change" === domEventName) return targetInst;
	}
	var isInputEventSupported = !1;
	if (canUseDOM) {
		var JSCompiler_inline_result$jscomp$318;
		if (canUseDOM) {
			var isSupported$jscomp$inline_474 = "oninput" in document;
			if (!isSupported$jscomp$inline_474) {
				var element$jscomp$inline_475 = document.createElement("div");
				element$jscomp$inline_475.setAttribute("oninput", "return;");
				isSupported$jscomp$inline_474 = "function" === typeof element$jscomp$inline_475.oninput;
			}
			JSCompiler_inline_result$jscomp$318 = isSupported$jscomp$inline_474;
		} else JSCompiler_inline_result$jscomp$318 = !1;
		isInputEventSupported = JSCompiler_inline_result$jscomp$318 && (!document.documentMode || 9 < document.documentMode);
	}
	function stopWatchingForValueChange() {
		activeElement$1 && (activeElement$1.detachEvent("onpropertychange", handlePropertyChange), activeElementInst$1 = activeElement$1 = null);
	}
	function handlePropertyChange(nativeEvent) {
		if ("value" === nativeEvent.propertyName && getInstIfValueChanged(activeElementInst$1)) {
			var dispatchQueue = [];
			createAndAccumulateChangeEvent(dispatchQueue, activeElementInst$1, nativeEvent, getEventTarget(nativeEvent));
			batchedUpdates$1(runEventInBatch, dispatchQueue);
		}
	}
	function handleEventsForInputEventPolyfill(domEventName, target, targetInst) {
		"focusin" === domEventName ? (stopWatchingForValueChange(), activeElement$1 = target, activeElementInst$1 = targetInst, activeElement$1.attachEvent("onpropertychange", handlePropertyChange)) : "focusout" === domEventName && stopWatchingForValueChange();
	}
	function getTargetInstForInputEventPolyfill(domEventName) {
		if ("selectionchange" === domEventName || "keyup" === domEventName || "keydown" === domEventName) return getInstIfValueChanged(activeElementInst$1);
	}
	function getTargetInstForClickEvent(domEventName, targetInst) {
		if ("click" === domEventName) return getInstIfValueChanged(targetInst);
	}
	function getTargetInstForInputOrChangeEvent(domEventName, targetInst) {
		if ("input" === domEventName || "change" === domEventName) return getInstIfValueChanged(targetInst);
	}
	function is(x, y) {
		return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
	}
	var objectIs = "function" === typeof Object.is ? Object.is : is;
	function shallowEqual(objA, objB) {
		if (objectIs(objA, objB)) return !0;
		if ("object" !== typeof objA || null === objA || "object" !== typeof objB || null === objB) return !1;
		var keysA = Object.keys(objA), keysB = Object.keys(objB);
		if (keysA.length !== keysB.length) return !1;
		for (keysB = 0; keysB < keysA.length; keysB++) {
			var currentKey = keysA[keysB];
			if (!hasOwnProperty.call(objB, currentKey) || !objectIs(objA[currentKey], objB[currentKey])) return !1;
		}
		return !0;
	}
	function getActiveElement(doc) {
		doc = doc || ("undefined" !== typeof document ? document : void 0);
		if ("undefined" === typeof doc) return null;
		try {
			return doc.activeElement || doc.body;
		} catch (e$20) {
			return doc.body;
		}
	}
	function getLeafNode(node) {
		for (; node && node.firstChild;) node = node.firstChild;
		return node;
	}
	function getNodeForCharacterOffset(root, offset) {
		var node = getLeafNode(root);
		root = 0;
		for (var nodeEnd; node;) {
			if (3 === node.nodeType) {
				nodeEnd = root + node.textContent.length;
				if (root <= offset && nodeEnd >= offset) return {
					node,
					offset: offset - root
				};
				root = nodeEnd;
			}
			a: {
				for (; node;) {
					if (node.nextSibling) {
						node = node.nextSibling;
						break a;
					}
					node = node.parentNode;
				}
				node = void 0;
			}
			node = getLeafNode(node);
		}
	}
	function containsNode(outerNode, innerNode) {
		return outerNode && innerNode ? outerNode === innerNode ? !0 : outerNode && 3 === outerNode.nodeType ? !1 : innerNode && 3 === innerNode.nodeType ? containsNode(outerNode, innerNode.parentNode) : "contains" in outerNode ? outerNode.contains(innerNode) : outerNode.compareDocumentPosition ? !!(outerNode.compareDocumentPosition(innerNode) & 16) : !1 : !1;
	}
	function getActiveElementDeep(containerInfo) {
		containerInfo = null != containerInfo && null != containerInfo.ownerDocument && null != containerInfo.ownerDocument.defaultView ? containerInfo.ownerDocument.defaultView : window;
		for (var element = getActiveElement(containerInfo.document); element instanceof containerInfo.HTMLIFrameElement;) {
			try {
				var JSCompiler_inline_result = "string" === typeof element.contentWindow.location.href;
			} catch (err) {
				JSCompiler_inline_result = !1;
			}
			if (JSCompiler_inline_result) containerInfo = element.contentWindow;
			else break;
			element = getActiveElement(containerInfo.document);
		}
		return element;
	}
	function hasSelectionCapabilities(elem) {
		var nodeName = elem && elem.nodeName && elem.nodeName.toLowerCase();
		return nodeName && ("input" === nodeName && ("text" === elem.type || "search" === elem.type || "tel" === elem.type || "url" === elem.type || "password" === elem.type) || "textarea" === nodeName || "true" === elem.contentEditable);
	}
	var skipSelectionChangeEvent = canUseDOM && "documentMode" in document && 11 >= document.documentMode;
	var activeElement = null;
	var activeElementInst = null;
	var lastSelection = null;
	var mouseDown = !1;
	function constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget) {
		var doc = nativeEventTarget.window === nativeEventTarget ? nativeEventTarget.document : 9 === nativeEventTarget.nodeType ? nativeEventTarget : nativeEventTarget.ownerDocument;
		mouseDown || null == activeElement || activeElement !== getActiveElement(doc) || (doc = activeElement, "selectionStart" in doc && hasSelectionCapabilities(doc) ? doc = {
			start: doc.selectionStart,
			end: doc.selectionEnd
		} : (doc = (doc.ownerDocument && doc.ownerDocument.defaultView || window).getSelection(), doc = {
			anchorNode: doc.anchorNode,
			anchorOffset: doc.anchorOffset,
			focusNode: doc.focusNode,
			focusOffset: doc.focusOffset
		}), lastSelection && shallowEqual(lastSelection, doc) || (lastSelection = doc, doc = accumulateTwoPhaseListeners(activeElementInst, "onSelect"), 0 < doc.length && (nativeEvent = new SyntheticEvent("onSelect", "select", null, nativeEvent, nativeEventTarget), dispatchQueue.push({
			event: nativeEvent,
			listeners: doc
		}), nativeEvent.target = activeElement)));
	}
	function makePrefixMap(styleProp, eventName) {
		var prefixes = {};
		prefixes[styleProp.toLowerCase()] = eventName.toLowerCase();
		prefixes["Webkit" + styleProp] = "webkit" + eventName;
		prefixes["Moz" + styleProp] = "moz" + eventName;
		return prefixes;
	}
	var vendorPrefixes = {
		animationend: makePrefixMap("Animation", "AnimationEnd"),
		animationiteration: makePrefixMap("Animation", "AnimationIteration"),
		animationstart: makePrefixMap("Animation", "AnimationStart"),
		transitionrun: makePrefixMap("Transition", "TransitionRun"),
		transitionstart: makePrefixMap("Transition", "TransitionStart"),
		transitioncancel: makePrefixMap("Transition", "TransitionCancel"),
		transitionend: makePrefixMap("Transition", "TransitionEnd")
	};
	var prefixedEventNames = {};
	var style = {};
	canUseDOM && (style = document.createElement("div").style, "AnimationEvent" in window || (delete vendorPrefixes.animationend.animation, delete vendorPrefixes.animationiteration.animation, delete vendorPrefixes.animationstart.animation), "TransitionEvent" in window || delete vendorPrefixes.transitionend.transition);
	function getVendorPrefixedEventName(eventName) {
		if (prefixedEventNames[eventName]) return prefixedEventNames[eventName];
		if (!vendorPrefixes[eventName]) return eventName;
		var prefixMap = vendorPrefixes[eventName], styleProp;
		for (styleProp in prefixMap) if (prefixMap.hasOwnProperty(styleProp) && styleProp in style) return prefixedEventNames[eventName] = prefixMap[styleProp];
		return eventName;
	}
	var ANIMATION_END = getVendorPrefixedEventName("animationend");
	var ANIMATION_ITERATION = getVendorPrefixedEventName("animationiteration");
	var ANIMATION_START = getVendorPrefixedEventName("animationstart");
	var TRANSITION_RUN = getVendorPrefixedEventName("transitionrun");
	var TRANSITION_START = getVendorPrefixedEventName("transitionstart");
	var TRANSITION_CANCEL = getVendorPrefixedEventName("transitioncancel");
	var TRANSITION_END = getVendorPrefixedEventName("transitionend");
	var topLevelEventsToReactNames = /* @__PURE__ */ new Map();
	var simpleEventPluginEvents = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
	simpleEventPluginEvents.push("scrollEnd");
	function registerSimpleEvent(domEventName, reactName) {
		topLevelEventsToReactNames.set(domEventName, reactName);
		registerTwoPhaseEvent(reactName, [domEventName]);
	}
	var globalClientIdCounter$1 = 0;
	function getViewTransitionName(props, instance) {
		if (null != props.name && "auto" !== props.name) return props.name;
		if (null !== instance.autoName) return instance.autoName;
		props = pendingEffectsRoot.identifierPrefix;
		var globalClientId = globalClientIdCounter$1++;
		props = "_" + props + "t_" + globalClientId.toString(32) + "_";
		return instance.autoName = props;
	}
	function getClassNameByType(classByType) {
		if (null == classByType || "string" === typeof classByType) return classByType;
		var className = null, activeTypes = pendingTransitionTypes;
		if (null !== activeTypes) for (var i = 0; i < activeTypes.length; i++) {
			var match = classByType[activeTypes[i]];
			if (null != match) {
				if ("none" === match) return "none";
				className = null == className ? match : className + (" " + match);
			}
		}
		return null == className ? classByType.default : className;
	}
	function getViewTransitionClassName(defaultClass, eventClass) {
		defaultClass = getClassNameByType(defaultClass);
		eventClass = getClassNameByType(eventClass);
		return null == eventClass ? "auto" === defaultClass ? null : defaultClass : "auto" === eventClass ? null : eventClass;
	}
	var reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
		if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
			var event = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
				error
			});
			if (!window.dispatchEvent(event)) return;
		} else if ("object" === typeof process && "function" === typeof process.emit) {
			process.emit("uncaughtException", error);
			return;
		}
		console.error(error);
	};
	var concurrentQueues = [];
	var concurrentQueuesIndex = 0;
	var concurrentlyUpdatedLanes = 0;
	function finishQueueingConcurrentUpdates() {
		for (var endIndex = concurrentQueuesIndex, i = concurrentlyUpdatedLanes = concurrentQueuesIndex = 0; i < endIndex;) {
			var fiber = concurrentQueues[i];
			concurrentQueues[i++] = null;
			var queue = concurrentQueues[i];
			concurrentQueues[i++] = null;
			var update = concurrentQueues[i];
			concurrentQueues[i++] = null;
			var lane = concurrentQueues[i];
			concurrentQueues[i++] = null;
			if (null !== queue && null !== update) {
				var pending = queue.pending;
				null === pending ? update.next = update : (update.next = pending.next, pending.next = update);
				queue.pending = update;
			}
			0 !== lane && markUpdateLaneFromFiberToRoot(fiber, update, lane);
		}
	}
	function enqueueUpdate$1(fiber, queue, update, lane) {
		concurrentQueues[concurrentQueuesIndex++] = fiber;
		concurrentQueues[concurrentQueuesIndex++] = queue;
		concurrentQueues[concurrentQueuesIndex++] = update;
		concurrentQueues[concurrentQueuesIndex++] = lane;
		concurrentlyUpdatedLanes |= lane;
		fiber.lanes |= lane;
		fiber = fiber.alternate;
		null !== fiber && (fiber.lanes |= lane);
	}
	function enqueueConcurrentHookUpdate(fiber, queue, update, lane) {
		enqueueUpdate$1(fiber, queue, update, lane);
		return getRootForUpdatedFiber(fiber);
	}
	function enqueueConcurrentRenderForLane(fiber, lane) {
		enqueueUpdate$1(fiber, null, null, lane);
		return getRootForUpdatedFiber(fiber);
	}
	function markUpdateLaneFromFiberToRoot(sourceFiber, update, lane) {
		sourceFiber.lanes |= lane;
		var alternate = sourceFiber.alternate;
		null !== alternate && (alternate.lanes |= lane);
		for (var isHidden = !1, parent = sourceFiber.return; null !== parent;) parent.childLanes |= lane, alternate = parent.alternate, null !== alternate && (alternate.childLanes |= lane), 22 === parent.tag && (sourceFiber = parent.stateNode, null === sourceFiber || sourceFiber._visibility & 1 || (isHidden = !0)), sourceFiber = parent, parent = parent.return;
		return 3 === sourceFiber.tag ? (parent = sourceFiber.stateNode, isHidden && null !== update && (isHidden = 31 - clz32(lane), sourceFiber = parent.hiddenUpdates, alternate = sourceFiber[isHidden], null === alternate ? sourceFiber[isHidden] = [update] : alternate.push(update), update.lane = lane | 536870912), parent) : null;
	}
	function getRootForUpdatedFiber(sourceFiber) {
		if (50 < nestedUpdateCount) throw nestedUpdateCount = 0, rootWithNestedUpdates = null, Error(formatProdErrorMessage(185));
		for (var parent = sourceFiber.return; null !== parent;) sourceFiber = parent, parent = sourceFiber.return;
		return 3 === sourceFiber.tag ? sourceFiber.stateNode : null;
	}
	var emptyContextObject = {};
	function FiberNode(tag, pendingProps, key, mode) {
		this.tag = tag;
		this.key = key;
		this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
		this.index = 0;
		this.refCleanup = this.ref = null;
		this.pendingProps = pendingProps;
		this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
		this.mode = mode;
		this.subtreeFlags = this.flags = 0;
		this.deletions = null;
		this.childLanes = this.lanes = 0;
		this.alternate = null;
	}
	function createFiberImplClass(tag, pendingProps, key, mode) {
		return new FiberNode(tag, pendingProps, key, mode);
	}
	function shouldConstruct(Component) {
		Component = Component.prototype;
		return !(!Component || !Component.isReactComponent);
	}
	function createWorkInProgress(current, pendingProps) {
		var workInProgress = current.alternate;
		null === workInProgress ? (workInProgress = createFiberImplClass(current.tag, pendingProps, current.key, current.mode), workInProgress.elementType = current.elementType, workInProgress.type = current.type, workInProgress.stateNode = current.stateNode, workInProgress.alternate = current, current.alternate = workInProgress) : (workInProgress.pendingProps = pendingProps, workInProgress.type = current.type, workInProgress.flags = 0, workInProgress.subtreeFlags = 0, workInProgress.deletions = null);
		workInProgress.flags = current.flags & 1206910976;
		workInProgress.childLanes = current.childLanes;
		workInProgress.lanes = current.lanes;
		workInProgress.child = current.child;
		workInProgress.memoizedProps = current.memoizedProps;
		workInProgress.memoizedState = current.memoizedState;
		workInProgress.updateQueue = current.updateQueue;
		pendingProps = current.dependencies;
		workInProgress.dependencies = null === pendingProps ? null : {
			lanes: pendingProps.lanes,
			firstContext: pendingProps.firstContext
		};
		workInProgress.sibling = current.sibling;
		workInProgress.index = current.index;
		workInProgress.ref = current.ref;
		workInProgress.refCleanup = current.refCleanup;
		return workInProgress;
	}
	function resetWorkInProgress(workInProgress, renderLanes) {
		workInProgress.flags &= 1206910978;
		var current = workInProgress.alternate;
		null === current ? (workInProgress.childLanes = 0, workInProgress.lanes = renderLanes, workInProgress.child = null, workInProgress.subtreeFlags = 0, workInProgress.memoizedProps = null, workInProgress.memoizedState = null, workInProgress.updateQueue = null, workInProgress.dependencies = null, workInProgress.stateNode = null) : (workInProgress.childLanes = current.childLanes, workInProgress.lanes = current.lanes, workInProgress.child = current.child, workInProgress.subtreeFlags = 0, workInProgress.deletions = null, workInProgress.memoizedProps = current.memoizedProps, workInProgress.memoizedState = current.memoizedState, workInProgress.updateQueue = current.updateQueue, workInProgress.type = current.type, renderLanes = current.dependencies, workInProgress.dependencies = null === renderLanes ? null : {
			lanes: renderLanes.lanes,
			firstContext: renderLanes.firstContext
		});
		return workInProgress;
	}
	function createFiberFromTypeAndProps(type, key, pendingProps, owner, mode, lanes) {
		var fiberTag = 0;
		owner = type;
		if ("function" === typeof owner) shouldConstruct(owner) && (fiberTag = 1);
		else if ("string" === typeof owner) fiberTag = isHostHoistableType(type, pendingProps, contextStackCursor.current) ? 26 : "html" === type || "head" === type || "body" === type ? 27 : 5;
		else a: switch (owner) {
			case REACT_ACTIVITY_TYPE: return type = createFiberImplClass(31, pendingProps, key, mode), type.elementType = REACT_ACTIVITY_TYPE, type.lanes = lanes, type;
			case REACT_FRAGMENT_TYPE: return createFiberFromFragment(pendingProps.children, mode, lanes, key);
			case REACT_STRICT_MODE_TYPE:
				fiberTag = 8;
				mode |= 24;
				break;
			case REACT_PROFILER_TYPE: return type = createFiberImplClass(12, pendingProps, key, mode | 2), type.elementType = REACT_PROFILER_TYPE, type.lanes = lanes, type;
			case REACT_SUSPENSE_TYPE: return type = createFiberImplClass(13, pendingProps, key, mode), type.elementType = REACT_SUSPENSE_TYPE, type.lanes = lanes, type;
			case REACT_SUSPENSE_LIST_TYPE: return type = createFiberImplClass(19, pendingProps, key, mode), type.elementType = REACT_SUSPENSE_LIST_TYPE, type.lanes = lanes, type;
			case REACT_LEGACY_HIDDEN_TYPE:
			case REACT_VIEW_TRANSITION_TYPE: return type = mode | 32, type = createFiberImplClass(30, pendingProps, key, type), type.elementType = REACT_VIEW_TRANSITION_TYPE, type.lanes = lanes, type.stateNode = {
				autoName: null,
				paired: null,
				clones: null,
				ref: null
			}, type;
			default:
				if ("object" === typeof owner && null !== owner) switch (owner.$$typeof) {
					case REACT_CONTEXT_TYPE:
						fiberTag = 10;
						break a;
					case REACT_CONSUMER_TYPE:
						fiberTag = 9;
						break a;
					case REACT_FORWARD_REF_TYPE:
						fiberTag = 11;
						break a;
					case REACT_MEMO_TYPE:
						fiberTag = 14;
						break a;
					case REACT_LAZY_TYPE:
						fiberTag = 16;
						owner = null;
						break a;
				}
				fiberTag = 29;
				pendingProps = Error(formatProdErrorMessage(130, null === type ? "null" : typeof type, ""));
				owner = null;
		}
		key = createFiberImplClass(fiberTag, pendingProps, key, mode);
		key.elementType = type;
		key.type = owner;
		key.lanes = lanes;
		return key;
	}
	function createFiberFromFragment(elements, mode, lanes, key) {
		elements = createFiberImplClass(7, elements, key, mode);
		elements.lanes = lanes;
		return elements;
	}
	function createFiberFromText(content, mode, lanes) {
		content = createFiberImplClass(6, content, null, mode);
		content.lanes = lanes;
		return content;
	}
	function createFiberFromDehydratedFragment(dehydratedNode) {
		var fiber = createFiberImplClass(18, null, null, 0);
		fiber.stateNode = dehydratedNode;
		return fiber;
	}
	function createFiberFromPortal(portal, mode, lanes) {
		mode = createFiberImplClass(4, null !== portal.children ? portal.children : [], portal.key, mode);
		mode.lanes = lanes;
		mode.stateNode = {
			containerInfo: portal.containerInfo,
			pendingChildren: null,
			implementation: portal.implementation
		};
		return mode;
	}
	var CapturedStacks = /* @__PURE__ */ new WeakMap();
	function createCapturedValueAtFiber(value, source) {
		if ("object" === typeof value && null !== value) {
			var existing = CapturedStacks.get(value);
			if (void 0 !== existing) return existing;
			source = {
				value,
				source,
				stack: getStackByFiberInDevAndProd(source)
			};
			CapturedStacks.set(value, source);
			return source;
		}
		return {
			value,
			source,
			stack: getStackByFiberInDevAndProd(source)
		};
	}
	var forkStack = [];
	var forkStackIndex = 0;
	var treeForkProvider = null;
	var treeForkCount = 0;
	var idStack = [];
	var idStackIndex = 0;
	var treeContextProvider = null;
	var treeContextId = 1;
	var treeContextOverflow = "";
	function pushTreeFork(workInProgress, totalChildren) {
		forkStack[forkStackIndex++] = treeForkCount;
		forkStack[forkStackIndex++] = treeForkProvider;
		treeForkProvider = workInProgress;
		treeForkCount = totalChildren;
	}
	function pushTreeId(workInProgress, totalChildren, index) {
		idStack[idStackIndex++] = treeContextId;
		idStack[idStackIndex++] = treeContextOverflow;
		idStack[idStackIndex++] = treeContextProvider;
		treeContextProvider = workInProgress;
		var baseIdWithLeadingBit = treeContextId;
		workInProgress = treeContextOverflow;
		var baseLength = 32 - clz32(baseIdWithLeadingBit) - 1;
		baseIdWithLeadingBit &= ~(1 << baseLength);
		index += 1;
		var length = 32 - clz32(totalChildren) + baseLength;
		if (30 < length) {
			var numberOfOverflowBits = baseLength - baseLength % 5;
			length = (baseIdWithLeadingBit & (1 << numberOfOverflowBits) - 1).toString(32);
			baseIdWithLeadingBit >>= numberOfOverflowBits;
			baseLength -= numberOfOverflowBits;
			treeContextId = 1 << 32 - clz32(totalChildren) + baseLength | index << baseLength | baseIdWithLeadingBit;
			treeContextOverflow = length + workInProgress;
		} else treeContextId = 1 << length | index << baseLength | baseIdWithLeadingBit, treeContextOverflow = workInProgress;
	}
	function pushMaterializedTreeId(workInProgress) {
		null !== workInProgress.return && (pushTreeFork(workInProgress, 1), pushTreeId(workInProgress, 1, 0));
	}
	function popTreeContext(workInProgress) {
		for (; workInProgress === treeForkProvider;) treeForkProvider = forkStack[--forkStackIndex], forkStack[forkStackIndex] = null, treeForkCount = forkStack[--forkStackIndex], forkStack[forkStackIndex] = null;
		for (; workInProgress === treeContextProvider;) treeContextProvider = idStack[--idStackIndex], idStack[idStackIndex] = null, treeContextOverflow = idStack[--idStackIndex], idStack[idStackIndex] = null, treeContextId = idStack[--idStackIndex], idStack[idStackIndex] = null;
	}
	function restoreSuspendedTreeContext(workInProgress, suspendedContext) {
		idStack[idStackIndex++] = treeContextId;
		idStack[idStackIndex++] = treeContextOverflow;
		idStack[idStackIndex++] = treeContextProvider;
		treeContextId = suspendedContext.id;
		treeContextOverflow = suspendedContext.overflow;
		treeContextProvider = workInProgress;
	}
	var hydrationParentFiber = null;
	var nextHydratableInstance = null;
	var isHydrating = !1;
	var hydrationErrors = null;
	var rootOrSingletonContext = !1;
	var HydrationMismatchException = Error(formatProdErrorMessage(519));
	function throwOnHydrationMismatch(fiber) {
		queueHydrationError(createCapturedValueAtFiber(Error(formatProdErrorMessage(418, 1 < arguments.length && void 0 !== arguments[1] && arguments[1] ? "text" : "HTML", "")), fiber));
		throw HydrationMismatchException;
	}
	function prepareToHydrateHostInstance(fiber) {
		var instance = fiber.stateNode, type = fiber.type, props = fiber.memoizedProps;
		instance[internalInstanceKey] = fiber;
		instance[internalPropsKey] = props;
		switch (type) {
			case "dialog":
				listenToNonDelegatedEvent("cancel", instance);
				listenToNonDelegatedEvent("close", instance);
				break;
			case "iframe":
			case "object":
			case "embed":
				listenToNonDelegatedEvent("load", instance);
				break;
			case "video":
			case "audio":
				for (type = 0; type < mediaEventTypes.length; type++) listenToNonDelegatedEvent(mediaEventTypes[type], instance);
				break;
			case "source":
				listenToNonDelegatedEvent("error", instance);
				break;
			case "img":
			case "image":
			case "link":
				listenToNonDelegatedEvent("error", instance);
				listenToNonDelegatedEvent("load", instance);
				break;
			case "details":
				listenToNonDelegatedEvent("toggle", instance);
				break;
			case "input":
				listenToNonDelegatedEvent("invalid", instance);
				initInput(instance, props.value, props.defaultValue, props.checked, props.defaultChecked, props.type, props.name, !0);
				break;
			case "select":
				listenToNonDelegatedEvent("invalid", instance);
				break;
			case "textarea": listenToNonDelegatedEvent("invalid", instance), initTextarea(instance, props.value, props.defaultValue, props.children);
		}
		type = props.children;
		"string" !== typeof type && "number" !== typeof type && "bigint" !== typeof type || instance.textContent === "" + type || !0 === props.suppressHydrationWarning || checkForUnmatchedText(instance.textContent, type) ? (null != props.popover && (listenToNonDelegatedEvent("beforetoggle", instance), listenToNonDelegatedEvent("toggle", instance)), null != props.onScroll && listenToNonDelegatedEvent("scroll", instance), null != props.onScrollEnd && listenToNonDelegatedEvent("scrollend", instance), null != props.onClick && (instance.onclick = noop$1), instance = !0) : instance = !1;
		instance || throwOnHydrationMismatch(fiber, !0);
	}
	function popToNextHostParent(fiber) {
		for (hydrationParentFiber = fiber.return; hydrationParentFiber;) switch (hydrationParentFiber.tag) {
			case 5:
			case 31:
			case 13:
				rootOrSingletonContext = !1;
				return;
			case 27:
			case 3:
				rootOrSingletonContext = !0;
				return;
			default: hydrationParentFiber = hydrationParentFiber.return;
		}
	}
	function popHydrationState(fiber) {
		if (fiber !== hydrationParentFiber) return !1;
		if (!isHydrating) return popToNextHostParent(fiber), isHydrating = !0, !1;
		var tag = fiber.tag, JSCompiler_temp;
		if (JSCompiler_temp = 3 !== tag && 27 !== tag) {
			if (JSCompiler_temp = 5 === tag) JSCompiler_temp = fiber.type, JSCompiler_temp = !("form" !== JSCompiler_temp && "button" !== JSCompiler_temp) || shouldSetTextContent(fiber.type, fiber.memoizedProps);
			JSCompiler_temp = !JSCompiler_temp;
		}
		JSCompiler_temp && nextHydratableInstance && throwOnHydrationMismatch(fiber);
		popToNextHostParent(fiber);
		if (13 === tag) {
			fiber = fiber.memoizedState;
			fiber = null !== fiber ? fiber.dehydrated : null;
			if (!fiber) throw Error(formatProdErrorMessage(317));
			nextHydratableInstance = getNextHydratableInstanceAfterHydrationBoundary(fiber);
		} else if (31 === tag) {
			fiber = fiber.memoizedState;
			fiber = null !== fiber ? fiber.dehydrated : null;
			if (!fiber) throw Error(formatProdErrorMessage(317));
			nextHydratableInstance = getNextHydratableInstanceAfterHydrationBoundary(fiber);
		} else 27 === tag ? (tag = nextHydratableInstance, isSingletonScope(fiber.type) ? (fiber = previousHydratableOnEnteringScopedSingleton, previousHydratableOnEnteringScopedSingleton = null, nextHydratableInstance = fiber) : nextHydratableInstance = tag) : nextHydratableInstance = hydrationParentFiber ? getNextHydratable(fiber.stateNode.nextSibling) : null;
		return !0;
	}
	function resetHydrationState() {
		nextHydratableInstance = hydrationParentFiber = null;
		isHydrating = !1;
	}
	function upgradeHydrationErrorsToRecoverable() {
		var queuedErrors = hydrationErrors;
		null !== queuedErrors && (null === workInProgressRootRecoverableErrors ? workInProgressRootRecoverableErrors = queuedErrors : workInProgressRootRecoverableErrors.push.apply(workInProgressRootRecoverableErrors, queuedErrors), hydrationErrors = null);
		return queuedErrors;
	}
	function queueHydrationError(error) {
		null === hydrationErrors ? hydrationErrors = [error] : hydrationErrors.push(error);
	}
	var valueCursor = createCursor(null);
	var currentlyRenderingFiber$1 = null;
	var lastContextDependency = null;
	function pushProvider(providerFiber, context, nextValue) {
		push(valueCursor, context._currentValue);
		context._currentValue = nextValue;
	}
	function popProvider(context) {
		context._currentValue = valueCursor.current;
		pop(valueCursor);
	}
	function scheduleContextWorkOnParentPath(parent, renderLanes, propagationRoot) {
		for (; null !== parent;) {
			var alternate = parent.alternate;
			(parent.childLanes & renderLanes) !== renderLanes ? (parent.childLanes |= renderLanes, null !== alternate && (alternate.childLanes |= renderLanes)) : null !== alternate && (alternate.childLanes & renderLanes) !== renderLanes && (alternate.childLanes |= renderLanes);
			if (parent === propagationRoot) break;
			parent = parent.return;
		}
	}
	function propagateContextChanges(workInProgress, contexts, renderLanes, forcePropagateEntireTree) {
		var fiber = workInProgress.child;
		null !== fiber && (fiber.return = workInProgress);
		for (; null !== fiber;) {
			var list = fiber.dependencies;
			if (null !== list) {
				var nextFiber = fiber.child;
				list = list.firstContext;
				a: for (; null !== list;) {
					var dependency = list;
					list = fiber;
					for (var i = 0; i < contexts.length; i++) if (dependency.context === contexts[i]) {
						list.lanes |= renderLanes;
						dependency = list.alternate;
						null !== dependency && (dependency.lanes |= renderLanes);
						scheduleContextWorkOnParentPath(list.return, renderLanes, workInProgress);
						forcePropagateEntireTree || (nextFiber = null);
						break a;
					}
					list = dependency.next;
				}
			} else if (18 === fiber.tag) {
				nextFiber = fiber.return;
				if (null === nextFiber) throw Error(formatProdErrorMessage(341));
				nextFiber.lanes |= renderLanes;
				list = nextFiber.alternate;
				null !== list && (list.lanes |= renderLanes);
				scheduleContextWorkOnParentPath(nextFiber, renderLanes, workInProgress);
				nextFiber = null;
			} else 13 === fiber.tag && null !== fiber.memoizedState && null === fiber.memoizedState.dehydrated ? (fiber.lanes |= renderLanes, nextFiber = fiber.alternate, null !== nextFiber && (nextFiber.lanes |= renderLanes), scheduleContextWorkOnParentPath(fiber.return, renderLanes, workInProgress), nextFiber = fiber.child, nextFiber = null !== nextFiber ? nextFiber.sibling : null) : nextFiber = fiber.child;
			if (null !== nextFiber) nextFiber.return = fiber;
			else for (nextFiber = fiber; null !== nextFiber;) {
				if (nextFiber === workInProgress) {
					nextFiber = null;
					break;
				}
				fiber = nextFiber.sibling;
				if (null !== fiber) {
					fiber.return = nextFiber.return;
					nextFiber = fiber;
					break;
				}
				nextFiber = nextFiber.return;
			}
			fiber = nextFiber;
		}
	}
	function propagateParentContextChanges(current, workInProgress, renderLanes, forcePropagateEntireTree) {
		current = null;
		for (var parent = workInProgress, isInsidePropagationBailout = !1; null !== parent;) {
			if (!isInsidePropagationBailout) {
				if (0 !== (parent.flags & 524288)) isInsidePropagationBailout = !0;
				else if (0 !== (parent.flags & 262144)) break;
			}
			if (10 === parent.tag) {
				var currentParent = parent.alternate;
				if (null === currentParent) throw Error(formatProdErrorMessage(387));
				currentParent = currentParent.memoizedProps;
				if (null !== currentParent) {
					var context = parent.type;
					objectIs(parent.pendingProps.value, currentParent.value) || (null !== current ? current.push(context) : current = [context]);
				}
			} else if (parent === hostTransitionProviderCursor.current) {
				currentParent = parent.alternate;
				if (null === currentParent) throw Error(formatProdErrorMessage(387));
				currentParent.memoizedState.memoizedState !== parent.memoizedState.memoizedState && (null !== current ? current.push(HostTransitionContext) : current = [HostTransitionContext]);
			}
			parent = parent.return;
		}
		null !== current && propagateContextChanges(workInProgress, current, renderLanes, forcePropagateEntireTree);
		workInProgress.flags |= 262144;
		return null !== current;
	}
	function checkIfContextChanged(currentDependencies) {
		for (currentDependencies = currentDependencies.firstContext; null !== currentDependencies;) {
			if (!objectIs(currentDependencies.context._currentValue, currentDependencies.memoizedValue)) return !0;
			currentDependencies = currentDependencies.next;
		}
		return !1;
	}
	function prepareToReadContext(workInProgress) {
		currentlyRenderingFiber$1 = workInProgress;
		lastContextDependency = null;
		workInProgress = workInProgress.dependencies;
		null !== workInProgress && (workInProgress.firstContext = null);
	}
	function readContext(context) {
		return readContextForConsumer(currentlyRenderingFiber$1, context);
	}
	function readContextDuringReconciliation(consumer, context) {
		null === currentlyRenderingFiber$1 && prepareToReadContext(consumer);
		return readContextForConsumer(consumer, context);
	}
	function readContextForConsumer(consumer, context) {
		var value = context._currentValue;
		context = {
			context,
			memoizedValue: value,
			next: null
		};
		if (null === lastContextDependency) {
			if (null === consumer) throw Error(formatProdErrorMessage(308));
			lastContextDependency = context;
			consumer.dependencies = {
				lanes: 0,
				firstContext: context
			};
			consumer.flags |= 524288;
		} else lastContextDependency = lastContextDependency.next = context;
		return value;
	}
	var AbortControllerLocal = "undefined" !== typeof AbortController ? AbortController : function() {
		var listeners = [], signal = this.signal = {
			aborted: !1,
			addEventListener: function(type, listener) {
				listeners.push(listener);
			}
		};
		this.abort = function() {
			signal.aborted = !0;
			listeners.forEach(function(listener) {
				return listener();
			});
		};
	};
	var scheduleCallback$2 = Scheduler.unstable_scheduleCallback;
	var NormalPriority = Scheduler.unstable_NormalPriority;
	var CacheContext = {
		$$typeof: REACT_CONTEXT_TYPE,
		Consumer: null,
		Provider: null,
		_currentValue: null,
		_currentValue2: null,
		_threadCount: 0
	};
	function createCache() {
		return {
			controller: new AbortControllerLocal(),
			data: /* @__PURE__ */ new Map(),
			refCount: 0
		};
	}
	function releaseCache(cache) {
		cache.refCount--;
		0 === cache.refCount && scheduleCallback$2(NormalPriority, function() {
			cache.controller.abort();
		});
	}
	function queueTransitionTypes(root, transitionTypes) {
		if (0 !== (root.pendingLanes & 4194048)) {
			var queued = root.transitionTypes;
			null === queued && (queued = root.transitionTypes = []);
			for (root = 0; root < transitionTypes.length; root++) {
				var transitionType = transitionTypes[root];
				-1 === queued.indexOf(transitionType) && queued.push(transitionType);
			}
		}
	}
	var entangledTransitionTypes = null;
	function claimQueuedTransitionTypes(root) {
		var claimed = root.transitionTypes;
		root.transitionTypes = null;
		return claimed;
	}
	var currentEntangledListeners = null;
	var currentEntangledPendingCount = 0;
	var currentEntangledLane = 0;
	var currentEntangledActionThenable = null;
	function entangleAsyncAction(transition, thenable) {
		if (null === currentEntangledListeners) {
			var entangledListeners = currentEntangledListeners = [];
			currentEntangledPendingCount = 0;
			currentEntangledLane = requestTransitionLane();
			currentEntangledActionThenable = {
				status: "pending",
				value: void 0,
				then: function(resolve) {
					entangledListeners.push(resolve);
				}
			};
		}
		currentEntangledPendingCount++;
		thenable.then(pingEngtangledActionScope, pingEngtangledActionScope);
		return thenable;
	}
	function pingEngtangledActionScope() {
		if (0 === --currentEntangledPendingCount && (entangledTransitionTypes = null, null !== currentEntangledListeners)) {
			null !== currentEntangledActionThenable && (currentEntangledActionThenable.status = "fulfilled");
			var listeners = currentEntangledListeners;
			currentEntangledListeners = null;
			currentEntangledLane = 0;
			currentEntangledActionThenable = null;
			for (var i = 0; i < listeners.length; i++) (0, listeners[i])();
		}
	}
	function chainThenableValue(thenable, result) {
		var listeners = [], thenableWithOverride = {
			status: "pending",
			value: null,
			reason: null,
			then: function(resolve) {
				listeners.push(resolve);
			}
		};
		thenable.then(function() {
			thenableWithOverride.status = "fulfilled";
			thenableWithOverride.value = result;
			for (var i = 0; i < listeners.length; i++) (0, listeners[i])(result);
		}, function(error) {
			thenableWithOverride.status = "rejected";
			thenableWithOverride.reason = error;
			for (error = 0; error < listeners.length; error++) (0, listeners[error])(void 0);
		});
		return thenableWithOverride;
	}
	var prevOnStartTransitionFinish = ReactSharedInternals.S;
	ReactSharedInternals.S = function(transition, returnValue) {
		globalMostRecentTransitionTime = now();
		"object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && entangleAsyncAction(transition, returnValue);
		if (null !== entangledTransitionTypes) for (var root$28 = firstScheduledRoot; null !== root$28;) queueTransitionTypes(root$28, entangledTransitionTypes), root$28 = root$28.next;
		root$28 = transition.types;
		if (null !== root$28) {
			for (var root$29 = firstScheduledRoot; null !== root$29;) queueTransitionTypes(root$29, root$28), root$29 = root$29.next;
			if (0 !== currentEntangledLane) {
				root$29 = entangledTransitionTypes;
				null === root$29 && (root$29 = entangledTransitionTypes = []);
				for (var i = 0; i < root$28.length; i++) {
					var transitionType = root$28[i];
					-1 === root$29.indexOf(transitionType) && root$29.push(transitionType);
				}
			}
		}
		null !== prevOnStartTransitionFinish && prevOnStartTransitionFinish(transition, returnValue);
	};
	var resumedCache = createCursor(null);
	function peekCacheFromPool() {
		var cacheResumedFromPreviousRender = resumedCache.current;
		return null !== cacheResumedFromPreviousRender ? cacheResumedFromPreviousRender : workInProgressRoot.pooledCache;
	}
	function pushTransition(offscreenWorkInProgress, prevCachePool) {
		null === prevCachePool ? push(resumedCache, resumedCache.current) : push(resumedCache, prevCachePool.pool);
	}
	function getSuspendedCache() {
		var cacheFromPool = peekCacheFromPool();
		return null === cacheFromPool ? null : {
			parent: CacheContext._currentValue,
			pool: cacheFromPool
		};
	}
	var SuspenseException = Error(formatProdErrorMessage(460));
	var SuspenseyCommitException = Error(formatProdErrorMessage(474));
	var SuspenseActionException = Error(formatProdErrorMessage(542));
	var noopSuspenseyCommitThenable = { then: function() {} };
	function isThenableResolved(thenable) {
		thenable = thenable.status;
		return "fulfilled" === thenable || "rejected" === thenable;
	}
	function trackUsedThenable(thenableState, thenable, index) {
		index = thenableState[index];
		void 0 === index ? thenableState.push(thenable) : index !== thenable && (thenable.then(noop$1, noop$1), thenable = index);
		switch (thenable.status) {
			case "fulfilled": return thenable.value;
			case "rejected":
				thenableState = thenable.reason;
				checkIfUseWrappedInAsyncCatch(thenableState);
				if (void 0 === thenableState && !("reason" in thenable)) throw Error(formatProdErrorMessage(600));
				throw thenableState;
			default:
				if ("string" === typeof thenable.status) thenable.then(noop$1, noop$1);
				else {
					thenableState = workInProgressRoot;
					if (null !== thenableState && 100 < thenableState.shellSuspendCounter) throw Error(formatProdErrorMessage(482));
					thenableState = thenable;
					thenableState.status = "pending";
					thenableState.then(function(fulfilledValue) {
						if ("pending" === thenable.status) {
							var fulfilledThenable = thenable;
							fulfilledThenable.status = "fulfilled";
							fulfilledThenable.value = fulfilledValue;
						}
					}, function(error) {
						if ("pending" === thenable.status) {
							var rejectedThenable = thenable;
							rejectedThenable.status = "rejected";
							rejectedThenable.reason = error;
						}
					});
				}
				switch (thenable.status) {
					case "fulfilled": return thenable.value;
					case "rejected": throw thenableState = thenable.reason, checkIfUseWrappedInAsyncCatch(thenableState), thenableState;
				}
				suspendedThenable = thenable;
				throw SuspenseException;
		}
	}
	function resolveLazy(lazyType) {
		try {
			var init = lazyType._init;
			return init(lazyType._payload);
		} catch (x) {
			if (null !== x && "object" === typeof x && "function" === typeof x.then) throw suspendedThenable = x, SuspenseException;
			throw x;
		}
	}
	var suspendedThenable = null;
	function getSuspendedThenable() {
		if (null === suspendedThenable) throw Error(formatProdErrorMessage(459));
		var thenable = suspendedThenable;
		suspendedThenable = null;
		return thenable;
	}
	function checkIfUseWrappedInAsyncCatch(rejectedReason) {
		if (rejectedReason === SuspenseException || rejectedReason === SuspenseActionException) throw Error(formatProdErrorMessage(483));
	}
	var thenableState$1 = null;
	var thenableIndexCounter$1 = 0;
	function unwrapThenable(thenable) {
		var index = thenableIndexCounter$1;
		thenableIndexCounter$1 += 1;
		null === thenableState$1 && (thenableState$1 = []);
		return trackUsedThenable(thenableState$1, thenable, index);
	}
	function coerceRef(workInProgress, element) {
		element = element.props.ref;
		workInProgress.ref = void 0 !== element ? element : null;
	}
	function throwOnInvalidObjectTypeImpl(returnFiber, newChild) {
		if (newChild.$$typeof === REACT_LEGACY_ELEMENT_TYPE) throw Error(formatProdErrorMessage(525));
		returnFiber = Object.prototype.toString.call(newChild);
		throw Error(formatProdErrorMessage(31, "[object Object]" === returnFiber ? "object with keys {" + Object.keys(newChild).join(", ") + "}" : returnFiber));
	}
	function createChildReconciler(shouldTrackSideEffects) {
		function deleteChild(returnFiber, childToDelete) {
			if (shouldTrackSideEffects) {
				var deletions = returnFiber.deletions;
				null === deletions ? (returnFiber.deletions = [childToDelete], returnFiber.flags |= 16) : deletions.push(childToDelete);
			}
		}
		function deleteRemainingChildren(returnFiber, currentFirstChild) {
			if (!shouldTrackSideEffects) return null;
			for (; null !== currentFirstChild;) deleteChild(returnFiber, currentFirstChild), currentFirstChild = currentFirstChild.sibling;
			return null;
		}
		function mapRemainingChildren(currentFirstChild) {
			for (var existingChildren = /* @__PURE__ */ new Map(); null !== currentFirstChild;) null === currentFirstChild.key ? existingChildren.set(currentFirstChild.index, currentFirstChild) : existingChildren.set(currentFirstChild.key, currentFirstChild), currentFirstChild = currentFirstChild.sibling;
			return existingChildren;
		}
		function useFiber(fiber, pendingProps) {
			fiber = createWorkInProgress(fiber, pendingProps);
			fiber.index = 0;
			fiber.sibling = null;
			return fiber;
		}
		function placeChild(newFiber, lastPlacedIndex, newIndex) {
			newFiber.index = newIndex;
			if (!shouldTrackSideEffects) return newFiber.flags |= 1048576, lastPlacedIndex;
			newIndex = newFiber.alternate;
			if (null !== newIndex) return newIndex = newIndex.index, newIndex < lastPlacedIndex ? (newFiber.flags |= 2, lastPlacedIndex) : newIndex;
			newFiber.flags |= 134217730;
			return lastPlacedIndex;
		}
		function placeSingleChild(newFiber) {
			shouldTrackSideEffects && null === newFiber.alternate && (newFiber.flags |= 134217730);
			return newFiber;
		}
		function updateTextNode(returnFiber, current, textContent, lanes) {
			if (null === current || 6 !== current.tag) return current = createFiberFromText(textContent, returnFiber.mode, lanes), current.return = returnFiber, current;
			current = useFiber(current, textContent);
			current.return = returnFiber;
			return current;
		}
		function updateElement(returnFiber, current, element, lanes) {
			var elementType = element.type;
			if (elementType === REACT_FRAGMENT_TYPE) return returnFiber = updateFragment(returnFiber, current, element.props.children, lanes, element.key), coerceRef(returnFiber, element), returnFiber;
			if (null !== current && (current.elementType === elementType || "object" === typeof elementType && null !== elementType && elementType.$$typeof === REACT_LAZY_TYPE && resolveLazy(elementType) === current.type)) return current = useFiber(current, element.props), coerceRef(current, element), current.return = returnFiber, current;
			current = createFiberFromTypeAndProps(element.type, element.key, element.props, null, returnFiber.mode, lanes);
			coerceRef(current, element);
			current.return = returnFiber;
			return current;
		}
		function updatePortal(returnFiber, current, portal, lanes) {
			if (null === current || 4 !== current.tag || current.stateNode.containerInfo !== portal.containerInfo || current.stateNode.implementation !== portal.implementation) return current = createFiberFromPortal(portal, returnFiber.mode, lanes), current.return = returnFiber, current;
			current = useFiber(current, portal.children || []);
			current.return = returnFiber;
			return current;
		}
		function updateFragment(returnFiber, current, fragment, lanes, key) {
			if (null === current || 7 !== current.tag) return current = createFiberFromFragment(fragment, returnFiber.mode, lanes, key), current.return = returnFiber, current;
			current = useFiber(current, fragment);
			current.return = returnFiber;
			return current;
		}
		function createChild(returnFiber, newChild, lanes) {
			if ("string" === typeof newChild && "" !== newChild || "number" === typeof newChild || "bigint" === typeof newChild) return newChild = createFiberFromText("" + newChild, returnFiber.mode, lanes), newChild.return = returnFiber, newChild;
			if ("object" === typeof newChild && null !== newChild) {
				switch (newChild.$$typeof) {
					case REACT_ELEMENT_TYPE: return lanes = createFiberFromTypeAndProps(newChild.type, newChild.key, newChild.props, null, returnFiber.mode, lanes), coerceRef(lanes, newChild), lanes.return = returnFiber, lanes;
					case REACT_PORTAL_TYPE: return newChild = createFiberFromPortal(newChild, returnFiber.mode, lanes), newChild.return = returnFiber, newChild;
					case REACT_LAZY_TYPE: return newChild = resolveLazy(newChild), createChild(returnFiber, newChild, lanes);
				}
				if (isArrayImpl(newChild) || getIteratorFn(newChild)) return newChild = createFiberFromFragment(newChild, returnFiber.mode, lanes, null), newChild.return = returnFiber, newChild;
				if ("function" === typeof newChild.then) return createChild(returnFiber, unwrapThenable(newChild), lanes);
				if (newChild.$$typeof === REACT_CONTEXT_TYPE) return createChild(returnFiber, readContextDuringReconciliation(returnFiber, newChild), lanes);
				throwOnInvalidObjectTypeImpl(returnFiber, newChild);
			}
			return null;
		}
		function updateSlot(returnFiber, oldFiber, newChild, lanes) {
			var key = null !== oldFiber ? oldFiber.key : null;
			if ("string" === typeof newChild && "" !== newChild || "number" === typeof newChild || "bigint" === typeof newChild) return null !== key ? null : updateTextNode(returnFiber, oldFiber, "" + newChild, lanes);
			if ("object" === typeof newChild && null !== newChild) {
				switch (newChild.$$typeof) {
					case REACT_ELEMENT_TYPE: return newChild.key === key ? updateElement(returnFiber, oldFiber, newChild, lanes) : null;
					case REACT_PORTAL_TYPE: return newChild.key === key ? updatePortal(returnFiber, oldFiber, newChild, lanes) : null;
					case REACT_LAZY_TYPE: return newChild = resolveLazy(newChild), updateSlot(returnFiber, oldFiber, newChild, lanes);
				}
				if (isArrayImpl(newChild) || getIteratorFn(newChild)) return null !== key ? null : updateFragment(returnFiber, oldFiber, newChild, lanes, null);
				if ("function" === typeof newChild.then) return updateSlot(returnFiber, oldFiber, unwrapThenable(newChild), lanes);
				if (newChild.$$typeof === REACT_CONTEXT_TYPE) return updateSlot(returnFiber, oldFiber, readContextDuringReconciliation(returnFiber, newChild), lanes);
				throwOnInvalidObjectTypeImpl(returnFiber, newChild);
			}
			return null;
		}
		function updateFromMap(existingChildren, returnFiber, newIdx, newChild, lanes) {
			if ("string" === typeof newChild && "" !== newChild || "number" === typeof newChild || "bigint" === typeof newChild) return existingChildren = existingChildren.get(newIdx) || null, updateTextNode(returnFiber, existingChildren, "" + newChild, lanes);
			if ("object" === typeof newChild && null !== newChild) {
				switch (newChild.$$typeof) {
					case REACT_ELEMENT_TYPE: return existingChildren = existingChildren.get(null === newChild.key ? newIdx : newChild.key) || null, updateElement(returnFiber, existingChildren, newChild, lanes);
					case REACT_PORTAL_TYPE: return existingChildren = existingChildren.get(null === newChild.key ? newIdx : newChild.key) || null, updatePortal(returnFiber, existingChildren, newChild, lanes);
					case REACT_LAZY_TYPE: return newChild = resolveLazy(newChild), updateFromMap(existingChildren, returnFiber, newIdx, newChild, lanes);
				}
				if (isArrayImpl(newChild) || getIteratorFn(newChild)) return existingChildren = existingChildren.get(newIdx) || null, updateFragment(returnFiber, existingChildren, newChild, lanes, null);
				if ("function" === typeof newChild.then) return updateFromMap(existingChildren, returnFiber, newIdx, unwrapThenable(newChild), lanes);
				if (newChild.$$typeof === REACT_CONTEXT_TYPE) return updateFromMap(existingChildren, returnFiber, newIdx, readContextDuringReconciliation(returnFiber, newChild), lanes);
				throwOnInvalidObjectTypeImpl(returnFiber, newChild);
			}
			return null;
		}
		function reconcileChildrenArray(returnFiber, currentFirstChild, newChildren, lanes) {
			for (var resultingFirstChild = null, previousNewFiber = null, oldFiber = currentFirstChild, newIdx = currentFirstChild = 0, nextOldFiber = null; null !== oldFiber && newIdx < newChildren.length; newIdx++) {
				oldFiber.index > newIdx ? (nextOldFiber = oldFiber, oldFiber = null) : nextOldFiber = oldFiber.sibling;
				var newFiber = updateSlot(returnFiber, oldFiber, newChildren[newIdx], lanes);
				if (null === newFiber) {
					null === oldFiber && (oldFiber = nextOldFiber);
					break;
				}
				shouldTrackSideEffects && oldFiber && null === newFiber.alternate && deleteChild(returnFiber, oldFiber);
				currentFirstChild = placeChild(newFiber, currentFirstChild, newIdx);
				null === previousNewFiber ? resultingFirstChild = newFiber : previousNewFiber.sibling = newFiber;
				previousNewFiber = newFiber;
				oldFiber = nextOldFiber;
			}
			if (newIdx === newChildren.length) return deleteRemainingChildren(returnFiber, oldFiber), isHydrating && pushTreeFork(returnFiber, newIdx), resultingFirstChild;
			if (null === oldFiber) {
				for (; newIdx < newChildren.length; newIdx++) oldFiber = createChild(returnFiber, newChildren[newIdx], lanes), null !== oldFiber && (currentFirstChild = placeChild(oldFiber, currentFirstChild, newIdx), null === previousNewFiber ? resultingFirstChild = oldFiber : previousNewFiber.sibling = oldFiber, previousNewFiber = oldFiber);
				isHydrating && pushTreeFork(returnFiber, newIdx);
				return resultingFirstChild;
			}
			for (oldFiber = mapRemainingChildren(oldFiber); newIdx < newChildren.length; newIdx++) nextOldFiber = updateFromMap(oldFiber, returnFiber, newIdx, newChildren[newIdx], lanes), null !== nextOldFiber && (shouldTrackSideEffects && (newFiber = nextOldFiber.alternate, null !== newFiber && oldFiber.delete(null === newFiber.key ? newIdx : newFiber.key)), currentFirstChild = placeChild(nextOldFiber, currentFirstChild, newIdx), null === previousNewFiber ? resultingFirstChild = nextOldFiber : previousNewFiber.sibling = nextOldFiber, previousNewFiber = nextOldFiber);
			shouldTrackSideEffects && oldFiber.forEach(function(child) {
				return deleteChild(returnFiber, child);
			});
			isHydrating && pushTreeFork(returnFiber, newIdx);
			return resultingFirstChild;
		}
		function reconcileChildrenIterator(returnFiber, currentFirstChild, newChildren, lanes) {
			if (null == newChildren) throw Error(formatProdErrorMessage(151));
			for (var resultingFirstChild = null, previousNewFiber = null, oldFiber = currentFirstChild, newIdx = currentFirstChild = 0, nextOldFiber = null, step = newChildren.next(); null !== oldFiber && !step.done; newIdx++, step = newChildren.next()) {
				oldFiber.index > newIdx ? (nextOldFiber = oldFiber, oldFiber = null) : nextOldFiber = oldFiber.sibling;
				var newFiber = updateSlot(returnFiber, oldFiber, step.value, lanes);
				if (null === newFiber) {
					null === oldFiber && (oldFiber = nextOldFiber);
					break;
				}
				shouldTrackSideEffects && oldFiber && null === newFiber.alternate && deleteChild(returnFiber, oldFiber);
				currentFirstChild = placeChild(newFiber, currentFirstChild, newIdx);
				null === previousNewFiber ? resultingFirstChild = newFiber : previousNewFiber.sibling = newFiber;
				previousNewFiber = newFiber;
				oldFiber = nextOldFiber;
			}
			if (step.done) return deleteRemainingChildren(returnFiber, oldFiber), isHydrating && pushTreeFork(returnFiber, newIdx), resultingFirstChild;
			if (null === oldFiber) {
				for (; !step.done; newIdx++, step = newChildren.next()) step = createChild(returnFiber, step.value, lanes), null !== step && (currentFirstChild = placeChild(step, currentFirstChild, newIdx), null === previousNewFiber ? resultingFirstChild = step : previousNewFiber.sibling = step, previousNewFiber = step);
				isHydrating && pushTreeFork(returnFiber, newIdx);
				return resultingFirstChild;
			}
			for (oldFiber = mapRemainingChildren(oldFiber); !step.done; newIdx++, step = newChildren.next()) step = updateFromMap(oldFiber, returnFiber, newIdx, step.value, lanes), null !== step && (shouldTrackSideEffects && (nextOldFiber = step.alternate, null !== nextOldFiber && oldFiber.delete(null === nextOldFiber.key ? newIdx : nextOldFiber.key)), currentFirstChild = placeChild(step, currentFirstChild, newIdx), null === previousNewFiber ? resultingFirstChild = step : previousNewFiber.sibling = step, previousNewFiber = step);
			shouldTrackSideEffects && oldFiber.forEach(function(child) {
				return deleteChild(returnFiber, child);
			});
			isHydrating && pushTreeFork(returnFiber, newIdx);
			return resultingFirstChild;
		}
		function reconcileChildFibersImpl(returnFiber, currentFirstChild, newChild, lanes) {
			"object" === typeof newChild && null !== newChild && newChild.type === REACT_FRAGMENT_TYPE && null === newChild.key && void 0 === newChild.props.ref && (newChild = newChild.props.children);
			if ("object" === typeof newChild && null !== newChild) {
				switch (newChild.$$typeof) {
					case REACT_ELEMENT_TYPE:
						a: {
							for (var key = newChild.key; null !== currentFirstChild;) {
								if (currentFirstChild.key === key) {
									key = newChild.type;
									if (key === REACT_FRAGMENT_TYPE) {
										if (7 === currentFirstChild.tag) {
											deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
											lanes = useFiber(currentFirstChild, newChild.props.children);
											coerceRef(lanes, newChild);
											lanes.return = returnFiber;
											returnFiber = lanes;
											break a;
										}
									} else if (currentFirstChild.elementType === key || "object" === typeof key && null !== key && key.$$typeof === REACT_LAZY_TYPE && resolveLazy(key) === currentFirstChild.type) {
										deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
										lanes = useFiber(currentFirstChild, newChild.props);
										coerceRef(lanes, newChild);
										lanes.return = returnFiber;
										returnFiber = lanes;
										break a;
									}
									deleteRemainingChildren(returnFiber, currentFirstChild);
									break;
								} else deleteChild(returnFiber, currentFirstChild);
								currentFirstChild = currentFirstChild.sibling;
							}
							newChild.type === REACT_FRAGMENT_TYPE ? (lanes = createFiberFromFragment(newChild.props.children, returnFiber.mode, lanes, newChild.key), coerceRef(lanes, newChild), lanes.return = returnFiber, returnFiber = lanes) : (lanes = createFiberFromTypeAndProps(newChild.type, newChild.key, newChild.props, null, returnFiber.mode, lanes), coerceRef(lanes, newChild), lanes.return = returnFiber, returnFiber = lanes);
						}
						return placeSingleChild(returnFiber);
					case REACT_PORTAL_TYPE:
						a: {
							for (key = newChild.key; null !== currentFirstChild;) {
								if (currentFirstChild.key === key) if (4 === currentFirstChild.tag && currentFirstChild.stateNode.containerInfo === newChild.containerInfo && currentFirstChild.stateNode.implementation === newChild.implementation) {
									deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
									lanes = useFiber(currentFirstChild, newChild.children || []);
									lanes.return = returnFiber;
									returnFiber = lanes;
									break a;
								} else {
									deleteRemainingChildren(returnFiber, currentFirstChild);
									break;
								}
								else deleteChild(returnFiber, currentFirstChild);
								currentFirstChild = currentFirstChild.sibling;
							}
							lanes = createFiberFromPortal(newChild, returnFiber.mode, lanes);
							lanes.return = returnFiber;
							returnFiber = lanes;
						}
						return placeSingleChild(returnFiber);
					case REACT_LAZY_TYPE: return newChild = resolveLazy(newChild), reconcileChildFibersImpl(returnFiber, currentFirstChild, newChild, lanes);
				}
				if (isArrayImpl(newChild)) return reconcileChildrenArray(returnFiber, currentFirstChild, newChild, lanes);
				if (getIteratorFn(newChild)) {
					key = getIteratorFn(newChild);
					if ("function" !== typeof key) throw Error(formatProdErrorMessage(150));
					newChild = key.call(newChild);
					return reconcileChildrenIterator(returnFiber, currentFirstChild, newChild, lanes);
				}
				if ("function" === typeof newChild.then) return reconcileChildFibersImpl(returnFiber, currentFirstChild, unwrapThenable(newChild), lanes);
				if (newChild.$$typeof === REACT_CONTEXT_TYPE) return reconcileChildFibersImpl(returnFiber, currentFirstChild, readContextDuringReconciliation(returnFiber, newChild), lanes);
				throwOnInvalidObjectTypeImpl(returnFiber, newChild);
			}
			return "string" === typeof newChild && "" !== newChild || "number" === typeof newChild || "bigint" === typeof newChild ? (newChild = "" + newChild, null !== currentFirstChild && 6 === currentFirstChild.tag ? (deleteRemainingChildren(returnFiber, currentFirstChild.sibling), lanes = useFiber(currentFirstChild, newChild), lanes.return = returnFiber, returnFiber = lanes) : (deleteRemainingChildren(returnFiber, currentFirstChild), lanes = createFiberFromText(newChild, returnFiber.mode, lanes), lanes.return = returnFiber, returnFiber = lanes), placeSingleChild(returnFiber)) : deleteRemainingChildren(returnFiber, currentFirstChild);
		}
		return function(returnFiber, currentFirstChild, newChild, lanes) {
			try {
				thenableIndexCounter$1 = 0;
				var firstChildFiber = reconcileChildFibersImpl(returnFiber, currentFirstChild, newChild, lanes);
				thenableState$1 = null;
				return firstChildFiber;
			} catch (x) {
				if (x === SuspenseException || x === SuspenseActionException) throw x;
				var fiber = createFiberImplClass(29, x, null, returnFiber.mode);
				fiber.lanes = lanes;
				fiber.return = returnFiber;
				return fiber;
			}
		};
	}
	var reconcileChildFibers = createChildReconciler(!0);
	var mountChildFibers = createChildReconciler(!1);
	var hasForceUpdate = !1;
	function initializeUpdateQueue(fiber) {
		fiber.updateQueue = {
			baseState: fiber.memoizedState,
			firstBaseUpdate: null,
			lastBaseUpdate: null,
			shared: {
				pending: null,
				lanes: 0,
				hiddenCallbacks: null
			},
			callbacks: null
		};
	}
	function cloneUpdateQueue(current, workInProgress) {
		current = current.updateQueue;
		workInProgress.updateQueue === current && (workInProgress.updateQueue = {
			baseState: current.baseState,
			firstBaseUpdate: current.firstBaseUpdate,
			lastBaseUpdate: current.lastBaseUpdate,
			shared: current.shared,
			callbacks: null
		});
	}
	function createUpdate(lane) {
		return {
			lane,
			tag: 0,
			payload: null,
			callback: null,
			next: null
		};
	}
	function enqueueUpdate(fiber, update, lane) {
		var updateQueue = fiber.updateQueue;
		if (null === updateQueue) return null;
		updateQueue = updateQueue.shared;
		if (0 !== (executionContext & 2)) {
			var pending = updateQueue.pending;
			null === pending ? update.next = update : (update.next = pending.next, pending.next = update);
			updateQueue.pending = update;
			update = getRootForUpdatedFiber(fiber);
			markUpdateLaneFromFiberToRoot(fiber, null, lane);
			return update;
		}
		enqueueUpdate$1(fiber, updateQueue, update, lane);
		return getRootForUpdatedFiber(fiber);
	}
	function entangleTransitions(root, fiber, lane) {
		fiber = fiber.updateQueue;
		if (null !== fiber && (fiber = fiber.shared, 0 !== (lane & 4194048))) {
			var queueLanes = fiber.lanes;
			queueLanes &= root.pendingLanes;
			lane |= queueLanes;
			fiber.lanes = lane;
			markRootEntangled(root, lane);
		}
	}
	function enqueueCapturedUpdate(workInProgress, capturedUpdate) {
		var queue = workInProgress.updateQueue, current = workInProgress.alternate;
		if (null !== current && (current = current.updateQueue, queue === current)) {
			var newFirst = null, newLast = null;
			queue = queue.firstBaseUpdate;
			if (null !== queue) {
				do {
					var clone = {
						lane: queue.lane,
						tag: queue.tag,
						payload: queue.payload,
						callback: null,
						next: null
					};
					null === newLast ? newFirst = newLast = clone : newLast = newLast.next = clone;
					queue = queue.next;
				} while (null !== queue);
				null === newLast ? newFirst = newLast = capturedUpdate : newLast = newLast.next = capturedUpdate;
			} else newFirst = newLast = capturedUpdate;
			queue = {
				baseState: current.baseState,
				firstBaseUpdate: newFirst,
				lastBaseUpdate: newLast,
				shared: current.shared,
				callbacks: current.callbacks
			};
			workInProgress.updateQueue = queue;
			return;
		}
		workInProgress = queue.lastBaseUpdate;
		null === workInProgress ? queue.firstBaseUpdate = capturedUpdate : workInProgress.next = capturedUpdate;
		queue.lastBaseUpdate = capturedUpdate;
	}
	var didReadFromEntangledAsyncAction = !1;
	function suspendIfUpdateReadFromEntangledAsyncAction() {
		if (didReadFromEntangledAsyncAction) {
			var entangledActionThenable = currentEntangledActionThenable;
			if (null !== entangledActionThenable) throw entangledActionThenable;
		}
	}
	function processUpdateQueue(workInProgress$jscomp$0, props, instance$jscomp$0, renderLanes) {
		didReadFromEntangledAsyncAction = !1;
		var queue = workInProgress$jscomp$0.updateQueue;
		hasForceUpdate = !1;
		var firstBaseUpdate = queue.firstBaseUpdate, lastBaseUpdate = queue.lastBaseUpdate, pendingQueue = queue.shared.pending;
		if (null !== pendingQueue) {
			queue.shared.pending = null;
			var lastPendingUpdate = pendingQueue, firstPendingUpdate = lastPendingUpdate.next;
			lastPendingUpdate.next = null;
			null === lastBaseUpdate ? firstBaseUpdate = firstPendingUpdate : lastBaseUpdate.next = firstPendingUpdate;
			lastBaseUpdate = lastPendingUpdate;
			var current = workInProgress$jscomp$0.alternate;
			null !== current && (current = current.updateQueue, pendingQueue = current.lastBaseUpdate, pendingQueue !== lastBaseUpdate && (null === pendingQueue ? current.firstBaseUpdate = firstPendingUpdate : pendingQueue.next = firstPendingUpdate, current.lastBaseUpdate = lastPendingUpdate));
		}
		if (null !== firstBaseUpdate) {
			var newState = queue.baseState;
			lastBaseUpdate = 0;
			current = firstPendingUpdate = lastPendingUpdate = null;
			pendingQueue = firstBaseUpdate;
			do {
				var updateLane = pendingQueue.lane & -536870913, isHiddenUpdate = updateLane !== pendingQueue.lane;
				if (isHiddenUpdate ? (workInProgressRootRenderLanes & updateLane) === updateLane : (renderLanes & updateLane) === updateLane) {
					0 !== updateLane && updateLane === currentEntangledLane && (didReadFromEntangledAsyncAction = !0);
					null !== current && (current = current.next = {
						lane: 0,
						tag: pendingQueue.tag,
						payload: pendingQueue.payload,
						callback: null,
						next: null
					});
					a: {
						var workInProgress = workInProgress$jscomp$0, update = pendingQueue;
						updateLane = props;
						var instance = instance$jscomp$0;
						switch (update.tag) {
							case 1:
								workInProgress = update.payload;
								if ("function" === typeof workInProgress) {
									newState = workInProgress.call(instance, newState, updateLane);
									break a;
								}
								newState = workInProgress;
								break a;
							case 3: workInProgress.flags = workInProgress.flags & -65537 | 128;
							case 0:
								workInProgress = update.payload;
								updateLane = "function" === typeof workInProgress ? workInProgress.call(instance, newState, updateLane) : workInProgress;
								if (null === updateLane || void 0 === updateLane) break a;
								newState = assign({}, newState, updateLane);
								break a;
							case 2: hasForceUpdate = !0;
						}
					}
					updateLane = pendingQueue.callback;
					null !== updateLane && (workInProgress$jscomp$0.flags |= 64, isHiddenUpdate && (workInProgress$jscomp$0.flags |= 8192), isHiddenUpdate = queue.callbacks, null === isHiddenUpdate ? queue.callbacks = [updateLane] : isHiddenUpdate.push(updateLane));
				} else isHiddenUpdate = {
					lane: updateLane,
					tag: pendingQueue.tag,
					payload: pendingQueue.payload,
					callback: pendingQueue.callback,
					next: null
				}, null === current ? (firstPendingUpdate = current = isHiddenUpdate, lastPendingUpdate = newState) : current = current.next = isHiddenUpdate, lastBaseUpdate |= updateLane;
				pendingQueue = pendingQueue.next;
				if (null === pendingQueue) if (pendingQueue = queue.shared.pending, null === pendingQueue) break;
				else isHiddenUpdate = pendingQueue, pendingQueue = isHiddenUpdate.next, isHiddenUpdate.next = null, queue.lastBaseUpdate = isHiddenUpdate, queue.shared.pending = null;
			} while (1);
			null === current && (lastPendingUpdate = newState);
			queue.baseState = lastPendingUpdate;
			queue.firstBaseUpdate = firstPendingUpdate;
			queue.lastBaseUpdate = current;
			null === firstBaseUpdate && (queue.shared.lanes = 0);
			workInProgressRootSkippedLanes |= lastBaseUpdate;
			workInProgress$jscomp$0.lanes = lastBaseUpdate;
			workInProgress$jscomp$0.memoizedState = newState;
		}
	}
	function callCallback(callback, context) {
		if ("function" !== typeof callback) throw Error(formatProdErrorMessage(191, callback));
		callback.call(context);
	}
	function commitCallbacks(updateQueue, context) {
		var callbacks = updateQueue.callbacks;
		if (null !== callbacks) for (updateQueue.callbacks = null, updateQueue = 0; updateQueue < callbacks.length; updateQueue++) callCallback(callbacks[updateQueue], context);
	}
	var currentTreeHiddenStackCursor = createCursor(null);
	var prevEntangledRenderLanesCursor = createCursor(0);
	function pushHiddenContext(fiber, context) {
		fiber = entangledRenderLanes;
		push(prevEntangledRenderLanesCursor, fiber);
		push(currentTreeHiddenStackCursor, context);
		entangledRenderLanes = fiber | context.baseLanes;
	}
	function reuseHiddenContextOnStack() {
		push(prevEntangledRenderLanesCursor, entangledRenderLanes);
		push(currentTreeHiddenStackCursor, currentTreeHiddenStackCursor.current);
	}
	function popHiddenContext() {
		entangledRenderLanes = prevEntangledRenderLanesCursor.current;
		pop(currentTreeHiddenStackCursor);
		pop(prevEntangledRenderLanesCursor);
	}
	var suspenseHandlerStackCursor = createCursor(null);
	var shellBoundary = null;
	function pushPrimaryTreeSuspenseHandler(handler) {
		var current = handler.alternate;
		push(suspenseStackCursor, suspenseStackCursor.current & 1);
		push(suspenseHandlerStackCursor, handler);
		null === shellBoundary && (null === current || null !== currentTreeHiddenStackCursor.current ? shellBoundary = handler : null !== current.memoizedState && (shellBoundary = handler));
	}
	function pushDehydratedActivitySuspenseHandler(fiber) {
		push(suspenseStackCursor, suspenseStackCursor.current);
		push(suspenseHandlerStackCursor, fiber);
		null === shellBoundary && (shellBoundary = fiber);
	}
	function pushOffscreenSuspenseHandler(fiber) {
		22 === fiber.tag ? (push(suspenseStackCursor, suspenseStackCursor.current), push(suspenseHandlerStackCursor, fiber), null === shellBoundary && (shellBoundary = fiber)) : reuseSuspenseHandlerOnStack();
	}
	function reuseSuspenseHandlerOnStack() {
		push(suspenseStackCursor, suspenseStackCursor.current);
		push(suspenseHandlerStackCursor, suspenseHandlerStackCursor.current);
	}
	function popSuspenseHandler(fiber) {
		pop(suspenseHandlerStackCursor);
		shellBoundary === fiber && (shellBoundary = null);
		pop(suspenseStackCursor);
	}
	var suspenseStackCursor = createCursor(0);
	function pushSuspenseListContext(fiber, newContext) {
		push(suspenseHandlerStackCursor, suspenseHandlerStackCursor.current);
		push(suspenseStackCursor, newContext);
	}
	function popSuspenseListContext(fiber) {
		pop(suspenseStackCursor);
		pop(suspenseHandlerStackCursor);
		shellBoundary === fiber && (shellBoundary = null);
	}
	function findFirstSuspended(row) {
		for (var node = row; null !== node;) {
			if (13 === node.tag) {
				var state = node.memoizedState;
				if (null !== state && (state = state.dehydrated, null === state || isSuspenseInstancePending(state) || isSuspenseInstanceFallback(state))) return node;
			} else if (19 === node.tag && "independent" !== node.memoizedProps.revealOrder) {
				if (0 !== (node.flags & 128)) return node;
			} else if (null !== node.child) {
				node.child.return = node;
				node = node.child;
				continue;
			}
			if (node === row) break;
			for (; null === node.sibling;) {
				if (null === node.return || node.return === row) return null;
				node = node.return;
			}
			node.sibling.return = node.return;
			node = node.sibling;
		}
		return null;
	}
	var renderLanes = 0;
	var currentlyRenderingFiber = null;
	var currentHook = null;
	var workInProgressHook = null;
	var didScheduleRenderPhaseUpdate = !1;
	var didScheduleRenderPhaseUpdateDuringThisPass = !1;
	var shouldDoubleInvokeUserFnsInHooksDEV = !1;
	var localIdCounter = 0;
	var thenableIndexCounter = 0;
	var thenableState = null;
	var globalClientIdCounter = 0;
	function throwInvalidHookError() {
		throw Error(formatProdErrorMessage(321));
	}
	function areHookInputsEqual(nextDeps, prevDeps) {
		if (null === prevDeps) return !1;
		for (var i = 0; i < prevDeps.length && i < nextDeps.length; i++) if (!objectIs(nextDeps[i], prevDeps[i])) return !1;
		return !0;
	}
	function renderWithHooks(current, workInProgress, Component, props, secondArg, nextRenderLanes) {
		renderLanes = nextRenderLanes;
		currentlyRenderingFiber = workInProgress;
		workInProgress.memoizedState = null;
		workInProgress.updateQueue = null;
		workInProgress.lanes = 0;
		ReactSharedInternals.H = null === current || null === current.memoizedState ? HooksDispatcherOnMount : HooksDispatcherOnUpdate;
		shouldDoubleInvokeUserFnsInHooksDEV = !1;
		nextRenderLanes = Component(props, secondArg);
		shouldDoubleInvokeUserFnsInHooksDEV = !1;
		didScheduleRenderPhaseUpdateDuringThisPass && (nextRenderLanes = renderWithHooksAgain(workInProgress, Component, props, secondArg));
		finishRenderingHooks(current);
		return nextRenderLanes;
	}
	function finishRenderingHooks(current) {
		ReactSharedInternals.H = ContextOnlyDispatcher;
		var didRenderTooFewHooks = null !== currentHook && null !== currentHook.next;
		renderLanes = 0;
		workInProgressHook = currentHook = currentlyRenderingFiber = null;
		didScheduleRenderPhaseUpdate = !1;
		thenableIndexCounter = 0;
		thenableState = null;
		if (didRenderTooFewHooks) throw Error(formatProdErrorMessage(300));
		null === current || didReceiveUpdate || (current = current.dependencies, null !== current && checkIfContextChanged(current) && (didReceiveUpdate = !0));
	}
	function renderWithHooksAgain(workInProgress, Component, props, secondArg) {
		currentlyRenderingFiber = workInProgress;
		var numberOfReRenders = 0;
		do {
			didScheduleRenderPhaseUpdateDuringThisPass && (thenableState = null);
			thenableIndexCounter = 0;
			didScheduleRenderPhaseUpdateDuringThisPass = !1;
			if (25 <= numberOfReRenders) throw Error(formatProdErrorMessage(301));
			numberOfReRenders += 1;
			workInProgressHook = currentHook = null;
			if (null != workInProgress.updateQueue) {
				var children = workInProgress.updateQueue;
				children.lastEffect = null;
				children.events = null;
				children.stores = null;
				null != children.memoCache && (children.memoCache.index = 0);
			}
			ReactSharedInternals.H = HooksDispatcherOnRerender;
			children = Component(props, secondArg);
		} while (didScheduleRenderPhaseUpdateDuringThisPass);
		return children;
	}
	function TransitionAwareHostComponent() {
		var dispatcher = ReactSharedInternals.H, maybeThenable = dispatcher.useState()[0];
		maybeThenable = "function" === typeof maybeThenable.then ? useThenable(maybeThenable) : maybeThenable;
		dispatcher = dispatcher.useState()[0];
		(null !== currentHook ? currentHook.memoizedState : null) !== dispatcher && (currentlyRenderingFiber.flags |= 1024);
		return maybeThenable;
	}
	function checkDidRenderIdHook() {
		var didRenderIdHook = 0 !== localIdCounter;
		localIdCounter = 0;
		return didRenderIdHook;
	}
	function bailoutHooks(current, workInProgress, lanes) {
		workInProgress.updateQueue = current.updateQueue;
		workInProgress.flags &= -2053;
		current.lanes &= ~lanes;
	}
	function resetHooksOnUnwind(workInProgress) {
		if (didScheduleRenderPhaseUpdate) {
			for (workInProgress = workInProgress.memoizedState; null !== workInProgress;) {
				var queue = workInProgress.queue;
				null !== queue && (queue.pending = null);
				workInProgress = workInProgress.next;
			}
			didScheduleRenderPhaseUpdate = !1;
		}
		renderLanes = 0;
		workInProgressHook = currentHook = currentlyRenderingFiber = null;
		didScheduleRenderPhaseUpdateDuringThisPass = !1;
		thenableIndexCounter = localIdCounter = 0;
		thenableState = null;
	}
	function mountWorkInProgressHook() {
		var hook = {
			memoizedState: null,
			baseState: null,
			baseQueue: null,
			queue: null,
			next: null
		};
		null === workInProgressHook ? currentlyRenderingFiber.memoizedState = workInProgressHook = hook : workInProgressHook = workInProgressHook.next = hook;
		return workInProgressHook;
	}
	function updateWorkInProgressHook() {
		if (null === currentHook) {
			var nextCurrentHook = currentlyRenderingFiber.alternate;
			nextCurrentHook = null !== nextCurrentHook ? nextCurrentHook.memoizedState : null;
		} else nextCurrentHook = currentHook.next;
		var nextWorkInProgressHook = null === workInProgressHook ? currentlyRenderingFiber.memoizedState : workInProgressHook.next;
		if (null !== nextWorkInProgressHook) workInProgressHook = nextWorkInProgressHook, currentHook = nextCurrentHook;
		else {
			if (null === nextCurrentHook) {
				if (null === currentlyRenderingFiber.alternate) throw Error(formatProdErrorMessage(467));
				throw Error(formatProdErrorMessage(310));
			}
			currentHook = nextCurrentHook;
			nextCurrentHook = {
				memoizedState: currentHook.memoizedState,
				baseState: currentHook.baseState,
				baseQueue: currentHook.baseQueue,
				queue: currentHook.queue,
				next: null
			};
			null === workInProgressHook ? currentlyRenderingFiber.memoizedState = workInProgressHook = nextCurrentHook : workInProgressHook = workInProgressHook.next = nextCurrentHook;
		}
		return workInProgressHook;
	}
	function createFunctionComponentUpdateQueue() {
		return {
			lastEffect: null,
			events: null,
			stores: null,
			memoCache: null
		};
	}
	function useThenable(thenable) {
		var index = thenableIndexCounter;
		thenableIndexCounter += 1;
		null === thenableState && (thenableState = []);
		thenable = trackUsedThenable(thenableState, thenable, index);
		index = currentlyRenderingFiber;
		null === (null === workInProgressHook ? index.memoizedState : workInProgressHook.next) && (index = index.alternate, ReactSharedInternals.H = null === index || null === index.memoizedState ? HooksDispatcherOnMount : HooksDispatcherOnUpdate);
		return thenable;
	}
	function use(usable) {
		if (null !== usable && "object" === typeof usable) {
			if ("function" === typeof usable.then) return useThenable(usable);
			if (usable.$$typeof === REACT_RECOVERABLE_TYPE) return;
			if (usable.$$typeof === REACT_CONTEXT_TYPE) return readContext(usable);
		}
		throw Error(formatProdErrorMessage(438, String(usable)));
	}
	function useMemoCache(size) {
		var memoCache = null, updateQueue = currentlyRenderingFiber.updateQueue;
		null !== updateQueue && (memoCache = updateQueue.memoCache);
		if (null == memoCache) {
			var current = currentlyRenderingFiber.alternate;
			null !== current && (current = current.updateQueue, null !== current && (current = current.memoCache, null != current && (memoCache = {
				data: current.data.map(function(array) {
					return array.slice();
				}),
				index: 0
			})));
		}
		memoCache ??= {
			data: [],
			index: 0
		};
		null === updateQueue && (updateQueue = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = updateQueue);
		updateQueue.memoCache = memoCache;
		updateQueue = memoCache.data[memoCache.index];
		if (void 0 === updateQueue) for (updateQueue = memoCache.data[memoCache.index] = Array(size), current = 0; current < size; current++) updateQueue[current] = REACT_MEMO_CACHE_SENTINEL;
		memoCache.index++;
		return updateQueue;
	}
	function basicStateReducer(state, action) {
		return "function" === typeof action ? action(state) : action;
	}
	function updateReducer(reducer) {
		return updateReducerImpl(updateWorkInProgressHook(), currentHook, reducer);
	}
	function updateReducerImpl(hook, current, reducer) {
		var queue = hook.queue;
		if (null === queue) throw Error(formatProdErrorMessage(311));
		queue.lastRenderedReducer = reducer;
		var baseQueue = hook.baseQueue, pendingQueue = queue.pending;
		if (null !== pendingQueue) {
			if (null !== baseQueue) {
				var baseFirst = baseQueue.next;
				baseQueue.next = pendingQueue.next;
				pendingQueue.next = baseFirst;
			}
			current.baseQueue = baseQueue = pendingQueue;
			queue.pending = null;
		}
		pendingQueue = hook.baseState;
		if (null === baseQueue) hook.memoizedState = pendingQueue;
		else {
			current = baseQueue.next;
			var newBaseQueueFirst = baseFirst = null, newBaseQueueLast = null, update = current, didReadFromEntangledAsyncAction$64 = !1;
			do {
				var updateLane = update.lane & -536870913;
				if (updateLane !== update.lane ? (workInProgressRootRenderLanes & updateLane) === updateLane : (renderLanes & updateLane) === updateLane) {
					var revertLane = update.revertLane;
					if (0 === revertLane) null !== newBaseQueueLast && (newBaseQueueLast = newBaseQueueLast.next = {
						lane: 0,
						revertLane: 0,
						gesture: null,
						action: update.action,
						hasEagerState: update.hasEagerState,
						eagerState: update.eagerState,
						next: null
					}), updateLane === currentEntangledLane && (didReadFromEntangledAsyncAction$64 = !0);
					else if ((renderLanes & revertLane) === revertLane) {
						update = update.next;
						revertLane === currentEntangledLane && (didReadFromEntangledAsyncAction$64 = !0);
						continue;
					} else updateLane = {
						lane: 0,
						revertLane: update.revertLane,
						gesture: null,
						action: update.action,
						hasEagerState: update.hasEagerState,
						eagerState: update.eagerState,
						next: null
					}, null === newBaseQueueLast ? (newBaseQueueFirst = newBaseQueueLast = updateLane, baseFirst = pendingQueue) : newBaseQueueLast = newBaseQueueLast.next = updateLane, currentlyRenderingFiber.lanes |= revertLane, workInProgressRootSkippedLanes |= revertLane;
					updateLane = update.action;
					shouldDoubleInvokeUserFnsInHooksDEV && reducer(pendingQueue, updateLane);
					pendingQueue = update.hasEagerState ? update.eagerState : reducer(pendingQueue, updateLane);
				} else revertLane = {
					lane: updateLane,
					revertLane: update.revertLane,
					gesture: update.gesture,
					action: update.action,
					hasEagerState: update.hasEagerState,
					eagerState: update.eagerState,
					next: null
				}, null === newBaseQueueLast ? (newBaseQueueFirst = newBaseQueueLast = revertLane, baseFirst = pendingQueue) : newBaseQueueLast = newBaseQueueLast.next = revertLane, currentlyRenderingFiber.lanes |= updateLane, workInProgressRootSkippedLanes |= updateLane;
				update = update.next;
			} while (null !== update && update !== current);
			null === newBaseQueueLast ? baseFirst = pendingQueue : newBaseQueueLast.next = newBaseQueueFirst;
			if (!objectIs(pendingQueue, hook.memoizedState) && (didReceiveUpdate = !0, didReadFromEntangledAsyncAction$64 && (reducer = currentEntangledActionThenable, null !== reducer))) throw reducer;
			hook.memoizedState = pendingQueue;
			hook.baseState = baseFirst;
			hook.baseQueue = newBaseQueueLast;
			queue.lastRenderedState = pendingQueue;
		}
		null === baseQueue && (queue.lanes = 0);
		return [hook.memoizedState, queue.dispatch];
	}
	function rerenderReducer(reducer) {
		var hook = updateWorkInProgressHook(), queue = hook.queue;
		if (null === queue) throw Error(formatProdErrorMessage(311));
		queue.lastRenderedReducer = reducer;
		var dispatch = queue.dispatch, lastRenderPhaseUpdate = queue.pending, newState = hook.memoizedState;
		if (null !== lastRenderPhaseUpdate) {
			queue.pending = null;
			var update = lastRenderPhaseUpdate = lastRenderPhaseUpdate.next;
			do
				newState = reducer(newState, update.action), update = update.next;
			while (update !== lastRenderPhaseUpdate);
			objectIs(newState, hook.memoizedState) || (didReceiveUpdate = !0);
			hook.memoizedState = newState;
			null === hook.baseQueue && (hook.baseState = newState);
			queue.lastRenderedState = newState;
		}
		return [newState, dispatch];
	}
	function updateSyncExternalStore(subscribe, getSnapshot, getServerSnapshot) {
		var fiber = currentlyRenderingFiber, hook = updateWorkInProgressHook(), isHydrating$jscomp$0 = isHydrating;
		if (isHydrating$jscomp$0) {
			if (void 0 === getServerSnapshot) throw Error(formatProdErrorMessage(407));
			getServerSnapshot = getServerSnapshot();
		} else getServerSnapshot = getSnapshot();
		var snapshotChanged = !objectIs((currentHook || hook).memoizedState, getServerSnapshot);
		snapshotChanged && (hook.memoizedState = getServerSnapshot, didReceiveUpdate = !0);
		hook = hook.queue;
		updateEffect(subscribeToStore.bind(null, fiber, hook, subscribe), [subscribe]);
		subscribe = hook.getSnapshot !== getSnapshot || snapshotChanged || null !== workInProgressHook && 0 !== (workInProgressHook.memoizedState.tag & 1);
		pushSimpleEffect(subscribe ? 9 : 8, { destroy: void 0 }, updateStoreInstance.bind(null, fiber, hook, getServerSnapshot, getSnapshot), null);
		if (subscribe) {
			fiber.flags |= 2048;
			if (null === workInProgressRoot) throw Error(formatProdErrorMessage(349));
			isHydrating$jscomp$0 || 0 !== (renderLanes & 127) || pushStoreConsistencyCheck(fiber, getSnapshot, getServerSnapshot);
		}
		return getServerSnapshot;
	}
	function pushStoreConsistencyCheck(fiber, getSnapshot, renderedSnapshot) {
		fiber.flags |= 16384;
		fiber = {
			getSnapshot,
			value: renderedSnapshot
		};
		getSnapshot = currentlyRenderingFiber.updateQueue;
		null === getSnapshot ? (getSnapshot = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = getSnapshot, getSnapshot.stores = [fiber]) : (renderedSnapshot = getSnapshot.stores, null === renderedSnapshot ? getSnapshot.stores = [fiber] : renderedSnapshot.push(fiber));
	}
	function updateStoreInstance(fiber, inst, nextSnapshot, getSnapshot) {
		inst.value = nextSnapshot;
		inst.getSnapshot = getSnapshot;
		checkIfSnapshotChanged(inst) && forceStoreRerender(fiber);
	}
	function subscribeToStore(fiber, inst, subscribe) {
		return subscribe(function() {
			checkIfSnapshotChanged(inst) && forceStoreRerender(fiber);
		});
	}
	function checkIfSnapshotChanged(inst) {
		var latestGetSnapshot = inst.getSnapshot;
		inst = inst.value;
		try {
			var nextValue = latestGetSnapshot();
			return !objectIs(inst, nextValue);
		} catch (error) {
			return !0;
		}
	}
	function forceStoreRerender(fiber) {
		var root = enqueueConcurrentRenderForLane(fiber, 2);
		null !== root && scheduleUpdateOnFiber(root, fiber, 2);
	}
	function mountStateImpl(initialState) {
		var hook = mountWorkInProgressHook();
		if ("function" === typeof initialState) {
			var initialStateInitializer = initialState;
			initialState = initialStateInitializer();
			if (shouldDoubleInvokeUserFnsInHooksDEV) {
				setIsStrictModeForDevtools(!0);
				try {
					initialStateInitializer();
				} finally {
					setIsStrictModeForDevtools(!1);
				}
			}
		}
		hook.memoizedState = hook.baseState = initialState;
		hook.queue = {
			pending: null,
			lanes: 0,
			dispatch: null,
			lastRenderedReducer: basicStateReducer,
			lastRenderedState: initialState
		};
		return hook;
	}
	function updateOptimisticImpl(hook, current, passthrough, reducer) {
		hook.baseState = passthrough;
		return updateReducerImpl(hook, currentHook, "function" === typeof reducer ? reducer : basicStateReducer);
	}
	function dispatchActionState(fiber, actionQueue, setPendingState, setState, payload) {
		if (isRenderPhaseUpdate(fiber)) throw Error(formatProdErrorMessage(485));
		fiber = actionQueue.action;
		if (null !== fiber) {
			var actionNode = {
				payload,
				action: fiber,
				next: null,
				isTransition: !0,
				status: "pending",
				value: null,
				reason: null,
				listeners: [],
				then: function(listener) {
					actionNode.listeners.push(listener);
				}
			};
			null !== ReactSharedInternals.T ? setPendingState(!0) : actionNode.isTransition = !1;
			setState(actionNode);
			setPendingState = actionQueue.pending;
			null === setPendingState ? (actionNode.next = actionQueue.pending = actionNode, runActionStateAction(actionQueue, actionNode)) : (actionNode.next = setPendingState.next, actionQueue.pending = setPendingState.next = actionNode);
		}
	}
	function runActionStateAction(actionQueue, node) {
		var action = node.action, payload = node.payload, prevState = actionQueue.state;
		if (node.isTransition) {
			var prevTransition = ReactSharedInternals.T, currentTransition = {};
			currentTransition.types = null !== prevTransition ? prevTransition.types : null;
			ReactSharedInternals.T = currentTransition;
			try {
				var returnValue = action(prevState, payload), onStartTransitionFinish = ReactSharedInternals.S;
				null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
				handleActionReturnValue(actionQueue, node, returnValue);
			} catch (error) {
				onActionError(actionQueue, node, error);
			} finally {
				null !== prevTransition && null !== currentTransition.types && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
			}
		} else try {
			prevTransition = action(prevState, payload), handleActionReturnValue(actionQueue, node, prevTransition);
		} catch (error$70) {
			onActionError(actionQueue, node, error$70);
		}
	}
	function handleActionReturnValue(actionQueue, node, returnValue) {
		null !== returnValue && "object" === typeof returnValue && "function" === typeof returnValue.then ? returnValue.then(function(nextState) {
			onActionSuccess(actionQueue, node, nextState);
		}, function(error) {
			return onActionError(actionQueue, node, error);
		}) : onActionSuccess(actionQueue, node, returnValue);
	}
	function onActionSuccess(actionQueue, actionNode, nextState) {
		actionNode.status = "fulfilled";
		actionNode.value = nextState;
		notifyActionListeners(actionNode);
		actionQueue.state = nextState;
		actionNode = actionQueue.pending;
		null !== actionNode && (nextState = actionNode.next, nextState === actionNode ? actionQueue.pending = null : (nextState = nextState.next, actionNode.next = nextState, runActionStateAction(actionQueue, nextState)));
	}
	function onActionError(actionQueue, actionNode, error) {
		var last = actionQueue.pending;
		actionQueue.pending = null;
		if (null !== last) {
			last = last.next;
			do
				actionNode.status = "rejected", actionNode.reason = error, notifyActionListeners(actionNode), actionNode = actionNode.next;
			while (actionNode !== last);
		}
		actionQueue.action = null;
	}
	function notifyActionListeners(actionNode) {
		actionNode = actionNode.listeners;
		for (var i = 0; i < actionNode.length; i++) (0, actionNode[i])();
	}
	function actionStateReducer(oldState, newState) {
		return newState;
	}
	function mountActionState(action, initialStateProp) {
		if (isHydrating) {
			var ssrFormState = workInProgressRoot.formState;
			if (null !== ssrFormState) {
				a: {
					var JSCompiler_inline_result = currentlyRenderingFiber;
					if (isHydrating) {
						if (nextHydratableInstance) {
							b: {
								var JSCompiler_inline_result$jscomp$0 = nextHydratableInstance;
								for (var inRootOrSingleton = rootOrSingletonContext; 8 !== JSCompiler_inline_result$jscomp$0.nodeType;) {
									if (!inRootOrSingleton) {
										JSCompiler_inline_result$jscomp$0 = null;
										break b;
									}
									JSCompiler_inline_result$jscomp$0 = getNextHydratable(JSCompiler_inline_result$jscomp$0.nextSibling);
									if (null === JSCompiler_inline_result$jscomp$0) {
										JSCompiler_inline_result$jscomp$0 = null;
										break b;
									}
								}
								inRootOrSingleton = JSCompiler_inline_result$jscomp$0.data;
								JSCompiler_inline_result$jscomp$0 = "F!" === inRootOrSingleton || "F" === inRootOrSingleton ? JSCompiler_inline_result$jscomp$0 : null;
							}
							if (JSCompiler_inline_result$jscomp$0) {
								nextHydratableInstance = getNextHydratable(JSCompiler_inline_result$jscomp$0.nextSibling);
								JSCompiler_inline_result = "F!" === JSCompiler_inline_result$jscomp$0.data;
								break a;
							}
						}
						throwOnHydrationMismatch(JSCompiler_inline_result);
					}
					JSCompiler_inline_result = !1;
				}
				JSCompiler_inline_result && (initialStateProp = ssrFormState[0]);
			}
		}
		ssrFormState = mountWorkInProgressHook();
		ssrFormState.memoizedState = ssrFormState.baseState = initialStateProp;
		JSCompiler_inline_result = {
			pending: null,
			lanes: 0,
			dispatch: null,
			lastRenderedReducer: actionStateReducer,
			lastRenderedState: initialStateProp
		};
		ssrFormState.queue = JSCompiler_inline_result;
		ssrFormState = dispatchSetState.bind(null, currentlyRenderingFiber, JSCompiler_inline_result);
		JSCompiler_inline_result.dispatch = ssrFormState;
		JSCompiler_inline_result = mountStateImpl(!1);
		inRootOrSingleton = dispatchOptimisticSetState.bind(null, currentlyRenderingFiber, !1, JSCompiler_inline_result.queue);
		JSCompiler_inline_result = mountWorkInProgressHook();
		JSCompiler_inline_result$jscomp$0 = {
			state: initialStateProp,
			dispatch: null,
			action,
			pending: null
		};
		JSCompiler_inline_result.queue = JSCompiler_inline_result$jscomp$0;
		ssrFormState = dispatchActionState.bind(null, currentlyRenderingFiber, JSCompiler_inline_result$jscomp$0, inRootOrSingleton, ssrFormState);
		JSCompiler_inline_result$jscomp$0.dispatch = ssrFormState;
		JSCompiler_inline_result.memoizedState = action;
		return [
			initialStateProp,
			ssrFormState,
			!1
		];
	}
	function updateActionState(action) {
		return updateActionStateImpl(updateWorkInProgressHook(), currentHook, action);
	}
	function updateActionStateImpl(stateHook, currentStateHook, action) {
		currentStateHook = updateReducerImpl(stateHook, currentStateHook, actionStateReducer)[0];
		stateHook = updateReducer(basicStateReducer)[0];
		if ("object" === typeof currentStateHook && null !== currentStateHook && "function" === typeof currentStateHook.then) try {
			var state = useThenable(currentStateHook);
		} catch (x) {
			if (x === SuspenseException) throw SuspenseActionException;
			throw x;
		}
		else state = currentStateHook;
		currentStateHook = updateWorkInProgressHook();
		var actionQueue = currentStateHook.queue, dispatch = actionQueue.dispatch;
		action !== currentStateHook.memoizedState && (currentlyRenderingFiber.flags |= 2048, pushSimpleEffect(9, { destroy: void 0 }, actionStateActionEffect.bind(null, actionQueue, action), null));
		return [
			state,
			dispatch,
			stateHook
		];
	}
	function actionStateActionEffect(actionQueue, action) {
		actionQueue.action = action;
	}
	function rerenderActionState(action) {
		var stateHook = updateWorkInProgressHook(), currentStateHook = currentHook;
		if (null !== currentStateHook) return updateActionStateImpl(stateHook, currentStateHook, action);
		updateWorkInProgressHook();
		stateHook = stateHook.memoizedState;
		currentStateHook = updateWorkInProgressHook();
		var dispatch = currentStateHook.queue.dispatch;
		currentStateHook.memoizedState = action;
		return [
			stateHook,
			dispatch,
			!1
		];
	}
	function pushSimpleEffect(tag, inst, create, deps) {
		tag = {
			tag,
			create,
			deps,
			inst,
			next: null
		};
		inst = currentlyRenderingFiber.updateQueue;
		null === inst && (inst = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = inst);
		create = inst.lastEffect;
		null === create ? inst.lastEffect = tag.next = tag : (deps = create.next, create.next = tag, tag.next = deps, inst.lastEffect = tag);
		return tag;
	}
	function updateRef() {
		return updateWorkInProgressHook().memoizedState;
	}
	function mountEffectImpl(fiberFlags, hookFlags, create, deps) {
		var hook = mountWorkInProgressHook();
		currentlyRenderingFiber.flags |= fiberFlags;
		hook.memoizedState = pushSimpleEffect(1 | hookFlags, { destroy: void 0 }, create, void 0 === deps ? null : deps);
	}
	function updateEffectImpl(fiberFlags, hookFlags, create, deps) {
		var hook = updateWorkInProgressHook();
		deps = void 0 === deps ? null : deps;
		var inst = hook.memoizedState.inst;
		null !== currentHook && null !== deps && areHookInputsEqual(deps, currentHook.memoizedState.deps) ? hook.memoizedState = pushSimpleEffect(hookFlags, inst, create, deps) : (currentlyRenderingFiber.flags |= fiberFlags, hook.memoizedState = pushSimpleEffect(1 | hookFlags, inst, create, deps));
	}
	function mountEffect(create, deps) {
		mountEffectImpl(8390656, 8, create, deps);
	}
	function updateEffect(create, deps) {
		updateEffectImpl(2048, 8, create, deps);
	}
	function useEffectEventImpl(payload) {
		currentlyRenderingFiber.flags |= 4;
		var componentUpdateQueue = currentlyRenderingFiber.updateQueue;
		if (null === componentUpdateQueue) componentUpdateQueue = createFunctionComponentUpdateQueue(), currentlyRenderingFiber.updateQueue = componentUpdateQueue, componentUpdateQueue.events = [payload];
		else {
			var events = componentUpdateQueue.events;
			null === events ? componentUpdateQueue.events = [payload] : events.push(payload);
		}
	}
	function updateEvent(callback) {
		var ref = updateWorkInProgressHook().memoizedState;
		useEffectEventImpl({
			ref,
			nextImpl: callback
		});
		return function() {
			if (0 !== (executionContext & 2)) throw Error(formatProdErrorMessage(440));
			return ref.impl.apply(void 0, arguments);
		};
	}
	function updateInsertionEffect(create, deps) {
		return updateEffectImpl(4, 2, create, deps);
	}
	function updateLayoutEffect(create, deps) {
		return updateEffectImpl(4, 4, create, deps);
	}
	function imperativeHandleEffect(create, ref) {
		if ("function" === typeof ref) {
			create = create();
			var refCleanup = ref(create);
			return function() {
				"function" === typeof refCleanup ? refCleanup() : ref(null);
			};
		}
		if (null !== ref && void 0 !== ref) return create = create(), ref.current = create, function() {
			ref.current = null;
		};
	}
	function updateImperativeHandle(ref, create, deps) {
		deps = null !== deps && void 0 !== deps ? deps.concat([ref]) : null;
		updateEffectImpl(4, 4, imperativeHandleEffect.bind(null, create, ref), deps);
	}
	function mountDebugValue() {}
	function updateCallback(callback, deps) {
		var hook = updateWorkInProgressHook();
		deps = void 0 === deps ? null : deps;
		var prevState = hook.memoizedState;
		if (null !== deps && areHookInputsEqual(deps, prevState[1])) return prevState[0];
		hook.memoizedState = [callback, deps];
		return callback;
	}
	function updateMemo(nextCreate, deps) {
		var hook = updateWorkInProgressHook();
		deps = void 0 === deps ? null : deps;
		var prevState = hook.memoizedState;
		if (null !== deps && areHookInputsEqual(deps, prevState[1])) return prevState[0];
		prevState = nextCreate();
		if (shouldDoubleInvokeUserFnsInHooksDEV) {
			setIsStrictModeForDevtools(!0);
			try {
				nextCreate();
			} finally {
				setIsStrictModeForDevtools(!1);
			}
		}
		hook.memoizedState = [prevState, deps];
		return prevState;
	}
	function mountDeferredValueImpl(hook, value, initialValue) {
		if (void 0 === initialValue || 0 !== (renderLanes & 1073741824) && 0 === (workInProgressRootRenderLanes & 261930)) return hook.memoizedState = value;
		hook.memoizedState = initialValue;
		hook = requestDeferredLane();
		currentlyRenderingFiber.lanes |= hook;
		workInProgressRootSkippedLanes |= hook;
		return initialValue;
	}
	function updateDeferredValueImpl(hook, prevValue, value, initialValue) {
		if (objectIs(value, prevValue)) return value;
		if (null !== currentTreeHiddenStackCursor.current) return hook = mountDeferredValueImpl(hook, value, initialValue), objectIs(hook, prevValue) || (didReceiveUpdate = !0), hook;
		if (0 === (renderLanes & 106) || 0 !== (renderLanes & 1073741824) && 0 === (workInProgressRootRenderLanes & 261930)) return didReceiveUpdate = !0, hook.memoizedState = value;
		hook = requestDeferredLane();
		currentlyRenderingFiber.lanes |= hook;
		workInProgressRootSkippedLanes |= hook;
		return prevValue;
	}
	function startTransition(fiber, queue, pendingState, finishedState, callback) {
		var previousPriority = ReactDOMSharedInternals.p;
		ReactDOMSharedInternals.p = 0 !== previousPriority && 8 > previousPriority ? previousPriority : 8;
		var prevTransition = ReactSharedInternals.T, currentTransition = {};
		currentTransition.types = null !== prevTransition ? prevTransition.types : null;
		ReactSharedInternals.T = currentTransition;
		dispatchOptimisticSetState(fiber, !1, queue, pendingState);
		try {
			var returnValue = callback(), onStartTransitionFinish = ReactSharedInternals.S;
			null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
			if (null !== returnValue && "object" === typeof returnValue && "function" === typeof returnValue.then) dispatchSetStateInternal(fiber, queue, chainThenableValue(returnValue, finishedState), requestUpdateLane(fiber));
			else dispatchSetStateInternal(fiber, queue, finishedState, requestUpdateLane(fiber));
		} catch (error) {
			dispatchSetStateInternal(fiber, queue, {
				then: function() {},
				status: "rejected",
				reason: error
			}, requestUpdateLane());
		} finally {
			ReactDOMSharedInternals.p = previousPriority, null !== prevTransition && null !== currentTransition.types && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
		}
	}
	function noop() {}
	function startHostTransition(formFiber, pendingState, action, formData) {
		if (5 !== formFiber.tag) throw Error(formatProdErrorMessage(476));
		var queue = ensureFormComponentIsStateful(formFiber).queue;
		startTransition(formFiber, queue, pendingState, sharedNotPendingObject, null === action ? noop : function() {
			requestFormReset$1(formFiber);
			return action(formData);
		});
	}
	function ensureFormComponentIsStateful(formFiber) {
		var existingStateHook = formFiber.memoizedState;
		if (null !== existingStateHook) return existingStateHook;
		existingStateHook = {
			memoizedState: sharedNotPendingObject,
			baseState: sharedNotPendingObject,
			baseQueue: null,
			queue: {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: basicStateReducer,
				lastRenderedState: sharedNotPendingObject
			},
			next: null
		};
		var initialResetState = {};
		existingStateHook.next = {
			memoizedState: initialResetState,
			baseState: initialResetState,
			baseQueue: null,
			queue: {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: basicStateReducer,
				lastRenderedState: initialResetState
			},
			next: null
		};
		formFiber.memoizedState = existingStateHook;
		formFiber = formFiber.alternate;
		null !== formFiber && (formFiber.memoizedState = existingStateHook);
		return existingStateHook;
	}
	function requestFormReset$1(formFiber) {
		var stateHook = ensureFormComponentIsStateful(formFiber);
		null === stateHook.next && (stateHook = formFiber.alternate.memoizedState);
		dispatchSetStateInternal(formFiber, stateHook.next.queue, {}, requestUpdateLane());
	}
	function useHostTransitionStatus() {
		return readContext(HostTransitionContext);
	}
	function updateId() {
		return updateWorkInProgressHook().memoizedState;
	}
	function updateRefresh() {
		return updateWorkInProgressHook().memoizedState;
	}
	function refreshCache(fiber) {
		for (var provider = fiber.return; null !== provider;) {
			switch (provider.tag) {
				case 24:
				case 3:
					var lane = requestUpdateLane();
					fiber = createUpdate(lane);
					var root$73 = enqueueUpdate(provider, fiber, lane);
					null !== root$73 && (scheduleUpdateOnFiber(root$73, provider, lane), entangleTransitions(root$73, provider, lane));
					provider = { cache: createCache() };
					fiber.payload = provider;
					return;
			}
			provider = provider.return;
		}
	}
	function dispatchReducerAction(fiber, queue, action) {
		var lane = requestUpdateLane();
		action = {
			lane,
			revertLane: 0,
			gesture: null,
			action,
			hasEagerState: !1,
			eagerState: null,
			next: null
		};
		isRenderPhaseUpdate(fiber) ? enqueueRenderPhaseUpdate(queue, action) : (action = enqueueConcurrentHookUpdate(fiber, queue, action, lane), null !== action && (scheduleUpdateOnFiber(action, fiber, lane), entangleTransitionUpdate(action, queue, lane)));
	}
	function dispatchSetState(fiber, queue, action) {
		dispatchSetStateInternal(fiber, queue, action, requestUpdateLane());
	}
	function dispatchSetStateInternal(fiber, queue, action, lane) {
		var update = {
			lane,
			revertLane: 0,
			gesture: null,
			action,
			hasEagerState: !1,
			eagerState: null,
			next: null
		};
		if (isRenderPhaseUpdate(fiber)) enqueueRenderPhaseUpdate(queue, update);
		else {
			var alternate = fiber.alternate;
			if (0 === fiber.lanes && (null === alternate || 0 === alternate.lanes) && (alternate = queue.lastRenderedReducer, null !== alternate)) try {
				var currentState = queue.lastRenderedState, eagerState = alternate(currentState, action);
				update.hasEagerState = !0;
				update.eagerState = eagerState;
				if (objectIs(eagerState, currentState)) return enqueueUpdate$1(fiber, queue, update, 0), null === workInProgressRoot && finishQueueingConcurrentUpdates(), !1;
			} catch (error) {}
			action = enqueueConcurrentHookUpdate(fiber, queue, update, lane);
			if (null !== action) return scheduleUpdateOnFiber(action, fiber, lane), entangleTransitionUpdate(action, queue, lane), !0;
		}
		return !1;
	}
	function dispatchOptimisticSetState(fiber, throwIfDuringRender, queue, action) {
		action = {
			lane: 2,
			revertLane: requestTransitionLane(),
			gesture: null,
			action,
			hasEagerState: !1,
			eagerState: null,
			next: null
		};
		if (isRenderPhaseUpdate(fiber)) {
			if (throwIfDuringRender) throw Error(formatProdErrorMessage(479));
		} else throwIfDuringRender = enqueueConcurrentHookUpdate(fiber, queue, action, 2), null !== throwIfDuringRender && scheduleUpdateOnFiber(throwIfDuringRender, fiber, 2);
	}
	function isRenderPhaseUpdate(fiber) {
		var alternate = fiber.alternate;
		return fiber === currentlyRenderingFiber || null !== alternate && alternate === currentlyRenderingFiber;
	}
	function enqueueRenderPhaseUpdate(queue, update) {
		didScheduleRenderPhaseUpdateDuringThisPass = didScheduleRenderPhaseUpdate = !0;
		var pending = queue.pending;
		null === pending ? update.next = update : (update.next = pending.next, pending.next = update);
		queue.pending = update;
	}
	function entangleTransitionUpdate(root, queue, lane) {
		if (0 !== (lane & 4194048)) {
			var queueLanes = queue.lanes;
			queueLanes &= root.pendingLanes;
			lane |= queueLanes;
			queue.lanes = lane;
			markRootEntangled(root, lane);
		}
	}
	var ContextOnlyDispatcher = {
		readContext,
		use,
		useCallback: throwInvalidHookError,
		useContext: throwInvalidHookError,
		useEffect: throwInvalidHookError,
		useImperativeHandle: throwInvalidHookError,
		useLayoutEffect: throwInvalidHookError,
		useInsertionEffect: throwInvalidHookError,
		useMemo: throwInvalidHookError,
		useReducer: throwInvalidHookError,
		useRef: throwInvalidHookError,
		useState: throwInvalidHookError,
		useDebugValue: throwInvalidHookError,
		useDeferredValue: throwInvalidHookError,
		useTransition: throwInvalidHookError,
		useSyncExternalStore: throwInvalidHookError,
		useId: throwInvalidHookError,
		useHostTransitionStatus: throwInvalidHookError,
		useFormState: throwInvalidHookError,
		useActionState: throwInvalidHookError,
		useOptimistic: throwInvalidHookError,
		useMemoCache: throwInvalidHookError,
		useCacheRefresh: throwInvalidHookError,
		useEffectEvent: throwInvalidHookError
	};
	var HooksDispatcherOnMount = {
		readContext,
		use,
		useCallback: function(callback, deps) {
			mountWorkInProgressHook().memoizedState = [callback, void 0 === deps ? null : deps];
			return callback;
		},
		useContext: readContext,
		useEffect: mountEffect,
		useImperativeHandle: function(ref, create, deps) {
			deps = null !== deps && void 0 !== deps ? deps.concat([ref]) : null;
			mountEffectImpl(4194308, 4, imperativeHandleEffect.bind(null, create, ref), deps);
		},
		useLayoutEffect: function(create, deps) {
			return mountEffectImpl(4194308, 4, create, deps);
		},
		useInsertionEffect: function(create, deps) {
			mountEffectImpl(4, 2, create, deps);
		},
		useMemo: function(nextCreate, deps) {
			var hook = mountWorkInProgressHook();
			deps = void 0 === deps ? null : deps;
			var nextValue = nextCreate();
			if (shouldDoubleInvokeUserFnsInHooksDEV) {
				setIsStrictModeForDevtools(!0);
				try {
					nextCreate();
				} finally {
					setIsStrictModeForDevtools(!1);
				}
			}
			hook.memoizedState = [nextValue, deps];
			return nextValue;
		},
		useReducer: function(reducer, initialArg, init) {
			var hook = mountWorkInProgressHook();
			if (void 0 !== init) {
				var initialState = init(initialArg);
				if (shouldDoubleInvokeUserFnsInHooksDEV) {
					setIsStrictModeForDevtools(!0);
					try {
						init(initialArg);
					} finally {
						setIsStrictModeForDevtools(!1);
					}
				}
			} else initialState = initialArg;
			hook.memoizedState = hook.baseState = initialState;
			reducer = {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: reducer,
				lastRenderedState: initialState
			};
			hook.queue = reducer;
			reducer = reducer.dispatch = dispatchReducerAction.bind(null, currentlyRenderingFiber, reducer);
			return [hook.memoizedState, reducer];
		},
		useRef: function(initialValue) {
			var hook = mountWorkInProgressHook();
			initialValue = { current: initialValue };
			return hook.memoizedState = initialValue;
		},
		useState: function(initialState) {
			initialState = mountStateImpl(initialState);
			var queue = initialState.queue, dispatch = dispatchSetState.bind(null, currentlyRenderingFiber, queue);
			queue.dispatch = dispatch;
			return [initialState.memoizedState, dispatch];
		},
		useDebugValue: mountDebugValue,
		useDeferredValue: function(value, initialValue) {
			return mountDeferredValueImpl(mountWorkInProgressHook(), value, initialValue);
		},
		useTransition: function() {
			var stateHook = mountStateImpl(!1);
			stateHook = startTransition.bind(null, currentlyRenderingFiber, stateHook.queue, !0, !1);
			mountWorkInProgressHook().memoizedState = stateHook;
			return [!1, stateHook];
		},
		useSyncExternalStore: function(subscribe, getSnapshot, getServerSnapshot) {
			var fiber = currentlyRenderingFiber, hook = mountWorkInProgressHook();
			if (isHydrating) {
				if (void 0 === getServerSnapshot) throw Error(formatProdErrorMessage(407));
				getServerSnapshot = getServerSnapshot();
			} else {
				getServerSnapshot = getSnapshot();
				if (null === workInProgressRoot) throw Error(formatProdErrorMessage(349));
				0 !== (workInProgressRootRenderLanes & 127) || pushStoreConsistencyCheck(fiber, getSnapshot, getServerSnapshot);
			}
			hook.memoizedState = getServerSnapshot;
			var inst = {
				value: getServerSnapshot,
				getSnapshot
			};
			hook.queue = inst;
			mountEffect(subscribeToStore.bind(null, fiber, inst, subscribe), [subscribe]);
			fiber.flags |= 2048;
			pushSimpleEffect(9, { destroy: void 0 }, updateStoreInstance.bind(null, fiber, inst, getServerSnapshot, getSnapshot), null);
			return getServerSnapshot;
		},
		useId: function() {
			var hook = mountWorkInProgressHook(), identifierPrefix = workInProgressRoot.identifierPrefix;
			if (isHydrating) {
				var JSCompiler_inline_result = treeContextOverflow;
				var idWithLeadingBit = treeContextId;
				JSCompiler_inline_result = (idWithLeadingBit & ~(1 << 32 - clz32(idWithLeadingBit) - 1)).toString(32) + JSCompiler_inline_result;
				identifierPrefix = "_" + identifierPrefix + "R_" + JSCompiler_inline_result;
				JSCompiler_inline_result = localIdCounter++;
				0 < JSCompiler_inline_result && (identifierPrefix += "H" + JSCompiler_inline_result.toString(32));
				identifierPrefix += "_";
			} else JSCompiler_inline_result = globalClientIdCounter++, identifierPrefix = "_" + identifierPrefix + "r_" + JSCompiler_inline_result.toString(32) + "_";
			return hook.memoizedState = identifierPrefix;
		},
		useHostTransitionStatus,
		useFormState: mountActionState,
		useActionState: mountActionState,
		useOptimistic: function(passthrough) {
			var hook = mountWorkInProgressHook();
			hook.memoizedState = hook.baseState = passthrough;
			var queue = {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: null,
				lastRenderedState: null
			};
			hook.queue = queue;
			hook = dispatchOptimisticSetState.bind(null, currentlyRenderingFiber, !0, queue);
			queue.dispatch = hook;
			return [passthrough, hook];
		},
		useMemoCache,
		useCacheRefresh: function() {
			return mountWorkInProgressHook().memoizedState = refreshCache.bind(null, currentlyRenderingFiber);
		},
		useEffectEvent: function(callback) {
			var hook = mountWorkInProgressHook(), ref = { impl: callback };
			hook.memoizedState = ref;
			return function() {
				if (0 !== (executionContext & 2)) throw Error(formatProdErrorMessage(440));
				return ref.impl.apply(void 0, arguments);
			};
		}
	};
	var HooksDispatcherOnUpdate = {
		readContext,
		use,
		useCallback: updateCallback,
		useContext: readContext,
		useEffect: updateEffect,
		useImperativeHandle: updateImperativeHandle,
		useInsertionEffect: updateInsertionEffect,
		useLayoutEffect: updateLayoutEffect,
		useMemo: updateMemo,
		useReducer: updateReducer,
		useRef: updateRef,
		useState: function() {
			return updateReducer(basicStateReducer);
		},
		useDebugValue: mountDebugValue,
		useDeferredValue: function(value, initialValue) {
			return updateDeferredValueImpl(updateWorkInProgressHook(), currentHook.memoizedState, value, initialValue);
		},
		useTransition: function() {
			var booleanOrThenable = updateReducer(basicStateReducer)[0], start = updateWorkInProgressHook().memoizedState;
			return ["boolean" === typeof booleanOrThenable ? booleanOrThenable : useThenable(booleanOrThenable), start];
		},
		useSyncExternalStore: updateSyncExternalStore,
		useId: updateId,
		useHostTransitionStatus,
		useFormState: updateActionState,
		useActionState: updateActionState,
		useOptimistic: function(passthrough, reducer) {
			return updateOptimisticImpl(updateWorkInProgressHook(), currentHook, passthrough, reducer);
		},
		useMemoCache,
		useCacheRefresh: updateRefresh,
		useEffectEvent: updateEvent
	};
	var HooksDispatcherOnRerender = {
		readContext,
		use,
		useCallback: updateCallback,
		useContext: readContext,
		useEffect: updateEffect,
		useImperativeHandle: updateImperativeHandle,
		useInsertionEffect: updateInsertionEffect,
		useLayoutEffect: updateLayoutEffect,
		useMemo: updateMemo,
		useReducer: rerenderReducer,
		useRef: updateRef,
		useState: function() {
			return rerenderReducer(basicStateReducer);
		},
		useDebugValue: mountDebugValue,
		useDeferredValue: function(value, initialValue) {
			var hook = updateWorkInProgressHook();
			return null === currentHook ? mountDeferredValueImpl(hook, value, initialValue) : updateDeferredValueImpl(hook, currentHook.memoizedState, value, initialValue);
		},
		useTransition: function() {
			var booleanOrThenable = rerenderReducer(basicStateReducer)[0], start = updateWorkInProgressHook().memoizedState;
			return ["boolean" === typeof booleanOrThenable ? booleanOrThenable : useThenable(booleanOrThenable), start];
		},
		useSyncExternalStore: updateSyncExternalStore,
		useId: updateId,
		useHostTransitionStatus,
		useFormState: rerenderActionState,
		useActionState: rerenderActionState,
		useOptimistic: function(passthrough, reducer) {
			var hook = updateWorkInProgressHook();
			if (null !== currentHook) return updateOptimisticImpl(hook, currentHook, passthrough, reducer);
			hook.baseState = passthrough;
			return [passthrough, hook.queue.dispatch];
		},
		useMemoCache,
		useCacheRefresh: updateRefresh,
		useEffectEvent: updateEvent
	};
	function applyDerivedStateFromProps(workInProgress, ctor, getDerivedStateFromProps, nextProps) {
		ctor = workInProgress.memoizedState;
		getDerivedStateFromProps = getDerivedStateFromProps(nextProps, ctor);
		getDerivedStateFromProps = null === getDerivedStateFromProps || void 0 === getDerivedStateFromProps ? ctor : assign({}, ctor, getDerivedStateFromProps);
		workInProgress.memoizedState = getDerivedStateFromProps;
		0 === workInProgress.lanes && (workInProgress.updateQueue.baseState = getDerivedStateFromProps);
	}
	var classComponentUpdater = {
		enqueueSetState: function(inst, payload, callback) {
			inst = inst._reactInternals;
			var lane = requestUpdateLane(), update = createUpdate(lane);
			update.payload = payload;
			void 0 !== callback && null !== callback && (update.callback = callback);
			payload = enqueueUpdate(inst, update, lane);
			null !== payload && (scheduleUpdateOnFiber(payload, inst, lane), entangleTransitions(payload, inst, lane));
		},
		enqueueReplaceState: function(inst, payload, callback) {
			inst = inst._reactInternals;
			var lane = requestUpdateLane(), update = createUpdate(lane);
			update.tag = 1;
			update.payload = payload;
			void 0 !== callback && null !== callback && (update.callback = callback);
			payload = enqueueUpdate(inst, update, lane);
			null !== payload && (scheduleUpdateOnFiber(payload, inst, lane), entangleTransitions(payload, inst, lane));
		},
		enqueueForceUpdate: function(inst, callback) {
			inst = inst._reactInternals;
			var lane = requestUpdateLane(), update = createUpdate(lane);
			update.tag = 2;
			void 0 !== callback && null !== callback && (update.callback = callback);
			callback = enqueueUpdate(inst, update, lane);
			null !== callback && (scheduleUpdateOnFiber(callback, inst, lane), entangleTransitions(callback, inst, lane));
		}
	};
	function checkShouldComponentUpdate(workInProgress, ctor, oldProps, newProps, oldState, newState, nextContext) {
		workInProgress = workInProgress.stateNode;
		return "function" === typeof workInProgress.shouldComponentUpdate ? workInProgress.shouldComponentUpdate(newProps, newState, nextContext) : ctor.prototype && ctor.prototype.isPureReactComponent ? !shallowEqual(oldProps, newProps) || !shallowEqual(oldState, newState) : !0;
	}
	function callComponentWillReceiveProps(workInProgress, instance, newProps, nextContext) {
		workInProgress = instance.state;
		"function" === typeof instance.componentWillReceiveProps && instance.componentWillReceiveProps(newProps, nextContext);
		"function" === typeof instance.UNSAFE_componentWillReceiveProps && instance.UNSAFE_componentWillReceiveProps(newProps, nextContext);
		instance.state !== workInProgress && classComponentUpdater.enqueueReplaceState(instance, instance.state, null);
	}
	function resolveClassComponentProps(Component, baseProps) {
		var newProps = baseProps;
		if ("ref" in baseProps) {
			newProps = {};
			for (var propName in baseProps) "ref" !== propName && (newProps[propName] = baseProps[propName]);
		}
		if (Component = Component.defaultProps) {
			newProps === baseProps && (newProps = assign({}, newProps));
			for (var propName$77 in Component) void 0 === newProps[propName$77] && (newProps[propName$77] = Component[propName$77]);
		}
		return newProps;
	}
	function defaultOnUncaughtError(error) {
		reportGlobalError(error);
	}
	function defaultOnCaughtError(error) {
		console.error(error);
	}
	function defaultOnRecoverableError(error) {
		reportGlobalError(error);
	}
	function logUncaughtError(root, errorInfo) {
		try {
			var onUncaughtError = root.onUncaughtError;
			onUncaughtError(errorInfo.value, { componentStack: errorInfo.stack });
		} catch (e$78) {
			setTimeout(function() {
				throw e$78;
			});
		}
	}
	function logCaughtError(root, boundary, errorInfo) {
		try {
			var onCaughtError = root.onCaughtError;
			onCaughtError(errorInfo.value, {
				componentStack: errorInfo.stack,
				errorBoundary: 1 === boundary.tag ? boundary.stateNode : null
			});
		} catch (e$79) {
			setTimeout(function() {
				throw e$79;
			});
		}
	}
	function createRootErrorUpdate(root, errorInfo, lane) {
		lane = createUpdate(lane);
		lane.tag = 3;
		lane.payload = { element: null };
		lane.callback = function() {
			logUncaughtError(root, errorInfo);
		};
		return lane;
	}
	function createClassErrorUpdate(lane) {
		lane = createUpdate(lane);
		lane.tag = 3;
		return lane;
	}
	function initializeClassErrorUpdate(update, root, fiber, errorInfo) {
		var getDerivedStateFromError = fiber.type.getDerivedStateFromError;
		if ("function" === typeof getDerivedStateFromError) {
			var error = errorInfo.value;
			update.payload = function() {
				return getDerivedStateFromError(error);
			};
			update.callback = function() {
				logCaughtError(root, fiber, errorInfo);
			};
		}
		var inst = fiber.stateNode;
		null !== inst && "function" === typeof inst.componentDidCatch && (update.callback = function() {
			logCaughtError(root, fiber, errorInfo);
			"function" !== typeof getDerivedStateFromError && (null === legacyErrorBoundariesThatAlreadyFailed ? legacyErrorBoundariesThatAlreadyFailed = /* @__PURE__ */ new Set([this]) : legacyErrorBoundariesThatAlreadyFailed.add(this));
			var stack = errorInfo.stack;
			this.componentDidCatch(errorInfo.value, { componentStack: null !== stack ? stack : "" });
		});
	}
	function throwException(root, returnFiber, sourceFiber, value, rootRenderLanes) {
		sourceFiber.flags |= 32768;
		if (null !== value && "object" === typeof value && "function" === typeof value.then) {
			returnFiber = sourceFiber.alternate;
			null !== returnFiber && propagateParentContextChanges(returnFiber, sourceFiber, rootRenderLanes, !0);
			sourceFiber = suspenseHandlerStackCursor.current;
			if (null !== sourceFiber) {
				switch (sourceFiber.tag) {
					case 31:
					case 13:
					case 19: return null === shellBoundary ? renderDidSuspendDelayIfPossible() : null === sourceFiber.alternate && 0 === workInProgressRootExitStatus && (workInProgressRootExitStatus = 3), sourceFiber.flags &= -257, sourceFiber.flags |= 65536, sourceFiber.lanes = rootRenderLanes, value === noopSuspenseyCommitThenable ? sourceFiber.flags |= 16384 : (returnFiber = sourceFiber.updateQueue, null === returnFiber ? sourceFiber.updateQueue = /* @__PURE__ */ new Set([value]) : returnFiber.add(value), attachPingListener(root, value, rootRenderLanes)), !1;
					case 22: return sourceFiber.flags |= 65536, value === noopSuspenseyCommitThenable ? sourceFiber.flags |= 16384 : (returnFiber = sourceFiber.updateQueue, null === returnFiber ? (returnFiber = {
						transitions: null,
						markerInstances: null,
						retryQueue: /* @__PURE__ */ new Set([value])
					}, sourceFiber.updateQueue = returnFiber) : (sourceFiber = returnFiber.retryQueue, null === sourceFiber ? returnFiber.retryQueue = /* @__PURE__ */ new Set([value]) : sourceFiber.add(value)), attachPingListener(root, value, rootRenderLanes)), !1;
				}
				throw Error(formatProdErrorMessage(435, sourceFiber.tag));
			}
			attachPingListener(root, value, rootRenderLanes);
			renderDidSuspendDelayIfPossible();
			return !1;
		}
		if (isHydrating) return returnFiber = suspenseHandlerStackCursor.current, null !== returnFiber ? (0 === (returnFiber.flags & 65536) && (returnFiber.flags |= 256), returnFiber.flags |= 65536, returnFiber.lanes = rootRenderLanes, value !== HydrationMismatchException && (root = Error(formatProdErrorMessage(422), { cause: value }), queueHydrationError(createCapturedValueAtFiber(root, sourceFiber)))) : (value !== HydrationMismatchException && (returnFiber = Error(formatProdErrorMessage(423), { cause: value }), queueHydrationError(createCapturedValueAtFiber(returnFiber, sourceFiber))), root = root.current.alternate, root.flags |= 65536, rootRenderLanes &= -rootRenderLanes, root.lanes |= rootRenderLanes, value = createCapturedValueAtFiber(value, sourceFiber), rootRenderLanes = createRootErrorUpdate(root.stateNode, value, rootRenderLanes), enqueueCapturedUpdate(root, rootRenderLanes), 4 !== workInProgressRootExitStatus && (workInProgressRootExitStatus = 2)), !1;
		var wrapperError = Error(formatProdErrorMessage(520), { cause: value });
		wrapperError = createCapturedValueAtFiber(wrapperError, sourceFiber);
		null === workInProgressRootConcurrentErrors ? workInProgressRootConcurrentErrors = [wrapperError] : workInProgressRootConcurrentErrors.push(wrapperError);
		4 !== workInProgressRootExitStatus && (workInProgressRootExitStatus = 2);
		if (null === returnFiber) return !0;
		value = createCapturedValueAtFiber(value, sourceFiber);
		sourceFiber = returnFiber;
		do {
			switch (sourceFiber.tag) {
				case 3: return sourceFiber.flags |= 65536, root = rootRenderLanes & -rootRenderLanes, sourceFiber.lanes |= root, root = createRootErrorUpdate(sourceFiber.stateNode, value, root), enqueueCapturedUpdate(sourceFiber, root), !1;
				case 1:
					returnFiber = sourceFiber.type;
					wrapperError = sourceFiber.stateNode;
					if (0 === (sourceFiber.flags & 128) && ("function" === typeof returnFiber.getDerivedStateFromError || null !== wrapperError && "function" === typeof wrapperError.componentDidCatch && (null === legacyErrorBoundariesThatAlreadyFailed || !legacyErrorBoundariesThatAlreadyFailed.has(wrapperError)))) return sourceFiber.flags |= 65536, rootRenderLanes &= -rootRenderLanes, sourceFiber.lanes |= rootRenderLanes, rootRenderLanes = createClassErrorUpdate(rootRenderLanes), initializeClassErrorUpdate(rootRenderLanes, root, sourceFiber, value), enqueueCapturedUpdate(sourceFiber, rootRenderLanes), !1;
					break;
				case 22: if (null !== sourceFiber.memoizedState) return sourceFiber.flags |= 65536, !1;
			}
			sourceFiber = sourceFiber.return;
		} while (null !== sourceFiber);
		return !1;
	}
	var SelectiveHydrationException = Error(formatProdErrorMessage(461));
	var didReceiveUpdate = !1;
	function reconcileChildren(current, workInProgress, nextChildren, renderLanes) {
		workInProgress.child = null === current ? mountChildFibers(workInProgress, null, nextChildren, renderLanes) : reconcileChildFibers(workInProgress, current.child, nextChildren, renderLanes);
	}
	function updateForwardRef(current, workInProgress, Component, nextProps, renderLanes) {
		Component = Component.render;
		var ref = workInProgress.ref;
		if ("ref" in nextProps) {
			var propsWithoutRef = {};
			for (var key in nextProps) "ref" !== key && (propsWithoutRef[key] = nextProps[key]);
		} else propsWithoutRef = nextProps;
		prepareToReadContext(workInProgress);
		nextProps = renderWithHooks(current, workInProgress, Component, propsWithoutRef, ref, renderLanes);
		key = checkDidRenderIdHook();
		if (null !== current && !didReceiveUpdate) return bailoutHooks(current, workInProgress, renderLanes), bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
		isHydrating && key && pushMaterializedTreeId(workInProgress);
		workInProgress.flags |= 1;
		reconcileChildren(current, workInProgress, nextProps, renderLanes);
		return workInProgress.child;
	}
	function updateMemoComponent(current, workInProgress, Component, nextProps, renderLanes) {
		if (null === current) {
			var type = Component.type;
			if ("function" === typeof type && !shouldConstruct(type) && void 0 === type.defaultProps && null === Component.compare) return workInProgress.tag = 15, workInProgress.type = type, updateSimpleMemoComponent(current, workInProgress, type, nextProps, renderLanes);
			current = createFiberFromTypeAndProps(Component.type, null, nextProps, workInProgress, workInProgress.mode, renderLanes);
			current.ref = workInProgress.ref;
			current.return = workInProgress;
			return workInProgress.child = current;
		}
		type = current.child;
		if (!checkScheduledUpdateOrContext(current, renderLanes)) {
			var prevProps = type.memoizedProps;
			Component = Component.compare;
			Component = null !== Component ? Component : shallowEqual;
			if (Component(prevProps, nextProps) && current.ref === workInProgress.ref) return bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
		}
		workInProgress.flags |= 1;
		current = createWorkInProgress(type, nextProps);
		current.ref = workInProgress.ref;
		current.return = workInProgress;
		return workInProgress.child = current;
	}
	function updateSimpleMemoComponent(current, workInProgress, Component, nextProps, renderLanes) {
		if (null !== current) {
			var prevProps = current.memoizedProps;
			if (shallowEqual(prevProps, nextProps) && current.ref === workInProgress.ref) if (didReceiveUpdate = !1, workInProgress.pendingProps = nextProps = prevProps, checkScheduledUpdateOrContext(current, renderLanes)) 0 !== (current.flags & 131072) && (didReceiveUpdate = !0);
			else return workInProgress.lanes = current.lanes, bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
		}
		return updateFunctionComponent(current, workInProgress, Component, nextProps, renderLanes);
	}
	function updateOffscreenComponent(current, workInProgress, renderLanes, nextProps) {
		var nextChildren = nextProps.children, prevState = null !== current ? current.memoizedState : null;
		null === current && null === workInProgress.stateNode && (workInProgress.stateNode = {
			_visibility: 1,
			_pendingMarkers: null,
			_retryCache: null,
			_transitions: null
		});
		if ("hidden" === nextProps.mode) {
			if (0 !== (workInProgress.flags & 128)) {
				prevState = null !== prevState ? prevState.baseLanes | renderLanes : renderLanes;
				if (null !== current) {
					nextProps = workInProgress.child = current.child;
					for (nextChildren = 0; null !== nextProps;) nextChildren = nextChildren | nextProps.lanes | nextProps.childLanes, nextProps = nextProps.sibling;
					nextProps = nextChildren & ~prevState;
				} else nextProps = 0, workInProgress.child = null;
				return deferHiddenOffscreenComponent(current, workInProgress, prevState, renderLanes, nextProps);
			}
			if (0 !== (renderLanes & 536870912)) workInProgress.memoizedState = {
				baseLanes: 0,
				cachePool: null
			}, null !== current && pushTransition(workInProgress, null !== prevState ? prevState.cachePool : null), null !== prevState ? pushHiddenContext(workInProgress, prevState) : reuseHiddenContextOnStack(), pushOffscreenSuspenseHandler(workInProgress);
			else return nextProps = workInProgress.lanes = 536870912, deferHiddenOffscreenComponent(current, workInProgress, null !== prevState ? prevState.baseLanes | renderLanes : renderLanes, renderLanes, nextProps);
		} else null !== prevState ? (pushTransition(workInProgress, prevState.cachePool), pushHiddenContext(workInProgress, prevState), reuseSuspenseHandlerOnStack(), workInProgress.memoizedState = null) : (null !== current && pushTransition(workInProgress, null), reuseHiddenContextOnStack(), reuseSuspenseHandlerOnStack());
		reconcileChildren(current, workInProgress, nextChildren, renderLanes);
		return workInProgress.child;
	}
	function bailoutOffscreenComponent(current, workInProgress) {
		null !== current && 22 === current.tag || null !== workInProgress.stateNode || (workInProgress.stateNode = {
			_visibility: 1,
			_pendingMarkers: null,
			_retryCache: null,
			_transitions: null
		});
		return workInProgress.sibling;
	}
	function deferHiddenOffscreenComponent(current, workInProgress, nextBaseLanes, renderLanes, remainingChildLanes) {
		var JSCompiler_inline_result = peekCacheFromPool();
		JSCompiler_inline_result = null === JSCompiler_inline_result ? null : {
			parent: CacheContext._currentValue,
			pool: JSCompiler_inline_result
		};
		workInProgress.memoizedState = {
			baseLanes: nextBaseLanes,
			cachePool: JSCompiler_inline_result
		};
		null !== current && pushTransition(workInProgress, null);
		reuseHiddenContextOnStack();
		pushOffscreenSuspenseHandler(workInProgress);
		null !== current && propagateParentContextChanges(current, workInProgress, renderLanes, !0);
		workInProgress.childLanes = remainingChildLanes;
		return null;
	}
	function mountActivityChildren(workInProgress, nextProps) {
		nextProps = mountWorkInProgressOffscreenFiber({
			mode: nextProps.mode,
			children: nextProps.children
		}, workInProgress.mode);
		nextProps.ref = workInProgress.ref;
		workInProgress.child = nextProps;
		nextProps.return = workInProgress;
		return nextProps;
	}
	function retryActivityComponentWithoutHydrating(current, workInProgress, renderLanes) {
		reconcileChildFibers(workInProgress, current.child, null, renderLanes);
		current = mountActivityChildren(workInProgress, workInProgress.pendingProps);
		current.flags |= 2;
		popSuspenseHandler(workInProgress);
		workInProgress.memoizedState = null;
		return current;
	}
	function updateActivityComponent(current, workInProgress, renderLanes) {
		var nextProps = workInProgress.pendingProps, didSuspend = 0 !== (workInProgress.flags & 128);
		workInProgress.flags &= -129;
		if (null === current) {
			if (isHydrating) {
				if ("hidden" === nextProps.mode) return current = mountActivityChildren(workInProgress, nextProps), workInProgress.lanes = 536870912, current.memoizedState = {
					baseLanes: 0,
					cachePool: null
				}, bailoutOffscreenComponent(null, current);
				pushDehydratedActivitySuspenseHandler(workInProgress);
				(current = nextHydratableInstance) ? (current = canHydrateHydrationBoundary(current, rootOrSingletonContext), current = null !== current && "&" === current.data ? current : null, null !== current && (workInProgress.memoizedState = {
					dehydrated: current,
					treeContext: null !== treeContextProvider ? {
						id: treeContextId,
						overflow: treeContextOverflow
					} : null,
					retryLane: 536870912,
					hydrationErrors: null
				}, renderLanes = createFiberFromDehydratedFragment(current), renderLanes.return = workInProgress, workInProgress.child = renderLanes, hydrationParentFiber = workInProgress, nextHydratableInstance = null)) : current = null;
				if (null === current) throw throwOnHydrationMismatch(workInProgress);
				workInProgress.lanes = 536870912;
				return null;
			}
			return mountActivityChildren(workInProgress, nextProps);
		}
		var prevState = current.memoizedState;
		if (null !== prevState) {
			var dehydrated = prevState.dehydrated;
			pushDehydratedActivitySuspenseHandler(workInProgress);
			if (didSuspend) if (workInProgress.flags & 256) workInProgress.flags &= -257, workInProgress = retryActivityComponentWithoutHydrating(current, workInProgress, renderLanes);
			else if (null !== workInProgress.memoizedState) workInProgress.child = current.child, workInProgress.flags |= 128, workInProgress = null;
			else throw Error(formatProdErrorMessage(558));
			else if (didReceiveUpdate || propagateParentContextChanges(current, workInProgress, renderLanes, !1), didSuspend = 0 !== (renderLanes & current.childLanes), didReceiveUpdate || didSuspend) {
				if (null === currentTreeHiddenStackCursor.current) {
					nextProps = workInProgressRoot;
					if (null !== nextProps && (dehydrated = getBumpedLaneForHydration(nextProps, renderLanes), 0 !== dehydrated && dehydrated !== prevState.retryLane)) throw prevState.retryLane = dehydrated, enqueueConcurrentRenderForLane(current, dehydrated), scheduleUpdateOnFiber(nextProps, current, dehydrated), SelectiveHydrationException;
					renderDidSuspendDelayIfPossible();
				}
				workInProgress = retryActivityComponentWithoutHydrating(current, workInProgress, renderLanes);
			} else current = prevState.treeContext, nextHydratableInstance = getNextHydratable(dehydrated.nextSibling), hydrationParentFiber = workInProgress, isHydrating = !0, hydrationErrors = null, rootOrSingletonContext = !1, null !== current && restoreSuspendedTreeContext(workInProgress, current), workInProgress = mountActivityChildren(workInProgress, nextProps), workInProgress.flags |= 134221824;
			return workInProgress;
		}
		current = createWorkInProgress(current.child, {
			mode: nextProps.mode,
			children: nextProps.children
		});
		current.ref = workInProgress.ref;
		workInProgress.child = current;
		current.return = workInProgress;
		return current;
	}
	function markRef(current, workInProgress) {
		var ref = workInProgress.ref;
		if (null === ref) null !== current && null !== current.ref && (workInProgress.flags |= 4194816);
		else {
			if ("function" !== typeof ref && "object" !== typeof ref) throw Error(formatProdErrorMessage(284));
			if (null === current || current.ref !== ref) workInProgress.flags |= 4194816;
		}
	}
	function updateFunctionComponent(current, workInProgress, Component, nextProps, renderLanes) {
		prepareToReadContext(workInProgress);
		Component = renderWithHooks(current, workInProgress, Component, nextProps, void 0, renderLanes);
		nextProps = checkDidRenderIdHook();
		if (null !== current && !didReceiveUpdate) return bailoutHooks(current, workInProgress, renderLanes), bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
		isHydrating && nextProps && pushMaterializedTreeId(workInProgress);
		workInProgress.flags |= 1;
		reconcileChildren(current, workInProgress, Component, renderLanes);
		return workInProgress.child;
	}
	function replayFunctionComponent(current, workInProgress, nextProps, Component, secondArg, renderLanes) {
		prepareToReadContext(workInProgress);
		workInProgress.updateQueue = null;
		nextProps = renderWithHooksAgain(workInProgress, Component, nextProps, secondArg);
		finishRenderingHooks(current);
		Component = checkDidRenderIdHook();
		if (null !== current && !didReceiveUpdate) return bailoutHooks(current, workInProgress, renderLanes), bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
		isHydrating && Component && pushMaterializedTreeId(workInProgress);
		workInProgress.flags |= 1;
		reconcileChildren(current, workInProgress, nextProps, renderLanes);
		return workInProgress.child;
	}
	function updateClassComponent(current, workInProgress, Component, nextProps, renderLanes) {
		prepareToReadContext(workInProgress);
		if (null === workInProgress.stateNode) {
			var context = emptyContextObject, contextType = Component.contextType;
			"object" === typeof contextType && null !== contextType && (context = readContext(contextType));
			context = new Component(nextProps, context);
			workInProgress.memoizedState = null !== context.state && void 0 !== context.state ? context.state : null;
			context.updater = classComponentUpdater;
			workInProgress.stateNode = context;
			context._reactInternals = workInProgress;
			context = workInProgress.stateNode;
			context.props = nextProps;
			context.state = workInProgress.memoizedState;
			context.refs = {};
			initializeUpdateQueue(workInProgress);
			contextType = Component.contextType;
			context.context = "object" === typeof contextType && null !== contextType ? readContext(contextType) : emptyContextObject;
			context.state = workInProgress.memoizedState;
			contextType = Component.getDerivedStateFromProps;
			"function" === typeof contextType && (applyDerivedStateFromProps(workInProgress, Component, contextType, nextProps), context.state = workInProgress.memoizedState);
			"function" === typeof Component.getDerivedStateFromProps || "function" === typeof context.getSnapshotBeforeUpdate || "function" !== typeof context.UNSAFE_componentWillMount && "function" !== typeof context.componentWillMount || (contextType = context.state, "function" === typeof context.componentWillMount && context.componentWillMount(), "function" === typeof context.UNSAFE_componentWillMount && context.UNSAFE_componentWillMount(), contextType !== context.state && classComponentUpdater.enqueueReplaceState(context, context.state, null), processUpdateQueue(workInProgress, nextProps, context, renderLanes), suspendIfUpdateReadFromEntangledAsyncAction(), context.state = workInProgress.memoizedState);
			"function" === typeof context.componentDidMount && (workInProgress.flags |= 4194308);
			nextProps = !0;
		} else if (null === current) {
			context = workInProgress.stateNode;
			var unresolvedOldProps = workInProgress.memoizedProps, oldProps = resolveClassComponentProps(Component, unresolvedOldProps);
			context.props = oldProps;
			var oldContext = context.context, contextType$jscomp$0 = Component.contextType;
			contextType = emptyContextObject;
			"object" === typeof contextType$jscomp$0 && null !== contextType$jscomp$0 && (contextType = readContext(contextType$jscomp$0));
			var getDerivedStateFromProps = Component.getDerivedStateFromProps;
			contextType$jscomp$0 = "function" === typeof getDerivedStateFromProps || "function" === typeof context.getSnapshotBeforeUpdate;
			unresolvedOldProps = workInProgress.pendingProps !== unresolvedOldProps;
			contextType$jscomp$0 || "function" !== typeof context.UNSAFE_componentWillReceiveProps && "function" !== typeof context.componentWillReceiveProps || (unresolvedOldProps || oldContext !== contextType) && callComponentWillReceiveProps(workInProgress, context, nextProps, contextType);
			hasForceUpdate = !1;
			var oldState = workInProgress.memoizedState;
			context.state = oldState;
			processUpdateQueue(workInProgress, nextProps, context, renderLanes);
			suspendIfUpdateReadFromEntangledAsyncAction();
			oldContext = workInProgress.memoizedState;
			unresolvedOldProps || oldState !== oldContext || hasForceUpdate ? ("function" === typeof getDerivedStateFromProps && (applyDerivedStateFromProps(workInProgress, Component, getDerivedStateFromProps, nextProps), oldContext = workInProgress.memoizedState), (oldProps = hasForceUpdate || checkShouldComponentUpdate(workInProgress, Component, oldProps, nextProps, oldState, oldContext, contextType)) ? (contextType$jscomp$0 || "function" !== typeof context.UNSAFE_componentWillMount && "function" !== typeof context.componentWillMount || ("function" === typeof context.componentWillMount && context.componentWillMount(), "function" === typeof context.UNSAFE_componentWillMount && context.UNSAFE_componentWillMount()), "function" === typeof context.componentDidMount && (workInProgress.flags |= 4194308)) : ("function" === typeof context.componentDidMount && (workInProgress.flags |= 4194308), workInProgress.memoizedProps = nextProps, workInProgress.memoizedState = oldContext), context.props = nextProps, context.state = oldContext, context.context = contextType, nextProps = oldProps) : ("function" === typeof context.componentDidMount && (workInProgress.flags |= 4194308), nextProps = !1);
		} else {
			context = workInProgress.stateNode;
			cloneUpdateQueue(current, workInProgress);
			contextType = workInProgress.memoizedProps;
			contextType$jscomp$0 = resolveClassComponentProps(Component, contextType);
			context.props = contextType$jscomp$0;
			getDerivedStateFromProps = workInProgress.pendingProps;
			oldState = context.context;
			oldContext = Component.contextType;
			oldProps = emptyContextObject;
			"object" === typeof oldContext && null !== oldContext && (oldProps = readContext(oldContext));
			unresolvedOldProps = Component.getDerivedStateFromProps;
			(oldContext = "function" === typeof unresolvedOldProps || "function" === typeof context.getSnapshotBeforeUpdate) || "function" !== typeof context.UNSAFE_componentWillReceiveProps && "function" !== typeof context.componentWillReceiveProps || (contextType !== getDerivedStateFromProps || oldState !== oldProps) && callComponentWillReceiveProps(workInProgress, context, nextProps, oldProps);
			hasForceUpdate = !1;
			oldState = workInProgress.memoizedState;
			context.state = oldState;
			processUpdateQueue(workInProgress, nextProps, context, renderLanes);
			suspendIfUpdateReadFromEntangledAsyncAction();
			var newState = workInProgress.memoizedState;
			contextType !== getDerivedStateFromProps || oldState !== newState || hasForceUpdate || null !== current && null !== current.dependencies && checkIfContextChanged(current.dependencies) ? ("function" === typeof unresolvedOldProps && (applyDerivedStateFromProps(workInProgress, Component, unresolvedOldProps, nextProps), newState = workInProgress.memoizedState), (contextType$jscomp$0 = hasForceUpdate || checkShouldComponentUpdate(workInProgress, Component, contextType$jscomp$0, nextProps, oldState, newState, oldProps) || null !== current && null !== current.dependencies && checkIfContextChanged(current.dependencies)) ? (oldContext || "function" !== typeof context.UNSAFE_componentWillUpdate && "function" !== typeof context.componentWillUpdate || ("function" === typeof context.componentWillUpdate && context.componentWillUpdate(nextProps, newState, oldProps), "function" === typeof context.UNSAFE_componentWillUpdate && context.UNSAFE_componentWillUpdate(nextProps, newState, oldProps)), "function" === typeof context.componentDidUpdate && (workInProgress.flags |= 4), "function" === typeof context.getSnapshotBeforeUpdate && (workInProgress.flags |= 1024)) : ("function" !== typeof context.componentDidUpdate || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 4), "function" !== typeof context.getSnapshotBeforeUpdate || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 1024), workInProgress.memoizedProps = nextProps, workInProgress.memoizedState = newState), context.props = nextProps, context.state = newState, context.context = oldProps, nextProps = contextType$jscomp$0) : ("function" !== typeof context.componentDidUpdate || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 4), "function" !== typeof context.getSnapshotBeforeUpdate || contextType === current.memoizedProps && oldState === current.memoizedState || (workInProgress.flags |= 1024), nextProps = !1);
		}
		context = nextProps;
		markRef(current, workInProgress);
		nextProps = 0 !== (workInProgress.flags & 128);
		context || nextProps ? (context = workInProgress.stateNode, Component = nextProps && "function" !== typeof Component.getDerivedStateFromError ? null : context.render(), workInProgress.flags |= 1, null !== current && nextProps ? (workInProgress.child = reconcileChildFibers(workInProgress, current.child, null, renderLanes), workInProgress.child = reconcileChildFibers(workInProgress, null, Component, renderLanes)) : reconcileChildren(current, workInProgress, Component, renderLanes), workInProgress.memoizedState = context.state, current = workInProgress.child) : current = bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
		return current;
	}
	function mountHostRootWithoutHydrating(current, workInProgress, nextChildren, renderLanes) {
		resetHydrationState();
		workInProgress.flags |= 256;
		reconcileChildren(current, workInProgress, nextChildren, renderLanes);
		return workInProgress.child;
	}
	var SUSPENDED_MARKER = {
		dehydrated: null,
		treeContext: null,
		retryLane: 0,
		hydrationErrors: null
	};
	function mountSuspenseOffscreenState(renderLanes) {
		return {
			baseLanes: renderLanes,
			cachePool: getSuspendedCache()
		};
	}
	function getRemainingWorkInPrimaryTree(current, primaryTreeDidDefer, renderLanes) {
		current = null !== current ? current.childLanes & ~renderLanes : 0;
		primaryTreeDidDefer && (current |= workInProgressDeferredLane);
		return current;
	}
	function updateSuspenseComponent(current, workInProgress, renderLanes) {
		var nextProps = workInProgress.pendingProps, showFallback = !1, didSuspend = 0 !== (workInProgress.flags & 128), JSCompiler_temp;
		(JSCompiler_temp = didSuspend) || (JSCompiler_temp = null !== current && null === current.memoizedState ? !1 : 0 !== (suspenseStackCursor.current & 2));
		JSCompiler_temp && (showFallback = !0, workInProgress.flags &= -129);
		JSCompiler_temp = 0 !== (workInProgress.flags & 32);
		workInProgress.flags &= -33;
		if (null === current) {
			if (isHydrating) {
				showFallback ? pushPrimaryTreeSuspenseHandler(workInProgress) : reuseSuspenseHandlerOnStack();
				(current = nextHydratableInstance) ? (current = canHydrateHydrationBoundary(current, rootOrSingletonContext), current = null !== current && "&" !== current.data ? current : null, null !== current && (workInProgress.memoizedState = {
					dehydrated: current,
					treeContext: null !== treeContextProvider ? {
						id: treeContextId,
						overflow: treeContextOverflow
					} : null,
					retryLane: 536870912,
					hydrationErrors: null
				}, renderLanes = createFiberFromDehydratedFragment(current), renderLanes.return = workInProgress, workInProgress.child = renderLanes, hydrationParentFiber = workInProgress, nextHydratableInstance = null)) : current = null;
				if (null === current) throw throwOnHydrationMismatch(workInProgress);
				isSuspenseInstanceFallback(current) ? workInProgress.lanes = 32 : workInProgress.lanes = 536870912;
				return null;
			}
			didSuspend = nextProps.children;
			nextProps = nextProps.fallback;
			if (showFallback) return reuseSuspenseHandlerOnStack(), showFallback = workInProgress.mode, didSuspend = mountWorkInProgressOffscreenFiber({
				mode: "hidden",
				children: didSuspend
			}, showFallback), nextProps = createFiberFromFragment(nextProps, showFallback, renderLanes, null), didSuspend.return = workInProgress, nextProps.return = workInProgress, didSuspend.sibling = nextProps, workInProgress.child = didSuspend, nextProps = workInProgress.child, nextProps.memoizedState = mountSuspenseOffscreenState(renderLanes), nextProps.childLanes = getRemainingWorkInPrimaryTree(current, JSCompiler_temp, renderLanes), workInProgress.memoizedState = SUSPENDED_MARKER, bailoutOffscreenComponent(null, nextProps);
			pushPrimaryTreeSuspenseHandler(workInProgress);
			return mountSuspensePrimaryChildren(workInProgress, didSuspend);
		}
		var prevState = current.memoizedState;
		if (null !== prevState) {
			var dehydrated$96 = prevState.dehydrated;
			if (null !== dehydrated$96) return updateDehydratedSuspenseComponent(current, workInProgress, didSuspend, JSCompiler_temp, nextProps, dehydrated$96, prevState, renderLanes);
		}
		if (showFallback) return reuseSuspenseHandlerOnStack(), showFallback = nextProps.fallback, didSuspend = workInProgress.mode, prevState = current.child, dehydrated$96 = prevState.sibling, nextProps = createWorkInProgress(prevState, {
			mode: "hidden",
			children: nextProps.children
		}), nextProps.subtreeFlags = prevState.subtreeFlags & 1206910976, null !== dehydrated$96 ? showFallback = createWorkInProgress(dehydrated$96, showFallback) : (showFallback = createFiberFromFragment(showFallback, didSuspend, renderLanes, null), showFallback.flags |= 2), showFallback.return = workInProgress, nextProps.return = workInProgress, nextProps.sibling = showFallback, workInProgress.child = nextProps, bailoutOffscreenComponent(null, nextProps), nextProps = workInProgress.child, showFallback = current.child.memoizedState, null === showFallback ? showFallback = mountSuspenseOffscreenState(renderLanes) : (didSuspend = showFallback.cachePool, null !== didSuspend ? (prevState = CacheContext._currentValue, didSuspend = didSuspend.parent !== prevState ? {
			parent: prevState,
			pool: prevState
		} : didSuspend) : didSuspend = getSuspendedCache(), showFallback = {
			baseLanes: showFallback.baseLanes | renderLanes,
			cachePool: didSuspend
		}), nextProps.memoizedState = showFallback, nextProps.childLanes = getRemainingWorkInPrimaryTree(current, JSCompiler_temp, renderLanes), workInProgress.memoizedState = SUSPENDED_MARKER, bailoutOffscreenComponent(current.child, nextProps);
		pushPrimaryTreeSuspenseHandler(workInProgress);
		renderLanes = current.child;
		current = renderLanes.sibling;
		renderLanes = createWorkInProgress(renderLanes, {
			mode: "visible",
			children: nextProps.children
		});
		renderLanes.return = workInProgress;
		renderLanes.sibling = null;
		null !== current && (JSCompiler_temp = workInProgress.deletions, null === JSCompiler_temp ? (workInProgress.deletions = [current], workInProgress.flags |= 16) : JSCompiler_temp.push(current));
		workInProgress.child = renderLanes;
		workInProgress.memoizedState = null;
		return renderLanes;
	}
	function mountSuspensePrimaryChildren(workInProgress, primaryChildren) {
		primaryChildren = mountWorkInProgressOffscreenFiber({
			mode: "visible",
			children: primaryChildren
		}, workInProgress.mode);
		primaryChildren.return = workInProgress;
		return workInProgress.child = primaryChildren;
	}
	function mountWorkInProgressOffscreenFiber(offscreenProps, mode) {
		offscreenProps = createFiberImplClass(22, offscreenProps, null, mode);
		offscreenProps.lanes = 0;
		return offscreenProps;
	}
	function retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes) {
		reconcileChildFibers(workInProgress, current.child, null, renderLanes);
		current = mountSuspensePrimaryChildren(workInProgress, workInProgress.pendingProps.children);
		current.flags |= 2;
		workInProgress.memoizedState = null;
		return current;
	}
	function updateDehydratedSuspenseComponent(current, workInProgress, didSuspend, didPrimaryChildrenDefer, nextProps, suspenseInstance, suspenseState, renderLanes) {
		if (didSuspend) {
			if (workInProgress.flags & 256) return pushPrimaryTreeSuspenseHandler(workInProgress), workInProgress.flags &= -257, retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
			if (null !== workInProgress.memoizedState) return reuseSuspenseHandlerOnStack(), workInProgress.child = current.child, workInProgress.flags |= 128, null;
			reuseSuspenseHandlerOnStack();
			suspenseInstance = nextProps.fallback;
			suspenseState = workInProgress.mode;
			nextProps = mountWorkInProgressOffscreenFiber({
				mode: "visible",
				children: nextProps.children
			}, suspenseState);
			suspenseInstance = createFiberFromFragment(suspenseInstance, suspenseState, renderLanes, null);
			suspenseInstance.flags |= 2;
			nextProps.return = workInProgress;
			suspenseInstance.return = workInProgress;
			nextProps.sibling = suspenseInstance;
			workInProgress.child = nextProps;
			reconcileChildFibers(workInProgress, current.child, null, renderLanes);
			nextProps = workInProgress.child;
			nextProps.memoizedState = mountSuspenseOffscreenState(renderLanes);
			nextProps.childLanes = getRemainingWorkInPrimaryTree(current, didPrimaryChildrenDefer, renderLanes);
			workInProgress.memoizedState = SUSPENDED_MARKER;
			return bailoutOffscreenComponent(null, nextProps);
		}
		pushPrimaryTreeSuspenseHandler(workInProgress);
		if (isSuspenseInstanceFallback(suspenseInstance)) {
			didPrimaryChildrenDefer = suspenseInstance.nextSibling && suspenseInstance.nextSibling.dataset;
			if (didPrimaryChildrenDefer) var digest = didPrimaryChildrenDefer.dgst;
			didPrimaryChildrenDefer = digest;
			"" !== didPrimaryChildrenDefer && (nextProps = Error(formatProdErrorMessage(419)), nextProps.stack = "", nextProps.digest = didPrimaryChildrenDefer, queueHydrationError({
				value: nextProps,
				source: null,
				stack: null
			}));
			return retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
		}
		didReceiveUpdate || propagateParentContextChanges(current, workInProgress, renderLanes, !1);
		didPrimaryChildrenDefer = 0 !== (renderLanes & current.childLanes);
		if (didReceiveUpdate || didPrimaryChildrenDefer) {
			if (null !== currentTreeHiddenStackCursor.current) return retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
			didPrimaryChildrenDefer = workInProgressRoot;
			if (null !== didPrimaryChildrenDefer && (nextProps = getBumpedLaneForHydration(didPrimaryChildrenDefer, renderLanes), 0 !== nextProps && nextProps !== suspenseState.retryLane)) throw suspenseState.retryLane = nextProps, enqueueConcurrentRenderForLane(current, nextProps), scheduleUpdateOnFiber(didPrimaryChildrenDefer, current, nextProps), SelectiveHydrationException;
			isSuspenseInstancePending(suspenseInstance) || renderDidSuspendDelayIfPossible();
			return retrySuspenseComponentWithoutHydrating(current, workInProgress, renderLanes);
		}
		if (isSuspenseInstancePending(suspenseInstance)) return workInProgress.flags |= 192, workInProgress.child = current.child, null;
		current = suspenseState.treeContext;
		nextHydratableInstance = getNextHydratable(suspenseInstance.nextSibling);
		hydrationParentFiber = workInProgress;
		isHydrating = !0;
		hydrationErrors = null;
		rootOrSingletonContext = !1;
		null !== current && restoreSuspendedTreeContext(workInProgress, current);
		workInProgress = mountSuspensePrimaryChildren(workInProgress, nextProps.children);
		workInProgress.flags |= 134221824;
		return workInProgress;
	}
	function scheduleSuspenseWorkOnFiber(fiber, renderLanes, propagationRoot) {
		fiber.lanes |= renderLanes;
		var alternate = fiber.alternate;
		null !== alternate && (alternate.lanes |= renderLanes);
		scheduleContextWorkOnParentPath(fiber.return, renderLanes, propagationRoot);
	}
	function findLastContentRow(firstChild) {
		for (var lastContentRow = null; null !== firstChild;) {
			var currentRow = firstChild.alternate;
			null !== currentRow && null === findFirstSuspended(currentRow) && (lastContentRow = firstChild);
			firstChild = firstChild.sibling;
		}
		return lastContentRow;
	}
	function initSuspenseListRenderState(workInProgress, isBackwards, tail, lastContentRow, tailMode, treeForkCount) {
		var renderState = workInProgress.memoizedState;
		null === renderState ? workInProgress.memoizedState = {
			isBackwards,
			rendering: null,
			renderingStartTime: 0,
			last: lastContentRow,
			tail,
			tailMode,
			treeForkCount
		} : (renderState.isBackwards = isBackwards, renderState.rendering = null, renderState.renderingStartTime = 0, renderState.last = lastContentRow, renderState.tail = tail, renderState.tailMode = tailMode, renderState.treeForkCount = treeForkCount);
	}
	function reverseChildren(fiber) {
		var row = fiber.child;
		for (fiber.child = null; null !== row;) {
			var nextRow = row.sibling;
			row.sibling = fiber.child;
			fiber.child = row;
			row = nextRow;
		}
	}
	function updateSuspenseListComponent(current, workInProgress, renderLanes) {
		var nextProps = workInProgress.pendingProps, revealOrder = nextProps.revealOrder, tailMode = nextProps.tail;
		nextProps = nextProps.children;
		var suspenseContext = suspenseStackCursor.current;
		if (workInProgress.flags & 128) return pushSuspenseListContext(workInProgress, suspenseContext), null;
		var shouldForceFallback = 0 !== (suspenseContext & 2);
		shouldForceFallback ? (suspenseContext = suspenseContext & 1 | 2, workInProgress.flags |= 128) : suspenseContext &= 1;
		pushSuspenseListContext(workInProgress, suspenseContext);
		"backwards" === revealOrder && null !== current ? (reverseChildren(current), reconcileChildren(current, workInProgress, nextProps, renderLanes), reverseChildren(current)) : reconcileChildren(current, workInProgress, nextProps, renderLanes);
		nextProps = isHydrating ? treeForkCount : 0;
		if (!shouldForceFallback && null !== current && 0 !== (current.flags & 128)) a: for (current = workInProgress.child; null !== current;) {
			if (13 === current.tag) null !== current.memoizedState && scheduleSuspenseWorkOnFiber(current, renderLanes, workInProgress);
			else if (19 === current.tag) scheduleSuspenseWorkOnFiber(current, renderLanes, workInProgress);
			else if (null !== current.child) {
				current.child.return = current;
				current = current.child;
				continue;
			}
			if (current === workInProgress) break a;
			for (; null === current.sibling;) {
				if (null === current.return || current.return === workInProgress) break a;
				current = current.return;
			}
			current.sibling.return = current.return;
			current = current.sibling;
		}
		switch (revealOrder) {
			case "backwards":
				renderLanes = findLastContentRow(workInProgress.child);
				null === renderLanes ? (revealOrder = workInProgress.child, workInProgress.child = null) : (revealOrder = renderLanes.sibling, renderLanes.sibling = null, reverseChildren(workInProgress));
				initSuspenseListRenderState(workInProgress, !0, revealOrder, null, tailMode, nextProps);
				break;
			case "unstable_legacy-backwards":
				renderLanes = null;
				revealOrder = workInProgress.child;
				for (workInProgress.child = null; null !== revealOrder;) {
					current = revealOrder.alternate;
					if (null !== current && null === findFirstSuspended(current)) {
						workInProgress.child = revealOrder;
						break;
					}
					current = revealOrder.sibling;
					revealOrder.sibling = renderLanes;
					renderLanes = revealOrder;
					revealOrder = current;
				}
				initSuspenseListRenderState(workInProgress, !0, renderLanes, null, tailMode, nextProps);
				break;
			case "together":
				initSuspenseListRenderState(workInProgress, !1, null, null, void 0, nextProps);
				break;
			case "independent":
				workInProgress.memoizedState = null;
				break;
			default: renderLanes = findLastContentRow(workInProgress.child), null === renderLanes ? (revealOrder = workInProgress.child, workInProgress.child = null) : (revealOrder = renderLanes.sibling, renderLanes.sibling = null), initSuspenseListRenderState(workInProgress, !1, revealOrder, renderLanes, tailMode, nextProps);
		}
		return workInProgress.child;
	}
	function updateContextProvider(current, workInProgress, renderLanes) {
		var newProps = workInProgress.pendingProps;
		pushProvider(workInProgress, workInProgress.type, newProps.value);
		reconcileChildren(current, workInProgress, newProps.children, renderLanes);
		return workInProgress.child;
	}
	function bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes) {
		null !== current && (workInProgress.dependencies = current.dependencies);
		workInProgressRootSkippedLanes |= workInProgress.lanes;
		if (0 === (renderLanes & workInProgress.childLanes)) if (null !== current) {
			if (propagateParentContextChanges(current, workInProgress, renderLanes, !1), 0 === (renderLanes & workInProgress.childLanes)) return null;
		} else return null;
		if (null !== current && workInProgress.child !== current.child) throw Error(formatProdErrorMessage(153));
		if (null !== workInProgress.child) {
			current = workInProgress.child;
			renderLanes = createWorkInProgress(current, current.pendingProps);
			workInProgress.child = renderLanes;
			for (renderLanes.return = workInProgress; null !== current.sibling;) current = current.sibling, renderLanes = renderLanes.sibling = createWorkInProgress(current, current.pendingProps), renderLanes.return = workInProgress;
			renderLanes.sibling = null;
		}
		return workInProgress.child;
	}
	function checkScheduledUpdateOrContext(current, renderLanes) {
		if (0 !== (current.lanes & renderLanes)) return !0;
		current = current.dependencies;
		return null !== current && checkIfContextChanged(current) ? !0 : !1;
	}
	function attemptEarlyBailoutIfNoScheduledUpdate(current, workInProgress, renderLanes) {
		switch (workInProgress.tag) {
			case 3:
				pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo);
				pushProvider(workInProgress, CacheContext, current.memoizedState.cache);
				resetHydrationState();
				break;
			case 27:
			case 5:
				pushHostContext(workInProgress);
				break;
			case 4:
				pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo);
				break;
			case 10:
				pushProvider(workInProgress, workInProgress.type, workInProgress.memoizedProps.value);
				break;
			case 31:
				if (null !== workInProgress.memoizedState) return workInProgress.flags |= 128, pushDehydratedActivitySuspenseHandler(workInProgress), null;
				break;
			case 13:
				var state$108 = workInProgress.memoizedState;
				if (null !== state$108) {
					if (null !== state$108.dehydrated) return pushPrimaryTreeSuspenseHandler(workInProgress), workInProgress.flags |= 128, null;
					state$108 = propagateParentContextChanges(current, workInProgress, renderLanes, !1);
					var primaryChildLanes = workInProgress.child.childLanes;
					if (state$108 || 0 !== (renderLanes & primaryChildLanes)) return updateSuspenseComponent(current, workInProgress, renderLanes);
					pushPrimaryTreeSuspenseHandler(workInProgress);
					current = bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
					return null !== current ? current.sibling : null;
				}
				pushPrimaryTreeSuspenseHandler(workInProgress);
				break;
			case 19:
				if (workInProgress.flags & 128) return updateSuspenseListComponent(current, workInProgress, renderLanes);
				primaryChildLanes = 0 !== (current.flags & 128);
				state$108 = 0 !== (renderLanes & workInProgress.childLanes);
				state$108 || (propagateParentContextChanges(current, workInProgress, renderLanes, !1), state$108 = 0 !== (renderLanes & workInProgress.childLanes));
				if (primaryChildLanes) {
					if (state$108) return updateSuspenseListComponent(current, workInProgress, renderLanes);
					workInProgress.flags |= 128;
				}
				primaryChildLanes = workInProgress.memoizedState;
				null !== primaryChildLanes && (primaryChildLanes.rendering = null, primaryChildLanes.tail = null, primaryChildLanes.lastEffect = null);
				pushSuspenseListContext(workInProgress, suspenseStackCursor.current);
				if (state$108) break;
				else return null;
			case 22: return workInProgress.lanes = 0, updateOffscreenComponent(current, workInProgress, renderLanes, workInProgress.pendingProps);
			case 24: pushProvider(workInProgress, CacheContext, current.memoizedState.cache);
		}
		return bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
	}
	function beginWork(current, workInProgress, renderLanes) {
		if (null !== current) if (current.memoizedProps !== workInProgress.pendingProps) didReceiveUpdate = !0;
		else {
			if (!checkScheduledUpdateOrContext(current, renderLanes) && 0 === (workInProgress.flags & 128)) return didReceiveUpdate = !1, attemptEarlyBailoutIfNoScheduledUpdate(current, workInProgress, renderLanes);
			didReceiveUpdate = 0 !== (current.flags & 131072) ? !0 : !1;
		}
		else didReceiveUpdate = !1, isHydrating && 0 !== (workInProgress.flags & 1048576) && pushTreeId(workInProgress, treeForkCount, workInProgress.index);
		workInProgress.lanes = 0;
		switch (workInProgress.tag) {
			case 16:
				a: {
					var props = workInProgress.pendingProps;
					current = resolveLazy(workInProgress.elementType);
					workInProgress.type = current;
					if ("function" === typeof current) shouldConstruct(current) ? (props = resolveClassComponentProps(current, props), workInProgress.tag = 1, workInProgress = updateClassComponent(null, workInProgress, current, props, renderLanes)) : (workInProgress.tag = 0, workInProgress = updateFunctionComponent(null, workInProgress, current, props, renderLanes));
					else {
						if (void 0 !== current && null !== current) {
							var $$typeof = current.$$typeof;
							if ($$typeof === REACT_FORWARD_REF_TYPE) {
								workInProgress.tag = 11;
								workInProgress = updateForwardRef(null, workInProgress, current, props, renderLanes);
								break a;
							} else if ($$typeof === REACT_MEMO_TYPE) {
								workInProgress.tag = 14;
								workInProgress = updateMemoComponent(null, workInProgress, current, props, renderLanes);
								break a;
							} else if ($$typeof === REACT_CONTEXT_TYPE) {
								workInProgress.tag = 10;
								workInProgress.type = current;
								workInProgress = updateContextProvider(null, workInProgress, renderLanes);
								break a;
							}
						}
						workInProgress = getComponentNameFromType(current) || current;
						throw Error(formatProdErrorMessage(306, workInProgress, ""));
					}
				}
				return workInProgress;
			case 0: return updateFunctionComponent(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
			case 1: return props = workInProgress.type, $$typeof = resolveClassComponentProps(props, workInProgress.pendingProps), updateClassComponent(current, workInProgress, props, $$typeof, renderLanes);
			case 3:
				a: {
					pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo);
					if (null === current) throw Error(formatProdErrorMessage(387));
					props = workInProgress.pendingProps;
					var prevState = workInProgress.memoizedState;
					$$typeof = prevState.element;
					cloneUpdateQueue(current, workInProgress);
					processUpdateQueue(workInProgress, props, null, renderLanes);
					var nextState = workInProgress.memoizedState;
					props = nextState.cache;
					pushProvider(workInProgress, CacheContext, props);
					props !== prevState.cache && propagateContextChanges(workInProgress, [CacheContext], renderLanes, !0);
					suspendIfUpdateReadFromEntangledAsyncAction();
					props = nextState.element;
					if (prevState.isDehydrated) if (prevState = {
						element: props,
						isDehydrated: !1,
						cache: nextState.cache
					}, workInProgress.updateQueue.baseState = prevState, workInProgress.memoizedState = prevState, workInProgress.flags & 256) {
						workInProgress = mountHostRootWithoutHydrating(current, workInProgress, props, renderLanes);
						break a;
					} else if (props !== $$typeof) {
						$$typeof = createCapturedValueAtFiber(Error(formatProdErrorMessage(424)), workInProgress);
						queueHydrationError($$typeof);
						workInProgress = mountHostRootWithoutHydrating(current, workInProgress, props, renderLanes);
						break a;
					} else {
						current = workInProgress.stateNode.containerInfo;
						switch (current.nodeType) {
							case 9:
								current = current.body;
								break;
							default: current = "HTML" === current.nodeName ? current.ownerDocument.body : current;
						}
						nextHydratableInstance = getNextHydratable(current.firstChild);
						hydrationParentFiber = workInProgress;
						isHydrating = !0;
						hydrationErrors = null;
						rootOrSingletonContext = !0;
						renderLanes = mountChildFibers(workInProgress, null, props, renderLanes);
						for (workInProgress.child = renderLanes; renderLanes;) renderLanes.flags = renderLanes.flags & -3 | 134221824, renderLanes = renderLanes.sibling;
					}
					else {
						resetHydrationState();
						if (props === $$typeof) {
							workInProgress = bailoutOnAlreadyFinishedWork(current, workInProgress, renderLanes);
							break a;
						}
						reconcileChildren(current, workInProgress, props, renderLanes);
					}
					workInProgress = workInProgress.child;
				}
				return workInProgress;
			case 26: return markRef(current, workInProgress), null === current ? (renderLanes = getResource(workInProgress.type, null, workInProgress.pendingProps, null)) ? workInProgress.memoizedState = renderLanes : isHydrating || (workInProgress.stateNode = createHoistableInstance(workInProgress.type, workInProgress.pendingProps, rootInstanceStackCursor.current, workInProgress)) : workInProgress.memoizedState = getResource(workInProgress.type, current.memoizedProps, workInProgress.pendingProps, current.memoizedState), null;
			case 27: return pushHostContext(workInProgress), null === current && isHydrating && (props = workInProgress.stateNode = resolveSingletonInstance(workInProgress.type, workInProgress.pendingProps, rootInstanceStackCursor.current), hydrationParentFiber = workInProgress, rootOrSingletonContext = !0, $$typeof = nextHydratableInstance, isSingletonScope(workInProgress.type) ? (previousHydratableOnEnteringScopedSingleton = $$typeof, nextHydratableInstance = getNextHydratable(props.firstChild)) : nextHydratableInstance = $$typeof), reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), markRef(current, workInProgress), null === current && (workInProgress.flags |= 4194304), workInProgress.child;
			case 5:
				if (null === current && isHydrating) {
					if ($$typeof = props = nextHydratableInstance) props = canHydrateInstance(props, workInProgress.type, workInProgress.pendingProps, rootOrSingletonContext), null !== props ? (workInProgress.stateNode = props, hydrationParentFiber = workInProgress, nextHydratableInstance = getNextHydratable(props.firstChild), rootOrSingletonContext = !1, $$typeof = !0) : $$typeof = !1;
					$$typeof || throwOnHydrationMismatch(workInProgress);
				}
				pushHostContext(workInProgress);
				$$typeof = workInProgress.type;
				prevState = workInProgress.pendingProps;
				nextState = null !== current ? current.memoizedProps : null;
				props = prevState.children;
				shouldSetTextContent($$typeof, prevState) ? props = null : null !== nextState && shouldSetTextContent($$typeof, nextState) && (workInProgress.flags |= 32);
				null !== workInProgress.memoizedState && ($$typeof = renderWithHooks(current, workInProgress, TransitionAwareHostComponent, null, null, renderLanes), HostTransitionContext._currentValue = $$typeof);
				markRef(current, workInProgress);
				reconcileChildren(current, workInProgress, props, renderLanes);
				return workInProgress.child;
			case 6:
				if (null === current && isHydrating) {
					if (current = renderLanes = nextHydratableInstance) renderLanes = canHydrateTextInstance(renderLanes, workInProgress.pendingProps, rootOrSingletonContext), null !== renderLanes ? (workInProgress.stateNode = renderLanes, hydrationParentFiber = workInProgress, nextHydratableInstance = null, current = !0) : current = !1;
					current || throwOnHydrationMismatch(workInProgress);
				}
				return null;
			case 13: return updateSuspenseComponent(current, workInProgress, renderLanes);
			case 4: return pushHostContainer(workInProgress, workInProgress.stateNode.containerInfo), props = workInProgress.pendingProps, null === current ? workInProgress.child = reconcileChildFibers(workInProgress, null, props, renderLanes) : reconcileChildren(current, workInProgress, props, renderLanes), workInProgress.child;
			case 11: return updateForwardRef(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
			case 7: return props = workInProgress.pendingProps, markRef(current, workInProgress), reconcileChildren(current, workInProgress, props, renderLanes), workInProgress.child;
			case 8: return reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), workInProgress.child;
			case 12: return reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), workInProgress.child;
			case 10: return updateContextProvider(current, workInProgress, renderLanes);
			case 9: return $$typeof = workInProgress.type._context, props = workInProgress.pendingProps.children, prepareToReadContext(workInProgress), $$typeof = readContext($$typeof), props = props($$typeof), workInProgress.flags |= 1, reconcileChildren(current, workInProgress, props, renderLanes), workInProgress.child;
			case 14: return updateMemoComponent(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
			case 15: return updateSimpleMemoComponent(current, workInProgress, workInProgress.type, workInProgress.pendingProps, renderLanes);
			case 19: return updateSuspenseListComponent(current, workInProgress, renderLanes);
			case 31: return updateActivityComponent(current, workInProgress, renderLanes);
			case 22: return updateOffscreenComponent(current, workInProgress, renderLanes, workInProgress.pendingProps);
			case 24: return prepareToReadContext(workInProgress), props = readContext(CacheContext), null === current ? ($$typeof = peekCacheFromPool(), null === $$typeof && ($$typeof = workInProgressRoot, prevState = createCache(), $$typeof.pooledCache = prevState, prevState.refCount++, null !== prevState && ($$typeof.pooledCacheLanes |= renderLanes), $$typeof = prevState), workInProgress.memoizedState = {
				parent: props,
				cache: $$typeof
			}, initializeUpdateQueue(workInProgress), pushProvider(workInProgress, CacheContext, $$typeof)) : (0 !== (current.lanes & renderLanes) && (cloneUpdateQueue(current, workInProgress), processUpdateQueue(workInProgress, null, null, renderLanes), suspendIfUpdateReadFromEntangledAsyncAction()), $$typeof = current.memoizedState, prevState = workInProgress.memoizedState, $$typeof.parent !== props ? ($$typeof = {
				parent: props,
				cache: props
			}, workInProgress.memoizedState = $$typeof, 0 === workInProgress.lanes && (workInProgress.memoizedState = workInProgress.updateQueue.baseState = $$typeof), pushProvider(workInProgress, CacheContext, props)) : (props = prevState.cache, pushProvider(workInProgress, CacheContext, props), props !== $$typeof.cache && propagateContextChanges(workInProgress, [CacheContext], renderLanes, !0))), reconcileChildren(current, workInProgress, workInProgress.pendingProps.children, renderLanes), workInProgress.child;
			case 30: return null === workInProgress.stateNode && (workInProgress.stateNode = {
				autoName: null,
				paired: null,
				clones: null,
				ref: null
			}), props = workInProgress.pendingProps, null != props.name && "auto" !== props.name ? workInProgress.flags |= null === current ? 18882560 : 18874368 : isHydrating && pushMaterializedTreeId(workInProgress), null !== current && current.memoizedProps.name !== props.name ? workInProgress.flags |= 4194816 : markRef(current, workInProgress), reconcileChildren(current, workInProgress, props.children, renderLanes), workInProgress.child;
			case 29: throw workInProgress.pendingProps;
		}
		throw Error(formatProdErrorMessage(156, workInProgress.tag));
	}
	function markUpdate(workInProgress) {
		workInProgress.flags |= 4;
	}
	function preloadInstanceAndSuspendIfNeeded(workInProgress, type, oldProps, newProps, renderLanes) {
		var JSCompiler_temp;
		if (JSCompiler_temp = 0 !== (workInProgress.mode & 32)) JSCompiler_temp = null === oldProps ? maySuspendCommit(type, newProps) : maySuspendCommit(type, newProps) && (newProps.src !== oldProps.src || newProps.srcSet !== oldProps.srcSet);
		if (JSCompiler_temp) {
			if (workInProgress.flags |= 16777216, (renderLanes & 335544128) === renderLanes) if (workInProgress.stateNode.complete) workInProgress.flags |= 8192;
			else if (shouldRemainOnPreviousScreen()) workInProgress.flags |= 8192;
			else throw suspendedThenable = noopSuspenseyCommitThenable, SuspenseyCommitException;
		} else workInProgress.flags &= -16777217;
	}
	function preloadResourceAndSuspendIfNeeded(workInProgress, resource) {
		if ("stylesheet" !== resource.type || 0 !== (resource.state.loading & 4)) workInProgress.flags &= -16777217;
		else if (workInProgress.flags |= 16777216, !preloadResource(resource)) if (shouldRemainOnPreviousScreen()) workInProgress.flags |= 8192;
		else throw suspendedThenable = noopSuspenseyCommitThenable, SuspenseyCommitException;
	}
	function scheduleRetryEffect(workInProgress, retryQueue) {
		null !== retryQueue && (workInProgress.flags |= 4);
		workInProgress.flags & 16384 && (retryQueue = 22 !== workInProgress.tag ? claimNextRetryLane() : 536870912, workInProgress.lanes |= retryQueue, workInProgressSuspendedRetryLanes |= retryQueue);
	}
	function cutOffTailIfNeeded(renderState, hasRenderedATailFallback) {
		if (!isHydrating) switch (renderState.tailMode) {
			case "visible": break;
			case "collapsed":
				for (var tailNode = renderState.tail, lastTailNode = null; null !== tailNode;) null !== tailNode.alternate && (lastTailNode = tailNode), tailNode = tailNode.sibling;
				null === lastTailNode ? hasRenderedATailFallback || null === renderState.tail ? renderState.tail = null : renderState.tail.sibling = null : lastTailNode.sibling = null;
				break;
			default:
				hasRenderedATailFallback = renderState.tail;
				for (tailNode = null; null !== hasRenderedATailFallback;) null !== hasRenderedATailFallback.alternate && (tailNode = hasRenderedATailFallback), hasRenderedATailFallback = hasRenderedATailFallback.sibling;
				null === tailNode ? renderState.tail = null : tailNode.sibling = null;
		}
	}
	function bubbleProperties(completedWork) {
		var didBailout = null !== completedWork.alternate && completedWork.alternate.child === completedWork.child, newChildLanes = 0, subtreeFlags = 0;
		if (didBailout) for (var child$113 = completedWork.child; null !== child$113;) newChildLanes |= child$113.lanes | child$113.childLanes, subtreeFlags |= child$113.subtreeFlags & 1206910976, subtreeFlags |= child$113.flags & 1206910976, child$113.return = completedWork, child$113 = child$113.sibling;
		else for (child$113 = completedWork.child; null !== child$113;) newChildLanes |= child$113.lanes | child$113.childLanes, subtreeFlags |= child$113.subtreeFlags, subtreeFlags |= child$113.flags, child$113.return = completedWork, child$113 = child$113.sibling;
		completedWork.subtreeFlags |= subtreeFlags;
		completedWork.childLanes = newChildLanes;
		return didBailout;
	}
	function completeWork(current, workInProgress, renderLanes) {
		var newProps = workInProgress.pendingProps;
		popTreeContext(workInProgress);
		switch (workInProgress.tag) {
			case 16:
			case 15:
			case 0:
			case 11:
			case 7:
			case 8:
			case 12:
			case 9:
			case 14: return bubbleProperties(workInProgress), null;
			case 1: return bubbleProperties(workInProgress), null;
			case 3:
				renderLanes = workInProgress.stateNode;
				newProps = null;
				null !== current && (newProps = current.memoizedState.cache);
				workInProgress.memoizedState.cache !== newProps && (workInProgress.flags |= 2048);
				popProvider(CacheContext);
				popHostContainer();
				renderLanes.pendingContext && (renderLanes.context = renderLanes.pendingContext, renderLanes.pendingContext = null);
				if (null === current || null === current.child) popHydrationState(workInProgress) ? markUpdate(workInProgress) : null === current || current.memoizedState.isDehydrated && 0 === (workInProgress.flags & 256) || (workInProgress.flags |= 1024, upgradeHydrationErrorsToRecoverable());
				bubbleProperties(workInProgress);
				return null;
			case 26:
				var type = workInProgress.type, nextResource = workInProgress.memoizedState;
				null === current ? (markUpdate(workInProgress), null !== nextResource ? (bubbleProperties(workInProgress), preloadResourceAndSuspendIfNeeded(workInProgress, nextResource)) : (bubbleProperties(workInProgress), preloadInstanceAndSuspendIfNeeded(workInProgress, type, null, newProps, renderLanes))) : nextResource ? nextResource !== current.memoizedState ? (markUpdate(workInProgress), bubbleProperties(workInProgress), preloadResourceAndSuspendIfNeeded(workInProgress, nextResource)) : (bubbleProperties(workInProgress), workInProgress.flags &= -16777217) : (current = current.memoizedProps, current !== newProps && markUpdate(workInProgress), bubbleProperties(workInProgress), preloadInstanceAndSuspendIfNeeded(workInProgress, type, current, newProps, renderLanes));
				return null;
			case 27:
				popHostContext(workInProgress);
				renderLanes = rootInstanceStackCursor.current;
				type = workInProgress.type;
				if (null !== current && null != workInProgress.stateNode) current.memoizedProps !== newProps && markUpdate(workInProgress);
				else {
					if (!newProps) {
						if (null === workInProgress.stateNode) throw Error(formatProdErrorMessage(166));
						bubbleProperties(workInProgress);
						workInProgress.subtreeFlags &= -33554433;
						return null;
					}
					current = contextStackCursor.current;
					popHydrationState(workInProgress) ? prepareToHydrateHostInstance(workInProgress, current) : (current = resolveSingletonInstance(type, newProps, renderLanes), workInProgress.stateNode = current, markUpdate(workInProgress));
				}
				bubbleProperties(workInProgress);
				workInProgress.subtreeFlags &= -33554433;
				return null;
			case 5:
				popHostContext(workInProgress);
				type = workInProgress.type;
				if (null !== current && null != workInProgress.stateNode) current.memoizedProps !== newProps && markUpdate(workInProgress);
				else {
					if (!newProps) {
						if (null === workInProgress.stateNode) throw Error(formatProdErrorMessage(166));
						bubbleProperties(workInProgress);
						workInProgress.subtreeFlags &= -33554433;
						return null;
					}
					nextResource = contextStackCursor.current;
					if (popHydrationState(workInProgress)) prepareToHydrateHostInstance(workInProgress, nextResource);
					else {
						var ownerDocument = getOwnerDocumentFromRootContainer(rootInstanceStackCursor.current);
						switch (nextResource) {
							case 1:
								nextResource = ownerDocument.createElementNS("http://www.w3.org/2000/svg", type);
								break;
							case 2:
								nextResource = ownerDocument.createElementNS("http://www.w3.org/1998/Math/MathML", type);
								break;
							default: switch (type) {
								case "svg":
									nextResource = ownerDocument.createElementNS("http://www.w3.org/2000/svg", type);
									break;
								case "math":
									nextResource = ownerDocument.createElementNS("http://www.w3.org/1998/Math/MathML", type);
									break;
								case "script":
									nextResource = ownerDocument.createElement("div");
									nextResource.innerHTML = "<script><\/script>";
									nextResource = nextResource.removeChild(nextResource.firstChild);
									break;
								case "select":
									nextResource = "string" === typeof newProps.is ? ownerDocument.createElement("select", { is: newProps.is }) : ownerDocument.createElement("select");
									newProps.multiple ? nextResource.multiple = !0 : newProps.size && (nextResource.size = newProps.size);
									break;
								default: nextResource = "string" === typeof newProps.is ? ownerDocument.createElement(type, { is: newProps.is }) : ownerDocument.createElement(type);
							}
						}
						nextResource[internalInstanceKey] = workInProgress;
						nextResource[internalPropsKey] = newProps;
						a: for (ownerDocument = workInProgress.child; null !== ownerDocument;) {
							if (5 === ownerDocument.tag || 6 === ownerDocument.tag) nextResource.appendChild(ownerDocument.stateNode);
							else if (4 !== ownerDocument.tag && 27 !== ownerDocument.tag && null !== ownerDocument.child) {
								ownerDocument.child.return = ownerDocument;
								ownerDocument = ownerDocument.child;
								continue;
							}
							if (ownerDocument === workInProgress) break a;
							for (; null === ownerDocument.sibling;) {
								if (null === ownerDocument.return || ownerDocument.return === workInProgress) break a;
								ownerDocument = ownerDocument.return;
							}
							ownerDocument.sibling.return = ownerDocument.return;
							ownerDocument = ownerDocument.sibling;
						}
						workInProgress.stateNode = nextResource;
						a: switch (setInitialProperties(nextResource, type, newProps), type) {
							case "button":
							case "input":
							case "select":
							case "textarea":
								newProps = !!newProps.autoFocus;
								break a;
							case "img":
								newProps = !0;
								break a;
							default: newProps = !1;
						}
						newProps && markUpdate(workInProgress);
					}
				}
				bubbleProperties(workInProgress);
				workInProgress.subtreeFlags &= -33554433;
				preloadInstanceAndSuspendIfNeeded(workInProgress, workInProgress.type, null === current ? null : current.memoizedProps, workInProgress.pendingProps, renderLanes);
				return null;
			case 6:
				if (current && null != workInProgress.stateNode) current.memoizedProps !== newProps && markUpdate(workInProgress);
				else {
					if ("string" !== typeof newProps && null === workInProgress.stateNode) throw Error(formatProdErrorMessage(166));
					current = rootInstanceStackCursor.current;
					if (popHydrationState(workInProgress)) {
						current = workInProgress.stateNode;
						renderLanes = workInProgress.memoizedProps;
						newProps = null;
						type = hydrationParentFiber;
						if (null !== type) switch (type.tag) {
							case 27:
							case 5: newProps = type.memoizedProps;
						}
						current[internalInstanceKey] = workInProgress;
						current = current.nodeValue === renderLanes || null !== newProps && !0 === newProps.suppressHydrationWarning || checkForUnmatchedText(current.nodeValue, renderLanes) ? !0 : !1;
						current || throwOnHydrationMismatch(workInProgress, !0);
					} else current = getOwnerDocumentFromRootContainer(current).createTextNode(newProps), current[internalInstanceKey] = workInProgress, workInProgress.stateNode = current;
				}
				bubbleProperties(workInProgress);
				return null;
			case 31:
				renderLanes = workInProgress.memoizedState;
				if (null === current || null !== current.memoizedState) {
					newProps = popHydrationState(workInProgress);
					if (null !== renderLanes) {
						if (null === current) {
							if (!newProps) throw Error(formatProdErrorMessage(318));
							current = workInProgress.memoizedState;
							current = null !== current ? current.dehydrated : null;
							if (!current) throw Error(formatProdErrorMessage(557));
							current[internalInstanceKey] = workInProgress;
						} else resetHydrationState(), 0 === (workInProgress.flags & 128) && (workInProgress.memoizedState = null), workInProgress.flags |= 4;
						bubbleProperties(workInProgress);
						current = !1;
					} else renderLanes = upgradeHydrationErrorsToRecoverable(), null !== current && null !== current.memoizedState && (current.memoizedState.hydrationErrors = renderLanes), current = !0;
					if (!current) {
						if (workInProgress.flags & 256) return popSuspenseHandler(workInProgress), workInProgress;
						popSuspenseHandler(workInProgress);
						return null;
					}
					if (0 !== (workInProgress.flags & 128)) throw Error(formatProdErrorMessage(558));
				}
				bubbleProperties(workInProgress);
				return null;
			case 13:
				newProps = workInProgress.memoizedState;
				if (null === current || null !== current.memoizedState && null !== current.memoizedState.dehydrated) {
					type = popHydrationState(workInProgress);
					if (null !== newProps && null !== newProps.dehydrated) {
						if (null === current) {
							if (!type) throw Error(formatProdErrorMessage(318));
							type = workInProgress.memoizedState;
							type = null !== type ? type.dehydrated : null;
							if (!type) throw Error(formatProdErrorMessage(317));
							type[internalInstanceKey] = workInProgress;
						} else resetHydrationState(), 0 === (workInProgress.flags & 128) && (workInProgress.memoizedState = null), workInProgress.flags |= 4;
						bubbleProperties(workInProgress);
						type = !1;
					} else type = upgradeHydrationErrorsToRecoverable(), null !== current && null !== current.memoizedState && (current.memoizedState.hydrationErrors = type), type = !0;
					if (!type) {
						if (workInProgress.flags & 256) return popSuspenseHandler(workInProgress), workInProgress;
						popSuspenseHandler(workInProgress);
						return null;
					}
				}
				popSuspenseHandler(workInProgress);
				if (0 !== (workInProgress.flags & 128)) return workInProgress.lanes = renderLanes, workInProgress;
				renderLanes = null !== newProps;
				current = null !== current && null !== current.memoizedState;
				renderLanes && (newProps = workInProgress.child, type = null, null !== newProps.alternate && null !== newProps.alternate.memoizedState && null !== newProps.alternate.memoizedState.cachePool && (type = newProps.alternate.memoizedState.cachePool.pool), nextResource = null, null !== newProps.memoizedState && null !== newProps.memoizedState.cachePool && (nextResource = newProps.memoizedState.cachePool.pool), nextResource !== type && (newProps.flags |= 2048));
				renderLanes !== current && renderLanes && (workInProgress.child.flags |= 8192);
				scheduleRetryEffect(workInProgress, workInProgress.updateQueue);
				bubbleProperties(workInProgress);
				return null;
			case 4: return popHostContainer(), null === current && listenToAllSupportedEvents(workInProgress.stateNode.containerInfo), workInProgress.flags |= 67108864, bubbleProperties(workInProgress), null;
			case 10: return popProvider(workInProgress.type), bubbleProperties(workInProgress), null;
			case 19:
				popSuspenseListContext(workInProgress);
				newProps = workInProgress.memoizedState;
				if (null === newProps) return bubbleProperties(workInProgress), null;
				type = 0 !== (workInProgress.flags & 128);
				nextResource = newProps.rendering;
				if (null === nextResource) if (type) cutOffTailIfNeeded(newProps, !1);
				else {
					if (0 !== workInProgressRootExitStatus || null !== current && 0 !== (current.flags & 128)) for (current = workInProgress.child; null !== current;) {
						nextResource = findFirstSuspended(current);
						if (null !== nextResource) {
							workInProgress.flags |= 128;
							cutOffTailIfNeeded(newProps, !1);
							current = nextResource.updateQueue;
							workInProgress.updateQueue = current;
							scheduleRetryEffect(workInProgress, current);
							workInProgress.subtreeFlags = 0;
							current = renderLanes;
							for (renderLanes = workInProgress.child; null !== renderLanes;) resetWorkInProgress(renderLanes, current), renderLanes = renderLanes.sibling;
							pushSuspenseListContext(workInProgress, suspenseStackCursor.current & 1 | 2);
							isHydrating && pushTreeFork(workInProgress, newProps.treeForkCount);
							return workInProgress.child;
						}
						current = current.sibling;
					}
					null !== newProps.tail && now() > workInProgressRootRenderTargetTime && (workInProgress.flags |= 128, type = !0, cutOffTailIfNeeded(newProps, !1), workInProgress.lanes = 4194304);
				}
				else {
					if (!type) if (current = findFirstSuspended(nextResource), null !== current) {
						if (workInProgress.flags |= 128, type = !0, current = current.updateQueue, workInProgress.updateQueue = current, scheduleRetryEffect(workInProgress, current), cutOffTailIfNeeded(newProps, !0), null === newProps.tail && "collapsed" !== newProps.tailMode && "visible" !== newProps.tailMode && !nextResource.alternate && !isHydrating) return bubbleProperties(workInProgress), null;
					} else 2 * now() - newProps.renderingStartTime > workInProgressRootRenderTargetTime && 536870912 !== renderLanes && (workInProgress.flags |= 128, type = !0, cutOffTailIfNeeded(newProps, !1), workInProgress.lanes = 4194304);
					newProps.isBackwards ? (nextResource.sibling = workInProgress.child, workInProgress.child = nextResource) : (current = newProps.last, null !== current ? current.sibling = nextResource : workInProgress.child = nextResource, newProps.last = nextResource);
				}
				if (null !== newProps.tail) {
					current = newProps.tail;
					a: {
						for (renderLanes = current; null !== renderLanes;) {
							if (null !== renderLanes.alternate) {
								renderLanes = !1;
								break a;
							}
							renderLanes = renderLanes.sibling;
						}
						renderLanes = !0;
					}
					newProps.rendering = current;
					newProps.tail = current.sibling;
					newProps.renderingStartTime = now();
					current.sibling = null;
					nextResource = suspenseStackCursor.current;
					nextResource = type ? nextResource & 1 | 2 : nextResource & 1;
					"visible" === newProps.tailMode || "collapsed" === newProps.tailMode || !renderLanes || isHydrating ? pushSuspenseListContext(workInProgress, nextResource) : (renderLanes = nextResource, push(suspenseHandlerStackCursor, workInProgress), push(suspenseStackCursor, renderLanes), null === shellBoundary && (shellBoundary = workInProgress));
					isHydrating && pushTreeFork(workInProgress, newProps.treeForkCount);
					return current;
				}
				bubbleProperties(workInProgress);
				return null;
			case 22:
			case 23: return popSuspenseHandler(workInProgress), popHiddenContext(), newProps = null !== workInProgress.memoizedState, null !== current ? null !== current.memoizedState !== newProps && (workInProgress.flags |= 8192) : newProps && (workInProgress.flags |= 8192), newProps ? 0 !== (renderLanes & 536870912) && 0 === (workInProgress.flags & 128) && (bubbleProperties(workInProgress), workInProgress.subtreeFlags & 6 && (workInProgress.flags |= 8192)) : bubbleProperties(workInProgress), renderLanes = workInProgress.updateQueue, null !== renderLanes && scheduleRetryEffect(workInProgress, renderLanes.retryQueue), renderLanes = null, null !== current && null !== current.memoizedState && null !== current.memoizedState.cachePool && (renderLanes = current.memoizedState.cachePool.pool), newProps = null, null !== workInProgress.memoizedState && null !== workInProgress.memoizedState.cachePool && (newProps = workInProgress.memoizedState.cachePool.pool), newProps !== renderLanes && (workInProgress.flags |= 2048), null !== current && pop(resumedCache), null;
			case 24: return renderLanes = null, null !== current && (renderLanes = current.memoizedState.cache), workInProgress.memoizedState.cache !== renderLanes && (workInProgress.flags |= 2048), popProvider(CacheContext), bubbleProperties(workInProgress), null;
			case 25: return null;
			case 30: return workInProgress.flags |= 33554432, bubbleProperties(workInProgress), null;
		}
		throw Error(formatProdErrorMessage(156, workInProgress.tag));
	}
	function unwindWork(current, workInProgress) {
		popTreeContext(workInProgress);
		switch (workInProgress.tag) {
			case 1: return current = workInProgress.flags, current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
			case 3: return popProvider(CacheContext), popHostContainer(), current = workInProgress.flags, 0 !== (current & 65536) && 0 === (current & 128) ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
			case 26:
			case 27:
			case 5: return popHostContext(workInProgress), null;
			case 31:
				if (null !== workInProgress.memoizedState) {
					popSuspenseHandler(workInProgress);
					if (null === workInProgress.alternate) throw Error(formatProdErrorMessage(340));
					resetHydrationState();
				}
				current = workInProgress.flags;
				return current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
			case 13:
				popSuspenseHandler(workInProgress);
				current = workInProgress.memoizedState;
				if (null !== current && null !== current.dehydrated) {
					if (null === workInProgress.alternate) throw Error(formatProdErrorMessage(340));
					resetHydrationState();
				}
				current = workInProgress.flags;
				return current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
			case 19: return popSuspenseListContext(workInProgress), current = workInProgress.flags, current & 65536 ? (workInProgress.flags = current & -65537 | 128, current = workInProgress.memoizedState, null !== current && (current.rendering = null, current.tail = null), workInProgress.flags |= 4, workInProgress) : null;
			case 4: return popHostContainer(), null;
			case 10: return popProvider(workInProgress.type), null;
			case 22:
			case 23: return popSuspenseHandler(workInProgress), popHiddenContext(), null !== current && pop(resumedCache), current = workInProgress.flags, current & 65536 ? (workInProgress.flags = current & -65537 | 128, workInProgress) : null;
			case 24: return popProvider(CacheContext), null;
			case 25: return null;
			default: return null;
		}
	}
	function unwindInterruptedWork(current, interruptedWork) {
		popTreeContext(interruptedWork);
		switch (interruptedWork.tag) {
			case 3:
				popProvider(CacheContext);
				popHostContainer();
				break;
			case 26:
			case 27:
			case 5:
				popHostContext(interruptedWork);
				break;
			case 4:
				popHostContainer();
				break;
			case 31:
				null !== interruptedWork.memoizedState && popSuspenseHandler(interruptedWork);
				break;
			case 13:
				popSuspenseHandler(interruptedWork);
				break;
			case 19:
				popSuspenseListContext(interruptedWork);
				break;
			case 10:
				popProvider(interruptedWork.type);
				break;
			case 22:
			case 23:
				popSuspenseHandler(interruptedWork);
				popHiddenContext();
				null !== current && pop(resumedCache);
				break;
			case 24: popProvider(CacheContext);
		}
	}
	function commitHookEffectListMount(flags, finishedWork) {
		try {
			var updateQueue = finishedWork.updateQueue, lastEffect = null !== updateQueue ? updateQueue.lastEffect : null;
			if (null !== lastEffect) {
				var firstEffect = lastEffect.next;
				updateQueue = firstEffect;
				do {
					if ((updateQueue.tag & flags) === flags) {
						lastEffect = void 0;
						var create = updateQueue.create, inst = updateQueue.inst;
						lastEffect = create();
						inst.destroy = lastEffect;
					}
					updateQueue = updateQueue.next;
				} while (updateQueue !== firstEffect);
			}
		} catch (error) {
			captureCommitPhaseError(finishedWork, finishedWork.return, error);
		}
	}
	function commitHookEffectListUnmount(flags, finishedWork, nearestMountedAncestor$jscomp$0) {
		try {
			var updateQueue = finishedWork.updateQueue, lastEffect = null !== updateQueue ? updateQueue.lastEffect : null;
			if (null !== lastEffect) {
				var firstEffect = lastEffect.next;
				updateQueue = firstEffect;
				do {
					if ((updateQueue.tag & flags) === flags) {
						var inst = updateQueue.inst, destroy = inst.destroy;
						if (void 0 !== destroy) {
							inst.destroy = void 0;
							lastEffect = finishedWork;
							var nearestMountedAncestor = nearestMountedAncestor$jscomp$0, destroy_ = destroy;
							try {
								destroy_();
							} catch (error) {
								captureCommitPhaseError(lastEffect, nearestMountedAncestor, error);
							}
						}
					}
					updateQueue = updateQueue.next;
				} while (updateQueue !== firstEffect);
			}
		} catch (error) {
			captureCommitPhaseError(finishedWork, finishedWork.return, error);
		}
	}
	function commitClassCallbacks(finishedWork) {
		var updateQueue = finishedWork.updateQueue;
		if (null !== updateQueue) {
			var instance = finishedWork.stateNode;
			try {
				commitCallbacks(updateQueue, instance);
			} catch (error) {
				captureCommitPhaseError(finishedWork, finishedWork.return, error);
			}
		}
	}
	function safelyCallComponentWillUnmount(current, nearestMountedAncestor, instance) {
		instance.props = resolveClassComponentProps(current.type, current.memoizedProps);
		instance.state = current.memoizedState;
		try {
			instance.componentWillUnmount();
		} catch (error) {
			captureCommitPhaseError(current, nearestMountedAncestor, error);
		}
	}
	function safelyAttachRef(current, nearestMountedAncestor) {
		try {
			var ref = current.ref;
			if (null !== ref) {
				switch (current.tag) {
					case 26:
					case 27:
					case 5:
						var instanceToUse = current.stateNode;
						break;
					case 30:
						var instance = current.stateNode, name = getViewTransitionName(current.memoizedProps, instance);
						if (null === instance.ref || instance.ref.name !== name) instance.ref = createViewTransitionInstance(name);
						instanceToUse = instance.ref;
						break;
					case 7:
						if (null === current.stateNode) {
							var fragmentInstance = new FragmentInstance(current);
							traverseVisibleInstancesAndTextInstances(current.child, !1, addFragmentHandleToFiber, fragmentInstance, void 0, void 0);
							current.stateNode = fragmentInstance;
						}
						instanceToUse = current.stateNode;
						break;
					default: instanceToUse = current.stateNode;
				}
				"function" === typeof ref ? current.refCleanup = ref(instanceToUse) : ref.current = instanceToUse;
			}
		} catch (error) {
			captureCommitPhaseError(current, nearestMountedAncestor, error);
		}
	}
	function safelyDetachRef(current, nearestMountedAncestor) {
		var ref = current.ref, refCleanup = current.refCleanup;
		if (null !== ref) if ("function" === typeof refCleanup) try {
			refCleanup();
		} catch (error) {
			captureCommitPhaseError(current, nearestMountedAncestor, error);
		} finally {
			current.refCleanup = null, current = current.alternate, null != current && (current.refCleanup = null);
		}
		else if ("function" === typeof ref) try {
			ref(null);
		} catch (error$148) {
			captureCommitPhaseError(current, nearestMountedAncestor, error$148);
		}
		else ref.current = null;
	}
	function commitNewChildToFragmentInstances(fiber, parentFragmentInstances) {
		if ((5 === fiber.tag || 27 === fiber.tag || 6 === fiber.tag) && null === fiber.alternate && null !== parentFragmentInstances) for (var i = 0; i < parentFragmentInstances.length; i++) commitNewChildToFragmentInstance(fiber.stateNode, parentFragmentInstances[i]);
	}
	function commitFragmentInstanceInsertionEffects(fiber) {
		for (var parent = fiber.return; null !== parent;) {
			isFragmentInstanceParent(parent) && commitNewChildToFragmentInstance(fiber.stateNode, parent.stateNode);
			if (isFragmentInstanceHostBoundary(parent)) break;
			parent = parent.return;
		}
	}
	function commitFragmentInstanceDeletionEffects(fiber) {
		for (var parent = fiber.return; null !== parent;) {
			isFragmentInstanceParent(parent) && deleteChildFromFragmentInstance(fiber.stateNode, parent.stateNode);
			if (isFragmentInstanceHostBoundary(parent)) break;
			parent = parent.return;
		}
	}
	function isFragmentInstanceHostBoundary(fiber) {
		return 5 === fiber.tag || 3 === fiber.tag || 27 === fiber.tag;
	}
	function isFragmentInstanceParent(fiber) {
		return fiber && 7 === fiber.tag && null !== fiber.stateNode;
	}
	function commitHostMount(finishedWork) {
		var type = finishedWork.type, props = finishedWork.memoizedProps, instance = finishedWork.stateNode;
		try {
			a: switch (type) {
				case "button":
				case "input":
				case "select":
				case "textarea":
					props.autoFocus && instance.focus();
					break a;
				case "img": props.src ? instance.src = props.src : props.srcSet && (instance.srcset = props.srcSet);
			}
		} catch (error) {
			captureCommitPhaseError(finishedWork, finishedWork.return, error);
		}
	}
	function commitHostUpdate(finishedWork, newProps, oldProps) {
		try {
			var domElement = finishedWork.stateNode;
			updateProperties(domElement, finishedWork.type, oldProps, newProps);
			domElement[internalPropsKey] = newProps;
		} catch (error) {
			captureCommitPhaseError(finishedWork, finishedWork.return, error);
		}
	}
	function isHostParent(fiber) {
		return 5 === fiber.tag || 3 === fiber.tag || 26 === fiber.tag || 27 === fiber.tag && isSingletonScope(fiber.type) || 4 === fiber.tag;
	}
	function getHostSibling(fiber) {
		a: for (;;) {
			for (; null === fiber.sibling;) {
				if (null === fiber.return || isHostParent(fiber.return)) return null;
				fiber = fiber.return;
			}
			fiber.sibling.return = fiber.return;
			for (fiber = fiber.sibling; 5 !== fiber.tag && 6 !== fiber.tag && 18 !== fiber.tag;) {
				if (27 === fiber.tag && isSingletonScope(fiber.type)) continue a;
				if (fiber.flags & 2) continue a;
				if (null === fiber.child || 4 === fiber.tag) continue a;
				else fiber.child.return = fiber, fiber = fiber.child;
			}
			if (!(fiber.flags & 2)) return fiber.stateNode;
		}
	}
	function insertOrAppendPlacementNodeIntoContainer(node, before, parent, parentFragmentInstances) {
		var tag = node.tag;
		if (5 === tag || 6 === tag) tag = node.stateNode, before ? (9 === parent.nodeType ? parent.body : "HTML" === parent.nodeName ? parent.ownerDocument.body : parent).insertBefore(tag, before) : (before = 9 === parent.nodeType ? parent.body : "HTML" === parent.nodeName ? parent.ownerDocument.body : parent, before.appendChild(tag), parent = parent._reactRootContainer, null !== parent && void 0 !== parent || null !== before.onclick || (before.onclick = noop$1)), commitNewChildToFragmentInstances(node, parentFragmentInstances), viewTransitionMutationContext = !0;
		else if (4 !== tag && (27 === tag && (commitNewChildToFragmentInstances(node, parentFragmentInstances), parentFragmentInstances = null, isSingletonScope(node.type) && (parent = node.stateNode, before = null)), node = node.child, null !== node)) for (insertOrAppendPlacementNodeIntoContainer(node, before, parent, parentFragmentInstances), node = node.sibling; null !== node;) insertOrAppendPlacementNodeIntoContainer(node, before, parent, parentFragmentInstances), node = node.sibling;
	}
	function insertOrAppendPlacementNode(node, before, parent, parentFragmentInstances) {
		var tag = node.tag;
		if (5 === tag || 6 === tag) tag = node.stateNode, before ? parent.insertBefore(tag, before) : parent.appendChild(tag), commitNewChildToFragmentInstances(node, parentFragmentInstances), viewTransitionMutationContext = !0;
		else if (4 !== tag && (27 === tag && (commitNewChildToFragmentInstances(node, parentFragmentInstances), parentFragmentInstances = null, isSingletonScope(node.type) && (parent = node.stateNode)), node = node.child, null !== node)) for (insertOrAppendPlacementNode(node, before, parent, parentFragmentInstances), node = node.sibling; null !== node;) insertOrAppendPlacementNode(node, before, parent, parentFragmentInstances), node = node.sibling;
	}
	function commitHostSingletonAcquisition(finishedWork) {
		var singleton = finishedWork.stateNode, props = finishedWork.memoizedProps;
		try {
			for (var type = finishedWork.type, attributes = singleton.attributes; attributes.length;) singleton.removeAttributeNode(attributes[0]);
			setInitialProperties(singleton, type, props);
			singleton[internalInstanceKey] = finishedWork;
			singleton[internalPropsKey] = props;
		} catch (error) {
			captureCommitPhaseError(finishedWork, finishedWork.return, error);
		}
	}
	var shouldStartViewTransition = !1;
	var appearingViewTransitions = null;
	function trackEnterViewTransitions(placement) {
		if (30 === placement.tag || 0 !== (placement.subtreeFlags & 33554432)) shouldStartViewTransition = !0;
	}
	var viewTransitionCancelableChildren = null;
	function pushViewTransitionCancelableScope() {
		var prevChildren = viewTransitionCancelableChildren;
		viewTransitionCancelableChildren = null;
		return prevChildren;
	}
	var viewTransitionHostInstanceIdx = 0;
	function applyViewTransitionToHostInstances(fiber, name, className, collectMeasurements, stopAtNestedViewTransitions) {
		viewTransitionHostInstanceIdx = 0;
		return applyViewTransitionToHostInstancesRecursive(fiber.child, name, className, collectMeasurements, stopAtNestedViewTransitions);
	}
	function applyViewTransitionToHostInstancesRecursive(child, name, className, collectMeasurements, stopAtNestedViewTransitions) {
		for (var inViewport = !1; null !== child;) {
			if (5 === child.tag) {
				var instance = child.stateNode;
				if (null !== collectMeasurements) {
					var measurement = measureInstance(instance);
					collectMeasurements.push(measurement);
					measurement.view && (inViewport = !0);
				} else inViewport || measureInstance(instance).view && (inViewport = !0);
				shouldStartViewTransition = !0;
				applyViewTransitionName(instance, 0 === viewTransitionHostInstanceIdx ? name : name + "_" + viewTransitionHostInstanceIdx, className);
				viewTransitionHostInstanceIdx++;
			} else if (22 !== child.tag || null === child.memoizedState) 30 === child.tag && stopAtNestedViewTransitions || applyViewTransitionToHostInstancesRecursive(child.child, name, className, collectMeasurements, stopAtNestedViewTransitions) && (inViewport = !0);
			child = child.sibling;
		}
		return inViewport;
	}
	function restoreViewTransitionOnHostInstances(child, stopAtNestedViewTransitions) {
		for (; null !== child;) {
			if (5 === child.tag) restoreViewTransitionName(child.stateNode, child.memoizedProps);
			else if (22 !== child.tag || null === child.memoizedState) 30 === child.tag && stopAtNestedViewTransitions || restoreViewTransitionOnHostInstances(child.child, stopAtNestedViewTransitions);
			child = child.sibling;
		}
	}
	function commitAppearingPairViewTransitions(placement) {
		if (0 !== (placement.subtreeFlags & 18874368)) for (placement = placement.child; null !== placement;) {
			if (22 !== placement.tag || null === placement.memoizedState) {
				if (commitAppearingPairViewTransitions(placement), 30 === placement.tag && 0 !== (placement.flags & 18874368) && placement.stateNode.paired) {
					var props = placement.memoizedProps;
					if (null == props.name || "auto" === props.name) throw Error(formatProdErrorMessage(544));
					var name = props.name;
					props = getViewTransitionClassName(props.default, props.share);
					"none" !== props && (applyViewTransitionToHostInstances(placement, name, props, null, !1) || restoreViewTransitionOnHostInstances(placement.child, !1));
				}
			}
			placement = placement.sibling;
		}
	}
	function commitEnterViewTransitions(placement, gesture) {
		if (30 === placement.tag) {
			var state = placement.stateNode, props = placement.memoizedProps, name = getViewTransitionName(props, state), className = getViewTransitionClassName(props.default, state.paired ? props.share : props.enter);
			"none" !== className ? applyViewTransitionToHostInstances(placement, name, className, null, !1) ? (commitAppearingPairViewTransitions(placement), state.paired || gesture || scheduleViewTransitionEvent(placement, props.onEnter)) : restoreViewTransitionOnHostInstances(placement.child, !1) : commitAppearingPairViewTransitions(placement);
		} else if (0 !== (placement.subtreeFlags & 33554432)) for (placement = placement.child; null !== placement;) commitEnterViewTransitions(placement, gesture), placement = placement.sibling;
		else commitAppearingPairViewTransitions(placement);
	}
	function commitDeletedPairViewTransitions(deletion) {
		if (null !== appearingViewTransitions && 0 !== appearingViewTransitions.size) {
			var pairs = appearingViewTransitions;
			if (0 !== (deletion.subtreeFlags & 18874368)) for (deletion = deletion.child; null !== deletion;) {
				if (22 !== deletion.tag || null === deletion.memoizedState) {
					if (30 === deletion.tag && 0 !== (deletion.flags & 18874368)) {
						var props = deletion.memoizedProps, name = props.name;
						if (null != name && "auto" !== name) {
							var pair = pairs.get(name);
							if (void 0 !== pair) {
								var className = getViewTransitionClassName(props.default, props.share);
								"none" !== className && (applyViewTransitionToHostInstances(deletion, name, className, null, !1) ? (className = deletion.stateNode, pair.paired = className, className.paired = pair, scheduleViewTransitionEvent(deletion, props.onShare)) : restoreViewTransitionOnHostInstances(deletion.child, !1));
								pairs.delete(name);
								if (0 === pairs.size) break;
							}
						}
					}
					commitDeletedPairViewTransitions(deletion);
				}
				deletion = deletion.sibling;
			}
		}
	}
	function commitExitViewTransitions(deletion) {
		if (30 === deletion.tag) {
			var props = deletion.memoizedProps, name = getViewTransitionName(props, deletion.stateNode), pair = null !== appearingViewTransitions ? appearingViewTransitions.get(name) : void 0, className = getViewTransitionClassName(props.default, void 0 !== pair ? props.share : props.exit);
			"none" !== className && (applyViewTransitionToHostInstances(deletion, name, className, null, !1) ? void 0 !== pair ? (className = deletion.stateNode, pair.paired = className, className.paired = pair, appearingViewTransitions.delete(name), scheduleViewTransitionEvent(deletion, props.onShare)) : scheduleViewTransitionEvent(deletion, props.onExit) : restoreViewTransitionOnHostInstances(deletion.child, !1));
			null !== appearingViewTransitions && commitDeletedPairViewTransitions(deletion);
		} else if (0 !== (deletion.subtreeFlags & 33554432)) for (deletion = deletion.child; null !== deletion;) commitExitViewTransitions(deletion), deletion = deletion.sibling;
		else null !== appearingViewTransitions && commitDeletedPairViewTransitions(deletion);
	}
	function commitNestedViewTransitions(changedParent) {
		for (changedParent = changedParent.child; null !== changedParent;) {
			if (30 === changedParent.tag) {
				var props = changedParent.memoizedProps, name = getViewTransitionName(props, changedParent.stateNode);
				props = getViewTransitionClassName(props.default, props.update);
				changedParent.flags &= -5;
				"none" !== props && applyViewTransitionToHostInstances(changedParent, name, props, changedParent.memoizedState = [], !1);
			} else 0 !== (changedParent.subtreeFlags & 33554432) && commitNestedViewTransitions(changedParent);
			changedParent = changedParent.sibling;
		}
	}
	function restorePairedViewTransitions(parent) {
		if (0 !== (parent.subtreeFlags & 18874368)) for (parent = parent.child; null !== parent;) {
			if (22 !== parent.tag || null === parent.memoizedState) {
				if (30 === parent.tag && 0 !== (parent.flags & 18874368)) {
					var instance = parent.stateNode;
					null !== instance.paired && (instance.paired = null, restoreViewTransitionOnHostInstances(parent.child, !1));
				}
				restorePairedViewTransitions(parent);
			}
			parent = parent.sibling;
		}
	}
	function restoreEnterOrExitViewTransitions(fiber) {
		if (30 === fiber.tag) fiber.stateNode.paired = null, restoreViewTransitionOnHostInstances(fiber.child, !1), restorePairedViewTransitions(fiber);
		else if (0 !== (fiber.subtreeFlags & 33554432)) for (fiber = fiber.child; null !== fiber;) restoreEnterOrExitViewTransitions(fiber), fiber = fiber.sibling;
		else restorePairedViewTransitions(fiber);
	}
	function restoreNestedViewTransitions(changedParent) {
		for (changedParent = changedParent.child; null !== changedParent;) 30 === changedParent.tag ? restoreViewTransitionOnHostInstances(changedParent.child, !1) : 0 !== (changedParent.subtreeFlags & 33554432) && restoreNestedViewTransitions(changedParent), changedParent = changedParent.sibling;
	}
	function measureViewTransitionHostInstancesRecursive(parentViewTransition, child, newName, oldName, className, previousMeasurements, stopAtNestedViewTransitions) {
		for (var inViewport = !1; null !== child;) {
			if (5 === child.tag) {
				var instance = child.stateNode;
				if (null !== previousMeasurements && viewTransitionHostInstanceIdx < previousMeasurements.length) {
					var previousMeasurement = previousMeasurements[viewTransitionHostInstanceIdx], nextMeasurement = measureInstance(instance);
					if (previousMeasurement.view || nextMeasurement.view) inViewport = !0;
					var JSCompiler_temp;
					if (JSCompiler_temp = 0 === (parentViewTransition.flags & 4)) if (nextMeasurement.clip) JSCompiler_temp = !0;
					else {
						JSCompiler_temp = previousMeasurement.rect;
						var newRect = nextMeasurement.rect;
						JSCompiler_temp = JSCompiler_temp.y !== newRect.y || JSCompiler_temp.x !== newRect.x || JSCompiler_temp.height !== newRect.height || JSCompiler_temp.width !== newRect.width;
					}
					JSCompiler_temp && (parentViewTransition.flags |= 4);
					nextMeasurement.abs ? nextMeasurement = !previousMeasurement.abs : (previousMeasurement = previousMeasurement.rect, nextMeasurement = nextMeasurement.rect, nextMeasurement = previousMeasurement.height !== nextMeasurement.height || previousMeasurement.width !== nextMeasurement.width);
					nextMeasurement && (parentViewTransition.flags |= 32);
				} else parentViewTransition.flags |= 32;
				0 !== (parentViewTransition.flags & 4) && applyViewTransitionName(instance, 0 === viewTransitionHostInstanceIdx ? newName : newName + "_" + viewTransitionHostInstanceIdx, className);
				inViewport && 0 !== (parentViewTransition.flags & 4) || (null === viewTransitionCancelableChildren && (viewTransitionCancelableChildren = []), viewTransitionCancelableChildren.push(instance, 0 === viewTransitionHostInstanceIdx ? oldName : oldName + "_" + viewTransitionHostInstanceIdx, child.memoizedProps));
				viewTransitionHostInstanceIdx++;
			} else if (22 !== child.tag || null === child.memoizedState) 30 === child.tag && stopAtNestedViewTransitions ? parentViewTransition.flags |= child.flags & 32 : measureViewTransitionHostInstancesRecursive(parentViewTransition, child.child, newName, oldName, className, previousMeasurements, stopAtNestedViewTransitions) && (inViewport = !0);
			child = child.sibling;
		}
		return inViewport;
	}
	function measureNestedViewTransitions(changedParent, gesture) {
		for (changedParent = changedParent.child; null !== changedParent;) {
			if (30 === changedParent.tag) {
				var props = changedParent.memoizedProps, state = changedParent.stateNode, name = getViewTransitionName(props, state), className = getViewTransitionClassName(props.default, props.update);
				if (gesture) {
					state = state.clones;
					var previousMeasurements = null === state ? null : state.map(measureClonedInstance);
				} else previousMeasurements = changedParent.memoizedState, changedParent.memoizedState = null;
				state = changedParent;
				var child = changedParent.child;
				viewTransitionHostInstanceIdx = 0;
				name = measureViewTransitionHostInstancesRecursive(state, child, name, name, className, previousMeasurements, !1);
				0 !== (changedParent.flags & 4) && name && (gesture || scheduleViewTransitionEvent(changedParent, props.onUpdate));
			} else 0 !== (changedParent.subtreeFlags & 33554432) && measureNestedViewTransitions(changedParent, gesture);
			changedParent = changedParent.sibling;
		}
	}
	var offscreenSubtreeIsHidden = !1;
	var offscreenSubtreeWasHidden = !1;
	var offscreenDirectParentIsHidden = !1;
	var needsFormReset = !1;
	var PossiblyWeakSet = "function" === typeof WeakSet ? WeakSet : Set;
	var nextEffect = null;
	var viewTransitionContextChanged = !1;
	var inUpdateViewTransition = !1;
	var rootViewTransitionAffected = !1;
	var rootViewTransitionNameCanceled = !1;
	function commitBeforeMutationEffects(root, firstChild, committedLanes) {
		root = root.containerInfo;
		eventsEnabled = _enabled;
		root = getActiveElementDeep(root);
		if (hasSelectionCapabilities(root)) {
			if ("selectionStart" in root) var JSCompiler_temp = {
				start: root.selectionStart,
				end: root.selectionEnd
			};
			else a: {
				JSCompiler_temp = (JSCompiler_temp = root.ownerDocument) && JSCompiler_temp.defaultView || window;
				var selection = JSCompiler_temp.getSelection && JSCompiler_temp.getSelection();
				if (selection && 0 !== selection.rangeCount) {
					JSCompiler_temp = selection.anchorNode;
					var anchorOffset = selection.anchorOffset, focusNode = selection.focusNode;
					selection = selection.focusOffset;
					try {
						JSCompiler_temp.nodeType, focusNode.nodeType;
					} catch (e$21) {
						JSCompiler_temp = null;
						break a;
					}
					var length = 0, start = -1, end = -1, indexWithinAnchor = 0, indexWithinFocus = 0, node = root, parentNode = null;
					b: for (;;) {
						for (var next;;) {
							node !== JSCompiler_temp || 0 !== anchorOffset && 3 !== node.nodeType || (start = length + anchorOffset);
							node !== focusNode || 0 !== selection && 3 !== node.nodeType || (end = length + selection);
							3 === node.nodeType && (length += node.nodeValue.length);
							if (null === (next = node.firstChild)) break;
							parentNode = node;
							node = next;
						}
						for (;;) {
							if (node === root) break b;
							parentNode === JSCompiler_temp && ++indexWithinAnchor === anchorOffset && (start = length);
							parentNode === focusNode && ++indexWithinFocus === selection && (end = length);
							if (null !== (next = node.nextSibling)) break;
							node = parentNode;
							parentNode = node.parentNode;
						}
						node = next;
					}
					JSCompiler_temp = -1 === start || -1 === end ? null : {
						start,
						end
					};
				} else JSCompiler_temp = null;
			}
			JSCompiler_temp = JSCompiler_temp || {
				start: 0,
				end: 0
			};
		} else JSCompiler_temp = null;
		selectionInformation = {
			focusedElem: root,
			selectionRange: JSCompiler_temp
		};
		_enabled = !1;
		committedLanes = (committedLanes & 335544064) === committedLanes;
		nextEffect = firstChild;
		for (firstChild = committedLanes ? 9270 : 1024; null !== nextEffect;) {
			root = nextEffect;
			if (committedLanes && (JSCompiler_temp = root.deletions, null !== JSCompiler_temp)) for (anchorOffset = 0; anchorOffset < JSCompiler_temp.length; anchorOffset++) committedLanes && commitExitViewTransitions(JSCompiler_temp[anchorOffset]);
			if (null === root.alternate && 0 !== (root.flags & 2)) committedLanes && trackEnterViewTransitions(root), commitBeforeMutationEffects_complete(committedLanes);
			else {
				if (22 === root.tag) {
					if (JSCompiler_temp = root.alternate, null !== root.memoizedState) {
						null !== JSCompiler_temp && null === JSCompiler_temp.memoizedState && committedLanes && commitExitViewTransitions(JSCompiler_temp);
						commitBeforeMutationEffects_complete(committedLanes);
						continue;
					} else if (null !== JSCompiler_temp && null !== JSCompiler_temp.memoizedState) {
						committedLanes && trackEnterViewTransitions(root);
						commitBeforeMutationEffects_complete(committedLanes);
						continue;
					}
				}
				JSCompiler_temp = root.child;
				0 !== (root.subtreeFlags & firstChild) && null !== JSCompiler_temp ? (JSCompiler_temp.return = root, nextEffect = JSCompiler_temp) : (committedLanes && commitNestedViewTransitions(root), commitBeforeMutationEffects_complete(committedLanes));
			}
		}
		appearingViewTransitions = null;
	}
	function commitBeforeMutationEffects_complete(isViewTransitionEligible$jscomp$0) {
		for (; null !== nextEffect;) {
			var fiber = nextEffect, isViewTransitionEligible = isViewTransitionEligible$jscomp$0, current = fiber.alternate, flags = fiber.flags;
			switch (fiber.tag) {
				case 0:
				case 11:
				case 15: break;
				case 1:
					if (0 !== (flags & 1024) && null !== current) {
						isViewTransitionEligible = void 0;
						flags = current.memoizedProps;
						current = current.memoizedState;
						var instance = fiber.stateNode;
						try {
							var resolvedPrevProps = resolveClassComponentProps(fiber.type, flags);
							isViewTransitionEligible = instance.getSnapshotBeforeUpdate(resolvedPrevProps, current);
							instance.__reactInternalSnapshotBeforeUpdate = isViewTransitionEligible;
						} catch (error) {
							captureCommitPhaseError(fiber, fiber.return, error);
						}
					}
					break;
				case 3:
					if (0 !== (flags & 1024)) {
						if (current = fiber.stateNode.containerInfo, isViewTransitionEligible = current.nodeType, 9 === isViewTransitionEligible) clearContainerSparingly(current);
						else if (1 === isViewTransitionEligible) switch (current.nodeName) {
							case "HEAD":
							case "HTML":
							case "BODY":
								clearContainerSparingly(current);
								break;
							default: current.textContent = "";
						}
					}
					break;
				case 5:
				case 26:
				case 27:
				case 6:
				case 4:
				case 17: break;
				case 30:
					isViewTransitionEligible && null !== current && (isViewTransitionEligible = getViewTransitionName(current.memoizedProps, current.stateNode), flags = fiber.memoizedProps, flags = getViewTransitionClassName(flags.default, flags.update), "none" !== flags && applyViewTransitionToHostInstances(current, isViewTransitionEligible, flags, current.memoizedState = [], !0));
					break;
				default: if (0 !== (flags & 1024)) throw Error(formatProdErrorMessage(163));
			}
			current = fiber.sibling;
			if (null !== current) {
				current.return = fiber.return;
				nextEffect = current;
				break;
			}
			nextEffect = fiber.return;
		}
	}
	function commitLayoutEffectOnFiber(finishedRoot, current, finishedWork) {
		var flags = finishedWork.flags;
		switch (finishedWork.tag) {
			case 0:
			case 11:
			case 15:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				flags & 4 && commitHookEffectListMount(5, finishedWork);
				break;
			case 1:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				if (flags & 4) if (finishedRoot = finishedWork.stateNode, null === current) try {
					finishedRoot.componentDidMount();
				} catch (error) {
					captureCommitPhaseError(finishedWork, finishedWork.return, error);
				}
				else {
					var prevProps = resolveClassComponentProps(finishedWork.type, current.memoizedProps);
					current = current.memoizedState;
					try {
						finishedRoot.componentDidUpdate(prevProps, current, finishedRoot.__reactInternalSnapshotBeforeUpdate);
					} catch (error$146) {
						captureCommitPhaseError(finishedWork, finishedWork.return, error$146);
					}
				}
				flags & 64 && commitClassCallbacks(finishedWork);
				flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
				break;
			case 3:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				if (flags & 64 && (finishedRoot = finishedWork.updateQueue, null !== finishedRoot)) {
					current = null;
					if (null !== finishedWork.child) switch (finishedWork.child.tag) {
						case 27:
						case 5:
							current = finishedWork.child.stateNode;
							break;
						case 1: current = finishedWork.child.stateNode;
					}
					try {
						commitCallbacks(finishedRoot, current);
					} catch (error) {
						captureCommitPhaseError(finishedWork, finishedWork.return, error);
					}
				}
				break;
			case 27: null === current && flags & 4 && commitHostSingletonAcquisition(finishedWork);
			case 26:
			case 5:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				null === current && flags & 4 && commitHostMount(finishedWork);
				flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
				break;
			case 12:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				break;
			case 31:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				flags & 4 && commitActivityHydrationCallbacks(finishedRoot, finishedWork);
				break;
			case 13:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				flags & 4 && commitSuspenseHydrationCallbacks(finishedRoot, finishedWork);
				flags & 64 && (finishedRoot = finishedWork.memoizedState, null !== finishedRoot && (finishedRoot = finishedRoot.dehydrated, null !== finishedRoot && (finishedWork = retryDehydratedSuspenseBoundary.bind(null, finishedWork), registerSuspenseInstanceRetry(finishedRoot, finishedWork))));
				break;
			case 22:
				flags = null !== finishedWork.memoizedState || offscreenSubtreeIsHidden;
				if (!flags) {
					var newOffscreenSubtreeWasHidden = null !== current && null !== current.memoizedState || offscreenSubtreeWasHidden;
					current = offscreenSubtreeIsHidden;
					prevProps = offscreenSubtreeWasHidden;
					offscreenSubtreeIsHidden = flags;
					(offscreenSubtreeWasHidden = newOffscreenSubtreeWasHidden) && !prevProps ? (flags = 2, 0 !== (finishedWork.subtreeFlags & 8772) && (flags |= 1), recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, flags)) : recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
					offscreenSubtreeIsHidden = current;
					offscreenSubtreeWasHidden = prevProps;
				}
				break;
			case 30:
				recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
				flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
				break;
			case 7: flags & 512 && safelyAttachRef(finishedWork, finishedWork.return);
			default: recursivelyTraverseLayoutEffects(finishedRoot, finishedWork);
		}
	}
	function hideOrUnhideAllChildren(parentFiber, isHidden) {
		for (parentFiber = parentFiber.child; null !== parentFiber;) hideOrUnhideAllChildrenOnFiber(parentFiber, isHidden), parentFiber = parentFiber.sibling;
	}
	function hideOrUnhideAllChildrenOnFiber(fiber, isHidden) {
		switch (fiber.tag) {
			case 5:
			case 26:
				try {
					var instance = fiber.stateNode;
					if (isHidden) {
						var style = instance.style;
						"function" === typeof style.setProperty ? style.setProperty("display", "none", "important") : style.display = "none";
					} else {
						var instance$jscomp$0 = fiber.stateNode, styleProp = fiber.memoizedProps.style, display = void 0 !== styleProp && null !== styleProp && styleProp.hasOwnProperty("display") ? styleProp.display : null;
						instance$jscomp$0.style.display = null == display || "boolean" === typeof display ? "" : ("" + display).trim();
					}
				} catch (error) {
					captureCommitPhaseError(fiber, fiber.return, error);
				}
				hideOrUnhideNearestPortals(fiber, isHidden);
				break;
			case 6:
				try {
					fiber.stateNode.nodeValue = isHidden ? "" : fiber.memoizedProps, viewTransitionMutationContext = !0;
				} catch (error) {
					captureCommitPhaseError(fiber, fiber.return, error);
				}
				break;
			case 18:
				try {
					var instance$jscomp$1 = fiber.stateNode;
					isHidden ? hideOrUnhideDehydratedBoundary(instance$jscomp$1, !0) : hideOrUnhideDehydratedBoundary(fiber.stateNode, !1);
				} catch (error) {
					captureCommitPhaseError(fiber, fiber.return, error);
				}
				break;
			case 22:
			case 23:
				null === fiber.memoizedState && hideOrUnhideAllChildren(fiber, isHidden);
				break;
			default: hideOrUnhideAllChildren(fiber, isHidden);
		}
	}
	function hideOrUnhideNearestPortals(parentFiber, isHidden$jscomp$0) {
		if (parentFiber.subtreeFlags & 67108864) for (parentFiber = parentFiber.child; null !== parentFiber;) {
			a: {
				var fiber = parentFiber, isHidden = isHidden$jscomp$0;
				switch (fiber.tag) {
					case 4:
						hideOrUnhideAllChildrenOnFiber(fiber, isHidden);
						break a;
					case 22:
						null === fiber.memoizedState && hideOrUnhideNearestPortals(fiber, isHidden);
						break a;
					default: hideOrUnhideNearestPortals(fiber, isHidden);
				}
			}
			parentFiber = parentFiber.sibling;
		}
	}
	function detachFiberAfterEffects(fiber) {
		var alternate = fiber.alternate;
		null !== alternate && (fiber.alternate = null, detachFiberAfterEffects(alternate));
		fiber.child = null;
		fiber.deletions = null;
		fiber.sibling = null;
		5 === fiber.tag && (alternate = fiber.stateNode, null !== alternate && detachDeletedInstance(alternate));
		fiber.stateNode = null;
		fiber.return = null;
		fiber.dependencies = null;
		fiber.memoizedProps = null;
		fiber.memoizedState = null;
		fiber.pendingProps = null;
		fiber.stateNode = null;
		fiber.updateQueue = null;
	}
	var hostParent = null;
	var hostParentIsContainer = !1;
	function recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, parent) {
		for (parent = parent.child; null !== parent;) commitDeletionEffectsOnFiber(finishedRoot, nearestMountedAncestor, parent), parent = parent.sibling;
	}
	function commitDeletionEffectsOnFiber(finishedRoot, nearestMountedAncestor, deletedFiber) {
		if (injectedHook && "function" === typeof injectedHook.onCommitFiberUnmount) try {
			injectedHook.onCommitFiberUnmount(rendererID, deletedFiber);
		} catch (err) {}
		switch (deletedFiber.tag) {
			case 26:
				offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor);
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				deletedFiber.memoizedState ? deletedFiber.memoizedState.count-- : deletedFiber.stateNode && !offscreenSubtreeWasHidden && (deletedFiber = deletedFiber.stateNode, deletedFiber.parentNode.removeChild(deletedFiber));
				break;
			case 27:
				offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor);
				commitFragmentInstanceDeletionEffects(deletedFiber);
				var prevHostParent = hostParent, prevHostParentIsContainer = hostParentIsContainer;
				isSingletonScope(deletedFiber.type) && (hostParent = deletedFiber.stateNode, hostParentIsContainer = !1);
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				releaseSingletonInstance(deletedFiber.stateNode, deletedFiber.type, deletedFiber.memoizedProps);
				hostParent = prevHostParent;
				hostParentIsContainer = prevHostParentIsContainer;
				break;
			case 5: offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor), commitFragmentInstanceDeletionEffects(deletedFiber);
			case 6:
				6 === deletedFiber.tag && commitFragmentInstanceDeletionEffects(deletedFiber);
				prevHostParent = hostParent;
				prevHostParentIsContainer = hostParentIsContainer;
				hostParent = null;
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				hostParent = prevHostParent;
				hostParentIsContainer = prevHostParentIsContainer;
				if (null !== hostParent) if (hostParentIsContainer) try {
					(9 === hostParent.nodeType ? hostParent.body : "HTML" === hostParent.nodeName ? hostParent.ownerDocument.body : hostParent).removeChild(deletedFiber.stateNode), viewTransitionMutationContext = !0;
				} catch (error) {
					captureCommitPhaseError(deletedFiber, nearestMountedAncestor, error);
				}
				else try {
					hostParent.removeChild(deletedFiber.stateNode), viewTransitionMutationContext = !0;
				} catch (error) {
					captureCommitPhaseError(deletedFiber, nearestMountedAncestor, error);
				}
				break;
			case 18:
				null !== hostParent && (hostParentIsContainer ? (finishedRoot = hostParent, clearHydrationBoundary(9 === finishedRoot.nodeType ? finishedRoot.body : "HTML" === finishedRoot.nodeName ? finishedRoot.ownerDocument.body : finishedRoot, deletedFiber.stateNode), retryIfBlockedOn(finishedRoot)) : clearHydrationBoundary(hostParent, deletedFiber.stateNode));
				break;
			case 4:
				prevHostParent = hostParent;
				prevHostParentIsContainer = hostParentIsContainer;
				hostParent = deletedFiber.stateNode.containerInfo;
				hostParentIsContainer = !0;
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				hostParent = prevHostParent;
				hostParentIsContainer = prevHostParentIsContainer;
				break;
			case 0:
			case 11:
			case 14:
			case 15:
				commitHookEffectListUnmount(2, deletedFiber, nearestMountedAncestor);
				offscreenSubtreeWasHidden || commitHookEffectListUnmount(4, deletedFiber, nearestMountedAncestor);
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				break;
			case 1:
				offscreenSubtreeWasHidden || (safelyDetachRef(deletedFiber, nearestMountedAncestor), prevHostParent = deletedFiber.stateNode, "function" === typeof prevHostParent.componentWillUnmount && safelyCallComponentWillUnmount(deletedFiber, nearestMountedAncestor, prevHostParent));
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				break;
			case 21:
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				break;
			case 22:
				offscreenSubtreeWasHidden = (prevHostParent = offscreenSubtreeWasHidden) || null !== deletedFiber.memoizedState;
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				offscreenSubtreeWasHidden = prevHostParent;
				break;
			case 30:
				safelyDetachRef(deletedFiber, nearestMountedAncestor);
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				break;
			case 7:
				offscreenSubtreeWasHidden || safelyDetachRef(deletedFiber, nearestMountedAncestor);
				recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
				break;
			default: recursivelyTraverseDeletionEffects(finishedRoot, nearestMountedAncestor, deletedFiber);
		}
	}
	function commitActivityHydrationCallbacks(finishedRoot, finishedWork) {
		if (null === finishedWork.memoizedState && (finishedRoot = finishedWork.alternate, null !== finishedRoot && (finishedRoot = finishedRoot.memoizedState, null !== finishedRoot))) {
			finishedRoot = finishedRoot.dehydrated;
			try {
				retryIfBlockedOn(finishedRoot);
			} catch (error) {
				captureCommitPhaseError(finishedWork, finishedWork.return, error);
			}
		}
	}
	function commitSuspenseHydrationCallbacks(finishedRoot, finishedWork) {
		if (null === finishedWork.memoizedState && (finishedRoot = finishedWork.alternate, null !== finishedRoot && (finishedRoot = finishedRoot.memoizedState, null !== finishedRoot && (finishedRoot = finishedRoot.dehydrated, null !== finishedRoot)))) try {
			retryIfBlockedOn(finishedRoot);
		} catch (error) {
			captureCommitPhaseError(finishedWork, finishedWork.return, error);
		}
	}
	function getRetryCache(finishedWork) {
		switch (finishedWork.tag) {
			case 31:
			case 13:
			case 19:
				var retryCache = finishedWork.stateNode;
				null === retryCache && (retryCache = finishedWork.stateNode = new PossiblyWeakSet());
				return retryCache;
			case 22: return finishedWork = finishedWork.stateNode, retryCache = finishedWork._retryCache, null === retryCache && (retryCache = finishedWork._retryCache = new PossiblyWeakSet()), retryCache;
			default: throw Error(formatProdErrorMessage(435, finishedWork.tag));
		}
	}
	function attachSuspenseRetryListeners(finishedWork, wakeables) {
		var retryCache = getRetryCache(finishedWork);
		wakeables.forEach(function(wakeable) {
			if (!retryCache.has(wakeable)) {
				retryCache.add(wakeable);
				var retry = resolveRetryWakeable.bind(null, finishedWork, wakeable);
				wakeable.then(retry, retry);
			}
		});
	}
	function recursivelyTraverseMutationEffects(root$jscomp$0, parentFiber, lanes) {
		var deletions = parentFiber.deletions;
		if (null !== deletions) for (var i = 0; i < deletions.length; i++) {
			var childToDelete = deletions[i], root = root$jscomp$0, returnFiber = parentFiber, parent = returnFiber;
			a: for (; null !== parent;) {
				switch (parent.tag) {
					case 27:
						if (isSingletonScope(parent.type)) {
							hostParent = parent.stateNode;
							hostParentIsContainer = !1;
							break a;
						}
						break;
					case 5:
						hostParent = parent.stateNode;
						hostParentIsContainer = !1;
						break a;
					case 3:
					case 4:
						hostParent = parent.stateNode.containerInfo;
						hostParentIsContainer = !0;
						break a;
				}
				parent = parent.return;
			}
			if (null === hostParent) throw Error(formatProdErrorMessage(160));
			commitDeletionEffectsOnFiber(root, returnFiber, childToDelete);
			hostParent = null;
			hostParentIsContainer = !1;
			root = childToDelete.alternate;
			null !== root && (root.return = null);
			childToDelete.return = null;
		}
		if (parentFiber.subtreeFlags & 13886) for (parentFiber = parentFiber.child; null !== parentFiber;) commitMutationEffectsOnFiber(parentFiber, root$jscomp$0, lanes), parentFiber = parentFiber.sibling;
	}
	var currentHoistableRoot = null;
	function commitMutationEffectsOnFiber(finishedWork, root, lanes) {
		var current = finishedWork.alternate, flags = finishedWork.flags;
		switch (finishedWork.tag) {
			case 0:
			case 11:
			case 14:
			case 15:
				if (flags & 4 && (current = finishedWork.updateQueue, current = null !== current ? current.events : null, null !== current)) for (var ii = 0; ii < current.length; ii++) {
					var _eventPayloads$ii2 = current[ii];
					_eventPayloads$ii2.ref.impl = _eventPayloads$ii2.nextImpl;
				}
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				flags & 4 && (commitHookEffectListUnmount(3, finishedWork, finishedWork.return), commitHookEffectListMount(3, finishedWork), commitHookEffectListUnmount(5, finishedWork, finishedWork.return));
				break;
			case 1:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				flags & 512 && (offscreenSubtreeWasHidden || null === current || safelyDetachRef(current, current.return));
				flags & 64 && offscreenSubtreeIsHidden && (finishedWork = finishedWork.updateQueue, null !== finishedWork && (root = finishedWork.callbacks, null !== root && (lanes = finishedWork.shared.hiddenCallbacks, finishedWork.shared.hiddenCallbacks = null === lanes ? root : lanes.concat(root))));
				break;
			case 26:
				ii = currentHoistableRoot;
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				flags & 512 && (offscreenSubtreeWasHidden || null === current || safelyDetachRef(current, current.return));
				if (flags & 4) if (flags = null !== current ? current.memoizedState : null, lanes = finishedWork.memoizedState, null === current) if (null === lanes) if (null === finishedWork.stateNode) if (offscreenSubtreeIsHidden) finishedWork.stateNode = createHoistableInstance(finishedWork.type, finishedWork.memoizedProps, root.containerInfo, finishedWork);
				else {
					a: {
						root = finishedWork.type;
						lanes = finishedWork.memoizedProps;
						flags = ii.ownerDocument || ii;
						b: switch (root) {
							case "title":
								current = flags.getElementsByTagName("title")[0];
								if (!current || current[internalHoistableMarker] || current[internalInstanceKey] || "http://www.w3.org/2000/svg" === current.namespaceURI || current.hasAttribute("itemprop")) current = flags.createElement(root), flags.head.insertBefore(current, flags.querySelector("head > title"));
								setInitialProperties(current, root, lanes);
								current[internalInstanceKey] = finishedWork;
								markNodeAsHoistable(current);
								root = current;
								break a;
							case "link":
								if (ii = getHydratableHoistableCache("link", "href", flags).get(root + (lanes.href || ""))) {
									for (_eventPayloads$ii2 = 0; _eventPayloads$ii2 < ii.length; _eventPayloads$ii2++) if (current = ii[_eventPayloads$ii2], current.getAttribute("href") === (null == lanes.href || "" === lanes.href ? null : lanes.href) && current.getAttribute("rel") === (null == lanes.rel ? null : lanes.rel) && current.getAttribute("title") === (null == lanes.title ? null : lanes.title) && current.getAttribute("crossorigin") === (null == lanes.crossOrigin ? null : lanes.crossOrigin)) {
										ii.splice(_eventPayloads$ii2, 1);
										break b;
									}
								}
								current = flags.createElement(root);
								setInitialProperties(current, root, lanes);
								flags.head.appendChild(current);
								break;
							case "meta":
								if (ii = getHydratableHoistableCache("meta", "content", flags).get(root + (lanes.content || ""))) {
									for (_eventPayloads$ii2 = 0; _eventPayloads$ii2 < ii.length; _eventPayloads$ii2++) if (current = ii[_eventPayloads$ii2], current.getAttribute("content") === (null == lanes.content ? null : "" + lanes.content) && current.getAttribute("name") === (null == lanes.name ? null : lanes.name) && current.getAttribute("property") === (null == lanes.property ? null : lanes.property) && current.getAttribute("http-equiv") === (null == lanes.httpEquiv ? null : lanes.httpEquiv) && current.getAttribute("charset") === (null == lanes.charSet ? null : lanes.charSet)) {
										ii.splice(_eventPayloads$ii2, 1);
										break b;
									}
								}
								current = flags.createElement(root);
								setInitialProperties(current, root, lanes);
								flags.head.appendChild(current);
								break;
							default: throw Error(formatProdErrorMessage(468, root));
						}
						current[internalInstanceKey] = finishedWork;
						markNodeAsHoistable(current);
						root = current;
					}
					finishedWork.stateNode = root;
				}
				else offscreenSubtreeIsHidden || mountHoistable(ii, finishedWork.type, finishedWork.stateNode);
				else finishedWork.stateNode = acquireResource(ii, lanes, finishedWork.memoizedProps);
				else flags !== lanes ? (null === flags ? (root = current.stateNode, null === root || offscreenSubtreeWasHidden || root.parentNode.removeChild(root)) : flags.count--, null === lanes ? offscreenSubtreeIsHidden || mountHoistable(ii, finishedWork.type, finishedWork.stateNode) : acquireResource(ii, lanes, finishedWork.memoizedProps)) : null === lanes && null !== finishedWork.stateNode && commitHostUpdate(finishedWork, finishedWork.memoizedProps, current.memoizedProps);
				break;
			case 27:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				flags & 512 && (offscreenSubtreeWasHidden || null === current || safelyDetachRef(current, current.return));
				null !== current && flags & 4 && commitHostUpdate(finishedWork, finishedWork.memoizedProps, current.memoizedProps);
				break;
			case 5:
				ii = offscreenDirectParentIsHidden;
				offscreenDirectParentIsHidden = !1;
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				offscreenDirectParentIsHidden = ii;
				commitReconciliationEffects(finishedWork);
				flags & 512 && (offscreenSubtreeWasHidden || null === current || safelyDetachRef(current, current.return));
				if (finishedWork.flags & 32) {
					root = finishedWork.stateNode;
					try {
						setTextContent(root, ""), viewTransitionMutationContext = !0;
					} catch (error) {
						captureCommitPhaseError(finishedWork, finishedWork.return, error);
					}
				}
				flags & 4 && null != finishedWork.stateNode && (root = finishedWork.memoizedProps, commitHostUpdate(finishedWork, root, null !== current ? current.memoizedProps : root));
				flags & 1024 && (needsFormReset = !0);
				break;
			case 6:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				if (flags & 4) {
					if (null === finishedWork.stateNode) throw Error(formatProdErrorMessage(162));
					root = finishedWork.memoizedProps;
					lanes = finishedWork.stateNode;
					try {
						lanes.nodeValue = root, viewTransitionMutationContext = !0;
					} catch (error) {
						captureCommitPhaseError(finishedWork, finishedWork.return, error);
					}
				}
				break;
			case 3:
				viewTransitionMutationContext = !1;
				tagCaches = null;
				ii = currentHoistableRoot;
				currentHoistableRoot = getHoistableRoot(root.containerInfo);
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				currentHoistableRoot = ii;
				commitReconciliationEffects(finishedWork);
				if (flags & 4 && null !== current && current.memoizedState.isDehydrated) try {
					retryIfBlockedOn(root.containerInfo);
				} catch (error) {
					captureCommitPhaseError(finishedWork, finishedWork.return, error);
				}
				needsFormReset && (needsFormReset = !1, recursivelyResetForms(finishedWork));
				viewTransitionMutationContext = !1;
				break;
			case 4:
				flags = offscreenDirectParentIsHidden;
				offscreenDirectParentIsHidden = offscreenSubtreeIsHidden;
				current = pushMutationContext();
				ii = currentHoistableRoot;
				currentHoistableRoot = getHoistableRoot(finishedWork.stateNode.containerInfo);
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				currentHoistableRoot = ii;
				viewTransitionMutationContext && inUpdateViewTransition && (rootViewTransitionAffected = !0);
				viewTransitionMutationContext = current;
				offscreenDirectParentIsHidden = flags;
				break;
			case 12:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				break;
			case 31:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				flags & 4 && (root = finishedWork.updateQueue, null !== root && (finishedWork.updateQueue = null, attachSuspenseRetryListeners(finishedWork, root)));
				break;
			case 13:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				finishedWork.child.flags & 8192 && null !== finishedWork.memoizedState !== (null !== current && null !== current.memoizedState) && (globalMostRecentFallbackTime = now());
				flags & 4 && (root = finishedWork.updateQueue, null !== root && (finishedWork.updateQueue = null, attachSuspenseRetryListeners(finishedWork, root)));
				break;
			case 22:
				ii = null !== finishedWork.memoizedState;
				_eventPayloads$ii2 = null !== current && null !== current.memoizedState;
				var prevOffscreenSubtreeIsHidden = offscreenSubtreeIsHidden, prevOffscreenSubtreeWasHidden = offscreenSubtreeWasHidden, prevOffscreenDirectParentIsHidden$166 = offscreenDirectParentIsHidden;
				offscreenSubtreeIsHidden = prevOffscreenSubtreeIsHidden || ii;
				offscreenDirectParentIsHidden = prevOffscreenDirectParentIsHidden$166 || ii;
				offscreenSubtreeWasHidden = prevOffscreenSubtreeWasHidden || _eventPayloads$ii2;
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				offscreenSubtreeWasHidden = prevOffscreenSubtreeWasHidden;
				offscreenDirectParentIsHidden = prevOffscreenDirectParentIsHidden$166;
				offscreenSubtreeIsHidden = prevOffscreenSubtreeIsHidden;
				commitReconciliationEffects(finishedWork);
				flags & 8192 && (root = finishedWork.stateNode, root._visibility = ii ? root._visibility & -2 : root._visibility | 1, !ii || null === current || _eventPayloads$ii2 || offscreenSubtreeIsHidden || offscreenSubtreeWasHidden || (root = _eventPayloads$ii2 || offscreenSubtreeWasHidden, lanes = offscreenSubtreeIsHidden, current = offscreenSubtreeWasHidden, offscreenSubtreeIsHidden = ii || offscreenSubtreeIsHidden, offscreenSubtreeWasHidden = root, recursivelyTraverseDisappearLayoutEffects(finishedWork, 2), offscreenSubtreeIsHidden = lanes, offscreenSubtreeWasHidden = current), !ii && offscreenDirectParentIsHidden || hideOrUnhideAllChildren(finishedWork, ii));
				flags & 4 && (root = finishedWork.updateQueue, null !== root && (lanes = root.retryQueue, null !== lanes && (root.retryQueue = null, attachSuspenseRetryListeners(finishedWork, lanes))));
				break;
			case 19:
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				flags & 4 && (root = finishedWork.updateQueue, null !== root && (finishedWork.updateQueue = null, attachSuspenseRetryListeners(finishedWork, root)));
				break;
			case 30:
				flags & 512 && (offscreenSubtreeWasHidden || null === current || safelyDetachRef(current, current.return));
				flags = pushMutationContext();
				ii = inUpdateViewTransition;
				_eventPayloads$ii2 = (lanes & 335544064) === lanes;
				prevOffscreenSubtreeIsHidden = finishedWork.memoizedProps;
				inUpdateViewTransition = _eventPayloads$ii2 && "none" !== getViewTransitionClassName(prevOffscreenSubtreeIsHidden.default, prevOffscreenSubtreeIsHidden.update);
				recursivelyTraverseMutationEffects(root, finishedWork, lanes);
				commitReconciliationEffects(finishedWork);
				_eventPayloads$ii2 && null !== current && viewTransitionMutationContext && (finishedWork.flags |= 4);
				inUpdateViewTransition = ii;
				viewTransitionMutationContext = flags;
				break;
			case 21: break;
			case 7: flags & 512 && (offscreenSubtreeWasHidden || null === current || safelyDetachRef(current, current.return)), current && null !== current.stateNode && (current.stateNode._fragmentFiber = finishedWork);
			default: recursivelyTraverseMutationEffects(root, finishedWork, lanes), commitReconciliationEffects(finishedWork);
		}
	}
	function commitReconciliationEffects(finishedWork) {
		var flags = finishedWork.flags;
		if (flags & 2) {
			try {
				for (var hostParentFiber, parentFiber = finishedWork.return; null !== parentFiber;) {
					if (isHostParent(parentFiber)) {
						hostParentFiber = parentFiber;
						break;
					}
					parentFiber = parentFiber.return;
				}
				parentFiber = null;
				for (var parent = finishedWork.return; null !== parent;) {
					if (isFragmentInstanceParent(parent)) {
						var fragmentInstance = parent.stateNode;
						null === parentFiber ? parentFiber = [fragmentInstance] : parentFiber.push(fragmentInstance);
					}
					if (isFragmentInstanceHostBoundary(parent)) break;
					parent = parent.return;
				}
				var JSCompiler_inline_result = parentFiber;
				if (null == hostParentFiber) throw Error(formatProdErrorMessage(160));
				switch (hostParentFiber.tag) {
					case 27:
						var parent$jscomp$0 = hostParentFiber.stateNode;
						insertOrAppendPlacementNode(finishedWork, getHostSibling(finishedWork), parent$jscomp$0, JSCompiler_inline_result);
						break;
					case 5:
						var parent$149 = hostParentFiber.stateNode;
						hostParentFiber.flags & 32 && (setTextContent(parent$149, ""), hostParentFiber.flags &= -33);
						insertOrAppendPlacementNode(finishedWork, getHostSibling(finishedWork), parent$149, JSCompiler_inline_result);
						break;
					case 3:
					case 4:
						var parent$151 = hostParentFiber.stateNode.containerInfo;
						insertOrAppendPlacementNodeIntoContainer(finishedWork, getHostSibling(finishedWork), parent$151, JSCompiler_inline_result);
						break;
					default: throw Error(formatProdErrorMessage(161));
				}
			} catch (error) {
				captureCommitPhaseError(finishedWork, finishedWork.return, error);
			}
			finishedWork.flags &= -3;
		}
		flags & 4096 && (finishedWork.flags &= -4097);
	}
	function recursivelyResetForms(parentFiber) {
		if (parentFiber.subtreeFlags & 1024) for (parentFiber = parentFiber.child; null !== parentFiber;) {
			var fiber = parentFiber;
			recursivelyResetForms(fiber);
			5 === fiber.tag && fiber.flags & 1024 && (fiber = fiber.stateNode, _enabled = !0, fiber.reset(), _enabled = !1);
			parentFiber = parentFiber.sibling;
		}
	}
	function recursivelyTraverseAfterMutationEffects(root, parentFiber) {
		if (parentFiber.subtreeFlags & 9270) for (parentFiber = parentFiber.child; null !== parentFiber;) commitAfterMutationEffectsOnFiber(parentFiber, root), parentFiber = parentFiber.sibling;
		else measureNestedViewTransitions(parentFiber, !1);
	}
	function commitAfterMutationEffectsOnFiber(finishedWork, root) {
		var current = finishedWork.alternate;
		if (null === current) commitEnterViewTransitions(finishedWork, !1);
		else switch (finishedWork.tag) {
			case 3:
				rootViewTransitionNameCanceled = viewTransitionContextChanged = !1;
				pushViewTransitionCancelableScope();
				recursivelyTraverseAfterMutationEffects(root, finishedWork);
				if (!viewTransitionContextChanged && !rootViewTransitionAffected) {
					finishedWork = viewTransitionCancelableChildren;
					if (null !== finishedWork) for (var i = 0; i < finishedWork.length; i += 3) {
						current = finishedWork[i];
						var oldName = finishedWork[i + 1];
						restoreViewTransitionName(current, finishedWork[i + 2]);
						current = current.ownerDocument.documentElement;
						null !== current && current.animate({
							opacity: [0, 0],
							pointerEvents: ["none", "none"]
						}, {
							duration: 0,
							fill: "forwards",
							pseudoElement: "::view-transition-group(" + oldName + ")"
						});
					}
					finishedWork = root.containerInfo;
					finishedWork = 9 === finishedWork.nodeType ? finishedWork.documentElement : finishedWork.ownerDocument.documentElement;
					null !== finishedWork && "" === finishedWork.style.viewTransitionName && (finishedWork.style.viewTransitionName = "none", finishedWork.animate({
						opacity: [0, 0],
						pointerEvents: ["none", "none"]
					}, {
						duration: 0,
						fill: "forwards",
						pseudoElement: "::view-transition-group(root)"
					}), finishedWork.animate({
						width: [0, 0],
						height: [0, 0]
					}, {
						duration: 0,
						fill: "forwards",
						pseudoElement: "::view-transition"
					}));
					rootViewTransitionNameCanceled = !0;
				}
				viewTransitionCancelableChildren = null;
				break;
			case 5:
				recursivelyTraverseAfterMutationEffects(root, finishedWork);
				break;
			case 4:
				i = viewTransitionContextChanged;
				viewTransitionContextChanged = !1;
				recursivelyTraverseAfterMutationEffects(root, finishedWork);
				viewTransitionContextChanged && (rootViewTransitionAffected = !0);
				viewTransitionContextChanged = i;
				break;
			case 22:
				null === finishedWork.memoizedState && (null !== current.memoizedState ? commitEnterViewTransitions(finishedWork, !1) : recursivelyTraverseAfterMutationEffects(root, finishedWork));
				break;
			case 30:
				i = viewTransitionContextChanged;
				oldName = pushViewTransitionCancelableScope();
				viewTransitionContextChanged = !1;
				recursivelyTraverseAfterMutationEffects(root, finishedWork);
				viewTransitionContextChanged && (finishedWork.flags |= 4);
				var props = finishedWork.memoizedProps, state = finishedWork.stateNode;
				root = getViewTransitionName(props, state);
				state = getViewTransitionName(current.memoizedProps, state);
				var className = getViewTransitionClassName(props.default, props.update);
				"none" === className ? root = !1 : (props = current.memoizedState, current.memoizedState = null, current = finishedWork.child, viewTransitionHostInstanceIdx = 0, root = measureViewTransitionHostInstancesRecursive(finishedWork, current, root, state, className, props, !0), viewTransitionHostInstanceIdx !== (null === props ? 0 : props.length) && (finishedWork.flags |= 32));
				0 !== (finishedWork.flags & 4) && root ? (scheduleViewTransitionEvent(finishedWork, finishedWork.memoizedProps.onUpdate), viewTransitionCancelableChildren = oldName) : null !== oldName && (oldName.push.apply(oldName, viewTransitionCancelableChildren), viewTransitionCancelableChildren = oldName);
				viewTransitionContextChanged = 0 !== (finishedWork.flags & 32) ? !0 : i;
				break;
			default: recursivelyTraverseAfterMutationEffects(root, finishedWork);
		}
	}
	function recursivelyTraverseLayoutEffects(root, parentFiber) {
		if (parentFiber.subtreeFlags & 8772) for (parentFiber = parentFiber.child; null !== parentFiber;) commitLayoutEffectOnFiber(root, parentFiber.alternate, parentFiber), parentFiber = parentFiber.sibling;
	}
	function recursivelyTraverseDisappearLayoutEffects(parentFiber, layoutEffectTraversalFlags$jscomp$0) {
		for (parentFiber = parentFiber.child; null !== parentFiber;) {
			var finishedWork = parentFiber, layoutEffectTraversalFlags = layoutEffectTraversalFlags$jscomp$0;
			switch (finishedWork.tag) {
				case 0:
				case 11:
				case 14:
				case 15:
					commitHookEffectListUnmount(4, finishedWork, finishedWork.return);
					recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
					break;
				case 1:
					safelyDetachRef(finishedWork, finishedWork.return);
					var instance = finishedWork.stateNode;
					"function" === typeof instance.componentWillUnmount && safelyCallComponentWillUnmount(finishedWork, finishedWork.return, instance);
					recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
					break;
				case 27: 0 !== (layoutEffectTraversalFlags & 2) && releaseSingletonInstance(finishedWork.stateNode, finishedWork.type, finishedWork.memoizedProps);
				case 5:
					safelyDetachRef(finishedWork, finishedWork.return);
					5 !== finishedWork.tag && 27 !== finishedWork.tag || commitFragmentInstanceDeletionEffects(finishedWork);
					recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
					break;
				case 6:
					commitFragmentInstanceDeletionEffects(finishedWork);
					break;
				case 26:
					safelyDetachRef(finishedWork, finishedWork.return);
					instance = finishedWork.stateNode;
					null !== finishedWork.memoizedState || null === instance || offscreenSubtreeWasHidden || instance.parentNode.removeChild(instance);
					recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
					break;
				case 22:
					null === finishedWork.memoizedState && recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
					break;
				case 30:
					safelyDetachRef(finishedWork, finishedWork.return);
					recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
					break;
				case 7: safelyDetachRef(finishedWork, finishedWork.return);
				default: recursivelyTraverseDisappearLayoutEffects(finishedWork, layoutEffectTraversalFlags);
			}
			parentFiber = parentFiber.sibling;
		}
	}
	function recursivelyTraverseReappearLayoutEffects(finishedRoot$jscomp$0, parentFiber, layoutEffectTraversalFlags) {
		layoutEffectTraversalFlags = 0 !== (parentFiber.subtreeFlags & 8772) ? layoutEffectTraversalFlags : layoutEffectTraversalFlags & -2;
		for (parentFiber = parentFiber.child; null !== parentFiber;) {
			var current = parentFiber.alternate, finishedRoot = finishedRoot$jscomp$0, finishedWork = parentFiber, flags = finishedWork.flags, includeWorkInProgressEffects = 0 !== (layoutEffectTraversalFlags & 1);
			switch (finishedWork.tag) {
				case 0:
				case 11:
				case 15:
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					commitHookEffectListMount(4, finishedWork);
					break;
				case 1:
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					current = finishedWork;
					finishedRoot = current.stateNode;
					if ("function" === typeof finishedRoot.componentDidMount) try {
						finishedRoot.componentDidMount();
					} catch (error) {
						captureCommitPhaseError(current, current.return, error);
					}
					current = finishedWork;
					finishedRoot = current.updateQueue;
					if (null !== finishedRoot) {
						var instance = current.stateNode;
						try {
							var hiddenCallbacks = finishedRoot.shared.hiddenCallbacks;
							if (null !== hiddenCallbacks) for (finishedRoot.shared.hiddenCallbacks = null, finishedRoot = 0; finishedRoot < hiddenCallbacks.length; finishedRoot++) callCallback(hiddenCallbacks[finishedRoot], instance);
						} catch (error) {
							captureCommitPhaseError(current, current.return, error);
						}
					}
					includeWorkInProgressEffects && flags & 64 && commitClassCallbacks(finishedWork);
					safelyAttachRef(finishedWork, finishedWork.return);
					break;
				case 27: 0 !== (layoutEffectTraversalFlags & 2) && commitHostSingletonAcquisition(finishedWork);
				case 5:
					5 !== finishedWork.tag && 27 !== finishedWork.tag || commitFragmentInstanceInsertionEffects(finishedWork);
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					includeWorkInProgressEffects && null === current && flags & 4 && commitHostMount(finishedWork);
					safelyAttachRef(finishedWork, finishedWork.return);
					break;
				case 6:
					commitFragmentInstanceInsertionEffects(finishedWork);
					break;
				case 26:
					instance = finishedWork.stateNode;
					null !== finishedWork.memoizedState || null === instance || offscreenSubtreeIsHidden || mountHoistable(getHoistableRoot(instance.ownerDocument), finishedWork.type, instance);
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					includeWorkInProgressEffects && null === current && flags & 4 && commitHostMount(finishedWork);
					safelyAttachRef(finishedWork, finishedWork.return);
					break;
				case 12:
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					break;
				case 31:
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					includeWorkInProgressEffects && flags & 4 && commitActivityHydrationCallbacks(finishedRoot, finishedWork);
					break;
				case 13:
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					includeWorkInProgressEffects && flags & 4 && commitSuspenseHydrationCallbacks(finishedRoot, finishedWork);
					break;
				case 22:
					null === finishedWork.memoizedState && recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					safelyAttachRef(finishedWork, finishedWork.return);
					break;
				case 30:
					recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
					safelyAttachRef(finishedWork, finishedWork.return);
					break;
				case 7: safelyAttachRef(finishedWork, finishedWork.return);
				default: recursivelyTraverseReappearLayoutEffects(finishedRoot, finishedWork, layoutEffectTraversalFlags);
			}
			parentFiber = parentFiber.sibling;
		}
	}
	function commitOffscreenPassiveMountEffects(current, finishedWork) {
		var previousCache = null;
		null !== current && null !== current.memoizedState && null !== current.memoizedState.cachePool && (previousCache = current.memoizedState.cachePool.pool);
		current = null;
		null !== finishedWork.memoizedState && null !== finishedWork.memoizedState.cachePool && (current = finishedWork.memoizedState.cachePool.pool);
		current !== previousCache && (null != current && current.refCount++, null != previousCache && releaseCache(previousCache));
	}
	function commitCachePassiveMountEffect(current, finishedWork) {
		current = null;
		null !== finishedWork.alternate && (current = finishedWork.alternate.memoizedState.cache);
		finishedWork = finishedWork.memoizedState.cache;
		finishedWork !== current && (finishedWork.refCount++, null != current && releaseCache(current));
	}
	function recursivelyTraversePassiveMountEffects(root, parentFiber, committedLanes, committedTransitions) {
		var isViewTransitionEligible = (committedLanes & 335544064) === committedLanes;
		if (parentFiber.subtreeFlags & (isViewTransitionEligible ? 10262 : 10256)) for (parentFiber = parentFiber.child; null !== parentFiber;) commitPassiveMountOnFiber(root, parentFiber, committedLanes, committedTransitions), parentFiber = parentFiber.sibling;
		else isViewTransitionEligible && restoreNestedViewTransitions(parentFiber);
	}
	function commitPassiveMountOnFiber(finishedRoot, finishedWork, committedLanes, committedTransitions) {
		var isViewTransitionEligible = (committedLanes & 335544064) === committedLanes;
		isViewTransitionEligible && null === finishedWork.alternate && null !== finishedWork.return && null !== finishedWork.return.alternate && restoreEnterOrExitViewTransitions(finishedWork);
		var flags = finishedWork.flags;
		switch (finishedWork.tag) {
			case 0:
			case 11:
			case 15:
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				flags & 2048 && commitHookEffectListMount(9, finishedWork);
				break;
			case 1:
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				break;
			case 3:
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				isViewTransitionEligible && rootViewTransitionNameCanceled && (finishedRoot = finishedRoot.containerInfo, finishedRoot = 9 === finishedRoot.nodeType ? finishedRoot.body : "HTML" === finishedRoot.nodeName ? finishedRoot.ownerDocument.body : finishedRoot, "root" === finishedRoot.style.viewTransitionName && (finishedRoot.style.viewTransitionName = ""), finishedRoot = finishedRoot.ownerDocument.documentElement, null !== finishedRoot && "none" === finishedRoot.style.viewTransitionName && (finishedRoot.style.viewTransitionName = ""));
				flags & 2048 && (flags = null, null !== finishedWork.alternate && (flags = finishedWork.alternate.memoizedState.cache), finishedWork = finishedWork.memoizedState.cache, finishedWork !== flags && (finishedWork.refCount++, null != flags && releaseCache(flags)));
				break;
			case 12:
				if (flags & 2048) {
					recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
					flags = finishedWork.stateNode;
					try {
						var _finishedWork$memoize2 = finishedWork.memoizedProps, id = _finishedWork$memoize2.id, onPostCommit = _finishedWork$memoize2.onPostCommit;
						"function" === typeof onPostCommit && onPostCommit(id, null === finishedWork.alternate ? "mount" : "update", flags.passiveEffectDuration, -0);
					} catch (error) {
						captureCommitPhaseError(finishedWork, finishedWork.return, error);
					}
				} else recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				break;
			case 31:
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				break;
			case 13:
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				break;
			case 23: break;
			case 22:
				_finishedWork$memoize2 = finishedWork.stateNode;
				id = finishedWork.alternate;
				null !== finishedWork.memoizedState ? (isViewTransitionEligible && null !== id && null === id.memoizedState && restoreEnterOrExitViewTransitions(id), _finishedWork$memoize2._visibility & 2 ? recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions) : recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork)) : (isViewTransitionEligible && null !== id && null !== id.memoizedState && restoreEnterOrExitViewTransitions(finishedWork), _finishedWork$memoize2._visibility & 2 ? recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions) : (_finishedWork$memoize2._visibility |= 2, recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, 0 !== (finishedWork.subtreeFlags & 10256) || !1)));
				flags & 2048 && commitOffscreenPassiveMountEffects(id, finishedWork);
				break;
			case 24:
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				flags & 2048 && commitCachePassiveMountEffect(finishedWork.alternate, finishedWork);
				break;
			case 30:
				isViewTransitionEligible && (flags = finishedWork.alternate, null !== flags && (restoreViewTransitionOnHostInstances(flags.child, !0), restoreViewTransitionOnHostInstances(finishedWork.child, !0)));
				recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
				break;
			default: recursivelyTraversePassiveMountEffects(finishedRoot, finishedWork, committedLanes, committedTransitions);
		}
	}
	function recursivelyTraverseReconnectPassiveEffects(finishedRoot$jscomp$0, parentFiber, committedLanes$jscomp$0, committedTransitions$jscomp$0, includeWorkInProgressEffects) {
		includeWorkInProgressEffects = includeWorkInProgressEffects && (0 !== (parentFiber.subtreeFlags & 10256) || !1);
		for (parentFiber = parentFiber.child; null !== parentFiber;) {
			var finishedRoot = finishedRoot$jscomp$0, finishedWork = parentFiber, committedLanes = committedLanes$jscomp$0, committedTransitions = committedTransitions$jscomp$0, flags = finishedWork.flags;
			switch (finishedWork.tag) {
				case 0:
				case 11:
				case 15:
					recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects);
					commitHookEffectListMount(8, finishedWork);
					break;
				case 23: break;
				case 22:
					var instance = finishedWork.stateNode;
					null !== finishedWork.memoizedState ? instance._visibility & 2 ? recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects) : recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork) : (instance._visibility |= 2, recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects));
					includeWorkInProgressEffects && flags & 2048 && commitOffscreenPassiveMountEffects(finishedWork.alternate, finishedWork);
					break;
				case 24:
					recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects);
					includeWorkInProgressEffects && flags & 2048 && commitCachePassiveMountEffect(finishedWork.alternate, finishedWork);
					break;
				default: recursivelyTraverseReconnectPassiveEffects(finishedRoot, finishedWork, committedLanes, committedTransitions, includeWorkInProgressEffects);
			}
			parentFiber = parentFiber.sibling;
		}
	}
	function recursivelyTraverseAtomicPassiveEffects(finishedRoot$jscomp$0, parentFiber) {
		if (parentFiber.subtreeFlags & 10256) for (parentFiber = parentFiber.child; null !== parentFiber;) {
			var finishedRoot = finishedRoot$jscomp$0, finishedWork = parentFiber, flags = finishedWork.flags;
			switch (finishedWork.tag) {
				case 22:
					recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork);
					flags & 2048 && commitOffscreenPassiveMountEffects(finishedWork.alternate, finishedWork);
					break;
				case 24:
					recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork);
					flags & 2048 && commitCachePassiveMountEffect(finishedWork.alternate, finishedWork);
					break;
				default: recursivelyTraverseAtomicPassiveEffects(finishedRoot, finishedWork);
			}
			parentFiber = parentFiber.sibling;
		}
	}
	var suspenseyCommitFlag = 8192;
	function recursivelyAccumulateSuspenseyCommit(parentFiber, committedLanes, suspendedState) {
		if (parentFiber.subtreeFlags & suspenseyCommitFlag) for (parentFiber = parentFiber.child; null !== parentFiber;) accumulateSuspenseyCommitOnFiber(parentFiber, committedLanes, suspendedState), parentFiber = parentFiber.sibling;
	}
	function accumulateSuspenseyCommitOnFiber(fiber, committedLanes, suspendedState) {
		switch (fiber.tag) {
			case 26:
				recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
				fiber.flags & suspenseyCommitFlag && (null !== fiber.memoizedState ? suspendResource(suspendedState, currentHoistableRoot, fiber.memoizedState, fiber.memoizedProps) : (fiber = fiber.stateNode, (committedLanes & 335544128) === committedLanes && suspendInstance(suspendedState, fiber)));
				break;
			case 5:
				recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
				fiber.flags & suspenseyCommitFlag && (fiber = fiber.stateNode, (committedLanes & 335544128) === committedLanes && suspendInstance(suspendedState, fiber));
				break;
			case 3:
			case 4:
				var previousHoistableRoot = currentHoistableRoot;
				currentHoistableRoot = getHoistableRoot(fiber.stateNode.containerInfo);
				recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
				currentHoistableRoot = previousHoistableRoot;
				break;
			case 22:
				null === fiber.memoizedState && (previousHoistableRoot = fiber.alternate, null !== previousHoistableRoot && null !== previousHoistableRoot.memoizedState ? (previousHoistableRoot = suspenseyCommitFlag, suspenseyCommitFlag = 16777216, recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState), suspenseyCommitFlag = previousHoistableRoot) : recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState));
				break;
			case 30:
				if (0 !== (fiber.flags & suspenseyCommitFlag) && (previousHoistableRoot = fiber.memoizedProps.name, null != previousHoistableRoot && "auto" !== previousHoistableRoot)) {
					var state = fiber.stateNode;
					state.paired = null;
					null === appearingViewTransitions && (appearingViewTransitions = /* @__PURE__ */ new Map());
					appearingViewTransitions.set(previousHoistableRoot, state);
				}
				recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
				break;
			default: recursivelyAccumulateSuspenseyCommit(fiber, committedLanes, suspendedState);
		}
	}
	function detachAlternateSiblings(parentFiber) {
		var previousFiber = parentFiber.alternate;
		if (null !== previousFiber && (parentFiber = previousFiber.child, null !== parentFiber)) {
			previousFiber.child = null;
			do
				previousFiber = parentFiber.sibling, parentFiber.sibling = null, parentFiber = previousFiber;
			while (null !== parentFiber);
		}
	}
	function recursivelyTraversePassiveUnmountEffects(parentFiber) {
		var deletions = parentFiber.deletions;
		if (0 !== (parentFiber.flags & 16)) {
			if (null !== deletions) for (var i = 0; i < deletions.length; i++) {
				var childToDelete = deletions[i];
				nextEffect = childToDelete;
				commitPassiveUnmountEffectsInsideOfDeletedTree_begin(childToDelete, parentFiber);
			}
			detachAlternateSiblings(parentFiber);
		}
		if (parentFiber.subtreeFlags & 10256) for (parentFiber = parentFiber.child; null !== parentFiber;) commitPassiveUnmountOnFiber(parentFiber), parentFiber = parentFiber.sibling;
	}
	function commitPassiveUnmountOnFiber(finishedWork) {
		switch (finishedWork.tag) {
			case 0:
			case 11:
			case 15:
				recursivelyTraversePassiveUnmountEffects(finishedWork);
				finishedWork.flags & 2048 && commitHookEffectListUnmount(9, finishedWork, finishedWork.return);
				break;
			case 3:
				recursivelyTraversePassiveUnmountEffects(finishedWork);
				break;
			case 12:
				recursivelyTraversePassiveUnmountEffects(finishedWork);
				break;
			case 22:
				var instance = finishedWork.stateNode;
				null !== finishedWork.memoizedState && instance._visibility & 2 && (null === finishedWork.return || 13 !== finishedWork.return.tag) ? (instance._visibility &= -3, recursivelyTraverseDisconnectPassiveEffects(finishedWork)) : recursivelyTraversePassiveUnmountEffects(finishedWork);
				break;
			default: recursivelyTraversePassiveUnmountEffects(finishedWork);
		}
	}
	function recursivelyTraverseDisconnectPassiveEffects(parentFiber) {
		var deletions = parentFiber.deletions;
		if (0 !== (parentFiber.flags & 16)) {
			if (null !== deletions) for (var i = 0; i < deletions.length; i++) {
				var childToDelete = deletions[i];
				nextEffect = childToDelete;
				commitPassiveUnmountEffectsInsideOfDeletedTree_begin(childToDelete, parentFiber);
			}
			detachAlternateSiblings(parentFiber);
		}
		for (parentFiber = parentFiber.child; null !== parentFiber;) {
			deletions = parentFiber;
			switch (deletions.tag) {
				case 0:
				case 11:
				case 15:
					commitHookEffectListUnmount(8, deletions, deletions.return);
					recursivelyTraverseDisconnectPassiveEffects(deletions);
					break;
				case 22:
					i = deletions.stateNode;
					i._visibility & 2 && (i._visibility &= -3, recursivelyTraverseDisconnectPassiveEffects(deletions));
					break;
				default: recursivelyTraverseDisconnectPassiveEffects(deletions);
			}
			parentFiber = parentFiber.sibling;
		}
	}
	function commitPassiveUnmountEffectsInsideOfDeletedTree_begin(deletedSubtreeRoot, nearestMountedAncestor) {
		for (; null !== nextEffect;) {
			var fiber = nextEffect;
			switch (fiber.tag) {
				case 0:
				case 11:
				case 15:
					commitHookEffectListUnmount(8, fiber, nearestMountedAncestor);
					break;
				case 23:
				case 22:
					if (null !== fiber.memoizedState && null !== fiber.memoizedState.cachePool) {
						var cache = fiber.memoizedState.cachePool.pool;
						null != cache && cache.refCount++;
					}
					break;
				case 24: releaseCache(fiber.memoizedState.cache);
			}
			cache = fiber.child;
			if (null !== cache) cache.return = fiber, nextEffect = cache;
			else a: for (fiber = deletedSubtreeRoot; null !== nextEffect;) {
				cache = nextEffect;
				var sibling = cache.sibling, returnFiber = cache.return;
				detachFiberAfterEffects(cache);
				if (cache === fiber) {
					nextEffect = null;
					break a;
				}
				if (null !== sibling) {
					sibling.return = returnFiber;
					nextEffect = sibling;
					break a;
				}
				nextEffect = returnFiber;
			}
		}
	}
	var DefaultAsyncDispatcher = {
		getCacheForType: function(resourceType) {
			var cache = readContext(CacheContext), cacheForType = cache.data.get(resourceType);
			void 0 === cacheForType && (cacheForType = resourceType(), cache.data.set(resourceType, cacheForType));
			return cacheForType;
		},
		cacheSignal: function() {
			return readContext(CacheContext).controller.signal;
		}
	};
	var PossiblyWeakMap = "function" === typeof WeakMap ? WeakMap : Map;
	var executionContext = 0;
	var workInProgressRoot = null;
	var workInProgress = null;
	var workInProgressRootRenderLanes = 0;
	var workInProgressSuspendedReason = 0;
	var workInProgressThrownValue = null;
	var workInProgressRootDidSkipSuspendedSiblings = !1;
	var workInProgressRootIsPrerendering = !1;
	var workInProgressRootDidAttachPingListener = !1;
	var entangledRenderLanes = 0;
	var workInProgressRootExitStatus = 0;
	var workInProgressRootSkippedLanes = 0;
	var workInProgressRootInterleavedUpdatedLanes = 0;
	var workInProgressRootPingedLanes = 0;
	var workInProgressDeferredLane = 0;
	var workInProgressSuspendedRetryLanes = 0;
	var workInProgressRootConcurrentErrors = null;
	var workInProgressRootRecoverableErrors = null;
	var workInProgressRootDidIncludeRecursiveRenderUpdate = !1;
	var globalMostRecentFallbackTime = 0;
	var globalMostRecentTransitionTime = 0;
	var workInProgressRootRenderTargetTime = Infinity;
	var workInProgressTransitions = null;
	var legacyErrorBoundariesThatAlreadyFailed = null;
	var pendingEffectsStatus = 0;
	var pendingEffectsRoot = null;
	var pendingFinishedWork = null;
	var pendingEffectsLanes = 0;
	var pendingEffectsRemainingLanes = 0;
	var pendingPassiveTransitions = null;
	var pendingRecoverableErrors = null;
	var pendingViewTransition = null;
	var pendingViewTransitionEvents = null;
	var pendingTransitionTypes = null;
	var nestedUpdateCount = 0;
	var rootWithNestedUpdates = null;
	function requestUpdateLane() {
		return 0 !== (executionContext & 2) && 0 !== workInProgressRootRenderLanes ? workInProgressRootRenderLanes & -workInProgressRootRenderLanes : null !== ReactSharedInternals.T ? requestTransitionLane() : resolveUpdatePriority();
	}
	function requestDeferredLane() {
		if (0 === workInProgressDeferredLane) if (0 === (workInProgressRootRenderLanes & 536870912) || isHydrating) {
			var lane = nextTransitionDeferredLane;
			nextTransitionDeferredLane <<= 1;
			0 === (nextTransitionDeferredLane & 3932160) && (nextTransitionDeferredLane = 262144);
			workInProgressDeferredLane = lane;
		} else workInProgressDeferredLane = 536870912;
		lane = suspenseHandlerStackCursor.current;
		null !== lane && (lane.flags |= 32);
		return workInProgressDeferredLane;
	}
	function scheduleViewTransitionEvent(fiber, callback) {
		if (null != callback) {
			var state = fiber.stateNode, instance = state.ref;
			null === instance && (instance = state.ref = createViewTransitionInstance(getViewTransitionName(fiber.memoizedProps, state)));
			null === pendingViewTransitionEvents && (pendingViewTransitionEvents = []);
			pendingViewTransitionEvents.push(callback.bind(null, instance));
		}
	}
	function scheduleUpdateOnFiber(root, fiber, lane) {
		if (root === workInProgressRoot && (2 === workInProgressSuspendedReason || 9 === workInProgressSuspendedReason) || null !== root.cancelPendingCommit) prepareFreshStack(root, 0), markRootSuspended(root, workInProgressRootRenderLanes, workInProgressDeferredLane, !1);
		markRootUpdated$1(root, lane);
		if (0 === (executionContext & 2) || root !== workInProgressRoot) root === workInProgressRoot && (0 === (executionContext & 2) && (workInProgressRootInterleavedUpdatedLanes |= lane), 4 === workInProgressRootExitStatus && markRootSuspended(root, workInProgressRootRenderLanes, workInProgressDeferredLane, !1)), ensureRootIsScheduled(root);
	}
	function performWorkOnRoot(root$jscomp$0, lanes, forceSync) {
		if (0 !== (executionContext & 6)) throw Error(formatProdErrorMessage(327));
		var shouldTimeSlice = !forceSync && 0 === (lanes & 127) && 0 === (lanes & root$jscomp$0.expiredLanes) || checkIfRootIsPrerendering(root$jscomp$0, lanes), exitStatus = shouldTimeSlice ? renderRootConcurrent(root$jscomp$0, lanes) : renderRootSync(root$jscomp$0, lanes, !0), renderWasConcurrent = shouldTimeSlice;
		do {
			if (0 === exitStatus) {
				workInProgressRootIsPrerendering && !shouldTimeSlice && markRootSuspended(root$jscomp$0, lanes, 0, !1);
				break;
			} else {
				forceSync = root$jscomp$0.current.alternate;
				if (renderWasConcurrent && !isRenderConsistentWithExternalStores(forceSync)) {
					exitStatus = renderRootSync(root$jscomp$0, lanes, !1);
					renderWasConcurrent = !1;
					continue;
				}
				if (2 === exitStatus) {
					renderWasConcurrent = lanes;
					if (root$jscomp$0.errorRecoveryDisabledLanes & renderWasConcurrent) var JSCompiler_inline_result = 0;
					else JSCompiler_inline_result = root$jscomp$0.pendingLanes & -536870913, JSCompiler_inline_result = 0 !== JSCompiler_inline_result ? JSCompiler_inline_result : JSCompiler_inline_result & 536870912 ? 536870912 : 0;
					if (0 !== JSCompiler_inline_result) {
						lanes = JSCompiler_inline_result;
						a: {
							var root = root$jscomp$0;
							exitStatus = workInProgressRootConcurrentErrors;
							var wasRootDehydrated = root.current.memoizedState.isDehydrated;
							wasRootDehydrated && (prepareFreshStack(root, JSCompiler_inline_result).flags |= 256);
							JSCompiler_inline_result = renderRootSync(root, JSCompiler_inline_result, !1);
							if (2 !== JSCompiler_inline_result && 6 !== JSCompiler_inline_result) {
								if (workInProgressRootDidAttachPingListener && !wasRootDehydrated) {
									root.errorRecoveryDisabledLanes |= renderWasConcurrent;
									workInProgressRootInterleavedUpdatedLanes |= renderWasConcurrent;
									exitStatus = 4;
									break a;
								}
								renderWasConcurrent = workInProgressRootRecoverableErrors;
								workInProgressRootRecoverableErrors = exitStatus;
								null !== renderWasConcurrent && (null === workInProgressRootRecoverableErrors ? workInProgressRootRecoverableErrors = renderWasConcurrent : workInProgressRootRecoverableErrors.push.apply(workInProgressRootRecoverableErrors, renderWasConcurrent));
							}
							exitStatus = JSCompiler_inline_result;
						}
						renderWasConcurrent = !1;
						if (2 !== exitStatus) continue;
					}
				}
				if (1 === exitStatus) {
					prepareFreshStack(root$jscomp$0, 0);
					markRootSuspended(root$jscomp$0, lanes, 0, !0);
					break;
				}
				a: {
					shouldTimeSlice = root$jscomp$0;
					renderWasConcurrent = exitStatus;
					switch (renderWasConcurrent) {
						case 0:
						case 1: throw Error(formatProdErrorMessage(345));
						case 4: if ((lanes & 4194048) !== lanes && (lanes & 62914560) !== lanes) break;
						case 6:
							markRootSuspended(shouldTimeSlice, lanes, workInProgressDeferredLane, !workInProgressRootDidSkipSuspendedSiblings);
							break a;
						case 2:
							workInProgressRootRecoverableErrors = null;
							break;
						case 3:
						case 5: break;
						default: throw Error(formatProdErrorMessage(329));
					}
					if ((lanes & 62914560) === lanes && (exitStatus = globalMostRecentFallbackTime + 300 - now(), 10 < exitStatus)) {
						markRootSuspended(shouldTimeSlice, lanes, workInProgressDeferredLane, !workInProgressRootDidSkipSuspendedSiblings);
						if (0 !== getNextLanes(shouldTimeSlice, 0, !0)) break a;
						pendingEffectsLanes = lanes;
						shouldTimeSlice.timeoutHandle = scheduleTimeout(completeRootWhenReady.bind(null, shouldTimeSlice, forceSync, workInProgressRootRecoverableErrors, workInProgressTransitions, workInProgressRootDidIncludeRecursiveRenderUpdate, lanes, workInProgressDeferredLane, workInProgressRootInterleavedUpdatedLanes, workInProgressSuspendedRetryLanes, workInProgressRootDidSkipSuspendedSiblings, renderWasConcurrent, "Throttled", -0, 0), exitStatus);
						break a;
					}
					completeRootWhenReady(shouldTimeSlice, forceSync, workInProgressRootRecoverableErrors, workInProgressTransitions, workInProgressRootDidIncludeRecursiveRenderUpdate, lanes, workInProgressDeferredLane, workInProgressRootInterleavedUpdatedLanes, workInProgressSuspendedRetryLanes, workInProgressRootDidSkipSuspendedSiblings, renderWasConcurrent, null, -0, 0);
				}
			}
			break;
		} while (1);
		ensureRootIsScheduled(root$jscomp$0);
	}
	function completeRootWhenReady(root, finishedWork, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, lanes, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedCommitReason, completedRenderStartTime, completedRenderEndTime) {
		root.timeoutHandle = -1;
		var subtreeFlags = finishedWork.subtreeFlags, isViewTransitionEligible = (lanes & 335544064) === lanes;
		suspendedCommitReason = null;
		if (isViewTransitionEligible || subtreeFlags & 8192 || 16785408 === (subtreeFlags & 16785408)) {
			if (suspendedCommitReason = {
				stylesheets: null,
				count: 0,
				imgCount: 0,
				imgBytes: 0,
				suspenseyImages: [],
				waitingForImages: !0,
				waitingForViewTransition: !1,
				unsuspend: noop$1
			}, appearingViewTransitions = null, accumulateSuspenseyCommitOnFiber(finishedWork, lanes, suspendedCommitReason), isViewTransitionEligible && (subtreeFlags = suspendedCommitReason, isViewTransitionEligible = root.containerInfo, isViewTransitionEligible = (9 === isViewTransitionEligible.nodeType ? isViewTransitionEligible : isViewTransitionEligible.ownerDocument).__reactViewTransition, null != isViewTransitionEligible && (subtreeFlags.count++, subtreeFlags.waitingForViewTransition = !0, subtreeFlags = onUnsuspend.bind(subtreeFlags), isViewTransitionEligible.finished.then(subtreeFlags, subtreeFlags))), subtreeFlags = (lanes & 62914560) === lanes ? globalMostRecentFallbackTime - now() : (lanes & 4194048) === lanes ? globalMostRecentTransitionTime - now() : 0, subtreeFlags = waitForCommitToBeReady(suspendedCommitReason, subtreeFlags), null !== subtreeFlags) {
				pendingEffectsLanes = lanes;
				root.cancelPendingCommit = subtreeFlags(completeRoot.bind(null, root, finishedWork, lanes, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedCommitReason, null, completedRenderStartTime, completedRenderEndTime));
				markRootSuspended(root, lanes, spawnedLane, !didSkipSuspendedSiblings);
				return;
			}
		}
		completeRoot(root, finishedWork, lanes, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedCommitReason);
	}
	function isRenderConsistentWithExternalStores(finishedWork) {
		for (var node = finishedWork;;) {
			var tag = node.tag;
			if ((0 === tag || 11 === tag || 15 === tag) && node.flags & 16384 && (tag = node.updateQueue, null !== tag && (tag = tag.stores, null !== tag))) for (var i = 0; i < tag.length; i++) {
				var check = tag[i], getSnapshot = check.getSnapshot;
				check = check.value;
				try {
					if (!objectIs(getSnapshot(), check)) return !1;
				} catch (error) {
					return !1;
				}
			}
			tag = node.child;
			if (node.subtreeFlags & 16384 && null !== tag) tag.return = node, node = tag;
			else {
				if (node === finishedWork) break;
				for (; null === node.sibling;) {
					if (null === node.return || node.return === finishedWork) return !0;
					node = node.return;
				}
				node.sibling.return = node.return;
				node = node.sibling;
			}
		}
		return !0;
	}
	function markRootSuspended(root, suspendedLanes, spawnedLane, didAttemptEntireTree) {
		suspendedLanes = getEntangledLanes(root, suspendedLanes);
		suspendedLanes &= ~workInProgressRootPingedLanes;
		suspendedLanes &= ~workInProgressRootInterleavedUpdatedLanes;
		root.suspendedLanes |= suspendedLanes;
		root.pingedLanes &= ~suspendedLanes;
		didAttemptEntireTree && (root.warmLanes |= suspendedLanes);
		didAttemptEntireTree = root.expirationTimes;
		for (var lanes = suspendedLanes; 0 < lanes;) {
			var index$6 = 31 - clz32(lanes), lane = 1 << index$6;
			didAttemptEntireTree[index$6] = -1;
			lanes &= ~lane;
		}
		0 !== spawnedLane && markSpawnedDeferredLane(root, spawnedLane, suspendedLanes);
	}
	function flushSyncWork$1() {
		return 0 === (executionContext & 6) ? (flushSyncWorkAcrossRoots_impl(0, !1), !1) : !0;
	}
	function resetWorkInProgressStack() {
		if (null !== workInProgress) {
			if (0 === workInProgressSuspendedReason) var interruptedWork = workInProgress.return;
			else interruptedWork = workInProgress, lastContextDependency = currentlyRenderingFiber$1 = null, resetHooksOnUnwind(interruptedWork), thenableState$1 = null, thenableIndexCounter$1 = 0, interruptedWork = workInProgress;
			for (; null !== interruptedWork;) unwindInterruptedWork(interruptedWork.alternate, interruptedWork), interruptedWork = interruptedWork.return;
			workInProgress = null;
		}
	}
	function prepareFreshStack(root, lanes) {
		var timeoutHandle = root.timeoutHandle;
		-1 !== timeoutHandle && (root.timeoutHandle = -1, cancelTimeout(timeoutHandle));
		timeoutHandle = root.cancelPendingCommit;
		null !== timeoutHandle && (root.cancelPendingCommit = null, timeoutHandle());
		pendingEffectsLanes = 0;
		resetWorkInProgressStack();
		workInProgressRoot = root;
		workInProgress = timeoutHandle = createWorkInProgress(root.current, null);
		workInProgressRootRenderLanes = lanes;
		workInProgressSuspendedReason = 0;
		workInProgressThrownValue = null;
		workInProgressRootDidSkipSuspendedSiblings = !1;
		workInProgressRootIsPrerendering = checkIfRootIsPrerendering(root, lanes);
		workInProgressRootDidAttachPingListener = !1;
		workInProgressSuspendedRetryLanes = workInProgressDeferredLane = workInProgressRootPingedLanes = workInProgressRootInterleavedUpdatedLanes = workInProgressRootSkippedLanes = workInProgressRootExitStatus = 0;
		workInProgressRootRecoverableErrors = workInProgressRootConcurrentErrors = null;
		workInProgressRootDidIncludeRecursiveRenderUpdate = !1;
		entangledRenderLanes = getEntangledLanes(root, lanes);
		finishQueueingConcurrentUpdates();
		return timeoutHandle;
	}
	function handleThrow(root, thrownValue) {
		currentlyRenderingFiber = null;
		ReactSharedInternals.H = ContextOnlyDispatcher;
		thrownValue === SuspenseException || thrownValue === SuspenseActionException ? (thrownValue = getSuspendedThenable(), workInProgressSuspendedReason = 3) : thrownValue === SuspenseyCommitException ? (thrownValue = getSuspendedThenable(), workInProgressSuspendedReason = 4) : workInProgressSuspendedReason = thrownValue === SelectiveHydrationException ? 8 : null !== thrownValue && "object" === typeof thrownValue && "function" === typeof thrownValue.then ? 6 : 1;
		workInProgressThrownValue = thrownValue;
		null === workInProgress && (workInProgressRootExitStatus = 1, logUncaughtError(root, createCapturedValueAtFiber(thrownValue, root.current)));
	}
	function shouldRemainOnPreviousScreen() {
		var handler = suspenseHandlerStackCursor.current;
		return null === handler ? !0 : (workInProgressRootRenderLanes & 4194048) === workInProgressRootRenderLanes ? null === shellBoundary ? !0 : !1 : (workInProgressRootRenderLanes & 62914560) === workInProgressRootRenderLanes || 0 !== (workInProgressRootRenderLanes & 536870912) ? handler === shellBoundary : !1;
	}
	function pushDispatcher() {
		var prevDispatcher = ReactSharedInternals.H;
		ReactSharedInternals.H = ContextOnlyDispatcher;
		return null === prevDispatcher ? ContextOnlyDispatcher : prevDispatcher;
	}
	function pushAsyncDispatcher() {
		var prevAsyncDispatcher = ReactSharedInternals.A;
		ReactSharedInternals.A = DefaultAsyncDispatcher;
		return prevAsyncDispatcher;
	}
	function renderDidSuspendDelayIfPossible() {
		workInProgressRootExitStatus = 4;
		workInProgressRootDidSkipSuspendedSiblings || (workInProgressRootRenderLanes & 4194048) !== workInProgressRootRenderLanes && null !== suspenseHandlerStackCursor.current || (workInProgressRootIsPrerendering = !0);
		0 === (workInProgressRootSkippedLanes & 134217727) && 0 === (workInProgressRootInterleavedUpdatedLanes & 134217727) || null === workInProgressRoot || markRootSuspended(workInProgressRoot, workInProgressRootRenderLanes, workInProgressDeferredLane, !1);
	}
	function renderRootSync(root, lanes, shouldYieldForPrerendering) {
		var prevExecutionContext = executionContext;
		executionContext |= 2;
		var prevDispatcher = pushDispatcher(), prevAsyncDispatcher = pushAsyncDispatcher();
		if (workInProgressRoot !== root || workInProgressRootRenderLanes !== lanes) workInProgressTransitions = null, prepareFreshStack(root, lanes);
		lanes = !1;
		var exitStatus = workInProgressRootExitStatus;
		a: do
			try {
				if (0 !== workInProgressSuspendedReason && null !== workInProgress) {
					var unitOfWork = workInProgress, thrownValue = workInProgressThrownValue;
					switch (workInProgressSuspendedReason) {
						case 8:
							resetWorkInProgressStack();
							exitStatus = 6;
							break a;
						case 3:
						case 2:
						case 9:
						case 6:
							null === suspenseHandlerStackCursor.current && (lanes = !0);
							var reason = workInProgressSuspendedReason;
							workInProgressSuspendedReason = 0;
							workInProgressThrownValue = null;
							throwAndUnwindWorkLoop(root, unitOfWork, thrownValue, reason);
							if (shouldYieldForPrerendering && workInProgressRootIsPrerendering) {
								exitStatus = 0;
								break a;
							}
							break;
						default: reason = workInProgressSuspendedReason, workInProgressSuspendedReason = 0, workInProgressThrownValue = null, throwAndUnwindWorkLoop(root, unitOfWork, thrownValue, reason);
					}
				}
				workLoopSync();
				exitStatus = workInProgressRootExitStatus;
				break;
			} catch (thrownValue$184) {
				handleThrow(root, thrownValue$184);
			}
		while (1);
		lanes && root.shellSuspendCounter++;
		lastContextDependency = currentlyRenderingFiber$1 = null;
		executionContext = prevExecutionContext;
		ReactSharedInternals.H = prevDispatcher;
		ReactSharedInternals.A = prevAsyncDispatcher;
		null === workInProgress && (workInProgressRoot = null, workInProgressRootRenderLanes = 0, finishQueueingConcurrentUpdates());
		return exitStatus;
	}
	function workLoopSync() {
		for (; null !== workInProgress;) performUnitOfWork(workInProgress);
	}
	function renderRootConcurrent(root, lanes) {
		var prevExecutionContext = executionContext;
		executionContext |= 2;
		var prevDispatcher = pushDispatcher(), prevAsyncDispatcher = pushAsyncDispatcher();
		workInProgressRoot !== root || workInProgressRootRenderLanes !== lanes ? (workInProgressTransitions = null, workInProgressRootRenderTargetTime = now() + 500, prepareFreshStack(root, lanes)) : workInProgressRootIsPrerendering = checkIfRootIsPrerendering(root, lanes);
		a: do
			try {
				if (0 !== workInProgressSuspendedReason && null !== workInProgress) {
					lanes = workInProgress;
					var thrownValue = workInProgressThrownValue;
					b: switch (workInProgressSuspendedReason) {
						case 1:
							workInProgressSuspendedReason = 0;
							workInProgressThrownValue = null;
							throwAndUnwindWorkLoop(root, lanes, thrownValue, 1);
							break;
						case 2:
						case 9:
							if (isThenableResolved(thrownValue)) {
								workInProgressSuspendedReason = 0;
								workInProgressThrownValue = null;
								replaySuspendedUnitOfWork(lanes);
								break;
							}
							lanes = function() {
								2 !== workInProgressSuspendedReason && 9 !== workInProgressSuspendedReason || workInProgressRoot !== root || (workInProgressSuspendedReason = 7);
								ensureRootIsScheduled(root);
							};
							thrownValue.then(lanes, lanes);
							break a;
						case 3:
							workInProgressSuspendedReason = 7;
							break a;
						case 4:
							workInProgressSuspendedReason = 5;
							break a;
						case 7:
							isThenableResolved(thrownValue) ? (workInProgressSuspendedReason = 0, workInProgressThrownValue = null, replaySuspendedUnitOfWork(lanes)) : (workInProgressSuspendedReason = 0, workInProgressThrownValue = null, throwAndUnwindWorkLoop(root, lanes, thrownValue, 7));
							break;
						case 5:
							var resource = null;
							switch (workInProgress.tag) {
								case 26: resource = workInProgress.memoizedState;
								case 5:
								case 27:
									var hostFiber = workInProgress;
									if (resource ? preloadResource(resource) : hostFiber.stateNode.complete) {
										workInProgressSuspendedReason = 0;
										workInProgressThrownValue = null;
										var sibling = hostFiber.sibling;
										if (null !== sibling) workInProgress = sibling;
										else {
											var returnFiber = hostFiber.return;
											null !== returnFiber ? (workInProgress = returnFiber, completeUnitOfWork(returnFiber)) : workInProgress = null;
										}
										break b;
									}
							}
							workInProgressSuspendedReason = 0;
							workInProgressThrownValue = null;
							throwAndUnwindWorkLoop(root, lanes, thrownValue, 5);
							break;
						case 6:
							workInProgressSuspendedReason = 0;
							workInProgressThrownValue = null;
							throwAndUnwindWorkLoop(root, lanes, thrownValue, 6);
							break;
						case 8:
							resetWorkInProgressStack();
							workInProgressRootExitStatus = 6;
							break a;
						default: throw Error(formatProdErrorMessage(462));
					}
				}
				workLoopConcurrentByScheduler();
				break;
			} catch (thrownValue$186) {
				handleThrow(root, thrownValue$186);
			}
		while (1);
		lastContextDependency = currentlyRenderingFiber$1 = null;
		ReactSharedInternals.H = prevDispatcher;
		ReactSharedInternals.A = prevAsyncDispatcher;
		executionContext = prevExecutionContext;
		if (null !== workInProgress) return 0;
		workInProgressRoot = null;
		workInProgressRootRenderLanes = 0;
		finishQueueingConcurrentUpdates();
		return workInProgressRootExitStatus;
	}
	function workLoopConcurrentByScheduler() {
		for (; null !== workInProgress && !shouldYield();) performUnitOfWork(workInProgress);
	}
	function performUnitOfWork(unitOfWork) {
		var next = beginWork(unitOfWork.alternate, unitOfWork, entangledRenderLanes);
		unitOfWork.memoizedProps = unitOfWork.pendingProps;
		null === next ? completeUnitOfWork(unitOfWork) : workInProgress = next;
	}
	function replaySuspendedUnitOfWork(unitOfWork) {
		var next = unitOfWork;
		var current = next.alternate;
		switch (next.tag) {
			case 15:
			case 0:
				next = replayFunctionComponent(current, next, next.pendingProps, next.type, void 0, workInProgressRootRenderLanes);
				break;
			case 11:
				next = replayFunctionComponent(current, next, next.pendingProps, next.type.render, next.ref, workInProgressRootRenderLanes);
				break;
			case 5:
				resetHooksOnUnwind(next);
				var fiber = next;
				fiber === hydrationParentFiber && (isHydrating ? (popToNextHostParent(fiber), 5 === fiber.tag && null != fiber.stateNode && (nextHydratableInstance = fiber.stateNode)) : (popToNextHostParent(fiber), isHydrating = !0));
			default: unwindInterruptedWork(current, next), next = workInProgress = resetWorkInProgress(next, entangledRenderLanes), next = beginWork(current, next, entangledRenderLanes);
		}
		unitOfWork.memoizedProps = unitOfWork.pendingProps;
		null === next ? completeUnitOfWork(unitOfWork) : workInProgress = next;
	}
	function throwAndUnwindWorkLoop(root, unitOfWork, thrownValue, suspendedReason) {
		lastContextDependency = currentlyRenderingFiber$1 = null;
		resetHooksOnUnwind(unitOfWork);
		thenableState$1 = null;
		thenableIndexCounter$1 = 0;
		var returnFiber = unitOfWork.return;
		try {
			if (throwException(root, returnFiber, unitOfWork, thrownValue, workInProgressRootRenderLanes)) {
				workInProgressRootExitStatus = 1;
				logUncaughtError(root, createCapturedValueAtFiber(thrownValue, root.current));
				workInProgress = null;
				return;
			}
		} catch (error) {
			if (null !== returnFiber) throw workInProgress = returnFiber, error;
			workInProgressRootExitStatus = 1;
			logUncaughtError(root, createCapturedValueAtFiber(thrownValue, root.current));
			workInProgress = null;
			return;
		}
		if (unitOfWork.flags & 32768) {
			if (isHydrating || 1 === suspendedReason) root = !0;
			else if (workInProgressRootIsPrerendering || 0 !== (workInProgressRootRenderLanes & 536870912)) root = !1;
			else if (workInProgressRootDidSkipSuspendedSiblings = root = !0, 2 === suspendedReason || 9 === suspendedReason || 3 === suspendedReason || 6 === suspendedReason) suspendedReason = suspenseHandlerStackCursor.current, null !== suspendedReason && 13 === suspendedReason.tag && (suspendedReason.flags |= 16384);
			unwindUnitOfWork(unitOfWork, root);
		} else completeUnitOfWork(unitOfWork);
	}
	function completeUnitOfWork(unitOfWork) {
		var completedWork = unitOfWork;
		do {
			if (0 !== (completedWork.flags & 32768)) {
				unwindUnitOfWork(completedWork, workInProgressRootDidSkipSuspendedSiblings);
				return;
			}
			unitOfWork = completedWork.return;
			var next = completeWork(completedWork.alternate, completedWork, entangledRenderLanes);
			if (null !== next) {
				workInProgress = next;
				return;
			}
			completedWork = completedWork.sibling;
			if (null !== completedWork) {
				workInProgress = completedWork;
				return;
			}
			workInProgress = completedWork = unitOfWork;
		} while (null !== completedWork);
		0 === workInProgressRootExitStatus && (workInProgressRootExitStatus = 5);
	}
	function unwindUnitOfWork(unitOfWork, skipSiblings) {
		do {
			var next = unwindWork(unitOfWork.alternate, unitOfWork);
			if (null !== next) {
				next.flags &= 32767;
				workInProgress = next;
				return;
			}
			next = unitOfWork.return;
			null !== next && (next.flags |= 32768, next.subtreeFlags = 0, next.deletions = null);
			if (!skipSiblings && (unitOfWork = unitOfWork.sibling, null !== unitOfWork)) {
				workInProgress = unitOfWork;
				return;
			}
			workInProgress = unitOfWork = next;
		} while (null !== unitOfWork);
		workInProgressRootExitStatus = 6;
		workInProgress = null;
	}
	function completeRoot(root, finishedWork, lanes, recoverableErrors, transitions, didIncludeRenderPhaseUpdate, spawnedLane, updatedLanes, suspendedRetryLanes, didSkipSuspendedSiblings, exitStatus, suspendedState) {
		root.cancelPendingCommit = null;
		do
			flushPendingEffects();
		while (0 !== pendingEffectsStatus);
		if (0 !== (executionContext & 6)) throw Error(formatProdErrorMessage(327));
		if (null !== finishedWork) {
			if (finishedWork === root.current) throw Error(formatProdErrorMessage(177));
			root === workInProgressRoot && (workInProgress = workInProgressRoot = null, workInProgressRootRenderLanes = 0);
			pendingFinishedWork = finishedWork;
			pendingEffectsRoot = root;
			pendingEffectsLanes = lanes;
			pendingPassiveTransitions = transitions;
			pendingRecoverableErrors = recoverableErrors;
			commitRoot(root, finishedWork, lanes, spawnedLane, updatedLanes, suspendedRetryLanes, suspendedState);
		}
	}
	function commitRoot(root, finishedWork, lanes, spawnedLane, updatedLanes, suspendedRetryLanes, suspendedState) {
		var remainingLanes = finishedWork.lanes | finishedWork.childLanes;
		pendingEffectsRemainingLanes = remainingLanes;
		remainingLanes |= concurrentlyUpdatedLanes;
		markRootFinished(root, lanes, remainingLanes, spawnedLane, updatedLanes, suspendedRetryLanes);
		pendingViewTransitionEvents = null;
		(lanes & 335544064) === lanes ? (pendingTransitionTypes = claimQueuedTransitionTypes(root), spawnedLane = 10262) : (pendingTransitionTypes = null, spawnedLane = 10256);
		0 !== (finishedWork.subtreeFlags & spawnedLane) || 0 !== (finishedWork.flags & spawnedLane) ? (root.callbackNode = null, root.callbackPriority = 0, scheduleCallback$1(NormalPriority$1, function() {
			flushPassiveEffects();
			return null;
		})) : (root.callbackNode = null, root.callbackPriority = 0);
		shouldStartViewTransition = !1;
		spawnedLane = 0 !== (finishedWork.flags & 13878);
		if (0 !== (finishedWork.subtreeFlags & 13878) || spawnedLane) {
			spawnedLane = ReactSharedInternals.T;
			ReactSharedInternals.T = null;
			updatedLanes = ReactDOMSharedInternals.p;
			ReactDOMSharedInternals.p = 2;
			suspendedRetryLanes = executionContext;
			executionContext |= 4;
			try {
				commitBeforeMutationEffects(root, finishedWork, lanes);
			} finally {
				executionContext = suspendedRetryLanes, ReactDOMSharedInternals.p = updatedLanes, ReactSharedInternals.T = spawnedLane;
			}
		}
		pendingEffectsStatus = 1;
		shouldStartViewTransition ? pendingViewTransition = startViewTransition(suspendedState, root.containerInfo, pendingTransitionTypes, flushMutationEffects, flushLayoutEffects, flushAfterMutationEffects, flushSpawnedWork, flushPassiveEffects, reportViewTransitionError, null, null) : (flushMutationEffects(), flushLayoutEffects(), flushSpawnedWork());
	}
	function reportViewTransitionError(error) {
		if (0 !== pendingEffectsStatus) {
			var onRecoverableError = pendingEffectsRoot.onRecoverableError;
			onRecoverableError(error, { componentStack: null });
		}
	}
	function flushAfterMutationEffects() {
		3 === pendingEffectsStatus && (pendingEffectsStatus = 0, commitAfterMutationEffectsOnFiber(pendingFinishedWork, pendingEffectsRoot), pendingEffectsStatus = 4);
	}
	function flushMutationEffects() {
		if (1 === pendingEffectsStatus) {
			pendingEffectsStatus = 0;
			var root = pendingEffectsRoot, finishedWork = pendingFinishedWork, lanes = pendingEffectsLanes, rootMutationHasEffect = 0 !== (finishedWork.flags & 13878);
			if (0 !== (finishedWork.subtreeFlags & 13878) || rootMutationHasEffect) {
				rootMutationHasEffect = ReactSharedInternals.T;
				ReactSharedInternals.T = null;
				var previousPriority = ReactDOMSharedInternals.p;
				ReactDOMSharedInternals.p = 2;
				var prevExecutionContext = executionContext;
				executionContext |= 4;
				try {
					inUpdateViewTransition = rootViewTransitionAffected = !1;
					commitMutationEffectsOnFiber(finishedWork, root, lanes);
					lanes = selectionInformation;
					var curFocusedElem = getActiveElementDeep(root.containerInfo), priorFocusedElem = lanes.focusedElem, priorSelectionRange = lanes.selectionRange;
					if (curFocusedElem !== priorFocusedElem && priorFocusedElem && priorFocusedElem.ownerDocument && containsNode(priorFocusedElem.ownerDocument.documentElement, priorFocusedElem)) {
						if (null !== priorSelectionRange && hasSelectionCapabilities(priorFocusedElem)) {
							var start = priorSelectionRange.start, end = priorSelectionRange.end;
							void 0 === end && (end = start);
							if ("selectionStart" in priorFocusedElem) priorFocusedElem.selectionStart = start, priorFocusedElem.selectionEnd = Math.min(end, priorFocusedElem.value.length);
							else {
								var doc = priorFocusedElem.ownerDocument || document, win = doc && doc.defaultView || window;
								if (win.getSelection) {
									var selection = win.getSelection(), length = priorFocusedElem.textContent.length, start$jscomp$0 = Math.min(priorSelectionRange.start, length), end$jscomp$0 = void 0 === priorSelectionRange.end ? start$jscomp$0 : Math.min(priorSelectionRange.end, length);
									!selection.extend && start$jscomp$0 > end$jscomp$0 && (curFocusedElem = end$jscomp$0, end$jscomp$0 = start$jscomp$0, start$jscomp$0 = curFocusedElem);
									var startMarker = getNodeForCharacterOffset(priorFocusedElem, start$jscomp$0), endMarker = getNodeForCharacterOffset(priorFocusedElem, end$jscomp$0);
									if (startMarker && endMarker && (1 !== selection.rangeCount || selection.anchorNode !== startMarker.node || selection.anchorOffset !== startMarker.offset || selection.focusNode !== endMarker.node || selection.focusOffset !== endMarker.offset)) {
										var range = doc.createRange();
										range.setStart(startMarker.node, startMarker.offset);
										selection.removeAllRanges();
										start$jscomp$0 > end$jscomp$0 ? (selection.addRange(range), selection.extend(endMarker.node, endMarker.offset)) : (range.setEnd(endMarker.node, endMarker.offset), selection.addRange(range));
									}
								}
							}
						}
						doc = [];
						for (selection = priorFocusedElem; selection = selection.parentNode;) 1 === selection.nodeType && doc.push({
							element: selection,
							left: selection.scrollLeft,
							top: selection.scrollTop
						});
						"function" === typeof priorFocusedElem.focus && priorFocusedElem.focus();
						for (priorFocusedElem = 0; priorFocusedElem < doc.length; priorFocusedElem++) {
							var info = doc[priorFocusedElem];
							info.element.scrollLeft = info.left;
							info.element.scrollTop = info.top;
						}
					}
					_enabled = !!eventsEnabled;
					selectionInformation = eventsEnabled = null;
				} finally {
					executionContext = prevExecutionContext, ReactDOMSharedInternals.p = previousPriority, ReactSharedInternals.T = rootMutationHasEffect;
				}
			}
			root.current = finishedWork;
			pendingEffectsStatus = 2;
		}
	}
	function flushLayoutEffects() {
		if (2 === pendingEffectsStatus) {
			pendingEffectsStatus = 0;
			var root = pendingEffectsRoot, finishedWork = pendingFinishedWork, rootHasLayoutEffect = 0 !== (finishedWork.flags & 8772);
			if (0 !== (finishedWork.subtreeFlags & 8772) || rootHasLayoutEffect) {
				rootHasLayoutEffect = ReactSharedInternals.T;
				ReactSharedInternals.T = null;
				var previousPriority = ReactDOMSharedInternals.p;
				ReactDOMSharedInternals.p = 2;
				var prevExecutionContext = executionContext;
				executionContext |= 4;
				try {
					commitLayoutEffectOnFiber(root, finishedWork.alternate, finishedWork);
				} finally {
					executionContext = prevExecutionContext, ReactDOMSharedInternals.p = previousPriority, ReactSharedInternals.T = rootHasLayoutEffect;
				}
			}
			pendingEffectsStatus = 3;
		}
	}
	function flushSpawnedWork() {
		if (4 === pendingEffectsStatus || 3 === pendingEffectsStatus) {
			pendingEffectsStatus = 0;
			var committedViewTransition = pendingViewTransition;
			pendingViewTransition = null;
			requestPaint();
			var root = pendingEffectsRoot, finishedWork = pendingFinishedWork, lanes = pendingEffectsLanes, recoverableErrors = pendingRecoverableErrors, passiveSubtreeMask = (lanes & 335544064) === lanes ? 10262 : 10256;
			0 !== (finishedWork.subtreeFlags & passiveSubtreeMask) || 0 !== (finishedWork.flags & passiveSubtreeMask) ? pendingEffectsStatus = 5 : (pendingEffectsStatus = 0, pendingFinishedWork = pendingEffectsRoot = null, releaseRootPooledCache(root, root.pendingLanes));
			passiveSubtreeMask = root.pendingLanes;
			0 === passiveSubtreeMask && (legacyErrorBoundariesThatAlreadyFailed = null);
			lanesToEventPriority(lanes);
			finishedWork = finishedWork.stateNode;
			if (injectedHook && "function" === typeof injectedHook.onCommitFiberRoot) try {
				injectedHook.onCommitFiberRoot(rendererID, finishedWork, void 0, 128 === (finishedWork.current.flags & 128));
			} catch (err) {}
			if (null !== recoverableErrors) {
				finishedWork = ReactSharedInternals.T;
				passiveSubtreeMask = ReactDOMSharedInternals.p;
				ReactDOMSharedInternals.p = 2;
				ReactSharedInternals.T = null;
				try {
					for (var onRecoverableError = root.onRecoverableError, i = 0; i < recoverableErrors.length; i++) {
						var recoverableError = recoverableErrors[i];
						onRecoverableError(recoverableError.value, { componentStack: recoverableError.stack });
					}
				} finally {
					ReactSharedInternals.T = finishedWork, ReactDOMSharedInternals.p = passiveSubtreeMask;
				}
			}
			recoverableErrors = pendingViewTransitionEvents;
			onRecoverableError = pendingTransitionTypes;
			pendingTransitionTypes = null;
			if (null !== recoverableErrors && (pendingViewTransitionEvents = null, null === onRecoverableError && (onRecoverableError = []), null !== committedViewTransition)) for (recoverableError = 0; recoverableError < recoverableErrors.length; recoverableError++) finishedWork = (0, recoverableErrors[recoverableError])(onRecoverableError), void 0 !== finishedWork && committedViewTransition.finished.finally(finishedWork);
			0 !== (pendingEffectsLanes & 3) && flushPendingEffects();
			ensureRootIsScheduled(root);
			passiveSubtreeMask = root.pendingLanes;
			0 !== (lanes & 261930) && 0 !== (passiveSubtreeMask & 42) ? root === rootWithNestedUpdates ? nestedUpdateCount++ : (nestedUpdateCount = 0, rootWithNestedUpdates = root) : (nestedUpdateCount = 0, rootWithNestedUpdates = null);
			flushSyncWorkAcrossRoots_impl(0, !1);
		}
	}
	function releaseRootPooledCache(root, remainingLanes) {
		0 === (root.pooledCacheLanes &= remainingLanes) && (remainingLanes = root.pooledCache, null != remainingLanes && (root.pooledCache = null, releaseCache(remainingLanes)));
	}
	function flushPendingEffects() {
		null !== pendingViewTransition && (pendingViewTransition.skipTransition(), pendingViewTransition = null);
		flushMutationEffects();
		flushLayoutEffects();
		flushSpawnedWork();
		return flushPassiveEffects();
	}
	function flushPassiveEffects() {
		if (5 !== pendingEffectsStatus) return !1;
		var root = pendingEffectsRoot, remainingLanes = pendingEffectsRemainingLanes;
		pendingEffectsRemainingLanes = 0;
		var renderPriority = lanesToEventPriority(pendingEffectsLanes), prevTransition = ReactSharedInternals.T, previousPriority = ReactDOMSharedInternals.p;
		try {
			ReactDOMSharedInternals.p = 32 > renderPriority ? 32 : renderPriority;
			ReactSharedInternals.T = null;
			renderPriority = pendingPassiveTransitions;
			pendingPassiveTransitions = null;
			var root$jscomp$0 = pendingEffectsRoot, lanes = pendingEffectsLanes;
			pendingEffectsStatus = 0;
			pendingFinishedWork = pendingEffectsRoot = null;
			pendingEffectsLanes = 0;
			if (0 !== (executionContext & 6)) throw Error(formatProdErrorMessage(331));
			var prevExecutionContext = executionContext;
			executionContext |= 4;
			commitPassiveUnmountOnFiber(root$jscomp$0.current);
			commitPassiveMountOnFiber(root$jscomp$0, root$jscomp$0.current, lanes, renderPriority);
			executionContext = prevExecutionContext;
			flushSyncWorkAcrossRoots_impl(0, !1);
			if (injectedHook && "function" === typeof injectedHook.onPostCommitFiberRoot) try {
				injectedHook.onPostCommitFiberRoot(rendererID, root$jscomp$0);
			} catch (err) {}
			return !0;
		} finally {
			ReactDOMSharedInternals.p = previousPriority, ReactSharedInternals.T = prevTransition, releaseRootPooledCache(root, remainingLanes);
		}
	}
	function captureCommitPhaseErrorOnRoot(rootFiber, sourceFiber, error) {
		sourceFiber = createCapturedValueAtFiber(error, sourceFiber);
		sourceFiber = createRootErrorUpdate(rootFiber.stateNode, sourceFiber, 2);
		rootFiber = enqueueUpdate(rootFiber, sourceFiber, 2);
		null !== rootFiber && (markRootUpdated$1(rootFiber, 2), ensureRootIsScheduled(rootFiber));
	}
	function captureCommitPhaseError(sourceFiber, nearestMountedAncestor, error) {
		if (3 === sourceFiber.tag) captureCommitPhaseErrorOnRoot(sourceFiber, sourceFiber, error);
		else for (; null !== nearestMountedAncestor;) {
			if (3 === nearestMountedAncestor.tag) {
				captureCommitPhaseErrorOnRoot(nearestMountedAncestor, sourceFiber, error);
				break;
			} else if (1 === nearestMountedAncestor.tag) {
				var instance = nearestMountedAncestor.stateNode;
				if ("function" === typeof nearestMountedAncestor.type.getDerivedStateFromError || "function" === typeof instance.componentDidCatch && (null === legacyErrorBoundariesThatAlreadyFailed || !legacyErrorBoundariesThatAlreadyFailed.has(instance))) {
					sourceFiber = createCapturedValueAtFiber(error, sourceFiber);
					error = createClassErrorUpdate(2);
					instance = enqueueUpdate(nearestMountedAncestor, error, 2);
					null !== instance && (initializeClassErrorUpdate(error, instance, nearestMountedAncestor, sourceFiber), markRootUpdated$1(instance, 2), ensureRootIsScheduled(instance));
					break;
				}
			}
			nearestMountedAncestor = nearestMountedAncestor.return;
		}
	}
	function attachPingListener(root, wakeable, lanes) {
		var pingCache = root.pingCache;
		if (null === pingCache) {
			pingCache = root.pingCache = new PossiblyWeakMap();
			var threadIDs = /* @__PURE__ */ new Set();
			pingCache.set(wakeable, threadIDs);
		} else threadIDs = pingCache.get(wakeable), void 0 === threadIDs && (threadIDs = /* @__PURE__ */ new Set(), pingCache.set(wakeable, threadIDs));
		threadIDs.has(lanes) || (workInProgressRootDidAttachPingListener = !0, threadIDs.add(lanes), root = pingSuspendedRoot.bind(null, root, wakeable, lanes), wakeable.then(root, root));
	}
	function pingSuspendedRoot(root, wakeable, pingedLanes) {
		var pingCache = root.pingCache;
		null !== pingCache && pingCache.delete(wakeable);
		root.pingedLanes |= root.suspendedLanes & pingedLanes;
		root.warmLanes &= ~pingedLanes;
		workInProgressRoot === root && (workInProgressRootRenderLanes & pingedLanes) === pingedLanes && (4 === workInProgressRootExitStatus || 3 === workInProgressRootExitStatus && (workInProgressRootRenderLanes & 62914560) === workInProgressRootRenderLanes && 300 > now() - globalMostRecentFallbackTime ? 0 === (executionContext & 2) ? prepareFreshStack(root, 0) : workInProgressRootPingedLanes |= pingedLanes : workInProgressRootPingedLanes |= pingedLanes, workInProgressSuspendedRetryLanes === workInProgressRootRenderLanes && (workInProgressSuspendedRetryLanes = 0));
		ensureRootIsScheduled(root);
	}
	function retryTimedOutBoundary(boundaryFiber, retryLane) {
		0 === retryLane && (retryLane = claimNextRetryLane());
		boundaryFiber = enqueueConcurrentRenderForLane(boundaryFiber, retryLane);
		null !== boundaryFiber && (markRootUpdated$1(boundaryFiber, retryLane), ensureRootIsScheduled(boundaryFiber));
	}
	function retryDehydratedSuspenseBoundary(boundaryFiber) {
		var suspenseState = boundaryFiber.memoizedState, retryLane = 0;
		null !== suspenseState && (retryLane = suspenseState.retryLane);
		retryTimedOutBoundary(boundaryFiber, retryLane);
	}
	function resolveRetryWakeable(boundaryFiber, wakeable) {
		var retryLane = 0;
		switch (boundaryFiber.tag) {
			case 31:
			case 13:
				var retryCache = boundaryFiber.stateNode;
				var suspenseState = boundaryFiber.memoizedState;
				null !== suspenseState && (retryLane = suspenseState.retryLane);
				break;
			case 19:
				retryCache = boundaryFiber.stateNode;
				break;
			case 22:
				retryCache = boundaryFiber.stateNode._retryCache;
				break;
			default: throw Error(formatProdErrorMessage(314));
		}
		null !== retryCache && retryCache.delete(wakeable);
		retryTimedOutBoundary(boundaryFiber, retryLane);
	}
	function scheduleCallback$1(priorityLevel, callback) {
		return scheduleCallback$3(priorityLevel, callback);
	}
	var firstScheduledRoot = null;
	var lastScheduledRoot = null;
	var didScheduleMicrotask = !1;
	var mightHavePendingSyncWork = !1;
	var isFlushingWork = !1;
	var currentEventTransitionLane = 0;
	function ensureRootIsScheduled(root) {
		root !== lastScheduledRoot && null === root.next && (null === lastScheduledRoot ? firstScheduledRoot = lastScheduledRoot = root : lastScheduledRoot = lastScheduledRoot.next = root);
		mightHavePendingSyncWork = !0;
		didScheduleMicrotask || (didScheduleMicrotask = !0, scheduleImmediateRootScheduleTask());
	}
	function flushSyncWorkAcrossRoots_impl(syncTransitionLanes, onlyLegacy) {
		if (!isFlushingWork && mightHavePendingSyncWork) {
			isFlushingWork = !0;
			do {
				var didPerformSomeWork = !1;
				for (var root$190 = firstScheduledRoot; null !== root$190;) {
					if (!onlyLegacy) if (0 !== syncTransitionLanes) {
						var pendingLanes = root$190.pendingLanes;
						if (0 === pendingLanes) var JSCompiler_inline_result = 0;
						else {
							var suspendedLanes = root$190.suspendedLanes, pingedLanes = root$190.pingedLanes;
							JSCompiler_inline_result = (1 << 31 - clz32(42 | syncTransitionLanes) + 1) - 1;
							JSCompiler_inline_result &= pendingLanes & ~(suspendedLanes & ~pingedLanes);
							JSCompiler_inline_result = JSCompiler_inline_result & 201326741 ? JSCompiler_inline_result & 201326741 | 1 : JSCompiler_inline_result ? JSCompiler_inline_result | 2 : 0;
						}
						0 !== JSCompiler_inline_result && (didPerformSomeWork = !0, performSyncWorkOnRoot(root$190, JSCompiler_inline_result));
					} else JSCompiler_inline_result = workInProgressRootRenderLanes, JSCompiler_inline_result = getNextLanes(root$190, root$190 === workInProgressRoot ? JSCompiler_inline_result : 0, null !== root$190.cancelPendingCommit || -1 !== root$190.timeoutHandle), 0 === (JSCompiler_inline_result & 3) || checkIfRootIsPrerendering(root$190, JSCompiler_inline_result) || (didPerformSomeWork = !0, performSyncWorkOnRoot(root$190, JSCompiler_inline_result));
					root$190 = root$190.next;
				}
			} while (didPerformSomeWork);
			isFlushingWork = !1;
		}
	}
	function processRootScheduleInImmediateTask() {
		processRootScheduleInMicrotask();
	}
	function processRootScheduleInMicrotask() {
		mightHavePendingSyncWork = didScheduleMicrotask = !1;
		var syncTransitionLanes = 0;
		0 !== currentEventTransitionLane && shouldAttemptEagerTransition() && (syncTransitionLanes = currentEventTransitionLane);
		for (var currentTime = now(), prev = null, root = firstScheduledRoot; null !== root;) {
			var next = root.next, nextLanes = scheduleTaskForRootDuringMicrotask(root, currentTime);
			if (0 === nextLanes) root.next = null, null === prev ? firstScheduledRoot = next : prev.next = next, null === next && (lastScheduledRoot = prev);
			else if (prev = root, 0 !== syncTransitionLanes || 0 !== (nextLanes & 3)) mightHavePendingSyncWork = !0;
			root = next;
		}
		0 !== pendingEffectsStatus && 5 !== pendingEffectsStatus || flushSyncWorkAcrossRoots_impl(syncTransitionLanes, !1);
		0 !== currentEventTransitionLane && (currentEventTransitionLane = 0);
	}
	function scheduleTaskForRootDuringMicrotask(root, currentTime) {
		for (var suspendedLanes = root.suspendedLanes, pingedLanes = root.pingedLanes, expirationTimes = root.expirationTimes, lanes = root.pendingLanes & -62914561; 0 < lanes;) {
			var index$5 = 31 - clz32(lanes), lane = 1 << index$5, expirationTime = expirationTimes[index$5];
			if (-1 === expirationTime) {
				if (0 === (lane & suspendedLanes) || 0 !== (lane & pingedLanes)) expirationTimes[index$5] = computeExpirationTime(lane, currentTime);
			} else expirationTime <= currentTime && (root.expiredLanes |= lane);
			lanes &= ~lane;
		}
		currentTime = workInProgressRoot;
		suspendedLanes = workInProgressRootRenderLanes;
		suspendedLanes = getNextLanes(root, root === currentTime ? suspendedLanes : 0, null !== root.cancelPendingCommit || -1 !== root.timeoutHandle);
		pingedLanes = root.callbackNode;
		if (0 === suspendedLanes || root === currentTime && (2 === workInProgressSuspendedReason || 9 === workInProgressSuspendedReason) || null !== root.cancelPendingCommit) return null !== pingedLanes && null !== pingedLanes && cancelCallback$1(pingedLanes), root.callbackNode = null, root.callbackPriority = 0;
		if (0 === (suspendedLanes & 3) || checkIfRootIsPrerendering(root, suspendedLanes)) {
			currentTime = suspendedLanes & -suspendedLanes;
			if (currentTime === root.callbackPriority) return currentTime;
			null !== pingedLanes && cancelCallback$1(pingedLanes);
			switch (lanesToEventPriority(suspendedLanes)) {
				case 2:
				case 8:
					suspendedLanes = UserBlockingPriority;
					break;
				case 32:
					suspendedLanes = NormalPriority$1;
					break;
				case 268435456:
					suspendedLanes = IdlePriority;
					break;
				default: suspendedLanes = NormalPriority$1;
			}
			pingedLanes = performWorkOnRootViaSchedulerTask.bind(null, root);
			suspendedLanes = scheduleCallback$3(suspendedLanes, pingedLanes);
			root.callbackPriority = currentTime;
			root.callbackNode = suspendedLanes;
			return currentTime;
		}
		null !== pingedLanes && null !== pingedLanes && cancelCallback$1(pingedLanes);
		root.callbackPriority = 2;
		root.callbackNode = null;
		return 2;
	}
	function performWorkOnRootViaSchedulerTask(root, didTimeout) {
		if (0 !== pendingEffectsStatus && 5 !== pendingEffectsStatus) return root.callbackNode = null, root.callbackPriority = 0, null;
		var originalCallbackNode = root.callbackNode;
		if (flushPendingEffects() && root.callbackNode !== originalCallbackNode) return null;
		var workInProgressRootRenderLanes$jscomp$0 = workInProgressRootRenderLanes;
		workInProgressRootRenderLanes$jscomp$0 = getNextLanes(root, root === workInProgressRoot ? workInProgressRootRenderLanes$jscomp$0 : 0, null !== root.cancelPendingCommit || -1 !== root.timeoutHandle);
		if (0 === workInProgressRootRenderLanes$jscomp$0) return null;
		performWorkOnRoot(root, workInProgressRootRenderLanes$jscomp$0, didTimeout);
		scheduleTaskForRootDuringMicrotask(root, now());
		return null != root.callbackNode && root.callbackNode === originalCallbackNode ? performWorkOnRootViaSchedulerTask.bind(null, root) : null;
	}
	function performSyncWorkOnRoot(root, lanes) {
		if (flushPendingEffects()) return null;
		performWorkOnRoot(root, lanes, !0);
	}
	function scheduleImmediateRootScheduleTask() {
		scheduleMicrotask(function() {
			0 !== (executionContext & 6) ? scheduleCallback$3(ImmediatePriority, processRootScheduleInImmediateTask) : processRootScheduleInMicrotask();
		});
	}
	function requestTransitionLane() {
		if (0 === currentEventTransitionLane) {
			var actionScopeLane = currentEntangledLane;
			0 === actionScopeLane && (actionScopeLane = nextTransitionUpdateLane, nextTransitionUpdateLane <<= 1, 0 === (nextTransitionUpdateLane & 261888) && (nextTransitionUpdateLane = 256));
			currentEventTransitionLane = actionScopeLane;
		}
		return currentEventTransitionLane;
	}
	function coerceFormActionProp(actionProp) {
		return null == actionProp || "symbol" === typeof actionProp || "boolean" === typeof actionProp ? null : "function" === typeof actionProp ? actionProp : sanitizeURL(actionProp);
	}
	function extractEvents$1(dispatchQueue, domEventName, maybeTargetInst, nativeEvent, nativeEventTarget) {
		if ("submit" === domEventName && maybeTargetInst && maybeTargetInst.stateNode === nativeEventTarget) {
			var action = coerceFormActionProp((nativeEventTarget[internalPropsKey] || null).action), submitter = nativeEvent.submitter;
			submitter && (domEventName = (domEventName = submitter[internalPropsKey] || null) ? coerceFormActionProp(domEventName.formAction) : submitter.getAttribute("formAction"), null !== domEventName && (action = domEventName, submitter = null));
			var event = new SyntheticEvent("action", "action", null, nativeEvent, nativeEventTarget);
			dispatchQueue.push({
				event,
				listeners: [{
					instance: null,
					listener: function() {
						if (nativeEvent.defaultPrevented) {
							if (0 !== currentEventTransitionLane) {
								var formData = new FormData(nativeEventTarget, submitter);
								startHostTransition(maybeTargetInst, {
									pending: !0,
									data: formData,
									method: nativeEventTarget.method,
									action
								}, null, formData);
							}
						} else "function" === typeof action && (event.preventDefault(), formData = new FormData(nativeEventTarget, submitter), startHostTransition(maybeTargetInst, {
							pending: !0,
							data: formData,
							method: nativeEventTarget.method,
							action
						}, action, formData));
					},
					currentTarget: nativeEventTarget
				}]
			});
		}
	}
	for (var i$jscomp$inline_1667 = 0; i$jscomp$inline_1667 < simpleEventPluginEvents.length; i$jscomp$inline_1667++) {
		var eventName$jscomp$inline_1668 = simpleEventPluginEvents[i$jscomp$inline_1667];
		registerSimpleEvent(eventName$jscomp$inline_1668.toLowerCase(), "on" + (eventName$jscomp$inline_1668[0].toUpperCase() + eventName$jscomp$inline_1668.slice(1)));
	}
	registerSimpleEvent(ANIMATION_END, "onAnimationEnd");
	registerSimpleEvent(ANIMATION_ITERATION, "onAnimationIteration");
	registerSimpleEvent(ANIMATION_START, "onAnimationStart");
	registerSimpleEvent("dblclick", "onDoubleClick");
	registerSimpleEvent("focusin", "onFocus");
	registerSimpleEvent("focusout", "onBlur");
	registerSimpleEvent(TRANSITION_RUN, "onTransitionRun");
	registerSimpleEvent(TRANSITION_START, "onTransitionStart");
	registerSimpleEvent(TRANSITION_CANCEL, "onTransitionCancel");
	registerSimpleEvent(TRANSITION_END, "onTransitionEnd");
	registerDirectEvent("onMouseEnter", ["mouseout", "mouseover"]);
	registerDirectEvent("onMouseLeave", ["mouseout", "mouseover"]);
	registerDirectEvent("onPointerEnter", ["pointerout", "pointerover"]);
	registerDirectEvent("onPointerLeave", ["pointerout", "pointerover"]);
	registerTwoPhaseEvent("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
	registerTwoPhaseEvent("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
	registerTwoPhaseEvent("onBeforeInput", [
		"compositionend",
		"keypress",
		"textInput",
		"paste"
	]);
	registerTwoPhaseEvent("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
	registerTwoPhaseEvent("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
	registerTwoPhaseEvent("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
	var mediaEventTypes = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" ");
	var nonDelegatedEvents = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(mediaEventTypes));
	function processDispatchQueue(dispatchQueue, eventSystemFlags) {
		eventSystemFlags = 0 !== (eventSystemFlags & 4);
		for (var i = 0; i < dispatchQueue.length; i++) {
			var _dispatchQueue$i = dispatchQueue[i], event = _dispatchQueue$i.event;
			_dispatchQueue$i = _dispatchQueue$i.listeners;
			a: {
				var previousInstance = void 0;
				if (eventSystemFlags) for (var i$jscomp$0 = _dispatchQueue$i.length - 1; 0 <= i$jscomp$0; i$jscomp$0--) {
					var _dispatchListeners$i = _dispatchQueue$i[i$jscomp$0], instance = _dispatchListeners$i.instance, currentTarget = _dispatchListeners$i.currentTarget;
					_dispatchListeners$i = _dispatchListeners$i.listener;
					if (instance !== previousInstance && event.isPropagationStopped()) break a;
					previousInstance = _dispatchListeners$i;
					event.currentTarget = currentTarget;
					try {
						previousInstance(event);
					} catch (error) {
						reportGlobalError(error);
					}
					event.currentTarget = null;
					previousInstance = instance;
				}
				else for (i$jscomp$0 = 0; i$jscomp$0 < _dispatchQueue$i.length; i$jscomp$0++) {
					_dispatchListeners$i = _dispatchQueue$i[i$jscomp$0];
					instance = _dispatchListeners$i.instance;
					currentTarget = _dispatchListeners$i.currentTarget;
					_dispatchListeners$i = _dispatchListeners$i.listener;
					if (instance !== previousInstance && event.isPropagationStopped()) break a;
					previousInstance = _dispatchListeners$i;
					event.currentTarget = currentTarget;
					try {
						previousInstance(event);
					} catch (error) {
						reportGlobalError(error);
					}
					event.currentTarget = null;
					previousInstance = instance;
				}
			}
		}
	}
	function listenToNonDelegatedEvent(domEventName, targetElement) {
		var JSCompiler_inline_result = targetElement[internalEventHandlersKey];
		void 0 === JSCompiler_inline_result && (JSCompiler_inline_result = targetElement[internalEventHandlersKey] = /* @__PURE__ */ new Set());
		var listenerSetKey = domEventName + "__bubble";
		JSCompiler_inline_result.has(listenerSetKey) || (addTrappedEventListener(targetElement, domEventName, 2, !1), JSCompiler_inline_result.add(listenerSetKey));
	}
	function listenToNativeEvent(domEventName, isCapturePhaseListener, target) {
		var eventSystemFlags = 0;
		isCapturePhaseListener && (eventSystemFlags |= 4);
		addTrappedEventListener(target, domEventName, eventSystemFlags, isCapturePhaseListener);
	}
	var listeningMarker = "_reactListening" + Math.random().toString(36).slice(2);
	function listenToAllSupportedEvents(rootContainerElement) {
		if (!rootContainerElement[listeningMarker]) {
			rootContainerElement[listeningMarker] = !0;
			allNativeEvents.forEach(function(domEventName) {
				"selectionchange" !== domEventName && (nonDelegatedEvents.has(domEventName) || listenToNativeEvent(domEventName, !1, rootContainerElement), listenToNativeEvent(domEventName, !0, rootContainerElement));
			});
			var ownerDocument = 9 === rootContainerElement.nodeType ? rootContainerElement : rootContainerElement.ownerDocument;
			null === ownerDocument || ownerDocument[listeningMarker] || (ownerDocument[listeningMarker] = !0, listenToNativeEvent("selectionchange", !1, ownerDocument));
		}
	}
	function addTrappedEventListener(targetContainer, domEventName, eventSystemFlags, isCapturePhaseListener) {
		switch (getEventPriority(domEventName)) {
			case 2:
				var listenerWrapper = dispatchDiscreteEvent;
				break;
			case 8:
				listenerWrapper = dispatchContinuousEvent;
				break;
			default: listenerWrapper = dispatchEvent;
		}
		eventSystemFlags = listenerWrapper.bind(null, domEventName, eventSystemFlags, targetContainer);
		listenerWrapper = void 0;
		!passiveBrowserEventsSupported || "touchstart" !== domEventName && "touchmove" !== domEventName && "wheel" !== domEventName || (listenerWrapper = !0);
		isCapturePhaseListener ? void 0 !== listenerWrapper ? targetContainer.addEventListener(domEventName, eventSystemFlags, {
			capture: !0,
			passive: listenerWrapper
		}) : targetContainer.addEventListener(domEventName, eventSystemFlags, !0) : void 0 !== listenerWrapper ? targetContainer.addEventListener(domEventName, eventSystemFlags, { passive: listenerWrapper }) : targetContainer.addEventListener(domEventName, eventSystemFlags, !1);
	}
	function dispatchEventForPluginEventSystem(domEventName, eventSystemFlags, nativeEvent, targetInst$jscomp$0, targetContainer) {
		var ancestorInst = targetInst$jscomp$0;
		if (0 === (eventSystemFlags & 1) && 0 === (eventSystemFlags & 2) && null !== targetInst$jscomp$0) a: for (;;) {
			if (null === targetInst$jscomp$0) return;
			var nodeTag = targetInst$jscomp$0.tag;
			if (3 === nodeTag || 4 === nodeTag) {
				var container = targetInst$jscomp$0.stateNode.containerInfo;
				if (container === targetContainer) break;
				if (4 === nodeTag) for (nodeTag = targetInst$jscomp$0.return; null !== nodeTag;) {
					var grandTag = nodeTag.tag;
					if ((3 === grandTag || 4 === grandTag) && nodeTag.stateNode.containerInfo === targetContainer) return;
					nodeTag = nodeTag.return;
				}
				for (; null !== container;) {
					nodeTag = getClosestInstanceFromNode(container);
					if (null === nodeTag) return;
					grandTag = nodeTag.tag;
					if (5 === grandTag || 6 === grandTag || 26 === grandTag || 27 === grandTag) {
						targetInst$jscomp$0 = ancestorInst = nodeTag;
						continue a;
					}
					container = container.parentNode;
				}
			}
			targetInst$jscomp$0 = targetInst$jscomp$0.return;
		}
		batchedUpdates$1(function() {
			var targetInst = ancestorInst, nativeEventTarget = getEventTarget(nativeEvent), dispatchQueue = [];
			a: {
				var reactName = topLevelEventsToReactNames.get(domEventName);
				if (void 0 !== reactName) {
					var SyntheticEventCtor = SyntheticEvent, reactEventType = domEventName;
					switch (domEventName) {
						case "keypress": if (0 === getEventCharCode(nativeEvent)) break a;
						case "keydown":
						case "keyup":
							SyntheticEventCtor = SyntheticKeyboardEvent;
							break;
						case "focusin":
							reactEventType = "focus";
							SyntheticEventCtor = SyntheticFocusEvent;
							break;
						case "focusout":
							reactEventType = "blur";
							SyntheticEventCtor = SyntheticFocusEvent;
							break;
						case "beforeblur":
						case "afterblur":
							SyntheticEventCtor = SyntheticFocusEvent;
							break;
						case "click": if (2 === nativeEvent.button) break a;
						case "auxclick":
						case "dblclick":
						case "mousedown":
						case "mousemove":
						case "mouseup":
						case "mouseout":
						case "mouseover":
						case "contextmenu":
							SyntheticEventCtor = SyntheticMouseEvent;
							break;
						case "drag":
						case "dragend":
						case "dragenter":
						case "dragexit":
						case "dragleave":
						case "dragover":
						case "dragstart":
						case "drop":
							SyntheticEventCtor = SyntheticDragEvent;
							break;
						case "touchcancel":
						case "touchend":
						case "touchmove":
						case "touchstart":
							SyntheticEventCtor = SyntheticTouchEvent;
							break;
						case ANIMATION_END:
						case ANIMATION_ITERATION:
						case ANIMATION_START:
							SyntheticEventCtor = SyntheticAnimationEvent;
							break;
						case TRANSITION_END:
							SyntheticEventCtor = SyntheticTransitionEvent;
							break;
						case "scroll":
						case "scrollend":
							SyntheticEventCtor = SyntheticUIEvent;
							break;
						case "wheel":
							SyntheticEventCtor = SyntheticWheelEvent;
							break;
						case "copy":
						case "cut":
						case "paste":
							SyntheticEventCtor = SyntheticClipboardEvent;
							break;
						case "gotpointercapture":
						case "lostpointercapture":
						case "pointercancel":
						case "pointerdown":
						case "pointermove":
						case "pointerout":
						case "pointerover":
						case "pointerup":
							SyntheticEventCtor = SyntheticPointerEvent;
							break;
						case "submit":
							SyntheticEventCtor = SyntheticSubmitEvent;
							break;
						case "toggle":
						case "beforetoggle": SyntheticEventCtor = SyntheticToggleEvent;
					}
					var inCapturePhase = 0 !== (eventSystemFlags & 4), accumulateTargetOnly = !inCapturePhase && ("scroll" === domEventName || "scrollend" === domEventName), reactEventName = inCapturePhase ? null !== reactName ? reactName + "Capture" : null : reactName;
					inCapturePhase = [];
					for (var instance = targetInst, lastHostComponent; null !== instance;) {
						var _instance = instance;
						lastHostComponent = _instance.stateNode;
						_instance = _instance.tag;
						5 !== _instance && 26 !== _instance && 27 !== _instance || null === lastHostComponent || null === reactEventName || (_instance = getListener(instance, reactEventName), null != _instance && inCapturePhase.push(createDispatchListener(instance, _instance, lastHostComponent)));
						if (accumulateTargetOnly) break;
						instance = instance.return;
					}
					0 < inCapturePhase.length && (reactName = new SyntheticEventCtor(reactName, reactEventType, null, nativeEvent, nativeEventTarget), dispatchQueue.push({
						event: reactName,
						listeners: inCapturePhase
					}));
				}
			}
			if (0 === (eventSystemFlags & 7)) {
				a: {
					SyntheticEventCtor = "mouseover" === domEventName || "pointerover" === domEventName;
					reactName = "mouseout" === domEventName || "pointerout" === domEventName;
					if (SyntheticEventCtor && nativeEvent !== currentReplayingEvent && (reactEventType = nativeEvent.relatedTarget || nativeEvent.fromElement) && (getClosestInstanceFromNode(reactEventType) || reactEventType[internalContainerInstanceKey])) break a;
					if (reactName || SyntheticEventCtor) {
						reactEventType = nativeEventTarget.window === nativeEventTarget ? nativeEventTarget : (SyntheticEventCtor = nativeEventTarget.ownerDocument) ? SyntheticEventCtor.defaultView || SyntheticEventCtor.parentWindow : window;
						if (reactName) {
							if (SyntheticEventCtor = nativeEvent.relatedTarget || nativeEvent.toElement, reactName = targetInst, SyntheticEventCtor = SyntheticEventCtor ? getClosestInstanceFromNode(SyntheticEventCtor) : null, null !== SyntheticEventCtor && (accumulateTargetOnly = getNearestMountedFiber(SyntheticEventCtor), inCapturePhase = SyntheticEventCtor.tag, SyntheticEventCtor !== accumulateTargetOnly || 5 !== inCapturePhase && 27 !== inCapturePhase && 6 !== inCapturePhase)) SyntheticEventCtor = null;
						} else reactName = null, SyntheticEventCtor = targetInst;
						if (reactName !== SyntheticEventCtor) {
							inCapturePhase = SyntheticMouseEvent;
							_instance = "onMouseLeave";
							reactEventName = "onMouseEnter";
							instance = "mouse";
							if ("pointerout" === domEventName || "pointerover" === domEventName) inCapturePhase = SyntheticPointerEvent, _instance = "onPointerLeave", reactEventName = "onPointerEnter", instance = "pointer";
							accumulateTargetOnly = null == reactName ? reactEventType : getNodeFromInstance(reactName);
							lastHostComponent = null == SyntheticEventCtor ? reactEventType : getNodeFromInstance(SyntheticEventCtor);
							reactEventType = new inCapturePhase(_instance, instance + "leave", reactName, nativeEvent, nativeEventTarget);
							reactEventType.target = accumulateTargetOnly;
							reactEventType.relatedTarget = lastHostComponent;
							_instance = null;
							getClosestInstanceFromNode(nativeEventTarget) === targetInst && (inCapturePhase = new inCapturePhase(reactEventName, instance + "enter", SyntheticEventCtor, nativeEvent, nativeEventTarget), inCapturePhase.target = lastHostComponent, inCapturePhase.relatedTarget = accumulateTargetOnly, _instance = inCapturePhase);
							accumulateTargetOnly = _instance;
							inCapturePhase = reactName && SyntheticEventCtor ? getLowestCommonAncestor(reactName, SyntheticEventCtor, getParent) : null;
							null !== reactName && accumulateEnterLeaveListenersForEvent(dispatchQueue, reactEventType, reactName, inCapturePhase, !1);
							null !== SyntheticEventCtor && null !== accumulateTargetOnly && accumulateEnterLeaveListenersForEvent(dispatchQueue, accumulateTargetOnly, SyntheticEventCtor, inCapturePhase, !0);
						}
					}
				}
				a: {
					reactName = targetInst ? getNodeFromInstance(targetInst) : window;
					SyntheticEventCtor = reactName.nodeName && reactName.nodeName.toLowerCase();
					if ("select" === SyntheticEventCtor || "input" === SyntheticEventCtor && "file" === reactName.type) var getTargetInstFunc = getTargetInstForChangeEvent;
					else if (isTextInputElement(reactName)) if (isInputEventSupported) getTargetInstFunc = getTargetInstForInputOrChangeEvent;
					else {
						getTargetInstFunc = getTargetInstForInputEventPolyfill;
						var handleEventFunc = handleEventsForInputEventPolyfill;
					}
					else SyntheticEventCtor = reactName.nodeName, !SyntheticEventCtor || "input" !== SyntheticEventCtor.toLowerCase() || "checkbox" !== reactName.type && "radio" !== reactName.type ? targetInst && isCustomElement(targetInst.elementType) && (getTargetInstFunc = getTargetInstForChangeEvent) : getTargetInstFunc = getTargetInstForClickEvent;
					if (getTargetInstFunc && (getTargetInstFunc = getTargetInstFunc(domEventName, targetInst))) {
						createAndAccumulateChangeEvent(dispatchQueue, getTargetInstFunc, nativeEvent, nativeEventTarget);
						break a;
					}
					handleEventFunc && handleEventFunc(domEventName, reactName, targetInst);
				}
				handleEventFunc = targetInst ? getNodeFromInstance(targetInst) : window;
				switch (domEventName) {
					case "focusin":
						if (isTextInputElement(handleEventFunc) || "true" === handleEventFunc.contentEditable) activeElement = handleEventFunc, activeElementInst = targetInst, lastSelection = null;
						break;
					case "focusout":
						lastSelection = activeElementInst = activeElement = null;
						break;
					case "mousedown":
						mouseDown = !0;
						break;
					case "contextmenu":
					case "mouseup":
					case "dragend":
						mouseDown = !1;
						constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget);
						break;
					case "selectionchange": if (skipSelectionChangeEvent) break;
					case "keydown":
					case "keyup": constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget);
				}
				var fallbackData;
				if (canUseCompositionEvent) b: {
					switch (domEventName) {
						case "compositionstart":
							var eventType = "onCompositionStart";
							break b;
						case "compositionend":
							eventType = "onCompositionEnd";
							break b;
						case "compositionupdate":
							eventType = "onCompositionUpdate";
							break b;
					}
					eventType = void 0;
				}
				else isComposing ? isFallbackCompositionEnd(domEventName, nativeEvent) && (eventType = "onCompositionEnd") : "keydown" === domEventName && 229 === nativeEvent.keyCode && (eventType = "onCompositionStart");
				eventType && (useFallbackCompositionData && "ko" !== nativeEvent.locale && (isComposing || "onCompositionStart" !== eventType ? "onCompositionEnd" === eventType && isComposing && (fallbackData = getData()) : (root = nativeEventTarget, startText = "value" in root ? root.value : root.textContent, isComposing = !0)), handleEventFunc = accumulateTwoPhaseListeners(targetInst, eventType), 0 < handleEventFunc.length && (eventType = new SyntheticCompositionEvent(eventType, domEventName, null, nativeEvent, nativeEventTarget), dispatchQueue.push({
					event: eventType,
					listeners: handleEventFunc
				}), fallbackData ? eventType.data = fallbackData : (fallbackData = getDataFromCustomEvent(nativeEvent), null !== fallbackData && (eventType.data = fallbackData))));
				if (fallbackData = canUseTextInputEvent ? getNativeBeforeInputChars(domEventName, nativeEvent) : getFallbackBeforeInputChars(domEventName, nativeEvent)) eventType = accumulateTwoPhaseListeners(targetInst, "onBeforeInput"), 0 < eventType.length && (handleEventFunc = new SyntheticCompositionEvent("onBeforeInput", "beforeinput", null, nativeEvent, nativeEventTarget), dispatchQueue.push({
					event: handleEventFunc,
					listeners: eventType
				}), handleEventFunc.data = fallbackData);
				extractEvents$1(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
			}
			processDispatchQueue(dispatchQueue, eventSystemFlags);
		});
	}
	function createDispatchListener(instance, listener, currentTarget) {
		return {
			instance,
			listener,
			currentTarget
		};
	}
	function accumulateTwoPhaseListeners(targetFiber, reactName) {
		for (var captureName = reactName + "Capture", listeners = []; null !== targetFiber;) {
			var _instance2 = targetFiber, stateNode = _instance2.stateNode;
			_instance2 = _instance2.tag;
			5 !== _instance2 && 26 !== _instance2 && 27 !== _instance2 || null === stateNode || (_instance2 = getListener(targetFiber, captureName), null != _instance2 && listeners.unshift(createDispatchListener(targetFiber, _instance2, stateNode)), _instance2 = getListener(targetFiber, reactName), null != _instance2 && listeners.push(createDispatchListener(targetFiber, _instance2, stateNode)));
			if (3 === targetFiber.tag) return listeners;
			targetFiber = targetFiber.return;
		}
		return [];
	}
	function getParent(inst) {
		if (null === inst) return null;
		do
			inst = inst.return;
		while (inst && 5 !== inst.tag && 27 !== inst.tag);
		return inst ? inst : null;
	}
	function accumulateEnterLeaveListenersForEvent(dispatchQueue, event, target, common, inCapturePhase) {
		for (var registrationName = event._reactName, listeners = []; null !== target && target !== common;) {
			var _instance3 = target, alternate = _instance3.alternate, stateNode = _instance3.stateNode;
			_instance3 = _instance3.tag;
			if (null !== alternate && alternate === common) break;
			5 !== _instance3 && 26 !== _instance3 && 27 !== _instance3 || null === stateNode || (alternate = stateNode, inCapturePhase ? (stateNode = getListener(target, registrationName), null != stateNode && listeners.unshift(createDispatchListener(target, stateNode, alternate))) : inCapturePhase || (stateNode = getListener(target, registrationName), null != stateNode && listeners.push(createDispatchListener(target, stateNode, alternate))));
			target = target.return;
		}
		0 !== listeners.length && dispatchQueue.push({
			event,
			listeners
		});
	}
	var NORMALIZE_NEWLINES_REGEX = /\r\n?/g;
	var NORMALIZE_NULL_AND_REPLACEMENT_REGEX = /\u0000|\uFFFD/g;
	function normalizeMarkupForTextOrAttribute(markup) {
		return ("string" === typeof markup ? markup : "" + markup).replace(NORMALIZE_NEWLINES_REGEX, "\n").replace(NORMALIZE_NULL_AND_REPLACEMENT_REGEX, "");
	}
	function checkForUnmatchedText(serverText, clientText) {
		clientText = normalizeMarkupForTextOrAttribute(clientText);
		return normalizeMarkupForTextOrAttribute(serverText) === clientText ? !0 : !1;
	}
	function setProp(domElement, tag, key, value, props, prevValue) {
		switch (key) {
			case "children":
				if ("string" === typeof value) "body" === tag || "textarea" === tag && "" === value || setTextContent(domElement, value);
				else if ("number" === typeof value || "bigint" === typeof value) "body" !== tag && setTextContent(domElement, "" + value);
				else return;
				break;
			case "className":
				setValueForKnownAttribute(domElement, "class", value);
				break;
			case "tabIndex":
				setValueForKnownAttribute(domElement, "tabindex", value);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				setValueForKnownAttribute(domElement, key, value);
				break;
			case "style":
				setValueForStyles(domElement, value, prevValue);
				return;
			case "data": if ("object" !== tag) {
				setValueForKnownAttribute(domElement, "data", value);
				break;
			}
			case "src":
			case "href":
				if ("" === value && ("a" !== tag || "href" !== key)) {
					domElement.removeAttribute(key);
					break;
				}
				if (null == value || "function" === typeof value || "symbol" === typeof value || "boolean" === typeof value) {
					domElement.removeAttribute(key);
					break;
				}
				value = sanitizeURL(value);
				domElement.setAttribute(key, value);
				break;
			case "action":
			case "formAction":
				if ("function" === typeof value) {
					domElement.setAttribute(key, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
					break;
				} else "function" === typeof prevValue && ("formAction" === key ? ("input" !== tag && setProp(domElement, tag, "name", props.name, props, null), setProp(domElement, tag, "formEncType", props.formEncType, props, null), setProp(domElement, tag, "formMethod", props.formMethod, props, null), setProp(domElement, tag, "formTarget", props.formTarget, props, null)) : (setProp(domElement, tag, "encType", props.encType, props, null), setProp(domElement, tag, "method", props.method, props, null), setProp(domElement, tag, "target", props.target, props, null)));
				if (null == value || "symbol" === typeof value || "boolean" === typeof value) {
					domElement.removeAttribute(key);
					break;
				}
				value = sanitizeURL(value);
				domElement.setAttribute(key, value);
				break;
			case "onClick":
				null != value && (domElement.onclick = noop$1);
				return;
			case "onScroll":
				null != value && listenToNonDelegatedEvent("scroll", domElement);
				return;
			case "onScrollEnd":
				null != value && listenToNonDelegatedEvent("scrollend", domElement);
				return;
			case "dangerouslySetInnerHTML":
				if (null != value) {
					if ("object" !== typeof value || !("__html" in value)) throw Error(formatProdErrorMessage(61));
					key = value.__html;
					if (null != key) {
						if (null != props.children) throw Error(formatProdErrorMessage(60));
						(null != prevValue ? prevValue.__html : void 0) !== key && (domElement.innerHTML = key);
					}
				}
				break;
			case "multiple":
				domElement.multiple = value && "function" !== typeof value && "symbol" !== typeof value;
				break;
			case "muted":
				domElement.muted = value && "function" !== typeof value && "symbol" !== typeof value;
				break;
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "ref": break;
			case "autoFocus": break;
			case "xlinkHref":
				if (null == value || "function" === typeof value || "boolean" === typeof value || "symbol" === typeof value) {
					domElement.removeAttribute("xlink:href");
					break;
				}
				key = sanitizeURL(value);
				domElement.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", key);
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				null != value && "function" !== typeof value && "symbol" !== typeof value ? domElement.setAttribute(key, value) : domElement.removeAttribute(key);
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "credentialless":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				value && "function" !== typeof value && "symbol" !== typeof value ? domElement.setAttribute(key, "") : domElement.removeAttribute(key);
				break;
			case "capture":
			case "download":
				!0 === value ? domElement.setAttribute(key, "") : !1 !== value && null != value && "function" !== typeof value && "symbol" !== typeof value ? domElement.setAttribute(key, value) : domElement.removeAttribute(key);
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				null != value && "function" !== typeof value && "symbol" !== typeof value && !isNaN(value) && 1 <= value ? domElement.setAttribute(key, value) : domElement.removeAttribute(key);
				break;
			case "rowSpan":
			case "start":
				null == value || "function" === typeof value || "symbol" === typeof value || isNaN(value) ? domElement.removeAttribute(key) : domElement.setAttribute(key, value);
				break;
			case "popover":
				listenToNonDelegatedEvent("beforetoggle", domElement);
				listenToNonDelegatedEvent("toggle", domElement);
				setValueForAttribute(domElement, "popover", value);
				break;
			case "xlinkActuate":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/1999/xlink", "xlink:actuate", value);
				break;
			case "xlinkArcrole":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/1999/xlink", "xlink:arcrole", value);
				break;
			case "xlinkRole":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/1999/xlink", "xlink:role", value);
				break;
			case "xlinkShow":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/1999/xlink", "xlink:show", value);
				break;
			case "xlinkTitle":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/1999/xlink", "xlink:title", value);
				break;
			case "xlinkType":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/1999/xlink", "xlink:type", value);
				break;
			case "xmlBase":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/XML/1998/namespace", "xml:base", value);
				break;
			case "xmlLang":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/XML/1998/namespace", "xml:lang", value);
				break;
			case "xmlSpace":
				setValueForNamespacedAttribute(domElement, "http://www.w3.org/XML/1998/namespace", "xml:space", value);
				break;
			case "is":
				setValueForAttribute(domElement, "is", value);
				break;
			case "innerText":
			case "textContent": return;
			default: if (!(2 < key.length) || "o" !== key[0] && "O" !== key[0] || "n" !== key[1] && "N" !== key[1]) key = aliases.get(key) || key, setValueForAttribute(domElement, key, value);
			else return;
		}
		viewTransitionMutationContext = !0;
	}
	function setPropOnCustomElement(domElement, tag, key, value, props, prevValue) {
		switch (key) {
			case "style":
				setValueForStyles(domElement, value, prevValue);
				return;
			case "dangerouslySetInnerHTML":
				if (null != value) {
					if ("object" !== typeof value || !("__html" in value)) throw Error(formatProdErrorMessage(61));
					key = value.__html;
					if (null != key) {
						if (null != props.children) throw Error(formatProdErrorMessage(60));
						(null != prevValue ? prevValue.__html : void 0) !== key && (domElement.innerHTML = key);
					}
				}
				break;
			case "children":
				if ("string" === typeof value) setTextContent(domElement, value);
				else if ("number" === typeof value || "bigint" === typeof value) setTextContent(domElement, "" + value);
				else return;
				break;
			case "onScroll":
				null != value && listenToNonDelegatedEvent("scroll", domElement);
				return;
			case "onScrollEnd":
				null != value && listenToNonDelegatedEvent("scrollend", domElement);
				return;
			case "onClick":
				null != value && (domElement.onclick = noop$1);
				return;
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "innerHTML":
			case "ref": return;
			case "innerText":
			case "textContent": return;
			default:
				if (!registrationNameDependencies.hasOwnProperty(key)) a: {
					if ("o" === key[0] && "n" === key[1] && (props = key.endsWith("Capture"), prevValue = key.slice(2, props ? key.length - 7 : void 0), tag = domElement[internalPropsKey] || null, tag = null != tag ? tag[key] : null, "function" === typeof tag && domElement.removeEventListener(prevValue, tag, props), "function" === typeof value)) {
						"function" !== typeof tag && null !== tag && (key in domElement ? domElement[key] = null : domElement.hasAttribute(key) && domElement.removeAttribute(key));
						domElement.addEventListener(prevValue, value, props);
						break a;
					}
					viewTransitionMutationContext = !0;
					key in domElement ? domElement[key] = value : !0 === value ? domElement.setAttribute(key, "") : setValueForAttribute(domElement, key, value);
				}
				return;
		}
		viewTransitionMutationContext = !0;
	}
	function setInitialProperties(domElement, tag, props) {
		switch (tag) {
			case "div":
			case "span":
			case "svg":
			case "path":
			case "a":
			case "g":
			case "p":
			case "li": break;
			case "img":
				listenToNonDelegatedEvent("error", domElement);
				listenToNonDelegatedEvent("load", domElement);
				var hasSrc = !1, hasSrcSet = !1, propKey;
				for (propKey in props) if (props.hasOwnProperty(propKey)) {
					var propValue = props[propKey];
					if (null != propValue) switch (propKey) {
						case "src":
							hasSrc = !0;
							break;
						case "srcSet":
							hasSrcSet = !0;
							break;
						case "children":
						case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(137, tag));
						default: setProp(domElement, tag, propKey, propValue, props, null);
					}
				}
				hasSrcSet && setProp(domElement, tag, "srcSet", props.srcSet, props, null);
				hasSrc && setProp(domElement, tag, "src", props.src, props, null);
				return;
			case "input":
				listenToNonDelegatedEvent("invalid", domElement);
				var defaultValue = propKey = propValue = hasSrcSet = null, checked = null, defaultChecked = null;
				for (hasSrc in props) if (props.hasOwnProperty(hasSrc)) {
					var propValue$204 = props[hasSrc];
					if (null != propValue$204) switch (hasSrc) {
						case "name":
							hasSrcSet = propValue$204;
							break;
						case "type":
							propValue = propValue$204;
							break;
						case "checked":
							checked = propValue$204;
							break;
						case "defaultChecked":
							defaultChecked = propValue$204;
							break;
						case "value":
							propKey = propValue$204;
							break;
						case "defaultValue":
							defaultValue = propValue$204;
							break;
						case "children":
						case "dangerouslySetInnerHTML":
							if (null != propValue$204) throw Error(formatProdErrorMessage(137, tag));
							break;
						default: setProp(domElement, tag, hasSrc, propValue$204, props, null);
					}
				}
				initInput(domElement, propKey, defaultValue, checked, defaultChecked, propValue, hasSrcSet, !1);
				return;
			case "select":
				listenToNonDelegatedEvent("invalid", domElement);
				hasSrc = propValue = propKey = null;
				for (hasSrcSet in props) if (props.hasOwnProperty(hasSrcSet) && (defaultValue = props[hasSrcSet], null != defaultValue)) switch (hasSrcSet) {
					case "value":
						propKey = defaultValue;
						break;
					case "defaultValue":
						propValue = defaultValue;
						break;
					case "multiple": hasSrc = defaultValue;
					default: setProp(domElement, tag, hasSrcSet, defaultValue, props, null);
				}
				tag = propKey;
				props = propValue;
				domElement.multiple = !!hasSrc;
				null != tag ? updateOptions(domElement, !!hasSrc, tag, !1) : null != props && updateOptions(domElement, !!hasSrc, props, !0);
				return;
			case "textarea":
				listenToNonDelegatedEvent("invalid", domElement);
				propKey = hasSrcSet = hasSrc = null;
				for (propValue in props) if (props.hasOwnProperty(propValue) && (defaultValue = props[propValue], null != defaultValue)) switch (propValue) {
					case "value":
						hasSrc = defaultValue;
						break;
					case "defaultValue":
						hasSrcSet = defaultValue;
						break;
					case "children":
						propKey = defaultValue;
						break;
					case "dangerouslySetInnerHTML":
						if (null != defaultValue) throw Error(formatProdErrorMessage(91));
						break;
					default: setProp(domElement, tag, propValue, defaultValue, props, null);
				}
				initTextarea(domElement, hasSrc, hasSrcSet, propKey);
				return;
			case "option":
				for (checked in props) if (props.hasOwnProperty(checked) && (hasSrc = props[checked], null != hasSrc)) switch (checked) {
					case "selected":
						domElement.selected = hasSrc && "function" !== typeof hasSrc && "symbol" !== typeof hasSrc;
						break;
					default: setProp(domElement, tag, checked, hasSrc, props, null);
				}
				return;
			case "dialog":
				listenToNonDelegatedEvent("beforetoggle", domElement);
				listenToNonDelegatedEvent("toggle", domElement);
				listenToNonDelegatedEvent("cancel", domElement);
				listenToNonDelegatedEvent("close", domElement);
				break;
			case "iframe":
			case "object":
				listenToNonDelegatedEvent("load", domElement);
				break;
			case "video":
			case "audio":
				for (hasSrc = 0; hasSrc < mediaEventTypes.length; hasSrc++) listenToNonDelegatedEvent(mediaEventTypes[hasSrc], domElement);
				break;
			case "image":
				listenToNonDelegatedEvent("error", domElement);
				listenToNonDelegatedEvent("load", domElement);
				break;
			case "details":
				listenToNonDelegatedEvent("toggle", domElement);
				break;
			case "embed":
			case "source":
			case "link": listenToNonDelegatedEvent("error", domElement), listenToNonDelegatedEvent("load", domElement);
			case "area":
			case "base":
			case "br":
			case "col":
			case "hr":
			case "keygen":
			case "meta":
			case "param":
			case "track":
			case "wbr":
			case "menuitem":
				for (defaultChecked in props) if (props.hasOwnProperty(defaultChecked) && (hasSrc = props[defaultChecked], null != hasSrc)) switch (defaultChecked) {
					case "children":
					case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(137, tag));
					default: setProp(domElement, tag, defaultChecked, hasSrc, props, null);
				}
				return;
			default: if (isCustomElement(tag)) {
				for (propValue$204 in props) props.hasOwnProperty(propValue$204) && (hasSrc = props[propValue$204], void 0 !== hasSrc && setPropOnCustomElement(domElement, tag, propValue$204, hasSrc, props, void 0));
				return;
			}
		}
		for (defaultValue in props) props.hasOwnProperty(defaultValue) && (hasSrc = props[defaultValue], null != hasSrc && setProp(domElement, tag, defaultValue, hasSrc, props, null));
	}
	var emptyProps = {};
	function updateProperties(domElement, tag, lastProps, nextProps) {
		switch (tag) {
			case "div":
			case "span":
			case "svg":
			case "path":
			case "a":
			case "g":
			case "p":
			case "li": break;
			case "input":
				var name = null, type = null, value = null, defaultValue = null, lastDefaultValue = null, checked = null, defaultChecked = null;
				for (propKey in lastProps) {
					var lastProp = lastProps[propKey];
					if (lastProps.hasOwnProperty(propKey) && null != lastProp) switch (propKey) {
						case "checked": break;
						case "value": break;
						case "defaultValue": lastDefaultValue = lastProp;
						default: nextProps.hasOwnProperty(propKey) || setProp(domElement, tag, propKey, null, nextProps, lastProp);
					}
				}
				for (var propKey$221 in nextProps) {
					var propKey = nextProps[propKey$221];
					lastProp = lastProps[propKey$221];
					if (nextProps.hasOwnProperty(propKey$221) && (null != propKey || null != lastProp)) switch (propKey$221) {
						case "type":
							propKey !== lastProp && (viewTransitionMutationContext = !0);
							type = propKey;
							break;
						case "name":
							propKey !== lastProp && (viewTransitionMutationContext = !0);
							name = propKey;
							break;
						case "checked":
							propKey !== lastProp && (viewTransitionMutationContext = !0);
							checked = propKey;
							break;
						case "defaultChecked":
							propKey !== lastProp && (viewTransitionMutationContext = !0);
							defaultChecked = propKey;
							break;
						case "value":
							propKey !== lastProp && (viewTransitionMutationContext = !0);
							value = propKey;
							break;
						case "defaultValue":
							propKey !== lastProp && (viewTransitionMutationContext = !0);
							defaultValue = propKey;
							break;
						case "children":
						case "dangerouslySetInnerHTML":
							if (null != propKey) throw Error(formatProdErrorMessage(137, tag));
							break;
						default: propKey !== lastProp && setProp(domElement, tag, propKey$221, propKey, nextProps, lastProp);
					}
				}
				updateInput(domElement, value, defaultValue, lastDefaultValue, checked, defaultChecked, type, name);
				return;
			case "select":
				propKey = value = defaultValue = propKey$221 = null;
				for (type in lastProps) if (lastDefaultValue = lastProps[type], lastProps.hasOwnProperty(type) && null != lastDefaultValue) switch (type) {
					case "value": break;
					case "multiple": propKey = lastDefaultValue;
					default: nextProps.hasOwnProperty(type) || setProp(domElement, tag, type, null, nextProps, lastDefaultValue);
				}
				for (name in nextProps) if (type = nextProps[name], lastDefaultValue = lastProps[name], nextProps.hasOwnProperty(name) && (null != type || null != lastDefaultValue)) switch (name) {
					case "value":
						type !== lastDefaultValue && (viewTransitionMutationContext = !0);
						propKey$221 = type;
						break;
					case "defaultValue":
						type !== lastDefaultValue && (viewTransitionMutationContext = !0);
						defaultValue = type;
						break;
					case "multiple": type !== lastDefaultValue && (viewTransitionMutationContext = !0), value = type;
					default: type !== lastDefaultValue && setProp(domElement, tag, name, type, nextProps, lastDefaultValue);
				}
				tag = defaultValue;
				lastProps = value;
				nextProps = propKey;
				null != propKey$221 ? updateOptions(domElement, !!lastProps, propKey$221, !1) : !!nextProps !== !!lastProps && (null != tag ? updateOptions(domElement, !!lastProps, tag, !0) : updateOptions(domElement, !!lastProps, lastProps ? [] : "", !1));
				return;
			case "textarea":
				propKey = propKey$221 = null;
				for (defaultValue in lastProps) if (name = lastProps[defaultValue], lastProps.hasOwnProperty(defaultValue) && null != name && !nextProps.hasOwnProperty(defaultValue)) switch (defaultValue) {
					case "value": break;
					case "children": break;
					default: setProp(domElement, tag, defaultValue, null, nextProps, name);
				}
				for (value in nextProps) if (name = nextProps[value], type = lastProps[value], nextProps.hasOwnProperty(value) && (null != name || null != type)) switch (value) {
					case "value":
						name !== type && (viewTransitionMutationContext = !0);
						propKey$221 = name;
						break;
					case "defaultValue":
						name !== type && (viewTransitionMutationContext = !0);
						propKey = name;
						break;
					case "children": break;
					case "dangerouslySetInnerHTML":
						if (null != name) throw Error(formatProdErrorMessage(91));
						break;
					default: name !== type && setProp(domElement, tag, value, name, nextProps, type);
				}
				updateTextarea(domElement, propKey$221, propKey);
				return;
			case "option":
				for (var propKey$237 in lastProps) if (propKey$221 = lastProps[propKey$237], lastProps.hasOwnProperty(propKey$237) && null != propKey$221 && !nextProps.hasOwnProperty(propKey$237)) switch (propKey$237) {
					case "selected":
						domElement.selected = !1;
						break;
					default: setProp(domElement, tag, propKey$237, null, nextProps, propKey$221);
				}
				for (lastDefaultValue in nextProps) if (propKey$221 = nextProps[lastDefaultValue], propKey = lastProps[lastDefaultValue], nextProps.hasOwnProperty(lastDefaultValue) && propKey$221 !== propKey && (null != propKey$221 || null != propKey)) switch (lastDefaultValue) {
					case "selected":
						propKey$221 !== propKey && (viewTransitionMutationContext = !0);
						domElement.selected = propKey$221 && "function" !== typeof propKey$221 && "symbol" !== typeof propKey$221;
						break;
					default: setProp(domElement, tag, lastDefaultValue, propKey$221, nextProps, propKey);
				}
				return;
			case "img":
			case "link":
			case "area":
			case "base":
			case "br":
			case "col":
			case "embed":
			case "hr":
			case "keygen":
			case "meta":
			case "param":
			case "source":
			case "track":
			case "wbr":
			case "menuitem":
				for (var propKey$242 in lastProps) propKey$221 = lastProps[propKey$242], lastProps.hasOwnProperty(propKey$242) && null != propKey$221 && !nextProps.hasOwnProperty(propKey$242) && setProp(domElement, tag, propKey$242, null, nextProps, propKey$221);
				for (checked in nextProps) if (propKey$221 = nextProps[checked], propKey = lastProps[checked], nextProps.hasOwnProperty(checked) && propKey$221 !== propKey && (null != propKey$221 || null != propKey)) switch (checked) {
					case "children":
					case "dangerouslySetInnerHTML":
						if (null != propKey$221) throw Error(formatProdErrorMessage(137, tag));
						break;
					default: setProp(domElement, tag, checked, propKey$221, nextProps, propKey);
				}
				return;
			default: if (isCustomElement(tag)) {
				for (var propKey$247 in lastProps) propKey$221 = lastProps[propKey$247], lastProps.hasOwnProperty(propKey$247) && void 0 !== propKey$221 && !nextProps.hasOwnProperty(propKey$247) && setPropOnCustomElement(domElement, tag, propKey$247, void 0, nextProps, propKey$221);
				for (defaultChecked in nextProps) propKey$221 = nextProps[defaultChecked], propKey = lastProps[defaultChecked], !nextProps.hasOwnProperty(defaultChecked) || propKey$221 === propKey || void 0 === propKey$221 && void 0 === propKey || setPropOnCustomElement(domElement, tag, defaultChecked, propKey$221, nextProps, propKey);
				return;
			}
		}
		for (var propKey$252 in lastProps) propKey$221 = lastProps[propKey$252], lastProps.hasOwnProperty(propKey$252) && null != propKey$221 && !nextProps.hasOwnProperty(propKey$252) && setProp(domElement, tag, propKey$252, null, nextProps, propKey$221);
		for (lastProp in nextProps) propKey$221 = nextProps[lastProp], propKey = lastProps[lastProp], !nextProps.hasOwnProperty(lastProp) || propKey$221 === propKey || null == propKey$221 && null == propKey || setProp(domElement, tag, lastProp, propKey$221, nextProps, propKey);
	}
	function isLikelyStaticResource(initiatorType) {
		switch (initiatorType) {
			case "css":
			case "script":
			case "font":
			case "img":
			case "image":
			case "input":
			case "link": return !0;
			default: return !1;
		}
	}
	function estimateBandwidth() {
		if ("function" === typeof performance.getEntriesByType) {
			for (var count = 0, bits = 0, resourceEntries = performance.getEntriesByType("resource"), i = 0; i < resourceEntries.length; i++) {
				var entry = resourceEntries[i], transferSize = entry.transferSize, initiatorType = entry.initiatorType, duration = entry.duration;
				if (transferSize && duration && isLikelyStaticResource(initiatorType)) {
					initiatorType = 0;
					duration = entry.responseEnd;
					for (i += 1; i < resourceEntries.length; i++) {
						var overlapEntry = resourceEntries[i], overlapStartTime = overlapEntry.startTime;
						if (overlapStartTime > duration) break;
						var overlapTransferSize = overlapEntry.transferSize, overlapInitiatorType = overlapEntry.initiatorType;
						overlapTransferSize && isLikelyStaticResource(overlapInitiatorType) && (overlapEntry = overlapEntry.responseEnd, initiatorType += overlapTransferSize * (overlapEntry < duration ? 1 : (duration - overlapStartTime) / (overlapEntry - overlapStartTime)));
					}
					--i;
					bits += 8 * (transferSize + initiatorType) / (entry.duration / 1e3);
					count++;
					if (10 < count) break;
				}
			}
			if (0 < count) return bits / count / 1e6;
		}
		return navigator.connection && (count = navigator.connection.downlink, "number" === typeof count) ? count : 5;
	}
	var eventsEnabled = null;
	var selectionInformation = null;
	function getOwnerDocumentFromRootContainer(rootContainerElement) {
		return 9 === rootContainerElement.nodeType ? rootContainerElement : rootContainerElement.ownerDocument;
	}
	function getOwnHostContext(namespaceURI) {
		switch (namespaceURI) {
			case "http://www.w3.org/2000/svg": return 1;
			case "http://www.w3.org/1998/Math/MathML": return 2;
			default: return 0;
		}
	}
	function getChildHostContextProd(parentNamespace, type) {
		if (0 === parentNamespace) switch (type) {
			case "svg": return 1;
			case "math": return 2;
			default: return 0;
		}
		return 1 === parentNamespace && "foreignObject" === type ? 0 : parentNamespace;
	}
	function createHoistableInstance(type, props, rootContainerInstance, internalInstanceHandle) {
		rootContainerInstance = getOwnerDocumentFromRootContainer(rootContainerInstance).createElement(type);
		rootContainerInstance[internalInstanceKey] = internalInstanceHandle;
		rootContainerInstance[internalPropsKey] = props;
		setInitialProperties(rootContainerInstance, type, props);
		markNodeAsHoistable(rootContainerInstance);
		return rootContainerInstance;
	}
	function shouldSetTextContent(type, props) {
		return "textarea" === type || "noscript" === type || "string" === typeof props.children || "number" === typeof props.children || "bigint" === typeof props.children || "object" === typeof props.dangerouslySetInnerHTML && null !== props.dangerouslySetInnerHTML && null != props.dangerouslySetInnerHTML.__html;
	}
	var currentPopstateTransitionEvent = null;
	function shouldAttemptEagerTransition() {
		var event = window.event;
		if (event && "popstate" === event.type) {
			if (event === currentPopstateTransitionEvent) return !1;
			currentPopstateTransitionEvent = event;
			return !0;
		}
		currentPopstateTransitionEvent = null;
		return !1;
	}
	var scheduleTimeout = "function" === typeof setTimeout ? setTimeout : void 0;
	var cancelTimeout = "function" === typeof clearTimeout ? clearTimeout : void 0;
	var localPromise = "function" === typeof Promise ? Promise : void 0;
	var localRequestAnimationFrame = "function" === typeof requestAnimationFrame ? requestAnimationFrame : scheduleTimeout;
	var scheduleMicrotask = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof localPromise ? function(callback) {
		return localPromise.resolve(null).then(callback).catch(handleErrorInNextTick);
	} : scheduleTimeout;
	function handleErrorInNextTick(error) {
		setTimeout(function() {
			throw error;
		});
	}
	function isSingletonScope(type) {
		return "head" === type;
	}
	function clearHydrationBoundary(parentInstance, hydrationInstance) {
		var node = hydrationInstance, depth = 0;
		do {
			var nextNode = node.nextSibling;
			parentInstance.removeChild(node);
			if (nextNode && 8 === nextNode.nodeType) if (node = nextNode.data, "/$" === node || "/&" === node) {
				if (0 === depth) {
					parentInstance.removeChild(nextNode);
					retryIfBlockedOn(hydrationInstance);
					return;
				}
				depth--;
			} else if ("$" === node || "$?" === node || "$~" === node || "$!" === node || "&" === node) depth++;
			else if ("html" === node) clearSingletonPreambleContribution(parentInstance.ownerDocument.documentElement);
			else if ("head" === node) {
				node = parentInstance.ownerDocument.head;
				clearSingletonPreambleContribution(node);
				for (var node$jscomp$0 = node.firstChild; node$jscomp$0;) {
					var nextNode$jscomp$0 = node$jscomp$0.nextSibling, nodeName = node$jscomp$0.nodeName;
					node$jscomp$0[internalHoistableMarker] || "SCRIPT" === nodeName || "STYLE" === nodeName || "LINK" === nodeName && "stylesheet" === node$jscomp$0.rel.toLowerCase() || node.removeChild(node$jscomp$0);
					node$jscomp$0 = nextNode$jscomp$0;
				}
			} else "body" === node && clearSingletonPreambleContribution(parentInstance.ownerDocument.body);
			node = nextNode;
		} while (node);
		retryIfBlockedOn(hydrationInstance);
	}
	function hideOrUnhideDehydratedBoundary(suspenseInstance, isHidden) {
		var node = suspenseInstance;
		suspenseInstance = 0;
		do {
			var nextNode = node.nextSibling;
			1 === node.nodeType ? isHidden ? (node._stashedDisplay = node.style.display, node.style.display = "none") : (node.style.display = node._stashedDisplay || "", "" === node.getAttribute("style") && node.removeAttribute("style")) : 3 === node.nodeType && (isHidden ? (node._stashedText = node.nodeValue, node.nodeValue = "") : node.nodeValue = node._stashedText || "");
			if (nextNode && 8 === nextNode.nodeType) if (node = nextNode.data, "/$" === node) if (0 === suspenseInstance) break;
			else suspenseInstance--;
			else "$" !== node && "$?" !== node && "$~" !== node && "$!" !== node || suspenseInstance++;
			node = nextNode;
		} while (node);
	}
	function applyViewTransitionName(instance, name, className) {
		name = CSS.escape(name) !== name ? "r-" + btoa(name).replace(/=/g, "") : name;
		instance.style.viewTransitionName = name;
		null != className && (instance.style.viewTransitionClass = className);
		className = getComputedStyle(instance);
		if ("inline" === className.display) {
			name = instance.getClientRects();
			if (1 === name.length) var JSCompiler_inline_result = 1;
			else for (var i = JSCompiler_inline_result = 0; i < name.length; i++) {
				var rect = name[i];
				0 < rect.width && 0 < rect.height && JSCompiler_inline_result++;
			}
			1 === JSCompiler_inline_result && (instance = instance.style, instance.display = 1 === name.length ? "inline-block" : "block", instance.marginTop = "-" + className.paddingTop, instance.marginBottom = "-" + className.paddingBottom);
		}
	}
	function restoreViewTransitionName(instance, props) {
		instance = instance.style;
		props = props.style;
		var viewTransitionName = null != props ? props.hasOwnProperty("viewTransitionName") ? props.viewTransitionName : props.hasOwnProperty("view-transition-name") ? props["view-transition-name"] : null : null;
		instance.viewTransitionName = null == viewTransitionName || "boolean" === typeof viewTransitionName ? "" : ("" + viewTransitionName).trim();
		viewTransitionName = null != props ? props.hasOwnProperty("viewTransitionClass") ? props.viewTransitionClass : props.hasOwnProperty("view-transition-class") ? props["view-transition-class"] : null : null;
		instance.viewTransitionClass = null == viewTransitionName || "boolean" === typeof viewTransitionName ? "" : ("" + viewTransitionName).trim();
		"inline-block" === instance.display && (null == props ? instance.display = instance.margin = "" : (viewTransitionName = props.display, instance.display = null == viewTransitionName || "boolean" === typeof viewTransitionName ? "" : viewTransitionName, viewTransitionName = props.margin, null != viewTransitionName ? instance.margin = viewTransitionName : (viewTransitionName = props.hasOwnProperty("marginTop") ? props.marginTop : props["margin-top"], instance.marginTop = null == viewTransitionName || "boolean" === typeof viewTransitionName ? "" : viewTransitionName, props = props.hasOwnProperty("marginBottom") ? props.marginBottom : props["margin-bottom"], instance.marginBottom = null == props || "boolean" === typeof props ? "" : props)));
	}
	function createMeasurement(rect, computedStyle, element) {
		element = element.ownerDocument.defaultView;
		return {
			rect,
			abs: "absolute" === computedStyle.position || "fixed" === computedStyle.position,
			clip: "none" !== computedStyle.clipPath || "visible" !== computedStyle.overflow || "none" !== computedStyle.filter || "none" !== computedStyle.mask || "none" !== computedStyle.mask || "0px" !== computedStyle.borderRadius,
			view: 0 <= rect.bottom && 0 <= rect.right && rect.top <= element.innerHeight && rect.left <= element.innerWidth
		};
	}
	function measureInstance(instance) {
		return createMeasurement(instance.getBoundingClientRect(), getComputedStyle(instance), instance);
	}
	function measureClonedInstance(instance) {
		var measuredRect = instance.getBoundingClientRect();
		measuredRect = new DOMRect(measuredRect.x + 2e4, measuredRect.y + 2e4, measuredRect.width, measuredRect.height);
		var computedStyle = getComputedStyle(instance);
		return createMeasurement(measuredRect, computedStyle, instance);
	}
	function forceLayout(ownerDocument) {
		return ownerDocument.documentElement.clientHeight;
	}
	function waitForImageToLoad(resolve) {
		this.addEventListener("load", resolve);
		this.addEventListener("error", resolve);
	}
	function startViewTransition(suspendedState, rootContainer, transitionTypes, mutationCallback, layoutCallback, afterMutationCallback, spawnedWorkCallback, passiveCallback, errorCallback) {
		var ownerDocument = 9 === rootContainer.nodeType ? rootContainer : rootContainer.ownerDocument;
		try {
			var transition = ownerDocument.startViewTransition({
				update: function() {
					var ownerWindow = ownerDocument.defaultView, pendingNavigation = ownerWindow.navigation && ownerWindow.navigation.transition, previousFontLoadingStatus = ownerDocument.fonts.status;
					mutationCallback();
					var blockingPromises = [];
					"loaded" === previousFontLoadingStatus && (forceLayout(ownerDocument), "loading" === ownerDocument.fonts.status && blockingPromises.push(ownerDocument.fonts.ready));
					previousFontLoadingStatus = blockingPromises.length;
					if (null !== suspendedState) for (var suspenseyImages = suspendedState.suspenseyImages, imgBytes = 0, i = 0; i < suspenseyImages.length; i++) {
						var suspenseyImage = suspenseyImages[i];
						if (!suspenseyImage.complete) {
							var rect = suspenseyImage.getBoundingClientRect();
							if (0 < rect.bottom && 0 < rect.right && rect.top < ownerWindow.innerHeight && rect.left < ownerWindow.innerWidth) {
								imgBytes += estimateImageBytes(suspenseyImage);
								if (imgBytes > estimatedBytesWithinLimit) {
									blockingPromises.length = previousFontLoadingStatus;
									break;
								}
								suspenseyImage = new Promise(waitForImageToLoad.bind(suspenseyImage));
								blockingPromises.push(suspenseyImage);
							}
						}
					}
					if (0 < blockingPromises.length) return ownerWindow = Promise.race([Promise.all(blockingPromises), new Promise(function(resolve) {
						return setTimeout(resolve, 500);
					})]).then(layoutCallback, layoutCallback), (pendingNavigation ? Promise.allSettled([pendingNavigation.finished, ownerWindow]) : ownerWindow).then(afterMutationCallback, afterMutationCallback);
					layoutCallback();
					if (pendingNavigation) return pendingNavigation.finished.then(afterMutationCallback, afterMutationCallback);
					afterMutationCallback();
				},
				types: transitionTypes
			});
			ownerDocument.__reactViewTransition = transition;
			var viewTransitionAnimations = [];
			transition.ready.then(function() {
				for (var animations = ownerDocument.documentElement.getAnimations({ subtree: !0 }), i = 0; i < animations.length; i++) {
					var animation = animations[i], effect = animation.effect, pseudoElement = effect.pseudoElement;
					if (null != pseudoElement && pseudoElement.startsWith("::view-transition")) {
						viewTransitionAnimations.push(animation);
						animation = effect.getKeyframes();
						for (var height = pseudoElement = void 0, unchangedDimensions = !0, j = 0; j < animation.length; j++) {
							var keyframe = animation[j], w = keyframe.width;
							if (void 0 === pseudoElement) pseudoElement = w;
							else if (pseudoElement !== w) {
								unchangedDimensions = !1;
								break;
							}
							w = keyframe.height;
							if (void 0 === height) height = w;
							else if (height !== w) {
								unchangedDimensions = !1;
								break;
							}
							delete keyframe.width;
							delete keyframe.height;
							"none" === keyframe.transform && delete keyframe.transform;
						}
						unchangedDimensions && void 0 !== pseudoElement && void 0 !== height && (effect.setKeyframes(animation), unchangedDimensions = getComputedStyle(effect.target, effect.pseudoElement), unchangedDimensions.width !== pseudoElement || unchangedDimensions.height !== height) && (unchangedDimensions = animation[0], unchangedDimensions.width = pseudoElement, unchangedDimensions.height = height, unchangedDimensions = animation[animation.length - 1], unchangedDimensions.width = pseudoElement, unchangedDimensions.height = height, effect.setKeyframes(animation));
					}
				}
				spawnedWorkCallback();
			}, function(error) {
				ownerDocument.__reactViewTransition === transition && (ownerDocument.__reactViewTransition = null);
				try {
					if ("object" === typeof error && null !== error) switch (error.name) {
						case "InvalidStateError": if ("View transition was skipped because document visibility state is hidden." === error.message || "Skipping view transition because document visibility state has become hidden." === error.message || "Skipping view transition because viewport size changed." === error.message || "Transition was aborted because of invalid state" === error.message) error = null;
					}
					null !== error && errorCallback(error);
				} finally {
					mutationCallback(), layoutCallback(), spawnedWorkCallback();
				}
			});
			transition.finished.finally(function() {
				for (var i = 0; i < viewTransitionAnimations.length; i++) viewTransitionAnimations[i].cancel();
				ownerDocument.__reactViewTransition === transition && (ownerDocument.__reactViewTransition = null);
				passiveCallback();
			});
			return transition;
		} catch (x) {
			return mutationCallback(), layoutCallback(), spawnedWorkCallback(), null;
		}
	}
	function ViewTransitionPseudoElement(pseudo, name) {
		this._scope = document.documentElement;
		this._selector = "::view-transition-" + pseudo + "(" + name + ")";
	}
	ViewTransitionPseudoElement.prototype.animate = function(keyframes, options) {
		options = "number" === typeof options ? { duration: options } : assign({}, options);
		options.pseudoElement = this._selector;
		return this._scope.animate(keyframes, options);
	};
	ViewTransitionPseudoElement.prototype.getAnimations = function() {
		for (var scope = this._scope, selector = this._selector, animations = scope.getAnimations({ subtree: !0 }), result = [], i = 0; i < animations.length; i++) {
			var effect = animations[i].effect;
			null !== effect && effect.target === scope && effect.pseudoElement === selector && result.push(animations[i]);
		}
		return result;
	};
	ViewTransitionPseudoElement.prototype.getComputedStyle = function() {
		return getComputedStyle(this._scope, this._selector);
	};
	function createViewTransitionInstance(name) {
		return {
			name,
			group: new ViewTransitionPseudoElement("group", name),
			imagePair: new ViewTransitionPseudoElement("image-pair", name),
			old: new ViewTransitionPseudoElement("old", name),
			new: new ViewTransitionPseudoElement("new", name)
		};
	}
	function FragmentInstance(fragmentFiber) {
		this._fragmentFiber = fragmentFiber;
		this._observers = this._eventListeners = null;
	}
	FragmentInstance.prototype.addEventListener = function(type, listener, optionsOrUseCapture) {
		var signal = null, cleanup = null;
		if (null != optionsOrUseCapture && "boolean" !== typeof optionsOrUseCapture && (signal = optionsOrUseCapture.signal || null, null !== signal && signal.aborted)) return;
		null === this._eventListeners && (this._eventListeners = []);
		var listeners = this._eventListeners;
		if (-1 === indexOfEventListener(listeners, type, listener, optionsOrUseCapture)) {
			var fragmentInstance = this, attachedListener = listener;
			null != optionsOrUseCapture && "boolean" !== typeof optionsOrUseCapture && !0 === optionsOrUseCapture.once && (attachedListener = function(event) {
				fragmentInstance.removeEventListener(type, listener, optionsOrUseCapture);
				"function" === typeof listener ? listener.call(this, event) : listener.handleEvent(event);
			});
			null !== signal && (cleanup = fragmentInstance.removeEventListener.bind(fragmentInstance, type, listener, optionsOrUseCapture), signal.addEventListener("abort", cleanup, { once: !0 }), cleanup = signal.removeEventListener.bind(signal, "abort", cleanup));
			signal = getAttachOptions(optionsOrUseCapture);
			listeners.push({
				type,
				listener,
				optionsOrUseCapture,
				attachedListener,
				cleanup
			});
			traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, addEventListenerToChild, type, attachedListener, signal);
		}
		this._eventListeners = listeners;
	};
	function addEventListenerToChild(child, type, listener, optionsOrUseCapture) {
		getInstanceFromHostFiber(child).addEventListener(type, listener, optionsOrUseCapture);
		return !1;
	}
	FragmentInstance.prototype.removeEventListener = function(type, listener, optionsOrUseCapture) {
		var listeners = this._eventListeners;
		if (null !== listeners && (listener = indexOfEventListener(listeners, type, listener, optionsOrUseCapture), -1 !== listener)) {
			var _listeners$index = listeners[listener];
			optionsOrUseCapture = _listeners$index.attachedListener;
			var cleanup = _listeners$index.cleanup;
			_listeners$index = getAttachOptions(_listeners$index.optionsOrUseCapture);
			traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, removeEventListenerFromChild, type, optionsOrUseCapture, _listeners$index);
			listeners.splice(listener, 1);
			null !== cleanup && cleanup();
		}
	};
	function removeEventListenerFromChild(child, type, listener, optionsOrUseCapture) {
		getInstanceFromHostFiber(child).removeEventListener(type, listener, optionsOrUseCapture);
		return !1;
	}
	function getAttachOptions(opts) {
		return null != opts && "boolean" !== typeof opts && (!0 === opts.once || opts.signal instanceof AbortSignal) ? {
			capture: opts.capture,
			passive: opts.passive
		} : opts;
	}
	function normalizeListenerOptions(opts) {
		return null == opts ? "c=0" : "boolean" === typeof opts ? "c=" + (opts ? "1" : "0") : "c=" + (opts.capture ? "1" : "0");
	}
	function indexOfEventListener(eventListeners, type, listener, optionsOrUseCapture) {
		if (0 === eventListeners.length) return -1;
		optionsOrUseCapture = normalizeListenerOptions(optionsOrUseCapture);
		for (var i = 0; i < eventListeners.length; i++) {
			var item = eventListeners[i];
			if (item.type === type && item.listener === listener && normalizeListenerOptions(item.optionsOrUseCapture) === optionsOrUseCapture) return i;
		}
		return -1;
	}
	FragmentInstance.prototype.dispatchEvent = function(event) {
		var parentHostFiber = getFragmentParentInstanceOrContainerFiber(this._fragmentFiber);
		if (null === parentHostFiber) return !0;
		parentHostFiber = getInstanceFromHostFiber(parentHostFiber);
		var eventListeners = this._eventListeners;
		if (null !== eventListeners && 0 < eventListeners.length || !event.bubbles) {
			var temp = 9 === parentHostFiber.nodeType ? parentHostFiber.createComment("") : document.createTextNode("");
			if (eventListeners) for (var i = 0; i < eventListeners.length; i++) {
				var _eventListeners$i = eventListeners[i];
				temp.addEventListener(_eventListeners$i.type, _eventListeners$i.attachedListener, getAttachOptions(_eventListeners$i.optionsOrUseCapture));
			}
			parentHostFiber.appendChild(temp);
			event = temp.dispatchEvent(event);
			if (eventListeners) for (i = 0; i < eventListeners.length; i++) _eventListeners$i = eventListeners[i], temp.removeEventListener(_eventListeners$i.type, _eventListeners$i.attachedListener, getAttachOptions(_eventListeners$i.optionsOrUseCapture));
			parentHostFiber.removeChild(temp);
			return event;
		}
		return parentHostFiber.dispatchEvent(event);
	};
	FragmentInstance.prototype.focus = function(focusOptions) {
		traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !0, setFocusOnFiberIfFocusable, focusOptions, void 0, void 0);
	};
	function setFocusOnFiberIfFocusable(fiber, focusOptions) {
		if (6 === fiber.tag) return !1;
		fiber = getInstanceFromHostFiber(fiber);
		return setFocusIfFocusable(fiber, focusOptions);
	}
	FragmentInstance.prototype.focusLast = function(focusOptions) {
		var children = [];
		traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !0, collectChildren, children, void 0, void 0);
		for (var i = children.length - 1; 0 <= i && !setFocusOnFiberIfFocusable(children[i], focusOptions); i--);
	};
	function collectChildren(child, collection) {
		collection.push(child);
		return !1;
	}
	FragmentInstance.prototype.blur = function() {
		var parentHostFiber = getFragmentParentInstanceOrContainerFiber(this._fragmentFiber);
		null !== parentHostFiber && (parentHostFiber = getInstanceFromHostFiber(parentHostFiber), parentHostFiber = getOwnerDocumentFromRootContainer(parentHostFiber).activeElement, null !== parentHostFiber && traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, blurActiveElementWithinFragment, parentHostFiber, void 0, void 0));
	};
	function blurActiveElementWithinFragment(child, activeElement) {
		if (6 === child.tag) return !1;
		child = getInstanceFromHostFiber(child);
		return child === activeElement || child.contains(activeElement) ? (activeElement.blur(), !0) : !1;
	}
	FragmentInstance.prototype.observeUsing = function(observer) {
		null === this._observers && (this._observers = /* @__PURE__ */ new Set());
		this._observers.add(observer);
		traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, observeChild, observer, void 0, void 0);
	};
	function observeChild(child, observer) {
		if (6 === child.tag) return !1;
		child = getInstanceFromHostFiber(child);
		observer.observe(child);
		return !1;
	}
	FragmentInstance.prototype.unobserveUsing = function(observer) {
		var observers = this._observers;
		if (null !== observers && observers.has(observer)) {
			observers.delete(observer);
			traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, unobserveChild, observer, void 0, void 0);
			for (var i = observers = 0; i < pendingIntersectionUnobserves.length; i++) {
				var pending = pendingIntersectionUnobserves[i];
				pending.fragmentInstance === this && pending.observer === observer ? observer.unobserve(pending.instance) : pendingIntersectionUnobserves[observers++] = pending;
			}
			pendingIntersectionUnobserves.length = observers;
		}
	};
	function unobserveChild(child, observer) {
		if (6 === child.tag) return !1;
		child = getInstanceFromHostFiber(child);
		observer.unobserve(child);
		return !1;
	}
	var pendingIntersectionUnobserves = [];
	var intersectionUnobserveScheduled = !1;
	function schedulePendingIntersectionUnobserve(fragmentInstance, observer, instance) {
		pendingIntersectionUnobserves.push({
			fragmentInstance,
			observer,
			instance
		});
		intersectionUnobserveScheduled || (intersectionUnobserveScheduled = !0, requestPostPaintCallback(function() {
			intersectionUnobserveScheduled = !1;
			var pending = pendingIntersectionUnobserves;
			pendingIntersectionUnobserves = [];
			for (var i = 0; i < pending.length; i++) {
				var item = pending[i];
				item.observer.unobserve(item.instance);
			}
		}));
	}
	FragmentInstance.prototype.getClientRects = function() {
		var rects = [];
		traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, collectClientRects, rects, void 0, void 0);
		return rects;
	};
	function collectClientRects(child, rects) {
		if (6 === child.tag) {
			child = child.stateNode;
			var range = child.ownerDocument.createRange();
			range.selectNodeContents(child);
			rects.push.apply(rects, range.getClientRects());
		} else child = getInstanceFromHostFiber(child), rects.push.apply(rects, child.getClientRects());
		return !1;
	}
	FragmentInstance.prototype.getRootNode = function(getRootNodeOptions) {
		var parentHostFiber = getFragmentParentInstanceOrContainerFiber(this._fragmentFiber);
		return null === parentHostFiber ? this : getInstanceFromHostFiber(parentHostFiber).getRootNode(getRootNodeOptions);
	};
	FragmentInstance.prototype.compareDocumentPosition = function(otherNode) {
		var parentHostFiber = getFragmentParentInstanceOrContainerFiber(this._fragmentFiber);
		if (null === parentHostFiber) return Node.DOCUMENT_POSITION_DISCONNECTED;
		var children = [];
		traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, collectChildren, children, void 0, void 0);
		var parentHostInstance = getInstanceFromHostFiber(parentHostFiber);
		if (0 === children.length) {
			children = parentHostInstance;
			if (fiberIsPortaledIntoHost(this._fragmentFiber)) {
				a: {
					for (parentHostFiber = this._fragmentFiber.return; null !== parentHostFiber;) {
						if (4 === parentHostFiber.tag) {
							parentHostFiber = parentHostFiber.stateNode.containerInfo;
							break a;
						}
						if (3 === parentHostFiber.tag || 5 === parentHostFiber.tag || 27 === parentHostFiber.tag) break;
						parentHostFiber = parentHostFiber.return;
					}
					parentHostFiber = null;
				}
				null != parentHostFiber && (children = parentHostFiber);
			}
			parentHostFiber = this._fragmentFiber;
			var result = parentHostInstance = children.compareDocumentPosition(otherNode);
			children === otherNode ? result = Node.DOCUMENT_POSITION_CONTAINS : parentHostInstance & Node.DOCUMENT_POSITION_CONTAINED_BY && (children = getFragmentInstanceOrTextInstanceSiblings(parentHostFiber)[1], null === children ? result = Node.DOCUMENT_POSITION_PRECEDING : (otherNode = getInstanceFromHostFiber(children).compareDocumentPosition(otherNode), result = 0 === otherNode || otherNode & Node.DOCUMENT_POSITION_FOLLOWING ? Node.DOCUMENT_POSITION_FOLLOWING : Node.DOCUMENT_POSITION_PRECEDING));
			return result |= Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
		}
		parentHostFiber = getInstanceFromHostFiber(children[0]);
		result = getInstanceFromHostFiber(children[children.length - 1]);
		var parentHostInstanceFromDOM = fiberIsPortaledIntoHost(this._fragmentFiber) ? parentHostFiber.parentElement : parentHostInstance;
		if (null == parentHostInstanceFromDOM) return Node.DOCUMENT_POSITION_DISCONNECTED;
		parentHostInstance = parentHostInstanceFromDOM.compareDocumentPosition(parentHostFiber) & Node.DOCUMENT_POSITION_CONTAINED_BY;
		parentHostInstanceFromDOM = parentHostInstanceFromDOM.compareDocumentPosition(result) & Node.DOCUMENT_POSITION_CONTAINED_BY;
		var firstResult = parentHostFiber.compareDocumentPosition(otherNode), lastResult = result.compareDocumentPosition(otherNode), otherNodeIsWithinFirstOrLastChild = firstResult & Node.DOCUMENT_POSITION_CONTAINED_BY || lastResult & Node.DOCUMENT_POSITION_CONTAINED_BY;
		lastResult = parentHostInstance && parentHostInstanceFromDOM && firstResult & Node.DOCUMENT_POSITION_FOLLOWING && lastResult & Node.DOCUMENT_POSITION_PRECEDING;
		parentHostFiber = parentHostInstance && parentHostFiber === otherNode || parentHostInstanceFromDOM && result === otherNode || otherNodeIsWithinFirstOrLastChild || lastResult ? Node.DOCUMENT_POSITION_CONTAINED_BY : !parentHostInstance && parentHostFiber === otherNode || !parentHostInstanceFromDOM && result === otherNode ? Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC : firstResult;
		return parentHostFiber & Node.DOCUMENT_POSITION_DISCONNECTED || parentHostFiber & Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC || validateDocumentPositionWithFiberTree(parentHostFiber, this._fragmentFiber, children[0], children[children.length - 1], otherNode) ? parentHostFiber : Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
	};
	function validateDocumentPositionWithFiberTree(documentPosition, fragmentFiber, precedingBoundaryFiber, followingBoundaryFiber, otherNode) {
		var otherFiber = getClosestInstanceFromNode(otherNode);
		if (documentPosition & Node.DOCUMENT_POSITION_CONTAINED_BY) {
			if (precedingBoundaryFiber = !!otherFiber) a: {
				for (; null !== otherFiber;) {
					if (7 === otherFiber.tag && (otherFiber === fragmentFiber || otherFiber.alternate === fragmentFiber)) {
						precedingBoundaryFiber = !0;
						break a;
					}
					otherFiber = otherFiber.return;
				}
				precedingBoundaryFiber = !1;
			}
			return precedingBoundaryFiber;
		}
		if (documentPosition & Node.DOCUMENT_POSITION_CONTAINS) {
			if (null === otherFiber) return otherFiber = otherNode.ownerDocument, otherNode === otherFiber || otherNode === otherFiber.documentElement || otherNode === otherFiber.body;
			a: {
				otherFiber = fragmentFiber;
				for (fragmentFiber = getFragmentParentInstanceOrContainerFiber(fragmentFiber); null !== otherFiber;) {
					if (!(5 !== otherFiber.tag && 3 !== otherFiber.tag && 27 !== otherFiber.tag || otherFiber !== fragmentFiber && otherFiber.alternate !== fragmentFiber)) {
						otherFiber = !0;
						break a;
					}
					otherFiber = otherFiber.return;
				}
				otherFiber = !1;
			}
			return otherFiber;
		}
		return documentPosition & Node.DOCUMENT_POSITION_PRECEDING ? ((fragmentFiber = !!otherFiber) && !(fragmentFiber = otherFiber === precedingBoundaryFiber) && (fragmentFiber = getLowestCommonAncestor(precedingBoundaryFiber, otherFiber, getParentForFragmentAncestors), null === fragmentFiber ? fragmentFiber = !1 : (traverseVisibleInstancesAndTextInstances(fragmentFiber, !0, isFiberPrecedingCheck, otherFiber, precedingBoundaryFiber), otherFiber = searchTarget, searchTarget = null, fragmentFiber = null !== otherFiber)), fragmentFiber) : documentPosition & Node.DOCUMENT_POSITION_FOLLOWING ? ((fragmentFiber = !!otherFiber) && !(fragmentFiber = otherFiber === followingBoundaryFiber) && (fragmentFiber = getLowestCommonAncestor(followingBoundaryFiber, otherFiber, getParentForFragmentAncestors), null === fragmentFiber ? fragmentFiber = !1 : (traverseVisibleInstancesAndTextInstances(fragmentFiber, !0, isFiberFollowingCheck, otherFiber, followingBoundaryFiber), otherFiber = searchTarget, searchBoundary = searchTarget = null, fragmentFiber = null !== otherFiber)), fragmentFiber) : !1;
	}
	function scrollTextNodeIntoView(textNode, resolvedAlignToTop) {
		var range = textNode.ownerDocument.createRange();
		range.selectNodeContents(textNode);
		textNode = range.getBoundingClientRect();
		window.scrollTo(window.scrollX + textNode.left, resolvedAlignToTop ? window.scrollY + textNode.top : window.scrollY + textNode.bottom - window.innerHeight);
	}
	FragmentInstance.prototype.scrollIntoView = function(alignToTop) {
		if ("object" === typeof alignToTop) throw Error(formatProdErrorMessage(566));
		var children = [];
		traverseVisibleInstancesAndTextInstances(this._fragmentFiber.child, !1, collectChildren, children, void 0, void 0);
		var resolvedAlignToTop = !1 !== alignToTop;
		if (0 === children.length) {
			var hostSiblings = getFragmentInstanceOrTextInstanceSiblings(this._fragmentFiber);
			hostSiblings = resolvedAlignToTop ? hostSiblings[1] || hostSiblings[0] || getFragmentParentInstanceOrContainerFiber(this._fragmentFiber) : hostSiblings[0] || hostSiblings[1];
			if (null === hostSiblings) return;
			if (6 === hostSiblings.tag) {
				alignToTop = getInstanceFromHostFiber(hostSiblings);
				scrollTextNodeIntoView(alignToTop, resolvedAlignToTop);
				return;
			}
			hostSiblings = getInstanceFromHostFiber(hostSiblings);
			if (9 !== hostSiblings.nodeType) {
				if (11 === hostSiblings.nodeType) {
					resolvedAlignToTop = "host" in hostSiblings ? hostSiblings.host : null;
					null !== resolvedAlignToTop && resolvedAlignToTop.scrollIntoView(alignToTop);
					return;
				}
				hostSiblings.scrollIntoView(alignToTop);
			}
		}
		for (hostSiblings = resolvedAlignToTop ? children.length - 1 : 0; hostSiblings !== (resolvedAlignToTop ? -1 : children.length);) {
			var child = children[hostSiblings];
			6 === child.tag ? (child = getInstanceFromHostFiber(child), scrollTextNodeIntoView(child, resolvedAlignToTop)) : getInstanceFromHostFiber(child).scrollIntoView(alignToTop);
			hostSiblings += resolvedAlignToTop ? -1 : 1;
		}
	};
	function addFragmentHandleToFiber(child, fragmentInstance) {
		child = getInstanceFromHostFiber(child);
		addFragmentHandleToInstance(child, fragmentInstance);
		return !1;
	}
	function addFragmentHandleToInstance(instance, fragmentInstance) {
		instance.reactFragments ??= /* @__PURE__ */ new Set();
		instance.reactFragments.add(fragmentInstance);
	}
	function commitNewChildToFragmentInstance(childInstance, fragmentInstance) {
		var eventListeners = fragmentInstance._eventListeners;
		if (null !== eventListeners) for (var i$jscomp$0 = 0; i$jscomp$0 < eventListeners.length; i$jscomp$0++) {
			var _eventListeners$i3 = eventListeners[i$jscomp$0];
			childInstance.addEventListener(_eventListeners$i3.type, _eventListeners$i3.attachedListener, getAttachOptions(_eventListeners$i3.optionsOrUseCapture));
		}
		3 !== childInstance.nodeType && (eventListeners = fragmentInstance._observers, null !== eventListeners && eventListeners.forEach(function(observer) {
			for (var writeIdx = 0, i = 0; i < pendingIntersectionUnobserves.length; i++) {
				var pending = pendingIntersectionUnobserves[i];
				if (pending.fragmentInstance !== fragmentInstance || pending.observer !== observer || pending.instance !== childInstance) pendingIntersectionUnobserves[writeIdx++] = pending;
			}
			pendingIntersectionUnobserves.length = writeIdx;
			observer.observe(childInstance);
		}), addFragmentHandleToInstance(childInstance, fragmentInstance));
	}
	function deleteChildFromFragmentInstance(childInstance, fragmentInstance) {
		var eventListeners = fragmentInstance._eventListeners;
		if (null !== eventListeners) for (var i = 0; i < eventListeners.length; i++) {
			var _eventListeners$i4 = eventListeners[i];
			childInstance.removeEventListener(_eventListeners$i4.type, _eventListeners$i4.attachedListener, getAttachOptions(_eventListeners$i4.optionsOrUseCapture));
		}
		3 !== childInstance.nodeType && (eventListeners = fragmentInstance._observers, null !== eventListeners && eventListeners.forEach(function(observer) {
			"string" === typeof observer.rootMargin ? schedulePendingIntersectionUnobserve(fragmentInstance, observer, childInstance) : observer.unobserve(childInstance);
		}), null != childInstance.reactFragments && childInstance.reactFragments.delete(fragmentInstance));
	}
	function clearContainerSparingly(container) {
		var nextNode = container.firstChild;
		nextNode && 10 === nextNode.nodeType && (nextNode = nextNode.nextSibling);
		for (; nextNode;) {
			var node = nextNode;
			nextNode = nextNode.nextSibling;
			switch (node.nodeName) {
				case "HTML":
				case "HEAD":
				case "BODY":
					clearContainerSparingly(node);
					detachDeletedInstance(node);
					continue;
				case "SCRIPT":
				case "STYLE": continue;
				case "LINK": if ("stylesheet" === node.rel.toLowerCase()) continue;
			}
			container.removeChild(node);
		}
	}
	function canHydrateInstance(instance, type, props, inRootOrSingleton) {
		for (; 1 === instance.nodeType;) {
			var anyProps = props;
			if (instance.nodeName.toLowerCase() !== type.toLowerCase()) {
				if (!inRootOrSingleton && ("INPUT" !== instance.nodeName || "hidden" !== instance.type)) break;
			} else if (!inRootOrSingleton) if ("input" === type && "hidden" === instance.type) {
				var name = null == anyProps.name ? null : "" + anyProps.name;
				if ("hidden" === anyProps.type && instance.getAttribute("name") === name) return instance;
			} else return instance;
			else if (!instance[internalHoistableMarker]) switch (type) {
				case "meta":
					if (!instance.hasAttribute("itemprop")) break;
					return instance;
				case "link":
					name = instance.getAttribute("rel");
					if ("stylesheet" === name && instance.hasAttribute("data-precedence")) break;
					else if (name !== anyProps.rel || instance.getAttribute("href") !== (null == anyProps.href || "" === anyProps.href ? null : anyProps.href) || instance.getAttribute("crossorigin") !== (null == anyProps.crossOrigin ? null : anyProps.crossOrigin) || instance.getAttribute("title") !== (null == anyProps.title ? null : anyProps.title)) break;
					return instance;
				case "style":
					if (instance.hasAttribute("data-precedence")) break;
					return instance;
				case "script":
					name = instance.getAttribute("src");
					if ((name !== (null == anyProps.src ? null : anyProps.src) || instance.getAttribute("type") !== (null == anyProps.type ? null : anyProps.type) || instance.getAttribute("crossorigin") !== (null == anyProps.crossOrigin ? null : anyProps.crossOrigin)) && name && instance.hasAttribute("async") && !instance.hasAttribute("itemprop")) break;
					return instance;
				default: return instance;
			}
			instance = getNextHydratable(instance.nextSibling);
			if (null === instance) break;
		}
		return null;
	}
	function canHydrateTextInstance(instance, text, inRootOrSingleton) {
		if ("" === text) return null;
		for (; 3 !== instance.nodeType;) {
			if ((1 !== instance.nodeType || "INPUT" !== instance.nodeName || "hidden" !== instance.type) && !inRootOrSingleton) return null;
			instance = getNextHydratable(instance.nextSibling);
			if (null === instance) return null;
		}
		return instance;
	}
	function canHydrateHydrationBoundary(instance, inRootOrSingleton) {
		for (; 8 !== instance.nodeType;) {
			if ((1 !== instance.nodeType || "INPUT" !== instance.nodeName || "hidden" !== instance.type) && !inRootOrSingleton) return null;
			instance = getNextHydratable(instance.nextSibling);
			if (null === instance) return null;
		}
		return instance;
	}
	function isSuspenseInstancePending(instance) {
		return "$?" === instance.data || "$~" === instance.data;
	}
	function isSuspenseInstanceFallback(instance) {
		return "$!" === instance.data || "$?" === instance.data && "loading" !== instance.ownerDocument.readyState;
	}
	function registerSuspenseInstanceRetry(instance, callback) {
		var ownerDocument = instance.ownerDocument;
		if ("$~" === instance.data) instance._reactRetry = callback;
		else if ("$?" !== instance.data || "loading" !== ownerDocument.readyState) callback();
		else {
			var listener = function() {
				callback();
				ownerDocument.removeEventListener("DOMContentLoaded", listener);
			};
			ownerDocument.addEventListener("DOMContentLoaded", listener);
			instance._reactRetry = listener;
		}
	}
	function getNextHydratable(node) {
		for (; null != node; node = node.nextSibling) {
			var nodeType = node.nodeType;
			if (1 === nodeType || 3 === nodeType) break;
			if (8 === nodeType) {
				nodeType = node.data;
				if ("$" === nodeType || "$!" === nodeType || "$?" === nodeType || "$~" === nodeType || "&" === nodeType || "F!" === nodeType || "F" === nodeType) break;
				if ("/$" === nodeType || "/&" === nodeType) return null;
			}
		}
		return node;
	}
	var previousHydratableOnEnteringScopedSingleton = null;
	function getNextHydratableInstanceAfterHydrationBoundary(hydrationInstance) {
		hydrationInstance = hydrationInstance.nextSibling;
		for (var depth = 0; hydrationInstance;) {
			if (8 === hydrationInstance.nodeType) {
				var data = hydrationInstance.data;
				if ("/$" === data || "/&" === data) {
					if (0 === depth) return getNextHydratable(hydrationInstance.nextSibling);
					depth--;
				} else "$" !== data && "$!" !== data && "$?" !== data && "$~" !== data && "&" !== data || depth++;
			}
			hydrationInstance = hydrationInstance.nextSibling;
		}
		return null;
	}
	function getParentHydrationBoundary(targetInstance) {
		targetInstance = targetInstance.previousSibling;
		for (var depth = 0; targetInstance;) {
			if (8 === targetInstance.nodeType) {
				var data = targetInstance.data;
				if ("$" === data || "$!" === data || "$?" === data || "$~" === data || "&" === data) {
					if (0 === depth) return targetInstance;
					depth--;
				} else "/$" !== data && "/&" !== data || depth++;
			}
			targetInstance = targetInstance.previousSibling;
		}
		return null;
	}
	function setFocusIfFocusable(node, focusOptions) {
		function handleFocus() {
			didFocus = !0;
		}
		if (node.ownerDocument.activeElement === node) return !0;
		var didFocus = !1;
		try {
			node.ownerDocument.addEventListener("focus", handleFocus, !0), (node.focus || HTMLElement.prototype.focus).call(node, focusOptions);
		} finally {
			node.ownerDocument.removeEventListener("focus", handleFocus, !0);
		}
		return didFocus;
	}
	function requestPostPaintCallback(callback) {
		localRequestAnimationFrame(function() {
			localRequestAnimationFrame(function(time) {
				return callback(time);
			});
		});
	}
	function resolveSingletonInstance(type, props, rootContainerInstance) {
		props = getOwnerDocumentFromRootContainer(rootContainerInstance);
		switch (type) {
			case "html":
				type = props.documentElement;
				if (!type) throw Error(formatProdErrorMessage(452));
				return type;
			case "head":
				type = props.head;
				if (!type) throw Error(formatProdErrorMessage(453));
				return type;
			case "body":
				type = props.body;
				if (!type) throw Error(formatProdErrorMessage(454));
				return type;
			default: throw Error(formatProdErrorMessage(451));
		}
	}
	function releaseSingletonInstance(instance, type, props) {
		for (var propKey in props) {
			var propValue = props[propKey];
			props.hasOwnProperty(propKey) && null != propValue && setProp(instance, type, propKey, null, emptyProps, propValue);
		}
		null != props.dangerouslySetInnerHTML && (instance.textContent = "");
		instance.onclick === noop$1 && (instance.onclick = null);
		detachDeletedInstance(instance);
	}
	function clearSingletonPreambleContribution(instance) {
		for (var attributes = instance.attributes; attributes.length;) instance.removeAttributeNode(attributes[0]);
		detachDeletedInstance(instance);
	}
	var preloadPropsMap = /* @__PURE__ */ new Map();
	var preconnectsSet = /* @__PURE__ */ new Set();
	function getHoistableRoot(container) {
		if ("function" === typeof container.getRootNode) {
			var rootNode = container.getRootNode();
			if (9 === rootNode.nodeType || 11 === rootNode.nodeType) return rootNode;
		}
		return 9 === container.nodeType ? container : container.ownerDocument;
	}
	var previousDispatcher = ReactDOMSharedInternals.d;
	ReactDOMSharedInternals.d = {
		f: flushSyncWork,
		r: requestFormReset,
		D: prefetchDNS,
		C: preconnect,
		L: preload,
		m: preloadModule,
		X: preinitScript,
		S: preinitStyle,
		M: preinitModuleScript
	};
	function flushSyncWork() {
		var previousWasRendering = previousDispatcher.f(), wasRendering = flushSyncWork$1();
		return previousWasRendering || wasRendering;
	}
	function requestFormReset(form) {
		var formInst = getInstanceFromNode(form);
		null !== formInst && 5 === formInst.tag && "form" === formInst.type ? requestFormReset$1(formInst) : previousDispatcher.r(form);
	}
	var globalDocument = "undefined" === typeof document ? null : document;
	function preconnectAs(rel, href, crossOrigin) {
		var ownerDocument = globalDocument;
		if (ownerDocument && "string" === typeof href && href) {
			var limitedEscapedHref = escapeSelectorAttributeValueInsideDoubleQuotes(href);
			limitedEscapedHref = "link[rel=\"" + rel + "\"][href=\"" + limitedEscapedHref + "\"]";
			"string" === typeof crossOrigin && (limitedEscapedHref += "[crossorigin=\"" + crossOrigin + "\"]");
			preconnectsSet.has(limitedEscapedHref) || (preconnectsSet.add(limitedEscapedHref), rel = {
				rel,
				crossOrigin,
				href
			}, null === ownerDocument.querySelector(limitedEscapedHref) && (href = ownerDocument.createElement("link"), setInitialProperties(href, "link", rel), markNodeAsHoistable(href), ownerDocument.head.appendChild(href)));
		}
	}
	function prefetchDNS(href) {
		previousDispatcher.D(href);
		preconnectAs("dns-prefetch", href, null);
	}
	function preconnect(href, crossOrigin) {
		previousDispatcher.C(href, crossOrigin);
		preconnectAs("preconnect", href, crossOrigin);
	}
	function preload(href, as, options) {
		previousDispatcher.L(href, as, options);
		var ownerDocument = globalDocument;
		if (ownerDocument && href && as) {
			var preloadSelector = "link[rel=\"preload\"][as=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(as) + "\"]";
			"image" === as ? options && options.imageSrcSet ? (preloadSelector += "[imagesrcset=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(options.imageSrcSet) + "\"]", "string" === typeof options.imageSizes && (preloadSelector += "[imagesizes=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(options.imageSizes) + "\"]")) : preloadSelector += "[href=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(href) + "\"]" : preloadSelector += "[href=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(href) + "\"]";
			var key = preloadSelector;
			switch (as) {
				case "style":
					key = getStyleKey(href);
					break;
				case "script": key = getScriptKey(href);
			}
			if (!(preloadPropsMap.has(key) || (href = assign({
				rel: "preload",
				href: "image" === as && options && options.imageSrcSet ? void 0 : href,
				as
			}, options), preloadPropsMap.set(key, href), null !== ownerDocument.querySelector(preloadSelector) || "style" === as && ownerDocument.querySelector(getStylesheetSelectorFromKey(key)) || "script" === as && ownerDocument.querySelector(getScriptSelectorFromKey(key))))) {
				var instance = ownerDocument.createElement("link");
				setInitialProperties(instance, "link", href);
				"style" === as && (instance[internalLoadPendingKey] = !0, instance.onload = instance.onerror = function() {
					clearPendingLoadOnNode(instance);
				});
				markNodeAsHoistable(instance);
				ownerDocument.head.appendChild(instance);
			}
		}
	}
	function preloadModule(href, options) {
		previousDispatcher.m(href, options);
		var ownerDocument = globalDocument;
		if (ownerDocument && href) {
			var as = options && "string" === typeof options.as ? options.as : "script", preloadSelector = "link[rel=\"modulepreload\"][as=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(as) + "\"][href=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(href) + "\"]", key = preloadSelector;
			switch (as) {
				case "audioworklet":
				case "paintworklet":
				case "serviceworker":
				case "sharedworker":
				case "worker":
				case "script": key = getScriptKey(href);
			}
			if (!preloadPropsMap.has(key) && (href = assign({
				rel: "modulepreload",
				href
			}, options), preloadPropsMap.set(key, href), null === ownerDocument.querySelector(preloadSelector))) {
				switch (as) {
					case "audioworklet":
					case "paintworklet":
					case "serviceworker":
					case "sharedworker":
					case "worker":
					case "script": if (ownerDocument.querySelector(getScriptSelectorFromKey(key))) return;
				}
				as = ownerDocument.createElement("link");
				setInitialProperties(as, "link", href);
				markNodeAsHoistable(as);
				ownerDocument.head.appendChild(as);
			}
		}
	}
	function preinitStyle(href, precedence, options) {
		previousDispatcher.S(href, precedence, options);
		var ownerDocument = globalDocument;
		if (ownerDocument && href) {
			var styles = getResourcesFromRoot(ownerDocument).hoistableStyles, key = getStyleKey(href);
			precedence = precedence || "default";
			var resource = styles.get(key);
			if (!resource) {
				var state = {
					loading: 0,
					preload: null
				};
				if (resource = ownerDocument.querySelector(getStylesheetSelectorFromKey(key))) state.loading = 5;
				else {
					href = assign({
						rel: "stylesheet",
						href,
						"data-precedence": precedence
					}, options);
					(options = preloadPropsMap.get(key)) && adoptPreloadPropsForStylesheet(href, options);
					var link = resource = ownerDocument.createElement("link");
					markNodeAsHoistable(link);
					setInitialProperties(link, "link", href);
					link._p = new Promise(function(resolve, reject) {
						link.onload = resolve;
						link.onerror = reject;
					});
					link.addEventListener("load", function() {
						state.loading |= 1;
					});
					link.addEventListener("error", function() {
						state.loading |= 2;
					});
					state.loading |= 4;
					insertStylesheet(resource, precedence, ownerDocument);
				}
				resource = {
					type: "stylesheet",
					instance: resource,
					count: 1,
					state
				};
				styles.set(key, resource);
			}
		}
	}
	function preinitScript(src, options) {
		previousDispatcher.X(src, options);
		var ownerDocument = globalDocument;
		if (ownerDocument && src) {
			var scripts = getResourcesFromRoot(ownerDocument).hoistableScripts, key = getScriptKey(src), resource = scripts.get(key);
			resource || (resource = ownerDocument.querySelector(getScriptSelectorFromKey(key)), resource || (src = assign({
				src,
				async: !0
			}, options), (options = preloadPropsMap.get(key)) && adoptPreloadPropsForScript(src, options), resource = ownerDocument.createElement("script"), markNodeAsHoistable(resource), setInitialProperties(resource, "link", src), ownerDocument.head.appendChild(resource)), resource = {
				type: "script",
				instance: resource,
				count: 1,
				state: null
			}, scripts.set(key, resource));
		}
	}
	function preinitModuleScript(src, options) {
		previousDispatcher.M(src, options);
		var ownerDocument = globalDocument;
		if (ownerDocument && src) {
			var scripts = getResourcesFromRoot(ownerDocument).hoistableScripts, key = getScriptKey(src), resource = scripts.get(key);
			resource || (resource = ownerDocument.querySelector(getScriptSelectorFromKey(key)), resource || (src = assign({
				src,
				async: !0,
				type: "module"
			}, options), (options = preloadPropsMap.get(key)) && adoptPreloadPropsForScript(src, options), resource = ownerDocument.createElement("script"), markNodeAsHoistable(resource), setInitialProperties(resource, "link", src), ownerDocument.head.appendChild(resource)), resource = {
				type: "script",
				instance: resource,
				count: 1,
				state: null
			}, scripts.set(key, resource));
		}
	}
	function getResource(type, currentProps, pendingProps, currentResource) {
		var JSCompiler_inline_result = (JSCompiler_inline_result = rootInstanceStackCursor.current) ? getHoistableRoot(JSCompiler_inline_result) : null;
		if (!JSCompiler_inline_result) throw Error(formatProdErrorMessage(446));
		switch (type) {
			case "meta":
			case "title": return null;
			case "style": return "string" === typeof pendingProps.precedence && "string" === typeof pendingProps.href ? (pendingProps = getStyleKey(pendingProps.href), currentProps = getResourcesFromRoot(JSCompiler_inline_result).hoistableStyles, currentResource = currentProps.get(pendingProps), currentResource || (currentResource = {
				type: "style",
				instance: null,
				count: 0,
				state: null
			}, currentProps.set(pendingProps, currentResource)), currentResource) : {
				type: "void",
				instance: null,
				count: 0,
				state: null
			};
			case "link":
				if ("stylesheet" === pendingProps.rel && "string" === typeof pendingProps.href && "string" === typeof pendingProps.precedence) {
					type = getStyleKey(pendingProps.href);
					var styles$268 = getResourcesFromRoot(JSCompiler_inline_result).hoistableStyles, resource$269 = styles$268.get(type);
					resource$269 || (JSCompiler_inline_result = JSCompiler_inline_result.ownerDocument || JSCompiler_inline_result, resource$269 = {
						type: "stylesheet",
						instance: null,
						count: 0,
						state: {
							loading: 0,
							preload: null
						}
					}, styles$268.set(type, resource$269), (styles$268 = JSCompiler_inline_result.querySelector(getStylesheetSelectorFromKey(type))) ? styles$268._p || (resource$269.instance = styles$268, resource$269.state.loading = 5) : (styles$268 = preloadPropsMap.get(type), styles$268 || (styles$268 = {
						rel: "preload",
						as: "style",
						href: pendingProps.href,
						crossOrigin: pendingProps.crossOrigin,
						integrity: pendingProps.integrity,
						media: pendingProps.media,
						hrefLang: pendingProps.hrefLang,
						referrerPolicy: pendingProps.referrerPolicy
					}, preloadPropsMap.set(type, styles$268)), preloadStylesheet(JSCompiler_inline_result, type, styles$268, resource$269.state)));
					if (currentProps && null === currentResource) throw Error(formatProdErrorMessage(528, ""));
					return resource$269;
				}
				if (currentProps && null !== currentResource) throw Error(formatProdErrorMessage(529, ""));
				return null;
			case "script": return currentProps = pendingProps.async, pendingProps = pendingProps.src, "string" === typeof pendingProps && currentProps && "function" !== typeof currentProps && "symbol" !== typeof currentProps ? (pendingProps = getScriptKey(pendingProps), currentProps = getResourcesFromRoot(JSCompiler_inline_result).hoistableScripts, currentResource = currentProps.get(pendingProps), currentResource || (currentResource = {
				type: "script",
				instance: null,
				count: 0,
				state: null
			}, currentProps.set(pendingProps, currentResource)), currentResource) : {
				type: "void",
				instance: null,
				count: 0,
				state: null
			};
			default: throw Error(formatProdErrorMessage(444, type));
		}
	}
	function getStyleKey(href) {
		return "href=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(href) + "\"";
	}
	function getStylesheetSelectorFromKey(key) {
		return "link[rel=\"stylesheet\"][" + key + "]";
	}
	function stylesheetPropsFromRawProps(rawProps) {
		return assign({}, rawProps, {
			"data-precedence": rawProps.precedence,
			precedence: null
		});
	}
	function preloadStylesheet(ownerDocument, key, preloadProps, state) {
		if (key = ownerDocument.querySelector("link[rel=\"preload\"][as=\"style\"][" + key + "]")) {
			if (!0 !== key[internalLoadPendingKey]) {
				state.loading = 1;
				return;
			}
		} else key = ownerDocument.createElement("link"), key[internalLoadPendingKey] = !0, key.onload = key.onerror = clearPendingLoadOnNode.bind(null, key), setInitialProperties(key, "link", preloadProps), markNodeAsHoistable(key), ownerDocument.head.appendChild(key);
		state.preload = key;
		key.addEventListener("load", function() {
			return state.loading |= 1;
		});
		key.addEventListener("error", function() {
			return state.loading |= 2;
		});
	}
	function getScriptKey(src) {
		return "[src=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(src) + "\"]";
	}
	function getScriptSelectorFromKey(key) {
		return "script[async]" + key;
	}
	function acquireResource(hoistableRoot, resource, props) {
		resource.count++;
		if (null === resource.instance) switch (resource.type) {
			case "style":
				var instance = hoistableRoot.querySelector("style[data-href~=\"" + escapeSelectorAttributeValueInsideDoubleQuotes(props.href) + "\"]");
				if (instance) return resource.instance = instance, markNodeAsHoistable(instance), instance;
				var styleProps = assign({}, props, {
					"data-href": props.href,
					"data-precedence": props.precedence,
					href: null,
					precedence: null
				});
				instance = (hoistableRoot.ownerDocument || hoistableRoot).createElement("style");
				markNodeAsHoistable(instance);
				setInitialProperties(instance, "style", styleProps);
				insertStylesheet(instance, props.precedence, hoistableRoot);
				return resource.instance = instance;
			case "stylesheet":
				styleProps = getStyleKey(props.href);
				var instance$274 = hoistableRoot.querySelector(getStylesheetSelectorFromKey(styleProps));
				if (instance$274) return resource.state.loading |= 4, resource.instance = instance$274, markNodeAsHoistable(instance$274), instance$274;
				instance = stylesheetPropsFromRawProps(props);
				(styleProps = preloadPropsMap.get(styleProps)) && adoptPreloadPropsForStylesheet(instance, styleProps);
				instance$274 = (hoistableRoot.ownerDocument || hoistableRoot).createElement("link");
				markNodeAsHoistable(instance$274);
				var linkInstance = instance$274;
				linkInstance._p = new Promise(function(resolve, reject) {
					linkInstance.onload = resolve;
					linkInstance.onerror = reject;
				});
				setInitialProperties(instance$274, "link", instance);
				resource.state.loading |= 4;
				insertStylesheet(instance$274, props.precedence, hoistableRoot);
				return resource.instance = instance$274;
			case "script":
				instance$274 = getScriptKey(props.src);
				if (styleProps = hoistableRoot.querySelector(getScriptSelectorFromKey(instance$274))) return resource.instance = styleProps, markNodeAsHoistable(styleProps), styleProps;
				instance = props;
				if (styleProps = preloadPropsMap.get(instance$274)) instance = assign({}, props), adoptPreloadPropsForScript(instance, styleProps);
				hoistableRoot = hoistableRoot.ownerDocument || hoistableRoot;
				styleProps = hoistableRoot.createElement("script");
				markNodeAsHoistable(styleProps);
				setInitialProperties(styleProps, "link", instance);
				hoistableRoot.head.appendChild(styleProps);
				return resource.instance = styleProps;
			case "void": return null;
			default: throw Error(formatProdErrorMessage(443, resource.type));
		}
		else "stylesheet" === resource.type && 0 === (resource.state.loading & 4) && (instance = resource.instance, resource.state.loading |= 4, insertStylesheet(instance, props.precedence, hoistableRoot));
		return resource.instance;
	}
	function insertStylesheet(instance, precedence, root) {
		for (var nodes = root.querySelectorAll("link[rel=\"stylesheet\"][data-precedence],style[data-precedence]"), last = nodes.length ? nodes[nodes.length - 1] : null, prior = last, i = 0; i < nodes.length; i++) {
			var node = nodes[i];
			if (node.dataset.precedence === precedence) prior = node;
			else if (prior !== last) break;
		}
		prior ? prior.parentNode.insertBefore(instance, prior.nextSibling) : (precedence = 9 === root.nodeType ? root.head : root, precedence.insertBefore(instance, precedence.firstChild));
	}
	function adoptPreloadPropsForStylesheet(stylesheetProps, preloadProps) {
		stylesheetProps.crossOrigin ??= preloadProps.crossOrigin;
		stylesheetProps.referrerPolicy ??= preloadProps.referrerPolicy;
		stylesheetProps.title ??= preloadProps.title;
	}
	function adoptPreloadPropsForScript(scriptProps, preloadProps) {
		scriptProps.crossOrigin ??= preloadProps.crossOrigin;
		scriptProps.referrerPolicy ??= preloadProps.referrerPolicy;
		scriptProps.integrity ??= preloadProps.integrity;
	}
	var tagCaches = null;
	function getHydratableHoistableCache(type, keyAttribute, ownerDocument) {
		if (null === tagCaches) {
			var cache = /* @__PURE__ */ new Map();
			var caches = tagCaches = /* @__PURE__ */ new Map();
			caches.set(ownerDocument, cache);
		} else caches = tagCaches, cache = caches.get(ownerDocument), cache || (cache = /* @__PURE__ */ new Map(), caches.set(ownerDocument, cache));
		if (cache.has(type)) return cache;
		cache.set(type, null);
		ownerDocument = ownerDocument.getElementsByTagName(type);
		for (caches = 0; caches < ownerDocument.length; caches++) {
			var node = ownerDocument[caches];
			if (!(node[internalHoistableMarker] || node[internalInstanceKey] || "link" === type && "stylesheet" === node.getAttribute("rel")) && "http://www.w3.org/2000/svg" !== node.namespaceURI) {
				var nodeKey = node.getAttribute(keyAttribute) || "";
				nodeKey = type + nodeKey;
				var existing = cache.get(nodeKey);
				existing ? existing.push(node) : cache.set(nodeKey, [node]);
			}
		}
		return cache;
	}
	function mountHoistable(hoistableRoot, type, instance) {
		hoistableRoot = hoistableRoot.ownerDocument || hoistableRoot;
		hoistableRoot.head.insertBefore(instance, "title" === type ? hoistableRoot.querySelector("head > title") : null);
	}
	function isHostHoistableType(type, props, hostContext) {
		if (1 === hostContext || null != props.itemProp) return !1;
		switch (type) {
			case "meta":
			case "title": return !0;
			case "style":
				if ("string" !== typeof props.precedence || "string" !== typeof props.href || "" === props.href) break;
				return !0;
			case "link":
				if ("string" !== typeof props.rel || "string" !== typeof props.href || "" === props.href || props.onLoad || props.onError) break;
				switch (props.rel) {
					case "stylesheet": return type = props.disabled, "string" === typeof props.precedence && null == type;
					default: return !0;
				}
			case "script": if (props.async && "function" !== typeof props.async && "symbol" !== typeof props.async && !props.onLoad && !props.onError && props.src && "string" === typeof props.src) return !0;
		}
		return !1;
	}
	function maySuspendCommit(type, props) {
		return "img" === type && null != props.src && "" !== props.src && null == props.onLoad && "lazy" !== props.loading;
	}
	function preloadResource(resource) {
		return "stylesheet" === resource.type && 0 === (resource.state.loading & 3) ? !1 : !0;
	}
	function estimateImageBytes(instance) {
		return (instance.width || 100) * (instance.height || 100) * ("number" === typeof devicePixelRatio ? devicePixelRatio : 1) * .25;
	}
	function suspendInstance(state, instance) {
		"function" === typeof instance.decode && (state.imgCount++, instance.complete || (state.imgBytes += estimateImageBytes(instance), state.suspenseyImages.push(instance)), state = onUnsuspendImg.bind(state), instance.decode().then(state, state));
	}
	function suspendResource(state, hoistableRoot, resource, props) {
		if ("stylesheet" === resource.type && ("string" !== typeof props.media || !1 !== matchMedia(props.media).matches) && 0 === (resource.state.loading & 4)) {
			if (null === resource.instance) {
				var key = getStyleKey(props.href), instance = hoistableRoot.querySelector(getStylesheetSelectorFromKey(key));
				if (instance) {
					hoistableRoot = instance._p;
					null !== hoistableRoot && "object" === typeof hoistableRoot && "function" === typeof hoistableRoot.then && (state.count++, state = onUnsuspend.bind(state), hoistableRoot.then(state, state));
					resource.state.loading |= 4;
					resource.instance = instance;
					markNodeAsHoistable(instance);
					return;
				}
				instance = hoistableRoot.ownerDocument || hoistableRoot;
				props = stylesheetPropsFromRawProps(props);
				(key = preloadPropsMap.get(key)) && adoptPreloadPropsForStylesheet(props, key);
				instance = instance.createElement("link");
				markNodeAsHoistable(instance);
				var linkInstance = instance;
				linkInstance._p = new Promise(function(resolve, reject) {
					linkInstance.onload = resolve;
					linkInstance.onerror = reject;
				});
				setInitialProperties(instance, "link", props);
				resource.instance = instance;
			}
			null === state.stylesheets && (state.stylesheets = /* @__PURE__ */ new Map());
			state.stylesheets.set(resource, hoistableRoot);
			(hoistableRoot = resource.state.preload) && 0 === (resource.state.loading & 3) && (state.count++, resource = onUnsuspend.bind(state), hoistableRoot.addEventListener("load", resource), hoistableRoot.addEventListener("error", resource));
		}
	}
	var estimatedBytesWithinLimit = 0;
	function waitForCommitToBeReady(state, timeoutOffset) {
		state.stylesheets && 0 === state.count && insertSuspendedStylesheets(state, state.stylesheets);
		return 0 < state.count || 0 < state.imgCount ? function(commit) {
			var stylesheetTimer = setTimeout(function() {
				state.stylesheets && insertSuspendedStylesheets(state, state.stylesheets);
				if (state.unsuspend) {
					var unsuspend = state.unsuspend;
					state.unsuspend = null;
					unsuspend();
				}
			}, 6e4 + timeoutOffset);
			0 < state.imgBytes && 0 === estimatedBytesWithinLimit && (estimatedBytesWithinLimit = 62500 * estimateBandwidth());
			var imgTimer = setTimeout(function() {
				state.waitingForImages = !1;
				if (0 === state.count && (state.stylesheets && insertSuspendedStylesheets(state, state.stylesheets), state.unsuspend)) {
					var unsuspend = state.unsuspend;
					state.unsuspend = null;
					unsuspend();
				}
			}, (state.imgBytes > estimatedBytesWithinLimit ? 50 : 800) + timeoutOffset);
			state.unsuspend = commit;
			return function() {
				state.unsuspend = null;
				clearTimeout(stylesheetTimer);
				clearTimeout(imgTimer);
			};
		} : null;
	}
	function checkIfFullyUnsuspended(state) {
		if (0 === state.count && (0 === state.imgCount || !state.waitingForImages)) {
			if (state.stylesheets) insertSuspendedStylesheets(state, state.stylesheets);
			else if (state.unsuspend) {
				var unsuspend = state.unsuspend;
				state.unsuspend = null;
				unsuspend();
			}
		}
	}
	function onUnsuspend() {
		this.count--;
		checkIfFullyUnsuspended(this);
	}
	function onUnsuspendImg() {
		this.imgCount--;
		checkIfFullyUnsuspended(this);
	}
	var precedencesByRoot = null;
	function insertSuspendedStylesheets(state, resources) {
		state.stylesheets = null;
		null !== state.unsuspend && (state.count++, precedencesByRoot = /* @__PURE__ */ new Map(), resources.forEach(insertStylesheetIntoRoot, state), precedencesByRoot = null, onUnsuspend.call(state));
	}
	function insertStylesheetIntoRoot(root, resource) {
		if (!(resource.state.loading & 4)) {
			var precedences = precedencesByRoot.get(root);
			if (precedences) var last = precedences.get(null);
			else {
				precedences = /* @__PURE__ */ new Map();
				precedencesByRoot.set(root, precedences);
				for (var nodes = root.querySelectorAll("link[data-precedence],style[data-precedence]"), i = 0; i < nodes.length; i++) {
					var node = nodes[i];
					if ("LINK" === node.nodeName || "not all" !== node.getAttribute("media")) precedences.set(node.dataset.precedence, node), last = node;
				}
				last && precedences.set(null, last);
			}
			nodes = resource.instance;
			node = nodes.getAttribute("data-precedence");
			i = precedences.get(node) || last;
			i === last && precedences.set(null, nodes);
			precedences.set(node, nodes);
			this.count++;
			last = onUnsuspend.bind(this);
			nodes.addEventListener("load", last);
			nodes.addEventListener("error", last);
			i ? i.parentNode.insertBefore(nodes, i.nextSibling) : (root = 9 === root.nodeType ? root.head : root, root.insertBefore(nodes, root.firstChild));
			resource.state.loading |= 4;
		}
	}
	var HostTransitionContext = {
		$$typeof: REACT_CONTEXT_TYPE,
		Provider: null,
		Consumer: null,
		_currentValue: sharedNotPendingObject,
		_currentValue2: sharedNotPendingObject,
		_threadCount: 0
	};
	function FiberRootNode(containerInfo, tag, hydrate, identifierPrefix, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator, formState) {
		this.tag = 1;
		this.containerInfo = containerInfo;
		this.pingCache = this.current = this.pendingChildren = null;
		this.timeoutHandle = -1;
		this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null;
		this.callbackPriority = 0;
		this.expirationTimes = createLaneMap(-1);
		this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
		this.entanglements = createLaneMap(0);
		this.hiddenUpdates = createLaneMap(null);
		this.identifierPrefix = identifierPrefix;
		this.onUncaughtError = onUncaughtError;
		this.onCaughtError = onCaughtError;
		this.onRecoverableError = onRecoverableError;
		this.pooledCache = null;
		this.pooledCacheLanes = 0;
		this.formState = formState;
		this.transitionTypes = null;
		this.incompleteTransitions = /* @__PURE__ */ new Map();
	}
	function createFiberRoot(containerInfo, tag, hydrate, initialChildren, hydrationCallbacks, isStrictMode, identifierPrefix, formState, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator) {
		containerInfo = new FiberRootNode(containerInfo, tag, hydrate, identifierPrefix, onUncaughtError, onCaughtError, onRecoverableError, onDefaultTransitionIndicator, formState);
		tag = 1;
		!0 === isStrictMode && (tag |= 24);
		isStrictMode = createFiberImplClass(3, null, null, tag);
		containerInfo.current = isStrictMode;
		isStrictMode.stateNode = containerInfo;
		tag = createCache();
		tag.refCount++;
		containerInfo.pooledCache = tag;
		tag.refCount++;
		isStrictMode.memoizedState = {
			element: initialChildren,
			isDehydrated: hydrate,
			cache: tag
		};
		initializeUpdateQueue(isStrictMode);
		return containerInfo;
	}
	function getContextForSubtree(parentComponent) {
		if (!parentComponent) return emptyContextObject;
		parentComponent = emptyContextObject;
		return parentComponent;
	}
	function updateContainerImpl(rootFiber, lane, element, container, parentComponent, callback) {
		parentComponent = getContextForSubtree(parentComponent);
		null === container.context ? container.context = parentComponent : container.pendingContext = parentComponent;
		container = createUpdate(lane);
		container.payload = { element };
		callback = void 0 === callback ? null : callback;
		null !== callback && (container.callback = callback);
		element = enqueueUpdate(rootFiber, container, lane);
		null !== element && (scheduleUpdateOnFiber(element, rootFiber, lane), entangleTransitions(element, rootFiber, lane));
	}
	function markRetryLaneImpl(fiber, retryLane) {
		fiber = fiber.memoizedState;
		if (null !== fiber && null !== fiber.dehydrated) {
			var a = fiber.retryLane;
			fiber.retryLane = 0 !== a && a < retryLane ? a : retryLane;
		}
	}
	function markRetryLaneIfNotHydrated(fiber, retryLane) {
		markRetryLaneImpl(fiber, retryLane);
		(fiber = fiber.alternate) && markRetryLaneImpl(fiber, retryLane);
	}
	function attemptContinuousHydration(fiber) {
		if (13 === fiber.tag || 31 === fiber.tag) {
			var root = enqueueConcurrentRenderForLane(fiber, 67108864);
			null !== root && scheduleUpdateOnFiber(root, fiber, 67108864);
			markRetryLaneIfNotHydrated(fiber, 67108864);
		}
	}
	function attemptHydrationAtCurrentPriority(fiber) {
		if (13 === fiber.tag || 31 === fiber.tag) {
			var lane = requestUpdateLane();
			lane = getBumpedLaneForHydrationByLane(lane);
			var root = enqueueConcurrentRenderForLane(fiber, lane);
			null !== root && scheduleUpdateOnFiber(root, fiber, lane);
			markRetryLaneIfNotHydrated(fiber, lane);
		}
	}
	var _enabled = !0;
	function dispatchDiscreteEvent(domEventName, eventSystemFlags, container, nativeEvent) {
		var prevTransition = ReactSharedInternals.T;
		ReactSharedInternals.T = null;
		var previousPriority = ReactDOMSharedInternals.p;
		try {
			ReactDOMSharedInternals.p = 2, dispatchEvent(domEventName, eventSystemFlags, container, nativeEvent);
		} finally {
			ReactDOMSharedInternals.p = previousPriority, ReactSharedInternals.T = prevTransition;
		}
	}
	function dispatchContinuousEvent(domEventName, eventSystemFlags, container, nativeEvent) {
		var prevTransition = ReactSharedInternals.T;
		ReactSharedInternals.T = null;
		var previousPriority = ReactDOMSharedInternals.p;
		try {
			ReactDOMSharedInternals.p = 8, dispatchEvent(domEventName, eventSystemFlags, container, nativeEvent);
		} finally {
			ReactDOMSharedInternals.p = previousPriority, ReactSharedInternals.T = prevTransition;
		}
	}
	function dispatchEvent(domEventName, eventSystemFlags, targetContainer, nativeEvent) {
		if (_enabled) {
			var blockedOn = findInstanceBlockingEvent(nativeEvent);
			if (null === blockedOn) dispatchEventForPluginEventSystem(domEventName, eventSystemFlags, nativeEvent, return_targetInst, targetContainer), clearIfContinuousEvent(domEventName, nativeEvent);
			else if (queueIfContinuousEvent(blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent)) nativeEvent.stopPropagation();
			else if (clearIfContinuousEvent(domEventName, nativeEvent), eventSystemFlags & 4 && -1 < discreteReplayableEvents.indexOf(domEventName)) {
				for (; null !== blockedOn;) {
					var fiber = getInstanceFromNode(blockedOn);
					if (null !== fiber) switch (fiber.tag) {
						case 3:
							fiber = fiber.stateNode;
							if (fiber.current.memoizedState.isDehydrated) {
								var lanes = getHighestPriorityLanes(fiber.pendingLanes);
								if (0 !== lanes) {
									var root = fiber;
									root.pendingLanes |= 2;
									for (root.entangledLanes |= 2; lanes;) {
										var lane = 1 << 31 - clz32(lanes);
										root.entanglements[1] |= lane;
										lanes &= ~lane;
									}
									ensureRootIsScheduled(fiber);
									0 === (executionContext & 6) && (workInProgressRootRenderTargetTime = now() + 500, flushSyncWorkAcrossRoots_impl(0, !1));
								}
							}
							break;
						case 31:
						case 13: root = enqueueConcurrentRenderForLane(fiber, 2), null !== root && scheduleUpdateOnFiber(root, fiber, 2), flushSyncWork$1(), markRetryLaneIfNotHydrated(fiber, 2);
					}
					fiber = findInstanceBlockingEvent(nativeEvent);
					null === fiber && dispatchEventForPluginEventSystem(domEventName, eventSystemFlags, nativeEvent, return_targetInst, targetContainer);
					if (fiber === blockedOn) break;
					blockedOn = fiber;
				}
				null !== blockedOn && nativeEvent.stopPropagation();
			} else dispatchEventForPluginEventSystem(domEventName, eventSystemFlags, nativeEvent, null, targetContainer);
		}
	}
	function findInstanceBlockingEvent(nativeEvent) {
		nativeEvent = getEventTarget(nativeEvent);
		return findInstanceBlockingTarget(nativeEvent);
	}
	var return_targetInst = null;
	function findInstanceBlockingTarget(targetNode) {
		return_targetInst = null;
		targetNode = getClosestInstanceFromNode(targetNode);
		if (null !== targetNode) {
			var nearestMounted = getNearestMountedFiber(targetNode);
			if (null === nearestMounted) targetNode = null;
			else {
				var tag = nearestMounted.tag;
				if (13 === tag) {
					targetNode = getSuspenseInstanceFromFiber(nearestMounted);
					if (null !== targetNode) return targetNode;
					targetNode = null;
				} else if (31 === tag) {
					targetNode = getActivityInstanceFromFiber(nearestMounted);
					if (null !== targetNode) return targetNode;
					targetNode = null;
				} else if (3 === tag) {
					if (nearestMounted.stateNode.current.memoizedState.isDehydrated) return 3 === nearestMounted.tag ? nearestMounted.stateNode.containerInfo : null;
					targetNode = null;
				} else nearestMounted !== targetNode && (targetNode = null);
			}
		}
		return_targetInst = targetNode;
		return null;
	}
	function getEventPriority(domEventName) {
		switch (domEventName) {
			case "beforetoggle":
			case "cancel":
			case "click":
			case "close":
			case "contextmenu":
			case "copy":
			case "cut":
			case "auxclick":
			case "dblclick":
			case "dragend":
			case "dragstart":
			case "drop":
			case "focusin":
			case "focusout":
			case "input":
			case "invalid":
			case "keydown":
			case "keypress":
			case "keyup":
			case "mousedown":
			case "mouseup":
			case "paste":
			case "pause":
			case "play":
			case "pointercancel":
			case "pointerdown":
			case "pointerup":
			case "ratechange":
			case "reset":
			case "seeked":
			case "submit":
			case "toggle":
			case "touchcancel":
			case "touchend":
			case "touchstart":
			case "volumechange":
			case "change":
			case "selectionchange":
			case "textInput":
			case "compositionstart":
			case "compositionend":
			case "compositionupdate":
			case "beforeblur":
			case "afterblur":
			case "beforeinput":
			case "blur":
			case "fullscreenchange":
			case "fullscreenerror":
			case "focus":
			case "hashchange":
			case "popstate":
			case "select":
			case "selectstart": return 2;
			case "drag":
			case "dragenter":
			case "dragexit":
			case "dragleave":
			case "dragover":
			case "mousemove":
			case "mouseout":
			case "mouseover":
			case "pointermove":
			case "pointerout":
			case "pointerover":
			case "resize":
			case "scroll":
			case "touchmove":
			case "wheel":
			case "mouseenter":
			case "mouseleave":
			case "pointerenter":
			case "pointerleave": return 8;
			case "message": switch (getCurrentPriorityLevel()) {
				case ImmediatePriority: return 2;
				case UserBlockingPriority: return 8;
				case NormalPriority$1:
				case LowPriority: return 32;
				case IdlePriority: return 268435456;
				default: return 32;
			}
			default: return 32;
		}
	}
	var hasScheduledReplayAttempt = !1;
	var queuedFocus = null;
	var queuedDrag = null;
	var queuedMouse = null;
	var queuedPointers = /* @__PURE__ */ new Map();
	var queuedPointerCaptures = /* @__PURE__ */ new Map();
	var queuedExplicitHydrationTargets = [];
	var discreteReplayableEvents = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
	function clearIfContinuousEvent(domEventName, nativeEvent) {
		switch (domEventName) {
			case "focusin":
			case "focusout":
				queuedFocus = null;
				break;
			case "dragenter":
			case "dragleave":
				queuedDrag = null;
				break;
			case "mouseover":
			case "mouseout":
				queuedMouse = null;
				break;
			case "pointerover":
			case "pointerout":
				queuedPointers.delete(nativeEvent.pointerId);
				break;
			case "gotpointercapture":
			case "lostpointercapture": queuedPointerCaptures.delete(nativeEvent.pointerId);
		}
	}
	function accumulateOrCreateContinuousQueuedReplayableEvent(existingQueuedEvent, blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent) {
		if (null === existingQueuedEvent || existingQueuedEvent.nativeEvent !== nativeEvent) return existingQueuedEvent = {
			blockedOn,
			domEventName,
			eventSystemFlags,
			nativeEvent,
			targetContainers: [targetContainer]
		}, null !== blockedOn && (blockedOn = getInstanceFromNode(blockedOn), null !== blockedOn && attemptContinuousHydration(blockedOn)), existingQueuedEvent;
		existingQueuedEvent.eventSystemFlags |= eventSystemFlags;
		blockedOn = existingQueuedEvent.targetContainers;
		null !== targetContainer && -1 === blockedOn.indexOf(targetContainer) && blockedOn.push(targetContainer);
		return existingQueuedEvent;
	}
	function queueIfContinuousEvent(blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent) {
		switch (domEventName) {
			case "focusin": return queuedFocus = accumulateOrCreateContinuousQueuedReplayableEvent(queuedFocus, blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent), !0;
			case "dragenter": return queuedDrag = accumulateOrCreateContinuousQueuedReplayableEvent(queuedDrag, blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent), !0;
			case "mouseover": return queuedMouse = accumulateOrCreateContinuousQueuedReplayableEvent(queuedMouse, blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent), !0;
			case "pointerover":
				var pointerId = nativeEvent.pointerId;
				queuedPointers.set(pointerId, accumulateOrCreateContinuousQueuedReplayableEvent(queuedPointers.get(pointerId) || null, blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent));
				return !0;
			case "gotpointercapture": return pointerId = nativeEvent.pointerId, queuedPointerCaptures.set(pointerId, accumulateOrCreateContinuousQueuedReplayableEvent(queuedPointerCaptures.get(pointerId) || null, blockedOn, domEventName, eventSystemFlags, targetContainer, nativeEvent)), !0;
		}
		return !1;
	}
	function attemptExplicitHydrationTarget(queuedTarget) {
		var targetInst = getClosestInstanceFromNode(queuedTarget.target);
		if (null !== targetInst) {
			var nearestMounted = getNearestMountedFiber(targetInst);
			if (null !== nearestMounted) {
				if (targetInst = nearestMounted.tag, 13 === targetInst) {
					if (targetInst = getSuspenseInstanceFromFiber(nearestMounted), null !== targetInst) {
						queuedTarget.blockedOn = targetInst;
						runWithPriority(queuedTarget.priority, function() {
							attemptHydrationAtCurrentPriority(nearestMounted);
						});
						return;
					}
				} else if (31 === targetInst) {
					if (targetInst = getActivityInstanceFromFiber(nearestMounted), null !== targetInst) {
						queuedTarget.blockedOn = targetInst;
						runWithPriority(queuedTarget.priority, function() {
							attemptHydrationAtCurrentPriority(nearestMounted);
						});
						return;
					}
				} else if (3 === targetInst && nearestMounted.stateNode.current.memoizedState.isDehydrated) {
					queuedTarget.blockedOn = 3 === nearestMounted.tag ? nearestMounted.stateNode.containerInfo : null;
					return;
				}
			}
		}
		queuedTarget.blockedOn = null;
	}
	function attemptReplayContinuousQueuedEvent(queuedEvent) {
		if (null !== queuedEvent.blockedOn) return !1;
		for (var targetContainers = queuedEvent.targetContainers; 0 < targetContainers.length;) {
			var nextBlockedOn = findInstanceBlockingEvent(queuedEvent.nativeEvent);
			if (null === nextBlockedOn) {
				nextBlockedOn = queuedEvent.nativeEvent;
				var nativeEventClone = new nextBlockedOn.constructor(nextBlockedOn.type, nextBlockedOn);
				currentReplayingEvent = nativeEventClone;
				nextBlockedOn.target.dispatchEvent(nativeEventClone);
				currentReplayingEvent = null;
			} else return targetContainers = getInstanceFromNode(nextBlockedOn), null !== targetContainers && attemptContinuousHydration(targetContainers), queuedEvent.blockedOn = nextBlockedOn, !1;
			targetContainers.shift();
		}
		return !0;
	}
	function attemptReplayContinuousQueuedEventInMap(queuedEvent, key, map) {
		attemptReplayContinuousQueuedEvent(queuedEvent) && map.delete(key);
	}
	function replayUnblockedEvents() {
		hasScheduledReplayAttempt = !1;
		null !== queuedFocus && attemptReplayContinuousQueuedEvent(queuedFocus) && (queuedFocus = null);
		null !== queuedDrag && attemptReplayContinuousQueuedEvent(queuedDrag) && (queuedDrag = null);
		null !== queuedMouse && attemptReplayContinuousQueuedEvent(queuedMouse) && (queuedMouse = null);
		queuedPointers.forEach(attemptReplayContinuousQueuedEventInMap);
		queuedPointerCaptures.forEach(attemptReplayContinuousQueuedEventInMap);
	}
	function scheduleCallbackIfUnblocked(queuedEvent, unblocked) {
		queuedEvent.blockedOn === unblocked && (queuedEvent.blockedOn = null, hasScheduledReplayAttempt || (hasScheduledReplayAttempt = !0, Scheduler.unstable_scheduleCallback(Scheduler.unstable_NormalPriority, replayUnblockedEvents)));
	}
	var lastScheduledReplayQueue = null;
	function scheduleReplayQueueIfNeeded(formReplayingQueue) {
		lastScheduledReplayQueue !== formReplayingQueue && (lastScheduledReplayQueue = formReplayingQueue, Scheduler.unstable_scheduleCallback(Scheduler.unstable_NormalPriority, function() {
			lastScheduledReplayQueue === formReplayingQueue && (lastScheduledReplayQueue = null);
			for (var i = 0; i < formReplayingQueue.length; i += 3) {
				var form = formReplayingQueue[i], submitterOrAction = formReplayingQueue[i + 1], formData = formReplayingQueue[i + 2];
				if ("function" !== typeof submitterOrAction) if (null === findInstanceBlockingTarget(submitterOrAction || form)) continue;
				else break;
				var formInst = getInstanceFromNode(form);
				null !== formInst && (formReplayingQueue.splice(i, 3), i -= 3, startHostTransition(formInst, {
					pending: !0,
					data: formData,
					method: form.method,
					action: submitterOrAction
				}, submitterOrAction, formData));
			}
		}));
	}
	function retryIfBlockedOn(unblocked) {
		function unblock(queuedEvent) {
			return scheduleCallbackIfUnblocked(queuedEvent, unblocked);
		}
		null !== queuedFocus && scheduleCallbackIfUnblocked(queuedFocus, unblocked);
		null !== queuedDrag && scheduleCallbackIfUnblocked(queuedDrag, unblocked);
		null !== queuedMouse && scheduleCallbackIfUnblocked(queuedMouse, unblocked);
		queuedPointers.forEach(unblock);
		queuedPointerCaptures.forEach(unblock);
		for (var i = 0; i < queuedExplicitHydrationTargets.length; i++) {
			var queuedTarget = queuedExplicitHydrationTargets[i];
			queuedTarget.blockedOn === unblocked && (queuedTarget.blockedOn = null);
		}
		for (; 0 < queuedExplicitHydrationTargets.length && (i = queuedExplicitHydrationTargets[0], null === i.blockedOn);) attemptExplicitHydrationTarget(i), null === i.blockedOn && queuedExplicitHydrationTargets.shift();
		i = (unblocked.ownerDocument || unblocked).$$reactFormReplay;
		if (null != i) for (queuedTarget = 0; queuedTarget < i.length; queuedTarget += 3) {
			var form = i[queuedTarget], submitterOrAction = i[queuedTarget + 1], formProps = form[internalPropsKey] || null;
			if ("function" === typeof submitterOrAction) formProps || scheduleReplayQueueIfNeeded(i);
			else if (formProps) {
				var action = null;
				if (submitterOrAction && submitterOrAction.hasAttribute("formAction")) {
					if (form = submitterOrAction, formProps = submitterOrAction[internalPropsKey] || null) action = formProps.formAction;
					else if (null !== findInstanceBlockingTarget(form)) continue;
				} else action = formProps.action;
				"function" === typeof action ? i[queuedTarget + 1] = action : (i.splice(queuedTarget, 3), queuedTarget -= 3);
				scheduleReplayQueueIfNeeded(i);
			}
		}
	}
	function defaultOnDefaultTransitionIndicator() {
		function handleNavigate(event) {
			event.canIntercept && "react-transition" === event.info && event.intercept({
				handler: function() {
					return new Promise(function(resolve) {
						return pendingResolve = resolve;
					});
				},
				focusReset: "manual",
				scroll: "manual"
			});
		}
		function handleNavigateComplete() {
			null !== pendingResolve && (pendingResolve(), pendingResolve = null);
			isCancelled || setTimeout(startFakeNavigation, 20);
		}
		function startFakeNavigation() {
			if (!isCancelled && !navigation.transition) {
				var currentEntry = navigation.currentEntry;
				currentEntry && null != currentEntry.url && navigation.navigate(currentEntry.url, {
					state: currentEntry.getState(),
					info: "react-transition",
					history: "replace"
				});
			}
		}
		if ("object" === typeof navigation) {
			var isCancelled = !1, pendingResolve = null;
			navigation.addEventListener("navigate", handleNavigate);
			navigation.addEventListener("navigatesuccess", handleNavigateComplete);
			navigation.addEventListener("navigateerror", handleNavigateComplete);
			setTimeout(startFakeNavigation, 100);
			return function() {
				isCancelled = !0;
				navigation.removeEventListener("navigate", handleNavigate);
				navigation.removeEventListener("navigatesuccess", handleNavigateComplete);
				navigation.removeEventListener("navigateerror", handleNavigateComplete);
				null !== pendingResolve && (pendingResolve(), pendingResolve = null);
			};
		}
	}
	function ReactDOMRoot(internalRoot) {
		this._internalRoot = internalRoot;
	}
	ReactDOMHydrationRoot.prototype.render = ReactDOMRoot.prototype.render = function(children) {
		var root = this._internalRoot;
		if (null === root) throw Error(formatProdErrorMessage(409));
		var current = root.current;
		updateContainerImpl(current, requestUpdateLane(), children, root, null, null);
	};
	ReactDOMHydrationRoot.prototype.unmount = ReactDOMRoot.prototype.unmount = function() {
		var root = this._internalRoot;
		if (null !== root) {
			this._internalRoot = null;
			var container = root.containerInfo;
			updateContainerImpl(root.current, 2, null, root, null, null);
			flushSyncWork$1();
			container[internalContainerInstanceKey] = null;
		}
	};
	function ReactDOMHydrationRoot(internalRoot) {
		this._internalRoot = internalRoot;
	}
	ReactDOMHydrationRoot.prototype.unstable_scheduleHydration = function(target) {
		if (target) {
			var updatePriority = resolveUpdatePriority();
			target = {
				blockedOn: null,
				target,
				priority: updatePriority
			};
			for (var i = 0; i < queuedExplicitHydrationTargets.length && 0 !== updatePriority && updatePriority < queuedExplicitHydrationTargets[i].priority; i++);
			queuedExplicitHydrationTargets.splice(i, 0, target);
			0 === i && attemptExplicitHydrationTarget(target);
		}
	};
	var isomorphicReactPackageVersion$jscomp$inline_2043 = React.version;
	if ("19.3.1" !== isomorphicReactPackageVersion$jscomp$inline_2043) throw Error(formatProdErrorMessage(527, isomorphicReactPackageVersion$jscomp$inline_2043, "19.3.1"));
	ReactDOMSharedInternals.findDOMNode = function(componentOrElement) {
		var fiber = componentOrElement._reactInternals;
		if (void 0 === fiber) {
			if ("function" === typeof componentOrElement.render) throw Error(formatProdErrorMessage(188));
			componentOrElement = Object.keys(componentOrElement).join(",");
			throw Error(formatProdErrorMessage(268, componentOrElement));
		}
		componentOrElement = findCurrentFiberUsingSlowPath(fiber);
		componentOrElement = null !== componentOrElement ? findCurrentHostFiberImpl(componentOrElement) : null;
		componentOrElement = null === componentOrElement ? null : componentOrElement.stateNode;
		return componentOrElement;
	};
	var internals$jscomp$inline_2586 = {
		bundleType: 0,
		version: "19.3.1",
		rendererPackageName: "react-dom",
		currentDispatcherRef: ReactSharedInternals,
		reconcilerVersion: "19.3.1"
	};
	if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
		var hook$jscomp$inline_2587 = __REACT_DEVTOOLS_GLOBAL_HOOK__;
		if (!hook$jscomp$inline_2587.isDisabled && hook$jscomp$inline_2587.supportsFiber) try {
			rendererID = hook$jscomp$inline_2587.inject(internals$jscomp$inline_2586), injectedHook = hook$jscomp$inline_2587;
		} catch (err) {}
	}
	exports.createRoot = function(container, options) {
		if (!isValidContainer(container)) throw Error(formatProdErrorMessage(299));
		var isStrictMode = !1, identifierPrefix = "", onUncaughtError = defaultOnUncaughtError, onCaughtError = defaultOnCaughtError, onRecoverableError = defaultOnRecoverableError;
		null !== options && void 0 !== options && (!0 === options.unstable_strictMode && (isStrictMode = !0), void 0 !== options.identifierPrefix && (identifierPrefix = options.identifierPrefix), void 0 !== options.onUncaughtError && (onUncaughtError = options.onUncaughtError), void 0 !== options.onCaughtError && (onCaughtError = options.onCaughtError), void 0 !== options.onRecoverableError && (onRecoverableError = options.onRecoverableError));
		options = createFiberRoot(container, 1, !1, null, null, isStrictMode, identifierPrefix, null, onUncaughtError, onCaughtError, onRecoverableError, defaultOnDefaultTransitionIndicator);
		container[internalContainerInstanceKey] = options.current;
		listenToAllSupportedEvents(container);
		return new ReactDOMRoot(options);
	};
}));
// node_modules/react-dom/client.js
var require_client = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function checkDCE() {
		if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") return;
		try {
			__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
		} catch (err) {
			console.error(err);
		}
	}
	checkDCE();
	module.exports = require_react_dom_client_production();
}));
// node_modules/lucide-react/dist/esm/shared/src/utils.js
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
var toCamelCase = (string) => string.replace(/^([A-Z])|[\s-_]+(\w)/g, (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase());
var toPascalCase = (string) => {
	const camelCase = toCamelCase(string);
	return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
var mergeClasses = (...classes) => classes.filter((className, index, array) => {
	return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
var hasA11yProp = (props) => {
	for (const prop in props) if (prop.startsWith("aria-") || prop === "role" || prop === "title") return true;
};
// node_modules/lucide-react/dist/esm/defaultAttributes.js
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var defaultAttributes = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
};
// node_modules/lucide-react/dist/esm/Icon.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Icon = (0, import_react.forwardRef)(({ color = "currentColor", size = 24, strokeWidth = 2, absoluteStrokeWidth, className = "", children, iconNode, ...rest }, ref) => (0, import_react.createElement)("svg", {
	ref,
	...defaultAttributes,
	width: size,
	height: size,
	stroke: color,
	strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
	className: mergeClasses("lucide", className),
	...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
	...rest
}, [...iconNode.map(([tag, attrs]) => (0, import_react.createElement)(tag, attrs)), ...Array.isArray(children) ? children : [children]]));
// node_modules/lucide-react/dist/esm/createLucideIcon.js
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var createLucideIcon = (iconName, iconNode) => {
	const Component = (0, import_react.forwardRef)(({ className, ...props }, ref) => (0, import_react.createElement)(Icon, {
		ref,
		iconNode,
		className: mergeClasses(`lucide-${toKebabCase(toPascalCase(iconName))}`, `lucide-${iconName}`, className),
		...props
	}));
	Component.displayName = toPascalCase(iconName);
	return Component;
};
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ArrowLeft = createLucideIcon("arrow-left", [["path", {
	d: "m12 19-7-7 7-7",
	key: "1l729n"
}], ["path", {
	d: "M19 12H5",
	key: "x3x0zl"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ArrowRight = createLucideIcon("arrow-right", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "m12 5 7 7-7 7",
	key: "xquz4c"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Award = createLucideIcon("award", [["path", {
	d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
	key: "1yiouv"
}], ["circle", {
	cx: "12",
	cy: "8",
	r: "6",
	key: "1vp47v"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var BookOpen = createLucideIcon("book-open", [["path", {
	d: "M12 7v14",
	key: "1akyts"
}], ["path", {
	d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
	key: "ruj8y"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Check = createLucideIcon("check", [["path", {
	d: "M20 6 9 17l-5-5",
	key: "1gmf2c"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var CircleQuestionMark = createLucideIcon("circle-question-mark", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
		key: "1u773s"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Clock = createLucideIcon("clock", [["path", {
	d: "M12 6v6l4 2",
	key: "mmk7yg"
}], ["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Coins = createLucideIcon("coins", [
	["circle", {
		cx: "8",
		cy: "8",
		r: "6",
		key: "3yglwk"
	}],
	["path", {
		d: "M18.09 10.37A6 6 0 1 1 10.34 18",
		key: "t5s6rm"
	}],
	["path", {
		d: "M7 6h1v4",
		key: "1obek4"
	}],
	["path", {
		d: "m16.71 13.88.7.71-2.82 2.82",
		key: "1rbuyh"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Crosshair = createLucideIcon("crosshair", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["line", {
		x1: "22",
		x2: "18",
		y1: "12",
		y2: "12",
		key: "l9bcsi"
	}],
	["line", {
		x1: "6",
		x2: "2",
		y1: "12",
		y2: "12",
		key: "13hhkx"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "6",
		y2: "2",
		key: "10w3f3"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "22",
		y2: "18",
		key: "15g9kq"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Crown = createLucideIcon("crown", [["path", {
	d: "M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",
	key: "1vdc57"
}], ["path", {
	d: "M5 21h14",
	key: "11awu3"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Download = createLucideIcon("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Gem = createLucideIcon("gem", [
	["path", {
		d: "M10.5 3 8 9l4 13 4-13-2.5-6",
		key: "b3dvk1"
	}],
	["path", {
		d: "M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z",
		key: "7w4byz"
	}],
	["path", {
		d: "M2 9h20",
		key: "16fsjt"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var House = createLucideIcon("house", [["path", {
	d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",
	key: "5wwlr5"
}], ["path", {
	d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
	key: "r6nss1"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Lock = createLucideIcon("lock", [["rect", {
	width: "18",
	height: "11",
	x: "3",
	y: "11",
	rx: "2",
	ry: "2",
	key: "1w4ew1"
}], ["path", {
	d: "M7 11V7a5 5 0 0 1 10 0v4",
	key: "fwvmzm"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Pause = createLucideIcon("pause", [["rect", {
	x: "14",
	y: "3",
	width: "5",
	height: "18",
	rx: "1",
	key: "kaeet6"
}], ["rect", {
	x: "5",
	y: "3",
	width: "5",
	height: "18",
	rx: "1",
	key: "1wsw3u"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Play = createLucideIcon("play", [["path", {
	d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
	key: "10ikf1"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Repeat = createLucideIcon("repeat", [
	["path", {
		d: "m17 2 4 4-4 4",
		key: "nntrym"
	}],
	["path", {
		d: "M3 11v-1a4 4 0 0 1 4-4h14",
		key: "84bu3i"
	}],
	["path", {
		d: "m7 22-4-4 4-4",
		key: "1wqhfi"
	}],
	["path", {
		d: "M21 13v1a4 4 0 0 1-4 4H3",
		key: "1rx37r"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var RotateCcw = createLucideIcon("rotate-ccw", [["path", {
	d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
	key: "1357e3"
}], ["path", {
	d: "M3 3v5h5",
	key: "1xhq8a"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Settings = createLucideIcon("settings", [["path", {
	d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
	key: "1i5ecw"
}], ["circle", {
	cx: "12",
	cy: "12",
	r: "3",
	key: "1v7zrd"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ShieldCheck = createLucideIcon("shield-check", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Shield = createLucideIcon("shield", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Shirt = createLucideIcon("shirt", [["path", {
	d: "M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z",
	key: "1wgbhj"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Sparkles = createLucideIcon("sparkles", [
	["path", {
		d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
		key: "1s2grr"
	}],
	["path", {
		d: "M20 2v4",
		key: "1rf3ol"
	}],
	["path", {
		d: "M22 4h-4",
		key: "gwowj6"
	}],
	["circle", {
		cx: "4",
		cy: "20",
		r: "2",
		key: "6kqj1y"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Star = createLucideIcon("star", [["path", {
	d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
	key: "r04s7s"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Trophy = createLucideIcon("trophy", [
	["path", {
		d: "M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978",
		key: "1n3hpd"
	}],
	["path", {
		d: "M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978",
		key: "rfe1zi"
	}],
	["path", {
		d: "M18 9h1.5a1 1 0 0 0 0-5H18",
		key: "7xy6bh"
	}],
	["path", {
		d: "M4 22h16",
		key: "57wxv0"
	}],
	["path", {
		d: "M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z",
		key: "1mhfuq"
	}],
	["path", {
		d: "M6 9H4.5a1 1 0 0 1 0-5H6",
		key: "tex48p"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var User = createLucideIcon("user", [["path", {
	d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
	key: "975kel"
}], ["circle", {
	cx: "12",
	cy: "7",
	r: "4",
	key: "17ys0d"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Video = createLucideIcon("video", [["path", {
	d: "m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",
	key: "ftymec"
}], ["rect", {
	x: "2",
	y: "6",
	width: "14",
	height: "12",
	rx: "2",
	key: "158x01"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Volume2 = createLucideIcon("volume-2", [
	["path", {
		d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
		key: "uqj9uw"
	}],
	["path", {
		d: "M16 9a5 5 0 0 1 0 6",
		key: "1q6k2b"
	}],
	["path", {
		d: "M19.364 18.364a9 9 0 0 0 0-12.728",
		key: "ijwkga"
	}]
]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var X = createLucideIcon("x", [["path", {
	d: "M18 6 6 18",
	key: "1bl5f8"
}], ["path", {
	d: "m6 6 12 12",
	key: "d8bk6v"
}]]);
/**
* @license lucide-react v0.546.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Zap = createLucideIcon("zap", [["path", {
	d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
	key: "1xq2db"
}]]);
// src/services/admobBridge.ts
var import_client = require_client();
var INTERSTITIAL_COOLDOWN_MS = 18e4;
var LEVELS_PER_INTERSTITIAL = 3;
var BANNER_SCREENS = /* @__PURE__ */ new Set([
	"MAIN_MENU",
	"WORLDS",
	"LEVELS",
	"SETTINGS",
	"UPGRADES",
	"COSTUMES",
	"PROFILE",
	"ACHIEVEMENTS",
	"LEVEL_COMPLETE",
	"GAME_OVER",
	"BOSS_VICTORY"
]);
var NATIVE_AD_SCREENS = /* @__PURE__ */ new Set([
	"MAIN_MENU",
	"WORLDS",
	"UPGRADES",
	"COSTUMES",
	"ACHIEVEMENTS",
	"PROFILE"
]);
var WebAndNativeAdMobManager = class {
	constructor() {
		this.levelsCompletedSinceAd = 0;
		this.lastInterstitialTime = 0;
		this.lastInterstitialRunToken = "";
		this.isFullscreenShowing = false;
		this.pendingRewardCallback = null;
		this.activeRewardPlacement = null;
		this.nativeAdListeners = /* @__PURE__ */ new Set();
		this.fullscreenListeners = /* @__PURE__ */ new Set();
		this.onPreviewModalRequest = null;
		if (typeof window !== "undefined") {
			window.onNativeRewardDismissed = (_placement, earned) => {
				this.isFullscreenShowing = false;
				this.notifyFullscreen(false);
				const cb = this.pendingRewardCallback;
				this.pendingRewardCallback = null;
				this.activeRewardPlacement = null;
				cb?.(Boolean(earned));
			};
			window.onNativeFullscreenAdWillShow = () => {
				this.isFullscreenShowing = true;
				this.notifyFullscreen(true);
			};
			window.onNativeFullscreenAdDismissed = () => {
				this.isFullscreenShowing = false;
				this.notifyFullscreen(false);
			};
			window.onNativeAdAvailabilityChanged = (loaded) => {
				this.nativeAdListeners.forEach((fn) => fn(Boolean(loaded)));
			};
		}
	}
	registerPreviewModalHandler(handler) {
		this.onPreviewModalRequest = handler;
	}
	subscribeNativeAvailability(listener) {
		this.nativeAdListeners.add(listener);
		return () => this.nativeAdListeners.delete(listener);
	}
	subscribeFullscreenLifecycle(listener) {
		this.fullscreenListeners.add(listener);
		return () => this.fullscreenListeners.delete(listener);
	}
	notifyFullscreen(showing) {
		this.fullscreenListeners.forEach((fn) => fn(showing));
	}
	isNativeAndroid() {
		return Boolean(window.ShadowNinjaNative?.isRunningNative?.());
	}
	isDebugInspectorAvailable() {
		if (this.isNativeAndroid()) return Boolean(window.ShadowNinjaNative?.isDebugBuild?.());
		return Boolean(false);
	}
	getDebugStatus() {
		if (!this.isDebugInspectorAvailable()) return null;
		if (this.isNativeAndroid() && window.ShadowNinjaNative?.getAdMobStatusJson) try {
			const raw = window.ShadowNinjaNative.getAdMobStatusJson();
			if (raw && raw !== "{}") return JSON.parse(raw);
		} catch {}
		return {
			mode: "WEB_DEV_BRIDGE",
			sdkInitialized: false,
			consentStatus: "WEB_PREVIEW",
			canRequestAds: true,
			privacyOptionsRequired: false,
			appOpenState: "NATIVE_APK_ONLY",
			bannerState: "NATIVE_APK_ONLY",
			interstitialState: "WEB_DEV_TEST",
			nativeState: "NATIVE_APK_ONLY",
			rewardedState: "WEB_DEV_TEST",
			lastLoadError: "None (Google Mobile Ads SDK runs inside Android APK)"
		};
	}
	syncScreenState(screen, inBoss = false) {
		const inGameplay = screen === "PLAYING" || screen === "PAUSED";
		const showBanner = BANNER_SCREENS.has(screen) && !inGameplay;
		const showNativeScreen = NATIVE_AD_SCREENS.has(screen) && !inGameplay;
		if (this.isNativeAndroid()) {
			window.ShadowNinjaNative?.updateScreenState?.(screen, inGameplay, inBoss);
			if (showBanner) window.ShadowNinjaNative?.showBanner?.(screen);
			else window.ShadowNinjaNative?.hideBanner?.();
			if (!showNativeScreen) window.ShadowNinjaNative?.hideNativeAdSlot?.();
		}
	}
	shouldShowBannerOnScreen(screen) {
		return BANNER_SCREENS.has(screen);
	}
	shouldBindNativeOnScreen(screen) {
		return NATIVE_AD_SCREENS.has(screen);
	}
	isNativeAdLoaded() {
		if (!this.isNativeAndroid()) return false;
		return Boolean(window.ShadowNinjaNative?.isNativeLoaded?.());
	}
	bindNativeOverlayRect(rect) {
		if (!this.isNativeAndroid()) return;
		const vw = window.innerWidth || 1;
		const vh = window.innerHeight || 1;
		const xRatio = Math.max(0, Math.min(1, rect.left / vw));
		const yRatio = Math.max(0, Math.min(1, rect.top / vh));
		const wRatio = Math.max(0, Math.min(1, rect.width / vw));
		const hRatio = Math.max(0, Math.min(1, rect.height / vh));
		window.ShadowNinjaNative?.bindNativeAdSlot?.(xRatio, yRatio, wRatio, hRatio);
	}
	hideNativeOverlay() {
		if (this.isNativeAndroid()) window.ShadowNinjaNative?.hideNativeAdSlot?.();
	}
	notifyLevelCompleted(levelId, runCounter, isBoss) {
		this.levelsCompletedSinceAd++;
		if (isBoss) return false;
		if (this.isFullscreenShowing) return false;
		if (this.levelsCompletedSinceAd < LEVELS_PER_INTERSTITIAL) return false;
		const runToken = `${levelId}:${runCounter}`;
		if (runToken === this.lastInterstitialRunToken) return false;
		const now = Date.now();
		if (now - this.lastInterstitialTime < INTERSTITIAL_COOLDOWN_MS) return false;
		this.levelsCompletedSinceAd = 0;
		this.lastInterstitialTime = now;
		this.lastInterstitialRunToken = runToken;
		if (this.isNativeAndroid()) return Boolean(window.ShadowNinjaNative?.showInterstitialIfReady?.(runToken));
		return false;
	}
	isRewardedReady() {
		if (this.isNativeAndroid()) return Boolean(window.ShadowNinjaNative?.isRewardedReady?.());
		return Boolean(false);
	}
	/**
	* Always presents a clear opt-in confirmation sheet (reward details + Watch Ad / Cancel)
	* before invoking native RewardedAd or failing safely when unavailable.
	*/
	requestRewardedOptIn(placement, onResult) {
		if (this.isFullscreenShowing) {
			onResult(false);
			return;
		}
		if (!this.onPreviewModalRequest) {
			onResult(false);
			return;
		}
		this.onPreviewModalRequest("rewardOptIn", placement, (confirmed) => {
			if (!confirmed) {
				onResult(false);
				return;
			}
			this.executeRewardedAd(placement, onResult);
		});
	}
	executeRewardedAd(placement, onResult) {
		if (this.isFullscreenShowing) {
			onResult(false);
			return;
		}
		if (this.isNativeAndroid() && window.ShadowNinjaNative?.showRewarded) {
			this.isFullscreenShowing = true;
			this.activeRewardPlacement = placement;
			this.pendingRewardCallback = onResult;
			this.notifyFullscreen(true);
			try {
				window.ShadowNinjaNative.showRewarded(placement);
			} catch {
				this.isFullscreenShowing = false;
				this.pendingRewardCallback = null;
				this.activeRewardPlacement = null;
				this.notifyFullscreen(false);
				onResult(false);
			}
			return;
		}
		onResult(false);
	}
	triggerAppOpenIfAppropriate(currentScreen) {
		if (currentScreen === "PLAYING" || currentScreen === "PAUSED" || this.isFullscreenShowing) return;
		if (this.isNativeAndroid()) window.ShadowNinjaNative?.showAppOpenIfReady?.();
	}
	isPrivacyOptionsRequired() {
		if (!this.isNativeAndroid()) return false;
		return Boolean(window.ShadowNinjaNative?.isPrivacyOptionsRequired?.());
	}
	openPrivacyConsent() {
		if (this.isNativeAndroid()) window.ShadowNinjaNative?.requestConsentUpdate?.();
	}
	getActivePlacement() {
		return this.activeRewardPlacement;
	}
};
var adMobBridge = new WebAndNativeAdMobManager();
// node_modules/react/cjs/react-jsx-runtime.production.js
/**
* @license React
* react-jsx-runtime.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_jsx_runtime_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
	var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	function jsxProd(type, config, maybeKey) {
		var key = null;
		void 0 !== maybeKey && (key = "" + maybeKey);
		void 0 !== config.key && (key = "" + config.key);
		if ("key" in config) {
			maybeKey = {};
			for (var propName in config) "key" !== propName && (maybeKey[propName] = config[propName]);
		} else maybeKey = config;
		config = maybeKey.ref;
		return {
			$$typeof: REACT_ELEMENT_TYPE,
			type,
			key,
			ref: void 0 !== config ? config : null,
			props: maybeKey
		};
	}
	exports.Fragment = REACT_FRAGMENT_TYPE;
	exports.jsx = jsxProd;
	exports.jsxs = jsxProd;
}));
// src/components/AdSlots.tsx
var import_jsx_runtime = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_jsx_runtime_production();
})))();
/**
* Reserves safe-area layout space ONLY when Native Android hosts a live AdView,
* or keeps zero HTML fake banner placeholders in web browsers.
* Note: In activity_main.xml, bannerAdContainer lives outside WebView (LinearLayout bottom),
* so WebView shrinks automatically when native Banner is visible — zero overlap!
*/
var BannerAdSlot = () => null;
/**
* Native Advanced Ad Anchor Container.
* - On Native Android when a genuine AdMob NativeAd is loaded: reserves exact non-overlapping
*   bounds and instructs AdMobManager.bindNativeAdOverlay(...) to display Google's real NativeAdView.
* - When no NativeAd is loaded (or on web browser): renders nothing (zero fake cards, zero blank gap).
*/
var NativeAdCard = ({ className = "" }) => {
	const hostRef = (0, import_react.useRef)(null);
	const [isNative] = (0, import_react.useState)(() => adMobBridge.isNativeAndroid());
	const [nativeLoaded, setNativeLoaded] = (0, import_react.useState)(() => adMobBridge.isNativeAdLoaded());
	(0, import_react.useEffect)(() => {
		if (!isNative) return;
		setNativeLoaded(adMobBridge.isNativeAdLoaded());
		const unsub = adMobBridge.subscribeNativeAvailability((loaded) => {
			setNativeLoaded(loaded);
		});
		return () => {
			unsub();
			adMobBridge.hideNativeOverlay();
		};
	}, [isNative]);
	(0, import_react.useEffect)(() => {
		if (!isNative || !nativeLoaded) {
			adMobBridge.hideNativeOverlay();
			return;
		}
		const el = hostRef.current;
		if (!el) return;
		const syncRect = () => {
			const r = el.getBoundingClientRect();
			if (r.width > 40 && r.height > 40) adMobBridge.bindNativeOverlayRect(r);
		};
		syncRect();
		const ro = new ResizeObserver(syncRect);
		ro.observe(el);
		window.addEventListener("resize", syncRect);
		return () => {
			ro.disconnect();
			window.removeEventListener("resize", syncRect);
			adMobBridge.hideNativeOverlay();
		};
	}, [isNative, nativeLoaded]);
	if (!isNative || !nativeLoaded) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: hostRef,
		className: `w-full h-[84px] rounded-xl border border-white/10 bg-[#0b0e17] shrink-0 ${className}`,
		"aria-label": "Sponsored Content"
	});
};
var REWARD_COPY = {
	extraLife: {
		title: "Extra Life Heart",
		detail: "Gain +1 Maximum Heart Seal (4 HP) for your next quest run."
	},
	checkpointRetry: {
		title: "Extra Checkpoint Retry",
		detail: "Revive immediately at your latest lit shrine checkpoint with restored health."
	},
	bonusCoins: {
		title: "+100 Bonus Coins",
		detail: "Receive 100 Gold Coins to spend on upgrades, arrows, or shadow costumes."
	},
	arrowEnergy: {
		title: "Magical Arrow Energy Surge",
		detail: "Start your next run with +50 Maximum Arrow Energy and +45% faster quiver recharge."
	},
	shadowShield: {
		title: "Temporary Shadow Shield",
		detail: "Gain +1 rotating protective Shadow Shield ward that blocks trap or enemy damage."
	},
	doubleReward: {
		title: "Double Level Coin Reward",
		detail: "Earn a bonus 100% Gold Coin payout equal to your stage reward."
	},
	abilityBoost: {
		title: "Full Shadow Shrine Blessing",
		detail: "Combines +1 Extra Heart, +1 Shadow Shield Ward, and +50 Arrow Energy for your next run."
	}
};
var AdPreviewModal = ({ modal }) => {
	const [secondsLeft, setSecondsLeft] = (0, import_react.useState)(3);
	(0, import_react.useEffect)(() => {
		if (!modal || modal.type === "rewardOptIn") return;
		setSecondsLeft(modal.type === "rewarded" ? 3 : 2);
		const id = window.setInterval(() => {
			setSecondsLeft((s) => s > 0 ? s - 1 : 0);
		}, 1e3);
		return () => clearInterval(id);
	}, [modal]);
	if (!modal) return null;
	if (modal.type === "rewardOptIn") {
		const info = modal.placement ? REWARD_COPY[modal.placement] : REWARD_COPY.bonusCoins;
		const isNative = adMobBridge.isNativeAndroid();
		const ready = adMobBridge.isRewardedReady();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md bg-[#0f131f] border border-amber-500/35 rounded-xl p-6 shadow-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold uppercase tracking-wider text-amber-300",
								children: "Optional Rewarded Ad"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => modal.onClose(false),
							className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer",
							"aria-label": "Cancel",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#080a10] border border-white/10 rounded-lg p-4 mb-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-display font-bold text-white mb-1",
								children: info.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-300 leading-relaxed",
								children: info.detail
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 pt-2.5 border-t border-white/10 text-[11px] flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-slate-400",
									children: "Ad Availability"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: ready ? "text-emerald-300 font-semibold" : "text-amber-300 font-semibold",
									children: isNative ? ready ? "Ready to Watch" : "No Ad Loaded Yet — Try Again Soon" : ready ? "Dev Test Simulator Ready" : "Available in Android APK"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-end gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => modal.onClose(false),
							className: "px-4 py-2.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							disabled: !ready,
							onClick: () => modal.onClose(true),
							className: "px-4 py-2.5 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 disabled:opacity-45 disabled:cursor-not-allowed text-slate-950 flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "w-3.5 h-3.5" }), ready ? "Watch Ad" : "Ad Loading…"]
						})]
					})
				]
			})
		});
	}
	const isRewarded = modal.type === "rewarded";
	const info = modal.placement ? REWARD_COPY[modal.placement] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md bg-[#0f131f] border border-white/15 rounded-xl p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-semibold text-amber-300 uppercase tracking-wider",
						children: ["Dev Web Test · ", isRewarded ? "Rewarded Unit" : "Interstitial Unit"]
					}), (!isRewarded || secondsLeft === 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => modal.onClose(isRewarded && secondsLeft === 0),
						className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#080a10] border border-white/10 rounded-lg p-5 text-center mb-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-9 h-9 text-amber-400 mx-auto mb-2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold text-white mb-1",
							children: isRewarded ? info?.title : "Natural Break Interstitial"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-400 leading-relaxed",
							children: isRewarded ? "Dev Web Simulator: Android APK executes Google Mobile Ads SDK RewardedAd and grants reward strictly inside OnUserEarnedRewardListener." : "Dev Web Simulator: Android APK enforces 3-level & 3-minute cooldowns and never interrupts active combat."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-end gap-3",
					children: [isRewarded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => modal.onClose(false),
						className: "px-4 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer",
						children: "Close Without Reward"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: secondsLeft > 0,
						onClick: () => modal.onClose(isRewarded),
						className: "px-4 py-2 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 cursor-pointer",
						children: secondsLeft > 0 ? `Ready in ${secondsLeft}s` : isRewarded ? "Earn Reward" : "Continue"
					})]
				})
			]
		})
	});
};
// src/game/constants.ts
var APP_IDENTITY = {
	title: "Shadow Ninja – Dark Quest",
	developer: "Rana Hassan",
	packageName: "com.educationwithhassan.shadowninja",
	versionName: "1.0.0"
};
var WORLD_IMAGES = {
	hero: "/src/assets/images/hero_shadow_ninja_1795440463061.jpg",
	forest: "/src/assets/images/forest_parallax_bg_1795442851456.jpg",
	temple: "/src/assets/images/world_forgotten_temple_1795440463470.jpg",
	mountains: "/src/assets/images/world_frozen_mountains_1795440463218.jpg",
	fortress: "/src/assets/images/world_dark_fortress_1795440462448.jpg"
};
var SPRITE_SHEET_URLS = {
	ninjaSheet: "/src/assets/images/ninja_spritesheet_1795442851277.jpg",
	enemySheet: "/src/assets/images/enemies_spritesheet_1795442850412.jpg",
	forestTiles: "/src/assets/images/forest_tileset_1795442850796.jpg",
	forestParallax: "/src/assets/images/forest_parallax_bg_1795442851456.jpg",
	dungeonTiles: "/src/assets/images/dungeon_traps_items_1795442850466.jpg",
	bowSheet: "/src/assets/images/bow_arrows_sheet_1795445830474.jpg"
};
var WORLDS = [
	{
		id: "forest",
		order: 1,
		name: "Cursed Forest",
		subtitle: "Act I · Moonlit Pines & Waterfalls",
		description: "Moonlit valleys of ancient twisted pines, roaring waterfalls, wooden bridges, and forgotten shrine lanterns.",
		image: WORLD_IMAGES.forest,
		accentColor: "#10b981",
		skyTop: "#050b10",
		skyBottom: "#133133",
		moonColor: "#bfe7df",
		fogColor: "rgba(26, 78, 76, 0.28)",
		silhouetteFar: "#0a1c20",
		silhouetteMid: "#071317",
		terrainColor: "#04080a",
		trimColor: "#144943",
		particleColor: "#6ee7b7",
		bossName: "Bramble Wraith",
		minibossName: "Cursed Treant Stalker",
		levelStart: 1,
		levelEnd: 15,
		completionRewardCoins: 350,
		completionRewardCrystals: 8
	},
	{
		id: "temple",
		order: 2,
		name: "Ancient Temple",
		subtitle: "Act II · Sunken Monoliths",
		description: "Subterranean stone sanctums lit by ember braziers, carved guardian statues, moving lifts, and timed rune gates.",
		image: WORLD_IMAGES.temple,
		accentColor: "#f59e0b",
		skyTop: "#080714",
		skyBottom: "#231c42",
		moonColor: "#fcd34d",
		fogColor: "rgba(84, 52, 118, 0.25)",
		silhouetteFar: "#14102b",
		silhouetteMid: "#0d0a1c",
		terrainColor: "#06050d",
		trimColor: "#78350f",
		particleColor: "#fbbf24",
		bossName: "Obsidian Sentinel",
		minibossName: "Temple Stone Warden",
		levelStart: 16,
		levelEnd: 30,
		completionRewardCoins: 550,
		completionRewardCrystals: 12
	},
	{
		id: "mountains",
		order: 3,
		name: "Frozen Kingdom",
		subtitle: "Act III · Glacial Peaks",
		description: "Snowy mountain ridges, frozen caverns, slick ice bridges, blinding snowstorms, and falling stalactites.",
		image: WORLD_IMAGES.mountains,
		accentColor: "#38bdf8",
		skyTop: "#040a16",
		skyBottom: "#0e3554",
		moonColor: "#bae6fd",
		fogColor: "rgba(56, 189, 248, 0.18)",
		silhouetteFar: "#0b2238",
		silhouetteMid: "#071626",
		terrainColor: "#050b14",
		trimColor: "#7dd3fc",
		particleColor: "#e0f2fe",
		bossName: "Glacial Wyrm",
		minibossName: "Frostfang Yeti",
		levelStart: 31,
		levelEnd: 45,
		completionRewardCoins: 750,
		completionRewardCrystals: 18
	},
	{
		id: "fortress",
		order: 4,
		name: "Dark Fortress",
		subtitle: "Act IV · Eclipse Citadel",
		description: "Obsidian battlements, suspended iron chains, rising furnace embers, and the throne of the Eclipse.",
		image: WORLD_IMAGES.fortress,
		accentColor: "#ef4444",
		skyTop: "#0a050a",
		skyBottom: "#33111c",
		moonColor: "#fca5a5",
		fogColor: "rgba(153, 27, 27, 0.24)",
		silhouetteFar: "#1f0b12",
		silhouetteMid: "#13070b",
		terrainColor: "#060306",
		trimColor: "#991b1b",
		particleColor: "#fb923c",
		bossName: "Lord of the Eclipse",
		minibossName: "Citadel Dreadknight",
		levelStart: 46,
		levelEnd: 60,
		completionRewardCoins: 1200,
		completionRewardCrystals: 30
	}
];
var WORLD_MAP = {
	forest: WORLDS[0],
	temple: WORLDS[1],
	mountains: WORLDS[2],
	fortress: WORLDS[3]
};
var COSTUMES = [
	{
		id: "classic",
		name: "Classic Shadow Ninja",
		description: "Traditional midnight shinobi silhouette with a flowing crimson silk scarf.",
		bodyColor: "#06070a",
		scarfColor: "#dc2626",
		eyeColor: "#f8fafc",
		accentGlow: "rgba(220, 38, 38, 0.55)",
		coinCost: 0,
		crystalCost: 0
	},
	{
		id: "blue",
		name: "Blue Shadow",
		description: "Cobalt mist cloak woven for silent leaps across moonlit forest canopies.",
		bodyColor: "#070b14",
		scarfColor: "#38bdf8",
		eyeColor: "#bae6fd",
		accentGlow: "rgba(56, 189, 248, 0.6)",
		coinCost: 400,
		crystalCost: 0
	},
	{
		id: "crimson",
		name: "Crimson Shadow",
		description: "Ember-forged armor ribbon radiating arcane heat during every Shadow Dash.",
		bodyColor: "#110608",
		scarfColor: "#f97316",
		eyeColor: "#fde047",
		accentGlow: "rgba(249, 115, 22, 0.65)",
		coinCost: 650,
		crystalCost: 10
	},
	{
		id: "golden",
		name: "Golden Shadow",
		description: "Sacred temple relic weave earned by mastering subterranean ruins.",
		bodyColor: "#0c0a06",
		scarfColor: "#facc15",
		eyeColor: "#fef08a",
		accentGlow: "rgba(250, 204, 21, 0.65)",
		coinCost: 1100,
		crystalCost: 18
	},
	{
		id: "frozen",
		name: "Frozen Shadow",
		description: "Glacial spirit shroud shimmering with frost runes and serene cyan light.",
		bodyColor: "#061018",
		scarfColor: "#67e8f9",
		eyeColor: "#ecfeff",
		accentGlow: "rgba(103, 232, 249, 0.7)",
		coinCost: 1400,
		crystalCost: 25
	}
];
var COSTUME_MAP = {
	classic: COSTUMES[0],
	blue: COSTUMES[1],
	crimson: COSTUMES[2],
	golden: COSTUMES[3],
	frozen: COSTUMES[4]
};
var ARROW_TYPES = [
	{
		id: "shadow",
		name: "Shadow Arrow",
		shortName: "Shadow",
		description: "Balanced obsidian shadow bolt. Pierces thin air cleanly and deals bonus critical damage at full draw.",
		energyCost: 16,
		baseDamage: 1,
		speed: 880,
		gravityScale: .22,
		color: "#e2e8f0",
		glowColor: "#a855f7",
		coinCost: 0,
		crystalCost: 0,
		unlockLevel: 1
	},
	{
		id: "fire",
		name: "Fire Spirit Arrow",
		shortName: "Fire",
		description: "Ignites struck foes with lingering crimson flame that burns through tough armor over 2.6s.",
		energyCost: 24,
		baseDamage: 1,
		speed: 835,
		gravityScale: .25,
		color: "#fb923c",
		glowColor: "#ef4444",
		coinCost: 180,
		crystalCost: 1,
		unlockLevel: 2
	},
	{
		id: "ice",
		name: "Ice Spirit Arrow",
		shortName: "Ice",
		description: "Chills struck targets in frost crystal, halving their movement and attack cadence for 3.2s.",
		energyCost: 24,
		baseDamage: 1,
		speed: 855,
		gravityScale: .23,
		color: "#67e8f9",
		glowColor: "#38bdf8",
		coinCost: 280,
		crystalCost: 2,
		unlockLevel: 4
	},
	{
		id: "lightning",
		name: "Lightning Arrow",
		shortName: "Lightning",
		description: "High-velocity storm bolt that discharges chained lightning arcs to up to 2 nearby enemies.",
		energyCost: 30,
		baseDamage: 1,
		speed: 1030,
		gravityScale: .12,
		color: "#fde047",
		glowColor: "#38bdf8",
		coinCost: 420,
		crystalCost: 4,
		unlockLevel: 8
	},
	{
		id: "explosive",
		name: "Explosive Magic Arrow",
		shortName: "Explosive",
		description: "Volatile runesmith warhead that detonates on enemy or stone impact in a 90px arcane blast.",
		energyCost: 36,
		baseDamage: 2,
		speed: 745,
		gravityScale: .34,
		color: "#f472b6",
		glowColor: "#a855f7",
		coinCost: 620,
		crystalCost: 6,
		unlockLevel: 12
	}
];
var ARROW_MAP = {
	shadow: ARROW_TYPES[0],
	fire: ARROW_TYPES[1],
	ice: ARROW_TYPES[2],
	lightning: ARROW_TYPES[3],
	explosive: ARROW_TYPES[4]
};
var ABILITY_UPGRADES = [
	{
		id: "swordPower",
		name: "Shadow Blade Mastery",
		keyHint: "F / X / Sword",
		description: "Tempers your katana edge for stronger melee strikes, wider crescent reach, and deadlier Dash Attacks.",
		maxLevel: 5,
		baseCoinCost: 130,
		baseCrystalCost: 0,
		effectSummary: (lvl) => `Slash ${1 + Math.floor((lvl - 1) / 2)} DMG · Reach ${68 + (lvl - 1) * 5}px`
	},
	{
		id: "bowMastery",
		name: "Shadow Bow & Quiver",
		keyHint: "Hold & Drag Bow / G",
		description: "Enhances bow draw speed, arrow velocity, critical charge power, and maximum Spirit Arrow Energy.",
		maxLevel: 5,
		baseCoinCost: 130,
		baseCrystalCost: 0,
		effectSummary: (lvl) => `Energy ${100 + (lvl - 1) * 18} · Regen ${(20 + (lvl - 1) * 4.5).toFixed(1)}/s · +${(lvl - 1) * 15}% Power`
	},
	{
		id: "shadowDash",
		name: "Shadow Dash",
		keyHint: "Shift / Dash",
		description: "Surge forward as an intangible shadow bolt, crossing wide chasms and phasing past hazards.",
		maxLevel: 5,
		baseCoinCost: 140,
		baseCrystalCost: 0,
		effectSummary: (lvl) => `Speed ${680 + lvl * 55} px/s · Cooldown ${(1.45 - lvl * .16).toFixed(2)}s`
	},
	{
		id: "doubleJump",
		name: "Double Jump Mastery",
		keyHint: "Space / Jump ×2",
		description: "Channel wind beneath your boots for higher mid-air ascents and razor-sharp aerial control.",
		maxLevel: 5,
		baseCoinCost: 120,
		baseCrystalCost: 0,
		effectSummary: (lvl) => `Air Impulse +${(lvl - 1) * 8}% · Air Control +${(lvl - 1) * 10}%`
	},
	{
		id: "energyShield",
		name: "Energy Shield",
		keyHint: "Auto / Passive",
		description: "Projects a rotating rune barrier that absorbs trap and creature impacts before recharging.",
		maxLevel: 5,
		baseCoinCost: 200,
		baseCrystalCost: 2,
		effectSummary: (lvl) => lvl === 0 ? "Locked — Unlock to gain 1 protective ward" : `${lvl >= 4 ? 2 : 1} Ward${lvl >= 4 ? "s" : ""} · Recharge ${(18 - lvl * 2.2).toFixed(1)}s`
	},
	{
		id: "shadowPulse",
		name: "Shadow Pulse",
		keyHint: "J / Pulse",
		description: "Release an expanding dark shockwave that disperses nearby shadow creatures and reflects orbs.",
		maxLevel: 5,
		baseCoinCost: 180,
		baseCrystalCost: 2,
		effectSummary: (lvl) => lvl === 0 ? "Locked — Unlock radial shadow dispersion" : `Radius ${160 + lvl * 28}px · Cooldown ${(4.2 - lvl * .45).toFixed(2)}s`
	},
	{
		id: "timeFocus",
		name: "Time Focus",
		keyHint: "T / Focus",
		description: "Slows moving platforms, traps, projectiles, and enemies to 35% speed while you move freely.",
		maxLevel: 5,
		baseCoinCost: 220,
		baseCrystalCost: 3,
		effectSummary: (lvl) => lvl === 0 ? "Locked — Unlock temporal slowdown" : `Duration ${(2.4 + lvl * .65).toFixed(1)}s · Cooldown ${(12 - lvl * 1.1).toFixed(1)}s`
	}
];
var ABILITY_MAP = {
	swordPower: ABILITY_UPGRADES[0],
	bowMastery: ABILITY_UPGRADES[1],
	shadowDash: ABILITY_UPGRADES[2],
	doubleJump: ABILITY_UPGRADES[3],
	energyShield: ABILITY_UPGRADES[4],
	shadowPulse: ABILITY_UPGRADES[5],
	timeFocus: ABILITY_UPGRADES[6]
};
function getUpgradeCost(ability, currentLevel) {
	const nextLevel = currentLevel + 1;
	return {
		coins: Math.round(ability.baseCoinCost * Math.pow(1.45, currentLevel)),
		crystals: ability.baseCrystalCost > 0 ? Math.max(1, Math.round(ability.baseCrystalCost + currentLevel * 2)) : nextLevel >= 4 ? nextLevel - 2 : 0
	};
}
// src/game/audio.ts
var SoundEngine = class {
	constructor() {
		this.ctx = null;
		this.musicGain = null;
		this.sfxGain = null;
		this.musicVolume = .65;
		this.sfxVolume = .8;
		this.currentTheme = null;
		this.musicTimer = null;
		this.stepIndex = 0;
		this.lastSfxTime = {};
		this.mutedByLifecycle = false;
	}
	ensureContext() {
		if (typeof window === "undefined") return null;
		if (!this.ctx) {
			const AudioCtx = window.AudioContext || window.webkitAudioContext;
			if (!AudioCtx) return null;
			this.ctx = new AudioCtx();
			this.musicGain = this.ctx.createGain();
			this.sfxGain = this.ctx.createGain();
			this.musicGain.gain.value = this.mutedByLifecycle ? 0 : this.musicVolume * .28;
			this.sfxGain.gain.value = this.mutedByLifecycle ? 0 : this.sfxVolume * .5;
			this.musicGain.connect(this.ctx.destination);
			this.sfxGain.connect(this.ctx.destination);
		}
		if (this.ctx.state === "suspended" && !this.mutedByLifecycle) this.ctx.resume().catch(() => {});
		return this.ctx;
	}
	unlock() {
		this.ensureContext();
	}
	setVolumes(musicVol, sfxVol) {
		this.musicVolume = Math.max(0, Math.min(1, musicVol));
		this.sfxVolume = Math.max(0, Math.min(1, sfxVol));
		if (this.musicGain && this.ctx) this.musicGain.gain.setTargetAtTime(this.mutedByLifecycle ? 0 : this.musicVolume * .28, this.ctx.currentTime, .04);
		if (this.sfxGain && this.ctx) this.sfxGain.gain.setTargetAtTime(this.mutedByLifecycle ? 0 : this.sfxVolume * .5, this.ctx.currentTime, .04);
	}
	onAppPause() {
		this.mutedByLifecycle = true;
		if (this.ctx && this.ctx.state === "running") this.ctx.suspend().catch(() => {});
	}
	onAppResume() {
		this.mutedByLifecycle = false;
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
	}
	startMusic(theme) {
		if (this.currentTheme === theme && this.musicTimer !== null) return;
		this.stopMusic();
		this.currentTheme = theme;
		this.stepIndex = 0;
		const scales = {
			menu: [
				146.83,
				174.61,
				196,
				220,
				261.63,
				293.66
			],
			forest: [
				146.83,
				164.81,
				196,
				220,
				261.63,
				293.66
			],
			temple: [
				130.81,
				155.56,
				174.61,
				196,
				233.08,
				261.63
			],
			mountains: [
				164.81,
				196,
				220,
				246.94,
				293.66,
				329.63
			],
			fortress: [
				110,
				123.47,
				130.81,
				164.81,
				174.61,
				220
			],
			boss: [
				98,
				110,
				116.54,
				146.83,
				155.56,
				196
			]
		};
		const intervalMs = theme === "boss" ? 280 : theme === "fortress" ? 380 : 520;
		const notes = scales[theme];
		this.musicTimer = window.setInterval(() => {
			if (this.mutedByLifecycle || this.musicVolume <= .01) return;
			const ctx = this.ctx;
			if (!ctx || !this.musicGain || ctx.state !== "running") return;
			const now = ctx.currentTime;
			const step = this.stepIndex++;
			if (step % 4 === 0) {
				const bassOsc = ctx.createOscillator();
				const bassGain = ctx.createGain();
				bassOsc.type = theme === "boss" ? "sawtooth" : "triangle";
				const bassFreq = notes[0] * (step % 8 === 0 ? .5 : .75);
				bassOsc.frequency.setValueAtTime(bassFreq, now);
				const filter = ctx.createBiquadFilter();
				filter.type = "lowpass";
				filter.frequency.value = theme === "boss" ? 420 : 260;
				bassGain.gain.setValueAtTime(.001, now);
				bassGain.gain.linearRampToValueAtTime(.28, now + .08);
				bassGain.gain.exponentialRampToValueAtTime(.001, now + intervalMs * 3.6 / 1e3);
				bassOsc.connect(filter);
				filter.connect(bassGain);
				bassGain.connect(this.musicGain);
				bassOsc.start(now);
				bassOsc.stop(now + intervalMs * 3.8 / 1e3);
			}
			const pattern = [
				0,
				2,
				4,
				3,
				5,
				2,
				1,
				4
			];
			if (step % 2 === 0 || theme === "boss") {
				const idx = pattern[(step + (step >> 3)) % pattern.length];
				const freq = notes[idx % notes.length] * (theme === "mountains" ? 2 : 1);
				const osc = ctx.createOscillator();
				const gain = ctx.createGain();
				osc.type = theme === "mountains" ? "sine" : "triangle";
				osc.frequency.setValueAtTime(freq, now);
				gain.gain.setValueAtTime(.001, now);
				gain.gain.linearRampToValueAtTime(theme === "boss" ? .22 : .16, now + .02);
				gain.gain.exponentialRampToValueAtTime(.001, now + intervalMs * 1.4 / 1e3);
				osc.connect(gain);
				gain.connect(this.musicGain);
				osc.start(now);
				osc.stop(now + intervalMs * 1.5 / 1e3);
			}
			if (step % 4 === 1 && (theme === "forest" || theme === "temple" || theme === "mountains" || theme === "fortress")) {
				const cutoff = theme === "forest" ? 520 : theme === "temple" ? 240 : theme === "mountains" ? 920 : 180;
				const dur = intervalMs * 2.2 / 1e3;
				const sampleCount = Math.floor(ctx.sampleRate * dur);
				const buffer = ctx.createBuffer(1, sampleCount, ctx.sampleRate);
				const data = buffer.getChannelData(0);
				for (let i = 0; i < sampleCount; i++) {
					const env = Math.sin(Math.PI * i / sampleCount);
					data[i] = (Math.random() * 2 - 1) * env * .14;
				}
				const src = ctx.createBufferSource();
				src.buffer = buffer;
				const filter = ctx.createBiquadFilter();
				filter.type = "bandpass";
				filter.frequency.value = cutoff;
				const g = ctx.createGain();
				g.gain.value = .25;
				src.connect(filter);
				filter.connect(g);
				g.connect(this.musicGain);
				src.start(now);
			}
		}, intervalMs);
	}
	stopMusic() {
		if (this.musicTimer !== null) {
			clearInterval(this.musicTimer);
			this.musicTimer = null;
		}
		this.currentTheme = null;
	}
	playSfx(name) {
		if (this.mutedByLifecycle || this.sfxVolume <= .01) return;
		const nowMs = performance.now();
		if (nowMs - (this.lastSfxTime[name] ?? 0) < ({
			coin: 45,
			land: 90,
			uiClick: 50,
			jump: 60
		}[name] ?? 40)) return;
		this.lastSfxTime[name] = nowMs;
		const ctx = this.ensureContext();
		if (!ctx || !this.sfxGain || ctx.state !== "running") return;
		const t = ctx.currentTime;
		switch (name) {
			case "jump":
				this.sweep(ctx, t, "triangle", 190, 440, .12, .35);
				break;
			case "doubleJump":
				this.sweep(ctx, t, "sine", 300, 680, .14, .38);
				break;
			case "land":
				this.sweep(ctx, t, "sine", 120, 48, .08, .28);
				break;
			case "dash":
				this.noiseBurst(ctx, t, .16, 1100, .38);
				this.sweep(ctx, t, "sawtooth", 420, 140, .15, .2);
				break;
			case "dashAttack":
				this.noiseBurst(ctx, t, .18, 2200, .42);
				this.sweep(ctx, t, "sawtooth", 620, 180, .17, .34);
				break;
			case "slash":
				this.noiseBurst(ctx, t, .11, 2400, .34);
				this.sweep(ctx, t, "triangle", 720, 210, .11, .26);
				break;
			case "alert":
				this.tone(ctx, t, "triangle", 620, .08, .2);
				break;
			case "trapSnap":
				this.tone(ctx, t, "square", 320, .06, .22);
				this.noiseBurst(ctx, t + .04, .08, 1800, .24);
				break;
			case "coin":
				this.tone(ctx, t, "sine", 880, .07, .25);
				this.tone(ctx, t + .055, "sine", 1318.5, .12, .25);
				break;
			case "crystal":
				this.tone(ctx, t, "triangle", 740, .08, .3);
				this.tone(ctx, t + .06, "triangle", 1108.7, .1, .3);
				this.tone(ctx, t + .12, "sine", 1480, .18, .32);
				break;
			case "treasure":
				[
					523.25,
					659.25,
					783.99,
					1046.5
				].forEach((f, i) => this.tone(ctx, t + i * .06, "triangle", f, .2, .32));
				break;
			case "checkpoint":
				[
					392,
					493.88,
					587.33,
					783.99
				].forEach((f, i) => this.tone(ctx, t + i * .07, "sine", f, .24, .3));
				break;
			case "shield":
				this.sweep(ctx, t, "sine", 260, 520, .18, .3);
				break;
			case "pulse":
				this.sweep(ctx, t, "sawtooth", 240, 55, .28, .42);
				this.noiseBurst(ctx, t, .22, 650, .3);
				break;
			case "timeFocus":
				this.sweep(ctx, t, "sine", 660, 220, .35, .35);
				break;
			case "hit":
				this.sweep(ctx, t, "sawtooth", 160, 48, .22, .45);
				this.noiseBurst(ctx, t, .14, 420, .35);
				break;
			case "defeat":
				[
					246.94,
					220,
					174.61,
					130.81
				].forEach((f, i) => this.tone(ctx, t + i * .11, "triangle", f, .28, .32));
				break;
			case "enemyDisperse":
				this.sweep(ctx, t, "triangle", 480, 120, .16, .32);
				this.noiseBurst(ctx, t, .12, 1400, .22);
				break;
			case "levelComplete":
				[
					440,
					554.37,
					659.25,
					880
				].forEach((f, i) => this.tone(ctx, t + i * .08, "triangle", f, .28, .34));
				break;
			case "bossDefeat":
				[
					293.66,
					369.99,
					440,
					587.33,
					880
				].forEach((f, i) => this.tone(ctx, t + i * .09, "triangle", f, .38, .4));
				break;
			case "bowDraw":
				this.sweep(ctx, t, "triangle", 170, 290, .09, .16);
				break;
			case "arrowShoot":
				this.noiseBurst(ctx, t, .08, 2800, .28);
				this.sweep(ctx, t, "triangle", 680, 210, .1, .26);
				break;
			case "arrowFire":
				this.noiseBurst(ctx, t, .14, 1600, .34);
				this.sweep(ctx, t, "sawtooth", 540, 150, .15, .28);
				break;
			case "arrowIce":
				this.tone(ctx, t, "sine", 1240, .09, .24);
				this.sweep(ctx, t, "triangle", 980, 520, .14, .22);
				break;
			case "arrowLightning":
				this.noiseBurst(ctx, t, .1, 3600, .35);
				this.sweep(ctx, t, "sawtooth", 1100, 320, .12, .28);
				break;
			case "arrowExplode":
				this.noiseBurst(ctx, t, .24, 520, .42);
				this.sweep(ctx, t, "sawtooth", 190, 44, .26, .42);
				break;
			case "arrowHit":
				this.noiseBurst(ctx, t, .06, 2100, .24);
				this.tone(ctx, t, "triangle", 360, .06, .22);
				break;
			case "uiClick": this.tone(ctx, t, "sine", 580, .045, .16);
		}
	}
	tone(ctx, start, type, freq, dur, vol) {
		if (!this.sfxGain) return;
		const osc = ctx.createOscillator();
		const g = ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, start);
		g.gain.setValueAtTime(.001, start);
		g.gain.linearRampToValueAtTime(vol, start + .012);
		g.gain.exponentialRampToValueAtTime(.001, start + dur);
		osc.connect(g);
		g.connect(this.sfxGain);
		osc.start(start);
		osc.stop(start + dur + .02);
	}
	sweep(ctx, start, type, f1, f2, dur, vol) {
		if (!this.sfxGain) return;
		const osc = ctx.createOscillator();
		const g = ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(f1, start);
		osc.frequency.exponentialRampToValueAtTime(Math.max(20, f2), start + dur);
		g.gain.setValueAtTime(vol, start);
		g.gain.exponentialRampToValueAtTime(.001, start + dur);
		osc.connect(g);
		g.connect(this.sfxGain);
		osc.start(start);
		osc.stop(start + dur + .02);
	}
	noiseBurst(ctx, start, dur, cutoff, vol) {
		if (!this.sfxGain) return;
		const sampleCount = Math.floor(ctx.sampleRate * dur);
		const buffer = ctx.createBuffer(1, sampleCount, ctx.sampleRate);
		const data = buffer.getChannelData(0);
		for (let i = 0; i < sampleCount; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / sampleCount);
		const src = ctx.createBufferSource();
		src.buffer = buffer;
		const filter = ctx.createBiquadFilter();
		filter.type = "bandpass";
		filter.frequency.value = cutoff;
		const g = ctx.createGain();
		g.gain.setValueAtTime(vol, start);
		g.gain.exponentialRampToValueAtTime(.001, start + dur);
		src.connect(filter);
		filter.connect(g);
		g.connect(this.sfxGain);
		src.start(start);
	}
};
var soundEngine = new SoundEngine();
// src/game/sprites.ts
var NINJA_KEYS = [
	"idle",
	"runA",
	"runB",
	"jump",
	"doubleJump",
	"fall",
	"land",
	"dash",
	"attack",
	"ability",
	"hurt",
	"victory"
];
var ENEMY_KEYS = [
	"warrior",
	"spirit",
	"guardian",
	"hunter",
	"mage",
	"elite",
	"miniboss",
	"boss"
];
var FOREST_TILE_KEYS = [
	"mossGround",
	"mossLedge",
	"woodBridge",
	"gnarledTree",
	"stoneLantern",
	"portalArch"
];
var DUNGEON_TILE_KEYS = [
	"templeStone",
	"iceLedge",
	"spikes",
	"sawBlade",
	"statueBrazier",
	"fortressStone",
	"coinCrystal",
	"treasureChest"
];
var BOW_KEYS = [
	"bow",
	"arrow_shadow",
	"arrow_fire",
	"arrow_ice",
	"arrow_lightning",
	"arrow_explosive"
];
var GameSpriteLibrary = class {
	constructor() {
		this.started = false;
		this.ninjaCache = /* @__PURE__ */ new Map();
		this.enemyCache = /* @__PURE__ */ new Map();
		this.forestCache = /* @__PURE__ */ new Map();
		this.dungeonCache = /* @__PURE__ */ new Map();
		this.bowCache = /* @__PURE__ */ new Map();
		this.backdropCache = /* @__PURE__ */ new Map();
	}
	ensureLoaded() {
		if (this.started || typeof Image === "undefined" || typeof document === "undefined") return;
		this.started = true;
		this.loadImage(SPRITE_SHEET_URLS.ninjaSheet, (img) => {
			this.extractGrid(img, 4, 3, { stripBottomShadow: false }, (idx, sprite) => {
				const key = NINJA_KEYS[idx];
				if (key) this.ninjaCache.set(`classic:${key}`, sprite);
			});
		});
		this.loadImage(SPRITE_SHEET_URLS.enemySheet, (img) => {
			this.extractGrid(img, 4, 2, { stripBottomShadow: true }, (idx, sprite) => {
				const key = ENEMY_KEYS[idx];
				if (key) this.enemyCache.set(key, sprite);
			});
		});
		this.loadImage(SPRITE_SHEET_URLS.forestTiles, (img) => {
			this.extractGrid(img, 3, 2, { stripBottomShadow: false }, (idx, sprite) => {
				const key = FOREST_TILE_KEYS[idx];
				if (key) this.forestCache.set(key, sprite);
			});
		});
		this.loadImage(SPRITE_SHEET_URLS.dungeonTiles, (img) => {
			this.extractGrid(img, 4, 2, { stripBottomShadow: false }, (idx, sprite) => {
				const key = DUNGEON_TILE_KEYS[idx];
				if (!key) return;
				if (key === "coinCrystal") this.splitCoinAndCrystal(sprite);
				else this.dungeonCache.set(key, sprite);
			});
		});
		this.loadImage(SPRITE_SHEET_URLS.bowSheet, (img) => {
			this.extractGrid(img, 3, 2, {
				stripBottomShadow: false,
				insetPad: 8
			}, (idx, sprite) => {
				const key = BOW_KEYS[idx];
				if (key) this.bowCache.set(key, sprite);
			});
		});
	}
	getBackdrop(url) {
		if (typeof Image === "undefined") return null;
		let img = this.backdropCache.get(url);
		if (!img) {
			img = new Image();
			img.src = url;
			this.backdropCache.set(url, img);
		}
		return img.complete && img.naturalWidth > 0 ? img : null;
	}
	getNinjaSprite(key, costumeId) {
		this.ensureLoaded();
		const cacheKey = `${costumeId}:${key}`;
		const existing = this.ninjaCache.get(cacheKey);
		if (existing) return existing;
		const base = this.ninjaCache.get(`classic:${key}`);
		if (!base) return null;
		if (costumeId === "classic") return base;
		const tinted = this.recolorScarf(base, costumeId);
		this.ninjaCache.set(cacheKey, tinted);
		return tinted;
	}
	getEnemySprite(type) {
		this.ensureLoaded();
		return this.enemyCache.get(type) ?? null;
	}
	getForestTile(key) {
		this.ensureLoaded();
		return this.forestCache.get(key) ?? null;
	}
	getDungeonTile(key) {
		this.ensureLoaded();
		return this.dungeonCache.get(key) ?? null;
	}
	getBowSprite(key) {
		this.ensureLoaded();
		return this.bowCache.get(key) ?? null;
	}
	loadImage(url, onLoad) {
		const img = new Image();
		img.onload = () => {
			if (img.naturalWidth > 0 && img.naturalHeight > 0) onLoad(img);
		};
		img.src = url;
	}
	extractGrid(img, cols, rows, opts, onCell) {
		const cellW = Math.floor(img.naturalWidth / cols);
		const cellH = Math.floor(img.naturalHeight / rows);
		const pad = opts.insetPad ?? 0;
		for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
			const idx = r * cols + c;
			const sx = c * cellW + pad;
			const sy = r * cellH + pad;
			const sprite = this.processCell(img, sx, sy, Math.max(4, cellW - pad * 2), Math.max(4, cellH - pad * 2), opts.stripBottomShadow);
			if (sprite) onCell(idx, sprite);
		}
	}
	processCell(img, sx, sy, sw, sh, stripBottomShadow) {
		const work = document.createElement("canvas");
		work.width = sw;
		work.height = sh;
		const wctx = work.getContext("2d", { willReadFrequently: true });
		if (!wctx) return null;
		wctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
		const imgData = wctx.getImageData(0, 0, sw, sh);
		const data = imgData.data;
		const visited = new Uint8Array(sw * sh);
		const queue = new Int32Array(sw * sh);
		let head = 0;
		let tail = 0;
		const isBgCandidate = (p) => {
			const i = p * 4;
			const r = data[i];
			const g = data[i + 1];
			const b = data[i + 2];
			const max = r > g ? r > b ? r : b : g > b ? g : b;
			const min = r < g ? r < b ? r : b : g < b ? g : b;
			return min > 212 && max - min < 34;
		};
		const enqueue = (x, y) => {
			if (x < 0 || x >= sw || y < 0 || y >= sh) return;
			const p = y * sw + x;
			if (visited[p] || !isBgCandidate(p)) return;
			visited[p] = 1;
			queue[tail++] = p;
		};
		for (let x = 0; x < sw; x++) {
			enqueue(x, 0);
			enqueue(x, sh - 1);
		}
		for (let y = 0; y < sh; y++) {
			enqueue(0, y);
			enqueue(sw - 1, y);
		}
		while (head < tail) {
			const p = queue[head++];
			data[p * 4 + 3] = 0;
			const x = p % sw;
			const y = (p - x) / sw;
			if (x > 0) enqueue(x - 1, y);
			if (x + 1 < sw) enqueue(x + 1, y);
			if (y > 0) enqueue(x, y - 1);
			if (y + 1 < sh) enqueue(x, y + 1);
		}
		for (let y = 1; y < sh - 1; y++) for (let x = 1; x < sw - 1; x++) {
			const p = y * sw + x;
			if (visited[p]) continue;
			if (!(visited[p - 1] || visited[p + 1] || visited[p - sw] || visited[p + sw])) continue;
			const i = p * 4;
			const r = data[i];
			const g = data[i + 1];
			const b = data[i + 2];
			const lum = (r + g + b) / 3;
			if (lum > 180 && Math.max(r, g, b) - Math.min(r, g, b) < 36) {
				const factor = Math.max(0, Math.min(1, (234 - lum) / 54));
				data[i + 3] = Math.round(data[i + 3] * factor);
			}
		}
		if (stripBottomShadow) {
			const rowCounts = new Int32Array(sh);
			for (let y = 0; y < sh; y++) {
				let count = 0;
				for (let x = 0; x < sw; x++) if (data[(y * sw + x) * 4 + 3] > 25) count++;
				rowCounts[y] = count;
			}
			const scanStart = Math.floor(sh * .72);
			let gapStart = -1;
			for (let y = sh - 6; y >= scanStart; y--) if (rowCounts[y] === 0 && rowCounts[y - 1] === 0 && rowCounts[y - 2] === 0) {
				gapStart = y;
				break;
			}
			if (gapStart > 0) for (let y = gapStart; y < sh; y++) for (let x = 0; x < sw; x++) data[(y * sw + x) * 4 + 3] = 0;
		}
		wctx.putImageData(imgData, 0, 0);
		let minX = sw;
		let minY = sh;
		let maxX = -1;
		let maxY = -1;
		for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) if (data[(y * sw + x) * 4 + 3] > 18) {
			if (x < minX) minX = x;
			if (x > maxX) maxX = x;
			if (y < minY) minY = y;
			if (y > maxY) maxY = y;
		}
		if (maxX < minX || maxY < minY) return null;
		const tw = maxX - minX + 1;
		const th = maxY - minY + 1;
		const out = document.createElement("canvas");
		out.width = tw;
		out.height = th;
		const octx = out.getContext("2d");
		if (!octx) return null;
		octx.drawImage(work, minX, minY, tw, th, 0, 0, tw, th);
		return {
			canvas: out,
			w: tw,
			h: th
		};
	}
	splitCoinAndCrystal(combined) {
		const midX = Math.floor(combined.w * .48);
		const makeCrop = (x0, x1) => {
			const cw = x1 - x0;
			if (cw <= 4) return null;
			const c = document.createElement("canvas");
			c.width = cw;
			c.height = combined.h;
			const ctx = c.getContext("2d");
			if (!ctx) return null;
			ctx.drawImage(combined.canvas, x0, 0, cw, combined.h, 0, 0, cw, combined.h);
			return {
				canvas: c,
				w: cw,
				h: combined.h
			};
		};
		const coin = makeCrop(0, midX);
		const crystal = makeCrop(midX, combined.w);
		if (coin) this.dungeonCache.set("coin", coin);
		if (crystal) this.dungeonCache.set("crystal", crystal);
	}
	recolorScarf(base, costumeId) {
		const hex = COSTUME_MAP[costumeId].scarfColor.replace("#", "");
		const tr = parseInt(hex.slice(0, 2), 16);
		const tg = parseInt(hex.slice(2, 4), 16);
		const tb = parseInt(hex.slice(4, 6), 16);
		const out = document.createElement("canvas");
		out.width = base.w;
		out.height = base.h;
		const ctx = out.getContext("2d", { willReadFrequently: true });
		if (!ctx) return base;
		ctx.drawImage(base.canvas, 0, 0);
		const img = ctx.getImageData(0, 0, base.w, base.h);
		const d = img.data;
		for (let i = 0; i < d.length; i += 4) {
			if (d[i + 3] < 16) continue;
			const r = d[i];
			const g = d[i + 1];
			const b = d[i + 2];
			if (r > 65 && r > g * 1.45 && r > b * 1.45) {
				const lum = r / 195;
				d[i] = Math.min(255, Math.round(tr * lum));
				d[i + 1] = Math.min(255, Math.round(tg * lum));
				d[i + 2] = Math.min(255, Math.round(tb * lum));
			}
		}
		ctx.putImageData(img, 0, 0);
		return {
			canvas: out,
			w: base.w,
			h: base.h
		};
	}
};
var spriteLibrary = new GameSpriteLibrary();
// src/game/renderer.ts
function renderGameScene(ctx, scene) {
	const { viewW, viewH, worldId, cameraX, cameraY, time } = scene;
	const world = WORLD_MAP[worldId];
	const costume = COSTUME_MAP[scene.costumeId];
	spriteLibrary.ensureLoaded();
	ctx.save();
	const skyGrad = ctx.createLinearGradient(0, 0, 0, viewH);
	skyGrad.addColorStop(0, world.skyTop);
	skyGrad.addColorStop(1, world.skyBottom);
	ctx.fillStyle = skyGrad;
	ctx.fillRect(0, 0, viewW, viewH);
	const bgUrl = worldId === "forest" ? SPRITE_SHEET_URLS.forestParallax : world.image;
	const bgImg = spriteLibrary.getBackdrop(bgUrl);
	if (bgImg) {
		ctx.save();
		ctx.globalAlpha = worldId === "forest" ? .88 : .72;
		const scale = Math.max(viewW / bgImg.naturalWidth, viewH / bgImg.naturalHeight) * 1.04;
		const dw = bgImg.naturalWidth * scale;
		const dh = bgImg.naturalHeight * scale;
		const dy = (viewH - dh) * .45;
		const scroll = (cameraX * .08 % (dw * 2) + dw * 2) % (dw * 2);
		const tilesNeeded = Math.ceil(viewW / dw) + 2;
		const baseIdx = Math.floor(scroll / dw);
		const fracOffset = scroll - baseIdx * dw;
		for (let t = 0; t <= tilesNeeded; t++) {
			const idx = baseIdx + t;
			const dx = t * dw - fracOffset;
			ctx.save();
			if (idx % 2 === 1) {
				ctx.translate(dx + dw, 0);
				ctx.scale(-1, 1);
				ctx.drawImage(bgImg, 0, dy, dw, dh);
			} else ctx.drawImage(bgImg, dx, dy, dw, dh);
			ctx.restore();
		}
		ctx.restore();
	}
	drawSkyAtmosphere(ctx, scene, worldId, time);
	const moonX = viewW * .72 - cameraX * .02;
	const moonY = viewH * .21;
	const moonRadius = worldId === "fortress" ? 68 : 56;
	const moonGlow = ctx.createRadialGradient(moonX, moonY, moonRadius * .35, moonX, moonY, moonRadius * 3.4);
	moonGlow.addColorStop(0, world.fogColor);
	moonGlow.addColorStop(1, "rgba(0,0,0,0)");
	ctx.fillStyle = moonGlow;
	ctx.beginPath();
	ctx.arc(moonX, moonY, moonRadius * 3.4, 0, Math.PI * 2);
	ctx.fill();
	if (worldId !== "forest" || !bgImg) {
		ctx.fillStyle = world.moonColor;
		ctx.beginPath();
		ctx.arc(moonX, moonY, moonRadius, 0, Math.PI * 2);
		ctx.fill();
		if (worldId === "fortress") {
			ctx.fillStyle = "#090308";
			ctx.beginPath();
			ctx.arc(moonX - 3, moonY - 2, moonRadius * .85, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	ctx.save();
	ctx.globalAlpha = .055;
	ctx.fillStyle = world.moonColor;
	for (let r = -1; r <= 1; r++) {
		ctx.beginPath();
		ctx.moveTo(moonX + r * 36, moonY);
		ctx.lineTo(moonX + r * 145 - 230, viewH);
		ctx.lineTo(moonX + r * 145 - 95, viewH);
		ctx.closePath();
		ctx.fill();
	}
	ctx.restore();
	drawParallaxRidges(ctx, viewW, viewH, cameraX * .14, world.silhouetteFar, .72, 48, 11);
	drawMidgroundSilhouettes(ctx, viewW, viewH, cameraX * .28, worldId, world.silhouetteMid);
	const mistGrad = ctx.createLinearGradient(0, viewH * .56, 0, viewH);
	mistGrad.addColorStop(0, "rgba(0,0,0,0)");
	mistGrad.addColorStop(.55, world.fogColor);
	mistGrad.addColorStop(1, "rgba(3, 6, 10, 0.65)");
	ctx.fillStyle = mistGrad;
	ctx.fillRect(0, viewH * .56, viewW, viewH * .44);
	ctx.save();
	ctx.translate(Math.round(-cameraX + scene.shakeX), Math.round(-cameraY + scene.shakeY));
	for (const deco of scene.level.decorations) {
		if (deco.x < cameraX - 240 || deco.x > cameraX + viewW + 240) continue;
		drawDecoration(ctx, deco, worldId, world.terrainColor, world.accentColor, time);
	}
	for (const cp of scene.checkpoints) drawCheckpoint(ctx, cp, world.accentColor, time);
	drawExitPortal(ctx, scene.level.exit, scene.bossAlive, world.accentColor, time);
	for (const p of scene.platforms) {
		if (p.fallState === "fallen") continue;
		if (p.x + p.w < cameraX - 140 || p.x > cameraX + viewW + 140) continue;
		drawPlatform(ctx, p, worldId, world.terrainColor, world.trimColor, world.accentColor, time);
	}
	for (const h of scene.hazards) {
		if (h.x + h.w < cameraX - 180 || h.x - h.w > cameraX + viewW + 180) continue;
		drawHazard(ctx, h, world.accentColor, time);
	}
	for (const c of scene.collectibles) {
		if (c.collected) continue;
		if (c.x < cameraX - 80 || c.x > cameraX + viewW + 80) continue;
		drawCollectible(ctx, c, time);
	}
	for (const e of scene.enemies) {
		if (!e.alive && e.defeatTimer <= 0) continue;
		if (e.x + e.w < cameraX - 180 || e.x - e.w > cameraX + viewW + 180) continue;
		drawEnemy(ctx, e, world.accentColor, worldId, time);
	}
	for (const proj of scene.projectiles) {
		if (!proj.active) continue;
		if (proj.isArrow && proj.arrowType) {
			drawMagicalArrowProjectile(ctx, proj, time);
			continue;
		}
		ctx.save();
		ctx.shadowColor = proj.color;
		ctx.shadowBlur = 14;
		ctx.fillStyle = proj.color;
		ctx.beginPath();
		ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#ffffff";
		ctx.beginPath();
		ctx.arc(proj.x, proj.y, proj.radius * .45, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	}
	if (scene.trajectoryPreview) drawTrajectoryPreview(ctx, scene.trajectoryPreview, time);
	for (const ghost of scene.player.afterimages) {
		ctx.save();
		ctx.globalAlpha = ghost.alpha * .42;
		drawNinjaSprite(ctx, {
			...scene.player,
			x: ghost.x,
			y: ghost.y,
			facing: ghost.facing,
			animState: "dash"
		}, scene.costumeId, costume.bodyColor, costume.eyeColor, true, time);
		ctx.restore();
	}
	drawNinja(ctx, scene.player, scene.costumeId, costume.bodyColor, costume.scarfColor, costume.eyeColor, costume.accentGlow, time);
	for (const arc of scene.slashArcs) {
		const progress = 1 - arc.life / arc.maxLife;
		ctx.save();
		ctx.translate(arc.x, arc.y);
		ctx.scale(arc.facing, 1);
		ctx.globalAlpha = Math.max(0, arc.life / arc.maxLife);
		ctx.strokeStyle = arc.color;
		ctx.shadowColor = arc.color;
		ctx.shadowBlur = 16;
		ctx.lineWidth = 7 * (1 - progress * .5);
		ctx.lineCap = "round";
		const startAng = arc.combo % 2 === 0 ? -1.1 : -.7;
		const endAng = arc.combo % 2 === 0 ? .95 : 1.15;
		ctx.beginPath();
		ctx.arc(0, 0, arc.radius, startAng, endAng);
		ctx.stroke();
		ctx.strokeStyle = "#ffffff";
		ctx.lineWidth = 2.5;
		ctx.beginPath();
		ctx.arc(0, 0, arc.radius - 2, startAng + .15, endAng - .1);
		ctx.stroke();
		ctx.restore();
	}
	for (const bolt of scene.lightningArcs) {
		if (bolt.points.length < 2) continue;
		ctx.save();
		ctx.globalAlpha = Math.max(0, bolt.life / bolt.maxLife);
		ctx.strokeStyle = bolt.color;
		ctx.shadowColor = "#38bdf8";
		ctx.shadowBlur = 16;
		ctx.lineWidth = 3.2;
		ctx.beginPath();
		ctx.moveTo(bolt.points[0].x, bolt.points[0].y);
		for (let k = 1; k < bolt.points.length; k++) {
			const prev = bolt.points[k - 1];
			const cur = bolt.points[k];
			const midX = (prev.x + cur.x) * .5 + Math.sin(time * 90 + k) * 14;
			const midY = (prev.y + cur.y) * .5 + Math.cos(time * 80 + k) * 14;
			ctx.lineTo(midX, midY);
			ctx.lineTo(cur.x, cur.y);
		}
		ctx.stroke();
		ctx.strokeStyle = "#ffffff";
		ctx.lineWidth = 1.2;
		ctx.stroke();
		ctx.restore();
	}
	for (const exp of scene.explosionWaves) {
		const progress = 1 - exp.life / exp.maxLife;
		const r = exp.radius + (exp.maxRadius - exp.radius) * progress;
		ctx.save();
		ctx.globalAlpha = Math.max(0, exp.life / exp.maxLife * .85);
		const blastGrad = ctx.createRadialGradient(exp.x, exp.y, 4, exp.x, exp.y, r);
		blastGrad.addColorStop(0, "rgba(255, 255, 255, 0.75)");
		blastGrad.addColorStop(.4, exp.color);
		blastGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
		ctx.fillStyle = blastGrad;
		ctx.beginPath();
		ctx.arc(exp.x, exp.y, r, 0, Math.PI * 2);
		ctx.fill();
		ctx.strokeStyle = "#fde047";
		ctx.lineWidth = 2.5;
		ctx.stroke();
		ctx.restore();
	}
	for (const w of scene.pulseWaves) {
		ctx.save();
		ctx.strokeStyle = costume.scarfColor;
		ctx.lineWidth = 4;
		ctx.globalAlpha = w.alpha;
		ctx.shadowColor = costume.scarfColor;
		ctx.shadowBlur = 16;
		ctx.beginPath();
		ctx.arc(w.x, w.y, w.radius, 0, Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	if (scene.particlesEnabled) {
		for (const pt of scene.particles) {
			if (!pt.active) continue;
			ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
			ctx.fillStyle = pt.color;
			ctx.beginPath();
			ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.globalAlpha = 1;
	}
	ctx.restore();
	drawForegroundFraming(ctx, viewW, viewH, cameraX * 1.22, worldId);
	if (scene.particlesEnabled) {
		ctx.fillStyle = world.particleColor;
		ctx.strokeStyle = world.particleColor;
		for (const m of scene.ambientMotes) if (worldId === "mountains") {
			const mx = ((m.x - cameraX * .65 - time * 165) % viewW + viewW) % viewW;
			const my = ((m.y + time * 115) % viewH + viewH) % viewH;
			ctx.globalAlpha = .45 + Math.sin(time * 2.5 + m.drift) * .2;
			ctx.lineWidth = Math.max(1.2, m.r * .75);
			ctx.beginPath();
			ctx.moveTo(mx, my);
			ctx.lineTo(mx - 10, my + 7);
			ctx.stroke();
		} else {
			const mx = ((m.x - cameraX * .65) % viewW + viewW) % viewW;
			const my = ((m.y + time * m.speed) % viewH + viewH) % viewH;
			const glowAlpha = .45 + Math.sin(time * 2.4 + m.drift) * .3;
			ctx.globalAlpha = glowAlpha * .35;
			ctx.beginPath();
			ctx.arc(mx, my, m.r * 2.6, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = glowAlpha;
			ctx.beginPath();
			ctx.arc(mx, my, m.r, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.globalAlpha = 1;
	}
	if (scene.timeFocusActive) {
		const tfGrad = ctx.createRadialGradient(viewW / 2, viewH / 2, viewH * .28, viewW / 2, viewH / 2, viewW * .72);
		tfGrad.addColorStop(0, "rgba(56, 189, 248, 0)");
		tfGrad.addColorStop(1, "rgba(14, 165, 233, 0.28)");
		ctx.fillStyle = tfGrad;
		ctx.fillRect(0, 0, viewW, viewH);
	}
	ctx.restore();
}
function drawSkyAtmosphere(ctx, scene, worldId, time) {
	const { viewW, viewH, cameraX } = scene;
	ctx.fillStyle = "#e2e8f0";
	for (let i = 0; i < 36; i++) {
		const sx = ((i * 197 + 43 - cameraX * .02) % viewW + viewW) % viewW;
		const sy = (i * 89 + 21) % (viewH * .48);
		ctx.globalAlpha = .2 + .5 * Math.abs(Math.sin(time * 1.5 + i));
		ctx.fillRect(sx, sy, i % 4 === 0 ? 2 : 1.4, i % 4 === 0 ? 2 : 1.4);
	}
	ctx.globalAlpha = 1;
	if (worldId === "mountains") {
		ctx.save();
		ctx.globalAlpha = .22;
		const aurGrad = ctx.createLinearGradient(0, 20, viewW, 180);
		aurGrad.addColorStop(0, "#0ea5e9");
		aurGrad.addColorStop(.5, "#2dd4bf");
		aurGrad.addColorStop(1, "#38bdf8");
		ctx.fillStyle = aurGrad;
		ctx.beginPath();
		ctx.moveTo(0, 120);
		for (let x = 0; x <= viewW; x += 60) {
			const wave = Math.sin(x * .008 + time * .55) * 26;
			ctx.lineTo(x, 95 + wave);
		}
		ctx.lineTo(viewW, 215);
		ctx.lineTo(0, 215);
		ctx.closePath();
		ctx.fill();
		ctx.restore();
	}
}
function drawParallaxRidges(ctx, viewW, viewH, scrollX, color, baseYRatio, amp, freqSeed) {
	ctx.save();
	ctx.globalAlpha = .55;
	ctx.fillStyle = color;
	ctx.beginPath();
	ctx.moveTo(0, viewH);
	const step = 44;
	for (let x = 0; x <= viewW + step; x += step) {
		const wx = x + scrollX;
		const h = Math.sin(wx * .0042 + freqSeed) * amp + Math.cos(wx * .011 - freqSeed) * (amp * .45);
		ctx.lineTo(x, viewH * baseYRatio + h);
	}
	ctx.lineTo(viewW + step, viewH);
	ctx.closePath();
	ctx.fill();
	ctx.restore();
}
function drawMidgroundSilhouettes(ctx, viewW, viewH, scrollX, worldId, color) {
	const treeSprite = spriteLibrary.getForestTile("gnarledTree");
	const spacing = worldId === "forest" ? 235 : 195;
	const startIdx = Math.floor(scrollX / spacing) - 1;
	const endIdx = startIdx + Math.ceil(viewW / spacing) + 3;
	ctx.save();
	for (let i = startIdx; i <= endIdx; i++) {
		const sx = i * spacing - scrollX;
		const baseY = viewH * .85 + Math.sin(i * 1.7) * 18;
		if (worldId === "forest") {
			if (treeSprite) {
				const sc = .78 + Math.abs(i) * 19 % 4 * .14;
				const dw = 215 * sc;
				const dh = 235 * sc;
				ctx.save();
				ctx.globalAlpha = .52;
				ctx.translate(sx, baseY);
				if (i % 2 === 0) ctx.scale(-1, 1);
				ctx.drawImage(treeSprite.canvas, -dw / 2, -dh, dw, dh);
				ctx.restore();
			} else {
				ctx.fillStyle = color;
				ctx.globalAlpha = .5;
				ctx.beginPath();
				ctx.arc(sx, baseY - 120, 48, 0, Math.PI * 2);
				ctx.arc(sx - 30, baseY - 102, 34, 0, Math.PI * 2);
				ctx.arc(sx + 32, baseY - 104, 36, 0, Math.PI * 2);
				ctx.fill();
				ctx.fillRect(sx - 9, baseY - 110, 18, 120);
			}
		} else if (worldId === "temple") {
			ctx.fillStyle = color;
			ctx.globalAlpha = .6;
			const h = 135 + Math.abs(i) * 37 % 75;
			ctx.fillRect(sx - 18, baseY - h, 36, h + viewH * .3);
			ctx.fillRect(sx - 28, baseY - h - 12, 56, 14);
			if (i % 2 === 0) ctx.fillRect(sx - 18, baseY - h, spacing + 36, 16);
		} else if (worldId === "mountains") {
			ctx.fillStyle = color;
			ctx.globalAlpha = .55;
			ctx.beginPath();
			ctx.moveTo(sx, baseY - 170);
			ctx.quadraticCurveTo(sx + 34, baseY - 60, sx + 78, viewH);
			ctx.lineTo(sx - 78, viewH);
			ctx.quadraticCurveTo(sx - 34, baseY - 60, sx, baseY - 170);
			ctx.fill();
		} else {
			ctx.fillStyle = color;
			ctx.globalAlpha = .62;
			const h = 150 + Math.abs(i) * 43 % 65;
			ctx.fillRect(sx - 26, baseY - h, 52, h + viewH * .3);
			ctx.fillRect(sx - 32, baseY - h - 16, 14, 16);
			ctx.fillRect(sx - 7, baseY - h - 16, 14, 16);
			ctx.fillRect(sx + 18, baseY - h - 16, 14, 16);
		}
	}
	ctx.restore();
}
function drawForegroundFraming(ctx, viewW, viewH, scrollX, worldId) {
	ctx.save();
	ctx.fillStyle = "#020406";
	ctx.globalAlpha = .65;
	const spacing = 460;
	const startIdx = Math.floor(scrollX / spacing) - 1;
	const endIdx = startIdx + Math.ceil(viewW / spacing) + 2;
	for (let i = startIdx; i <= endIdx; i++) {
		const fx = i * spacing - scrollX;
		if (worldId === "forest" || worldId === "temple") {
			ctx.beginPath();
			ctx.moveTo(fx - 12, 0);
			ctx.quadraticCurveTo(fx + 22, 42, fx + 62, 18);
			ctx.quadraticCurveTo(fx + 88, 48, fx + 125, 0);
			ctx.closePath();
			ctx.fill();
		} else ctx.fillRect(fx, 0, 5, 42 + Math.abs(i) % 3 * 14);
	}
	ctx.restore();
}
function drawPlatform(ctx, p, worldId, terrainColor, trimColor, accentColor, time) {
	const px = p.x + p.shakeOffset;
	const py = p.y;
	if (p.type === "bridge") {
		const dip = p.bridgeDip;
		const bridgeSprite = spriteLibrary.getForestTile("woodBridge");
		if (bridgeSprite) {
			const segW = Math.min(180, p.w);
			const count = Math.max(1, Math.round(p.w / segW));
			const eachW = p.w / count;
			const spriteH = eachW * (bridgeSprite.h / bridgeSprite.w);
			const topOffset = spriteH * .56;
			for (let i = 0; i < count; i++) ctx.drawImage(bridgeSprite.canvas, px + i * eachW - 4, py - topOffset + dip * .45, eachW + 8, spriteH);
			return;
		}
		ctx.fillStyle = "#291c12";
		ctx.fillRect(px - 3, py - 24, 7, 28);
		ctx.fillRect(px + p.w - 4, py - 24, 7, 28);
		ctx.strokeStyle = "#6b4c30";
		ctx.lineWidth = 2.5;
		ctx.beginPath();
		ctx.moveTo(px, py - 18);
		ctx.quadraticCurveTo(px + p.w / 2, py - 6 + dip, px + p.w, py - 18);
		ctx.stroke();
		const plankCount = Math.max(4, Math.floor(p.w / 20));
		const plankW = p.w / plankCount;
		for (let i = 0; i < plankCount; i++) {
			const t = (i + .5) / plankCount;
			const arch = 4 * t * (1 - t) * dip;
			ctx.fillStyle = "#3f2b1c";
			ctx.fillRect(px + i * plankW + 1.5, py + arch, plankW - 3, 11);
		}
		return;
	}
	if (p.type === "gate") {
		if (p.gateOpen) {
			ctx.fillStyle = "rgba(255,255,255,0.12)";
			ctx.fillRect(px + 4, py, p.w - 8, 12);
			return;
		}
		ctx.fillStyle = "#12131a";
		ctx.fillRect(px, py, p.w, p.h);
		ctx.strokeStyle = accentColor;
		ctx.lineWidth = 2;
		ctx.strokeRect(px + 2, py + 2, p.w - 4, p.h - 4);
		ctx.fillStyle = accentColor;
		ctx.globalAlpha = .7 + Math.sin(time * 6) * .25;
		ctx.fillRect(px + p.w / 2 - 3, py + 16, 6, p.h - 32);
		ctx.globalAlpha = 1;
		return;
	}
	if (p.type === "ice") {
		const iceSprite = spriteLibrary.getDungeonTile("iceLedge");
		if (iceSprite) {
			const tileW = Math.min(165, p.w);
			const count = Math.max(1, Math.round(p.w / tileW));
			const eachW = p.w / count;
			const spriteH = Math.max(p.h + 26, eachW * (iceSprite.h / iceSprite.w));
			for (let i = 0; i < count; i++) ctx.drawImage(iceSprite.canvas, px + i * eachW - 4, py - 5, eachW + 8, spriteH);
			return;
		}
	}
	if (worldId === "forest") {
		const isThinLedge = p.type === "moving" || p.h <= 48;
		const ledgeTile = spriteLibrary.getForestTile("mossLedge");
		const groundTile = spriteLibrary.getForestTile("mossGround");
		if (isThinLedge && ledgeTile) {
			const targetH = Math.max(54, p.h + 30);
			const tileW = Math.min(180, p.w);
			const count = Math.max(1, Math.round(p.w / tileW));
			const eachW = p.w / count;
			for (let i = 0; i < count; i++) ctx.drawImage(ledgeTile.canvas, px + i * eachW - 6, py - 8, eachW + 12, targetH);
			if (p.type === "falling" && p.fallState === "shaking") {
				ctx.fillStyle = "rgba(239, 68, 68, 0.35)";
				ctx.fillRect(px, py, p.w, 6);
			}
			if (p.concealsSecret) {
				ctx.fillStyle = "rgba(250, 204, 21, 0.45)";
				ctx.fillRect(px, py, p.w, 3);
			}
			return;
		}
		if (!isThinLedge && groundTile) {
			ctx.save();
			const rockGrad = ctx.createLinearGradient(0, py, 0, py + p.h);
			rockGrad.addColorStop(0, "#141c1d");
			rockGrad.addColorStop(1, "#040608");
			ctx.fillStyle = rockGrad;
			ctx.fillRect(px, py + 4, p.w, p.h - 4);
			ctx.beginPath();
			ctx.rect(px - 4, py - 16, p.w + 8, p.h + 18);
			ctx.clip();
			const tileW = 190;
			const tileH = Math.min(p.h + 16, 155);
			for (let tx = px; tx < px + p.w; tx += 184) ctx.drawImage(groundTile.canvas, tx, py - 12, tileW, tileH);
			ctx.restore();
			if (p.concealsSecret) {
				ctx.fillStyle = "rgba(250, 204, 21, 0.45)";
				ctx.fillRect(px, py, p.w, 3);
			}
			return;
		}
	}
	const stoneTile = worldId === "fortress" ? spriteLibrary.getDungeonTile("fortressStone") : spriteLibrary.getDungeonTile("templeStone");
	if (stoneTile) {
		ctx.save();
		ctx.fillStyle = terrainColor;
		ctx.fillRect(px, py, p.w, p.h);
		ctx.beginPath();
		ctx.rect(px, py, p.w, p.h);
		ctx.clip();
		const blockW = Math.min(110, Math.max(46, p.h > 80 ? 84 : p.h * 1.4));
		const blockH = Math.min(96, Math.max(36, p.h));
		for (let by = py; by < py + p.h; by += blockH - 2) for (let bx = px; bx < px + p.w; bx += blockW - 2) ctx.drawImage(stoneTile.canvas, bx, by, blockW, blockH);
		ctx.restore();
		if (p.type === "moving") {
			ctx.fillStyle = accentColor;
			ctx.fillRect(px + 8, py + p.h / 2 - 2, p.w - 16, 3);
		} else if (p.type === "falling" && p.fallState === "shaking") {
			ctx.fillStyle = "rgba(239, 68, 68, 0.4)";
			ctx.fillRect(px, py, p.w, 5);
		}
		if (p.concealsSecret) {
			ctx.fillStyle = "rgba(250, 204, 21, 0.45)";
			ctx.fillRect(px, py, p.w, 3);
		}
		return;
	}
	ctx.fillStyle = terrainColor;
	ctx.fillRect(px, py, p.w, p.h);
	ctx.fillStyle = trimColor;
	ctx.fillRect(px, py, p.w, 6);
}
function drawHazard(ctx, h, accentColor, time) {
	if (h.type === "spikes") {
		const spikeSprite = spriteLibrary.getDungeonTile("spikes");
		if (spikeSprite) {
			ctx.drawImage(spikeSprite.canvas, h.x - 4, h.y - 6, h.w + 8, h.h + 10);
			return;
		}
		const spikeCount = Math.max(2, Math.floor(h.w / 11));
		const sw = h.w / spikeCount;
		for (let i = 0; i < spikeCount; i++) {
			const sx = h.x + i * sw;
			ctx.fillStyle = "#09090b";
			ctx.beginPath();
			ctx.moveTo(sx, h.y + h.h);
			ctx.lineTo(sx + sw * .5, h.y);
			ctx.lineTo(sx + sw, h.y + h.h);
			ctx.closePath();
			ctx.fill();
		}
		return;
	}
	if (h.type === "saw") {
		const cx = h.x + (h.bobX || 0);
		const cy = h.y;
		const r = h.w * .55;
		const sawSprite = spriteLibrary.getDungeonTile("sawBlade");
		ctx.save();
		ctx.translate(cx, cy);
		ctx.rotate(h.angle);
		if (sawSprite) {
			ctx.drawImage(sawSprite.canvas, -r, -r, r * 2, r * 2);
			ctx.restore();
			return;
		}
		ctx.fillStyle = "#09090b";
		ctx.beginPath();
		ctx.arc(0, 0, r, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
		return;
	}
	if (h.type === "pendulum" && h.anchorX !== void 0 && h.anchorY !== void 0) {
		const bx = h.bobX ?? h.x;
		const by = h.bobY ?? h.y;
		ctx.strokeStyle = "#64748b";
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.moveTo(h.anchorX, h.anchorY);
		ctx.lineTo(bx, by);
		ctx.stroke();
		const sawSprite = spriteLibrary.getDungeonTile("sawBlade");
		if (sawSprite) {
			ctx.save();
			ctx.translate(bx, by);
			ctx.rotate(time * 6);
			ctx.drawImage(sawSprite.canvas, -22, -22, 44, 44);
			ctx.restore();
		} else {
			ctx.fillStyle = "#09090b";
			ctx.beginPath();
			ctx.arc(bx, by, 18, 0, Math.PI * 2);
			ctx.fill();
			ctx.strokeStyle = accentColor;
			ctx.lineWidth = 2;
			ctx.stroke();
		}
		return;
	}
	if (h.type === "fallingRock") {
		if (h.warning) {
			ctx.fillStyle = "rgba(239, 68, 68, 0.85)";
			ctx.beginPath();
			ctx.arc(h.x + h.w / 2, h.y + 8, 6 + Math.sin(time * 18) * 2, 0, Math.PI * 2);
			ctx.fill();
		}
		if (!h.active) return;
		ctx.fillStyle = "#1e293b";
		ctx.beginPath();
		ctx.moveTo(h.x + h.w * .5, h.y);
		ctx.lineTo(h.x + h.w, h.y + h.h * .45);
		ctx.lineTo(h.x + h.w * .75, h.y + h.h);
		ctx.lineTo(h.x + h.w * .2, h.y + h.h);
		ctx.lineTo(h.x, h.y + h.h * .4);
		ctx.closePath();
		ctx.fill();
		ctx.strokeStyle = "#94a3b8";
		ctx.lineWidth = 1.5;
		ctx.stroke();
		return;
	}
	if (h.type === "fireJet") {
		ctx.fillStyle = "#18181b";
		ctx.fillRect(h.x, h.y + h.h - 10, h.w, 10);
		if (h.warning && !h.active) {
			ctx.fillStyle = "#f97316";
			ctx.globalAlpha = .55 + Math.sin(time * 22) * .35;
			ctx.beginPath();
			ctx.arc(h.x + h.w / 2, h.y + h.h - 14, 7, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 1;
			return;
		}
		if (h.active) {
			const grad = ctx.createLinearGradient(0, h.y + h.h, 0, h.y);
			grad.addColorStop(0, "#ef4444");
			grad.addColorStop(.5, "#f97316");
			grad.addColorStop(1, "rgba(253, 224, 71, 0.15)");
			ctx.fillStyle = grad;
			ctx.fillRect(h.x + 3, h.y, h.w - 6, h.h - 10);
		}
		return;
	}
	if (h.type === "hiddenSpikes") {
		ctx.fillStyle = "#1e293b";
		ctx.fillRect(h.x, h.y + h.h - 4, h.w, 4);
		if (h.warning && !h.active) {
			ctx.fillStyle = "rgba(239, 68, 68, 0.85)";
			ctx.fillRect(h.x + 2, h.y + h.h - 5, h.w - 4, 2);
		} else if (h.active) {
			const spikeSprite = spriteLibrary.getDungeonTile("spikes");
			if (spikeSprite) ctx.drawImage(spikeSprite.canvas, h.x - 4, h.y - 6, h.w + 8, h.h + 10);
		}
		return;
	}
	if (h.type === "dangerZone") {
		const dzGrad = ctx.createLinearGradient(0, h.y, 0, h.y + h.h);
		dzGrad.addColorStop(0, accentColor);
		dzGrad.addColorStop(1, "rgba(5, 5, 10, 0.95)");
		ctx.save();
		ctx.globalAlpha = .45 + Math.sin(time * 4) * .12;
		ctx.fillStyle = dzGrad;
		ctx.fillRect(h.x, h.y, h.w, h.h);
		ctx.fillStyle = "#ffffff";
		for (let bx = h.x + 14; bx < h.x + h.w - 14; bx += 32) {
			const by = h.y + 4 + Math.sin(time * 5 + bx) * 3;
			ctx.beginPath();
			ctx.arc(bx, by, 2.5, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.restore();
	}
}
function drawCollectible(ctx, c, time) {
	const cy = c.y + Math.sin(time * 3.5 + c.bobOffset) * 5;
	ctx.save();
	if (c.type === "coin") {
		const coinSprite = spriteLibrary.getDungeonTile("coin");
		ctx.shadowColor = "#facc15";
		ctx.shadowBlur = 12;
		if (coinSprite) {
			ctx.drawImage(coinSprite.canvas, c.x - 13, cy - 13, 26, 26);
			ctx.restore();
			return;
		}
		ctx.fillStyle = "#eab308";
		ctx.beginPath();
		ctx.arc(c.x, cy, 9, 0, Math.PI * 2);
		ctx.fill();
	} else if (c.type === "crystal") {
		const crySprite = spriteLibrary.getDungeonTile("crystal");
		ctx.shadowColor = "#38bdf8";
		ctx.shadowBlur = 16;
		if (crySprite) {
			ctx.drawImage(crySprite.canvas, c.x - 14, cy - 17, 28, 34);
			ctx.restore();
			return;
		}
		ctx.fillStyle = "#0ea5e9";
		ctx.beginPath();
		ctx.moveTo(c.x, cy - 14);
		ctx.lineTo(c.x + 9, cy);
		ctx.lineTo(c.x, cy + 14);
		ctx.lineTo(c.x - 9, cy);
		ctx.closePath();
		ctx.fill();
	} else {
		const chestSprite = spriteLibrary.getDungeonTile("treasureChest");
		ctx.shadowColor = c.type === "secret" ? "#c084fc" : "#f59e0b";
		ctx.shadowBlur = 18;
		if (chestSprite) {
			ctx.drawImage(chestSprite.canvas, c.x - 18, cy - 15, 36, 30);
			ctx.restore();
			return;
		}
		ctx.fillStyle = c.type === "secret" ? "#a855f7" : "#d97706";
		ctx.fillRect(c.x - 12, cy - 9, 24, 18);
	}
	ctx.restore();
}
function drawCheckpoint(ctx, cp, accentColor, time) {
	const x = cp.x;
	const y = cp.y;
	const lanternSprite = spriteLibrary.getForestTile("stoneLantern");
	if (lanternSprite) {
		const h = 76;
		const w = h * (lanternSprite.w / lanternSprite.h);
		ctx.drawImage(lanternSprite.canvas, x - w / 2, y - h + 3, w, h);
	} else {
		ctx.fillStyle = "#07080c";
		ctx.fillRect(x - 12, y - 6, 24, 6);
		ctx.fillRect(x - 4, y - 48, 8, 42);
	}
	if (cp.activated) {
		ctx.save();
		const glow = ctx.createRadialGradient(x, y - 44, 2, x, y - 44, 52);
		glow.addColorStop(0, accentColor);
		glow.addColorStop(1, "rgba(0,0,0,0)");
		ctx.globalAlpha = .55;
		ctx.fillStyle = glow;
		ctx.beginPath();
		ctx.arc(x, y - 44, 52, 0, Math.PI * 2);
		ctx.fill();
		ctx.globalAlpha = 1;
		ctx.shadowColor = accentColor;
		ctx.shadowBlur = 18;
		ctx.fillStyle = "#ffffff";
		ctx.beginPath();
		ctx.arc(x, y - 44, 5 + Math.sin(time * 8) * 1.2, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	}
}
function drawExitPortal(ctx, exit, locked, accentColor, time) {
	const cx = exit.x + exit.w / 2;
	const cy = exit.y + exit.h / 2;
	const portalSprite = spriteLibrary.getForestTile("portalArch");
	ctx.save();
	if (portalSprite) {
		const ph = exit.h + 24;
		const pw = ph * (portalSprite.w / portalSprite.h);
		ctx.globalAlpha = locked ? .55 : 1;
		ctx.drawImage(portalSprite.canvas, cx - pw / 2, exit.y + exit.h - ph + 4, pw, ph);
	} else {
		ctx.fillStyle = "#050507";
		ctx.fillRect(exit.x, exit.y + 10, 10, exit.h - 10);
		ctx.fillRect(exit.x + exit.w - 10, exit.y + 10, 10, exit.h - 10);
	}
	const portalColor = locked ? "#64748b" : accentColor;
	ctx.shadowColor = portalColor;
	ctx.shadowBlur = locked ? 6 : 26;
	ctx.fillStyle = portalColor;
	ctx.globalAlpha = locked ? .18 : .32 + Math.sin(time * 4) * .14;
	ctx.beginPath();
	ctx.ellipse(cx, cy + 6, exit.w * .34, exit.h * .36, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.restore();
}
function drawDecoration(ctx, deco, worldId, terrainColor, accentColor, time) {
	ctx.save();
	ctx.translate(deco.x, deco.y);
	ctx.scale(deco.scale, deco.scale);
	if (deco.kind === "pine") {
		const treeSprite = spriteLibrary.getForestTile("gnarledTree");
		if (treeSprite) {
			const th = 205;
			const tw = th * (treeSprite.w / treeSprite.h);
			ctx.drawImage(treeSprite.canvas, -tw / 2, -197, tw, th);
			ctx.restore();
			return;
		}
		ctx.fillStyle = terrainColor;
		ctx.beginPath();
		ctx.arc(0, -110, 44, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillRect(-7, -110, 14, 110);
	} else if (deco.kind === "lantern") {
		const lanternSprite = spriteLibrary.getForestTile("stoneLantern");
		if (lanternSprite) {
			const lh = 72;
			const lw = lh * (lanternSprite.w / lanternSprite.h);
			ctx.drawImage(lanternSprite.canvas, -lw / 2, -68, lw, lh);
		} else {
			ctx.fillStyle = terrainColor;
			ctx.fillRect(-5, -36, 10, 36);
		}
		const flicker = 36 + Math.sin(time * 9 + deco.x) * 5;
		const halo = ctx.createRadialGradient(0, -45, 2, 0, -45, flicker);
		halo.addColorStop(0, "rgba(251, 191, 36, 0.55)");
		halo.addColorStop(1, "rgba(251, 191, 36, 0)");
		ctx.fillStyle = halo;
		ctx.beginPath();
		ctx.arc(0, -45, flicker, 0, Math.PI * 2);
		ctx.fill();
	} else if (deco.kind === "statue" || deco.kind === "brazier") {
		const statueSprite = spriteLibrary.getDungeonTile("statueBrazier");
		if (statueSprite) {
			const sh = 92;
			const sw = sh * (statueSprite.w / statueSprite.h);
			ctx.drawImage(statueSprite.canvas, -sw / 2, -88, sw, sh);
		} else {
			ctx.fillStyle = terrainColor;
			ctx.fillRect(-14, -60, 28, 60);
		}
		const flicker = 34 + Math.sin(time * 9 + deco.x) * 4;
		const halo = ctx.createRadialGradient(16, -24, 2, 16, -24, flicker);
		halo.addColorStop(0, "rgba(251, 146, 60, 0.48)");
		halo.addColorStop(1, "rgba(251, 146, 60, 0)");
		ctx.fillStyle = halo;
		ctx.beginPath();
		ctx.arc(16, -24, flicker, 0, Math.PI * 2);
		ctx.fill();
	} else if (deco.kind === "waterfall") {
		const wGrad = ctx.createLinearGradient(0, -240, 0, 120);
		wGrad.addColorStop(0, "rgba(186, 230, 253, 0.08)");
		wGrad.addColorStop(.5, "rgba(110, 231, 183, 0.28)");
		wGrad.addColorStop(1, "rgba(186, 230, 253, 0.03)");
		ctx.fillStyle = wGrad;
		ctx.fillRect(-26, -240, 52, 360);
		ctx.strokeStyle = "rgba(224, 242, 254, 0.36)";
		ctx.lineWidth = 2;
		for (let i = -2; i <= 2; i++) {
			const offset = (time * 105 + i * 47) % 300;
			ctx.beginPath();
			ctx.moveTo(i * 10, -230 + offset);
			ctx.lineTo(i * 10, -195 + offset);
			ctx.stroke();
		}
	} else if (deco.kind === "torii") {
		ctx.fillStyle = worldId === "forest" ? "#131d1d" : terrainColor;
		ctx.fillRect(-36, -110, 10, 110);
		ctx.fillRect(26, -110, 10, 110);
		ctx.fillRect(-48, -114, 96, 10);
		ctx.fillRect(-40, -96, 80, 7);
	} else if (deco.kind === "pillar") {
		ctx.fillStyle = terrainColor;
		ctx.fillRect(-14, -185, 28, 185);
		ctx.fillRect(-22, -190, 44, 12);
	} else if (deco.kind === "banner") {
		ctx.fillStyle = terrainColor;
		ctx.fillRect(-3, -104, 6, 104);
		ctx.fillStyle = accentColor;
		ctx.globalAlpha = .52;
		const sway = Math.sin(time * 3 + deco.x) * 4;
		ctx.beginPath();
		ctx.moveTo(3, -98);
		ctx.lineTo(30 + sway, -84);
		ctx.lineTo(3, -64);
		ctx.closePath();
		ctx.fill();
	} else if (deco.kind === "shrine") {
		ctx.fillStyle = terrainColor;
		ctx.fillRect(-16, -24, 32, 24);
		ctx.beginPath();
		ctx.moveTo(-22, -24);
		ctx.lineTo(0, -44);
		ctx.lineTo(22, -24);
		ctx.closePath();
		ctx.fill();
	}
	ctx.restore();
}
function drawEnemy(ctx, e, accentColor, worldId, time) {
	const cx = e.x + e.w / 2;
	const footY = e.y + e.h + 2;
	ctx.save();
	if (!e.alive && e.defeatTimer > 0) {
		const t = e.defeatTimer / .4;
		ctx.globalAlpha = t;
		ctx.translate(cx, footY - (1 - t) * 28);
		ctx.scale(1 + (1 - t) * .4, t);
		ctx.translate(-cx, -footY);
	}
	const enemySprite = spriteLibrary.getEnemySprite(e.type);
	const isFlying = e.type === "spirit" || e.type === "mage" || e.type === "elite";
	const hoverOffset = isFlying ? Math.sin(time * 4.2 + e.animTime) * 6 : 0;
	const walkBob = !isFlying && (e.state === "patrol" || e.state === "approach") ? Math.abs(Math.sin(e.animTime * 9)) * 3.5 : Math.sin(time * 3 + e.animTime) * 1.2;
	const walkTilt = e.state === "patrol" || e.state === "approach" ? Math.sin(e.animTime * 9) * .055 * e.facing : e.telegraphTimer > 0 ? -.14 * e.facing : e.attackAnimTimer > 0 ? .16 * e.facing : e.state === "hurt" ? -.2 * e.facing : 0;
	if (e.hitFlash > 0) {
		ctx.shadowColor = "#ffffff";
		ctx.shadowBlur = 22;
	} else if (e.telegraphTimer > 0) {
		ctx.shadowColor = "#ef4444";
		ctx.shadowBlur = 20;
	} else if (e.type === "boss" || e.type === "miniboss") {
		ctx.shadowColor = accentColor;
		ctx.shadowBlur = 16;
	}
	if (enemySprite) {
		const targetH = e.type === "boss" ? 124 : e.type === "miniboss" ? 92 : e.type === "elite" ? 70 : e.type === "guardian" ? 68 : e.type === "mage" ? 64 : e.type === "spirit" ? 58 : e.type === "hunter" ? 50 : 64;
		const targetW = targetH * (enemySprite.w / enemySprite.h);
		ctx.save();
		ctx.translate(cx, footY + hoverOffset - walkBob);
		ctx.rotate(walkTilt);
		ctx.scale(e.facing, 1);
		if (!isFlying) {
			ctx.fillStyle = "rgba(0,0,0,0.42)";
			ctx.beginPath();
			ctx.ellipse(0, walkBob, targetW * .28, 4, 0, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.drawImage(enemySprite.canvas, -targetW / 2, -targetH, targetW, targetH);
		if (e.hitFlash > 0) {
			ctx.globalCompositeOperation = "source-atop";
			ctx.fillStyle = "rgba(255, 255, 255, 0.55)";
			ctx.fillRect(-targetW / 2, -targetH, targetW, targetH);
		} else if (e.slowTimer > 0) {
			ctx.globalCompositeOperation = "source-atop";
			ctx.fillStyle = "rgba(56, 189, 248, 0.35)";
			ctx.fillRect(-targetW / 2, -targetH, targetW, targetH);
		} else if (e.burnTimer > 0) {
			ctx.globalCompositeOperation = "source-atop";
			ctx.fillStyle = "rgba(249, 115, 22, 0.35)";
			ctx.fillRect(-targetW / 2, -targetH, targetW, targetH);
		}
		ctx.restore();
	} else {
		ctx.fillStyle = e.hitFlash > 0 ? "#f8fafc" : "#090b10";
		ctx.fillRect(cx - e.w * .35, e.y + 8 + hoverOffset, e.w * .7, e.h - 8);
		ctx.fillStyle = worldId === "forest" ? "#10b981" : "#ef4444";
		ctx.fillRect(cx + e.facing * 4, e.y + 12 + hoverOffset, 5, 3);
	}
	if (e.alive) {
		if (e.burnTimer > 0) {
			ctx.fillStyle = "#fb923c";
			for (let f = 0; f < 3; f++) {
				const fx = cx + Math.sin(time * 12 + f * 2.1) * (e.w * .38);
				const fy = e.y + e.h * .4 + Math.cos(time * 10 + f * 1.7) * 10 + hoverOffset;
				ctx.beginPath();
				ctx.arc(fx, fy, 3.2, 0, Math.PI * 2);
				ctx.fill();
			}
		}
		if (e.slowTimer > 0) {
			ctx.strokeStyle = "#67e8f9";
			ctx.lineWidth = 1.6;
			ctx.beginPath();
			ctx.arc(cx, e.y + e.h * .55 + hoverOffset, e.w * .56, time * 2, time * 2 + Math.PI * 1.4);
			ctx.stroke();
		}
		if (e.telegraphTimer > 0) {
			ctx.fillStyle = "#ef4444";
			ctx.font = "bold 16px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("!", cx, e.y - 14 + hoverOffset);
		}
		if (e.maxHp > 1 && e.hp < e.maxHp) {
			const bw = Math.max(32, e.w * .9);
			ctx.fillStyle = "rgba(0,0,0,0.72)";
			ctx.fillRect(cx - bw / 2, e.y - 10 + hoverOffset, bw, 4.5);
			ctx.fillStyle = "#ef4444";
			ctx.fillRect(cx - bw / 2, e.y - 10 + hoverOffset, bw * (e.hp / e.maxHp), 4.5);
		}
	}
	ctx.restore();
}
function drawNinja(ctx, p, costumeId, bodyColor, scarfColor, eyeColor, accentGlow, time) {
	ctx.save();
	if (p.defeatTimer > 0) {
		const t = Math.max(0, 1 - p.defeatTimer / .65);
		ctx.globalAlpha = t;
		ctx.translate(p.x + p.w / 2, p.y + p.h / 2 - p.defeatTimer * 35);
		ctx.scale(1 + p.defeatTimer * .5, t);
		ctx.translate(-(p.x + p.w / 2), -(p.y + p.h / 2));
	} else if (p.invulnTimer > 0 && Math.floor(p.invulnTimer * 18) % 2 === 0) ctx.globalAlpha = .45;
	if (p.shieldCharges > 0) {
		ctx.save();
		ctx.strokeStyle = "#38bdf8";
		ctx.lineWidth = 2;
		ctx.globalAlpha = .58;
		ctx.setLineDash([8, 6]);
		ctx.beginPath();
		ctx.arc(p.x + p.w / 2, p.y + p.h / 2, 32 + Math.sin(time * 4) * 1.5, time * 2.2, time * 2.2 + Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	if (p.reviveShieldTimer && p.reviveShieldTimer > 0) {
		const fade = Math.min(1, p.reviveShieldTimer / .8);
		ctx.save();
		ctx.strokeStyle = "#fbbf24";
		ctx.fillStyle = "rgba(251, 191, 36, 0.12)";
		ctx.lineWidth = 2.6;
		ctx.globalAlpha = .78 * fade;
		ctx.shadowColor = "#fbbf24";
		ctx.shadowBlur = 12;
		ctx.beginPath();
		ctx.arc(p.x + p.w / 2, p.y + p.h / 2, 37 + Math.sin(time * 7) * 2.2, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.strokeStyle = "#34d399";
		ctx.lineWidth = 1.6;
		ctx.setLineDash([6, 5]);
		ctx.beginPath();
		ctx.arc(p.x + p.w / 2, p.y + p.h / 2, 43 + Math.cos(time * 5) * 1.5, -time * 3.1, -time * 3.1 + Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	if (p.scarfNodes.length > 1) {
		ctx.save();
		ctx.strokeStyle = scarfColor;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.shadowColor = accentGlow;
		ctx.shadowBlur = 10;
		for (let i = 0; i < p.scarfNodes.length - 1; i++) {
			const a = p.scarfNodes[i];
			const b = p.scarfNodes[i + 1];
			ctx.lineWidth = Math.max(1.8, 6.2 - i * .65);
			ctx.beginPath();
			ctx.moveTo(a.x, a.y);
			ctx.lineTo(b.x, b.y);
			ctx.stroke();
		}
		ctx.restore();
	}
	drawNinjaSprite(ctx, p, costumeId, bodyColor, eyeColor, false, time);
	if (p.bowAiming || p.bowReleaseTimer > 0) drawNinjaBowOverlay(ctx, p, time);
	ctx.restore();
}
function drawNinjaBowOverlay(ctx, p, time) {
	const cx = p.x + p.w / 2;
	const cy = p.y + p.h * .44;
	const bowSprite = spriteLibrary.getBowSprite("bow");
	const arrowDef = ARROW_MAP[p.activeArrowType];
	const arrowSprite = spriteLibrary.getBowSprite(`arrow_${p.activeArrowType}`);
	const pullback = p.bowAiming ? p.bowCharge * 10 : 0;
	ctx.save();
	ctx.translate(cx, cy);
	ctx.rotate(p.bowAngle);
	if (p.bowAiming && p.bowCharge >= .72) {
		ctx.save();
		ctx.globalAlpha = .35 + Math.sin(time * 18) * .18;
		ctx.fillStyle = arrowDef.glowColor;
		ctx.beginPath();
		ctx.arc(16, 0, 12, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	}
	ctx.strokeStyle = arrowDef.glowColor;
	ctx.lineWidth = p.bowAiming ? 2 : 1.4;
	ctx.shadowColor = arrowDef.glowColor;
	ctx.shadowBlur = 8;
	ctx.beginPath();
	ctx.moveTo(6, -18);
	ctx.lineTo(2 - pullback, 0);
	ctx.lineTo(6, 18);
	ctx.stroke();
	if (bowSprite) {
		const bh = 42;
		const bw = bh * (bowSprite.w / bowSprite.h);
		ctx.drawImage(bowSprite.canvas, 3, -21, bw, bh);
	} else {
		ctx.strokeStyle = "#1e293b";
		ctx.lineWidth = 3.5;
		ctx.beginPath();
		ctx.arc(4, 0, 18, -Math.PI * .45, Math.PI * .45);
		ctx.stroke();
	}
	if (p.bowAiming) {
		const ax = 6 - pullback;
		ctx.shadowColor = arrowDef.glowColor;
		ctx.shadowBlur = 12;
		if (arrowSprite) {
			const aw = 34;
			const ah = aw * (arrowSprite.h / arrowSprite.w);
			ctx.drawImage(arrowSprite.canvas, ax - 8, -ah / 2, aw, ah);
		} else {
			ctx.strokeStyle = arrowDef.color;
			ctx.lineWidth = 2.5;
			ctx.beginPath();
			ctx.moveTo(ax - 8, 0);
			ctx.lineTo(ax + 20, 0);
			ctx.stroke();
		}
	}
	ctx.restore();
}
function drawMagicalArrowProjectile(ctx, proj, time) {
	const arrowType = proj.arrowType || "shadow";
	const arrowDef = ARROW_MAP[arrowType];
	const arrowSprite = spriteLibrary.getBowSprite(`arrow_${arrowType}`);
	const angle = Math.atan2(proj.vy, proj.vx);
	ctx.save();
	ctx.translate(proj.x, proj.y);
	ctx.rotate(angle);
	const trailLen = proj.charged ? 42 : 28;
	const trailGrad = ctx.createLinearGradient(-trailLen, 0, 6, 0);
	trailGrad.addColorStop(0, "rgba(0,0,0,0)");
	trailGrad.addColorStop(.55, arrowDef.glowColor);
	trailGrad.addColorStop(1, "#ffffff");
	ctx.fillStyle = trailGrad;
	ctx.globalAlpha = .78;
	ctx.beginPath();
	ctx.moveTo(-trailLen, 0);
	ctx.lineTo(4, -3.5);
	ctx.lineTo(4, 3.5);
	ctx.closePath();
	ctx.fill();
	ctx.globalAlpha = 1;
	ctx.shadowColor = arrowDef.glowColor;
	ctx.shadowBlur = proj.charged ? 18 : 12;
	if (arrowSprite) {
		const aw = proj.charged ? 40 : 34;
		const ah = aw * (arrowSprite.h / arrowSprite.w);
		ctx.drawImage(arrowSprite.canvas, -aw * .68, -ah / 2, aw, ah);
	} else {
		ctx.strokeStyle = arrowDef.color;
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.moveTo(-18, 0);
		ctx.lineTo(10, 0);
		ctx.stroke();
		ctx.fillStyle = arrowDef.glowColor;
		ctx.beginPath();
		ctx.moveTo(14, 0);
		ctx.lineTo(6, -4.5);
		ctx.lineTo(6, 4.5);
		ctx.closePath();
		ctx.fill();
	}
	if (arrowType === "lightning") {
		ctx.strokeStyle = "#fde047";
		ctx.lineWidth = 1.5;
		ctx.beginPath();
		ctx.moveTo(-14, Math.sin(time * 60) * 4);
		ctx.lineTo(-4, -Math.sin(time * 60) * 4);
		ctx.lineTo(6, Math.cos(time * 55) * 3);
		ctx.stroke();
	}
	ctx.restore();
}
function drawTrajectoryPreview(ctx, preview, time) {
	const def = ARROW_MAP[preview.arrowType];
	const pts = preview.points;
	if (pts.length === 0) return;
	ctx.save();
	for (let i = 0; i < pts.length; i++) {
		const pt = pts[i];
		const t = i / pts.length;
		ctx.globalAlpha = (1 - t * .72) * (.48 + preview.chargeRatio * .45);
		ctx.fillStyle = preview.chargeRatio >= .72 ? "#fde047" : def.color;
		ctx.shadowColor = def.glowColor;
		ctx.shadowBlur = 8;
		const r = Math.max(1.8, (1 - t * .55) * (preview.chargeRatio >= .72 ? 3.8 : 3));
		ctx.beginPath();
		ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
		ctx.fill();
	}
	const tip = pts[Math.min(pts.length - 1, 7)];
	ctx.globalAlpha = .85;
	ctx.strokeStyle = preview.chargeRatio >= .72 ? "#fde047" : def.glowColor;
	ctx.lineWidth = 1.8;
	const ringR = 9 + Math.sin(time * 12) * 1.5;
	ctx.beginPath();
	ctx.arc(tip.x, tip.y, ringR, 0, Math.PI * 2);
	ctx.stroke();
	ctx.beginPath();
	ctx.moveTo(tip.x - ringR - 4, tip.y);
	ctx.lineTo(tip.x - 4, tip.y);
	ctx.moveTo(tip.x + 4, tip.y);
	ctx.lineTo(tip.x + ringR + 4, tip.y);
	ctx.moveTo(tip.x, tip.y - ringR - 4);
	ctx.lineTo(tip.x, tip.y - 4);
	ctx.moveTo(tip.x, tip.y + 4);
	ctx.lineTo(tip.x, tip.y + ringR + 4);
	ctx.stroke();
	ctx.restore();
}
function selectNinjaSpriteKey(p) {
	switch (p.animState) {
		case "victory": return "victory";
		case "hurt":
		case "defeat": return "hurt";
		case "ability":
		case "bowAim":
		case "bowRelease": return p.animState === "bowAim" ? "ability" : p.animState === "bowRelease" ? "attack" : "ability";
		case "dash": return "dash";
		case "attack": return "attack";
		case "doubleJump": return "doubleJump";
		case "jump":
		case "wallSlide": return "jump";
		case "fall": return "fall";
		case "land": return "land";
		case "run": return Math.sin(p.runCycle) >= 0 ? "runA" : "runB";
		default: return "idle";
	}
}
function drawNinjaSprite(ctx, p, costumeId, bodyColor, eyeColor, isGhost, time) {
	const spriteKey = selectNinjaSpriteKey(p);
	const sprite = spriteLibrary.getNinjaSprite(spriteKey, costumeId);
	const cx = p.x + p.w / 2;
	const cy = p.y + p.h / 2;
	const footY = p.y + p.h + 2;
	ctx.save();
	if (!isGhost && p.abilityTimer > 0) {
		ctx.save();
		ctx.strokeStyle = "#38bdf8";
		ctx.lineWidth = 2.5;
		ctx.globalAlpha = Math.min(1, p.abilityTimer * 3);
		ctx.beginPath();
		ctx.arc(cx, cy, 34 - p.abilityTimer * 25, 0, Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	if (!isGhost && p.victoryTimer > 0) {
		ctx.save();
		const glow = ctx.createRadialGradient(cx, cy - 6, 4, cx, cy - 6, 42);
		glow.addColorStop(0, "rgba(250, 204, 21, 0.55)");
		glow.addColorStop(1, "rgba(250, 204, 21, 0)");
		ctx.fillStyle = glow;
		ctx.beginPath();
		ctx.arc(cx, cy - 6, 42, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	}
	if (sprite) {
		const baseH = spriteKey === "doubleJump" ? 52 : spriteKey === "land" ? 48 : spriteKey === "victory" ? 68 : 60;
		const drawW = baseH * (sprite.w / sprite.h);
		if (p.doubleJumpSpin > 0) {
			ctx.translate(cx, cy);
			ctx.rotate(p.doubleJumpSpin * p.facing);
			ctx.scale(p.facing, 1);
			ctx.drawImage(sprite.canvas, -drawW / 2, -baseH / 2, drawW, baseH);
		} else {
			ctx.translate(cx, footY);
			const idleScaleY = p.animState === "idle" ? 1 + Math.sin(time * 3.8) * .018 : 1;
			const squashY = p.landSquashTimer > 0 ? .9 : idleScaleY;
			const squashX = p.landSquashTimer > 0 ? 1.1 : 1;
			ctx.scale(p.facing * squashX, squashY);
			if (!isGhost && p.onGround) {
				ctx.fillStyle = "rgba(0,0,0,0.38)";
				ctx.beginPath();
				ctx.ellipse(0, 0, 15, 3.5, 0, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.drawImage(sprite.canvas, -drawW / 2, -baseH, drawW, baseH);
		}
		ctx.restore();
		return;
	}
	ctx.translate(cx, cy);
	ctx.fillStyle = bodyColor;
	ctx.fillRect(-10, -14, 20, 32);
	ctx.beginPath();
	ctx.arc(0, -16, 9, 0, Math.PI * 2);
	ctx.fill();
	if (!isGhost) {
		ctx.fillStyle = eyeColor;
		ctx.fillRect(p.facing > 0 ? 2 : -7, -18, 5, 2.5);
	}
	ctx.restore();
}
// src/game/save.ts
var STORAGE_KEY = "shadow_ninja_dark_quest_save_v1";
function createDefaultSaveData() {
	return {
		version: 1,
		unlockedWorlds: ["forest"],
		unlockedLevelMax: 1,
		levelProgress: {},
		collectedItemKeys: [],
		unlockedAchievements: [],
		coins: 120,
		crystals: 2,
		upgrades: {
			swordPower: 1,
			bowMastery: 1,
			shadowDash: 1,
			doubleJump: 1,
			energyShield: 1,
			shadowPulse: 1,
			timeFocus: 0
		},
		unlockedArrows: ["shadow"],
		selectedArrow: "shadow",
		unlockedCostumes: ["classic"],
		selectedCostume: "classic",
		settings: {
			musicVolume: .65,
			sfxVolume: .8,
			showTouchControls: true,
			autoTouchDetect: true,
			particlesEnabled: true,
			hapticsEnabled: true,
			consentAccepted: false
		},
		stats: {
			totalDeaths: 0,
			totalEnemiesDispersed: 0,
			totalDashes: 0,
			totalJumps: 0,
			totalArrowsFired: 0,
			totalPlayTimeSec: 0,
			bossesDefeated: 0,
			secretsFound: 0
		}
	};
}
function loadSaveData() {
	try {
		let raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) {
			const nativeBridge = window.ShadowNinjaNative;
			const backup = nativeBridge && typeof nativeBridge.loadBackup === "function" ? nativeBridge.loadBackup() : "";
			if (backup) {
				raw = backup;
				localStorage.setItem(STORAGE_KEY, backup);
			}
		}
		if (!raw) return createDefaultSaveData();
		const parsed = JSON.parse(raw);
		const def = createDefaultSaveData();
		const unlockedArrows = Array.isArray(parsed.unlockedArrows) && parsed.unlockedArrows.length > 0 ? parsed.unlockedArrows : def.unlockedArrows;
		const selectedArrow = parsed.selectedArrow && unlockedArrows.includes(parsed.selectedArrow) ? parsed.selectedArrow : "shadow";
		return {
			...def,
			...parsed,
			upgrades: {
				...def.upgrades,
				...parsed.upgrades || {}
			},
			unlockedArrows,
			selectedArrow,
			settings: {
				...def.settings,
				...parsed.settings || {}
			},
			stats: {
				...def.stats,
				...parsed.stats || {}
			},
			unlockedWorlds: Array.isArray(parsed.unlockedWorlds) ? parsed.unlockedWorlds : def.unlockedWorlds,
			collectedItemKeys: Array.isArray(parsed.collectedItemKeys) ? parsed.collectedItemKeys : def.collectedItemKeys,
			unlockedAchievements: Array.isArray(parsed.unlockedAchievements) ? parsed.unlockedAchievements : def.unlockedAchievements,
			unlockedCostumes: Array.isArray(parsed.unlockedCostumes) ? parsed.unlockedCostumes : def.unlockedCostumes
		};
	} catch {
		return createDefaultSaveData();
	}
}
function persistSaveData(data) {
	try {
		const serialized = JSON.stringify(data);
		localStorage.setItem(STORAGE_KEY, serialized);
		const nativeBridge = window.ShadowNinjaNative;
		if (nativeBridge && typeof nativeBridge.saveBackup === "function") nativeBridge.saveBackup(serialized);
	} catch {}
}
function resetSaveData() {
	const fresh = createDefaultSaveData();
	persistSaveData(fresh);
	return fresh;
}
function getWorldForLevel(levelId) {
	if (levelId <= 15) return "forest";
	if (levelId <= 30) return "temple";
	if (levelId <= 45) return "mountains";
	return "fortress";
}
function getAbilityLevel(save, id) {
	return save.upgrades[id] ?? 0;
}
// src/game/engine.ts
var FIXED_DT = 1 / 60;
var GRAVITY = 1520;
var MAX_FALL_SPEED = 780;
var BASE_MOVE_SPEED = 315;
var BASE_JUMP_VEL = -565;
var ShadowNinjaEngine = class {
	constructor(level, save, bonusBoostOrBuffs, onHudUpdate, onLevelEnd) {
		this.platforms = [];
		this.platformOrigins = /* @__PURE__ */ new Map();
		this.hazards = [];
		this.hiddenTraps = /* @__PURE__ */ new Map();
		this.enemies = [];
		this.enemyAi = [];
		this.projectiles = [];
		this.slashArcs = [];
		this.lightningArcs = [];
		this.explosionWaves = [];
		this.collectibles = [];
		this.checkpoints = [];
		this.particles = [];
		this.ambientMotes = [];
		this.pulseWaves = [];
		this.hp = 3;
		this.maxHp = 3;
		this.shieldCharges = 0;
		this.maxShieldCharges = 0;
		this.shieldRechargeTimer = 0;
		this.arrowEnergy = 100;
		this.maxArrowEnergy = 100;
		this.bowCooldown = 0;
		this.bowDrawSoundPlayed = false;
		this.wasBowHeld = false;
		this.selectedArrow = "shadow";
		this.score = 0;
		this.runCoins = 0;
		this.runCrystals = 0;
		this.runSecrets = 0;
		this.runEnemiesDispersed = 0;
		this.runDashes = 0;
		this.runJumps = 0;
		this.runArrowsFired = 0;
		this.newlyCollectedKeys = /* @__PURE__ */ new Set();
		this.elapsedSec = 0;
		this.time = 0;
		this.accumulator = 0;
		this.coyoteTimer = 0;
		this.jumpBufferTimer = 0;
		this.jumpsUsed = 0;
		this.dashCooldown = 0;
		this.dashDir = 1;
		this.attackCooldown = 0;
		this.slashHitIds = /* @__PURE__ */ new Set();
		this.pulseCooldown = 0;
		this.timeFocusCooldown = 0;
		this.timeFocusRemaining = 0;
		this.isDying = false;
		this.isWinning = false;
		this.checkpointReached = false;
		this.revivesUsed = 0;
		this.reviveShieldTimer = 0;
		this.deathSnapshot = null;
		this.committedCoins = 0;
		this.committedCrystals = 0;
		this.committedSecrets = 0;
		this.committedEnemiesDispersed = 0;
		this.committedDashes = 0;
		this.committedJumps = 0;
		this.committedArrowsFired = 0;
		this.committedTimeSec = 0;
		this.cameraX = 0;
		this.cameraY = 0;
		this.shakeTimer = 0;
		this.shakeIntensity = 0;
		this.bossActionTimer = 1.6;
		this.bossPhase = 1;
		this.bossAlive = false;
		this.paused = false;
		this.finished = false;
		this.hudSyncCounter = 0;
		this.level = level;
		this.save = save;
		const isBool = typeof bonusBoostOrBuffs === "boolean";
		this.runBuffs = isBool ? {
			extraLife: bonusBoostOrBuffs,
			arrowEnergyBoost: bonusBoostOrBuffs,
			shadowShieldBoost: bonusBoostOrBuffs
		} : bonusBoostOrBuffs;
		this.bonusBoost = Boolean(this.runBuffs.extraLife || this.runBuffs.arrowEnergyBoost || this.runBuffs.shadowShieldBoost);
		this.onHudUpdate = onHudUpdate;
		this.onLevelEnd = onLevelEnd;
		this.activeSpawn = { ...level.spawn };
		this.lastSafeGroundedPos = {
			x: level.spawn.x,
			y: level.spawn.y,
			facing: 1
		};
		this.maxHp = this.runBuffs.extraLife ? 4 : 3;
		this.hp = this.maxHp;
		const shieldLvl = getAbilityLevel(save, "energyShield");
		const baseShield = shieldLvl === 0 ? 0 : shieldLvl >= 4 ? 2 : 1;
		this.maxShieldCharges = baseShield + (this.runBuffs.shadowShieldBoost ? 1 : 0);
		this.shieldCharges = this.maxShieldCharges;
		const bowLvl = Math.max(1, getAbilityLevel(save, "bowMastery"));
		this.maxArrowEnergy = 100 + (bowLvl - 1) * 18 + (this.runBuffs.arrowEnergyBoost ? 50 : 0);
		this.arrowEnergy = this.maxArrowEnergy;
		const unlocked = save.unlockedArrows?.length ? save.unlockedArrows : ["shadow"];
		this.selectedArrow = unlocked.includes(save.selectedArrow) ? save.selectedArrow : unlocked[0];
		for (let i = 0; i < 140; i++) this.particles.push({
			active: false,
			x: 0,
			y: 0,
			vx: 0,
			vy: 0,
			size: 2,
			life: 0,
			maxLife: 1,
			color: "#ffffff"
		});
		for (let i = 0; i < 48; i++) this.ambientMotes.push({
			x: Math.random() * 1200,
			y: Math.random() * 640,
			r: 1 + Math.random() * 2,
			speed: -10 - Math.random() * 20,
			drift: Math.random() * Math.PI * 2
		});
		this.player = {
			x: level.spawn.x,
			y: level.spawn.y,
			w: 28,
			h: 46,
			vx: 0,
			vy: 0,
			facing: 1,
			onGround: false,
			onWall: false,
			wallDir: 1,
			isDashing: false,
			dashTimer: 0,
			doubleJumpSpin: 0,
			runCycle: 0,
			invulnTimer: 0,
			shieldCharges: this.shieldCharges,
			reviveShieldTimer: 0,
			animState: "idle",
			attackTimer: 0,
			attackCombo: 0,
			bowAiming: false,
			bowCharge: 0,
			bowAngle: 0,
			bowReleaseTimer: 0,
			activeArrowType: this.selectedArrow,
			abilityTimer: 0,
			victoryTimer: 0,
			landSquashTimer: 0,
			hurtTimer: 0,
			defeatTimer: 0,
			scarfNodes: Array.from({ length: 8 }, (_, idx) => ({
				x: level.spawn.x - idx * 5,
				y: level.spawn.y + 12
			})),
			afterimages: []
		};
		this.initEntities();
		this.emitHud();
	}
	initEntities() {
		this.platforms = this.level.platforms.map((p) => {
			this.platformOrigins.set(p.id, {
				x: p.x,
				y: p.y,
				timer: 0
			});
			return {
				id: p.id,
				x: p.x,
				y: p.y,
				w: p.w,
				h: p.h,
				type: p.type,
				fallState: "idle",
				shakeOffset: 0,
				gateOpen: false,
				bridgeDip: 0,
				concealsSecret: p.concealsSecret
			};
		});
		this.hazards = this.level.hazards.map((h) => {
			if (h.type === "hiddenSpikes") this.hiddenTraps.set(h.id, {
				triggered: false,
				timer: 0
			});
			return {
				id: h.id,
				x: h.x,
				y: h.y,
				w: h.w,
				h: h.h,
				type: h.type,
				angle: 0,
				active: h.type !== "fallingRock" && h.type !== "fireJet" && h.type !== "hiddenSpikes",
				warning: false,
				anchorX: h.type === "pendulum" ? h.x : void 0,
				anchorY: h.type === "pendulum" ? h.y : void 0,
				bobX: h.x,
				bobY: h.y
			};
		});
		this.enemies = this.level.enemies.map((e, idx) => {
			const dims = e.type === "boss" ? {
				w: 76,
				h: 96
			} : e.type === "miniboss" ? {
				w: 54,
				h: 68
			} : e.type === "mage" ? {
				w: 32,
				h: 46
			} : e.type === "guardian" ? {
				w: 36,
				h: 46
			} : e.type === "elite" ? {
				w: 34,
				h: 44
			} : e.type === "hunter" ? {
				w: 32,
				h: 32
			} : {
				w: 30,
				h: 40
			};
			return {
				id: e.id,
				x: e.x,
				y: e.y,
				w: dims.w,
				h: dims.h,
				type: e.type,
				state: "patrol",
				facing: idx % 2 === 0 ? -1 : 1,
				hp: e.hp,
				maxHp: e.hp,
				alive: true,
				defeatTimer: 0,
				alerted: false,
				telegraphTimer: 0,
				attackAnimTimer: 0,
				hitFlash: 0,
				burnTimer: 0,
				burnTickTimer: 0,
				slowTimer: 0,
				animTime: idx * .9,
				bossName: e.bossName
			};
		});
		this.enemyAi = this.level.enemies.map((e, idx) => ({
			baseY: e.y,
			cooldownTimer: .7 + idx % 3 * .35,
			idleTimer: 0,
			detectTimer: 0,
			attackTimer: 0,
			recoverTimer: 0,
			lungeVx: 0,
			wasAlerted: false
		}));
		this.bossAlive = this.enemies.some((e) => (e.type === "boss" || e.type === "miniboss") && e.alive);
		const existingSet = new Set(this.save.collectedItemKeys);
		this.collectibles = this.level.collectibles.map((c, idx) => {
			const key = `${this.level.id}:${c.id}`;
			const alreadyClaimedPermanent = c.type !== "coin" && existingSet.has(key);
			return {
				id: c.id,
				x: c.x,
				y: c.y,
				type: c.type,
				collected: alreadyClaimedPermanent,
				bobOffset: idx * .7
			};
		});
		this.checkpoints = this.level.checkpoints.map((cp) => ({
			id: cp.id,
			x: cp.x,
			y: cp.y,
			activated: false
		}));
	}
	setPaused(p) {
		this.paused = p;
	}
	reviveFromDeathSnapshot() {
		if (!this.finished) return false;
		if (this.revivesUsed >= 2) return false;
		const snap = this.deathSnapshot;
		if (!snap) return false;
		this.revivesUsed += 1;
		this.finished = false;
		this.paused = false;
		this.isDying = false;
		this.isWinning = false;
		this.accumulator = 0;
		this.platforms = snap.platforms.map((p) => ({ ...p }));
		this.platformOrigins = new Map(snap.platformOrigins.map(([k, v]) => [k, { ...v }]));
		for (const plat of this.platforms) if (plat.fallState === "fallen" && snap.deathX + this.player.w > plat.x - 16 && snap.deathX < plat.x + plat.w + 16) {
			plat.fallState = "idle";
			plat.shakeOffset = 0;
			const origin = this.platformOrigins.get(plat.id);
			if (origin) origin.timer = 0;
		}
		this.hazards = snap.hazards.map((h) => ({ ...h }));
		this.hiddenTraps = new Map(snap.hiddenTraps.map(([k, v]) => [k, { ...v }]));
		for (const h of this.hazards) if (h.type === "hiddenSpikes" && this.aabb(snap.deathX - 24, snap.deathY - 12, this.player.w + 48, this.player.h + 24, h.x, h.y, h.w, h.h)) {
			h.active = false;
			h.warning = false;
			const trap = this.hiddenTraps.get(h.id);
			if (trap) {
				trap.triggered = false;
				trap.timer = 0;
			}
		}
		this.enemies = snap.enemies.map((e) => ({ ...e }));
		this.enemyAi = snap.enemyAi.map((a) => ({ ...a }));
		this.projectiles = [];
		this.slashArcs = [];
		this.lightningArcs = [];
		this.explosionWaves = [];
		this.pulseWaves = [];
		this.collectibles = snap.collectibles.map((c) => ({ ...c }));
		this.checkpoints = snap.checkpoints.map((cp) => ({ ...cp }));
		this.newlyCollectedKeys = new Set(snap.newlyCollectedKeys);
		this.player.x = snap.deathX;
		this.player.y = snap.deathY;
		this.player.vx = 0;
		this.player.vy = 0;
		this.player.facing = snap.facing;
		this.player.isDashing = false;
		this.player.dashTimer = 0;
		this.player.doubleJumpSpin = 0;
		this.player.attackTimer = 0;
		this.player.bowAiming = false;
		this.player.bowCharge = 0;
		this.player.bowReleaseTimer = 0;
		this.player.defeatTimer = 0;
		this.player.victoryTimer = 0;
		this.player.abilityTimer = 0;
		this.player.hurtTimer = 0;
		this.player.afterimages = [];
		this.player.animState = "idle";
		this.player.scarfNodes = Array.from({ length: 8 }, (_, idx) => ({
			x: snap.deathX - snap.facing * idx * 5,
			y: snap.deathY + 12
		}));
		this.cameraX = snap.cameraX;
		this.cameraY = snap.cameraY;
		this.maxHp = snap.maxHp;
		this.hp = snap.maxHp;
		this.shieldCharges = snap.shieldCharges;
		this.player.shieldCharges = this.shieldCharges;
		this.arrowEnergy = Math.max(snap.arrowEnergy, this.maxArrowEnergy * .5);
		this.score = snap.score;
		this.runCoins = snap.runCoins;
		this.runCrystals = snap.runCrystals;
		this.runSecrets = snap.runSecrets;
		this.runEnemiesDispersed = snap.runEnemiesDispersed;
		this.runDashes = snap.runDashes;
		this.runJumps = snap.runJumps;
		this.runArrowsFired = snap.runArrowsFired;
		this.elapsedSec = snap.elapsedSec;
		this.time = snap.time;
		this.dashCooldown = snap.dashCooldown;
		this.attackCooldown = snap.attackCooldown;
		this.bowCooldown = snap.bowCooldown;
		this.pulseCooldown = snap.pulseCooldown;
		this.timeFocusCooldown = snap.timeFocusCooldown;
		this.timeFocusRemaining = snap.timeFocusRemaining;
		this.checkpointReached = snap.checkpointReached;
		this.activeSpawn = { ...snap.activeSpawn };
		this.bossAlive = snap.bossAlive;
		this.bossPhase = snap.bossPhase;
		this.bossActionTimer = snap.bossActionTimer;
		this.reviveShieldTimer = 4;
		this.player.reviveShieldTimer = 4;
		this.player.invulnTimer = 4;
		this.deathSnapshot = null;
		this.spawnBurst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, 22, "#fbbf24");
		soundEngine.playSfx("shield");
		this.emitHud();
		return true;
	}
	reviveAtCheckpoint() {
		return this.reviveFromDeathSnapshot();
	}
	canReviveAtCheckpoint() {
		return this.revivesUsed < 2 && this.deathSnapshot !== null;
	}
	getRevivesUsed() {
		return this.revivesUsed;
	}
	getRevivesRemaining() {
		return Math.max(0, 2 - this.revivesUsed);
	}
	getDeathSnapshot() {
		return this.deathSnapshot;
	}
	selectArrow(arrowType) {
		if ((this.save.unlockedArrows?.length ? this.save.unlockedArrows : ["shadow"]).includes(arrowType)) {
			this.selectedArrow = arrowType;
			this.player.activeArrowType = arrowType;
			this.emitHud();
		}
	}
	cycleArrow() {
		const unlocked = this.save.unlockedArrows?.length ? this.save.unlockedArrows : ["shadow"];
		const next = unlocked[(unlocked.indexOf(this.selectedArrow) + 1) % unlocked.length];
		this.selectedArrow = next;
		this.player.activeArrowType = next;
		this.emitHud();
		return next;
	}
	getDebugState() {
		return {
			hp: this.hp,
			maxHp: this.maxHp,
			arrowEnergy: this.arrowEnergy,
			maxArrowEnergy: this.maxArrowEnergy,
			selectedArrow: this.selectedArrow,
			runArrowsFired: this.runArrowsFired,
			finished: this.finished,
			paused: this.paused,
			isDying: this.isDying,
			isWinning: this.isWinning,
			revivesUsed: this.revivesUsed,
			revivesRemaining: this.getRevivesRemaining(),
			reviveShieldTimer: this.reviveShieldTimer,
			cameraX: this.cameraX,
			cameraY: this.cameraY,
			score: this.score,
			runCoins: this.runCoins,
			runCrystals: this.runCrystals,
			runEnemiesDispersed: this.runEnemiesDispersed,
			checkpointReached: this.checkpointReached,
			bossAlive: this.bossAlive,
			bossPhase: this.bossPhase,
			deathSnapshot: this.deathSnapshot,
			player: { ...this.player },
			enemies: this.enemies.map((e) => ({ ...e })),
			projectiles: this.projectiles.map((pr) => ({ ...pr })),
			collectibles: this.collectibles.map((c) => ({ ...c }))
		};
	}
	stepSimulation(dt, input) {
		const clampedDt = Math.min(.05, Math.max(0, dt));
		if (!this.paused && !this.finished) {
			this.accumulator += clampedDt;
			let steps = 0;
			while (this.accumulator >= FIXED_DT && steps < 4) {
				this.fixedUpdate(FIXED_DT, input);
				this.accumulator -= FIXED_DT;
				steps++;
			}
			input.jumpPressed = false;
			input.dashPressed = false;
			input.attackPressed = false;
			input.pulsePressed = false;
			input.timeFocusPressed = false;
			input.cycleArrowPressed = false;
		}
	}
	stepAndRender(dt, input, ctx, viewW, viewH) {
		const clampedDt = Math.min(.05, Math.max(0, dt));
		this.stepSimulation(clampedDt, input);
		if (!this.paused && !this.finished) this.updateCamera(viewW, viewH, clampedDt);
		renderGameScene(ctx, {
			level: this.level,
			worldId: this.level.worldId,
			costumeId: this.save.selectedCostume,
			time: this.time,
			timeFocusActive: this.timeFocusRemaining > 0,
			cameraX: this.cameraX,
			cameraY: this.cameraY,
			viewW,
			viewH,
			shakeX: this.shakeTimer > 0 ? (Math.random() - .5) * this.shakeIntensity : 0,
			shakeY: this.shakeTimer > 0 ? (Math.random() - .5) * this.shakeIntensity : 0,
			player: this.player,
			platforms: this.platforms,
			hazards: this.hazards,
			enemies: this.enemies,
			projectiles: this.projectiles,
			slashArcs: this.slashArcs,
			lightningArcs: this.lightningArcs,
			explosionWaves: this.explosionWaves,
			trajectoryPreview: this.buildTrajectoryPreview(),
			collectibles: this.collectibles,
			checkpoints: this.checkpoints,
			particles: this.particles,
			ambientMotes: this.ambientMotes,
			pulseWaves: this.pulseWaves,
			bossAlive: this.bossAlive,
			particlesEnabled: this.save.settings.particlesEnabled
		});
		this.hudSyncCounter++;
		if (this.hudSyncCounter % 4 === 0) this.emitHud();
	}
	fixedUpdate(dt, input) {
		this.time += dt;
		this.elapsedSec += dt;
		if (this.shakeTimer > 0) this.shakeTimer = Math.max(0, this.shakeTimer - dt);
		if (this.isWinning) {
			this.player.victoryTimer += dt;
			this.player.animState = "victory";
			this.player.vx = 0;
			this.player.vy = 0;
			this.updateScarfAndParticles(dt);
			if (this.player.victoryTimer >= .72) this.finishRun(true);
			return;
		}
		if (this.isDying) {
			this.player.defeatTimer += dt;
			this.player.animState = "defeat";
			this.player.y += this.player.vy * dt;
			this.player.vy += GRAVITY * .4 * dt;
			this.updateScarfAndParticles(dt);
			if (this.player.defeatTimer >= .62) this.finishRun(false);
			return;
		}
		if (this.reviveShieldTimer > 0) {
			this.reviveShieldTimer = Math.max(0, this.reviveShieldTimer - dt);
			this.player.reviveShieldTimer = this.reviveShieldTimer;
		}
		if (this.player.invulnTimer > 0) this.player.invulnTimer = Math.max(0, this.player.invulnTimer - dt);
		if (this.player.hurtTimer > 0) this.player.hurtTimer = Math.max(0, this.player.hurtTimer - dt);
		if (this.player.abilityTimer > 0) this.player.abilityTimer = Math.max(0, this.player.abilityTimer - dt);
		if (this.player.landSquashTimer > 0) this.player.landSquashTimer = Math.max(0, this.player.landSquashTimer - dt);
		if (this.player.attackTimer > 0) this.player.attackTimer = Math.max(0, this.player.attackTimer - dt);
		if (this.player.bowReleaseTimer > 0) this.player.bowReleaseTimer = Math.max(0, this.player.bowReleaseTimer - dt);
		if (this.dashCooldown > 0) this.dashCooldown = Math.max(0, this.dashCooldown - dt);
		if (this.attackCooldown > 0) this.attackCooldown = Math.max(0, this.attackCooldown - dt);
		if (this.bowCooldown > 0) this.bowCooldown = Math.max(0, this.bowCooldown - dt);
		if (this.pulseCooldown > 0) this.pulseCooldown = Math.max(0, this.pulseCooldown - dt);
		if (this.timeFocusCooldown > 0) this.timeFocusCooldown = Math.max(0, this.timeFocusCooldown - dt);
		if (this.timeFocusRemaining > 0) this.timeFocusRemaining = Math.max(0, this.timeFocusRemaining - dt);
		const arrowRegen = (20 + (Math.max(1, getAbilityLevel(this.save, "bowMastery")) - 1) * 4.5) * (this.runBuffs.arrowEnergyBoost ? 1.45 : 1) * (this.player.bowAiming ? .35 : 1);
		if (this.arrowEnergy < this.maxArrowEnergy) this.arrowEnergy = Math.min(this.maxArrowEnergy, this.arrowEnergy + arrowRegen * dt);
		if (this.maxShieldCharges > 0 && this.shieldCharges < this.maxShieldCharges) {
			const shieldLvl = getAbilityLevel(this.save, "energyShield");
			const rechargeDur = Math.max(6.5, 18 - shieldLvl * 2.2);
			this.shieldRechargeTimer += dt;
			if (this.shieldRechargeTimer >= rechargeDur) {
				this.shieldRechargeTimer = 0;
				this.shieldCharges++;
				this.player.shieldCharges = this.shieldCharges;
				soundEngine.playSfx("shield");
			}
		}
		const envTimeScale = this.timeFocusRemaining > 0 ? .35 : 1;
		this.updatePlatforms(dt, envTimeScale);
		this.handleAbilities(dt, input);
		this.updatePlayer(dt, input);
		if (this.player.attackTimer > .08) this.resolveSlashHits(this.player.isDashing);
		this.updateHazards(dt, envTimeScale);
		this.updateEnemies(dt, envTimeScale);
		this.updateProjectiles(dt, envTimeScale);
		this.checkPickupsAndExit();
		this.updatePlayerAnimState();
		this.updateScarfAndParticles(dt);
	}
	updatePlatforms(dt, envScale) {
		for (let i = 0; i < this.platforms.length; i++) {
			const p = this.platforms[i];
			const def = this.level.platforms[i];
			const origin = this.platformOrigins.get(p.id);
			if (p.type === "moving" && def.moveRange) {
				origin.timer += dt * (def.moveSpeed || 1.2) * envScale;
				const offset = Math.sin(origin.timer + (def.phase || 0)) * (def.moveRange * .5);
				const prevX = p.x;
				const prevY = p.y;
				if (def.moveAxis === "y") p.y = origin.y + offset;
				else p.x = origin.x + offset;
				if (this.player.onGround && this.player.x + this.player.w > prevX && this.player.x < prevX + p.w && Math.abs(this.player.y + this.player.h - prevY) <= 4) {
					this.player.x += p.x - prevX;
					this.player.y += p.y - prevY;
				}
			} else if (p.type === "falling" || p.type === "bridge" && def.collapses) {
				if (p.fallState === "shaking") {
					origin.timer += dt * envScale;
					p.shakeOffset = Math.sin(this.time * 55) * 3;
					if (origin.timer >= .58) {
						p.fallState = "fallen";
						origin.timer = 0;
						p.shakeOffset = 0;
					}
				} else if (p.fallState === "fallen") {
					origin.timer += dt;
					if (origin.timer >= 3) {
						p.fallState = "idle";
						origin.timer = 0;
					}
				}
			} else if (p.type === "gate") {
				const openDur = def.openDuration || 2.2;
				const cycle = openDur + (def.closedDuration || 1.8);
				origin.timer += dt * envScale;
				p.gateOpen = (origin.timer + (def.phase || 0)) % cycle < openDur;
			}
			if (p.bridgeDip > 0) p.bridgeDip = Math.max(0, p.bridgeDip - dt * 16);
		}
	}
	handleAbilities(dt, input) {
		if (input.cycleArrowPressed) {
			this.cycleArrow();
			soundEngine.playSfx("uiClick");
		}
		this.handleBowControl(dt, input);
		if (input.attackPressed && this.attackCooldown <= 0) {
			this.player.bowAiming = false;
			this.player.bowCharge = 0;
			this.performAttack(input);
		}
		const dashLvl = getAbilityLevel(this.save, "shadowDash");
		if (input.dashPressed && this.dashCooldown <= 0 && !this.player.isDashing) {
			this.player.bowAiming = false;
			this.player.bowCharge = 0;
			const cd = Math.max(.55, 1.45 - dashLvl * .16) * (this.bonusBoost ? .75 : 1);
			this.dashCooldown = cd;
			this.player.isDashing = true;
			this.player.attackTimer = 0;
			this.player.dashTimer = .17 + dashLvl * .015;
			this.dashDir = input.left ? -1 : input.right ? 1 : this.player.facing;
			this.player.facing = this.dashDir;
			this.player.vy = 0;
			this.player.invulnTimer = Math.max(this.player.invulnTimer, .22);
			this.runDashes++;
			this.shake(.1, 4);
			soundEngine.playSfx("dash");
			this.spawnBurst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, 10, WORLD_MAP[this.level.worldId].accentColor);
		}
		const pulseLvl = getAbilityLevel(this.save, "shadowPulse");
		if (input.pulsePressed && pulseLvl > 0 && this.pulseCooldown <= 0) {
			const cd = Math.max(1.6, 4.2 - pulseLvl * .45) * (this.bonusBoost ? .75 : 1);
			const radius = 165 + pulseLvl * 28;
			this.pulseCooldown = cd;
			this.player.abilityTimer = .34;
			this.shake(.16, 6);
			soundEngine.playSfx("pulse");
			const cx = this.player.x + this.player.w / 2;
			const cy = this.player.y + this.player.h / 2;
			this.pulseWaves.push({
				x: cx,
				y: cy,
				radius: 18,
				maxRadius: radius,
				alpha: .9
			});
			for (const e of this.enemies) {
				if (!e.alive) continue;
				const ex = e.x + e.w / 2;
				const ey = e.y + e.h / 2;
				if (Math.hypot(ex - cx, ey - cy) <= radius) this.damageEnemy(e, e.type === "boss" || e.type === "miniboss" ? 1 : 2);
			}
			for (const pr of this.projectiles) {
				if (!pr.active || pr.fromPlayer) continue;
				if (Math.hypot(pr.x - cx, pr.y - cy) <= radius) {
					pr.active = false;
					this.spawnBurst(pr.x, pr.y, 6, pr.color);
				}
			}
		}
		const tfLvl = getAbilityLevel(this.save, "timeFocus");
		if (input.timeFocusPressed && tfLvl > 0 && this.timeFocusCooldown <= 0) {
			const dur = 2.4 + tfLvl * .65;
			const cd = Math.max(5.5, 12 - tfLvl * 1.1);
			this.timeFocusRemaining = dur;
			this.timeFocusCooldown = cd;
			this.player.abilityTimer = .34;
			soundEngine.playSfx("timeFocus");
		}
	}
	handleBowControl(dt, input) {
		const p = this.player;
		const arrowDef = ARROW_MAP[this.selectedArrow];
		const bowLvl = Math.max(1, getAbilityLevel(this.save, "bowMastery"));
		const chargeDur = Math.max(.26, .54 - (bowLvl - 1) * .05);
		if (input.bowHeld && !p.isDashing) {
			if (!this.wasBowHeld) this.bowDrawSoundPlayed = false;
			p.bowAiming = true;
			p.bowCharge = Math.min(1, p.bowCharge + dt / chargeDur);
			if (!this.bowDrawSoundPlayed) {
				this.bowDrawSoundPlayed = true;
				soundEngine.playSfx("bowDraw");
			}
			if (input.bowAimActive) {
				p.bowAngle = input.bowAimAngle;
				p.facing = Math.cos(p.bowAngle) >= 0 ? 1 : -1;
			} else if (input.left && !input.right) {
				p.facing = -1;
				p.bowAngle = Math.PI + .08;
			} else if (input.right && !input.left) {
				p.facing = 1;
				p.bowAngle = -.08;
			} else p.bowAngle = p.facing > 0 ? -.08 : Math.PI + .08;
		} else if (this.wasBowHeld && !input.bowHeld) {
			if (this.bowCooldown <= 0 && this.arrowEnergy >= arrowDef.energyCost) this.fireMagicalArrow();
			p.bowAiming = false;
			p.bowCharge = 0;
		} else if (!input.bowHeld) {
			p.bowAiming = false;
			p.bowCharge = 0;
		}
		this.wasBowHeld = input.bowHeld;
	}
	getArrowLaunchParams() {
		const p = this.player;
		const arrowDef = ARROW_MAP[this.selectedArrow];
		const bowLvl = Math.max(1, getAbilityLevel(this.save, "bowMastery"));
		const charged = p.bowCharge >= .72;
		const speedScale = (1 + (bowLvl - 1) * .07) * (charged ? 1.18 : .92 + p.bowCharge * .25) * (this.bonusBoost ? 1.1 : 1);
		const speed = arrowDef.speed * speedScale;
		const bonusDmg = (bowLvl >= 3 ? 1 : 0) + (bowLvl >= 5 ? 1 : 0) + (charged ? 1 : 0) + (this.bonusBoost ? 1 : 0);
		const cx = p.x + p.w / 2;
		const cy = p.y + p.h * .44;
		const ang = p.bowAngle;
		return {
			startX: cx + Math.cos(ang) * 20,
			startY: cy + Math.sin(ang) * 20,
			vx: Math.cos(ang) * speed,
			vy: Math.sin(ang) * speed,
			gravityScale: arrowDef.gravityScale * (charged ? .78 : 1),
			charged,
			damage: arrowDef.baseDamage + bonusDmg
		};
	}
	fireMagicalArrow() {
		const p = this.player;
		const arrowDef = ARROW_MAP[this.selectedArrow];
		const bowLvl = Math.max(1, getAbilityLevel(this.save, "bowMastery"));
		const params = this.getArrowLaunchParams();
		this.arrowEnergy = Math.max(0, this.arrowEnergy - arrowDef.energyCost);
		this.bowCooldown = Math.max(.18, .32 - (bowLvl - 1) * .025);
		p.bowReleaseTimer = .22;
		p.facing = Math.cos(p.bowAngle) >= 0 ? 1 : -1;
		this.runArrowsFired++;
		this.projectiles.push({
			x: params.startX,
			y: params.startY,
			prevX: params.startX,
			prevY: params.startY,
			vx: params.vx,
			vy: params.vy,
			radius: 7,
			color: arrowDef.glowColor,
			fromPlayer: true,
			active: true,
			isArrow: true,
			arrowType: this.selectedArrow,
			damage: params.damage,
			gravityScale: params.gravityScale,
			pierceLeft: this.selectedArrow === "shadow" && params.charged ? 1 : 0,
			charged: params.charged,
			hitEnemyIds: []
		});
		const sfx = this.selectedArrow === "fire" ? "arrowFire" : this.selectedArrow === "ice" ? "arrowIce" : this.selectedArrow === "lightning" ? "arrowLightning" : "arrowShoot";
		soundEngine.playSfx(sfx);
		this.spawnBurst(params.startX, params.startY, 7, arrowDef.glowColor);
		if (params.charged) this.shake(.08, 3.5);
	}
	buildTrajectoryPreview() {
		if (!this.player.bowAiming) return null;
		const params = this.getArrowLaunchParams();
		const pts = [];
		let x = params.startX;
		let y = params.startY;
		let vx = params.vx;
		let vy = params.vy;
		const simStep = .035;
		for (let i = 0; i < 12; i++) {
			x += vx * simStep;
			y += vy * simStep;
			vy += GRAVITY * params.gravityScale * simStep;
			pts.push({
				x,
				y
			});
		}
		return {
			points: pts,
			arrowType: this.selectedArrow,
			chargeRatio: this.player.bowCharge,
			aimAngle: this.player.bowAngle
		};
	}
	performAttack(input) {
		const p = this.player;
		if (input.left && !input.right) p.facing = -1;
		else if (input.right && !input.left) p.facing = 1;
		const swordLvl = Math.max(1, getAbilityLevel(this.save, "swordPower"));
		const isDashStrike = p.isDashing;
		this.attackCooldown = isDashStrike ? .2 : Math.max(.2, .27 - (swordLvl - 1) * .014);
		p.attackTimer = .22;
		p.attackCombo = (p.attackCombo + 1) % 3;
		this.slashHitIds.clear();
		if (p.onGround && !p.isDashing) p.vx += p.facing * 95;
		const costume = COSTUME_MAP[this.save.selectedCostume];
		const cx = p.x + p.w / 2 + p.facing * (isDashStrike ? 18 : 12);
		const cy = p.y + p.h * .45;
		this.slashArcs.push({
			x: cx,
			y: cy,
			facing: p.facing,
			radius: (isDashStrike ? 58 : 44) + (swordLvl - 1) * 4,
			life: .19,
			maxLife: .19,
			color: isDashStrike ? "#facc15" : costume.accentGlow,
			combo: p.attackCombo
		});
		soundEngine.playSfx(isDashStrike ? "dashAttack" : "slash");
		this.resolveSlashHits(isDashStrike);
	}
	resolveSlashHits(isDashStrike) {
		const p = this.player;
		const swordLvl = Math.max(1, getAbilityLevel(this.save, "swordPower"));
		const reach = (isDashStrike ? 84 : 68) + (swordLvl - 1) * 5;
		const hitX = p.facing > 0 ? p.x + p.w * .35 : p.x - (reach - 10);
		const hitY = p.y - 10;
		const hitH = p.h + 18;
		const dmg = 1 + Math.floor((swordLvl - 1) / 2) + (this.bonusBoost ? 1 : 0) + (isDashStrike ? 1 : 0);
		for (const e of this.enemies) {
			if (!e.alive || this.slashHitIds.has(e.id)) continue;
			if (this.aabb(hitX, hitY, reach, hitH, e.x, e.y, e.w, e.h)) {
				this.slashHitIds.add(e.id);
				this.damageEnemy(e, dmg);
				this.shake(.1, isDashStrike ? 7 : 4.5);
			}
		}
		for (const pr of this.projectiles) {
			if (!pr.active || pr.fromPlayer) continue;
			if (this.circleRect(pr.x, pr.y, pr.radius + 8, hitX, hitY, reach, hitH)) {
				pr.fromPlayer = true;
				pr.vx = Math.abs(pr.vx) * p.facing * 1.3;
				pr.vy = -pr.vy * .4;
				pr.color = "#38bdf8";
				this.spawnBurst(pr.x, pr.y, 7, "#f8fafc");
			}
		}
	}
	updatePlayer(dt, input) {
		const p = this.player;
		const djLvl = getAbilityLevel(this.save, "doubleJump");
		const dashLvl = getAbilityLevel(this.save, "shadowDash");
		if (input.jumpPressed) this.jumpBufferTimer = .12;
		else if (this.jumpBufferTimer > 0) this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - dt);
		if (p.onGround) {
			this.coyoteTimer = .11;
			this.jumpsUsed = 0;
		} else if (this.coyoteTimer > 0) this.coyoteTimer = Math.max(0, this.coyoteTimer - dt);
		if (p.isDashing) {
			const dashSpeed = 680 + dashLvl * 55;
			p.vx = this.dashDir * dashSpeed;
			p.vy = 0;
			p.dashTimer -= dt;
			p.afterimages.push({
				x: p.x,
				y: p.y,
				facing: p.facing,
				alpha: .9
			});
			if (p.dashTimer <= 0) {
				p.isDashing = false;
				p.vx *= .45;
			}
		} else {
			const moveDir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
			if (moveDir !== 0 && p.attackTimer <= .05) p.facing = moveDir;
			const onIce = this.isStandingOnIce();
			const accel = p.onGround ? onIce ? 5.2 : 16 : 10 + djLvl * 1.2;
			const targetVx = moveDir * (BASE_MOVE_SPEED * (this.bonusBoost ? 1.12 : 1));
			p.vx += (targetVx - p.vx) * Math.min(1, accel * dt);
			if (Math.abs(p.vx) < 4 && moveDir === 0) p.vx = 0;
			p.vy = Math.min(p.onWall && p.vy > 0 ? 150 : MAX_FALL_SPEED, p.vy + GRAVITY * dt);
		}
		if (this.jumpBufferTimer > 0) {
			if (this.coyoteTimer > 0) {
				p.vy = BASE_JUMP_VEL;
				p.onGround = false;
				this.coyoteTimer = 0;
				this.jumpBufferTimer = 0;
				this.jumpsUsed = 1;
				this.runJumps++;
				soundEngine.playSfx("jump");
				this.spawnBurst(p.x + p.w / 2, p.y + p.h, 5, "#94a3b8");
			} else if (p.onWall && !p.onGround) {
				p.vy = BASE_JUMP_VEL * .96;
				p.vx = -p.wallDir * 330;
				p.facing = -p.wallDir;
				p.onWall = false;
				this.jumpBufferTimer = 0;
				this.jumpsUsed = 1;
				this.runJumps++;
				soundEngine.playSfx("jump");
				this.spawnBurst(p.x + p.w / 2, p.y + p.h / 2, 6, "#e2e8f0");
			} else if (this.jumpsUsed < 2) {
				p.vy = -530 * (1 + (djLvl - 1) * .04);
				p.isDashing = false;
				this.jumpsUsed = 2;
				this.jumpBufferTimer = 0;
				p.doubleJumpSpin = .01;
				this.runJumps++;
				soundEngine.playSfx("doubleJump");
				this.spawnBurst(p.x + p.w / 2, p.y + p.h, 8, "#38bdf8");
			}
		}
		if (!input.jumpHeld && p.vy < -210 && !p.isDashing) p.vy *= .9;
		if (p.doubleJumpSpin > 0) {
			p.doubleJumpSpin += dt * 16;
			if (p.doubleJumpSpin >= Math.PI * 2) p.doubleJumpSpin = 0;
		}
		p.x += p.vx * dt;
		p.onWall = false;
		this.resolveCollisionsX();
		if (p.x < 0) {
			p.x = 0;
			p.vx = 0;
		} else if (p.x + p.w > this.level.width) {
			p.x = this.level.width - p.w;
			p.vx = 0;
		}
		const wasOnGround = p.onGround;
		p.y += p.vy * dt;
		p.onGround = false;
		this.resolveCollisionsY();
		if (!wasOnGround && p.onGround) {
			p.landSquashTimer = .12;
			soundEngine.playSfx("land");
			this.spawnBurst(p.x + p.w / 2, p.y + p.h, 5, "#94a3b8");
		}
		if (p.onGround && p.y < this.level.height - 24 && p.hurtTimer <= 0 && !this.isPlayerOnHazard()) this.lastSafeGroundedPos = {
			x: p.x,
			y: p.y,
			facing: p.facing
		};
		if (p.onGround && Math.abs(p.vx) > 22) p.runCycle += dt * (Math.abs(p.vx) * .052);
		else if (p.onGround) p.runCycle = 0;
		if (p.y > this.level.height + 90) this.applyDamage(1, true);
	}
	isPlayerOnHazard() {
		const p = this.player;
		for (const h of this.hazards) if (h.type === "spikes" || h.type === "dangerZone" || h.type === "hiddenSpikes") {
			if (this.aabb(p.x, p.y, p.w, p.h + 4, h.x, h.y, h.w, h.h)) return true;
		}
		return false;
	}
	updatePlayerAnimState() {
		const p = this.player;
		let state = "idle";
		if (p.victoryTimer > 0) state = "victory";
		else if (p.defeatTimer > 0) state = "defeat";
		else if (p.hurtTimer > 0) state = "hurt";
		else if (p.abilityTimer > 0) state = "ability";
		else if (p.isDashing) state = "dash";
		else if (p.bowAiming) state = "bowAim";
		else if (p.bowReleaseTimer > 0) state = "bowRelease";
		else if (p.attackTimer > 0) state = "attack";
		else if (p.onWall && !p.onGround && p.vy > 0) state = "wallSlide";
		else if (p.doubleJumpSpin > 0) state = "doubleJump";
		else if (!p.onGround && p.vy < 0) state = "jump";
		else if (!p.onGround && p.vy >= 0) state = "fall";
		else if (p.landSquashTimer > 0) state = "land";
		else if (Math.abs(p.vx) > 22) state = "run";
		p.animState = state;
	}
	resolveCollisionsX() {
		const p = this.player;
		for (const plat of this.platforms) {
			if (plat.fallState === "fallen") continue;
			if (plat.type === "bridge") continue;
			if (plat.type === "gate" && plat.gateOpen) continue;
			if (this.aabb(p.x, p.y + 3, p.w, p.h - 6, plat.x, plat.y, plat.w, plat.h)) {
				if (p.vx > 0) {
					p.x = plat.x - p.w;
					p.vx = 0;
					if (plat.type === "wall" || plat.h >= 120) {
						p.onWall = true;
						p.wallDir = 1;
					}
				} else if (p.vx < 0) {
					p.x = plat.x + plat.w;
					p.vx = 0;
					if (plat.type === "wall" || plat.h >= 120) {
						p.onWall = true;
						p.wallDir = -1;
					}
				}
			}
		}
	}
	resolveCollisionsY() {
		const p = this.player;
		for (let i = 0; i < this.platforms.length; i++) {
			const plat = this.platforms[i];
			const def = this.level.platforms[i];
			if (plat.fallState === "fallen") continue;
			if (plat.type === "gate" && plat.gateOpen) continue;
			if (plat.type === "bridge") {
				if (p.vy >= 0 && p.x + p.w - 4 > plat.x && p.x + 4 < plat.x + plat.w && p.y + p.h >= plat.y && p.y + p.h - p.vy * FIXED_DT <= plat.y + 14) {
					p.y = plat.y - p.h;
					p.vy = 0;
					p.onGround = true;
					plat.bridgeDip = Math.min(12, plat.bridgeDip + 3);
					if (def.collapses && plat.fallState === "idle") {
						plat.fallState = "shaking";
						const origin = this.platformOrigins.get(plat.id);
						if (origin) origin.timer = 0;
					}
				}
				continue;
			}
			if (this.aabb(p.x + 2, p.y, p.w - 4, p.h, plat.x, plat.y, plat.w, plat.h)) {
				if (p.vy >= 0) {
					p.y = plat.y - p.h;
					p.vy = 0;
					p.onGround = true;
					if (plat.type === "falling" && plat.fallState === "idle") {
						plat.fallState = "shaking";
						const origin = this.platformOrigins.get(plat.id);
						if (origin) origin.timer = 0;
					}
				} else if (p.vy < 0) {
					p.y = plat.y + plat.h;
					p.vy = 0;
				}
			}
		}
	}
	isStandingOnIce() {
		const p = this.player;
		for (const plat of this.platforms) {
			if (plat.type !== "ice") continue;
			if (p.x + p.w > plat.x && p.x < plat.x + plat.w && Math.abs(p.y + p.h - plat.y) <= 3) return true;
		}
		return false;
	}
	updateHazards(dt, envScale) {
		const p = this.player;
		for (let i = 0; i < this.hazards.length; i++) {
			const h = this.hazards[i];
			const def = this.level.hazards[i];
			if (h.type === "saw") {
				h.angle += dt * 9 * envScale;
				h.bobX = Math.sin(this.time * (def.speed || 2) * envScale + (def.phase || 0)) * (def.range || 80);
				const cx = h.x + h.bobX;
				const cy = h.y;
				const r = (def.radius || 20) - 3;
				if (this.circleRect(cx, cy, r, p.x + 3, p.y + 3, p.w - 6, p.h - 6)) this.applyDamage(1, false);
			} else if (h.type === "pendulum" && h.anchorX !== void 0 && h.anchorY !== void 0) {
				const len = def.range || 140;
				const swing = Math.sin(this.time * (def.speed || 1.6) * envScale + (def.phase || 0)) * .92;
				h.bobX = h.anchorX + Math.sin(swing) * len;
				h.bobY = h.anchorY + Math.cos(swing) * len;
				if (this.circleRect(h.bobX, h.bobY, 16, p.x + 3, p.y + 3, p.w - 6, p.h - 6)) this.applyDamage(1, false);
			} else if (h.type === "fallingRock") {
				const period = def.period || 2.8;
				const cycle = (this.time * envScale + (def.phase || 0)) % period;
				h.warning = cycle < .75;
				h.active = cycle >= .75;
				if (!h.active) h.y = def.y;
				else {
					const fallT = cycle - .75;
					h.y = def.y + fallT * fallT * 460;
					if (this.aabb(p.x + 4, p.y + 4, p.w - 8, p.h - 8, h.x + 3, h.y + 3, h.w - 6, h.h - 6)) this.applyDamage(1, false);
				}
			} else if (h.type === "fireJet") {
				const period = def.period || 2.8;
				const cycle = (this.time * envScale + (def.phase || 0)) % period;
				h.warning = cycle >= 1.1 && cycle < 1.6;
				h.active = cycle >= 1.6;
				if (h.active && this.aabb(p.x + 4, p.y + 4, p.w - 8, p.h - 8, h.x + 4, h.y + 8, h.w - 8, h.h - 16)) this.applyDamage(1, false);
			} else if (h.type === "hiddenSpikes") {
				const trap = this.hiddenTraps.get(h.id);
				const nearTrigger = this.aabb(p.x - 16, p.y, p.w + 32, p.h + 12, h.x, h.y, h.w, h.h);
				if (!trap.triggered && nearTrigger) {
					trap.triggered = true;
					trap.timer = 0;
					soundEngine.playSfx("trapSnap");
				}
				if (trap.triggered) {
					trap.timer += dt * envScale;
					h.warning = trap.timer < .42;
					h.active = trap.timer >= .42 && trap.timer < 1.75;
					if (trap.timer >= 2.2) {
						trap.triggered = false;
						trap.timer = 0;
						h.warning = false;
						h.active = false;
					}
				}
				if (h.active && this.aabb(p.x + 5, p.y + 6, p.w - 10, p.h - 8, h.x + 3, h.y + 2, h.w - 6, h.h - 2)) this.applyDamage(1, false);
			} else if (h.type === "dangerZone") {
				if (this.aabb(p.x + 4, p.y + 4, p.w - 8, p.h - 8, h.x, h.y + 6, h.w, h.h)) this.applyDamage(1, true);
			} else if (h.type === "spikes") {
				if (this.aabb(p.x + 5, p.y + 6, p.w - 10, p.h - 8, h.x + 3, h.y + 4, h.w - 6, h.h - 4)) this.applyDamage(1, false);
			}
		}
	}
	updateEnemies(dt, envScale) {
		const p = this.player;
		const pcx = p.x + p.w / 2;
		const pcy = p.y + p.h / 2;
		const scaledDt = dt * envScale;
		const worldAccent = WORLD_MAP[this.level.worldId].accentColor;
		for (let i = 0; i < this.enemies.length; i++) {
			const e = this.enemies[i];
			const ai = this.enemyAi[i];
			const def = this.level.enemies[i];
			if (!e.alive) {
				if (e.defeatTimer > 0) e.defeatTimer = Math.max(0, e.defeatTimer - dt);
				continue;
			}
			if (e.hitFlash > 0) e.hitFlash = Math.max(0, e.hitFlash - dt);
			if (e.attackAnimTimer > 0) e.attackAnimTimer = Math.max(0, e.attackAnimTimer - dt);
			if (e.burnTimer > 0) {
				e.burnTimer = Math.max(0, e.burnTimer - dt);
				e.burnTickTimer -= dt;
				if (e.burnTickTimer <= 0) {
					e.burnTickTimer = .85;
					this.spawnBurst(e.x + e.w / 2, e.y + e.h * .45, 5, "#fb923c");
					this.damageEnemy(e, 1, "burn");
					if (!e.alive) continue;
				}
			}
			let statusScale = 1;
			if (e.slowTimer > 0) {
				e.slowTimer = Math.max(0, e.slowTimer - dt);
				statusScale = .48;
			}
			const enemyDt = scaledDt * statusScale;
			if (ai.cooldownTimer > 0) ai.cooldownTimer = Math.max(0, ai.cooldownTimer - enemyDt);
			e.animTime += enemyDt;
			const ecx = e.x + e.w / 2;
			const ecy = e.y + e.h / 2;
			const dx = pcx - ecx;
			const dy = pcy - ecy;
			const dist = Math.hypot(dx, dy);
			const detectRange = e.type === "boss" ? 760 : e.type === "miniboss" ? 480 : e.type === "elite" || e.type === "mage" ? 430 : 340;
			const verticalOk = e.type === "spirit" || e.type === "boss" || e.type === "mage" || Math.abs(dy) < 145;
			e.alerted = dist < detectRange && verticalOk;
			if (e.alerted && !ai.wasAlerted && e.type !== "boss") {
				ai.wasAlerted = true;
				ai.detectTimer = .22;
				soundEngine.playSfx("alert");
			} else if (!e.alerted) ai.wasAlerted = false;
			if (e.type === "boss") this.updateBoss(e, ai, def.patrolLeft, def.patrolRight, def.speed, enemyDt);
			else if (ai.recoverTimer > 0) {
				e.state = "recover";
				ai.recoverTimer = Math.max(0, ai.recoverTimer - scaledDt);
			} else if (ai.detectTimer > 0) {
				e.state = "detect";
				e.facing = dx >= 0 ? 1 : -1;
				ai.detectTimer = Math.max(0, ai.detectTimer - scaledDt);
			} else if (e.type === "spirit") {
				e.y = ai.baseY + Math.sin(e.animTime * 2.8) * 18;
				if (e.telegraphTimer > 0) {
					e.state = "windup";
					e.facing = dx >= 0 ? 1 : -1;
					e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
					if (e.telegraphTimer === 0) {
						e.state = "attack";
						e.attackAnimTimer = .25;
						ai.recoverTimer = .35;
						ai.cooldownTimer = 2.3;
						const ang = Math.atan2(dy, dx);
						this.projectiles.push({
							x: ecx + e.facing * 12,
							y: ecy,
							vx: Math.cos(ang) * 230,
							vy: Math.sin(ang) * 230,
							radius: 7,
							color: "#38bdf8",
							fromPlayer: false,
							active: true
						});
					}
				} else if (e.alerted && ai.cooldownTimer <= 0 && dist < 340) {
					e.telegraphTimer = .45;
					e.state = "windup";
				} else {
					e.state = "patrol";
					e.x += e.facing * def.speed * scaledDt;
				}
			} else if (e.type === "mage") {
				e.y = ai.baseY + Math.sin(e.animTime * 2.4) * 5;
				if (e.telegraphTimer > 0) {
					e.state = "windup";
					e.facing = dx >= 0 ? 1 : -1;
					e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
					if (e.telegraphTimer === 0) {
						e.state = "attack";
						e.attackAnimTimer = .3;
						ai.recoverTimer = .48;
						ai.cooldownTimer = 2.4;
						const ang = Math.atan2(dy, dx);
						for (const spread of [-.14, .14]) this.projectiles.push({
							x: ecx + e.facing * 12,
							y: ecy - 6,
							vx: Math.cos(ang + spread) * 240,
							vy: Math.sin(ang + spread) * 240,
							radius: 7,
							color: "#a855f7",
							fromPlayer: false,
							active: true
						});
					}
				} else if (e.alerted && ai.cooldownTimer <= 0 && dist < 370) {
					e.telegraphTimer = .48;
					e.state = "windup";
				} else if (e.alerted && dist < 130) {
					e.state = "approach";
					e.facing = dx >= 0 ? -1 : 1;
					e.x += e.facing * def.speed * scaledDt;
				} else {
					e.state = "patrol";
					e.x += e.facing * def.speed * scaledDt;
				}
			} else if (e.type === "elite") {
				e.y = ai.baseY + Math.sin(e.animTime * 2.2) * 9;
				if (e.telegraphTimer > 0) {
					e.state = "windup";
					e.facing = dx >= 0 ? 1 : -1;
					e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
					if (e.telegraphTimer === 0) {
						e.state = "attack";
						e.attackAnimTimer = .3;
						ai.recoverTimer = .42;
						ai.cooldownTimer = 2.5;
						const baseAng = Math.atan2(dy, dx);
						for (const spread of [
							-.22,
							0,
							.22
						]) this.projectiles.push({
							x: ecx + e.facing * 10,
							y: ecy - 4,
							vx: Math.cos(baseAng + spread) * 235,
							vy: Math.sin(baseAng + spread) * 235,
							radius: 7,
							color: "#c084fc",
							fromPlayer: false,
							active: true
						});
					}
				} else if (e.alerted && ai.cooldownTimer <= 0 && dist < 370) {
					e.telegraphTimer = .52;
					e.state = "windup";
				} else {
					e.state = "patrol";
					e.x += e.facing * def.speed * scaledDt;
				}
			} else if (e.type === "miniboss") {
				if (ai.attackTimer > 0) {
					e.state = "attack";
					ai.attackTimer = Math.max(0, ai.attackTimer - scaledDt);
					e.x += ai.lungeVx * scaledDt;
					if (ai.attackTimer === 0) ai.recoverTimer = .5;
				} else if (e.telegraphTimer > 0) {
					e.state = "windup";
					e.facing = dx >= 0 ? 1 : -1;
					e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
					if (e.telegraphTimer === 0) {
						e.state = "attack";
						e.attackAnimTimer = .35;
						ai.cooldownTimer = 2.1;
						this.shake(.16, 6);
						this.spawnBurst(ecx, e.y + e.h - 4, 14, worldAccent);
						if (dist < 145) {
							ai.attackTimer = .32;
							ai.lungeVx = e.facing * 230;
						} else {
							ai.recoverTimer = .45;
							const ang = Math.atan2(dy, dx);
							for (const sp of [-.15, .15]) this.projectiles.push({
								x: ecx + e.facing * 16,
								y: ecy - 6,
								vx: Math.cos(ang + sp) * 255,
								vy: Math.sin(ang + sp) * 255,
								radius: 8,
								color: worldAccent,
								fromPlayer: false,
								active: true
							});
						}
					}
				} else if (e.alerted && ai.cooldownTimer <= 0 && dist < 320) {
					e.telegraphTimer = .52;
					e.state = "windup";
				} else if (e.alerted) {
					e.state = "approach";
					if (Math.abs(dx) > 24) e.facing = dx > 0 ? 1 : -1;
					e.x += e.facing * def.speed * 1.15 * scaledDt;
				} else {
					e.state = "patrol";
					e.x += e.facing * def.speed * scaledDt;
				}
			} else if (e.type === "guardian") {
				if (e.telegraphTimer > 0) {
					e.state = "windup";
					e.facing = dx >= 0 ? 1 : -1;
					e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
					if (e.telegraphTimer === 0) {
						e.state = "attack";
						e.attackAnimTimer = .32;
						ai.recoverTimer = .48;
						ai.cooldownTimer = 2.4;
						this.shake(.14, 5);
						this.spawnBurst(ecx, e.y + e.h - 4, 12, "#f59e0b");
						for (const dir of [-1, 1]) this.projectiles.push({
							x: ecx + dir * 18,
							y: e.y + e.h - 10,
							vx: dir * 215,
							vy: 0,
							radius: 7,
							color: "#f59e0b",
							fromPlayer: false,
							active: true
						});
					}
				} else if (e.alerted && dist < 115 && ai.cooldownTimer <= 0) {
					e.telegraphTimer = .55;
					e.state = "windup";
				} else if (e.alerted) {
					e.state = "approach";
					if (Math.abs(dx) > 18) e.facing = dx > 0 ? 1 : -1;
					e.x += e.facing * def.speed * 1.15 * scaledDt;
				} else {
					e.state = "patrol";
					e.x += e.facing * def.speed * scaledDt;
				}
			} else if (e.type === "hunter") {
				if (ai.attackTimer > 0) {
					e.state = "attack";
					ai.attackTimer = Math.max(0, ai.attackTimer - scaledDt);
					e.x += ai.lungeVx * scaledDt;
					if (ai.attackTimer === 0) ai.recoverTimer = .32;
				} else if (e.telegraphTimer > 0) {
					e.state = "windup";
					e.facing = dx >= 0 ? 1 : -1;
					e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
					if (e.telegraphTimer === 0) {
						ai.attackTimer = .36;
						e.attackAnimTimer = .36;
						ai.lungeVx = e.facing * Math.max(240, def.speed * 2.1);
						ai.cooldownTimer = 1.9;
						this.spawnBurst(ecx, ecy, 6, "#f43f5e");
					}
				} else if (e.alerted && dist < 175 && ai.cooldownTimer <= 0) {
					e.telegraphTimer = .28;
					e.state = "windup";
				} else if (e.alerted) {
					e.state = "approach";
					if (Math.abs(dx) > 14) e.facing = dx > 0 ? 1 : -1;
					e.x += e.facing * def.speed * 1.35 * scaledDt;
				} else {
					e.state = "patrol";
					e.x += e.facing * def.speed * scaledDt;
				}
			} else if (ai.idleTimer > 0) {
				e.state = "idle";
				ai.idleTimer = Math.max(0, ai.idleTimer - scaledDt);
			} else if (ai.attackTimer > 0) {
				e.state = "attack";
				ai.attackTimer = Math.max(0, ai.attackTimer - scaledDt);
				e.x += ai.lungeVx * scaledDt;
				if (ai.attackTimer === 0) ai.recoverTimer = .36;
			} else if (e.telegraphTimer > 0) {
				e.state = "windup";
				e.facing = dx >= 0 ? 1 : -1;
				e.telegraphTimer = Math.max(0, e.telegraphTimer - scaledDt);
				if (e.telegraphTimer === 0) {
					ai.attackTimer = .22;
					e.attackAnimTimer = .26;
					ai.lungeVx = e.facing * 200;
					ai.cooldownTimer = 1.65;
					soundEngine.playSfx("slash");
				}
			} else if (e.alerted && dist < 90 && ai.cooldownTimer <= 0) {
				e.telegraphTimer = .36;
				e.state = "windup";
			} else if (e.alerted) {
				e.state = "approach";
				if (Math.abs(dx) > 16) e.facing = dx > 0 ? 1 : -1;
				e.x += e.facing * def.speed * 1.28 * scaledDt;
			} else {
				e.state = "patrol";
				e.x += e.facing * def.speed * scaledDt;
			}
			if (e.type !== "boss") {
				const minX = def.patrolLeft;
				const maxX = Math.max(minX, def.patrolRight - e.w);
				if (e.x <= minX) {
					e.x = minX;
					if (!e.alerted || e.state === "patrol") {
						e.facing = 1;
						if (e.type === "warrior") ai.idleTimer = .28;
					}
					ai.lungeVx = Math.max(0, ai.lungeVx);
				} else if (e.x >= maxX) {
					e.x = maxX;
					if (!e.alerted || e.state === "patrol") {
						e.facing = -1;
						if (e.type === "warrior") ai.idleTimer = .28;
					}
					ai.lungeVx = Math.min(0, ai.lungeVx);
				}
			}
			if (e.hitFlash > 0) e.state = "hurt";
			if (this.aabb(p.x + 3, p.y + 3, p.w - 6, p.h - 6, e.x + 3, e.y + 3, e.w - 6, e.h - 6)) {
				const stomping = p.vy > 40 && p.y + p.h - p.vy * FIXED_DT <= e.y + 18;
				if (stomping || p.isDashing) {
					if (stomping) p.vy = -420;
					if (p.isDashing) {
						soundEngine.playSfx("dashAttack");
						this.damageEnemy(e, 2);
					} else this.damageEnemy(e, 1);
				} else {
					this.applyDamage(1, false);
					this.spawnBurst(pcx, pcy, 6, worldAccent);
				}
			}
		}
	}
	updateBoss(boss, ai, leftBound, rightBound, baseSpeed, dt) {
		const pcx = this.player.x + this.player.w / 2;
		const bcx = boss.x + boss.w / 2;
		boss.facing = pcx >= bcx ? 1 : -1;
		const hpRatio = boss.hp / Math.max(1, boss.maxHp);
		this.bossPhase = hpRatio <= .34 ? 3 : hpRatio <= .68 ? 2 : 1;
		const phaseMult = this.bossPhase === 3 ? 1.55 : this.bossPhase === 2 ? 1.28 : 1;
		this.bossActionTimer -= dt * phaseMult;
		if (ai.recoverTimer > 0) {
			boss.state = "recover";
			ai.recoverTimer = Math.max(0, ai.recoverTimer - dt);
		} else if (ai.attackTimer > 0) {
			boss.state = "attack";
			ai.attackTimer = Math.max(0, ai.attackTimer - dt);
			boss.x += ai.lungeVx * dt;
			if (ai.attackTimer === 0) ai.recoverTimer = this.bossPhase === 3 ? .32 : .42;
		} else if (boss.telegraphTimer > 0) {
			boss.state = "windup";
			boss.telegraphTimer = Math.max(0, boss.telegraphTimer - dt);
			if (boss.telegraphTimer === 0) {
				boss.state = "attack";
				boss.attackAnimTimer = .35;
				if (Math.abs(pcx - bcx) > 175 || this.bossPhase >= 2) {
					const angle = Math.atan2(this.player.y + 20 - (boss.y + 36), pcx - bcx);
					const speed = this.bossPhase === 3 ? 355 : this.bossPhase === 2 ? 315 : 260;
					const color = WORLD_MAP[this.level.worldId].accentColor;
					const spreads = this.bossPhase === 3 ? [
						-.34,
						-.17,
						0,
						.17,
						.34
					] : this.bossPhase === 2 ? [
						-.24,
						0,
						.24
					] : [-.14, .14];
					for (const sp of spreads) this.projectiles.push({
						x: bcx,
						y: boss.y + 36,
						vx: Math.cos(angle + sp) * speed,
						vy: Math.sin(angle + sp) * speed,
						radius: 9,
						color,
						fromPlayer: false,
						active: true
					});
				}
				ai.attackTimer = .36;
				ai.lungeVx = boss.facing * (this.bossPhase === 3 ? 295 : this.bossPhase === 2 ? 255 : 195);
			}
		} else if (this.bossActionTimer <= 0) {
			boss.telegraphTimer = this.bossPhase === 3 ? .42 : .52;
			boss.state = "windup";
			this.bossActionTimer = this.bossPhase === 3 ? 1.45 : this.bossPhase === 2 ? 1.75 : 2.15;
		} else {
			boss.state = "approach";
			const targetDir = Math.abs(pcx - bcx) > 45 ? boss.facing : 0;
			boss.x += targetDir * baseSpeed * (this.bossPhase === 3 ? 1.05 : .88) * dt;
		}
		boss.x = Math.max(leftBound, Math.min(rightBound - boss.w, boss.x));
	}
	updateProjectiles(dt, envScale) {
		const p = this.player;
		for (const pr of this.projectiles) {
			if (!pr.active) continue;
			const mult = pr.fromPlayer ? 1 : envScale;
			pr.prevX = pr.x;
			pr.prevY = pr.y;
			pr.x += pr.vx * dt * mult;
			if (pr.isArrow) pr.vy += GRAVITY * (pr.gravityScale ?? .22) * dt;
			pr.y += pr.vy * dt * mult;
			if (pr.x < -80 || pr.x > this.level.width + 80 || pr.y < -120 || pr.y > this.level.height + 80) {
				pr.active = false;
				continue;
			}
			if (pr.fromPlayer) {
				if (pr.isArrow) {
					let hitWall = false;
					for (const plat of this.platforms) {
						if (plat.fallState === "fallen") continue;
						if (plat.type === "bridge") continue;
						if (plat.type === "gate" && plat.gateOpen) continue;
						if (this.segmentIntersectsRect(pr.prevX, pr.prevY, pr.x, pr.y, plat.x, plat.y, plat.w, plat.h)) {
							hitWall = true;
							break;
						}
					}
					if (hitWall) {
						pr.active = false;
						if (pr.arrowType === "explosive") this.triggerExplosiveDetonation(pr.x, pr.y, pr.damage ?? 2, pr.color);
						else {
							soundEngine.playSfx("arrowHit");
							this.spawnBurst(pr.x, pr.y, 7, pr.color);
						}
						continue;
					}
				}
				for (const e of this.enemies) {
					if (!e.alive) continue;
					if (pr.hitEnemyIds && pr.hitEnemyIds.includes(e.id)) continue;
					if (pr.isArrow ? this.segmentIntersectsRect(pr.prevX, pr.prevY, pr.x, pr.y, e.x - 4, e.y - 4, e.w + 8, e.h + 8) : this.circleRect(pr.x, pr.y, pr.radius, e.x, e.y, e.w, e.h)) {
						if (pr.isArrow) {
							this.applyArrowHit(pr, e);
							if (!pr.active) break;
						} else {
							pr.active = false;
							this.damageEnemy(e, 1);
							break;
						}
					}
				}
			} else if (this.circleRect(pr.x, pr.y, pr.radius, p.x + 3, p.y + 3, p.w - 6, p.h - 6)) {
				pr.active = false;
				if (!p.isDashing) this.applyDamage(1, false);
			}
		}
		if (this.projectiles.length > 56) this.projectiles = this.projectiles.filter((pr) => pr.active);
	}
	applyArrowHit(pr, e) {
		const arrowType = pr.arrowType || "shadow";
		if (!pr.hitEnemyIds) pr.hitEnemyIds = [];
		pr.hitEnemyIds.push(e.id);
		let dmg = pr.damage ?? 1;
		const frontalHit = (pr.vx >= 0 ? 1 : -1) !== e.facing;
		if ((e.type === "guardian" || e.type === "miniboss") && arrowType === "shadow" && frontalHit && !pr.charged) {
			dmg = Math.max(1, dmg - 1);
			this.spawnBurst(pr.x, pr.y, 6, "#94a3b8");
		} else if ((e.type === "spirit" || e.type === "mage") && pr.charged) dmg += 1;
		if (arrowType === "fire") {
			e.burnTimer = 2.6;
			e.burnTickTimer = .7;
			this.spawnBurst(e.x + e.w / 2, e.y + e.h / 2, 12, "#fb923c");
			this.damageEnemy(e, dmg, "arrow");
			soundEngine.playSfx("arrowFire");
			pr.active = false;
		} else if (arrowType === "ice") {
			e.slowTimer = 3.2;
			this.spawnBurst(e.x + e.w / 2, e.y + e.h / 2, 12, "#67e8f9");
			this.damageEnemy(e, dmg, "arrow");
			soundEngine.playSfx("arrowIce");
			pr.active = false;
		} else if (arrowType === "lightning") {
			this.damageEnemy(e, dmg, "arrow");
			soundEngine.playSfx("arrowLightning");
			this.triggerLightningChain(e, Math.max(1, dmg));
			pr.active = false;
		} else if (arrowType === "explosive") {
			this.triggerExplosiveDetonation(pr.x, pr.y, dmg + 1, pr.color);
			pr.active = false;
		} else {
			this.damageEnemy(e, dmg, "arrow");
			soundEngine.playSfx("arrowHit");
			this.spawnBurst(pr.x, pr.y, 8, pr.color);
			if (pr.pierceLeft && pr.pierceLeft > 0) pr.pierceLeft--;
			else pr.active = false;
		}
	}
	triggerLightningChain(originEnemy, chainDmg) {
		const ox = originEnemy.x + originEnemy.w / 2;
		const oy = originEnemy.y + originEnemy.h / 2;
		const chainPoints = [{
			x: ox,
			y: oy
		}];
		const candidates = this.enemies.filter((other) => other.alive && other.id !== originEnemy.id).map((other) => ({
			enemy: other,
			dist: Math.hypot(other.x + other.w / 2 - ox, other.y + other.h / 2 - oy)
		})).filter((c) => c.dist <= 225).sort((a, b) => a.dist - b.dist).slice(0, 2);
		for (const c of candidates) {
			const tx = c.enemy.x + c.enemy.w / 2;
			const ty = c.enemy.y + c.enemy.h / 2;
			chainPoints.push({
				x: tx,
				y: ty
			});
			this.damageEnemy(c.enemy, chainDmg, "arrow");
			this.spawnBurst(tx, ty, 8, "#fde047");
		}
		if (chainPoints.length >= 2) this.lightningArcs.push({
			points: chainPoints,
			life: .22,
			maxLife: .22,
			color: "#fde047"
		});
	}
	triggerExplosiveDetonation(x, y, aoeDmg, color) {
		const radius = 92;
		this.explosionWaves.push({
			x,
			y,
			radius: 16,
			maxRadius: radius,
			life: .28,
			maxLife: .28,
			color
		});
		soundEngine.playSfx("arrowExplode");
		this.shake(.16, 7);
		this.spawnBurst(x, y, 18, "#f472b6");
		for (const e of this.enemies) {
			if (!e.alive) continue;
			if (this.circleRect(x, y, radius, e.x, e.y, e.w, e.h)) this.damageEnemy(e, aoeDmg, "arrow");
		}
	}
	damageEnemy(enemy, dmg, source = "melee") {
		if (!enemy.alive) return;
		enemy.hp -= dmg;
		enemy.hitFlash = .16;
		enemy.telegraphTimer = Math.max(0, enemy.telegraphTimer - .12);
		if (enemy.type !== "boss" && source !== "burn") {
			const idx = this.enemies.indexOf(enemy);
			if (idx >= 0) {
				const def = this.level.enemies[idx];
				const push = enemy.x + enemy.w / 2 >= this.player.x + this.player.w / 2 ? 12 : -12;
				enemy.x = Math.max(def.patrolLeft, Math.min(def.patrolRight - enemy.w, enemy.x + push));
			}
		}
		if (enemy.hp <= 0) {
			enemy.alive = false;
			enemy.state = "defeat";
			enemy.defeatTimer = .4;
			this.runEnemiesDispersed++;
			this.save.stats.totalEnemiesDispersed++;
			this.score += enemy.type === "boss" ? 1200 : enemy.type === "miniboss" ? 650 : enemy.type === "elite" || enemy.type === "mage" ? 240 : 140;
			soundEngine.playSfx(enemy.type === "boss" || enemy.type === "miniboss" ? "bossDefeat" : "enemyDisperse");
			this.shake(enemy.type === "boss" ? .35 : enemy.type === "miniboss" ? .24 : .12, enemy.type === "boss" ? 11 : 5);
			this.spawnBurst(enemy.x + enemy.w / 2, enemy.y + enemy.h / 2, enemy.type === "boss" ? 38 : enemy.type === "miniboss" ? 26 : 16, WORLD_MAP[this.level.worldId].accentColor);
			if (enemy.type === "boss" || enemy.type === "miniboss") {
				this.bossAlive = this.enemies.some((other) => (other.type === "boss" || other.type === "miniboss") && other.alive);
				if (!this.bossAlive) this.projectiles.forEach((pr) => pr.active = false);
			}
		} else {
			enemy.state = "hurt";
			if (source !== "burn") {
				soundEngine.playSfx("enemyDisperse");
				this.spawnBurst(enemy.x + enemy.w / 2, enemy.y + enemy.h / 2, 9, "#f8fafc");
			}
		}
	}
	captureDeathSnapshot(fellIntoAbyss) {
		const restoreAtSafeLedge = fellIntoAbyss || this.player.y > this.level.height - 16;
		const deathX = restoreAtSafeLedge ? this.lastSafeGroundedPos.x : this.player.x;
		const deathY = restoreAtSafeLedge ? this.lastSafeGroundedPos.y : this.player.y;
		const facing = restoreAtSafeLedge ? this.lastSafeGroundedPos.facing : this.player.facing;
		this.deathSnapshot = {
			levelId: this.level.id,
			deathX,
			deathY,
			facing,
			fellIntoAbyss,
			cameraX: this.cameraX,
			cameraY: this.cameraY,
			hpBeforeDeath: this.hp,
			maxHp: this.maxHp,
			shieldCharges: this.shieldCharges,
			arrowEnergy: this.arrowEnergy,
			score: this.score,
			runCoins: this.runCoins,
			runCrystals: this.runCrystals,
			runSecrets: this.runSecrets,
			runEnemiesDispersed: this.runEnemiesDispersed,
			runDashes: this.runDashes,
			runJumps: this.runJumps,
			runArrowsFired: this.runArrowsFired,
			elapsedSec: this.elapsedSec,
			time: this.time,
			dashCooldown: this.dashCooldown,
			attackCooldown: this.attackCooldown,
			bowCooldown: this.bowCooldown,
			pulseCooldown: this.pulseCooldown,
			timeFocusCooldown: this.timeFocusCooldown,
			timeFocusRemaining: this.timeFocusRemaining,
			checkpointReached: this.checkpointReached,
			activeSpawn: { ...this.activeSpawn },
			bossAlive: this.bossAlive,
			bossPhase: this.bossPhase,
			bossActionTimer: this.bossActionTimer,
			enemies: this.enemies.map((e) => ({ ...e })),
			enemyAi: this.enemyAi.map((a) => ({ ...a })),
			collectibles: this.collectibles.map((c) => ({ ...c })),
			checkpoints: this.checkpoints.map((cp) => ({ ...cp })),
			hazards: this.hazards.map((h) => ({ ...h })),
			hiddenTraps: Array.from(this.hiddenTraps.entries()).map(([k, v]) => [k, { ...v }]),
			platforms: this.platforms.map((p) => ({ ...p })),
			platformOrigins: Array.from(this.platformOrigins.entries()).map(([k, v]) => [k, { ...v }]),
			newlyCollectedKeys: Array.from(this.newlyCollectedKeys)
		};
	}
	applyDamage(amount, fellIntoAbyss) {
		if (this.finished || this.isDying || this.isWinning) return;
		if (this.reviveShieldTimer > 0) {
			if (fellIntoAbyss) {
				this.player.x = this.lastSafeGroundedPos.x;
				this.player.y = this.lastSafeGroundedPos.y;
				this.player.vx = 0;
				this.player.vy = 0;
			}
			return;
		}
		if (!fellIntoAbyss && this.player.invulnTimer > 0) return;
		if (!fellIntoAbyss && this.shieldCharges > 0) {
			this.shieldCharges--;
			this.player.shieldCharges = this.shieldCharges;
			this.player.invulnTimer = 1.25;
			this.shake(.16, 6);
			soundEngine.playSfx("shield");
			this.spawnBurst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, 14, "#38bdf8");
			return;
		}
		this.hp = Math.max(0, this.hp - amount);
		this.player.invulnTimer = 1.4;
		this.player.hurtTimer = .25;
		this.shake(.2, 8);
		soundEngine.playSfx("hit");
		if (this.hp <= 0) {
			this.captureDeathSnapshot(fellIntoAbyss);
			soundEngine.playSfx("defeat");
			if (fellIntoAbyss) this.finishRun(false);
			else {
				this.isDying = true;
				this.player.defeatTimer = .01;
				this.player.vx = 0;
				this.player.vy = -160;
				this.player.animState = "defeat";
				this.spawnBurst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, 24, WORLD_MAP[this.level.worldId].accentColor);
			}
			return;
		}
		if (fellIntoAbyss) {
			this.player.x = this.activeSpawn.x;
			this.player.y = this.activeSpawn.y;
			this.player.vx = 0;
			this.player.vy = 0;
		} else this.player.vy = -300;
	}
	checkPickupsAndExit() {
		const p = this.player;
		for (const c of this.collectibles) {
			if (c.collected) continue;
			if (this.circleRect(c.x, c.y, 18, p.x, p.y, p.w, p.h)) {
				c.collected = true;
				const key = `${this.level.id}:${c.id}`;
				const alreadySaved = this.save.collectedItemKeys.includes(key);
				if (!alreadySaved) this.newlyCollectedKeys.add(key);
				if (c.type === "coin") {
					this.runCoins += 15;
					this.score += 50;
					soundEngine.playSfx("coin");
					this.spawnBurst(c.x, c.y, 6, "#facc15");
				} else if (c.type === "crystal") {
					if (!alreadySaved) this.runCrystals += 1;
					this.score += 250;
					soundEngine.playSfx("crystal");
					this.spawnBurst(c.x, c.y, 12, "#38bdf8");
				} else {
					if (!alreadySaved) {
						this.runCoins += c.type === "secret" ? 75 : 50;
						this.runCrystals += c.type === "secret" ? 2 : 1;
						if (c.type === "secret") this.runSecrets++;
					}
					this.score += 500;
					soundEngine.playSfx("treasure");
					this.spawnBurst(c.x, c.y, 16, "#c084fc");
				}
			}
		}
		for (const cp of this.checkpoints) if (!cp.activated && Math.abs(p.x + p.w / 2 - cp.x) < 38 && Math.abs(p.y + p.h - cp.y) < 62) {
			cp.activated = true;
			this.checkpointReached = true;
			this.activeSpawn = {
				x: cp.x - 14,
				y: cp.y - 54
			};
			soundEngine.playSfx("checkpoint");
			this.spawnBurst(cp.x, cp.y - 40, 16, WORLD_MAP[this.level.worldId].accentColor);
		}
		if (!this.bossAlive && !this.isWinning) {
			const ex = this.level.exit;
			if (this.aabb(p.x, p.y, p.w, p.h, ex.x, ex.y, ex.w, ex.h)) {
				this.isWinning = true;
				this.player.victoryTimer = .01;
				this.player.animState = "victory";
				soundEngine.playSfx(this.level.isBoss ? "bossDefeat" : "levelComplete");
				this.spawnBurst(ex.x + ex.w / 2, ex.y + ex.h / 2, 26, "#facc15");
			}
		}
	}
	finishRun(victory) {
		if (this.finished) return;
		this.finished = true;
		this.paused = true;
		this.player.vx = 0;
		this.player.vy = 0;
		let stars = 0;
		let coinsEarned = this.runCoins;
		let crystalsEarned = this.runCrystals;
		if (victory) {
			stars = 1;
			if (this.hp === this.maxHp) stars++;
			if (this.elapsedSec <= this.level.parTimeSec) stars++;
			coinsEarned += this.level.baseCoinReward;
			crystalsEarned += this.level.baseCrystalReward;
			this.score += Math.max(0, Math.round((this.level.parTimeSec - this.elapsedSec) * 18)) + this.hp * 200;
		}
		const world = WORLD_MAP[this.level.worldId];
		const isWorldClear = victory && this.level.isBoss && !this.save.levelProgress[this.level.id]?.completed;
		if (isWorldClear) {
			coinsEarned += world.completionRewardCoins;
			crystalsEarned += world.completionRewardCrystals;
		}
		const saveCoinsDelta = Math.max(0, coinsEarned - this.committedCoins);
		const saveCrystalsDelta = Math.max(0, crystalsEarned - this.committedCrystals);
		const saveSecretsDelta = Math.max(0, this.runSecrets - this.committedSecrets);
		const saveEnemiesDelta = Math.max(0, this.runEnemiesDispersed - this.committedEnemiesDispersed);
		const saveDashesDelta = Math.max(0, this.runDashes - this.committedDashes);
		const saveJumpsDelta = Math.max(0, this.runJumps - this.committedJumps);
		const saveArrowsDelta = Math.max(0, this.runArrowsFired - this.committedArrowsFired);
		const saveTimeDeltaSec = Math.max(0, Math.round((this.elapsedSec - this.committedTimeSec) * 10) / 10);
		this.committedCoins = coinsEarned;
		this.committedCrystals = crystalsEarned;
		this.committedSecrets = this.runSecrets;
		this.committedEnemiesDispersed = this.runEnemiesDispersed;
		this.committedDashes = this.runDashes;
		this.committedJumps = this.runJumps;
		this.committedArrowsFired = this.runArrowsFired;
		this.committedTimeSec = this.elapsedSec;
		const summary = {
			levelId: this.level.id,
			worldId: this.level.worldId,
			isBoss: this.level.isBoss,
			bossName: world.bossName,
			victory,
			score: this.score,
			stars,
			timeSec: Math.round(this.elapsedSec * 10) / 10,
			coinsEarned,
			crystalsEarned,
			secretsFound: this.runSecrets,
			enemiesDispersed: this.runEnemiesDispersed,
			dashesUsed: this.runDashes,
			jumpsUsed: this.runJumps,
			arrowsFired: this.runArrowsFired,
			worldJustCleared: isWorldClear,
			rewardBonusApplied: false,
			saveCoinsDelta,
			saveCrystalsDelta,
			saveSecretsDelta,
			saveEnemiesDelta,
			saveDashesDelta,
			saveJumpsDelta,
			saveArrowsDelta,
			saveTimeDeltaSec
		};
		const keysSnapshot = Array.from(this.newlyCollectedKeys);
		this.newlyCollectedKeys.clear();
		this.emitHud();
		this.onLevelEnd(summary, keysSnapshot);
	}
	updateScarfAndParticles(dt) {
		const nodes = this.player.scarfNodes;
		nodes[0].x = this.player.x + this.player.w / 2 - this.player.facing * 4;
		nodes[0].y = this.player.y + 13;
		const windX = -this.player.facing * 35 - this.player.vx * .14;
		for (let i = 1; i < nodes.length; i++) {
			const prev = nodes[i - 1];
			const cur = nodes[i];
			cur.x += windX * dt;
			cur.y += (Math.sin(this.time * 9 + i * .7) * 28 + 18) * dt;
			const dx = cur.x - prev.x;
			const dy = cur.y - prev.y;
			const dist = Math.hypot(dx, dy) || 1;
			const segLen = 5.5;
			if (dist > segLen) {
				cur.x = prev.x + dx / dist * segLen;
				cur.y = prev.y + dy / dist * segLen;
			}
		}
		for (let i = this.slashArcs.length - 1; i >= 0; i--) {
			this.slashArcs[i].life -= dt;
			this.slashArcs[i].x = this.player.x + this.player.w / 2 + this.slashArcs[i].facing * 12;
			this.slashArcs[i].y = this.player.y + this.player.h * .45;
			if (this.slashArcs[i].life <= 0) this.slashArcs.splice(i, 1);
		}
		for (let i = this.lightningArcs.length - 1; i >= 0; i--) {
			this.lightningArcs[i].life -= dt;
			if (this.lightningArcs[i].life <= 0) this.lightningArcs.splice(i, 1);
		}
		for (let i = this.explosionWaves.length - 1; i >= 0; i--) {
			this.explosionWaves[i].life -= dt;
			if (this.explosionWaves[i].life <= 0) this.explosionWaves.splice(i, 1);
		}
		for (let i = this.player.afterimages.length - 1; i >= 0; i--) {
			this.player.afterimages[i].alpha -= dt * 5.5;
			if (this.player.afterimages[i].alpha <= 0) this.player.afterimages.splice(i, 1);
		}
		for (let i = this.pulseWaves.length - 1; i >= 0; i--) {
			const w = this.pulseWaves[i];
			w.radius += dt * 620;
			w.alpha = Math.max(0, 1 - w.radius / w.maxRadius);
			if (w.radius >= w.maxRadius) this.pulseWaves.splice(i, 1);
		}
		for (const pt of this.particles) {
			if (!pt.active) continue;
			pt.x += pt.vx * dt;
			pt.y += pt.vy * dt;
			pt.vy += 260 * dt;
			pt.life -= dt;
			if (pt.life <= 0) pt.active = false;
		}
	}
	updateCamera(viewW, viewH, dt) {
		const lookAhead = this.player.facing * 90;
		const targetX = Math.max(0, Math.min(this.level.width - viewW, this.player.x + lookAhead - viewW * .42));
		const targetY = Math.max(-40, Math.min(this.level.height - viewH + 40, this.player.y - viewH * .56));
		const smooth = Math.min(1, dt * 7.5);
		this.cameraX += (targetX - this.cameraX) * smooth;
		this.cameraY += (targetY - this.cameraY) * smooth;
	}
	spawnBurst(x, y, count, color) {
		if (!this.save.settings.particlesEnabled) return;
		let spawned = 0;
		for (const pt of this.particles) if (!pt.active) {
			const ang = Math.random() * Math.PI * 2;
			const spd = 40 + Math.random() * 170;
			pt.active = true;
			pt.x = x;
			pt.y = y;
			pt.vx = Math.cos(ang) * spd;
			pt.vy = Math.sin(ang) * spd - 60;
			pt.size = 1.8 + Math.random() * 2.8;
			pt.maxLife = .35 + Math.random() * .35;
			pt.life = pt.maxLife;
			pt.color = color;
			spawned++;
			if (spawned >= count) break;
		}
	}
	shake(dur, intensity) {
		this.shakeTimer = Math.max(this.shakeTimer, dur);
		this.shakeIntensity = Math.max(this.shakeIntensity, intensity);
	}
	emitHud() {
		const dashLvl = getAbilityLevel(this.save, "shadowDash");
		const dashMax = Math.max(.55, 1.45 - dashLvl * .16);
		const pulseLvl = getAbilityLevel(this.save, "shadowPulse");
		const pulseMax = Math.max(1.6, 4.2 - pulseLvl * .45);
		const tfLvl = getAbilityLevel(this.save, "timeFocus");
		const tfMax = Math.max(5.5, 12 - tfLvl * 1.1);
		const tfDur = 2.4 + tfLvl * .65;
		const bowLvl = Math.max(1, getAbilityLevel(this.save, "bowMastery"));
		const bowMaxCd = Math.max(.18, .32 - (bowLvl - 1) * .025);
		const boss = this.enemies.find((e) => e.type === "boss" || e.type === "miniboss");
		const hints = this.level.tutorialHints;
		let activeHint = null;
		if (hints && hints.length > 0) {
			for (const h of hints) if (Math.abs(this.player.x - h.x) <= 185) {
				activeHint = h;
				break;
			}
		}
		this.onHudUpdate({
			hp: this.hp,
			maxHp: this.maxHp,
			shieldCharges: this.shieldCharges,
			maxShieldCharges: this.maxShieldCharges,
			arrowEnergy: Math.round(this.arrowEnergy),
			maxArrowEnergy: this.maxArrowEnergy,
			selectedArrow: this.selectedArrow,
			unlockedArrows: this.save.unlockedArrows?.length ? this.save.unlockedArrows : ["shadow"],
			bowCooldownRatio: Math.min(1, this.bowCooldown / bowMaxCd),
			bowCharging: this.player.bowAiming,
			bowChargeRatio: this.player.bowCharge,
			bowAimAngle: this.player.bowAngle,
			activeTutorialHint: activeHint,
			difficultyLabel: this.level.difficultyLabel,
			score: this.score,
			runCoins: this.runCoins,
			runCrystals: this.runCrystals,
			elapsedSec: this.elapsedSec,
			dashCooldownRatio: Math.min(1, this.dashCooldown / dashMax),
			pulseCooldownRatio: pulseLvl === 0 ? 1 : Math.min(1, this.pulseCooldown / pulseMax),
			timeFocusCooldownRatio: tfLvl === 0 ? 1 : Math.min(1, this.timeFocusCooldown / tfMax),
			timeFocusActiveRatio: tfLvl === 0 ? 0 : Math.min(1, this.timeFocusRemaining / tfDur),
			shieldCooldownRatio: this.maxShieldCharges > 0 && this.shieldCharges < this.maxShieldCharges ? Math.min(1, this.shieldRechargeTimer / 12) : 0,
			reviveShieldRemaining: Math.round(this.reviveShieldTimer * 10) / 10,
			bossHp: boss ? Math.max(0, boss.hp) : 0,
			bossMaxHp: boss ? boss.maxHp : 0,
			bossName: boss?.bossName || "",
			checkpointReached: this.checkpointReached,
			bonusBoostActive: this.bonusBoost,
			levelName: this.level.name,
			worldName: WORLD_MAP[this.level.worldId].name
		});
	}
	segmentIntersectsRect(x1, y1, x2, y2, rx, ry, rw, rh) {
		const steps = Math.max(3, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 8));
		for (let i = 0; i <= steps; i++) {
			const t = i / steps;
			const sx = x1 + (x2 - x1) * t;
			const sy = y1 + (y2 - y1) * t;
			if (sx >= rx && sx <= rx + rw && sy >= ry && sy <= ry + rh) return true;
		}
		return false;
	}
	aabb(ax, ay, aw, ah, bx, by, bw, bh) {
		return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
	}
	circleRect(cx, cy, cr, rx, ry, rw, rh) {
		const nx = Math.max(rx, Math.min(cx, rx + rw));
		const ny = Math.max(ry, Math.min(cy, ry + rh));
		const dx = cx - nx;
		const dy = cy - ny;
		return dx * dx + dy * dy <= cr * cr;
	}
};
// src/game/levels.ts
function getDifficultyLabel(levelId, isBoss) {
	if (levelId === 1) return "Tutorial";
	if (isBoss) return levelId === 60 ? "Final Boss" : "Boss Battle";
	if (levelId <= 5) return "Challenging";
	if (levelId <= 10) return "Hard";
	if (levelId <= 15) return "Very Hard";
	if (levelId <= 30) return "Advanced Hard";
	if (levelId <= 45) return "Expert";
	return "Master Challenge";
}
var WORLD_LEVEL_NAMES = {
	forest: [
		["Mossy Trail", "Cursed sentries prowl the ancient stones"],
		["Moonlit Clearing", "Cross the timber ravines"],
		["Lantern Path", "Ancient stones mark the way"],
		["Whispering Pines", "Armored sentries guard the woods"],
		["Timber Span", "Bridges groan above the mist"],
		["Hollow Trunk", "Spirits circle the canopy"],
		["Thorn Ravine", "Leap cleanly over briar spikes"],
		["Shrine Steps", "Ascend the forgotten torii"],
		["Misty Hollow", "Hidden relics lie above the fog"],
		["Watchful Woods", "Hunters stalk between the pines"],
		["Broken Causeway", "Shattered spans over deep abyss"],
		["Twin Canopies", "Scale the ancient pine walls"],
		["Sunken Brook", "Dash across the flooded gorge"],
		["Edge of the Glade", "Elite guardians defend the shrine"],
		["Sanctum of Roots", "Boss Encounter: Bramble Wraith"]
	],
	temple: [
		["Sunken Threshold", "Enter the buried stone halls"],
		["Brazier Corridor", "Amber flames pierce the gloom"],
		["Shifting Slabs", "Ancient stone lifts still turn"],
		["Crumbling Vault", "Tread lightly on weathered stone"],
		["Pendulum Hall", "Time your dash between swings"],
		["Rune Gate", "Wait for the ancient seals to part"],
		["Pillared Abyss", "Scale the carved monoliths"],
		["Crypt of Echoes", "Armored guardians patrol the dust"],
		["Suspended Altar", "Secret crystals crown the spire"],
		["Clockwork Chamber", "Synchronized lifts and blades"],
		["Twin Gates", "Dash swiftly before the seals lock"],
		["Collapsed Aqueduct", "Falling stones guard the chasm"],
		["Shadow Cloister", "Fast hunters prowl the lower hall"],
		["Inner Antechamber", "Elite temple knights await"],
		["Throne of Obsidian", "Boss Encounter: Obsidian Sentinel"]
	],
	mountains: [
		["Frostline Ascent", "Cold winds sweep the lower ridge"],
		["Glacial Ledge", "Keep steady footing on slick ice"],
		["Icicle Cavern", "Watch above for falling shards"],
		["Aurora Bridge", "Suspend your leap across the void"],
		["Frozen Shaft", "Wall-climb the twin ice cliffs"],
		["Rime Sawmills", "Spinning frost wheels guard the pass"],
		["Whiteout Gorge", "Dash cleanly through blizzard winds"],
		["Crystal Shelf", "Hidden paths wind beneath the peak"],
		["Avalanche Ridge", "Falling boulders thunder below"],
		["Shattered Glacier", "Crumbling ice shelves over spikes"],
		["Windcarved Spire", "Ascend the vertical chasm walls"],
		["Glacial Vault", "Timed ice gates and shifting lifts"],
		["Frosthunter Pass", "Agile shadow beasts hunt the ridge"],
		["Summit Approach", "The wyrm stirs atop the glacier"],
		["Peak of the Wyrm", "Boss Encounter: Glacial Wyrm"]
	],
	fortress: [
		["Obsidian Gate", "Cross the drawbridge into ash"],
		["Chain Chasm", "Suspended battlements in the dark"],
		["Furnace Shaft", "Mind the rising ember vents"],
		["Iron Pendulums", "Precision timing through steel arcs"],
		["Citadel Ramparts", "Crumbling bridges over crimson pits"],
		["Sentinel Keep", "Elite shadow knights hold the wall"],
		["Ember Gauntlet", "Timed fire jets and blade wheels"],
		["Tower of Chains", "Climb the vertical fortress spire"],
		["Eclipse Hall", "Secret relics hidden near the rafters"],
		["Shattered Bastion", "Moving iron lifts above the abyss"],
		["Bloodmoon Bridge", "Dash swiftly past twin hazards"],
		["Vault of Ash", "Multi-gate sanctuary of traps"],
		["High Battlements", "Hunters and guardians converge"],
		["Eclipse Stair", "The final ascent to the throne"],
		["Seat of the Eclipse", "Final Boss: Lord of the Eclipse"]
	]
};
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function enemyDimensions(type) {
	switch (type) {
		case "boss": return {
			w: 84,
			h: 108
		};
		case "miniboss": return {
			w: 58,
			h: 72
		};
		case "mage": return {
			w: 34,
			h: 48
		};
		case "elite": return {
			w: 42,
			h: 56
		};
		case "guardian": return {
			w: 40,
			h: 52
		};
		case "hunter": return {
			w: 38,
			h: 36
		};
		case "spirit": return {
			w: 36,
			h: 38
		};
		default: return {
			w: 32,
			h: 48
		};
	}
}
function enemyStats(type, worldTier, levelId = 1) {
	const isTutorial = levelId === 1;
	const lateBoost = levelId >= 10 ? 1 : 0;
	const speedScale = isTutorial ? .82 : levelId >= 30 ? 1.18 : levelId >= 6 ? 1.08 : 1;
	switch (type) {
		case "miniboss": return {
			hp: 8 + worldTier * 3,
			speed: Math.round((102 + worldTier * 15) * speedScale)
		};
		case "mage": return {
			hp: 2 + Math.floor(worldTier / 2) + lateBoost,
			speed: Math.round((72 + worldTier * 10) * speedScale)
		};
		case "elite": return {
			hp: 3 + worldTier,
			speed: Math.round((104 + worldTier * 12) * speedScale)
		};
		case "guardian": return {
			hp: 3 + Math.floor(worldTier / 2) + (levelId >= 16 ? 1 : 0),
			speed: Math.round((72 + worldTier * 10) * speedScale)
		};
		case "hunter": return {
			hp: 2 + (levelId >= 20 ? 1 : 0),
			speed: Math.round((152 + worldTier * 16) * speedScale)
		};
		case "spirit": return {
			hp: isTutorial ? 1 : 1 + (worldTier >= 2 ? 1 : 0) + (levelId >= 35 ? 1 : 0),
			speed: Math.round((95 + worldTier * 14) * speedScale)
		};
		default: return {
			hp: isTutorial ? 1 : levelId >= 12 ? 2 : 1,
			speed: Math.round((92 + worldTier * 12) * speedScale)
		};
	}
}
function addGroundedEnemy(enemies, id, type, platX, platY, platW, worldTier, levelId = 1, avoidRange) {
	const { w, h } = enemyDimensions(type);
	const { hp, speed } = enemyStats(type, worldTier, levelId);
	const margin = 22;
	let left = platX + margin;
	let right = platX + platW - margin;
	if (avoidRange) {
		const leftSpan = avoidRange.x1 - left;
		const rightSpan = right - avoidRange.x2;
		if (rightSpan >= leftSpan && rightSpan >= w + 36) left = avoidRange.x2 + 12;
		else if (leftSpan >= w + 36) right = avoidRange.x1 - 12;
	}
	if (right - left < w + 18) return;
	const spawnX = Math.round(left + (right - left - w) * .65);
	enemies.push({
		id,
		x: spawnX,
		y: platY - h,
		type,
		patrolLeft: left,
		patrolRight: right,
		speed,
		hp
	});
}
function buildBossLevel(id, worldId, indexInWorld, name, subtitle) {
	const world = WORLD_MAP[worldId];
	const worldTier = world.order;
	const arenaWidth = 1140 + worldTier * 40;
	const arenaHeight = 620;
	const floorY = 470;
	const platforms = [
		{
			id: `p_floor_${id}`,
			x: 0,
			y: floorY,
			w: arenaWidth,
			h: 160,
			type: "solid"
		},
		{
			id: `p_lwall_${id}`,
			x: -40,
			y: 0,
			w: 40,
			h: arenaHeight,
			type: "wall"
		},
		{
			id: `p_rwall_${id}`,
			x: arenaWidth,
			y: 0,
			w: 40,
			h: arenaHeight,
			type: "wall"
		},
		{
			id: `p_ledge_l_${id}`,
			x: 115,
			y: 350,
			w: 170 + worldTier * 5,
			h: 22,
			type: worldId === "mountains" ? "ice" : "solid"
		},
		{
			id: `p_ledge_r_${id}`,
			x: arenaWidth - 285 - worldTier * 5,
			y: 350,
			w: 170 + worldTier * 5,
			h: 22,
			type: worldId === "mountains" ? "ice" : "solid"
		},
		{
			id: `p_mid_${id}`,
			x: arenaWidth / 2 - 95,
			y: 255,
			w: 190,
			h: 20,
			type: worldId === "temple" || worldId === "fortress" ? "moving" : "bridge",
			moveAxis: "x",
			moveRange: 85,
			moveSpeed: 1.4
		}
	];
	const hazards = [];
	if (worldTier >= 2) hazards.push({
		id: `h_boss_sp1_${id}`,
		x: 340,
		y: 452,
		w: 48,
		h: 18,
		type: "spikes"
	}, {
		id: `h_boss_sp2_${id}`,
		x: arenaWidth - 388,
		y: 452,
		w: 48,
		h: 18,
		type: "spikes"
	});
	if (worldTier >= 3) hazards.push({
		id: `h_boss_pend_${id}`,
		x: arenaWidth / 2,
		y: 90,
		w: 28,
		h: 28,
		type: "pendulum",
		range: 145,
		speed: 1.6
	});
	const collectibles = [
		{
			id: `c_b1_${id}`,
			x: 190,
			y: 315,
			type: "coin"
		},
		{
			id: `c_b2_${id}`,
			x: arenaWidth - 190,
			y: 315,
			type: "coin"
		},
		{
			id: `c_bc_${id}`,
			x: arenaWidth / 2,
			y: 210,
			type: "crystal"
		}
	];
	const bossHp = 14 + worldTier * 7;
	const enemies = [{
		id: `boss_${id}`,
		x: arenaWidth - 260,
		y: 362,
		type: "boss",
		patrolLeft: 140,
		patrolRight: arenaWidth - 140,
		speed: 132 + worldTier * 22,
		hp: bossHp,
		bossName: world.bossName
	}, ...worldTier >= 2 ? [{
		id: `boss_minion_${id}`,
		x: arenaWidth / 2,
		y: 180,
		type: "spirit",
		patrolLeft: 220,
		patrolRight: arenaWidth - 220,
		speed: 112 + worldTier * 10,
		hp: 2 + Math.floor(worldTier / 2)
	}] : []];
	const decorations = [
		{
			x: 90,
			y: floorY,
			kind: worldId === "forest" ? "torii" : "pillar",
			scale: 1.15
		},
		{
			x: arenaWidth - 140,
			y: floorY,
			kind: worldId === "forest" ? "torii" : "pillar",
			scale: 1.15
		},
		{
			x: 300,
			y: floorY,
			kind: worldId === "forest" ? "lantern" : "brazier",
			scale: 1
		},
		{
			x: arenaWidth - 300,
			y: floorY,
			kind: worldId === "forest" ? "lantern" : "brazier",
			scale: 1
		}
	];
	return {
		id,
		worldId,
		indexInWorld,
		name,
		subtitle,
		difficultyLabel: getDifficultyLabel(id, true),
		isBoss: true,
		width: arenaWidth,
		height: arenaHeight,
		spawn: {
			x: 85,
			y: 418
		},
		exit: {
			x: arenaWidth - 115,
			y: 388,
			w: 54,
			h: 82
		},
		platforms,
		hazards,
		enemies,
		collectibles,
		checkpoints: [],
		decorations,
		parTimeSec: 85 + worldTier * 18,
		baseCoinReward: 180 + worldTier * 85,
		baseCrystalReward: 3 + worldTier * 2
	};
}
function pickSegments(worldId, indexInWorld, rand) {
	if (worldId === "forest" && indexInWorld === 1) return [
		"flat_run",
		"stepping_stones",
		"bridge_chasm",
		"high_low_split"
	];
	if (worldId === "forest" && indexInWorld === 2) return [
		"bridge_chasm",
		"ambush_gorge",
		"crumble_cross",
		"vertical_ascent",
		"saw_gauntlet"
	];
	const count = indexInWorld <= 3 ? 5 : indexInWorld <= 9 ? 6 : 7;
	const pool = {
		forest: [
			"ambush_gorge",
			"stepping_stones",
			"bridge_chasm",
			"high_low_split",
			"vertical_ascent",
			"crumble_cross",
			"moving_ferry",
			"saw_gauntlet"
		],
		temple: [
			"ambush_gorge",
			"stepping_stones",
			"crumble_cross",
			"moving_ferry",
			"pendulum_hall",
			"gate_trial",
			"high_low_split",
			"vertical_ascent"
		],
		mountains: [
			"ice_slide",
			"ambush_gorge",
			"stepping_stones",
			"vertical_ascent",
			"saw_gauntlet",
			"moving_ferry",
			"crumble_cross",
			"high_low_split"
		],
		fortress: [
			"ember_corridor",
			"ambush_gorge",
			"bridge_chasm",
			"moving_ferry",
			"pendulum_hall",
			"gate_trial",
			"saw_gauntlet",
			"vertical_ascent",
			"crumble_cross"
		]
	}[worldId];
	const chosen = [];
	for (let i = 0; i < count; i++) {
		const idx = Math.floor((rand() * pool.length + i + indexInWorld) % pool.length);
		let style = pool[idx];
		if (i > 0 && chosen[i - 1] === style) style = pool[(idx + 1) % pool.length];
		chosen.push(style);
	}
	return chosen;
}
function chooseGroundEnemy(difficulty, rand) {
	if (difficulty >= 16 && rand() > .68) return "elite";
	if (difficulty >= 3 && rand() > .68) return "mage";
	if (difficulty >= 4 && rand() > .52) return "guardian";
	if (difficulty >= 2 && rand() > .45) return "hunter";
	return "warrior";
}
function buildStandardLevel(id, worldId, indexInWorld, name, subtitle) {
	const rand = mulberry32(id * 9173 + 1337);
	const worldTier = WORLD_MAP[worldId].order;
	const difficulty = (worldTier - 1) * 14 + indexInWorld;
	const isTutorial = id === 1;
	const platforms = [];
	const hazards = [];
	const enemies = [];
	const collectibles = [];
	const checkpoints = [];
	const decorations = [];
	const tutorialHints = [];
	let cursorX = 0;
	let currentY = 440;
	let segIdx = 0;
	const startW = 310 + id % 5 * 14;
	platforms.push({
		id: `p_start_${id}`,
		x: 0,
		y: currentY,
		w: startW,
		h: 240,
		type: "solid"
	});
	decorations.push({
		x: 68,
		y: currentY,
		kind: worldId === "forest" ? "lantern" : worldId === "mountains" ? "shrine" : "brazier",
		scale: 1
	});
	collectibles.push({
		id: `c_s1_${id}`,
		x: 195,
		y: currentY - 34,
		type: "coin"
	});
	collectibles.push({
		id: `c_s2_${id}`,
		x: 245,
		y: currentY - 34,
		type: "coin"
	});
	cursorX = startW;
	const segments = pickSegments(worldId, indexInWorld, rand);
	const checkpointAfterSegment = Math.floor(segments.length / 2);
	const secondCheckpointAfter = segments.length >= 6 ? segments.length - 1 : -1;
	if (isTutorial) tutorialHints.push({
		id: "tut_move",
		x: 60,
		title: "Move & Double Jump",
		message: "Use Left / Right (A / D) to run, and tap Jump twice (Space) to Double-Jump gaps."
	}, {
		id: "tut_bow",
		x: 340,
		title: "Sword & Magical Bow",
		message: "Tap Sword (F) up close, or HOLD & DRAG the Bow button (G / Mouse) to aim & shoot flying spirits!"
	}, {
		id: "tut_traps",
		x: 690,
		title: "Traps & Shadow Dash",
		message: "Leap over iron spikes and use Shadow Dash (Shift) to cross wider ravines safely."
	});
	for (const style of segments) {
		segIdx++;
		const tag = `${id}_${segIdx}`;
		const gap = isTutorial ? 92 : Math.round(104 + rand() * Math.min(64, 24 + difficulty * .95));
		const addDeco = (dx, dy) => {
			const kinds = worldId === "forest" ? [
				"pine",
				"lantern",
				"torii",
				"waterfall"
			] : worldId === "temple" ? [
				"pillar",
				"brazier",
				"shrine",
				"statue"
			] : worldId === "mountains" ? [
				"icicle",
				"shrine",
				"pine"
			] : [
				"banner",
				"brazier",
				"chain",
				"statue"
			];
			decorations.push({
				x: dx,
				y: dy,
				kind: kinds[Math.floor(rand() * kinds.length)],
				scale: .9 + rand() * .35
			});
		};
		switch (style) {
			case "flat_run": {
				const platW = 390 + Math.round(rand() * 130);
				const deltaY = isTutorial ? -20 : Math.round((rand() - .5) * 60);
				currentY = Math.max(255, Math.min(480, currentY + deltaY));
				cursorX += Math.min(gap, 115);
				platforms.push({
					id: `p_flat_${tag}`,
					x: cursorX,
					y: currentY,
					w: platW,
					h: 250,
					type: worldId === "mountains" && rand() > .55 ? "ice" : "solid"
				});
				addDeco(cursorX + 55, currentY);
				let avoid;
				if (difficulty >= 2 || id === 1 && segIdx === 1) {
					const sx = cursorX + Math.round(platW * .56);
					const isHidden = !isTutorial && difficulty >= 3 && segIdx % 2 === 1;
					hazards.push({
						id: `h_sp_${tag}`,
						x: sx,
						y: currentY - 18,
						w: 44,
						h: 18,
						type: isHidden ? "hiddenSpikes" : "spikes"
					});
					avoid = {
						x1: sx - 10,
						x2: sx + 54
					};
					collectibles.push({
						id: `c_arc_${tag}`,
						x: sx + 22,
						y: currentY - 76,
						type: "coin"
					});
				}
				const eType = isTutorial ? "warrior" : chooseGroundEnemy(difficulty, rand);
				addGroundedEnemy(enemies, `e_flat_${tag}`, eType, cursorX, currentY, platW, worldTier, id, avoid);
				if (id === 1 && segIdx === 1 || difficulty >= 2 && rand() > .35) enemies.push({
					id: `e_flat_fly_${tag}`,
					x: cursorX + platW * .48,
					y: currentY - 148,
					type: "spirit",
					patrolLeft: cursorX + 16,
					patrolRight: cursorX + platW - 16,
					speed: (isTutorial ? 70 : 95) + worldTier * 14,
					hp: isTutorial ? 1 : 1 + (worldTier >= 2 ? 1 : 0)
				});
				collectibles.push({
					id: `c_f1_${tag}`,
					x: cursorX + 55,
					y: currentY - 34,
					type: "coin"
				});
				collectibles.push({
					id: `c_f2_${tag}`,
					x: cursorX + platW - 55,
					y: currentY - 34,
					type: "coin"
				});
				cursorX += platW;
				break;
			}
			case "stepping_stones": {
				const steps = isTutorial ? 3 : 3 + (rand() > .35 ? 1 : 0);
				const startOfSteps = cursorX;
				let midStepY = currentY;
				for (let s = 0; s < steps; s++) {
					cursorX += isTutorial ? 92 : Math.round(98 + rand() * 54);
					const stepUp = Math.round((rand() - .48) * (isTutorial ? 65 : 95));
					currentY = Math.max(225, Math.min(480, currentY + stepUp));
					if (s === 1) midStepY = currentY;
					const w = isTutorial ? 130 : Math.round(94 + rand() * 48);
					platforms.push({
						id: `p_step_${tag}_${s}`,
						x: cursorX,
						y: currentY,
						w,
						h: 26,
						type: worldId === "mountains" && s % 2 === 1 ? "ice" : "solid"
					});
					collectibles.push({
						id: `c_step_${tag}_${s}`,
						x: cursorX + w / 2,
						y: currentY - 34,
						type: s === steps - 1 && rand() > .65 ? "crystal" : "coin"
					});
					cursorX += w;
				}
				enemies.push({
					id: `e_fly_${tag}`,
					x: Math.round((startOfSteps + cursorX) * .5),
					y: midStepY - 108,
					type: !isTutorial && difficulty >= 6 && rand() > .5 ? "mage" : "spirit",
					patrolLeft: startOfSteps + 45,
					patrolRight: cursorX - 30,
					speed: 88 + worldTier * 16,
					hp: isTutorial ? 1 : 1 + (worldTier >= 2 ? 1 : 0)
				});
				break;
			}
			case "bridge_chasm": {
				cursorX += Math.min(gap, 118);
				const bridgeW = 240 + Math.round(rand() * 80);
				platforms.push({
					id: `p_br_l_${tag}`,
					x: cursorX,
					y: currentY,
					w: 115,
					h: 230,
					type: "solid"
				});
				platforms.push({
					id: `p_br_${tag}`,
					x: cursorX + 115,
					y: currentY + 4,
					w: bridgeW,
					h: 16,
					type: "bridge",
					collapses: !isTutorial && difficulty >= 2 && segIdx % 2 === 0
				});
				platforms.push({
					id: `p_br_r_${tag}`,
					x: cursorX + 115 + bridgeW,
					y: currentY,
					w: 155,
					h: 230,
					type: "solid"
				});
				if (difficulty >= 2) hazards.push({
					id: `h_dz_${tag}`,
					x: cursorX + 115,
					y: 595,
					w: bridgeW,
					h: 55,
					type: "dangerZone"
				});
				if (worldId === "forest") decorations.push({
					x: cursorX + 115 + bridgeW * .5,
					y: currentY + 120,
					kind: "waterfall",
					scale: 1
				});
				addDeco(cursorX + 48, currentY);
				collectibles.push({
					id: `c_br1_${tag}`,
					x: cursorX + 115 + bridgeW * .3,
					y: currentY - 40,
					type: "coin"
				});
				collectibles.push({
					id: `c_br2_${tag}`,
					x: cursorX + 115 + bridgeW * .7,
					y: currentY - 40,
					type: "coin"
				});
				addGroundedEnemy(enemies, `e_br_${tag}`, !isTutorial && difficulty >= 2 ? chooseGroundEnemy(difficulty, rand) : "warrior", cursorX + 115 + bridgeW, currentY, 155, worldTier, id);
				if (!isTutorial && difficulty >= 3) hazards.push({
					id: `h_br_rock_${tag}`,
					x: cursorX + 115 + bridgeW * .5,
					y: Math.max(60, currentY - 230),
					w: 32,
					h: 32,
					type: "fallingRock",
					period: Math.max(2, 3.2 - worldTier * .25),
					phase: rand() * 2
				});
				cursorX += 270 + bridgeW;
				break;
			}
			case "ambush_gorge": {
				cursorX += Math.min(gap, 125);
				const lowW = 330;
				platforms.push({
					id: `p_ag_low_${tag}`,
					x: cursorX,
					y: currentY,
					w: lowW,
					h: 235,
					type: "solid"
				});
				const perchX = cursorX + lowW + 95;
				const perchY = Math.max(225, currentY - 96);
				const perchW = 195;
				platforms.push({
					id: `p_ag_perch_${tag}`,
					x: perchX,
					y: perchY,
					w: perchW,
					h: 24,
					type: worldId === "mountains" ? "ice" : "solid"
				});
				const sx = cursorX + 125;
				hazards.push({
					id: `h_ag_sp_${tag}`,
					x: sx,
					y: currentY - 18,
					w: 44,
					h: 18,
					type: difficulty >= 5 ? "hiddenSpikes" : "spikes"
				});
				addGroundedEnemy(enemies, `e_ag_front_${tag}`, difficulty >= 4 ? "guardian" : "hunter", cursorX, currentY, lowW, worldTier, id, {
					x1: sx - 12,
					x2: sx + 56
				});
				addGroundedEnemy(enemies, `e_ag_mage_${tag}`, difficulty >= 14 ? "elite" : "mage", perchX, perchY, perchW, worldTier, id);
				enemies.push({
					id: `e_ag_sky_${tag}`,
					x: cursorX + lowW + 25,
					y: perchY - 75,
					type: "spirit",
					patrolLeft: cursorX + 80,
					patrolRight: perchX + perchW - 20,
					speed: 105 + worldTier * 12,
					hp: 2
				});
				collectibles.push({
					id: `c_ag_cry_${tag}`,
					x: perchX + perchW * .5,
					y: perchY - 36,
					type: "crystal"
				});
				currentY = perchY;
				cursorX = perchX + perchW;
				break;
			}
			case "crumble_cross": {
				const count = 3;
				const startCrumble = cursorX;
				for (let c = 0; c < count; c++) {
					cursorX += 108 + Math.round(rand() * 38);
					currentY = Math.max(240, Math.min(470, currentY + Math.round((rand() - .5) * 60)));
					const w = 92;
					platforms.push({
						id: `p_fall_${tag}_${c}`,
						x: cursorX,
						y: currentY,
						w,
						h: 22,
						type: "falling"
					});
					collectibles.push({
						id: `c_fall_${tag}_${c}`,
						x: cursorX + w / 2,
						y: currentY - 36,
						type: c === 1 ? "crystal" : "coin"
					});
					cursorX += w;
				}
				cursorX += 98;
				const landW = 200;
				platforms.push({
					id: `p_fall_end_${tag}`,
					x: cursorX,
					y: currentY,
					w: landW,
					h: 230,
					type: "solid"
				});
				addGroundedEnemy(enemies, `e_cr_${tag}`, chooseGroundEnemy(difficulty, rand), cursorX, currentY, landW, worldTier, id);
				enemies.push({
					id: `e_cr_sp_${tag}`,
					x: Math.round((startCrumble + cursorX) * .5),
					y: currentY - 125,
					type: "spirit",
					patrolLeft: startCrumble + 60,
					patrolRight: cursorX - 20,
					speed: 98 + worldTier * 14,
					hp: 1 + (worldTier >= 2 ? 1 : 0)
				});
				cursorX += landW;
				break;
			}
			case "moving_ferry": {
				cursorX += 98;
				const axis = rand() > .35 ? "x" : "y";
				const range = axis === "x" ? 140 : 85;
				const ferryW = 108;
				platforms.push({
					id: `p_mov_${tag}`,
					x: cursorX + (axis === "x" ? range * .45 : 0),
					y: currentY - (axis === "y" ? 35 : 0),
					w: ferryW,
					h: 22,
					type: "moving",
					moveAxis: axis,
					moveRange: range,
					moveSpeed: 1.25 + worldTier * .22,
					phase: rand() * Math.PI
				});
				collectibles.push({
					id: `c_mov_${tag}`,
					x: cursorX + (axis === "x" ? range * .5 + ferryW / 2 : ferryW / 2),
					y: currentY - 75,
					type: "coin"
				});
				if (axis === "x") cursorX += ferryW + range + 92;
				else cursorX += 210;
				const landW = 205;
				platforms.push({
					id: `p_mov_land_${tag}`,
					x: cursorX,
					y: currentY,
					w: landW,
					h: 230,
					type: "solid"
				});
				enemies.push({
					id: `e_mov_sp_${tag}`,
					x: cursorX + 40,
					y: currentY - 115,
					type: "spirit",
					patrolLeft: cursorX - 95,
					patrolRight: cursorX + landW - 20,
					speed: 102 + worldTier * 14,
					hp: 1 + (worldTier >= 2 ? 1 : 0)
				});
				addGroundedEnemy(enemies, `e_mov_g_${tag}`, chooseGroundEnemy(difficulty, rand), cursorX, currentY, landW, worldTier, id);
				cursorX += landW;
				break;
			}
			case "vertical_ascent": {
				cursorX += 95;
				const baseW = 180;
				platforms.push({
					id: `p_va_base_${tag}`,
					x: cursorX,
					y: currentY,
					w: baseW,
					h: 230,
					type: "solid"
				});
				addGroundedEnemy(enemies, `e_va_low_${tag}`, difficulty >= 4 ? "hunter" : "warrior", cursorX, currentY, baseW, worldTier, id);
				const wallX = cursorX + baseW + 85;
				const topY = Math.max(205, currentY - 145);
				platforms.push({
					id: `p_va_mid_${tag}`,
					x: cursorX + 35,
					y: currentY - 82,
					w: 95,
					h: 20,
					type: "solid"
				});
				const wallW = 205;
				platforms.push({
					id: `p_va_wall_${tag}`,
					x: wallX,
					y: topY,
					w: wallW,
					h: 370,
					type: "wall"
				});
				addGroundedEnemy(enemies, `e_va_top_${tag}`, chooseGroundEnemy(difficulty, rand), wallX, topY, wallW, worldTier, id);
				collectibles.push({
					id: `c_va1_${tag}`,
					x: cursorX + 82,
					y: currentY - 115,
					type: "coin"
				});
				collectibles.push({
					id: `c_va2_${tag}`,
					x: wallX + 75,
					y: topY - 35,
					type: "crystal"
				});
				currentY = topY;
				cursorX = wallX + wallW;
				break;
			}
			case "pendulum_hall": {
				cursorX += 100;
				const hallW = 400;
				platforms.push({
					id: `p_pend_${tag}`,
					x: cursorX,
					y: currentY,
					w: hallW,
					h: 235,
					type: "solid"
				});
				hazards.push({
					id: `h_pend_${tag}`,
					x: cursorX + hallW * .5,
					y: currentY - 210,
					w: 28,
					h: 28,
					type: "pendulum",
					range: 145,
					speed: 1.65 + worldTier * .22,
					phase: rand() * Math.PI
				});
				collectibles.push({
					id: `c_pend_${tag}`,
					x: cursorX + hallW * .5,
					y: currentY - 35,
					type: "coin"
				});
				addGroundedEnemy(enemies, `e_pend_${tag}`, chooseGroundEnemy(difficulty, rand), cursorX, currentY, hallW, worldTier, id, {
					x1: cursorX + hallW * .36,
					x2: cursorX + hallW * .64
				});
				addDeco(cursorX + 45, currentY);
				cursorX += hallW;
				break;
			}
			case "gate_trial": {
				cursorX += 95;
				const w = 390;
				platforms.push({
					id: `p_gt_floor_${tag}`,
					x: cursorX,
					y: currentY,
					w,
					h: 235,
					type: "solid"
				});
				platforms.push({
					id: `p_gate_${tag}`,
					x: cursorX + 180,
					y: currentY - 115,
					w: 26,
					h: 115,
					type: "gate",
					openDuration: 2.2,
					closedDuration: 1.8,
					phase: rand() * 2
				});
				platforms.push({
					id: `p_gt_top_${tag}`,
					x: cursorX + 125,
					y: currentY - 135,
					w: 120,
					h: 20,
					type: "solid"
				});
				addGroundedEnemy(enemies, `e_gt_${tag}`, chooseGroundEnemy(difficulty, rand), cursorX + 215, currentY, 175, worldTier, id);
				collectibles.push({
					id: `c_gt_${tag}`,
					x: cursorX + 185,
					y: currentY - 170,
					type: "crystal"
				});
				collectibles.push({
					id: `c_gt2_${tag}`,
					x: cursorX + 280,
					y: currentY - 34,
					type: "coin"
				});
				cursorX += w;
				break;
			}
			case "ice_slide": {
				cursorX += 98;
				const iceW = 365;
				platforms.push({
					id: `p_ice_${tag}`,
					x: cursorX,
					y: currentY,
					w: iceW,
					h: 235,
					type: "ice"
				});
				const sx = cursorX + 145;
				hazards.push({
					id: `h_ice_sp_${tag}`,
					x: sx,
					y: currentY - 18,
					w: 44,
					h: 18,
					type: "spikes"
				});
				collectibles.push({
					id: `c_ice1_${tag}`,
					x: cursorX + 60,
					y: currentY - 34,
					type: "coin"
				});
				collectibles.push({
					id: `c_ice2_${tag}`,
					x: cursorX + 166,
					y: currentY - 82,
					type: "coin"
				});
				addGroundedEnemy(enemies, `e_ice_${tag}`, chooseGroundEnemy(difficulty, rand), cursorX, currentY, iceW, worldTier, id, {
					x1: sx - 10,
					x2: sx + 54
				});
				cursorX += iceW;
				break;
			}
			case "saw_gauntlet": {
				cursorX += 98;
				const w = 395;
				platforms.push({
					id: `p_saw_${tag}`,
					x: cursorX,
					y: currentY,
					w,
					h: 235,
					type: "solid"
				});
				hazards.push({
					id: `h_saw_${tag}`,
					x: cursorX + w * .5,
					y: currentY - 18,
					w: 40,
					h: 40,
					type: "saw",
					radius: 22,
					range: 85,
					speed: 2.1 + worldTier * .25,
					phase: rand() * Math.PI
				});
				enemies.push({
					id: `e_saw_sp_${tag}`,
					x: cursorX + w * .5,
					y: currentY - 125,
					type: "spirit",
					patrolLeft: cursorX + 20,
					patrolRight: cursorX + w - 20,
					speed: 108 + worldTier * 12,
					hp: 2
				});
				collectibles.push({
					id: `c_saw1_${tag}`,
					x: cursorX + w * .5,
					y: currentY - 86,
					type: "coin"
				});
				cursorX += w;
				break;
			}
			case "high_low_split": {
				cursorX += 95;
				const splitW = 375;
				platforms.push({
					id: `p_hl_low_${tag}`,
					x: cursorX,
					y: currentY,
					w: splitW,
					h: 235,
					type: "solid"
				});
				platforms.push({
					id: `p_hl_step_${tag}`,
					x: cursorX + 18,
					y: currentY - 82,
					w: 88,
					h: 20,
					type: "solid"
				});
				platforms.push({
					id: `p_hl_secret_${tag}`,
					x: cursorX + 125,
					y: currentY - 150,
					w: 185,
					h: 22,
					type: "solid",
					concealsSecret: true
				});
				collectibles.push({
					id: `c_secret_${tag}`,
					x: cursorX + 218,
					y: currentY - 186,
					type: segIdx % 2 === 0 ? "secret" : "treasure"
				});
				collectibles.push({
					id: `c_hl_l1_${tag}`,
					x: cursorX + 160,
					y: currentY - 34,
					type: "coin"
				});
				addGroundedEnemy(enemies, `e_hl_${tag}`, isTutorial ? "warrior" : chooseGroundEnemy(difficulty, rand), cursorX, currentY, splitW, worldTier, id);
				cursorX += splitW;
				break;
			}
			case "ember_corridor": {
				cursorX += 100;
				const w = 415;
				platforms.push({
					id: `p_emb_${tag}`,
					x: cursorX,
					y: currentY,
					w,
					h: 235,
					type: "solid"
				});
				hazards.push({
					id: `h_fire1_${tag}`,
					x: cursorX + 110,
					y: currentY - 95,
					w: 28,
					h: 95,
					type: "fireJet",
					period: 2.7,
					phase: 0
				});
				hazards.push({
					id: `h_fire2_${tag}`,
					x: cursorX + 260,
					y: currentY - 95,
					w: 28,
					h: 95,
					type: "fireJet",
					period: 2.7,
					phase: 1.35
				});
				addGroundedEnemy(enemies, `e_emb_${tag}`, difficulty >= 38 ? "elite" : "guardian", cursorX + 295, currentY, 120, worldTier, id);
				collectibles.push({
					id: `c_emb_${tag}`,
					x: cursorX + 185,
					y: currentY - 44,
					type: "crystal"
				});
				cursorX += w;
				break;
			}
		}
		if (segIdx === checkpointAfterSegment || segIdx === secondCheckpointAfter) {
			cursorX += 90;
			platforms.push({
				id: `p_cp_${id}_${segIdx}`,
				x: cursorX,
				y: currentY,
				w: 185,
				h: 235,
				type: "solid"
			});
			checkpoints.push({
				id: `cp_${id}_${segIdx}`,
				x: cursorX + 92,
				y: currentY
			});
			if (isTutorial && segIdx === checkpointAfterSegment) tutorialHints.push({
				id: "tut_cp",
				x: cursorX + 40,
				title: "Shrine Checkpoint",
				message: "Pass beneath the stone lantern to light your checkpoint before clearing the rest of the woods."
			});
			cursorX += 185;
		}
	}
	const isMiniboss = indexInWorld === 8;
	cursorX += 95;
	const endW = isMiniboss ? 490 : 320;
	platforms.push({
		id: `p_end_${id}`,
		x: cursorX,
		y: currentY,
		w: endW,
		h: 245,
		type: "solid"
	});
	decorations.push({
		x: cursorX + endW - 105,
		y: currentY,
		kind: worldId === "forest" ? "torii" : "shrine",
		scale: 1.15
	});
	collectibles.push({
		id: `c_end_tr_${id}`,
		x: cursorX + 65,
		y: currentY - 36,
		type: "treasure"
	});
	if (isMiniboss) {
		const { hp, speed } = enemyStats("miniboss", worldTier, id);
		const { h } = enemyDimensions("miniboss");
		enemies.push({
			id: `e_miniboss_${id}`,
			x: cursorX + 225,
			y: currentY - h,
			type: "miniboss",
			patrolLeft: cursorX + 36,
			patrolRight: cursorX + endW - 95,
			speed,
			hp,
			bossName: WORLD_MAP[worldId].minibossName
		});
	} else addGroundedEnemy(enemies, `e_exit_guard_${id}`, isTutorial ? "warrior" : difficulty >= 16 ? "elite" : difficulty >= 3 ? "guardian" : "warrior", cursorX, currentY, 195, worldTier, id);
	const levelWidth = cursorX + endW;
	return {
		id,
		worldId,
		indexInWorld,
		name,
		subtitle,
		difficultyLabel: getDifficultyLabel(id, false),
		isBoss: false,
		isMiniboss,
		width: levelWidth,
		height: 660,
		spawn: {
			x: 80,
			y: 388
		},
		exit: {
			x: cursorX + endW - 105,
			y: currentY - 82,
			w: 54,
			h: 82
		},
		platforms,
		hazards,
		enemies,
		collectibles,
		checkpoints,
		decorations,
		tutorialHints: tutorialHints.length > 0 ? tutorialHints : void 0,
		parTimeSec: 45 + segments.length * 10 + worldTier * 5 + (isMiniboss ? 15 : 0),
		baseCoinReward: 40 + id * 4 + (isMiniboss ? 50 : 0),
		baseCrystalReward: indexInWorld % 3 === 0 || isMiniboss ? 2 : 1
	};
}
function generateAll60Levels() {
	const levels = [];
	const worlds = [
		"forest",
		"temple",
		"mountains",
		"fortress"
	];
	let idCounter = 1;
	for (const worldId of worlds) {
		const names = WORLD_LEVEL_NAMES[worldId];
		for (let i = 0; i < 15; i++) {
			const indexInWorld = i + 1;
			const [name, subtitle] = names[i];
			if (indexInWorld === 15) levels.push(buildBossLevel(idCounter, worldId, indexInWorld, name, subtitle));
			else levels.push(buildStandardLevel(idCounter, worldId, indexInWorld, name, subtitle));
			idCounter++;
		}
	}
	return levels;
}
var ALL_LEVELS = generateAll60Levels();
function getLevelById(levelId) {
	return ALL_LEVELS.find((l) => l.id === levelId) || ALL_LEVELS[0];
}
function getLevelsForWorld(worldId) {
	return ALL_LEVELS.filter((l) => l.worldId === worldId);
}
// src/components/GameViewport.tsx
var GameViewport = ({ levelId, save, paused, suspended = false, bonusBoost, reviveToken, onPauseToggle, onLevelEnd, engineRefOut }) => {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const onLevelEndRef = (0, import_react.useRef)(onLevelEnd);
	onLevelEndRef.current = onLevelEnd;
	const inputRef = (0, import_react.useRef)({
		left: false,
		right: false,
		jumpHeld: false,
		jumpPressed: false,
		dashPressed: false,
		attackPressed: false,
		pulsePressed: false,
		timeFocusPressed: false,
		bowHeld: false,
		bowAimActive: false,
		bowAimAngle: 0,
		cycleArrowPressed: false
	});
	const activePointersRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const bowPointerRef = (0, import_react.useRef)(null);
	const canvasAimPointerRef = (0, import_react.useRef)(null);
	const [pressedBtns, setPressedBtns] = (0, import_react.useState)({});
	const [bowDragOffset, setBowDragOffset] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const level = getLevelById(levelId);
	const unlockedArrowsInitial = save.unlockedArrows?.length ? save.unlockedArrows : ["shadow"];
	const selectedArrowInitial = unlockedArrowsInitial.includes(save.selectedArrow) ? save.selectedArrow : unlockedArrowsInitial[0];
	const bowLvl = Math.max(1, getAbilityLevel(save, "bowMastery"));
	const hasExtraLife = typeof bonusBoost === "boolean" ? bonusBoost : Boolean(bonusBoost.extraLife);
	const hasArrowBoost = typeof bonusBoost === "boolean" ? bonusBoost : Boolean(bonusBoost.arrowEnergyBoost);
	const hasShieldBoost = typeof bonusBoost === "boolean" ? bonusBoost : Boolean(bonusBoost.shadowShieldBoost);
	const maxEnergyInitial = 100 + (bowLvl - 1) * 18 + (hasArrowBoost ? 50 : 0);
	const [hud, setHud] = (0, import_react.useState)({
		hp: hasExtraLife ? 4 : 3,
		maxHp: hasExtraLife ? 4 : 3,
		shieldCharges: hasShieldBoost ? 1 : 0,
		maxShieldCharges: hasShieldBoost ? 1 : 0,
		arrowEnergy: maxEnergyInitial,
		maxArrowEnergy: maxEnergyInitial,
		selectedArrow: selectedArrowInitial,
		unlockedArrows: unlockedArrowsInitial,
		bowCooldownRatio: 0,
		bowCharging: false,
		bowChargeRatio: 0,
		bowAimAngle: 0,
		activeTutorialHint: level.tutorialHints?.[0] ?? null,
		difficultyLabel: level.difficultyLabel,
		score: 0,
		runCoins: 0,
		runCrystals: 0,
		elapsedSec: 0,
		dashCooldownRatio: 0,
		pulseCooldownRatio: 0,
		timeFocusCooldownRatio: 0,
		timeFocusActiveRatio: 0,
		shieldCooldownRatio: 0,
		reviveShieldRemaining: 0,
		bossHp: 0,
		bossMaxHp: 0,
		bossName: "",
		checkpointReached: false,
		bonusBoostActive: Boolean(hasExtraLife || hasArrowBoost || hasShieldBoost),
		levelName: level.name,
		worldName: ""
	});
	(0, import_react.useEffect)(() => {
		const lvl = getLevelById(levelId);
		const eng = new ShadowNinjaEngine(lvl, save, bonusBoost, (snap) => setHud(snap), (summary, newKeys) => {
			onLevelEndRef.current(summary, newKeys, eng.canReviveAtCheckpoint());
		});
		engineRef.current = eng;
		if (engineRefOut) engineRefOut.current = eng;
		soundEngine.startMusic(lvl.isBoss ? "boss" : lvl.worldId);
		spriteLibrary.ensureLoaded();
		return () => {
			engineRef.current = null;
			if (engineRefOut) engineRefOut.current = null;
		};
	}, [levelId, bonusBoost]);
	(0, import_react.useEffect)(() => {
		if (reviveToken > 0 && engineRef.current) {
			inputRef.current = {
				left: false,
				right: false,
				jumpHeld: false,
				jumpPressed: false,
				dashPressed: false,
				attackPressed: false,
				pulsePressed: false,
				timeFocusPressed: false,
				bowHeld: false,
				bowAimActive: false,
				bowAimAngle: 0,
				cycleArrowPressed: false
			};
			activePointersRef.current.clear();
			bowPointerRef.current = null;
			canvasAimPointerRef.current = null;
			setPressedBtns({});
			setBowDragOffset({
				x: 0,
				y: 0
			});
			engineRef.current.reviveFromDeathSnapshot();
			const lvl = getLevelById(levelId);
			soundEngine.onAppResume();
			soundEngine.startMusic(lvl.isBoss ? "boss" : lvl.worldId);
		}
	}, [reviveToken, levelId]);
	(0, import_react.useEffect)(() => {
		engineRef.current?.setPaused(paused || suspended);
		if (paused || suspended) {
			inputRef.current.left = false;
			inputRef.current.right = false;
			inputRef.current.jumpHeld = false;
			inputRef.current.bowHeld = false;
			inputRef.current.bowAimActive = false;
			activePointersRef.current.clear();
			bowPointerRef.current = null;
			canvasAimPointerRef.current = null;
			setPressedBtns({});
			setBowDragOffset({
				x: 0,
				y: 0
			});
		}
	}, [paused, suspended]);
	(0, import_react.useEffect)(() => {
		if (suspended) return;
		let rafId = 0;
		let lastTime = performance.now();
		const loop = (now) => {
			const dt = (now - lastTime) / 1e3;
			lastTime = now;
			const canvas = canvasRef.current;
			const eng = engineRef.current;
			if (canvas && eng) {
				const parent = canvas.parentElement;
				const cssW = parent ? parent.clientWidth : window.innerWidth;
				const cssH = parent ? parent.clientHeight : window.innerHeight;
				const viewH = 540;
				const aspect = Math.max(1.3, Math.min(2.4, cssW / Math.max(1, cssH)));
				const viewW = Math.round(viewH * aspect);
				if (canvas.width !== viewW || canvas.height !== viewH) {
					canvas.width = viewW;
					canvas.height = viewH;
				}
				const ctx = canvas.getContext("2d", { alpha: false });
				if (ctx) eng.stepAndRender(dt, inputRef.current, ctx, viewW, viewH);
			}
			rafId = requestAnimationFrame(loop);
		};
		rafId = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(rafId);
	}, [suspended]);
	(0, import_react.useEffect)(() => {
		const onKeyDown = (e) => {
			soundEngine.unlock();
			if (e.code === "ArrowLeft" || e.code === "KeyA") inputRef.current.left = true;
			if (e.code === "ArrowRight" || e.code === "KeyD") inputRef.current.right = true;
			if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") {
				if (!e.repeat) inputRef.current.jumpPressed = true;
				inputRef.current.jumpHeld = true;
			}
			if ((e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyK") && !e.repeat) inputRef.current.dashPressed = true;
			if ((e.code === "KeyF" || e.code === "KeyX" || e.code === "Enter") && !e.repeat) inputRef.current.attackPressed = true;
			if ((e.code === "KeyG" || e.code === "KeyC") && !e.repeat) {
				inputRef.current.bowHeld = true;
				inputRef.current.bowAimActive = false;
			}
			if (e.code === "KeyR" && !e.repeat) inputRef.current.cycleArrowPressed = true;
			if (e.code.startsWith("Digit") && !e.repeat) {
				const idx = Number(e.code.slice(5)) - 1;
				if (idx >= 0 && idx < ARROW_TYPES.length) engineRef.current?.selectArrow(ARROW_TYPES[idx].id);
			}
			if ((e.code === "KeyJ" || e.code === "KeyE") && !e.repeat) inputRef.current.pulsePressed = true;
			if ((e.code === "KeyT" || e.code === "KeyQ") && !e.repeat) inputRef.current.timeFocusPressed = true;
			if ((e.code === "Escape" || e.code === "KeyP") && !e.repeat) onPauseToggle();
		};
		const onKeyUp = (e) => {
			if (e.code === "ArrowLeft" || e.code === "KeyA") inputRef.current.left = false;
			if (e.code === "ArrowRight" || e.code === "KeyD") inputRef.current.right = false;
			if (e.code === "Space" || e.code === "ArrowUp" || e.code === "KeyW") inputRef.current.jumpHeld = false;
			if (e.code === "KeyG" || e.code === "KeyC") {
				inputRef.current.bowHeld = false;
				inputRef.current.bowAimActive = false;
			}
		};
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("keyup", onKeyUp);
		return () => {
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
		};
	}, [onPauseToggle]);
	(0, import_react.useEffect)(() => {
		if (!suspended) return;
		const stopKeys = (e) => {
			if (e.code === "Escape" || e.code === "KeyP") e.stopPropagation();
		};
		window.addEventListener("keydown", stopKeys, true);
		return () => window.removeEventListener("keydown", stopKeys, true);
	}, [suspended]);
	const handleTouchDown = (action) => (e) => {
		e.preventDefault();
		e.stopPropagation();
		soundEngine.unlock();
		try {
			e.currentTarget.setPointerCapture(e.pointerId);
		} catch {}
		activePointersRef.current.set(e.pointerId, action);
		setPressedBtns((prev) => ({
			...prev,
			[action]: true
		}));
		if (action === "left") inputRef.current.left = true;
		if (action === "right") inputRef.current.right = true;
		if (action === "jump") {
			inputRef.current.jumpPressed = true;
			inputRef.current.jumpHeld = true;
		}
		if (action === "dash") inputRef.current.dashPressed = true;
		if (action === "attack") inputRef.current.attackPressed = true;
		if (action === "pulse") inputRef.current.pulsePressed = true;
		if (action === "timeFocus") inputRef.current.timeFocusPressed = true;
		if (action === "cycleArrow") inputRef.current.cycleArrowPressed = true;
	};
	const handleTouchUp = (action) => (e) => {
		e.preventDefault();
		e.stopPropagation();
		activePointersRef.current.delete(e.pointerId);
		setPressedBtns((prev) => ({
			...prev,
			[action]: false
		}));
		if (action === "left") inputRef.current.left = false;
		if (action === "right") inputRef.current.right = false;
		if (action === "jump") inputRef.current.jumpHeld = false;
	};
	const handleBowDown = (e) => {
		e.preventDefault();
		e.stopPropagation();
		soundEngine.unlock();
		try {
			e.currentTarget.setPointerCapture(e.pointerId);
		} catch {}
		const rect = e.currentTarget.getBoundingClientRect();
		bowPointerRef.current = {
			pointerId: e.pointerId,
			cx: rect.left + rect.width / 2,
			cy: rect.top + rect.height / 2
		};
		setPressedBtns((prev) => ({
			...prev,
			bow: true
		}));
		setBowDragOffset({
			x: 0,
			y: 0
		});
		inputRef.current.bowHeld = true;
		inputRef.current.bowAimActive = false;
	};
	const handleBowMove = (e) => {
		const active = bowPointerRef.current;
		if (!active || active.pointerId !== e.pointerId) return;
		e.preventDefault();
		const dx = e.clientX - active.cx;
		const dy = e.clientY - active.cy;
		const dist = Math.hypot(dx, dy);
		const clampMax = 24;
		const scale = dist > clampMax ? clampMax / dist : 1;
		setBowDragOffset({
			x: dx * scale,
			y: dy * scale
		});
		if (dist > 8) {
			inputRef.current.bowAimActive = true;
			inputRef.current.bowAimAngle = Math.atan2(dy, dx);
		} else inputRef.current.bowAimActive = false;
	};
	const handleBowUp = (e) => {
		const active = bowPointerRef.current;
		if (active && active.pointerId !== e.pointerId) return;
		e.preventDefault();
		e.stopPropagation();
		bowPointerRef.current = null;
		setPressedBtns((prev) => ({
			...prev,
			bow: false
		}));
		setBowDragOffset({
			x: 0,
			y: 0
		});
		inputRef.current.bowHeld = false;
	};
	const updateCanvasAim = (e) => {
		const rect = e.currentTarget.getBoundingClientRect();
		const anchorX = rect.left + rect.width * .36;
		const anchorY = rect.top + rect.height * .58;
		const dx = e.clientX - anchorX;
		const dy = e.clientY - anchorY;
		if (Math.hypot(dx, dy) > 10) {
			inputRef.current.bowAimActive = true;
			inputRef.current.bowAimAngle = Math.atan2(dy, dx);
		}
	};
	const handleCanvasPointerDown = (e) => {
		if (e.pointerType === "touch" || paused) return;
		soundEngine.unlock();
		canvasAimPointerRef.current = e.pointerId;
		try {
			e.currentTarget.setPointerCapture(e.pointerId);
		} catch {}
		inputRef.current.bowHeld = true;
		updateCanvasAim(e);
	};
	const handleCanvasPointerMove = (e) => {
		if (canvasAimPointerRef.current !== e.pointerId) return;
		updateCanvasAim(e);
	};
	const handleCanvasPointerUp = (e) => {
		if (canvasAimPointerRef.current !== e.pointerId) return;
		canvasAimPointerRef.current = null;
		inputRef.current.bowHeld = false;
		inputRef.current.bowAimActive = false;
	};
	const pulseUnlocked = getAbilityLevel(save, "shadowPulse") > 0;
	const timeFocusUnlocked = getAbilityLevel(save, "timeFocus") > 0;
	const showControls = save.settings.showTouchControls;
	const worldName = hud.worldName || WORLD_MAP[level.worldId].name;
	const currentArrowDef = ARROW_MAP[hud.selectedArrow] ?? ARROW_MAP.shadow;
	const energyPct = Math.max(0, Math.min(100, hud.arrowEnergy / Math.max(1, hud.maxArrowEnergy) * 100));
	const hasEnoughEnergy = hud.arrowEnergy >= currentArrowDef.energyCost;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative w-full h-full bg-black overflow-hidden select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				onPointerDown: handleCanvasPointerDown,
				onPointerMove: handleCanvasPointerMove,
				onPointerUp: handleCanvasPointerUp,
				onPointerCancel: handleCanvasPointerUp,
				className: "w-full h-full block object-cover cursor-crosshair"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-0 inset-x-0 px-4 pt-3 flex items-start justify-between gap-4 z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 bg-[#090c14]/85 backdrop-blur-md border border-amber-500/25 rounded-xl px-3.5 py-2 shadow-lg shadow-black/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-1.5",
									"aria-label": `Health ${hud.hp} of ${hud.maxHp}`,
									children: Array.from({ length: hud.maxHp }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 24 24",
										className: `w-4.5 h-4.5 transition-opacity ${i < hud.hp ? "text-red-500 opacity-100 drop-shadow-[0_0_6px_rgba(239,68,68,0.65)]" : "text-slate-700 opacity-65"}`,
										fill: "currentColor",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" })
									}, i))
								}),
								hud.maxShieldCharges > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-1 pl-2.5 border-l border-white/15",
									children: Array.from({ length: hud.maxShieldCharges }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 24 24",
										className: `w-4.5 h-4.5 ${i < hud.shieldCharges ? "text-sky-400 drop-shadow-[0_0_6px_rgba(56,189,248,0.65)]" : "text-slate-700"}`,
										fill: "currentColor",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3z" })
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-medium text-slate-200 pl-2.5 border-l border-white/15 hidden sm:inline tracking-wide whitespace-nowrap",
									children: [
										worldName,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-slate-500",
											children: "·"
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono-tabular text-amber-200",
											children: [level.indexInWorld, "/15"]
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-slate-500",
											children: "·"
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display font-semibold text-white",
											children: hud.levelName
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 bg-[#090c14]/80 backdrop-blur-md border border-white/12 rounded-lg px-2.5 py-1 shadow-md shadow-black/50",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-2.5 h-2.5 rounded-full shrink-0",
											style: {
												backgroundColor: currentArrowDef.color,
												boxShadow: `0 0 8px ${currentArrowDef.glowColor}`
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-semibold text-slate-100 whitespace-nowrap",
											children: currentArrowDef.shortName
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-20 h-1.5 bg-slate-900 rounded-full overflow-hidden border border-white/10",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full transition-all duration-100",
												style: {
													width: `${energyPct}%`,
													backgroundColor: hasEnoughEnergy ? currentArrowDef.glowColor : "#64748b"
												}
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-mono-tabular text-slate-300",
											children: Math.floor(hud.arrowEnergy)
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-wider font-semibold text-amber-200/85 bg-[#090c14]/75 px-2 py-1 rounded-md border border-amber-500/20 hidden md:inline",
									children: hud.difficultyLabel
								}),
								hud.checkpointReached && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-medium text-emerald-300 bg-[#090c14]/80 px-2.5 py-0.5 rounded-md border border-emerald-500/35",
									children: "Shrine Lit"
								}),
								hud.reviveShieldRemaining > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-mono-tabular font-semibold text-amber-200 bg-amber-500/20 px-2.5 py-0.5 rounded-md border border-amber-400/50 animate-pulse",
									children: [
										"Revive Shield ",
										hud.reviveShieldRemaining.toFixed(1),
										"s"
									]
								})
							]
						})]
					}),
					hud.bossMaxHp > 0 && hud.bossHp > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 max-w-sm bg-[#090c14]/85 backdrop-blur-md border border-red-500/40 rounded-xl px-4 py-2 shadow-lg shadow-black/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs font-semibold text-red-200 mb-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display tracking-wide",
								children: hud.bossName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono-tabular",
								children: [
									hud.bossHp,
									" / ",
									hud.bossMaxHp
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-white/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-gradient-to-r from-red-700 via-red-500 to-amber-400 transition-all duration-150",
								style: { width: `${hud.bossHp / hud.bossMaxHp * 100}%` }
							})
						})]
					}) : hud.activeTutorialHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 max-w-xs sm:max-w-md bg-[#090c14]/88 backdrop-blur-md border border-emerald-400/35 rounded-xl px-3.5 py-2 shadow-lg shadow-black/65",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-display font-bold uppercase tracking-wider text-emerald-300",
							children: hud.activeTutorialHint.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-slate-200 leading-snug mt-0.5",
							children: hud.activeTutorialHint.message
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 pointer-events-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 bg-[#090c14]/80 backdrop-blur-md border border-amber-500/25 rounded-xl px-3.5 py-2 text-xs font-mono-tabular text-slate-100 shadow-lg shadow-black/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5 text-amber-300 font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										viewBox: "0 0 20 20",
										className: "w-3.5 h-3.5",
										fill: "currentColor",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "10",
											cy: "10",
											r: "8"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
											points: "10,5 13.5,10 10,15 6.5,10",
											fill: "#78350f"
										})]
									}), hud.runCoins]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5 text-sky-300 font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 20 20",
										className: "w-3.5 h-3.5",
										fill: "currentColor",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "10,1 17,10 10,19 3,10" })
									}), hud.runCrystals]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-slate-300 hidden sm:inline",
									children: [hud.elapsedSec.toFixed(1), "s"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white font-bold pl-1 border-l border-white/15",
									children: hud.score
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundEngine.playSfx("uiClick");
								onPauseToggle();
							},
							className: "w-11 h-11 rounded-xl bg-[#090c14]/85 hover:bg-slate-800 border border-amber-500/30 flex items-center justify-center text-amber-100 transition-colors cursor-pointer shadow-lg shadow-black/60",
							"aria-label": "Pause Game",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "w-5 h-5" })
						})]
					})
				]
			}),
			showControls && !paused && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute bottom-4 left-4 flex items-center gap-3 z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onPointerDown: handleTouchDown("left"),
					onPointerUp: handleTouchUp("left"),
					onPointerCancel: handleTouchUp("left"),
					className: `w-16 h-16 rounded-2xl border-2 flex items-center justify-center transition-transform touch-none shadow-xl shadow-black/60 ${pressedBtns.left ? "bg-red-700/60 border-amber-300 scale-95 text-white" : "bg-[#090d16]/70 border-amber-500/30 text-amber-100"}`,
					"aria-label": "Move Left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 24 24",
						className: "w-7 h-7",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2.4",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M15 5l-7 7 7 7" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onPointerDown: handleTouchDown("right"),
					onPointerUp: handleTouchUp("right"),
					onPointerCancel: handleTouchUp("right"),
					className: `w-16 h-16 rounded-2xl border-2 flex items-center justify-center transition-transform touch-none shadow-xl shadow-black/60 ${pressedBtns.right ? "bg-red-700/60 border-amber-300 scale-95 text-white" : "bg-[#090d16]/70 border-amber-500/30 text-amber-100"}`,
					"aria-label": "Move Right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 24 24",
						className: "w-7 h-7",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2.4",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 5l7 7-7 7" })
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute bottom-4 right-4 flex flex-col items-end gap-2.5 z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 pr-1",
					children: [hud.unlockedArrows.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onPointerDown: handleTouchDown("cycleArrow"),
						onPointerUp: handleTouchUp("cycleArrow"),
						onPointerCancel: handleTouchUp("cycleArrow"),
						className: "h-10 px-3 rounded-full border border-white/20 bg-[#090d16]/80 text-xs font-semibold text-slate-100 flex items-center gap-1.5 touch-none shadow-lg shadow-black/60 active:scale-95",
						"aria-label": "Switch Arrow Type",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "w-3.5 h-3.5 text-slate-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-2.5 h-2.5 rounded-full",
								style: {
									backgroundColor: currentArrowDef.color,
									boxShadow: `0 0 6px ${currentArrowDef.glowColor}`
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentArrowDef.shortName })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onPointerDown: handleBowDown,
						onPointerMove: handleBowMove,
						onPointerUp: handleBowUp,
						onPointerCancel: handleBowUp,
						className: `relative w-16 h-16 rounded-full border-2 flex items-center justify-center touch-none shadow-xl shadow-black/65 transition-colors ${!hasEnoughEnergy ? "bg-[#090d16]/70 border-slate-600/50 text-slate-500" : pressedBtns.bow ? "bg-purple-600/45 border-amber-200 text-white" : "bg-[#090d16]/78 border-purple-400/70 text-purple-200"}`,
						style: { boxShadow: pressedBtns.bow ? `0 0 22px ${currentArrowDef.glowColor}` : void 0 },
						"aria-label": "Hold and Drag to Aim Bow, Release to Fire",
						children: [hud.bowCharging && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 rounded-full border-2 border-amber-300 pointer-events-none",
							style: {
								opacity: .4 + hud.bowChargeRatio * .6,
								transform: `scale(${1 + hud.bowChargeRatio * .14})`
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col items-center justify-center pointer-events-none",
							style: { transform: `translate(${bowDragOffset.x * .55}px, ${bowDragOffset.y * .55}px)` },
							children: pressedBtns.bow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "w-6 h-6 text-amber-200" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 24 24",
								className: "w-7 h-7",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 4c-5 2-8 5-8 8s3 6 8 8" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
										x1: "16",
										y1: "4",
										x2: "16",
										y2: "20",
										strokeOpacity: "0.65"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
										x1: "6",
										y1: "12",
										x2: "21",
										y2: "12"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "18 9 21 12 18 15" })
								]
							})
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end gap-2.5",
					children: [
						timeFocusUnlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onPointerDown: handleTouchDown("timeFocus"),
							onPointerUp: handleTouchUp("timeFocus"),
							onPointerCancel: handleTouchUp("timeFocus"),
							className: `relative w-12 h-12 rounded-full border-2 flex items-center justify-center transition-transform touch-none overflow-hidden shadow-lg shadow-black/60 ${hud.timeFocusCooldownRatio > 0 ? "bg-[#090d16]/70 border-white/15 text-slate-500" : pressedBtns.timeFocus ? "bg-sky-500/55 border-sky-300 scale-95 text-white" : "bg-[#090d16]/75 border-sky-400/55 text-sky-300"}`,
							"aria-label": "Time Focus",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-5 h-5 z-10" }), hud.timeFocusCooldownRatio > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-x-0 bottom-0 bg-sky-400/20",
								style: { height: `${(1 - hud.timeFocusCooldownRatio) * 100}%` }
							})]
						}),
						pulseUnlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onPointerDown: handleTouchDown("pulse"),
							onPointerUp: handleTouchUp("pulse"),
							onPointerCancel: handleTouchUp("pulse"),
							className: `relative w-13 h-13 rounded-full border-2 flex items-center justify-center transition-transform touch-none overflow-hidden shadow-lg shadow-black/60 ${hud.pulseCooldownRatio > 0 ? "bg-[#090d16]/70 border-white/15 text-slate-500" : pressedBtns.pulse ? "bg-purple-500/55 border-purple-300 scale-95 text-white" : "bg-[#090d16]/75 border-purple-400/55 text-purple-300"}`,
							"aria-label": "Shadow Pulse",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5 z-10" }), hud.pulseCooldownRatio > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-x-0 bottom-0 bg-purple-400/20",
								style: { height: `${(1 - hud.pulseCooldownRatio) * 100}%` }
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onPointerDown: handleTouchDown("attack"),
							onPointerUp: handleTouchUp("attack"),
							onPointerCancel: handleTouchUp("attack"),
							className: `relative w-15 h-15 rounded-full border-2 flex items-center justify-center transition-transform touch-none shadow-xl shadow-black/65 ${pressedBtns.attack ? "bg-emerald-500/60 border-emerald-200 scale-95 text-white" : "bg-[#090d16]/75 border-emerald-400/65 text-emerald-300"}`,
							"aria-label": "Shadow Blade Slash",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 24 24",
								className: "w-7 h-7 z-10",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.1",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.5 4.5l-9.5 9.5" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8.5 11.5l4 4" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.5 17.5l3-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4.5 19.5l2-2" })
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onPointerDown: handleTouchDown("dash"),
							onPointerUp: handleTouchUp("dash"),
							onPointerCancel: handleTouchUp("dash"),
							className: `relative w-14 h-14 rounded-full border-2 flex items-center justify-center transition-transform touch-none overflow-hidden shadow-xl shadow-black/65 ${hud.dashCooldownRatio > 0 ? "bg-[#090d16]/70 border-white/15 text-slate-500" : pressedBtns.dash ? "bg-amber-500/55 border-amber-200 scale-95 text-white" : "bg-[#090d16]/75 border-amber-400/60 text-amber-300"}`,
							"aria-label": "Shadow Dash",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 24 24",
								className: "w-6 h-6 z-10",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.2",
								strokeLinecap: "round",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 9h10a3 3 0 1 0-3-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 14h14a3 3 0 1 1-3 3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 19h5" })
								]
							}), hud.dashCooldownRatio > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-x-0 bottom-0 bg-amber-400/25",
								style: { height: `${(1 - hud.dashCooldownRatio) * 100}%` }
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onPointerDown: handleTouchDown("jump"),
							onPointerUp: handleTouchUp("jump"),
							onPointerCancel: handleTouchUp("jump"),
							className: `w-18 h-18 rounded-full border-2 flex items-center justify-center transition-transform touch-none shadow-xl shadow-black/65 ${pressedBtns.jump ? "bg-red-600/65 border-amber-200 scale-95 text-white" : "bg-[#090d16]/75 border-red-500/70 text-white"}`,
							"aria-label": "Jump and Double Jump",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 24 24",
								className: "w-8 h-8",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.5",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 19V5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 11l6-6 6 6" })]
							})
						})
					]
				})]
			})] })
		]
	});
};
// src/game/achievements.ts
var ACHIEVEMENTS = [
	{
		id: "first_blood",
		title: "First Shadow Strike",
		description: "Disperse your first shadow creature in combat.",
		rewardCoins: 75,
		rewardCrystals: 1,
		progressText: (s) => `${Math.min(1, s.stats.totalEnemiesDispersed)}/1`,
		isEarned: (s) => s.stats.totalEnemiesDispersed >= 1
	},
	{
		id: "cursed_walker",
		title: "Survivor of the Mist",
		description: "Complete the opening stage of Cursed Forest.",
		rewardCoins: 100,
		rewardCrystals: 1,
		progressText: (s) => s.levelProgress[1]?.completed ? "1/1" : "0/1",
		isEarned: (s) => Boolean(s.levelProgress[1]?.completed)
	},
	{
		id: "shadow_slayer",
		title: "Phantom Vanquisher",
		description: "Disperse 40 shadow creatures across your journey.",
		rewardCoins: 220,
		rewardCrystals: 4,
		progressText: (s) => `${Math.min(40, s.stats.totalEnemiesDispersed)}/40`,
		isEarned: (s) => s.stats.totalEnemiesDispersed >= 40
	},
	{
		id: "dash_adept",
		title: "Phantom Step",
		description: "Perform 50 Shadow Dashes.",
		rewardCoins: 120,
		rewardCrystals: 2,
		progressText: (s) => `${Math.min(50, s.stats.totalDashes)}/50`,
		isEarned: (s) => s.stats.totalDashes >= 50
	},
	{
		id: "flawless_star",
		title: "Master of Shadows",
		description: "Earn a 3-star rating on any level.",
		rewardCoins: 150,
		rewardCrystals: 2,
		progressText: (s) => Object.values(s.levelProgress).some((l) => l.stars >= 3) ? "1/1" : "0/1",
		isEarned: (s) => Object.values(s.levelProgress).some((l) => l.stars >= 3)
	},
	{
		id: "secret_seeker",
		title: "Hidden Path Finder",
		description: "Uncover 5 hidden secret relics.",
		rewardCoins: 200,
		rewardCrystals: 4,
		progressText: (s) => `${Math.min(5, s.stats.secretsFound)}/5`,
		isEarned: (s) => s.stats.secretsFound >= 5
	},
	{
		id: "forest_savior",
		title: "Bramble Bane",
		description: "Defeat Bramble Wraith and clear Cursed Forest.",
		rewardCoins: 300,
		rewardCrystals: 5,
		progressText: (s) => s.levelProgress[15]?.completed ? "1/1" : "0/1",
		isEarned: (s) => Boolean(s.levelProgress[15]?.completed)
	},
	{
		id: "temple_conqueror",
		title: "Monolith Breaker",
		description: "Defeat Obsidian Sentinel and clear Ancient Temple.",
		rewardCoins: 400,
		rewardCrystals: 6,
		progressText: (s) => s.levelProgress[30]?.completed ? "1/1" : "0/1",
		isEarned: (s) => Boolean(s.levelProgress[30]?.completed)
	},
	{
		id: "frost_breaker",
		title: "Glacial Sovereign",
		description: "Defeat Glacial Wyrm and clear Frozen Kingdom.",
		rewardCoins: 500,
		rewardCrystals: 8,
		progressText: (s) => s.levelProgress[45]?.completed ? "1/1" : "0/1",
		isEarned: (s) => Boolean(s.levelProgress[45]?.completed)
	},
	{
		id: "eclipse_lord",
		title: "Eclipse Vanquisher",
		description: "Defeat Lord of the Eclipse and complete all 4 worlds.",
		rewardCoins: 900,
		rewardCrystals: 15,
		progressText: (s) => s.levelProgress[60]?.completed ? "1/1" : "0/1",
		isEarned: (s) => Boolean(s.levelProgress[60]?.completed)
	},
	{
		id: "wardrobe_collector",
		title: "Cloaks of Legend",
		description: "Unlock 3 Shadow Costumes.",
		rewardCoins: 240,
		rewardCrystals: 4,
		progressText: (s) => `${Math.min(3, s.unlockedCostumes.length)}/3`,
		isEarned: (s) => s.unlockedCostumes.length >= 3
	},
	{
		id: "max_discipline",
		title: "Arcane Grandmaster",
		description: "Upgrade any ninja ability to maximum level (Lv 5).",
		rewardCoins: 350,
		rewardCrystals: 6,
		progressText: (s) => `${Math.min(5, Math.max(...Object.values(s.upgrades)))}/5`,
		isEarned: (s) => Object.values(s.upgrades).some((lvl) => lvl >= 5)
	},
	{
		id: "sharpshooter_1",
		title: "Shadow Marksman",
		description: "Loose 25 magical arrows from your ninja bow.",
		rewardCoins: 140,
		rewardCrystals: 2,
		progressText: (s) => `${Math.min(25, s.stats.totalArrowsFired ?? 0)}/25`,
		isEarned: (s) => (s.stats.totalArrowsFired ?? 0) >= 25
	},
	{
		id: "elemental_quiver",
		title: "Spirit Quiver Adept",
		description: "Unlock 3 different magical arrow types in Upgrades.",
		rewardCoins: 260,
		rewardCrystals: 4,
		progressText: (s) => `${Math.min(3, s.unlockedArrows?.length ?? 1)}/3`,
		isEarned: (s) => (s.unlockedArrows?.length ?? 1) >= 3
	}
];
function evaluateNewAchievements(save) {
	const existing = new Set(save.unlockedAchievements ?? []);
	const newlyUnlocked = [];
	let bonusCoins = 0;
	let bonusCrystals = 0;
	for (const ach of ACHIEVEMENTS) if (!existing.has(ach.id) && ach.isEarned(save)) {
		existing.add(ach.id);
		newlyUnlocked.push(ach);
		bonusCoins += ach.rewardCoins;
		bonusCrystals += ach.rewardCrystals;
	}
	if (newlyUnlocked.length === 0) return {
		updated: save,
		newlyUnlocked: []
	};
	return {
		updated: {
			...save,
			unlockedAchievements: Array.from(existing),
			coins: save.coins + bonusCoins,
			crystals: save.crystals + bonusCrystals
		},
		newlyUnlocked
	};
}
// src/components/MenuScreens.tsx
var MenuHeader = ({ title, save, onBack, rightAction }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
	className: "w-full px-5 py-3 border-b border-white/10 bg-[#080a11]/90 backdrop-blur-md flex items-center justify-between gap-4 shrink-0",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 min-w-0",
		children: [onBack && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => {
				soundEngine.playSfx("uiClick");
				onBack();
			},
			className: "w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-200 transition-colors shrink-0 cursor-pointer",
			"aria-label": "Go Back",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-5 h-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-lg sm:text-xl font-bold tracking-wide text-slate-100 truncate",
			children: title
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-4 shrink-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 text-sm font-mono-tabular",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1.5 text-amber-300 font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-4 h-4" }), save.coins]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-slate-600",
					children: "/"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1.5 text-sky-300 font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-4 h-4" }), save.crystals]
				})
			]
		}), rightAction]
	})]
});
var SplashScreen = ({ onContinue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "relative w-full h-full bg-[#05060a] flex items-center justify-center overflow-hidden",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: WORLD_IMAGES.hero,
			alt: "Shadow Ninja perched beneath a silver full moon",
			referrerPolicy: "no-referrer",
			className: "absolute inset-0 w-full h-full object-cover opacity-55"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-[#05060a] via-[#05060a]/55 to-transparent" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 max-w-xl text-center px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tracking-[0.28em] uppercase text-red-400 font-semibold mb-3",
					children: [APP_IDENTITY.developer, " Presents"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl sm:text-5xl font-extrabold text-white tracking-wider mb-3",
					children: "Shadow Ninja"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg sm:text-xl text-slate-300 tracking-[0.2em] uppercase mb-8",
					children: "Dark Quest"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						soundEngine.unlock();
						soundEngine.playSfx("uiClick");
						onContinue();
					},
					className: "px-8 py-3.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold tracking-wide text-sm transition-colors shadow-lg shadow-red-950/50 cursor-pointer",
					children: "Enter the Shadows"
				})
			]
		})
	]
});
var MainMenuScreen = ({ save, onNavigate, onPlayContinue, onWatchBonusCoins }) => {
	const completedCount = Object.values(save.levelProgress).filter((p) => p.completed).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex-1 w-full overflow-hidden bg-[#07080d] flex flex-col justify-between",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: WORLD_IMAGES.hero,
				alt: "Shadow Ninja – Dark Quest Key Art",
				referrerPolicy: "no-referrer",
				className: "absolute inset-0 w-full h-full object-cover opacity-45"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-[#06070c] via-[#06070c]/80 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 px-6 pt-4 flex items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl sm:text-3xl font-bold text-white tracking-wide",
					children: "Shadow Ninja – Dark Quest"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-slate-400 mt-0.5 flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["By ", APP_IDENTITY.developer] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono-tabular",
							children: [completedCount, "/60 Levels Cleared"]
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 bg-black/60 border border-white/10 rounded-lg px-3.5 py-2 text-sm font-mono-tabular",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-amber-300 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-4 h-4" }), save.coins]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-slate-600",
								children: "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-sky-300 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-4 h-4" }), save.crystals]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundEngine.playSfx("uiClick");
							onNavigate("PROFILE");
						},
						className: "h-10 px-3.5 rounded-lg bg-black/60 hover:bg-slate-800 border border-white/15 text-xs font-medium text-slate-200 flex items-center gap-2 cursor-pointer whitespace-nowrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-4 h-4" }), "Profile"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 px-6 pb-5 pt-2 flex flex-col sm:flex-row items-end sm:items-center justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md flex flex-col gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundEngine.unlock();
								soundEngine.playSfx("uiClick");
								onPlayContinue();
							},
							className: "w-full py-3.5 px-5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-base flex items-center justify-between transition-colors shadow-lg shadow-red-950/50 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-5 h-5 fill-white" }),
									"Play · Level ",
									save.unlockedLevelMax
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-normal text-red-100",
								children: "Continue Quest"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onNavigate("WORLDS");
									},
									className: "py-2.5 px-4 rounded-lg bg-[#0d1019]/90 hover:bg-slate-800 border border-white/15 text-slate-100 text-sm font-medium flex items-center gap-2.5 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-emerald-400" }), "Worlds"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onNavigate("UPGRADES");
									},
									className: "py-2.5 px-4 rounded-lg bg-[#0d1019]/90 hover:bg-slate-800 border border-white/15 text-slate-100 text-sm font-medium flex items-center gap-2.5 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-4 h-4 text-amber-400" }), "Upgrades"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onNavigate("COSTUMES");
									},
									className: "py-2.5 px-4 rounded-lg bg-[#0d1019]/90 hover:bg-slate-800 border border-white/15 text-slate-100 text-sm font-medium flex items-center gap-2.5 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shirt, { className: "w-4 h-4 text-sky-400" }), "Costumes"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onNavigate("SETTINGS");
									},
									className: "py-2.5 px-4 rounded-lg bg-[#0d1019]/90 hover:bg-slate-800 border border-white/15 text-slate-100 text-sm font-medium flex items-center gap-2.5 transition-colors cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "w-4 h-4 text-slate-300" }), "Settings"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onNavigate("ACHIEVEMENTS");
									},
									className: "py-2.5 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-amber-300 shrink-0" }), "Achievements"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onNavigate("HOW_TO_PLAY");
									},
									className: "py-2.5 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "w-4 h-4 shrink-0" }), "How to Play"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundEngine.playSfx("uiClick");
										onWatchBonusCoins();
									},
									className: "py-2.5 px-3 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-4 h-4 text-amber-400 shrink-0" }), "+100 Coins"]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block w-[360px] shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeAdCard, {})
				})]
			})
		]
	});
};
var WorldSelectionScreen = ({ save, onSelectWorld, onBack }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
			title: "World Selection",
			save,
			onBack
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 overflow-y-auto dark-scroll p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto",
				children: WORLDS.map((world) => {
					const unlocked = save.unlockedWorlds.includes(world.id);
					const cleared = getLevelsForWorld(world.id).filter((l) => save.levelProgress[l.id]?.completed).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: !unlocked,
						onClick: () => {
							soundEngine.playSfx("uiClick");
							onSelectWorld(world.id);
						},
						className: `group relative rounded-xl overflow-hidden border text-left flex flex-col justify-end min-h-[250px] transition-transform ${unlocked ? "border-white/15 hover:border-red-500/60 hover:-translate-y-0.5 cursor-pointer" : "border-white/5 opacity-60 cursor-not-allowed"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: world.image,
								alt: world.name,
								referrerPolicy: "no-referrer",
								className: "absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-black via-black/65 to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] font-medium text-slate-300 mb-1 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: world.subtitle }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono-tabular",
											children: [cleared, "/15"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "font-display text-lg font-bold text-white flex items-center gap-2",
										children: [world.name, !unlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-4 h-4 text-slate-400" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-300 mt-1.5 line-clamp-2",
										children: world.description
									})
								]
							})
						]
					}, world.id);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0 px-5 pb-2 max-w-6xl w-full mx-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeAdCard, {})
		})
	]
});
var LevelSelectionScreen = ({ worldId, save, runBuffs, onArmBuff, onStartLevel, onBack }) => {
	const world = WORLD_MAP[worldId];
	const levels = getLevelsForWorld(worldId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
			title: `${world.name} · Levels`,
			save,
			onBack,
			rightAction: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1.5 flex-wrap justify-end",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							soundEngine.playSfx("uiClick");
							onArmBuff("extraLife");
						},
						disabled: Boolean(runBuffs.extraLife),
						className: `px-2.5 py-1.5 rounded-lg text-[11px] font-medium border flex items-center gap-1 cursor-pointer whitespace-nowrap ${runBuffs.extraLife ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300" : "bg-red-500/15 hover:bg-red-500/25 border-red-500/35 text-red-200"}`,
						children: runBuffs.extraLife ? "4 HP Ready" : "+1 Heart (Ad)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							soundEngine.playSfx("uiClick");
							onArmBuff("arrowEnergy");
						},
						disabled: Boolean(runBuffs.arrowEnergyBoost),
						className: `px-2.5 py-1.5 rounded-lg text-[11px] font-medium border flex items-center gap-1 cursor-pointer whitespace-nowrap ${runBuffs.arrowEnergyBoost ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300" : "bg-purple-500/15 hover:bg-purple-500/25 border-purple-500/35 text-purple-200"}`,
						children: runBuffs.arrowEnergyBoost ? "Quiver Boosted" : "+Arrow Energy (Ad)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundEngine.playSfx("uiClick");
							onArmBuff("shadowShield");
						},
						disabled: Boolean(runBuffs.shadowShieldBoost),
						className: `px-2.5 py-1.5 rounded-lg text-[11px] font-medium border flex items-center gap-1 cursor-pointer whitespace-nowrap ${runBuffs.shadowShieldBoost ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300" : "bg-sky-500/15 hover:bg-sky-500/25 border-sky-500/35 text-sky-200"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-3 h-3" }), runBuffs.shadowShieldBoost ? "Shield Ready" : "+Shield (Ad)"]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 overflow-y-auto dark-scroll p-5 space-y-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 sm:grid-cols-5 gap-3 max-w-5xl mx-auto",
				children: levels.map((lvl) => {
					const unlocked = lvl.id <= save.unlockedLevelMax;
					const prog = save.levelProgress[lvl.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: !unlocked,
						onClick: () => {
							soundEngine.unlock();
							soundEngine.playSfx("uiClick");
							onStartLevel(lvl.id);
						},
						className: `p-3 rounded-xl border text-left transition-colors flex flex-col justify-between min-h-[96px] ${unlocked ? lvl.isBoss ? "bg-red-950/35 hover:bg-red-900/40 border-red-500/45 cursor-pointer" : lvl.isMiniboss ? "bg-amber-950/25 hover:bg-amber-900/30 border-amber-500/40 cursor-pointer" : "bg-[#0e111b] hover:bg-slate-800/80 border-white/15 cursor-pointer" : "bg-[#090b12] border-white/5 opacity-50 cursor-not-allowed"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between w-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular text-sm font-bold text-white",
									children: lvl.indexInWorld.toString().padStart(2, "0")
								}), !unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5 text-slate-500" }) : lvl.isBoss ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-wider font-bold text-red-300",
									children: "Boss"
								}) : lvl.isMiniboss ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] uppercase tracking-wider font-bold text-amber-300",
									children: "Miniboss"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-medium text-slate-200 truncate mt-1",
								children: lvl.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-slate-400 truncate mb-1",
								children: lvl.difficultyLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[11px] text-slate-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-0.5",
									children: [
										1,
										2,
										3
									].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-3 h-3 ${prog && prog.stars >= s ? "text-amber-400 fill-amber-400" : "text-slate-700"}` }, s))
								}), prog?.bestScore ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular",
									children: prog.bestScore
								}) : null]
							})
						]
					}, lvl.id);
				})
			})
		})]
	});
};
var UpgradesScreen = ({ save, onUpgrade, onSelectOrUnlockArrow, onBack }) => {
	const unlockedArrows = save.unlockedArrows ?? ["shadow"];
	const selectedArrow = save.selectedArrow ?? "shadow";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
				title: "Weapons, Quiver & Shadow Arts",
				save,
				onBack
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 overflow-y-auto dark-scroll p-5 space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-6xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-sm uppercase tracking-wider font-bold text-slate-300",
							children: "Martial & Shadow Mastery"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-slate-500",
							children: "Upgrade blade, bow, agility & arcane skills"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
						children: ABILITY_UPGRADES.map((ab) => {
							const lvl = save.upgrades[ab.id] ?? 0;
							const isMax = lvl >= ab.maxLevel;
							const cost = getUpgradeCost(ab, lvl);
							const canAfford = !isMax && save.coins >= cost.coins && save.crystals >= cost.crystals;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#0e111a] border border-white/10 rounded-xl p-4 flex flex-col justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2 mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-base font-bold text-white",
											children: ab.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-mono-tabular text-slate-400",
											children: [
												"Lv ",
												lvl,
												"/",
												ab.maxLevel
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-slate-400 mb-2",
										children: ab.keyHint
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-300 leading-relaxed mb-3",
										children: ab.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-sky-300 font-medium bg-sky-500/10 border border-sky-500/20 rounded-lg px-2.5 py-1.5",
										children: ab.effectSummary(lvl)
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-1.5",
										children: Array.from({ length: ab.maxLevel }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1.5 flex-1 rounded-full ${i < lvl ? "bg-amber-400" : "bg-slate-800"}` }, i))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										disabled: isMax || !canAfford,
										onClick: () => {
											soundEngine.playSfx("crystal");
											onUpgrade(ab.id);
										},
										className: `w-full py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${isMax ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 cursor-default" : canAfford ? "bg-red-600 hover:bg-red-500 text-white cursor-pointer" : "bg-slate-800/80 text-slate-500 border border-white/5 cursor-not-allowed"}`,
										children: isMax ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), " Mastered"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lvl === 0 ? "Unlock" : "Upgrade" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1 font-mono-tabular",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-3.5 h-3.5 text-amber-300" }), cost.coins]
											}),
											cost.crystals > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1 font-mono-tabular",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-3.5 h-3.5 text-sky-300" }), cost.crystals]
											})
										] })
									})]
								})]
							}, ab.id);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-6xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-sm uppercase tracking-wider font-bold text-slate-300",
							children: "Magical Arrow Quiver"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-slate-500",
							children: "Equip default arrow or swap in combat"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5",
						children: ARROW_TYPES.map((arrow) => {
							const unlocked = unlockedArrows.includes(arrow.id);
							const equipped = selectedArrow === arrow.id;
							const canAfford = save.coins >= arrow.coinCost && save.crystals >= arrow.crystalCost;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-xl p-4 border flex flex-col justify-between gap-3.5 ${equipped ? "bg-[#121624] border-purple-400/65" : "bg-[#0e111a] border-white/10"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2 mb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-3.5 h-3.5 rounded-full shrink-0",
											style: {
												backgroundColor: arrow.color,
												boxShadow: `0 0 10px ${arrow.glowColor}`
											}
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono-tabular text-slate-400",
											children: ["Energy ", arrow.energyCost]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-sm font-bold text-white",
										children: arrow.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-400 mt-1.5 leading-relaxed",
										children: arrow.description
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !unlocked && !canAfford,
									onClick: () => {
										soundEngine.playSfx(unlocked ? "uiClick" : "treasure");
										onSelectOrUnlockArrow(arrow.id);
									},
									className: `w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${equipped ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default" : unlocked ? "bg-white/10 hover:bg-white/15 text-white cursor-pointer" : canAfford ? "bg-red-600 hover:bg-red-500 text-white cursor-pointer" : "bg-slate-800/80 text-slate-500 cursor-not-allowed"}`,
									children: equipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), " Equipped"] }) : unlocked ? "Equip Arrow" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unlock" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono-tabular flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-3 h-3 text-amber-300" }), arrow.coinCost]
										}),
										arrow.crystalCost > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono-tabular flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-3 h-3 text-sky-300" }), arrow.crystalCost]
										})
									] })
								})]
							}, arrow.id);
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 px-5 pb-2 max-w-6xl w-full mx-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeAdCard, {})
			})
		]
	});
};
var CostumesScreen = ({ save, onSelectOrUnlock, onBack }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
			title: "Shadow Costumes",
			save,
			onBack
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 overflow-y-auto dark-scroll p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 max-w-6xl mx-auto",
				children: COSTUMES.map((c) => {
					const unlocked = save.unlockedCostumes.includes(c.id);
					const equipped = save.selectedCostume === c.id;
					const canAfford = save.coins >= c.coinCost && save.crystals >= c.crystalCost;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-xl p-4 border flex flex-col justify-between gap-4 ${equipped ? "bg-[#121624] border-red-500/60" : "bg-[#0e111a] border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full h-28 rounded-lg bg-[#06070c] border border-white/5 flex items-center justify-center mb-3 relative overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-16 h-16 rounded-full blur-xl opacity-55 absolute",
									style: { backgroundColor: c.scarfColor }
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 80 80",
									className: "w-20 h-20 relative z-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M42 26 Q22 24 10 34 Q22 31 38 33 Z",
											fill: c.scarfColor
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "42",
											cy: "24",
											r: "9",
											fill: c.bodyColor,
											stroke: "rgba(255,255,255,0.18)",
											strokeWidth: "1"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
											x: "43",
											y: "21",
											width: "5",
											height: "2.5",
											fill: c.eyeColor
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M35 33 L49 33 L47 53 L37 53 Z",
											fill: c.bodyColor,
											stroke: "rgba(255,255,255,0.12)",
											strokeWidth: "1"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "39",
											y1: "53",
											x2: "35",
											y2: "69",
											stroke: c.bodyColor,
											strokeWidth: "5",
											strokeLinecap: "round"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
											x1: "45",
											y1: "53",
											x2: "50",
											y2: "69",
											stroke: c.bodyColor,
											strokeWidth: "5",
											strokeLinecap: "round"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-sm font-bold text-white",
								children: c.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-400 mt-1 leading-relaxed",
								children: c.description
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: !unlocked && !canAfford,
							onClick: () => {
								soundEngine.playSfx(unlocked ? "uiClick" : "treasure");
								onSelectOrUnlock(c.id);
							},
							className: `w-full py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${equipped ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default" : unlocked ? "bg-white/10 hover:bg-white/15 text-white cursor-pointer" : canAfford ? "bg-red-600 hover:bg-red-500 text-white cursor-pointer" : "bg-slate-800/80 text-slate-500 cursor-not-allowed"}`,
							children: equipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), " Equipped"] }) : unlocked ? "Equip" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unlock" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono-tabular flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-3 h-3 text-amber-300" }), c.coinCost]
								}),
								c.crystalCost > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono-tabular flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-3 h-3 text-sky-300" }), c.crystalCost]
								})
							] })
						})]
					}, c.id);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0 px-5 pb-2 max-w-6xl w-full mx-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeAdCard, {})
		})
	]
});
var SettingsScreen = ({ save, onUpdateSettings, onResetProgress, onOpenPrivacy, onBack }) => {
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
			title: "Settings & Android Export",
			save,
			onBack
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 overflow-y-auto dark-scroll p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-3xl mx-auto space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#0e111a] border border-white/10 rounded-xl p-5 space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-base font-bold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4 text-amber-400" }), " Audio Controls"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center justify-between gap-4 text-sm text-slate-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Music Volume" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 w-56",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 0,
										max: 1,
										step: .05,
										value: save.settings.musicVolume,
										onChange: (e) => onUpdateSettings({ musicVolume: parseFloat(e.target.value) }),
										className: "w-full accent-red-500"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono-tabular text-xs w-10 text-right",
										children: [Math.round(save.settings.musicVolume * 100), "%"]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center justify-between gap-4 text-sm text-slate-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sound Effects Volume" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 w-56",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 0,
										max: 1,
										step: .05,
										value: save.settings.sfxVolume,
										onChange: (e) => onUpdateSettings({ sfxVolume: parseFloat(e.target.value) }),
										className: "w-full accent-red-500"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono-tabular text-xs w-10 text-right",
										children: [Math.round(save.settings.sfxVolume * 100), "%"]
									})]
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#0e111a] border border-white/10 rounded-xl p-5 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-base font-bold text-white",
								children: "Controls & Visual Quality"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center justify-between text-sm text-slate-300 py-1 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Show Android Touch Controls" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: save.settings.showTouchControls,
									onChange: (e) => onUpdateSettings({ showTouchControls: e.target.checked }),
									className: "w-4 h-4 accent-red-500"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center justify-between text-sm text-slate-300 py-1 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Atmospheric Particles & Mist Effects" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: save.settings.particlesEnabled,
									onChange: (e) => onUpdateSettings({ particlesEnabled: e.target.checked }),
									className: "w-4 h-4 accent-red-500"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#0e111a] border border-white/10 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-base font-bold text-white",
							children: "Android Studio / AndroidForge Project"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-slate-400 mt-1",
							children: [
								"Package: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular text-slate-300",
									children: APP_IDENTITY.packageName
								}),
								" · Includes Gradle, Kotlin AdMobManager, UMP Consent & full game assets."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/api/export-android-zip",
								download: "ShadowNinja-DarkQuest-Android.zip",
								className: "px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-4 h-4" }), "Download Android ZIP"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: onOpenPrivacy,
								className: "px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-4 h-4" }), "Privacy & Ads"]
							})]
						})]
					}),
					adMobBridge.isDebugInspectorAvailable() && (() => {
						const st = adMobBridge.getDebugStatus();
						if (!st) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#0e111a] border border-amber-500/35 rounded-xl p-5 space-y-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-sm font-bold text-amber-300",
										children: "AdMob SDK Status Report (Debug Only)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-mono-tabular text-slate-400",
										children: st.mode
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono-tabular",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-black/40 rounded p-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: "SDK Initialized"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-slate-100",
												children: String(st.sdkInitialized)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-black/40 rounded p-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: "Consent Status"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-slate-100",
												children: st.consentStatus
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-black/40 rounded p-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: "App Open"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-slate-100",
												children: st.appOpenState
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-black/40 rounded p-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: "Banner"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-slate-100",
												children: st.bannerState
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-black/40 rounded p-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: "Interstitial"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-slate-100",
												children: st.interstitialState
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-black/40 rounded p-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: "Native / Rewarded"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-slate-100",
												children: [
													st.nativeState,
													" / ",
													st.rewardedState
												]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-slate-400 truncate",
									children: ["Last Error: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-200",
										children: st.lastLoadError
									})]
								})
							]
						});
					})(),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#0e111a] border border-white/10 rounded-xl p-5 flex items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold text-white",
							children: "Reset Local Progress"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-slate-400",
							children: "Clear unlocked levels, coins, crystals, and upgrades."
						})] }), !confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setConfirmReset(true),
							className: "px-4 py-2 rounded-lg bg-red-950/60 hover:bg-red-900/60 border border-red-500/40 text-red-200 text-xs font-semibold flex items-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), "Reset Save"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setConfirmReset(false),
								className: "px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300 cursor-pointer",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									onResetProgress();
									setConfirmReset(false);
								},
								className: "px-3 py-1.5 rounded-lg bg-red-600 text-xs font-semibold text-white cursor-pointer",
								children: "Confirm Reset"
							})]
						})]
					})
				]
			})
		})]
	});
};
var ProfileScreen = ({ save, onBack }) => {
	const levelsCleared = Object.values(save.levelProgress).filter((l) => l.completed).length;
	const totalStars = Object.values(save.levelProgress).reduce((acc, l) => acc + l.stars, 0);
	const metrics = [
		{
			label: "Levels Cleared",
			value: `${levelsCleared} / 60`
		},
		{
			label: "Stars Earned",
			value: `${totalStars} / 180`
		},
		{
			label: "Bosses Defeated",
			value: `${save.stats.bossesDefeated} / 4`
		},
		{
			label: "Shadow Creatures Dispersed",
			value: String(save.stats.totalEnemiesDispersed)
		},
		{
			label: "Magical Arrows Fired",
			value: String(save.stats.totalArrowsFired ?? 0)
		},
		{
			label: "Total Shadow Dashes",
			value: String(save.stats.totalDashes)
		},
		{
			label: "Secrets Uncovered",
			value: String(save.stats.secretsFound)
		},
		{
			label: "Time Played",
			value: `${Math.round(save.stats.totalPlayTimeSec / 60)} min`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
				title: "Shadow Profile & Statistics",
				save,
				onBack
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto dark-scroll p-5 space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-5xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-3",
					children: metrics.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#0e111a] border border-white/10 rounded-xl p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-slate-400",
							children: m.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono-tabular text-xl font-bold text-white mt-1 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "w-4 h-4 text-amber-400" }), m.value]
						})]
					}, m.label))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 px-5 pb-2 max-w-5xl w-full mx-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeAdCard, {})
			})
		]
	});
};
var AchievementsScreen = ({ save, onBack }) => {
	const unlockedSet = new Set(save.unlockedAchievements ?? []);
	const unlockedCount = ACHIEVEMENTS.filter((a) => unlockedSet.has(a.id)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
				title: `Achievements · ${unlockedCount} / ${ACHIEVEMENTS.length}`,
				save,
				onBack
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto dark-scroll p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5",
					children: ACHIEVEMENTS.map((ach) => {
						const done = unlockedSet.has(ach.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-xl p-4 border flex flex-col justify-between gap-3 ${done ? "bg-[#121624] border-amber-500/45" : "bg-[#0e111a] border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2 mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: `w-4 h-4 shrink-0 ${done ? "text-amber-400" : "text-slate-500"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-sm font-bold text-white",
										children: ach.title
									})]
								}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-semibold text-emerald-300 flex items-center gap-1 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), " Unlocked"]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-mono-tabular text-slate-400 shrink-0",
									children: ach.progressText(save)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-300 leading-relaxed mt-1",
								children: ach.description
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[11px] pt-2 border-t border-white/5 text-slate-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reward" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 font-mono-tabular font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1 text-amber-300",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-3.5 h-3.5" }),
											"+",
											ach.rewardCoins
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1 text-sky-300",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-3.5 h-3.5" }),
											"+",
											ach.rewardCrystals
										]
									})]
								})]
							})]
						}, ach.id);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 px-5 pb-2 max-w-5xl w-full mx-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeAdCard, {})
			})
		]
	});
};
var HowToPlayScreen = ({ save, onBack }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
		title: "How to Play",
		save,
		onBack
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex-1 overflow-y-auto dark-scroll p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#0e111a] border border-white/10 rounded-xl p-5 space-y-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-base font-bold text-white flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-red-400" }), " Movement, Blade & Ninja Bow"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "text-xs text-slate-300 space-y-2 leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"• Move & Jump: On-screen pads or ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "A / D"
							}),
							" + ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "Space / W"
							}),
							" (Double Jump & Wall Jump)."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"• Shadow Blade Slash: Strike enemies and deflect orbs (",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "F / X / Sword"
							}),
							")."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"• Ninja Bow & Aiming: Hold & drag the ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "Bow"
							}),
							" pad (or drag with mouse / hold ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "G"
							}),
							") to charge and preview trajectory in 360°, then release to shoot!"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"• Magical Arrows: Switch between Shadow, Fire, Ice, Lightning, and Explosive arrows (",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "R / 1–5"
							}),
							" or Quiver tap)."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"• Dash Attack: Press Attack during a Shadow Dash (",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "Shift / K"
							}),
							") for 2× damage golden crescent cleave."
						] })
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#0e111a] border border-white/10 rounded-xl p-5 space-y-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-base font-bold text-white flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-sky-400" }), " Tactics, Traps & Bosses"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "text-xs text-slate-300 space-y-2 leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"• Shadow Pulse (",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "J / E"
							}),
							") & Time Focus (",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-white",
								children: "T / Q"
							}),
							"): Shockwaves and slow-motion mastery."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• Enemy Weaknesses: Fire & Explosive arrows pierce armored Guardians; Ice chills charging Brutes; Lightning chains across aerial Spirits and Mages." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• Traps & Bridges: Beware pressure-plate hidden floor spikes and collapsing bridges from Stage 2 onward." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• Multi-Phase Bosses: Stage 8 Minibosses & Stage 15 World Bosses escalate through 3 phases—mix katana cleaves and charged bow shots!" })
					]
				})]
			})]
		})
	})]
});
var PrivacyPolicyScreen = ({ save, onConsentAccept, onBack }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex-1 w-full bg-[#07080d] flex flex-col overflow-hidden",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuHeader, {
		title: "Privacy Policy & AdMob Disclosure",
		save,
		onBack
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex-1 overflow-y-auto dark-scroll p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-3xl mx-auto bg-[#0e111a] border border-white/10 rounded-xl p-5 space-y-3 text-xs text-slate-300 leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-white",
						children: APP_IDENTITY.title
					}),
					" (",
					APP_IDENTITY.packageName,
					") is developed by",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-white",
						children: APP_IDENTITY.developer
					}),
					" as an offline single-player platformer."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "text-white",
					children: "Local Save Data:"
				}), " Game progress, unlocked levels, coins, crystals, costumes, and settings are stored strictly locally on your device. No account registration or personal login is required."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "text-white",
					children: "Google AdMob & UMP Consent:"
				}), " On Android, the official Google Mobile Ads SDK and User Messaging Platform (UMP) handle advertising consent where required by regional regulations (EEA/UK/US). Rewarded ads are strictly optional and never forced."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-2 flex flex-wrap items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onConsentAccept,
						className: "px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer",
						children: save.settings.consentAccepted ? "Consent Preferences Saved" : "Acknowledge & Save Preferences"
					}), (adMobBridge.isPrivacyOptionsRequired() || adMobBridge.isNativeAndroid()) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => adMobBridge.openPrivacyConsent(),
						className: "px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/15 text-slate-200 font-semibold cursor-pointer",
						children: "Manage UMP Ad Privacy Choices"
					})]
				})
			]
		})
	})]
});
// src/components/OutcomeScreens.tsx
var PauseOverlay = ({ onResume, onRestart, onSettings, onExitToLevels }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "fixed inset-0 z-40 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-sm bg-[#0d1019] border border-white/15 rounded-xl p-6 space-y-3 shadow-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-bold text-white text-center mb-4",
				children: "Quest Paused"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					soundEngine.playSfx("uiClick");
					onResume();
				},
				className: "w-full py-3 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-4 h-4 fill-white" }), " Resume"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					soundEngine.playSfx("uiClick");
					onRestart();
				},
				className: "w-full py-2.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-100 text-sm font-medium flex items-center justify-center gap-2 cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" }), " Restart Level"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					soundEngine.playSfx("uiClick");
					onSettings();
				},
				className: "w-full py-2.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-100 text-sm font-medium flex items-center justify-center gap-2 cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "w-4 h-4" }), " Settings"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					soundEngine.playSfx("uiClick");
					onExitToLevels();
				},
				className: "w-full py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-white/10 text-slate-300 text-sm font-medium flex items-center justify-center gap-2 cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4" }), " Exit to Levels"]
			})
		]
	})
});
var LevelCompleteScreen = ({ summary, hasNextLevel, onDoubleRewardAd, onNextLevel, onReplay, onLevels }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "flex-1 w-full bg-[#07080d] flex items-center justify-center p-5 overflow-y-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-lg bg-[#0d101a] border border-white/15 rounded-2xl p-6 text-center space-y-5 shadow-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.22em] text-emerald-400 font-semibold",
				children: "Stage Cleared"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-2xl font-bold text-white mt-1",
				children: [
					"Level ",
					summary.levelId,
					" Complete"
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-center gap-3",
				children: [
					1,
					2,
					3
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-9 h-9 ${summary.stars >= s ? "text-amber-400 fill-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.45)]" : "text-slate-700"}` }, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2.5 bg-[#080a10] border border-white/10 rounded-xl p-3.5 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-slate-400",
						children: "Score"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono-tabular text-base font-bold text-white mt-0.5",
						children: summary.score
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-slate-400",
						children: "Time"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono-tabular text-base font-bold text-white mt-0.5",
						children: [summary.timeSec.toFixed(1), "s"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-slate-400",
						children: "Rewards"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono-tabular text-sm font-bold text-amber-300 mt-1 flex items-center justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-3.5 h-3.5" }),
								"+",
								summary.coinsEarned
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 text-sky-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-3.5 h-3.5" }),
								"+",
								summary.crystalsEarned
							]
						})]
					})] })
				]
			}),
			!summary.rewardBonusApplied && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onDoubleRewardAd,
				className: "w-full py-2.5 px-4 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-200 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "w-4 h-4 text-amber-400" }),
					"Watch Optional Ad for Bonus +",
					summary.coinsEarned,
					" Coins"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onLevels,
						className: "px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer",
						children: "Levels"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: onReplay,
						className: "px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), " Replay"]
					}),
					hasNextLevel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: onNextLevel,
						className: "flex-1 py-3 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer",
						children: ["Next Level ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })]
					})
				]
			})
		]
	})
});
var BossVictoryScreen = ({ summary, hasNextWorld, onContinue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "flex-1 w-full bg-[#07080d] flex items-center justify-center p-5 overflow-y-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-lg bg-[#110c14] border border-amber-500/40 rounded-2xl p-6 text-center space-y-5 shadow-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "w-12 h-12 text-amber-400 mx-auto" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.24em] text-amber-300 font-semibold",
				children: "World Guardian Vanquished"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-2xl font-bold text-white mt-1",
				children: [summary.bossName, " Defeated"]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-black/45 border border-white/10 rounded-xl p-4 space-y-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-5 font-mono-tabular font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-amber-300",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "w-4 h-4" }),
							" +",
							summary.coinsEarned,
							" Coins"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 text-sky-300",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "w-4 h-4" }),
							" +",
							summary.crystalsEarned,
							" Crystals"
						]
					})]
				}), summary.worldJustCleared && hasNextWorld && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-emerald-300 font-medium",
					children: "Next World Unlocked! World Completion Bonus Awarded."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onContinue,
				className: "w-full py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer",
				children: hasNextWorld ? "Proceed to Next World" : "Return to Hall of Victory"
			})
		]
	})
});
var GameOverScreen = ({ canRevive, revivesUsed, maxRevives, isRequestingAd = false, adStatusMessage = null, onWatchContinueAd, onRestart, onUpgrades, onMainMenu }) => {
	const revivesLeft = Math.max(0, maxRevives - revivesUsed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex-1 w-full bg-[#07080d] flex items-center justify-center p-5 overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md bg-[#110b0e] border border-red-500/40 rounded-2xl p-6 text-center space-y-4 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.26em] text-red-400/90 font-semibold",
						children: "Fallen in the Shadows"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-bold text-white mt-1",
						children: "GAME OVER"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-400 mt-1",
						children: "Continue right where you fell with full HP & 4s magical shield, or restart clean."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-2 text-[11px] font-mono-tabular text-slate-300 bg-black/35 border border-white/10 rounded-lg py-1.5 px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Revives This Attempt:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: revivesLeft > 0 ? "text-amber-300 font-bold" : "text-red-400 font-bold",
						children: [
							revivesLeft,
							" / ",
							maxRevives,
							" remaining"
						]
					})]
				}),
				adStatusMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-amber-200 bg-amber-500/15 border border-amber-500/35 rounded-lg px-3 py-2 leading-snug",
					children: adStatusMessage
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					disabled: !(canRevive && revivesLeft > 0) || isRequestingAd,
					onClick: () => {
						soundEngine.playSfx("uiClick");
						onWatchContinueAd();
					},
					className: "w-full py-3 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 disabled:text-slate-400 disabled:border disabled:border-white/10 disabled:cursor-not-allowed text-slate-950 text-xs font-extrabold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "w-4 h-4 shrink-0" }), isRequestingAd ? "Loading Rewarded Ad…" : revivesLeft <= 0 ? `Max Revives Reached (${revivesUsed}/${maxRevives})` : "WATCH AD & CONTINUE"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundEngine.playSfx("uiClick");
								onMainMenu();
							},
							className: "px-4 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer",
							children: "MAIN MENU"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundEngine.playSfx("uiClick");
								onUpgrades();
							},
							className: "px-3.5 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer",
							children: "Upgrades"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundEngine.playSfx("uiClick");
								onRestart();
							},
							className: "flex-1 py-3 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" }), " RUN AGAIN"]
						})
					]
				})
			]
		})
	});
};
// src/App.tsx
function App() {
	const [save, setSave] = (0, import_react.useState)(() => loadSaveData());
	const [screen, setScreen] = (0, import_react.useState)("SPLASH");
	const [selectedWorld, setSelectedWorld] = (0, import_react.useState)(() => getWorldForLevel(loadSaveData().unlockedLevelMax));
	const [activeLevelId, setActiveLevelId] = (0, import_react.useState)(() => loadSaveData().unlockedLevelMax);
	const [runCounter, setRunCounter] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [runBuffs, setRunBuffs] = (0, import_react.useState)({});
	const [reviveToken, setReviveToken] = (0, import_react.useState)(0);
	const [revivesUsed, setRevivesUsed] = (0, import_react.useState)(0);
	const [isRequestingReviveAd, setIsRequestingReviveAd] = (0, import_react.useState)(false);
	const [reviveAdMessage, setReviveAdMessage] = (0, import_react.useState)(null);
	const [lastSummary, setLastSummary] = (0, import_react.useState)(null);
	const [canRevive, setCanRevive] = (0, import_react.useState)(false);
	const [privacyBackTarget, setPrivacyBackTarget] = (0, import_react.useState)("SETTINGS");
	const [achievementToast, setAchievementToast] = (0, import_react.useState)(null);
	const [adModal, setAdModal] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!achievementToast) return;
		const t = window.setTimeout(() => setAchievementToast(null), 4200);
		return () => window.clearTimeout(t);
	}, [achievementToast]);
	const updateSave = (0, import_react.useCallback)((updater) => {
		setSave((prev) => {
			const { updated, newlyUnlocked } = evaluateNewAchievements(updater(prev));
			persistSaveData(updated);
			if (newlyUnlocked.length > 0) {
				soundEngine.playSfx("treasure");
				setAchievementToast(newlyUnlocked[0]);
			}
			return updated;
		});
	}, []);
	(0, import_react.useEffect)(() => {
		soundEngine.setVolumes(save.settings.musicVolume, save.settings.sfxVolume);
	}, [save.settings.musicVolume, save.settings.sfxVolume]);
	(0, import_react.useEffect)(() => {
		adMobBridge.registerPreviewModalHandler((type, placement, done) => {
			setAdModal({
				type,
				placement,
				onClose: (granted) => {
					setAdModal(null);
					done?.(granted);
				}
			});
		});
		return adMobBridge.subscribeFullscreenLifecycle((showing) => {
			if (showing) {
				soundEngine.onAppPause();
				if (screen === "PLAYING") setPaused(true);
			} else soundEngine.onAppResume();
		});
	}, [screen]);
	(0, import_react.useEffect)(() => {
		const isBossLevel = screen === "PLAYING" && getLevelById(activeLevelId).isBoss;
		adMobBridge.syncScreenState(screen, isBossLevel);
		if (screen !== "PLAYING" && screen !== "SPLASH") soundEngine.startMusic("menu");
	}, [screen, activeLevelId]);
	(0, import_react.useEffect)(() => {
		const onVisChange = () => {
			if (document.hidden) {
				soundEngine.onAppPause();
				if (screen === "PLAYING") setPaused(true);
			} else {
				soundEngine.onAppResume();
				adMobBridge.triggerAppOpenIfAppropriate(screen);
			}
		};
		document.addEventListener("visibilitychange", onVisChange);
		return () => document.removeEventListener("visibilitychange", onVisChange);
	}, [screen]);
	const startLevel = (0, import_react.useCallback)((levelId, buffsOverride) => {
		if (buffsOverride) setRunBuffs(buffsOverride);
		setActiveLevelId(levelId);
		setSelectedWorld(getWorldForLevel(levelId));
		setPaused(false);
		setReviveToken(0);
		setRevivesUsed(0);
		setIsRequestingReviveAd(false);
		setReviveAdMessage(null);
		setRunCounter((c) => c + 1);
		setScreen("PLAYING");
	}, []);
	const handleLevelEnd = (0, import_react.useCallback)((summary, newKeys, revivable) => {
		setLastSummary(summary);
		setCanRevive(revivable);
		setReviveAdMessage(null);
		setIsRequestingReviveAd(false);
		const deltaCoins = summary.saveCoinsDelta ?? summary.coinsEarned;
		const deltaCrystals = summary.saveCrystalsDelta ?? summary.crystalsEarned;
		const deltaTime = summary.saveTimeDeltaSec ?? summary.timeSec;
		const deltaEnemies = summary.saveEnemiesDelta ?? summary.enemiesDispersed ?? 0;
		const deltaDashes = summary.saveDashesDelta ?? summary.dashesUsed ?? 0;
		const deltaJumps = summary.saveJumpsDelta ?? summary.jumpsUsed ?? 0;
		const deltaArrows = summary.saveArrowsDelta ?? summary.arrowsFired ?? 0;
		const deltaSecrets = summary.saveSecretsDelta ?? summary.secretsFound;
		updateSave((prev) => {
			const existingKeys = new Set(prev.collectedItemKeys);
			newKeys.forEach((k) => existingKeys.add(k));
			const nextStats = {
				...prev.stats,
				totalPlayTimeSec: prev.stats.totalPlayTimeSec + deltaTime,
				totalEnemiesDispersed: prev.stats.totalEnemiesDispersed + deltaEnemies,
				totalDashes: prev.stats.totalDashes + deltaDashes,
				totalJumps: prev.stats.totalJumps + deltaJumps,
				totalArrowsFired: (prev.stats.totalArrowsFired ?? 0) + deltaArrows,
				secretsFound: prev.stats.secretsFound + deltaSecrets,
				totalDeaths: prev.stats.totalDeaths + (summary.victory ? 0 : 1),
				bossesDefeated: prev.stats.bossesDefeated + (summary.victory && summary.isBoss && !prev.levelProgress[summary.levelId]?.completed ? 1 : 0)
			};
			if (!summary.victory) return {
				...prev,
				collectedItemKeys: Array.from(existingKeys),
				coins: prev.coins + deltaCoins,
				crystals: prev.crystals + deltaCrystals,
				stats: nextStats
			};
			const prevProg = prev.levelProgress[summary.levelId];
			const nextLevelProgress = {
				...prev.levelProgress,
				[summary.levelId]: {
					completed: true,
					stars: Math.max(prevProg?.stars ?? 0, summary.stars),
					bestScore: Math.max(prevProg?.bestScore ?? 0, summary.score),
					bestTimeSec: prevProg?.bestTimeSec && prevProg.bestTimeSec > 0 ? Math.min(prevProg.bestTimeSec, summary.timeSec) : summary.timeSec
				}
			};
			const nextUnlockedMax = Math.min(60, Math.max(prev.unlockedLevelMax, summary.levelId + 1));
			const nextWorlds = new Set(prev.unlockedWorlds);
			nextWorlds.add(getWorldForLevel(nextUnlockedMax));
			return {
				...prev,
				unlockedLevelMax: nextUnlockedMax,
				unlockedWorlds: Array.from(nextWorlds),
				levelProgress: nextLevelProgress,
				collectedItemKeys: Array.from(existingKeys),
				coins: prev.coins + deltaCoins,
				crystals: prev.crystals + deltaCrystals,
				stats: nextStats
			};
		});
		if (!summary.victory) setScreen("GAME_OVER");
		else if (summary.isBoss) {
			setRunBuffs({});
			setScreen("BOSS_VICTORY");
		} else {
			setRunBuffs({});
			setScreen("LEVEL_COMPLETE");
			adMobBridge.notifyLevelCompleted(summary.levelId, runCounter, summary.isBoss);
		}
	}, [updateSave, runCounter]);
	const handleUpgrade = (id) => {
		updateSave((prev) => {
			const def = ABILITY_MAP[id];
			const current = prev.upgrades[id] ?? 0;
			if (current >= def.maxLevel) return prev;
			const cost = getUpgradeCost(def, current);
			if (prev.coins < cost.coins || prev.crystals < cost.crystals) return prev;
			return {
				...prev,
				coins: prev.coins - cost.coins,
				crystals: prev.crystals - cost.crystals,
				upgrades: {
					...prev.upgrades,
					[id]: current + 1
				}
			};
		});
	};
	const handleArrow = (id) => {
		updateSave((prev) => {
			const unlocked = prev.unlockedArrows ?? ["shadow"];
			if (unlocked.includes(id)) return {
				...prev,
				selectedArrow: id
			};
			const def = ARROW_MAP[id];
			if (prev.coins < def.coinCost || prev.crystals < def.crystalCost) return prev;
			return {
				...prev,
				coins: prev.coins - def.coinCost,
				crystals: prev.crystals - def.crystalCost,
				unlockedArrows: [...unlocked, id],
				selectedArrow: id
			};
		});
	};
	const handleCostume = (id) => {
		updateSave((prev) => {
			if (prev.unlockedCostumes.includes(id)) return {
				...prev,
				selectedCostume: id
			};
			const def = COSTUME_MAP[id];
			if (prev.coins < def.coinCost || prev.crystals < def.crystalCost) return prev;
			return {
				...prev,
				coins: prev.coins - def.coinCost,
				crystals: prev.crystals - def.crystalCost,
				unlockedCostumes: [...prev.unlockedCostumes, id],
				selectedCostume: id
			};
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-screen h-screen bg-[#07080d] text-slate-100 flex flex-col overflow-hidden",
		children: [
			screen === "SPLASH" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplashScreen, { onContinue: () => {
				soundEngine.startMusic("menu");
				setScreen("MAIN_MENU");
			} }),
			screen === "MAIN_MENU" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MainMenuScreen, {
				save,
				onNavigate: setScreen,
				onPlayContinue: () => startLevel(save.unlockedLevelMax),
				onWatchBonusCoins: () => {
					adMobBridge.requestRewardedOptIn("bonusCoins", (granted) => {
						if (granted) {
							soundEngine.playSfx("treasure");
							updateSave((prev) => ({
								...prev,
								coins: prev.coins + 100
							}));
						}
					});
				}
			}),
			screen === "WORLDS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldSelectionScreen, {
				save,
				onSelectWorld: (w) => {
					setSelectedWorld(w);
					setScreen("LEVELS");
				},
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "LEVELS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelSelectionScreen, {
				worldId: selectedWorld,
				save,
				runBuffs,
				onArmBuff: (placement) => {
					adMobBridge.requestRewardedOptIn(placement, (granted) => {
						if (granted) {
							soundEngine.playSfx("shield");
							setRunBuffs((prev) => ({
								...prev,
								...placement === "extraLife" ? { extraLife: true } : {},
								...placement === "arrowEnergy" ? { arrowEnergyBoost: true } : {},
								...placement === "shadowShield" ? { shadowShieldBoost: true } : {},
								...placement === "abilityBoost" ? {
									extraLife: true,
									arrowEnergyBoost: true,
									shadowShieldBoost: true
								} : {}
							}));
						}
					});
				},
				onStartLevel: (lvlId) => startLevel(lvlId),
				onBack: () => setScreen("WORLDS")
			}),
			screen === "UPGRADES" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradesScreen, {
				save,
				onUpgrade: handleUpgrade,
				onSelectOrUnlockArrow: handleArrow,
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "COSTUMES" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostumesScreen, {
				save,
				onSelectOrUnlock: handleCostume,
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "SETTINGS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {
				save,
				onUpdateSettings: (patch) => updateSave((prev) => ({
					...prev,
					settings: {
						...prev.settings,
						...patch
					}
				})),
				onResetProgress: () => {
					const fresh = resetSaveData();
					setSave(fresh);
					setSelectedWorld("forest");
					setActiveLevelId(1);
				},
				onOpenPrivacy: () => {
					setPrivacyBackTarget("SETTINGS");
					setScreen("PRIVACY");
				},
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "ACHIEVEMENTS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AchievementsScreen, {
				save,
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "PROFILE" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, {
				save,
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "HOW_TO_PLAY" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowToPlayScreen, {
				save,
				onBack: () => setScreen("MAIN_MENU")
			}),
			screen === "PRIVACY" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyPolicyScreen, {
				save,
				onConsentAccept: () => {
					adMobBridge.openPrivacyConsent();
					updateSave((prev) => ({
						...prev,
						settings: {
							...prev.settings,
							consentAccepted: true
						}
					}));
				},
				onBack: () => setScreen(privacyBackTarget)
			}),
			(screen === "PLAYING" || screen === "GAME_OVER") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: screen === "GAME_OVER" ? "hidden" : "relative flex-1 w-full overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameViewport, {
					levelId: activeLevelId,
					save,
					paused,
					suspended: screen === "GAME_OVER",
					bonusBoost: runBuffs,
					reviveToken,
					onPauseToggle: () => {
						if (screen === "PLAYING") setPaused((p) => !p);
					},
					onLevelEnd: handleLevelEnd
				}, `${activeLevelId}-${runCounter}`), paused && screen === "PLAYING" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseOverlay, {
					onResume: () => setPaused(false),
					onRestart: () => {
						setRunBuffs({});
						startLevel(activeLevelId);
					},
					onSettings: () => {
						setPaused(false);
						setScreen("SETTINGS");
					},
					onExitToLevels: () => {
						setPaused(false);
						setScreen("LEVELS");
					}
				})]
			}),
			screen === "LEVEL_COMPLETE" && lastSummary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelCompleteScreen, {
				summary: lastSummary,
				hasNextLevel: lastSummary.levelId < 60,
				onDoubleRewardAd: () => {
					adMobBridge.requestRewardedOptIn("doubleReward", (granted) => {
						if (granted) {
							soundEngine.playSfx("treasure");
							updateSave((prev) => ({
								...prev,
								coins: prev.coins + lastSummary.coinsEarned
							}));
							setLastSummary((s) => s ? {
								...s,
								rewardBonusApplied: true
							} : s);
						}
					});
				},
				onNextLevel: () => startLevel(Math.min(60, lastSummary.levelId + 1)),
				onReplay: () => startLevel(lastSummary.levelId),
				onLevels: () => setScreen("LEVELS")
			}),
			screen === "BOSS_VICTORY" && lastSummary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BossVictoryScreen, {
				summary: lastSummary,
				hasNextWorld: lastSummary.worldId !== "fortress",
				onContinue: () => {
					const idx = WORLDS.findIndex((w) => w.id === lastSummary.worldId);
					if (idx >= 0 && idx < WORLDS.length - 1) {
						setSelectedWorld(WORLDS[idx + 1].id);
						setScreen("LEVELS");
					} else setScreen("PROFILE");
				}
			}),
			screen === "GAME_OVER" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameOverScreen, {
				canRevive,
				revivesUsed,
				maxRevives: 2,
				isRequestingAd: isRequestingReviveAd,
				adStatusMessage: reviveAdMessage,
				onWatchContinueAd: () => {
					if (isRequestingReviveAd || !canRevive || revivesUsed >= 2) return;
					setIsRequestingReviveAd(true);
					setReviveAdMessage(null);
					adMobBridge.requestRewardedOptIn("checkpointRetry", (granted) => {
						setIsRequestingReviveAd(false);
						if (granted) {
							setRevivesUsed((used) => used + 1);
							setReviveToken((t) => t + 1);
							setScreen("PLAYING");
						} else setReviveAdMessage("Rewarded ad was not completed or is not loaded yet. Your progress is safe — try again or tap RUN AGAIN.");
					});
				},
				onRestart: () => {
					setRunBuffs({});
					startLevel(activeLevelId);
				},
				onUpgrades: () => {
					setRunBuffs({});
					setScreen("UPGRADES");
				},
				onMainMenu: () => {
					setRunBuffs({});
					setScreen("MAIN_MENU");
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BannerAdSlot, { screen }),
			achievementToast && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-[#0d111c]/95 border border-amber-400/60 rounded-xl px-4 py-2.5 shadow-2xl flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-5 h-5 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-wider text-amber-300 font-semibold",
					children: "Achievement Unlocked"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs font-bold text-white",
					children: [
						achievementToast.title,
						" · +",
						achievementToast.rewardCoins,
						" Coins, +",
						achievementToast.rewardCrystals,
						" Crystals"
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdPreviewModal, { modal: adModal })
		]
	});
}
// src/main.tsx
(0, import_client.createRoot)(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {}));
