plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.educationwithhassan.islamicallinone"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.educationwithhassan.islamicallinone"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.1.0"

        manifestPlaceholders["admobAppId"] = "ca-app-pub-3133971041724338~8711999965"
        buildConfigField("String", "ADMOB_APP_ID", "\"ca-app-pub-3133971041724338~8711999965\"")
        buildConfigField("String", "ADMOB_BANNER_ID", "\"ca-app-pub-3133971041724338/4228656986\"")
        buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3133971041724338/7976330301\"")
        buildConfigField("String", "ADMOB_REWARDED_ID", "\"ca-app-pub-3133971041724338/2724003629\"")
        buildConfigField("String", "ADMOB_APP_OPEN_ID", "\"ca-app-pub-3133971041724338/5158595277\"")
        buildConfigField("String", "ADMOB_NATIVE_ID", "\"ca-app-pub-3133971041724338/6990551699\"")
        buildConfigField("boolean", "ADMOB_USE_TEST_IDS", "false")
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("androidx.lifecycle:lifecycle-process:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("com.batoulapps.adhan:adhan2:0.0.5")
    implementation("com.google.android.gms:play-services-ads:23.3.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")
}
