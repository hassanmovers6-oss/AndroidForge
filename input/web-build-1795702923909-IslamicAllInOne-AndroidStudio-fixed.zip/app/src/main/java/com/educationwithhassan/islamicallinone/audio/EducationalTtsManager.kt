package com.educationwithhassan.islamicallinone.audio

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class TtsUiState(
    val isActive: Boolean = false,
    val isSpeaking: Boolean = false,
    val isPaused: Boolean = false,
    val isReady: Boolean = false,
    val trackId: String = "",
    val title: String = "",
    val subtitle: String = "Text-to-Speech Narration (not an authentic recording)",
    val langLabel: String = "EN",
    val chunkIndex: Int = 0,
    val totalChunks: Int = 0,
    val errorMessage: String? = null,
    val unavailableNotice: String? = null
)

class EducationalTtsManager(private val context: Context) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var chunks: List<String> = emptyList()
    private var currentIndex: Int = 0
    private var currentIsUrdu: Boolean = false
    private var activeToken: Int = 0

    var onBeforeSpeak: (() -> Unit)? = null

    private val _uiState = MutableStateFlow(TtsUiState())
    val uiState: StateFlow<TtsUiState> = _uiState.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            mainHandler.post {
                val engine = tts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            val token = utteranceId?.substringAfter("tts_")?.substringBefore("_")?.toIntOrNull()
                            if (token != activeToken) return
                            mainHandler.post {
                                _uiState.value = _uiState.value.copy(
                                    isSpeaking = true,
                                    isPaused = false,
                                    errorMessage = null
                                )
                            }
                        }

                        override fun onDone(utteranceId: String?) {
                            val token = utteranceId?.substringAfter("tts_")?.substringBefore("_")?.toIntOrNull()
                            if (token != activeToken) return
                            mainHandler.post {
                                if (currentIndex + 1 < chunks.size) {
                                    currentIndex += 1
                                    speakCurrentChunk()
                                } else {
                                    _uiState.value = TtsUiState(isReady = true)
                                }
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            val token = utteranceId?.substringAfter("tts_")?.substringBefore("_")?.toIntOrNull()
                            if (token != activeToken) return
                            mainHandler.post {
                                _uiState.value = _uiState.value.copy(
                                    isSpeaking = false,
                                    isPaused = false,
                                    errorMessage = "Text-to-Speech narration failed. Tap Retry."
                                )
                            }
                        }
                    })
                    _uiState.value = _uiState.value.copy(isReady = true)
                }
            }
        }
    }

    private fun splitSpeechChunks(text: String): List<String> {
        val rawSentences = text
            .replace(Regex("\\s+"), " ")
            .trim()
            .split(Regex("(?<=[.!؟۔?])\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (rawSentences.isEmpty()) return emptyList()
        val grouped = mutableListOf<String>()
        var current = ""
        for (sentence in rawSentences) {
            if ((current + " " + sentence).trim().length > 260 && current.isNotEmpty()) {
                grouped.add(current.trim())
                current = sentence
            } else {
                current = if (current.isEmpty()) sentence else "${current} ${sentence}"
            }
        }
        if (current.isNotEmpty()) grouped.add(current.trim())
        return grouped
    }

    fun speak(trackId: String, title: String, text: String, isUrdu: Boolean) {
        onBeforeSpeak?.invoke()
        val engine = tts
        if (engine == null || !_uiState.value.isReady) {
            _uiState.value = _uiState.value.copy(
                unavailableNotice = "Text-to-Speech engine is still initializing on this device."
            )
            return
        }

        if (isUrdu) {
            val urPk = engine.isLanguageAvailable(Locale("ur", "PK"))
            val urAny = engine.isLanguageAvailable(Locale("ur"))
            val ok = urPk >= TextToSpeech.LANG_AVAILABLE || urAny >= TextToSpeech.LANG_AVAILABLE
            if (!ok) {
                _uiState.value = _uiState.value.copy(
                    unavailableNotice = "Urdu Text-to-Speech voice pack is unavailable on this device."
                )
                return
            }
            engine.language = if (urPk >= TextToSpeech.LANG_AVAILABLE) Locale("ur", "PK") else Locale("ur")
        } else {
            engine.language = Locale.US
        }

        val parsedChunks = splitSpeechChunks(text)
        if (parsedChunks.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                unavailableNotice = "${title}: No narration text available."
            )
            return
        }

        activeToken += 1
        chunks = parsedChunks
        currentIndex = 0
        currentIsUrdu = isUrdu

        _uiState.value = _uiState.value.copy(
            isActive = true,
            isSpeaking = true,
            isPaused = false,
            trackId = trackId,
            title = title,
            subtitle = if (isUrdu) "Urdu Text-to-Speech Narration (not an authentic recording)" else "English Text-to-Speech Narration (not an authentic recording)",
            langLabel = if (isUrdu) "UR" else "EN",
            chunkIndex = 1,
            totalChunks = parsedChunks.size,
            errorMessage = null,
            unavailableNotice = null
        )
        speakCurrentChunk()
    }

    private fun speakCurrentChunk() {
        val engine = tts ?: return
        val chunk = chunks.getOrNull(currentIndex) ?: return
        val uttId = "tts_${activeToken}_${currentIndex}"
        _uiState.value = _uiState.value.copy(
            chunkIndex = currentIndex + 1,
            totalChunks = chunks.size,
            isSpeaking = true,
            isPaused = false,
            errorMessage = null
        )
        engine.speak(chunk, TextToSpeech.QUEUE_FLUSH, Bundle(), uttId)
    }

    fun pause() {
        activeToken += 1
        tts?.stop()
        if (_uiState.value.isActive) {
            _uiState.value = _uiState.value.copy(isSpeaking = false, isPaused = true)
        }
    }

    fun resume() {
        if (!_uiState.value.isActive || chunks.isEmpty()) return
        activeToken += 1
        speakCurrentChunk()
    }

    fun retry() {
        if (!_uiState.value.isActive || chunks.isEmpty()) return
        activeToken += 1
        speakCurrentChunk()
    }

    fun stop() {
        activeToken += 1
        tts?.stop()
        chunks = emptyList()
        currentIndex = 0
        _uiState.value = TtsUiState(isReady = _uiState.value.isReady)
    }

    fun clearUnavailableNotice() {
        _uiState.value = _uiState.value.copy(unavailableNotice = null)
    }
}
