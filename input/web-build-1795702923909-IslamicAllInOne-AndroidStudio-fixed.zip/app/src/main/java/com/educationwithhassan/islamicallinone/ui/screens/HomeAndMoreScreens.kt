package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.islamicallinone.ads.AdManager
import com.educationwithhassan.islamicallinone.ads.NativeAdFeedCard
import com.educationwithhassan.islamicallinone.ads.RewardStorage
import com.educationwithhassan.islamicallinone.ads.RewardedOfferCard
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.EducationalTtsManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.data.AllSectionsRepository
import java.util.Calendar

enum class MoreDestination {
    HUB,
    NAMES99,
    SEERAH,
    LEARNING,
    TASBEEH,
    QUIZ,
    SETTINGS
}

@Composable
fun HomeScreen(
    adManager: AdManager,
    rewardStorage: RewardStorage,
    audioManager: AudioPlayerManager,
    ttsManager: EducationalTtsManager,
    isAudioPlaying: Boolean,
    onOpenQuran: () -> Unit,
    onOpenHadith: () -> Unit,
    onOpenDuas: () -> Unit,
    onOpenAzkar: () -> Unit,
    onOpenMoreSection: (MoreDestination) -> Unit
) {
    val context = LocalContext.current
    val data = remember { AllSectionsRepository.load(context) }
    val dayOfYear = remember { Calendar.getInstance().get(Calendar.DAY_OF_YEAR) }
    val dailyDua = remember(data, dayOfYear) {
        val verified = data.duas.filter { it.audioUrl != null }
        verified[dayOfYear % verified.size]
    }
    val dailyReminder = remember(data, dayOfYear) {
        data.dailyReminders[dayOfYear % data.dailyReminders.size]
    }

    val audioState by audioManager.uiState.collectAsState()
    val ttsState by ttsManager.uiState.collectAsState()
    val rewardState by rewardStorage.state.collectAsState()

    val isDailyDuaThis = audioState.mode == PlaybackModeState.TRACK && audioState.trackId == "home_${dailyDua.id}"
    val isReminderEn = ttsState.isActive && ttsState.trackId == "home_reminder_en"
    val isReminderUr = ttsState.isActive && ttsState.trackId == "home_reminder_ur"

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Text("Assalamu Alaikum", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Text("Islamic All-in-One", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Your Complete Offline Islamic Companion · ${rewardState.knowledgePoints} Knowledge Pts", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            Text("Quick Sections", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onOpenQuran, modifier = Modifier.weight(1f)) { Text("Quran") }
                OutlinedButton(onClick = onOpenHadith, modifier = Modifier.weight(1f)) { Text("Hadith") }
                OutlinedButton(onClick = onOpenAzkar, modifier = Modifier.weight(1f)) { Text("Azkar") }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onOpenMoreSection(MoreDestination.NAMES99) }, modifier = Modifier.weight(1f)) { Text("99 Names") }
                OutlinedButton(onClick = { onOpenMoreSection(MoreDestination.QUIZ) }, modifier = Modifier.weight(1f)) { Text("Quiz") }
                OutlinedButton(onClick = { onOpenMoreSection(MoreDestination.SETTINGS) }, modifier = Modifier.weight(1f)) { Text("Themes") }
            }
        }

        item {
            RewardedOfferCard(
                title = "Daily Islamic Knowledge Bonus (+25 Pts)",
                description = "Optional daily reward (1 per day): watch a short video to earn +25 Knowledge Points toward your learning streak.",
                rewardBadge = "+25 Points",
                placement = "home_daily_bonus",
                adManager = adManager,
                isAudioPlaying = isAudioPlaying,
                alreadyGrantedLabel = if (rewardState.isDailyBonusClaimedToday()) "Today's +25 Knowledge Points claimed! Total: ${rewardState.knowledgePoints} pts" else null,
                onRewardGranted = { token -> rewardStorage.claimDailyBonusReward(token) }
            )
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Daily Dua · Verified Recording", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(dailyDua.title, fontWeight = FontWeight.Bold)
                        }
                        if (dailyDua.audioUrl != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = {
                                    when {
                                        isDailyDuaThis && audioState.isPlaying -> audioManager.pause()
                                        isDailyDuaThis && !audioState.isLoading && audioState.errorMessage == null -> audioManager.resume()
                                        else -> audioManager.playTrack(
                                            title = dailyDua.title,
                                            subtitle = dailyDua.audioSourceNote ?: "Hisn al-Muslim Verified Recording",
                                            audioUrl = dailyDua.audioUrl,
                                            trackId = "home_${dailyDua.id}"
                                        )
                                    }
                                }) {
                                    Icon(if (isDailyDuaThis && audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (isDailyDuaThis && audioState.isPlaying) "Pause" else "Play")
                                }
                                if (isDailyDuaThis) {
                                    IconButton(onClick = { audioManager.stop() }) {
                                        Icon(Icons.Default.Stop, null)
                                    }
                                }
                            }
                        }
                    }
                    Text(dailyDua.arabic, fontSize = 20.sp, lineHeight = 32.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Text(dailyDua.english, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Daily Islamic Reminder", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(dailyReminder.title, fontWeight = FontWeight.Bold)
                    Text(dailyReminder.body, style = MaterialTheme.typography.bodyMedium)
                    if (dailyReminder.bodyUr.isNotBlank()) {
                        Text(dailyReminder.bodyUr, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            when {
                                isReminderEn && ttsState.isSpeaking -> ttsManager.pause()
                                isReminderEn && ttsState.isPaused -> ttsManager.resume()
                                else -> ttsManager.speak("home_reminder_en", dailyReminder.title, "${dailyReminder.title}. ${dailyReminder.body}", isUrdu = false)
                            }
                        }) {
                            Icon(Icons.Default.RecordVoiceOver, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (isReminderEn && ttsState.isSpeaking) "Pause TTS" else "Listen EN (TTS)")
                        }
                        if (dailyReminder.bodyUr.isNotBlank()) {
                            OutlinedButton(onClick = {
                                when {
                                    isReminderUr && ttsState.isSpeaking -> ttsManager.pause()
                                    isReminderUr && ttsState.isPaused -> ttsManager.resume()
                                    else -> ttsManager.speak("home_reminder_ur", "${dailyReminder.title} (Urdu)", dailyReminder.bodyUr, isUrdu = true)
                                }
                            }) {
                                Text(if (isReminderUr && ttsState.isSpeaking) "Pause UR" else "Urdu (TTS)")
                            }
                        }
                    }
                    Text("Voice narration uses Text-to-Speech (not an authentic recording) · ${dailyReminder.reference}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun MoreHubScreen(
    adManager: AdManager,
    isAudioPlaying: Boolean,
    onOpenAzkar: () -> Unit,
    onSelectDestination: (MoreDestination) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Text("More Islamic Tools & Audio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Complete audio-enabled Islamic sections", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            MoreMenuCard("Asma-ul-Husna · 99 Names of Allah", "Individual verified Arabic pronunciation for all 99 Names", Icons.Default.AutoAwesome) {
                onSelectDestination(MoreDestination.NAMES99)
            }
        }
        item {
            MoreMenuCard("Morning, Evening & After-Salah Azkar", "Verified Hisn al-Muslim Arabic recitations & repeat counters", Icons.Default.Favorite) {
                onOpenAzkar()
            }
        }
        item {
            MoreMenuCard("Seerah & Islamic History", "Chronological articles with labeled EN/UR Text-to-Speech", Icons.Default.HistoryEdu) {
                onSelectDestination(MoreDestination.SEERAH)
            }
        }
        item {
            MoreMenuCard("Islamic Learning Center", "Wudu, Salah & Tajweed with authentic step recitations + TTS", Icons.Default.School) {
                onSelectDestination(MoreDestination.LEARNING)
            }
        }
        item {
            MoreMenuCard("Islamic Knowledge Quiz", "10 categories, 50/50 hints & optional learning boost", Icons.Default.Quiz) {
                onSelectDestination(MoreDestination.QUIZ)
            }
        }
        item {
            MoreMenuCard("Digital Tasbeeh & Dhikr Audio", "Authentic Arabic Dhikr clips & interactive Tasbeeh counter", Icons.Default.TouchApp) {
                onSelectDestination(MoreDestination.TASBEEH)
            }
        }
        item {
            MoreMenuCard("Themes, Customization & AdMob", "Aurora free + optional 24h premium themes & live AdMob diagnostics", Icons.Default.Palette) {
                onSelectDestination(MoreDestination.SETTINGS)
            }
        }
        item {
            NativeAdFeedCard(
                adManager = adManager,
                isVisible = !isAudioPlaying,
                placement = "more_hub_feed"
            )
        }
    }
}

@Composable
private fun MoreMenuCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        }
    }
}
