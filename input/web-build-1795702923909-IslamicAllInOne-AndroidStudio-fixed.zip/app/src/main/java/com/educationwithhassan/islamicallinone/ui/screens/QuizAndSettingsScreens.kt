package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.educationwithhassan.islamicallinone.BuildConfig
import com.educationwithhassan.islamicallinone.ads.AdManager
import com.educationwithhassan.islamicallinone.ads.RewardStorage
import com.educationwithhassan.islamicallinone.ads.RewardedOfferCard
import com.educationwithhassan.islamicallinone.ads.findActivity
import com.educationwithhassan.islamicallinone.data.AllSectionsRepository
import com.educationwithhassan.islamicallinone.data.QuizQuestionItem
import com.educationwithhassan.islamicallinone.ui.theme.ISLAMIC_THEME_OPTIONS

@Composable
fun QuizScreen(
    adManager: AdManager,
    rewardStorage: RewardStorage,
    isAudioPlaying: Boolean,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val data = remember { AllSectionsRepository.load(context) }
    val rewardState by rewardStorage.state.collectAsState()

    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var activeQuestions by remember { mutableStateOf<List<QuizQuestionItem>>(emptyList()) }
    var qIndex by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var hiddenWrongIndices by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var isCompleted by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Islamic Knowledge Quiz", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Hints: ${rewardState.quizHintsCount} · Knowledge Points: ${rewardState.knowledgePoints}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(Modifier.height(8.dp))

        if (selectedCategory == null) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    RewardedOfferCard(
                        title = "Learning Boost: +2 Quiz Hints & Bonus Practice",
                        description = "Optional reward: watch a short video to receive 2 extra 50/50 hints and unlock Mixed All-Categories Challenge. You can always play every category without watching.",
                        rewardBadge = "+2 Hints",
                        placement = "quiz_learning_boost",
                        adManager = adManager,
                        isAudioPlaying = isAudioPlaying,
                        onRewardGranted = { token -> rewardStorage.grantQuizReward(token) }
                    )
                }

                if (rewardState.bonusPracticeUnlocked && data.quizQuestions.isNotEmpty()) {
                    item {
                        Card(
                            onClick = {
                                selectedCategory = "Mixed Challenge"
                                activeQuestions = data.quizQuestions.shuffled().take(10)
                                qIndex = 0; selectedAnswer = null; score = 0; hiddenWrongIndices = emptySet(); isCompleted = false
                            },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Row(modifier = Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Quiz, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Bonus Practice: Mixed 10-Question Challenge", fontWeight = FontWeight.Bold)
                                    Text("Unlocked via Learning Reward", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                items(data.quizCategories) { category ->
                    val count = data.quizQuestions.count { it.category == category }
                    Card(
                        onClick = {
                            val list = data.quizQuestions.filter { it.category == category }
                            if (list.isNotEmpty()) {
                                selectedCategory = category
                                activeQuestions = list
                                qIndex = 0; selectedAnswer = null; score = 0; hiddenWrongIndices = emptySet(); isCompleted = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(category, fontWeight = FontWeight.Bold)
                                Text("$count verified questions", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("Start", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else if (isCompleted) {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("$selectedCategory Complete!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Score: $score / ${activeQuestions.size}", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val goHome = { selectedCategory = null; isCompleted = false }
                            if (activity != null) {
                                adManager.showInterstitialIfEligible(
                                    activity = activity,
                                    isSacredScreen = false,
                                    isAudioPlaying = isAudioPlaying,
                                    placement = "post_quiz_continue",
                                    onContinue = goHome
                                )
                            } else {
                                goHome()
                            }
                        }) {
                            Text("All Categories")
                        }
                        OutlinedButton(onClick = {
                            qIndex = 0; selectedAnswer = null; score = 0; hiddenWrongIndices = emptySet(); isCompleted = false
                        }) {
                            Text("Retry")
                        }
                    }
                }
            }
        } else {
            val q = activeQuestions[qIndex]
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("$selectedCategory · Question ${qIndex + 1}/${activeQuestions.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        OutlinedButton(
                            enabled = selectedAnswer == null && hiddenWrongIndices.isEmpty() && rewardState.quizHintsCount > 0,
                            onClick = {
                                if (rewardStorage.consumeQuizHint()) {
                                    val wrong = q.options.indices.filter { it != q.correctIndex }.shuffled().take(2).toSet()
                                    hiddenWrongIndices = wrong
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Lightbulb, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("50/50 Hint (${rewardState.quizHintsCount})", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(q.question, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            q.options.forEachIndexed { idx, opt ->
                                if (idx !in hiddenWrongIndices) {
                                    val isChosen = selectedAnswer == idx
                                    val isCorrect = idx == q.correctIndex
                                    val container = when {
                                        selectedAnswer == null -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        isCorrect -> MaterialTheme.colorScheme.primaryContainer
                                        isChosen -> MaterialTheme.colorScheme.errorContainer
                                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                    }
                                    Card(
                                        onClick = {
                                            if (selectedAnswer == null) {
                                                selectedAnswer = idx
                                                if (idx == q.correctIndex) score += 1
                                            }
                                        },
                                        colors = CardDefaults.cardColors(containerColor = container),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(opt, modifier = Modifier.padding(12.dp), fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }
                            if (selectedAnswer != null) {
                                Text(q.explanation, style = MaterialTheme.typography.bodySmall)
                                Text("Reference: ${q.reference}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Button(onClick = {
                                    if (qIndex + 1 < activeQuestions.size) {
                                        qIndex += 1
                                        selectedAnswer = null
                                        hiddenWrongIndices = emptySet()
                                    } else {
                                        isCompleted = true
                                    }
                                }) {
                                    Text(if (qIndex + 1 < activeQuestions.size) "Next Question" else "Finish Quiz")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsAndCustomizationScreen(
    adManager: AdManager,
    rewardStorage: RewardStorage,
    isAudioPlaying: Boolean,
    onBack: (() -> Unit)? = null
) {
    val rewardState by rewardStorage.state.collectAsState()
    val useTestIds by adManager.testModeEnabled.collectAsState()
    val logs by adManager.debugLogs.collectAsState()
    val themesUnlocked = rewardState.areThemesUnlocked()
    val customUnlocked = rewardState.isCustomizationUnlocked()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Themes, Customization & AdMob", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Knowledge Points: ${rewardState.knowledgePoints} · Aurora theme is always free", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        item {
            RewardedOfferCard(
                title = "Unlock Premium Theme Pack & Decorative Accents (24h)",
                description = "Optional reward: watch a short video to temporarily unlock all 6 premium Islamic themes and golden decorative accents for 24 hours. Default Aurora theme remains free forever.",
                rewardBadge = "24h Theme Pack",
                placement = "settings_themes_pack",
                adManager = adManager,
                isAudioPlaying = isAudioPlaying,
                alreadyGrantedLabel = if (themesUnlocked && customUnlocked) "Premium Themes & Decorative Accents unlocked for 24h" else null,
                onRewardGranted = { token -> rewardStorage.grantThemeAndCustomizationReward(token) }
            )
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("App Color Themes", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = { rewardStorage.useDefaultThemeFree() }) {
                            Text("Use Aurora Free", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    ISLAMIC_THEME_OPTIONS.forEach { meta ->
                        val available = meta.isFree || themesUnlocked
                        val selected = rewardState.selectedThemeId == meta.id
                        Card(
                            onClick = { if (available) rewardStorage.selectTheme(meta.id) },
                            border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            )
                        ) {
                            Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(meta.label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                                Icon(
                                    imageVector = when {
                                        selected -> Icons.Default.CheckCircle
                                        available -> Icons.Default.Palette
                                        else -> Icons.Default.Lock
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (available) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Golden Decorative Accent", fontWeight = FontWeight.SemiBold)
                            Text(if (customUnlocked) "Unlocked for 24h" else "Unlock via optional reward above", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = rewardState.decorativeAccent,
                            enabled = customUnlocked || rewardState.decorativeAccent,
                            onCheckedChange = { rewardStorage.setDecorativeAccent(it) }
                        )
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("AdMob Configuration & Test Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Test Mode (Official Google Test IDs)", fontWeight = FontWeight.SemiBold)
                            Text("Use during development to prevent invalid traffic on production units", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = useTestIds, onCheckedChange = { adManager.setTestMode(it) })
                    }
                    Text("App ID: ${BuildConfig.ADMOB_APP_ID}", style = MaterialTheme.typography.labelSmall)
                    Text("Banner: ${adManager.activeBannerUnitId()}", style = MaterialTheme.typography.labelSmall)
                    Text("Interstitial: ${adManager.activeInterstitialUnitId()}", style = MaterialTheme.typography.labelSmall)
                    Text("Rewarded: ${adManager.activeRewardedUnitId()}", style = MaterialTheme.typography.labelSmall)
                    Text("Native: ${adManager.activeNativeUnitId()}", style = MaterialTheme.typography.labelSmall)
                    Text("App Open: ${adManager.activeAppOpenUnitId()}", style = MaterialTheme.typography.labelSmall)
                    Button(onClick = { adManager.preloadAll() }) {
                        Text("Preload Full-Screen Ads")
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("AdMob Debug Event Log (Live)", fontWeight = FontWeight.Bold)
                    if (logs.isEmpty()) {
                        Text("Waiting for AdMob lifecycle events...", style = MaterialTheme.typography.bodySmall)
                    } else {
                        logs.take(15).forEach { line ->
                            Text(line, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
