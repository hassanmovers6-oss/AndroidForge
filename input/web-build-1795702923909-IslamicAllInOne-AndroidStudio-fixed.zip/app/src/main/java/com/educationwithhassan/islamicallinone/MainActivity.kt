package com.educationwithhassan.islamicallinone

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.educationwithhassan.islamicallinone.ui.IslamicRootApp
import com.educationwithhassan.islamicallinone.ui.theme.IslamicAuroraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as IslamicAllInOneApp
        app.audioPlayerManager.connect()
        setContent {
            val rewardState by app.rewardStorage.state.collectAsState()
            IslamicAuroraTheme(
                themeId = rewardState.selectedThemeId,
                decorativeAccent = rewardState.decorativeAccent
            ) {
                IslamicRootApp(
                    adManager = app.adManager,
                    rewardStorage = app.rewardStorage,
                    audioManager = app.audioPlayerManager,
                    downloadManager = app.downloadManager,
                    ttsManager = app.educationalTtsManager
                )
            }
        }
    }
}
