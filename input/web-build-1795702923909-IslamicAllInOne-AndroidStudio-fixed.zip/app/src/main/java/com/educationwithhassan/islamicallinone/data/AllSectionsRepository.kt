package com.educationwithhassan.islamicallinone.data

import android.content.Context
import org.json.JSONObject

data class Name99Item(
    val number: Int,
    val arabic: String,
    val transliteration: String,
    val english: String,
    val urdu: String,
    val explanation: String,
    val audioUrl: String?,
    val audioSourceNote: String?
)

data class DuaEntry(
    val id: String,
    val category: String,
    val title: String,
    val titleUr: String,
    val arabic: String,
    val transliteration: String,
    val english: String,
    val urdu: String,
    val reference: String,
    val audioUrl: String?,
    val audioSourceNote: String?
)

data class ZikrEntry(
    val id: String,
    val category: String,
    val title: String,
    val titleUr: String,
    val arabic: String,
    val transliteration: String,
    val english: String,
    val urdu: String,
    val repeatCount: Int,
    val reference: String,
    val audioUrl: String?,
    val audioSourceNote: String?
)

data class DhikrPresetItem(
    val id: String,
    val arabic: String,
    val transliteration: String,
    val meaning: String,
    val defaultTarget: Int,
    val audioUrl: String?,
    val audioSourceNote: String?
)

data class DailyReminderItem(
    val title: String,
    val body: String,
    val bodyUr: String,
    val reference: String
)

data class SeerahArticleItem(
    val id: String,
    val section: String,
    val title: String,
    val period: String,
    val summary: String,
    val summaryUr: String,
    val content: List<String>,
    val reference: String,
    val takeaway: String
)

data class LearningStepItem(
    val heading: String,
    val arabic: String?,
    val transliteration: String?,
    val detail: String,
    val audioUrl: String?,
    val audioSourceNote: String?
)

data class LearningLessonItem(
    val id: String,
    val module: String,
    val title: String,
    val summary: String,
    val summaryUr: String,
    val steps: List<LearningStepItem>,
    val scholarlyDifferenceNote: String?,
    val reference: String
)

data class QuizQuestionItem(
    val id: String,
    val category: String,
    val difficulty: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val reference: String
)

data class AllSectionsData(
    val asmaUlHusna: List<Name99Item>,
    val duaCategories: List<String>,
    val duas: List<DuaEntry>,
    val azkarCategories: List<String>,
    val azkar: List<ZikrEntry>,
    val dhikrPresets: List<DhikrPresetItem>,
    val dailyReminders: List<DailyReminderItem>,
    val seerahArticles: List<SeerahArticleItem>,
    val learningLessons: List<LearningLessonItem>,
    val quizCategories: List<String>,
    val quizQuestions: List<QuizQuestionItem>
)

object AllSectionsRepository {
    @Volatile
    private var cached: AllSectionsData? = null

    private fun optNullableString(obj: JSONObject, key: String): String? {
        if (!obj.has(key) || obj.isNull(key)) return null
        val v = obj.optString(key, "")
        return if (v.isBlank()) null else v
    }

    fun load(context: Context): AllSectionsData {
        cached?.let { return it }
        val text = context.assets.open("data/sections_audio_catalog.json").bufferedReader().use { it.readText() }
        val root = JSONObject(text)

        val namesArr = root.getJSONArray("asmaUlHusna")
        val names = ArrayList<Name99Item>(namesArr.length())
        for (i in 0 until namesArr.length()) {
            val o = namesArr.getJSONObject(i)
            names.add(
                Name99Item(
                    number = o.getInt("number"),
                    arabic = o.getString("arabic"),
                    transliteration = o.getString("transliteration"),
                    english = o.getString("english"),
                    urdu = o.getString("urdu"),
                    explanation = o.getString("explanation"),
                    audioUrl = optNullableString(o, "audioUrl"),
                    audioSourceNote = optNullableString(o, "audioSourceNote")
                )
            )
        }

        val duaCatsArr = root.getJSONArray("duaCategories")
        val duaCategories = ArrayList<String>(duaCatsArr.length())
        for (i in 0 until duaCatsArr.length()) duaCategories.add(duaCatsArr.getString(i))

        val duasArr = root.getJSONArray("duas")
        val duas = ArrayList<DuaEntry>(duasArr.length())
        for (i in 0 until duasArr.length()) {
            val o = duasArr.getJSONObject(i)
            duas.add(
                DuaEntry(
                    id = o.getString("id"),
                    category = o.getString("category"),
                    title = o.getString("title"),
                    titleUr = o.optString("titleUr", ""),
                    arabic = o.getString("arabic"),
                    transliteration = o.optString("transliteration", ""),
                    english = o.getString("english"),
                    urdu = o.optString("urdu", ""),
                    reference = o.optString("reference", ""),
                    audioUrl = optNullableString(o, "audioUrl"),
                    audioSourceNote = optNullableString(o, "audioSourceNote")
                )
            )
        }

        val azkarCatsArr = root.getJSONArray("azkarCategories")
        val azkarCategories = ArrayList<String>(azkarCatsArr.length())
        for (i in 0 until azkarCatsArr.length()) azkarCategories.add(azkarCatsArr.getString(i))

        val azkarArr = root.getJSONArray("azkar")
        val azkar = ArrayList<ZikrEntry>(azkarArr.length())
        for (i in 0 until azkarArr.length()) {
            val o = azkarArr.getJSONObject(i)
            azkar.add(
                ZikrEntry(
                    id = o.getString("id"),
                    category = o.getString("category"),
                    title = o.getString("title"),
                    titleUr = o.optString("titleUr", ""),
                    arabic = o.getString("arabic"),
                    transliteration = o.optString("transliteration", ""),
                    english = o.getString("english"),
                    urdu = o.optString("urdu", ""),
                    repeatCount = o.optInt("repeatCount", 1),
                    reference = o.optString("reference", ""),
                    audioUrl = optNullableString(o, "audioUrl"),
                    audioSourceNote = optNullableString(o, "audioSourceNote")
                )
            )
        }

        val dhikrArr = root.getJSONArray("dhikrPresets")
        val dhikrs = ArrayList<DhikrPresetItem>(dhikrArr.length())
        for (i in 0 until dhikrArr.length()) {
            val o = dhikrArr.getJSONObject(i)
            dhikrs.add(
                DhikrPresetItem(
                    id = o.getString("id"),
                    arabic = o.getString("arabic"),
                    transliteration = o.getString("transliteration"),
                    meaning = o.getString("meaning"),
                    defaultTarget = o.optInt("defaultTarget", 33),
                    audioUrl = optNullableString(o, "audioUrl"),
                    audioSourceNote = optNullableString(o, "audioSourceNote")
                )
            )
        }

        val remArr = root.getJSONArray("dailyReminders")
        val reminders = ArrayList<DailyReminderItem>(remArr.length())
        for (i in 0 until remArr.length()) {
            val o = remArr.getJSONObject(i)
            reminders.add(
                DailyReminderItem(
                    title = o.getString("title"),
                    body = o.getString("body"),
                    bodyUr = o.optString("bodyUr", ""),
                    reference = o.optString("reference", "")
                )
            )
        }

        val seerahArr = root.getJSONArray("seerahArticles")
        val seerah = ArrayList<SeerahArticleItem>(seerahArr.length())
        for (i in 0 until seerahArr.length()) {
            val o = seerahArr.getJSONObject(i)
            val contentArr = o.getJSONArray("content")
            val paras = ArrayList<String>(contentArr.length())
            for (j in 0 until contentArr.length()) paras.add(contentArr.getString(j))
            seerah.add(
                SeerahArticleItem(
                    id = o.getString("id"),
                    section = o.getString("section"),
                    title = o.getString("title"),
                    period = o.optString("period", ""),
                    summary = o.getString("summary"),
                    summaryUr = o.optString("summaryUr", ""),
                    content = paras,
                    reference = o.optString("reference", ""),
                    takeaway = o.optString("takeaway", "")
                )
            )
        }

        val learnArr = root.getJSONArray("learningLessons")
        val lessons = ArrayList<LearningLessonItem>(learnArr.length())
        for (i in 0 until learnArr.length()) {
            val o = learnArr.getJSONObject(i)
            val stepsArr = o.getJSONArray("steps")
            val steps = ArrayList<LearningStepItem>(stepsArr.length())
            for (j in 0 until stepsArr.length()) {
                val s = stepsArr.getJSONObject(j)
                steps.add(
                    LearningStepItem(
                        heading = s.getString("heading"),
                        arabic = optNullableString(s, "arabic"),
                        transliteration = optNullableString(s, "transliteration"),
                        detail = s.getString("detail"),
                        audioUrl = optNullableString(s, "audioUrl"),
                        audioSourceNote = optNullableString(s, "audioSourceNote")
                    )
                )
            }
            lessons.add(
                LearningLessonItem(
                    id = o.getString("id"),
                    module = o.getString("module"),
                    title = o.getString("title"),
                    summary = o.getString("summary"),
                    summaryUr = o.optString("summaryUr", ""),
                    steps = steps,
                    scholarlyDifferenceNote = optNullableString(o, "scholarlyDifferenceNote"),
                    reference = o.optString("reference", "")
                )
            )
        }

        val quizCatsArr = root.optJSONArray("quizCategories")
        val quizCategories = ArrayList<String>(quizCatsArr?.length() ?: 0)
        if (quizCatsArr != null) {
            for (i in 0 until quizCatsArr.length()) quizCategories.add(quizCatsArr.getString(i))
        }

        val quizArr = root.optJSONArray("quizQuestions")
        val quizQuestions = ArrayList<QuizQuestionItem>(quizArr?.length() ?: 0)
        if (quizArr != null) {
            for (i in 0 until quizArr.length()) {
                val q = quizArr.getJSONObject(i)
                val optsArr = q.getJSONArray("options")
                val opts = ArrayList<String>(optsArr.length())
                for (j in 0 until optsArr.length()) opts.add(optsArr.getString(j))
                quizQuestions.add(
                    QuizQuestionItem(
                        id = q.getString("id"),
                        category = q.getString("category"),
                        difficulty = q.optString("difficulty", "Easy"),
                        question = q.getString("question"),
                        options = opts,
                        correctIndex = q.getInt("correctIndex"),
                        explanation = q.optString("explanation", ""),
                        reference = q.optString("reference", "")
                    )
                )
            }
        }

        val parsed = AllSectionsData(
            asmaUlHusna = names,
            duaCategories = duaCategories,
            duas = duas,
            azkarCategories = azkarCategories,
            azkar = azkar,
            dhikrPresets = dhikrs,
            dailyReminders = reminders,
            seerahArticles = seerah,
            learningLessons = lessons,
            quizCategories = quizCategories,
            quizQuestions = quizQuestions
        )
        cached = parsed
        return parsed
    }
}
