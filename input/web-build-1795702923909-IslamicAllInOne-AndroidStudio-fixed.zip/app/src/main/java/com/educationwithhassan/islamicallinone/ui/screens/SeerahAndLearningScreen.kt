package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.islamicallinone.ads.AdManager
import com.educationwithhassan.islamicallinone.ads.NativeAdFeedCard
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.EducationalTtsManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.data.AllSectionsRepository

@Composable
fun SeerahAndLearningScreen(
    adManager: AdManager,
    audioManager: AudioPlayerManager,
    ttsManager: EducationalTtsManager,
    isAudioPlaying: Boolean,
    initialSectionTab: Int = 0, // 0 = Seerah & History, 1 = Learning Center, 2 = Tasbeeh & Dhikr
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val data = remember { AllSectionsRepository.load(context) }
    var activeSubTab by remember(initialSectionTab) { mutableIntStateOf(initialSectionTab) }
    var tasbeehCount by remember { mutableIntStateOf(0) }
    var selectedDhikrIndex by remember { mutableIntStateOf(0) }

    val audioState by audioManager.uiState.collectAsState()
    val ttsState by ttsManager.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Seerah, Lessons & Dhikr Audio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Authentic Arabic step audio + clearly labeled Text-to-Speech guides", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(8.dp))

        TabRow(selectedTabIndex = activeSubTab) {
            Tab(selected = activeSubTab == 0, onClick = { activeSubTab = 0 }, text = { Text("Seerah") })
            Tab(selected = activeSubTab == 1, onClick = { activeSubTab = 1 }, text = { Text("Learning") })
            Tab(selected = activeSubTab == 2, onClick = { activeSubTab = 2 }, text = { Text("Tasbeeh") })
        }
        Spacer(Modifier.height(8.dp))

        when (activeSubTab) {
            0 -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.RecordVoiceOver, null)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Audio Note: Seerah & Islamic History narration uses Text-to-Speech (not an authentic studio recording).",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                    items(data.seerahArticles, key = { it.id }) { article ->
                        val enId = "${article.id}_en"
                        val urId = "${article.id}_ur"
                        val isEnActive = ttsState.isActive && ttsState.trackId == enId
                        val isUrActive = ttsState.isActive && ttsState.trackId == urId
                        val fullEn = "${article.title}. ${article.summary}. ${article.content.joinToString(" ")}. Key Takeaway: ${article.takeaway}"

                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("${article.section} · ${article.period}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(article.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(article.summary, style = MaterialTheme.typography.bodyMedium)
                                if (article.summaryUr.isNotBlank()) {
                                    Text(article.summaryUr, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            when {
                                                isEnActive && ttsState.isSpeaking -> ttsManager.pause()
                                                isEnActive && ttsState.isPaused -> ttsManager.resume()
                                                else -> ttsManager.speak(enId, article.title, fullEn, isUrdu = false)
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(if (isEnActive && ttsState.isSpeaking) Icons.Default.Pause else Icons.Default.RecordVoiceOver, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            when {
                                                isEnActive && ttsState.isSpeaking -> "Pause EN"
                                                isEnActive && ttsState.isPaused -> "Resume EN"
                                                else -> "Listen EN (TTS)"
                                            },
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            when {
                                                isUrActive && ttsState.isSpeaking -> ttsManager.pause()
                                                isUrActive && ttsState.isPaused -> ttsManager.resume()
                                                else -> ttsManager.speak(urId, "${article.title} (Urdu)", article.summaryUr.ifBlank { article.summary }, isUrdu = true)
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            when {
                                                isUrActive && ttsState.isSpeaking -> "Pause UR"
                                                isUrActive && ttsState.isPaused -> "Resume UR"
                                                else -> "Urdu (TTS)"
                                            },
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                    if (isEnActive || isUrActive) {
                                        IconButton(onClick = { ttsManager.stop() }) {
                                            Icon(Icons.Default.Stop, contentDescription = "Stop")
                                        }
                                    }
                                }
                                if (isEnActive || isUrActive) {
                                    Text(
                                        "Text-to-Speech Narration (not an authentic recording) · Section ${ttsState.chunkIndex}/${ttsState.totalChunks}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                    item {
                        NativeAdFeedCard(
                            adManager = adManager,
                            isVisible = !isAudioPlaying,
                            placement = "seerah_feed"
                        )
                    }
                }
            }
            1 -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.RecordVoiceOver, null)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Arabic verses & step supplications use verified recordings. Full lesson explanations use labeled Text-to-Speech.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                    items(data.learningLessons, key = { it.id }) { lesson ->
                        val enId = "${lesson.id}_en"
                        val urId = "${lesson.id}_ur"
                        val isEnActive = ttsState.isActive && ttsState.trackId == enId
                        val isUrActive = ttsState.isActive && ttsState.trackId == urId
                        val fullEn = "${lesson.title}. ${lesson.summary}. " + lesson.steps.joinToString(". ") { "${it.heading}: ${it.detail}" }

                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(lesson.module, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(lesson.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(lesson.summary, style = MaterialTheme.typography.bodyMedium)
                                if (lesson.summaryUr.isNotBlank()) {
                                    Text(lesson.summaryUr, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        when {
                                            isEnActive && ttsState.isSpeaking -> ttsManager.pause()
                                            isEnActive && ttsState.isPaused -> ttsManager.resume()
                                            else -> ttsManager.speak(enId, lesson.title, fullEn, isUrdu = false)
                                        }
                                    }) {
                                        Text(if (isEnActive && ttsState.isSpeaking) "Pause Guide (TTS)" else "Listen Guide (TTS EN)", style = MaterialTheme.typography.labelMedium)
                                    }
                                    OutlinedButton(onClick = {
                                        when {
                                            isUrActive && ttsState.isSpeaking -> ttsManager.pause()
                                            isUrActive && ttsState.isPaused -> ttsManager.resume()
                                            else -> ttsManager.speak(urId, "${lesson.title} (Urdu)", lesson.summaryUr.ifBlank { lesson.summary }, isUrdu = true)
                                        }
                                    }) {
                                        Text(if (isUrActive && ttsState.isSpeaking) "Pause UR" else "Urdu (TTS)", style = MaterialTheme.typography.labelMedium)
                                    }
                                    if (isEnActive || isUrActive) {
                                        IconButton(onClick = { ttsManager.stop() }) {
                                            Icon(Icons.Default.Stop, contentDescription = "Stop")
                                        }
                                    }
                                }

                                lesson.steps.forEachIndexed { idx, step ->
                                    val stepTrackId = "${lesson.id}_step_${idx}"
                                    val isThisStep = audioState.mode == PlaybackModeState.TRACK && audioState.trackId == stepTrackId
                                    val stepLoading = isThisStep && audioState.isLoading
                                    val stepPlaying = isThisStep && audioState.isPlaying
                                    val stepPaused = isThisStep && !audioState.isPlaying && !audioState.isLoading && audioState.errorMessage == null

                                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
                                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(step.heading, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                                if (step.audioUrl != null) {
                                                    Row {
                                                        OutlinedButton(
                                                            onClick = {
                                                                when {
                                                                    stepLoading -> Unit
                                                                    stepPlaying -> audioManager.pause()
                                                                    stepPaused -> audioManager.resume()
                                                                    else -> audioManager.playTrack(
                                                                        title = step.heading,
                                                                        subtitle = step.audioSourceNote ?: "Verified Arabic Recitation",
                                                                        audioUrl = step.audioUrl,
                                                                        trackId = stepTrackId
                                                                    )
                                                                }
                                                            },
                                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                                        ) {
                                                            Text(
                                                                when {
                                                                    stepLoading -> "Loading..."
                                                                    stepPlaying -> "Pause"
                                                                    stepPaused -> "Resume"
                                                                    else -> "Play Arabic"
                                                                },
                                                                style = MaterialTheme.typography.labelSmall
                                                            )
                                                        }
                                                        if (isThisStep) {
                                                            IconButton(onClick = { audioManager.stop() }, modifier = Modifier.size(32.dp)) {
                                                                Icon(Icons.Default.Stop, null, modifier = Modifier.size(16.dp))
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (!step.arabic.isNullOrBlank()) {
                                                Text(step.arabic, fontSize = 19.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                                            }
                                            Text(step.detail, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        NativeAdFeedCard(
                            adManager = adManager,
                            isVisible = !isAudioPlaying,
                            placement = "learning_feed"
                        )
                    }
                }
            }
            else -> {
                val activePreset = data.dhikrPresets[selectedDhikrIndex.coerceIn(0, data.dhikrPresets.lastIndex)]
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(activePreset.arabic, fontSize = 24.sp, textAlign = TextAlign.Center)
                            Text(activePreset.transliteration, fontWeight = FontWeight.Bold)
                            Text("${tasbeehCount} / ${activePreset.defaultTarget}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { tasbeehCount += 1 }) { Text("Tap +1") }
                                OutlinedButton(onClick = { tasbeehCount = 0 }) { Text("Reset") }
                            }
                        }
                    }

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                        items(data.dhikrPresets.size) { index ->
                            val preset = data.dhikrPresets[index]
                            val isThis = audioState.mode == PlaybackModeState.TRACK && audioState.trackId == preset.id
                            val isLoading = isThis && audioState.isLoading
                            val isPlaying = isThis && audioState.isPlaying
                            val isPaused = isThis && !audioState.isPlaying && !audioState.isLoading && audioState.errorMessage == null

                            Card(
                                onClick = { selectedDhikrIndex = index },
                                border = if (index == selectedDhikrIndex) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                            ) {
                                Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(preset.transliteration, fontWeight = FontWeight.Bold)
                                        Text(preset.meaning, style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (preset.audioUrl != null) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Button(
                                                onClick = {
                                                    when {
                                                        isLoading -> Unit
                                                        isPlaying -> audioManager.pause()
                                                        isPaused -> audioManager.resume()
                                                        else -> audioManager.playTrack(
                                                            title = preset.transliteration,
                                                            subtitle = preset.audioSourceNote ?: "Hisn al-Muslim Verified Recording",
                                                            audioUrl = preset.audioUrl,
                                                            trackId = preset.id
                                                        )
                                                    }
                                                },
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text(
                                                    when {
                                                        isLoading -> "Loading"
                                                        isPlaying -> "Pause"
                                                        isPaused -> "Resume"
                                                        else -> "Play"
                                                    },
                                                    style = MaterialTheme.typography.labelSmall
                                                )
                                            }
                                            if (isThis) {
                                                IconButton(onClick = { audioManager.stop() }) {
                                                    Icon(Icons.Default.Stop, null)
                                                }
                                            }
                                        }
                                    } else {
                                        Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant) {
                                            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.VolumeOff, null, modifier = Modifier.size(14.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Unavailable", style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
