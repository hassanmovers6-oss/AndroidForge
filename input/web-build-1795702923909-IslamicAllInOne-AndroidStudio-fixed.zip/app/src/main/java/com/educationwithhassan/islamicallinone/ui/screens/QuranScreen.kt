package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.islamicallinone.audio.AudioDownloadManager
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.audio.QariCatalog
import com.educationwithhassan.islamicallinone.audio.RepeatModeState
import com.educationwithhassan.islamicallinone.data.QuranAssetRepository
import com.educationwithhassan.islamicallinone.data.SurahData
import kotlinx.coroutines.launch

@Composable
fun QuranScreen(
    audioManager: AudioPlayerManager,
    downloadManager: AudioDownloadManager
) {
    val context = LocalContext.current
    val surahs = remember { QuranAssetRepository.loadAllSurahs(context) }
    var selectedSurah by remember { mutableStateOf<SurahData?>(null) }
    var showQariMenu by remember { mutableStateOf(false) }

    val audioState by audioManager.uiState.collectAsState()
    val downloadProgress by downloadManager.progress.collectAsState()
    val downloadedKeys by downloadManager.downloadedKeys.collectAsState()
    val scope = rememberCoroutineScope()

    if (selectedSurah == null) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "Holy Quran — 114 Surahs",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { showQariMenu = true }) {
                    Text("Qari: ${QariCatalog.findById(audioState.qariId).name}")
                }
                DropdownMenu(expanded = showQariMenu, onDismissRequest = { showQariMenu = false }) {
                    QariCatalog.VERIFIED_QARIS.forEach { qari ->
                        DropdownMenuItem(
                            text = { Text("${qari.name} (${qari.bitrate}kbps)") },
                            onClick = {
                                audioManager.setQari(qari.id)
                                showQariMenu = false
                            }
                        )
                    }
                }
            }
            items(surahs, key = { it.number }) { surah ->
                val isPlayingThisSurah =
                    audioState.surahNumber == surah.number && audioState.mode == PlaybackModeState.FULL_SURAH && audioState.isPlaying
                Card(
                    onClick = { selectedSurah = surah },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${surah.number}. ${surah.englishName}", fontWeight = FontWeight.Bold)
                            Text(
                                "${surah.revelationType} · ${surah.ayahCount} Ayahs",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = {
                            if (isPlayingThisSurah) audioManager.pause()
                            else audioManager.playFullSurah(surah, 0)
                        }) {
                            Icon(
                                if (isPlayingThisSurah) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play Full Surah"
                            )
                        }
                    }
                }
            }
        }
    } else {
        val surah = selectedSurah!!
        val listState = rememberLazyListState()
        val activeHere = audioState.surahNumber == surah.number && audioState.mode != PlaybackModeState.IDLE
        val isDownloaded = downloadedKeys.contains("${audioState.qariId}:${surah.number}")

        LaunchedEffect(audioState.currentAyahNumber, activeHere) {
            if (activeHere && audioState.currentAyahNumber > 0) {
                listState.animateScrollToItem(audioState.currentAyahNumber)
            }
        }

        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selectedSurah = null }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("${surah.number}. ${surah.englishName}", fontWeight = FontWeight.Bold)
                    Text("${surah.name} · ${surah.ayahCount} Ayahs", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = {
                    if (isDownloaded) {
                        downloadManager.deleteSurah(surah.number, audioState.qariId)
                    } else {
                        scope.launch { downloadManager.downloadSurah(surah, audioState.qariId) }
                    }
                }) {
                    Icon(Icons.Default.Download, contentDescription = "Download Surah")
                }
            }

            downloadProgress?.takeIf { it.surahNumber == surah.number }?.let { prog ->
                Text(
                    "Downloading offline audio: ${prog.completed} / ${prog.total}",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            if (activeHere && audioState.mode == PlaybackModeState.FULL_SURAH) {
                                if (audioState.isPlaying) audioManager.pause() else audioManager.resume()
                            } else {
                                audioManager.playFullSurah(surah, 0)
                            }
                        }) {
                            Icon(if (activeHere && audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                            Text(if (activeHere && audioState.isPlaying) " Pause" else " Play Full Surah")
                        }
                        if (activeHere) {
                            IconButton(onClick = { audioManager.prevAyah() }) { Icon(Icons.Default.SkipPrevious, "Prev") }
                            IconButton(onClick = { audioManager.nextAyah() }) { Icon(Icons.Default.SkipNext, "Next") }
                            IconButton(onClick = { audioManager.stop() }) { Icon(Icons.Default.Stop, "Stop") }
                        }
                    }

                    if (activeHere) {
                        Text(
                            "Ayah ${audioState.currentAyahNumber} / ${audioState.totalAyahs} · ${QariCatalog.findById(audioState.qariId).name}",
                            style = MaterialTheme.typography.labelMedium
                        )
                        if (audioState.durationMs > 0L) {
                            Slider(
                                value = audioState.positionMs.toFloat(),
                                onValueChange = { audioManager.seekTo(it.toLong()) },
                                valueRange = 0f..audioState.durationMs.toFloat().coerceAtLeast(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { audioManager.cycleRepeatMode() }) {
                                Icon(Icons.Default.Repeat, null)
                                Text(
                                    when (audioState.repeatMode) {
                                        RepeatModeState.OFF -> " Repeat: Off"
                                        RepeatModeState.AYAH -> " Repeat Ayah"
                                        RepeatModeState.SURAH -> " Repeat Surah"
                                    }
                                )
                            }
                            OutlinedButton(onClick = {
                                val nextSpeed = when (audioState.playbackSpeed) {
                                    1.0f -> 1.25f
                                    1.25f -> 1.5f
                                    1.5f -> 0.75f
                                    else -> 1.0f
                                }
                                audioManager.setPlaybackSpeed(nextSpeed)
                            }) {
                                Text("${audioState.playbackSpeed}x")
                            }
                        }
                    }
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(surah.ayahs, key = { _, a -> a.n }) { index, ayah ->
                    val isCurrentAyah = activeHere && audioState.currentAyahNumber == ayah.n
                    Card(
                        border = if (isCurrentAyah) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${surah.number}:${ayah.n}", fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = { audioManager.playSingleAyah(surah, index) }) {
                                        Text("Play Ayah")
                                    }
                                    OutlinedButton(onClick = { audioManager.playFullSurah(surah, index) }) {
                                        Text("From Here")
                                    }
                                }
                            }
                            Text(
                                ayah.ar,
                                fontSize = 24.sp,
                                lineHeight = 40.sp,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(ayah.en, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
