package com.educationwithhassan.islamicallinone.audio

import android.content.Context
import android.net.Uri
import com.educationwithhassan.islamicallinone.data.SurahData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class DownloadProgressState(
    val surahNumber: Int,
    val qariId: String,
    val completed: Int,
    val total: Int
)

class AudioDownloadManager(private val context: Context) {
    private val rootDir = File(context.filesDir, "quran_audio")

    private val _progress = MutableStateFlow<DownloadProgressState?>(null)
    val progress: StateFlow<DownloadProgressState?> = _progress.asStateFlow()

    private val _downloadedKeys = MutableStateFlow<Set<String>>(emptySet())
    val downloadedKeys: StateFlow<Set<String>> = _downloadedKeys.asStateFlow()

    private var activeJob: Job? = null

    init {
        refreshDownloadedKeys()
    }

    fun getLocalAyahFile(qariId: String, surahNumber: Int, ayahNumber: Int): File {
        val dir = File(File(rootDir, qariId), "surah_${surahNumber}")
        return File(dir, "ayah_${ayahNumber}.mp3")
    }

    fun getPlayableUri(qariId: String, surahNumber: Int, ayahNumber: Int, globalAyah: Int): Pair<Uri, Boolean> {
        val localFile = getLocalAyahFile(qariId, surahNumber, ayahNumber)
        return if (localFile.exists() && localFile.length() > 0L) {
            Uri.fromFile(localFile) to true
        } else {
            Uri.parse(QariCatalog.buildAyahAudioUrl(qariId, globalAyah)) to false
        }
    }

    fun refreshDownloadedKeys() {
        val keys = mutableSetOf<String>()
        if (rootDir.exists()) {
            rootDir.listFiles()?.forEach { qariDir ->
                if (qariDir.isDirectory) {
                    qariDir.listFiles()?.forEach { surahDir ->
                        if (surahDir.isDirectory && surahDir.name.startsWith("surah_")) {
                            val surahNum = surahDir.name.removePrefix("surah_").toIntOrNull()
                            val mp3Count = surahDir.listFiles()?.count { it.extension == "mp3" && it.length() > 0L } ?: 0
                            if (surahNum != null && mp3Count > 0) {
                                keys.add("${qariDir.name}:${surahNum}")
                            }
                        }
                    }
                }
            }
        }
        _downloadedKeys.value = keys
    }

    suspend fun downloadSurah(surah: SurahData, qariId: String) = withContext(Dispatchers.IO) {
        val targetDir = File(File(rootDir, qariId), "surah_${surah.number}")
        if (!targetDir.exists()) targetDir.mkdirs()

        val total = surah.ayahs.size
        var completed = 0
        _progress.value = DownloadProgressState(surah.number, qariId, 0, total)

        try {
            for (ayah in surah.ayahs) {
                if (!isActive) throw CancellationException("Cancelled")
                val outFile = getLocalAyahFile(qariId, surah.number, ayah.n)
                if (!outFile.exists() || outFile.length() == 0L) {
                    val tempFile = File(targetDir, "ayah_${ayah.n}.tmp")
                    val conn = (URL(QariCatalog.buildAyahAudioUrl(qariId, ayah.g)).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000
                        readTimeout = 20000
                    }
                    conn.inputStream.use { input ->
                        tempFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    tempFile.renameTo(outFile)
                }
                completed += 1
                _progress.value = DownloadProgressState(surah.number, qariId, completed, total)
            }
            refreshDownloadedKeys()
        } finally {
            _progress.value = null
        }
    }

    fun deleteSurah(surahNumber: Int, qariId: String) {
        val dir = File(File(rootDir, qariId), "surah_${surahNumber}")
        if (dir.exists()) {
            dir.deleteRecursively()
        }
        refreshDownloadedKeys()
    }
}
