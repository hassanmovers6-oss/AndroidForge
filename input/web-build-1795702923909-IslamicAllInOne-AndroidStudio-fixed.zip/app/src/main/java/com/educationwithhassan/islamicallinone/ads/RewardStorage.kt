package com.educationwithhassan.islamicallinone.ads

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RewardLocalState(
    val selectedThemeId: String = "aurora",
    val decorativeAccent: Boolean = false,
    val unlockedThemesUntil: Long = 0L,
    val unlockedCustomizationUntil: Long = 0L,
    val dailyBonusDate: String = "",
    val knowledgePoints: Int = 0,
    val quizHintsCount: Int = 1,
    val bonusPracticeUnlocked: Boolean = false,
    val lastRewardToken: String = ""
) {
    fun areThemesUnlocked(nowMs: Long = System.currentTimeMillis()): Boolean = unlockedThemesUntil > nowMs
    fun isCustomizationUnlocked(nowMs: Long = System.currentTimeMillis()): Boolean = unlockedCustomizationUntil > nowMs
    fun isDailyBonusClaimedToday(): Boolean = dailyBonusDate == RewardStorage.todayKey()
}

class RewardStorage(context: Context) {
    private val prefs = context.getSharedPreferences("islamic_rewards_prefs", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(readState())
    val state: StateFlow<RewardLocalState> = _state.asStateFlow()

    companion object {
        private const val TWENTY_FOUR_HOURS_MS = 86_400_000L
        fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private fun readState(): RewardLocalState {
        return RewardLocalState(
            selectedThemeId = prefs.getString("selectedThemeId", "aurora") ?: "aurora",
            decorativeAccent = prefs.getBoolean("decorativeAccent", false),
            unlockedThemesUntil = prefs.getLong("unlockedThemesUntil", 0L),
            unlockedCustomizationUntil = prefs.getLong("unlockedCustomizationUntil", 0L),
            dailyBonusDate = prefs.getString("dailyBonusDate", "") ?: "",
            knowledgePoints = prefs.getInt("knowledgePoints", 0),
            quizHintsCount = prefs.getInt("quizHintsCount", 1),
            bonusPracticeUnlocked = prefs.getBoolean("bonusPracticeUnlocked", false),
            lastRewardToken = prefs.getString("lastRewardToken", "") ?: ""
        )
    }

    private fun updateAndPersist(next: RewardLocalState) {
        prefs.edit()
            .putString("selectedThemeId", next.selectedThemeId)
            .putBoolean("decorativeAccent", next.decorativeAccent)
            .putLong("unlockedThemesUntil", next.unlockedThemesUntil)
            .putLong("unlockedCustomizationUntil", next.unlockedCustomizationUntil)
            .putString("dailyBonusDate", next.dailyBonusDate)
            .putInt("knowledgePoints", next.knowledgePoints)
            .putInt("quizHintsCount", next.quizHintsCount)
            .putBoolean("bonusPracticeUnlocked", next.bonusPracticeUnlocked)
            .putString("lastRewardToken", next.lastRewardToken)
            .apply()
        _state.value = next
    }

    fun selectTheme(themeId: String) {
        val cur = _state.value
        if (themeId != "aurora" && !cur.areThemesUnlocked()) return
        updateAndPersist(cur.copy(selectedThemeId = themeId))
    }

    fun useDefaultThemeFree() {
        updateAndPersist(_state.value.copy(selectedThemeId = "aurora", decorativeAccent = false))
    }

    fun setDecorativeAccent(enabled: Boolean) {
        val cur = _state.value
        if (enabled && !cur.isCustomizationUnlocked()) return
        updateAndPersist(cur.copy(decorativeAccent = enabled))
    }

    fun grantThemeAndCustomizationReward(rewardToken: String): Boolean {
        val cur = _state.value
        if (rewardToken.isBlank() || rewardToken == cur.lastRewardToken) return false
        val expiry = System.currentTimeMillis() + TWENTY_FOUR_HOURS_MS
        updateAndPersist(
            cur.copy(
                unlockedThemesUntil = expiry,
                unlockedCustomizationUntil = expiry,
                lastRewardToken = rewardToken
            )
        )
        return true
    }

    fun claimDailyBonusReward(rewardToken: String): Boolean {
        val cur = _state.value
        val today = todayKey()
        if (rewardToken.isBlank() || rewardToken == cur.lastRewardToken) return false
        if (cur.dailyBonusDate == today) return false
        updateAndPersist(
            cur.copy(
                dailyBonusDate = today,
                knowledgePoints = cur.knowledgePoints + 25,
                lastRewardToken = rewardToken
            )
        )
        return true
    }

    fun grantQuizReward(rewardToken: String): Boolean {
        val cur = _state.value
        if (rewardToken.isBlank() || rewardToken == cur.lastRewardToken) return false
        updateAndPersist(
            cur.copy(
                quizHintsCount = cur.quizHintsCount + 2,
                bonusPracticeUnlocked = true,
                lastRewardToken = rewardToken
            )
        )
        return true
    }

    fun consumeQuizHint(): Boolean {
        val cur = _state.value
        if (cur.quizHintsCount <= 0) return false
        updateAndPersist(cur.copy(quizHintsCount = cur.quizHintsCount - 1))
        return true
    }
}
