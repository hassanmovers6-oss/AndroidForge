package com.educationwithhassan.islamicallinone.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val id: String,
    val type: String,
    val title: String,
    val subtitle: String,
    val arabic: String?,
    val body: String,
    val reference: String,
    val savedAtEpoch: Long
)

@Entity(tableName = "tasbeeh_sessions")
data class TasbeehSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dhikrTitle: String,
    val count: Int,
    val target: Int,
    val createdAtEpoch: Long
)

@Dao
interface IslamicDao {
    @Query("SELECT * FROM bookmarks ORDER BY savedAtEpoch DESC")
    fun observeBookmarks(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBookmark(item: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: String)

    @Query("SELECT * FROM tasbeeh_sessions ORDER BY createdAtEpoch DESC LIMIT 30")
    fun observeTasbeehSessions(): Flow<List<TasbeehSessionEntity>>

    @Insert
    suspend fun insertTasbeehSession(session: TasbeehSessionEntity)
}

@Database(
    entities = [BookmarkEntity::class, TasbeehSessionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class IslamicDatabase : RoomDatabase() {
    abstract fun islamicDao(): IslamicDao
}
