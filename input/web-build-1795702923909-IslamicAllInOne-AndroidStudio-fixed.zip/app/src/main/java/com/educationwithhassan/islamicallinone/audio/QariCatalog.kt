package com.educationwithhassan.islamicallinone.audio

data class QariInfo(
    val id: String,
    val name: String,
    val arabicName: String,
    val style: String,
    val bitrate: Int
)

object QariCatalog {
    val VERIFIED_QARIS: List<QariInfo> = listOf(
        QariInfo("ar.alafasy", "Mishary Rashid Alafasy", "مشاري راشد العفاسي", "Murattal", 128),
        QariInfo("ar.abdulbasitmurattal", "Abdul Basit Abdul Samad", "عبد الباسط عبد الصمد", "Murattal", 192),
        QariInfo("ar.abdurrahmaansudais", "Abdur-Rahman as-Sudais", "عبد الرحمن السديس", "Murattal", 64),
        QariInfo("ar.husary", "Mahmoud Khalil Al-Husary", "محمود خليل الحصري", "Murattal", 128),
        QariInfo("ar.minshawi", "Mohamed Siddiq Al-Minshawi", "محمد صديق المنشاوي", "Murattal", 128),
        QariInfo("ar.hudhaify", "Ali Al-Hudhaify", "علي الحذيفي", "Murattal", 128),
        QariInfo("ar.mahermuaiqly", "Maher Al-Muaiqly", "ماهر المعيقلي", "Murattal", 128),
        QariInfo("ar.shaatree", "Abu Bakr ash-Shatri", "أبو بكر الشاطري", "Murattal", 128),
        QariInfo("ar.ahmedajamy", "Ahmad ibn Ali al-Ajamy", "أحمد العجمي", "Murattal", 128)
    )

    fun findById(id: String): QariInfo {
        return VERIFIED_QARIS.firstOrNull { it.id == id } ?: VERIFIED_QARIS.first()
    }

    fun buildAyahAudioUrl(qariId: String, globalAyahNumber: Int): String {
        val qari = findById(qariId)
        return "https://cdn.islamic.network/quran/audio/${qari.bitrate}/${qari.id}/${globalAyahNumber}.mp3"
    }
}
