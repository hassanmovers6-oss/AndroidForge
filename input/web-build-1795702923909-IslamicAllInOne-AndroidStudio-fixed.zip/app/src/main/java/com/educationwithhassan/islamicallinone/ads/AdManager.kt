package com.educationwithhassan.islamicallinone.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.educationwithhassan.islamicallinone.BuildConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Centralized Google AdMob manager supporting all 5 formats with strict religious-content respect:
 * - Production IDs from BuildConfig (exact verified units) + Official Google Test IDs toggle for QA.
 * - Never displays ads inside Quran, Hadith, Dua reading screens, Qibla Compass, or prayer alerts.
 * - Never interrupts active Quran/Hadith/Dua/Azkar/99 Names/TTS audio playback.
 * - Enforces 120s Interstitial cooldown, 45s post-App-Open protection, and no overlapping full-screen ads.
 * - Splash App Open guarantees a 3-second maximum timeout so users are never trapped offline.
 * - Rewarded ads strictly require SDK OnUserEarnedRewardListener confirmation with duplicate-grant guards.
 */
class AdManager(private val context: Context) {

    companion object {
        private const val TAG = "AdMobManager"
        const val GOOGLE_TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
        const val GOOGLE_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
        const val GOOGLE_TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
        const val GOOGLE_TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
        const val GOOGLE_TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
        const val GOOGLE_TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"

        private const val INTERSTITIAL_COOLDOWN_MS = 120_000L
        private const val POST_APP_OPEN_INTERSTITIAL_GUARD_MS = 45_000L
        private const val APP_OPEN_FOREGROUND_COOLDOWN_MS = 240_000L
        private const val APP_OPEN_FRESHNESS_MAX_MS = 14_400_000L
        private const val SPLASH_APP_OPEN_TIMEOUT_MS = 3_000L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val _testModeEnabled = MutableStateFlow(BuildConfig.ADMOB_USE_TEST_IDS)
    val testModeEnabled: StateFlow<Boolean> = _testModeEnabled.asStateFlow()

    private val _debugLogs = MutableStateFlow<List<String>>(emptyList())
    val debugLogs: StateFlow<List<String>> = _debugLogs.asStateFlow()

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadedAt = 0L

    private var isLoadingInterstitial = false
    private var isLoadingRewarded = false
    private var isLoadingAppOpen = false

    private var interstitialRetryCount = 0
    private var rewardedRetryCount = 0
    private var appOpenRetryCount = 0

    @Volatile
    private var isFullScreenAdShowing = false
    private var lastInterstitialShownAt = 0L
    private var lastAppOpenShownAt = 0L
    private var lastAppOpenDismissedAt = 0L

    fun activeBannerUnitId(): String =
        if (_testModeEnabled.value) GOOGLE_TEST_BANNER_ID else BuildConfig.ADMOB_BANNER_ID

    fun activeInterstitialUnitId(): String =
        if (_testModeEnabled.value) GOOGLE_TEST_INTERSTITIAL_ID else BuildConfig.ADMOB_INTERSTITIAL_ID

    fun activeRewardedUnitId(): String =
        if (_testModeEnabled.value) GOOGLE_TEST_REWARDED_ID else BuildConfig.ADMOB_REWARDED_ID

    fun activeNativeUnitId(): String =
        if (_testModeEnabled.value) GOOGLE_TEST_NATIVE_ID else BuildConfig.ADMOB_NATIVE_ID

    fun activeAppOpenUnitId(): String =
        if (_testModeEnabled.value) GOOGLE_TEST_APP_OPEN_ID else BuildConfig.ADMOB_APP_OPEN_ID

    fun logEvent(eventType: String, detail: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val entry = "[$time] $eventType · $detail"
        Log.d(TAG, entry)
        _debugLogs.value = (listOf(entry) + _debugLogs.value).take(40)
    }

    fun initialize() {
        MobileAds.initialize(context) {
            logEvent("INITIALIZED", "MobileAds SDK ready (testMode=${_testModeEnabled.value})")
            preloadAll()
        }
    }

    fun registerTestDeviceIds(deviceIds: List<String>) {
        val config = RequestConfiguration.Builder()
            .setTestDeviceIds(deviceIds)
            .build()
        MobileAds.setRequestConfiguration(config)
        logEvent("TEST_DEVICES", "Registered ${deviceIds.size} test device IDs")
    }

    fun setTestMode(enabled: Boolean) {
        if (_testModeEnabled.value == enabled) return
        _testModeEnabled.value = enabled
        interstitialAd = null
        rewardedAd = null
        appOpenAd = null
        isLoadingInterstitial = false
        isLoadingRewarded = false
        isLoadingAppOpen = false
        logEvent("MODE_SWITCH", if (enabled) "Switched to Google Official Test IDs" else "Switched to Exact Production IDs")
        preloadAll()
    }

    fun preloadAll() {
        preloadInterstitial()
        preloadRewarded()
        preloadAppOpen()
    }

    fun createAdaptiveBanner(activity: Activity, widthDp: Int): AdView {
        val unitId = activeBannerUnitId()
        return AdView(activity).apply {
            adUnitId = unitId
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp))
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    logEvent("LOADED", "Banner unit=$unitId")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    logEvent("FAILED", "Banner unit=$unitId code=${error.code} msg=${error.message}")
                }

                override fun onAdOpened() {
                    logEvent("DISPLAYED", "Banner opened")
                }

                override fun onAdClosed() {
                    logEvent("DISMISSED", "Banner closed")
                }
            }
            logEvent("REQUESTED", "Banner unit=$unitId widthDp=$widthDp")
            loadAd(AdRequest.Builder().build())
        }
    }

    fun preloadInterstitial() {
        if (interstitialAd != null || isLoadingInterstitial) return
        isLoadingInterstitial = true
        val unitId = activeInterstitialUnitId()
        logEvent("REQUESTED", "Interstitial unit=$unitId")
        InterstitialAd.load(
            context,
            unitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    isLoadingInterstitial = false
                    interstitialRetryCount = 0
                    interstitialAd = ad
                    logEvent("LOADED", "Interstitial ready unit=$unitId")
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    isLoadingInterstitial = false
                    interstitialAd = null
                    logEvent("FAILED", "Interstitial load failed code=${err.code} msg=${err.message}")
                    if (interstitialRetryCount < 3) {
                        interstitialRetryCount += 1
                        mainHandler.postDelayed({ preloadInterstitial() }, 15_000L * interstitialRetryCount)
                    }
                }
            }
        )
    }

    fun showInterstitialIfEligible(
        activity: Activity,
        isSacredScreen: Boolean,
        isAudioPlaying: Boolean = false,
        placement: String = "natural_transition",
        onContinue: () -> Unit = {}
    ) {
        if (isSacredScreen || isAudioPlaying || isFullScreenAdShowing) {
            onContinue()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastAppOpenDismissedAt < POST_APP_OPEN_INTERSTITIAL_GUARD_MS) {
            onContinue()
            return
        }
        if (now - lastInterstitialShownAt < INTERSTITIAL_COOLDOWN_MS) {
            onContinue()
            return
        }
        val ad = interstitialAd
        if (ad == null) {
            preloadInterstitial()
            onContinue()
            return
        }
        isFullScreenAdShowing = true
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                logEvent("DISPLAYED", "Interstitial ($placement)")
            }

            override fun onAdDismissedFullScreenContent() {
                isFullScreenAdShowing = false
                interstitialAd = null
                logEvent("DISMISSED", "Interstitial ($placement)")
                preloadInterstitial()
                onContinue()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isFullScreenAdShowing = false
                interstitialAd = null
                logEvent("FAILED", "Interstitial show failed ($placement): ${error.message}")
                preloadInterstitial()
                onContinue()
            }
        }
        lastInterstitialShownAt = now
        ad.show(activity)
    }

    fun preloadRewarded() {
        if (rewardedAd != null || isLoadingRewarded) return
        isLoadingRewarded = true
        val unitId = activeRewardedUnitId()
        logEvent("REQUESTED", "Rewarded unit=$unitId")
        RewardedAd.load(
            context,
            unitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    isLoadingRewarded = false
                    rewardedRetryCount = 0
                    rewardedAd = ad
                    logEvent("LOADED", "Rewarded ready unit=$unitId")
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    isLoadingRewarded = false
                    rewardedAd = null
                    logEvent("FAILED", "Rewarded load failed code=${err.code} msg=${err.message}")
                    if (rewardedRetryCount < 3) {
                        rewardedRetryCount += 1
                        mainHandler.postDelayed({ preloadRewarded() }, 15_000L * rewardedRetryCount)
                    }
                }
            }
        )
    }

    fun showRewardedAd(
        activity: Activity,
        placement: String,
        isAudioPlaying: Boolean = false,
        onAdUnavailable: (String) -> Unit,
        onDismissedWithoutReward: () -> Unit = {},
        onRewardEarned: (rewardToken: String) -> Unit
    ) {
        if (isAudioPlaying) {
            onAdUnavailable("Pause audio playback before watching an optional rewarded ad.")
            return
        }
        if (isFullScreenAdShowing) {
            onAdUnavailable("Another screen prompt is active. Please try again.")
            return
        }
        val ad = rewardedAd
        if (ad == null) {
            logEvent("FAILED", "Rewarded unavailable for $placement; preloading")
            preloadRewarded()
            onAdUnavailable("Ad unavailable right now. Please try again shortly or continue without the ad.")
            return
        }

        var rewardEarned = false
        var rewardDelivered = false
        isFullScreenAdShowing = true

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                logEvent("DISPLAYED", "Rewarded ($placement)")
            }

            override fun onAdDismissedFullScreenContent() {
                isFullScreenAdShowing = false
                rewardedAd = null
                logEvent("DISMISSED", "Rewarded ($placement) earned=$rewardEarned")
                preloadRewarded()
                if (!rewardEarned) {
                    onDismissedWithoutReward()
                }
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isFullScreenAdShowing = false
                rewardedAd = null
                logEvent("FAILED", "Rewarded show failed ($placement): ${error.message}")
                preloadRewarded()
                onAdUnavailable("Ad unavailable right now. Please continue without the ad.")
            }
        }

        ad.show(activity) { rewardItem ->
            rewardEarned = true
            if (!rewardDelivered) {
                rewardDelivered = true
                val token = "${placement}_${System.currentTimeMillis()}"
                logEvent("REWARDED", "Rewarded ($placement) type=${rewardItem.type} amount=${rewardItem.amount}")
                onRewardEarned(token)
            }
        }
    }

    fun loadNativeAd(
        placement: String,
        onLoaded: (NativeAd) -> Unit,
        onFailed: (String) -> Unit
    ) {
        val unitId = activeNativeUnitId()
        logEvent("REQUESTED", "Native ($placement) unit=$unitId")
        val loader = AdLoader.Builder(context, unitId)
            .forNativeAd { nativeAd ->
                logEvent("LOADED", "Native ($placement) ready")
                onLoaded(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(err: LoadAdError) {
                    logEvent("FAILED", "Native ($placement) failed code=${err.code} msg=${err.message}")
                    onFailed(err.message)
                }

                override fun onAdOpened() {
                    logEvent("DISPLAYED", "Native ($placement) opened")
                }

                override fun onAdClosed() {
                    logEvent("DISMISSED", "Native ($placement) closed")
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()
        loader.loadAd(AdRequest.Builder().build())
    }

    fun preloadAppOpen() {
        if (appOpenAd != null || isLoadingAppOpen) return
        isLoadingAppOpen = true
        val unitId = activeAppOpenUnitId()
        logEvent("REQUESTED", "AppOpen unit=$unitId")
        AppOpenAd.load(
            context,
            unitId,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    isLoadingAppOpen = false
                    appOpenRetryCount = 0
                    appOpenAd = ad
                    appOpenLoadedAt = System.currentTimeMillis()
                    logEvent("LOADED", "AppOpen ready unit=$unitId")
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    isLoadingAppOpen = false
                    appOpenAd = null
                    logEvent("FAILED", "AppOpen load failed code=${err.code} msg=${err.message}")
                    if (appOpenRetryCount < 3) {
                        appOpenRetryCount += 1
                        mainHandler.postDelayed({ preloadAppOpen() }, 20_000L * appOpenRetryCount)
                    }
                }
            }
        )
    }

    private fun isAppOpenValid(): Boolean {
        val ad = appOpenAd ?: return false
        val ageMs = System.currentTimeMillis() - appOpenLoadedAt
        if (ageMs >= APP_OPEN_FRESHNESS_MAX_MS) {
            appOpenAd = null
            return false
        }
        return ad != null
    }

    fun loadAndShowSplashAppOpen(
        activity: Activity,
        isAudioPlaying: Boolean = false,
        onFinished: () -> Unit
    ) {
        val completed = AtomicBoolean(false)
        fun finishOnce() {
            if (completed.compareAndSet(false, true)) {
                onFinished()
            }
        }

        val timeoutRunnable = Runnable {
            logEvent("DISMISSED", "Splash AppOpen 3s timeout -> continuing immediately")
            finishOnce()
        }
        mainHandler.postDelayed(timeoutRunnable, SPLASH_APP_OPEN_TIMEOUT_MS)

        if (isAudioPlaying || isFullScreenAdShowing) {
            mainHandler.removeCallbacks(timeoutRunnable)
            finishOnce()
            return
        }

        if (isAppOpenValid()) {
            mainHandler.removeCallbacks(timeoutRunnable)
            showAppOpenInternal(activity, "cold_splash") { finishOnce() }
            return
        }

        val unitId = activeAppOpenUnitId()
        logEvent("REQUESTED", "Splash AppOpen unit=$unitId")
        AppOpenAd.load(
            context,
            unitId,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    appOpenLoadedAt = System.currentTimeMillis()
                    logEvent("LOADED", "Splash AppOpen ready")
                    if (completed.get()) return
                    mainHandler.removeCallbacks(timeoutRunnable)
                    showAppOpenInternal(activity, "cold_splash") { finishOnce() }
                }

                override fun onAdFailedToLoad(err: LoadAdError) {
                    logEvent("FAILED", "Splash AppOpen failed code=${err.code}")
                    mainHandler.removeCallbacks(timeoutRunnable)
                    finishOnce()
                }
            }
        )
    }

    fun showAppOpenOnForeground(activity: Activity, isAudioPlaying: Boolean = false) {
        val now = System.currentTimeMillis()
        if (isAudioPlaying || isFullScreenAdShowing) return
        if (now - lastAppOpenShownAt < APP_OPEN_FOREGROUND_COOLDOWN_MS) return
        if (!isAppOpenValid()) {
            preloadAppOpen()
            return
        }
        showAppOpenInternal(activity, "foreground_return") {}
    }

    private fun showAppOpenInternal(
        activity: Activity,
        source: String,
        onComplete: () -> Unit
    ) {
        val ad = appOpenAd
        if (ad == null || isFullScreenAdShowing) {
            onComplete()
            return
        }
        isFullScreenAdShowing = true
        lastAppOpenShownAt = System.currentTimeMillis()
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                logEvent("DISPLAYED", "AppOpen ($source)")
            }

            override fun onAdDismissedFullScreenContent() {
                isFullScreenAdShowing = false
                appOpenAd = null
                lastAppOpenDismissedAt = System.currentTimeMillis()
                logEvent("DISMISSED", "AppOpen ($source)")
                preloadAppOpen()
                onComplete()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isFullScreenAdShowing = false
                appOpenAd = null
                logEvent("FAILED", "AppOpen show failed ($source): ${error.message}")
                preloadAppOpen()
                onComplete()
            }
        }
        ad.show(activity)
    }
}
