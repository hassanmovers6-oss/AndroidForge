package com.educationwithhassan.islamicallinone.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

data class HadithCollectionMeta(
    val id: String,
    val title: String,
    val compiler: String,
    val bundledCount: Int,
    val totalInCollection: Int
)

data class HadithItemData(
    val n: Int,
    val bookNum: Int,
    val chapter: String,
    val ar: String,
    val en: String,
    val ur: String,
    val grades: List<String>,
    val ref: String
)

data class HadithCollectionData(
    val id: String,
    val title: String,
    val compiler: String,
    val totalInCollection: Int,
    val bundledCount: Int,
    val source: String,
    val hadiths: List<HadithItemData>
)

object HadithAssetRepository {
    @Volatile
    private var indexCache: List<HadithCollectionMeta>? = null
    private val bookCache = ConcurrentHashMap<String, HadithCollectionData>()

    fun loadIndex(context: Context): List<HadithCollectionMeta> {
        indexCache?.let { return it }
        val jsonText = context.assets.open("data/hadith/index.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(jsonText)
        val result = ArrayList<HadithCollectionMeta>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            result.add(
                HadithCollectionMeta(
                    id = obj.getString("id"),
                    title = obj.getString("title"),
                    compiler = obj.getString("compiler"),
                    bundledCount = obj.getInt("bundledCount"),
                    totalInCollection = obj.getInt("totalInCollection")
                )
            )
        }
        indexCache = result
        return result
    }

    fun loadBook(context: Context, bookId: String): HadithCollectionData {
        bookCache[bookId]?.let { return it }
        val safeId = bookId.replace(Regex("[^a-zA-Z0-9_-]"), "")
        val jsonText = context.assets.open("data/hadith/${safeId}.json").bufferedReader().use { it.readText() }
        val obj = JSONObject(jsonText)
        val hadithsArr = obj.getJSONArray("hadiths")
        val hadiths = ArrayList<HadithItemData>(hadithsArr.length())
        for (i in 0 until hadithsArr.length()) {
            val h = hadithsArr.getJSONObject(i)
            val gradesArr = h.optJSONArray("grades")
            val grades = ArrayList<String>(gradesArr?.length() ?: 0)
            if (gradesArr != null) {
                for (g in 0 until gradesArr.length()) {
                    grades.add(gradesArr.getString(g))
                }
            }
            hadiths.add(
                HadithItemData(
                    n = h.getInt("n"),
                    bookNum = h.optInt("bookNum", 1),
                    chapter = h.optString("chapter", ""),
                    ar = h.optString("ar", ""),
                    en = h.optString("en", ""),
                    ur = h.optString("ur", ""),
                    grades = grades,
                    ref = h.optString("ref", "${obj.getString("title")} ${h.getInt("n")}")
                )
            )
        }
        val parsed = HadithCollectionData(
            id = obj.getString("id"),
            title = obj.getString("title"),
            compiler = obj.getString("compiler"),
            totalInCollection = obj.optInt("totalInCollection", hadiths.size),
            bundledCount = obj.optInt("bundledCount", hadiths.size),
            source = obj.optString("source", ""),
            hadiths = hadiths
        )
        bookCache[bookId] = parsed
        return parsed
    }
}
