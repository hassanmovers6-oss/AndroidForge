package com.educationwithhassan.islamicallinone.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class IslamicThemeMeta(val id: String, val label: String, val isFree: Boolean)

val ISLAMIC_THEME_OPTIONS = listOf(
    IslamicThemeMeta("aurora", "Aurora Sanctuary (Default Free)", isFree = true),
    IslamicThemeMeta("emerald", "Madinah Emerald", isFree = false),
    IslamicThemeMeta("ocean", "Royal Sapphire", isFree = false),
    IslamicThemeMeta("golden", "Golden Dome", isFree = false),
    IslamicThemeMeta("ramadan", "Ramadan Twilight", isFree = false),
    IslamicThemeMeta("pastel", "Soft Pastel Blossom", isFree = false),
    IslamicThemeMeta("dark", "Night Qiyam Dark", isFree = false)
)

@Composable
fun IslamicAuroraTheme(
    themeId: String = "aurora",
    decorativeAccent: Boolean = false,
    content: @Composable () -> Unit
) {
    val tertiaryAccent = if (decorativeAccent) Color(0xFFB45309) else Color(0xFFD97706)
    val scheme = when (themeId) {
        "emerald" -> lightColorScheme(
            primary = Color(0xFF047857),
            secondary = Color(0xFF0F766E),
            tertiary = tertiaryAccent,
            background = Color(0xFFECFDF5),
            surface = Color(0xFFFFFFFF)
        )
        "ocean" -> lightColorScheme(
            primary = Color(0xFF1D4ED8),
            secondary = Color(0xFF0284C7),
            tertiary = tertiaryAccent,
            background = Color(0xFFEFF6FF),
            surface = Color(0xFFFFFFFF)
        )
        "golden" -> lightColorScheme(
            primary = Color(0xFFB45309),
            secondary = Color(0xFF059669),
            tertiary = Color(0xFF0369A1),
            background = Color(0xFFFFFBEB),
            surface = Color(0xFFFFFFFF)
        )
        "ramadan" -> darkColorScheme(
            primary = Color(0xFFA78BFA),
            secondary = Color(0xFF34D399),
            tertiary = Color(0xFFFBBF24),
            background = Color(0xFF1E1B4B),
            surface = Color(0xFF2E2A63)
        )
        "pastel" -> lightColorScheme(
            primary = Color(0xFFDB2777),
            secondary = Color(0xFF0D9488),
            tertiary = tertiaryAccent,
            background = Color(0xFFFDF2F8),
            surface = Color(0xFFFFFFFF)
        )
        "dark" -> darkColorScheme(
            primary = Color(0xFF34D399),
            secondary = Color(0xFF60A5FA),
            tertiary = Color(0xFFFBBF24),
            background = Color(0xFF0B131E),
            surface = Color(0xFF15202E)
        )
        else -> lightColorScheme(
            primary = Color(0xFF059669),
            secondary = Color(0xFF1D4ED8),
            tertiary = tertiaryAccent,
            background = Color(0xFFF3F9F7),
            surface = Color(0xFFFFFFFF)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
