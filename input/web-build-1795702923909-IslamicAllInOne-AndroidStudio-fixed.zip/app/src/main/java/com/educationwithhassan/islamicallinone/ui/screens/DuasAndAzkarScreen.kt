package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.data.AllSectionsRepository

private fun formatDuaDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "${m}:${s.toString().padStart(2, '0')}"
}

@Composable
fun DuasAndAzkarScreen(
    audioManager: AudioPlayerManager,
    initialModeTab: Int = 0
) {
    val context = LocalContext.current
    val data = remember { AllSectionsRepository.load(context) }
    var subTab by remember(initialModeTab) { mutableIntStateOf(initialModeTab) } // 0 = Azkar, 1 = Duas
    var selectedAzkarCat by remember { mutableStateOf("All") }
    var selectedDuaCat by remember { mutableStateOf("All") }
    var search by remember { mutableStateOf("") }
    val audioState by audioManager.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Duas & Daily Azkar (Hisn al-Muslim)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        TabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Azkar (${data.azkar.size})") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Duas (${data.duas.size})") })
        }

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text(if (subTab == 0) "Search Morning, Evening, After Salah Azkar..." else "Search Duas...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        val cats = if (subTab == 0) listOf("All") + data.azkarCategories else listOf("All") + data.duaCategories
        val activeCat = if (subTab == 0) selectedAzkarCat else selectedDuaCat

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { cat ->
                FilterChip(
                    selected = activeCat == cat,
                    onClick = { if (subTab == 0) selectedAzkarCat = cat else selectedDuaCat = cat },
                    label = { Text(cat) }
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        val q = search.trim().lowercase()
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            if (subTab == 0) {
                val filteredAzkar = data.azkar.filter { item ->
                    val catOk = selectedAzkarCat == "All" || item.category == selectedAzkarCat
                    val qOk = q.isEmpty() || item.title.lowercase().contains(q) || item.english.lowercase().contains(q) || item.arabic.contains(search.trim()) || item.category.lowercase().contains(q)
                    catOk && qOk
                }
                items(filteredAzkar, key = { it.id }) { item ->
                    AudioSupplicationCard(
                        trackId = item.id,
                        category = "${item.category} · Repeat ${item.repeatCount}x",
                        title = item.title,
                        arabic = item.arabic,
                        transliteration = item.transliteration,
                        english = item.english,
                        urdu = item.urdu,
                        reference = item.reference,
                        audioUrl = item.audioUrl,
                        audioSourceNote = item.audioSourceNote,
                        audioState = audioState,
                        audioManager = audioManager
                    )
                }
            } else {
                val filteredDuas = data.duas.filter { item ->
                    val catOk = selectedDuaCat == "All" || item.category == selectedDuaCat
                    val qOk = q.isEmpty() || item.title.lowercase().contains(q) || item.english.lowercase().contains(q) || item.arabic.contains(search.trim()) || item.category.lowercase().contains(q)
                    catOk && qOk
                }
                items(filteredDuas, key = { it.id }) { item ->
                    AudioSupplicationCard(
                        trackId = item.id,
                        category = item.category,
                        title = item.title,
                        arabic = item.arabic,
                        transliteration = item.transliteration,
                        english = item.english,
                        urdu = item.urdu,
                        reference = item.reference,
                        audioUrl = item.audioUrl,
                        audioSourceNote = item.audioSourceNote,
                        audioState = audioState,
                        audioManager = audioManager
                    )
                }
            }
        }
    }
}

@Composable
private fun AudioSupplicationCard(
    trackId: String,
    category: String,
    title: String,
    arabic: String,
    transliteration: String,
    english: String,
    urdu: String,
    reference: String,
    audioUrl: String?,
    audioSourceNote: String?,
    audioState: com.educationwithhassan.islamicallinone.audio.AudioUiState,
    audioManager: AudioPlayerManager
) {
    val isThis = audioState.mode == PlaybackModeState.TRACK && audioState.trackId == trackId
    val isLoading = isThis && audioState.isLoading
    val isPlaying = isThis && audioState.isPlaying
    val isPaused = isThis && !audioState.isPlaying && !audioState.isLoading && audioState.errorMessage == null

    Card(
        modifier = Modifier.fillMaxWidth(),
        border = if (isThis) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }
                if (audioUrl != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                when {
                                    isLoading -> Unit
                                    isPlaying -> audioManager.pause()
                                    isPaused -> audioManager.resume()
                                    else -> audioManager.playTrack(
                                        title = title,
                                        subtitle = audioSourceNote ?: "Hisn al-Muslim Verified Recording",
                                        audioUrl = audioUrl,
                                        trackId = trackId
                                    )
                                }
                            },
                            enabled = !isLoading,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            when {
                                isLoading -> {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Loading", style = MaterialTheme.typography.labelMedium)
                                }
                                isPlaying -> {
                                    Icon(Icons.Default.Pause, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Pause", style = MaterialTheme.typography.labelMedium)
                                }
                                isPaused -> {
                                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Resume", style = MaterialTheme.typography.labelMedium)
                                }
                                else -> {
                                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Play Arabic", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                        if (isThis) {
                            IconButton(onClick = { audioManager.stop() }) {
                                Icon(Icons.Default.Stop, contentDescription = "Stop")
                            }
                        }
                    }
                } else {
                    Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant) {
                        Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeOff, null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Audio unavailable", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            if (isThis) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (audioState.isLoading) "Loading Arabic recitation..." else (audioSourceNote ?: "Arabic Recitation"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text("${formatDuaDuration(audioState.positionMs)} / ${formatDuaDuration(audioState.durationMs)}", style = MaterialTheme.typography.labelSmall)
                        }
                        if (audioState.errorMessage != null) {
                            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(audioState.errorMessage!!, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                OutlinedButton(onClick = { audioManager.retry() }) {
                                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Retry")
                                }
                            }
                        } else if (audioState.durationMs > 0L) {
                            Slider(
                                value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                                onValueChange = { audioManager.seekTo(it.toLong()) },
                                valueRange = 0f..audioState.durationMs.toFloat()
                            )
                        }
                    }
                }
            }

            Text(arabic, fontSize = 21.sp, lineHeight = 35.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
            if (transliteration.isNotBlank()) {
                Text(transliteration, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(english, style = MaterialTheme.typography.bodyMedium)
            if (urdu.isNotBlank()) {
                Text(urdu, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
            }
            Text(reference, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
