package com.educationwithhassan.islamicallinone.data

import android.content.Context
import org.json.JSONArray

data class AyahData(
    val n: Int,
    val g: Int,
    val ar: String,
    val en: String,
    val ur: String
)

data class SurahData(
    val number: Int,
    val name: String,
    val englishName: String,
    val englishNameTranslation: String,
    val revelationType: String,
    val ayahCount: Int,
    val ayahs: List<AyahData>
)

object QuranAssetRepository {
    @Volatile
    private var cached: List<SurahData>? = null

    fun loadAllSurahs(context: Context): List<SurahData> {
        cached?.let { return it }
        val jsonText = context.assets.open("data/quran-full.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(jsonText)
        val result = ArrayList<SurahData>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val ayahsArr = obj.getJSONArray("ayahs")
            val ayahs = ArrayList<AyahData>(ayahsArr.length())
            for (j in 0 until ayahsArr.length()) {
                val a = ayahsArr.getJSONObject(j)
                ayahs.add(
                    AyahData(
                        n = a.getInt("n"),
                        g = a.getInt("g"),
                        ar = a.getString("ar"),
                        en = a.getString("en"),
                        ur = a.optString("ur", "")
                    )
                )
            }
            result.add(
                SurahData(
                    number = obj.getInt("number"),
                    name = obj.getString("name"),
                    englishName = obj.getString("englishName"),
                    englishNameTranslation = obj.getString("englishNameTranslation"),
                    revelationType = obj.getString("revelationType"),
                    ayahCount = obj.getInt("ayahCount"),
                    ayahs = ayahs
                )
            )
        }
        cached = result
        return result
    }
}
