package com.educationwithhassan.islamicallinone.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

@Composable
fun AdaptiveBannerBar(
    adManager: AdManager,
    isVisible: Boolean,
    screenTag: String
) {
    if (!isVisible) return

    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() } ?: return
    val widthDp = LocalConfiguration.current.screenWidthDp.coerceAtLeast(320)
    val useTestIds by adManager.testModeEnabled.collectAsState()
    val lifecycleOwner = LocalLifecycleOwner.current

    val adView = remember(screenTag, useTestIds, widthDp) {
        adManager.createAdaptiveBanner(activity, widthDp)
    }

    DisposableEffect(adView, lifecycleOwner) {
        val handler = Handler(Looper.getMainLooper())
        var retryCount = 0
        val retryRunnable = Runnable {
            if (retryCount < 2) {
                retryCount += 1
                adView.loadAd(AdRequest.Builder().build())
            }
        }

        val existingListener = adView.adListener
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() { existingListener.onAdLoaded() }
            override fun onAdFailedToLoad(err: LoadAdError) {
                existingListener.onAdFailedToLoad(err)
                handler.postDelayed(retryRunnable, 20_000L)
            }
            override fun onAdOpened() { existingListener.onAdOpened() }
            override fun onAdClosed() { existingListener.onAdClosed() }
        }

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> adView.resume()
                Lifecycle.Event.ON_PAUSE -> adView.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            handler.removeCallbacks(retryRunnable)
            lifecycleOwner.lifecycle.removeObserver(observer)
            adView.destroy()
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    ) {
        Box(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), contentAlignment = Alignment.Center) {
            AndroidView(factory = { adView }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun NativeAdFeedCard(
    adManager: AdManager,
    isVisible: Boolean,
    placement: String
) {
    if (!isVisible) return

    val useTestIds by adManager.testModeEnabled.collectAsState()
    var nativeAd by remember(placement, useTestIds) { mutableStateOf<NativeAd?>(null) }

    LaunchedEffect(placement, useTestIds) {
        adManager.loadNativeAd(
            placement = placement,
            onLoaded = { loaded ->
                nativeAd?.destroy()
                nativeAd = loaded
            },
            onFailed = { /* graceful no-fill hide */ }
        )
    }

    DisposableEffect(nativeAd) {
        val current = nativeAd
        onDispose { current?.destroy() }
    }

    val loaded = nativeAd ?: return
    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            factory = { ctx ->
                val adView = NativeAdView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }
                val container = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }

                val badge = TextView(ctx).apply {
                    text = "Ad · Sponsored"
                    textSize = 10f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(AndroidColor.parseColor("#92400E"))
                    background = GradientDrawable().apply {
                        setColor(AndroidColor.parseColor("#FEF3C7"))
                        cornerRadius = 12f
                    }
                    setPadding(16, 4, 16, 4)
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = 10 }
                }

                val headerRow = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val iconView = ImageView(ctx).apply {
                    layoutParams = LinearLayout.LayoutParams(96, 96).apply { marginEnd = 24 }
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }
                val textCol = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                val headlineView = TextView(ctx).apply {
                    textSize = 15f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(AndroidColor.parseColor("#0F172A"))
                }
                val advertiserView = TextView(ctx).apply {
                    textSize = 11f
                    setTextColor(AndroidColor.parseColor("#64748B"))
                }
                textCol.addView(headlineView)
                textCol.addView(advertiserView)
                headerRow.addView(iconView)
                headerRow.addView(textCol)

                val bodyView = TextView(ctx).apply {
                    textSize = 13f
                    setTextColor(AndroidColor.parseColor("#334155"))
                    setPadding(0, 14, 0, 16)
                }
                val ctaButton = Button(ctx).apply {
                    isAllCaps = false
                    setBackgroundColor(AndroidColor.parseColor("#059669"))
                    setTextColor(AndroidColor.WHITE)
                }

                container.addView(badge)
                container.addView(headerRow)
                container.addView(bodyView)
                container.addView(ctaButton)
                adView.addView(container)

                adView.headlineView = headlineView
                adView.bodyView = bodyView
                adView.iconView = iconView
                adView.advertiserView = advertiserView
                adView.callToActionView = ctaButton
                adView
            },
            update = { adView ->
                (adView.headlineView as? TextView)?.text = loaded.headline ?: ""
                val bodyTv = adView.bodyView as? TextView
                if (loaded.body != null) {
                    bodyTv?.visibility = View.VISIBLE
                    bodyTv?.text = loaded.body
                } else {
                    bodyTv?.visibility = View.GONE
                }
                val advTv = adView.advertiserView as? TextView
                if (loaded.advertiser != null) {
                    advTv?.visibility = View.VISIBLE
                    advTv?.text = loaded.advertiser
                } else {
                    advTv?.visibility = View.GONE
                }
                val iconIv = adView.iconView as? ImageView
                if (loaded.icon != null) {
                    iconIv?.visibility = View.VISIBLE
                    iconIv?.setImageDrawable(loaded.icon?.drawable)
                } else {
                    iconIv?.visibility = View.GONE
                }
                val ctaBtn = adView.callToActionView as? Button
                if (loaded.callToAction != null) {
                    ctaBtn?.visibility = View.VISIBLE
                    ctaBtn?.text = loaded.callToAction
                } else {
                    ctaBtn?.visibility = View.GONE
                }
                adView.setNativeAd(loaded)
            }
        )
    }
}

@Composable
fun RewardedOfferCard(
    title: String,
    description: String,
    rewardBadge: String,
    placement: String,
    adManager: AdManager,
    isAudioPlaying: Boolean,
    alreadyGrantedLabel: String? = null,
    onRewardGranted: (rewardToken: String) -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var isLoadingAd by remember { mutableStateOf(false) }
    var unavailableMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var dismissed by remember { mutableStateOf(false) }

    if (dismissed && alreadyGrantedLabel == null && successMessage == null) return

    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Optional Reward · $rewardBadge", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                }
            }
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (alreadyGrantedLabel != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(alreadyGrantedLabel, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            } else {
                unavailableMessage?.let { msg ->
                    Text(msg, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                }
                successMessage?.let { msg ->
                    Text(msg, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        enabled = !isLoadingAd && activity != null && !isAudioPlaying,
                        onClick = {
                            val act = activity ?: return@Button
                            unavailableMessage = null
                            isLoadingAd = true
                            adManager.showRewardedAd(
                                activity = act,
                                placement = placement,
                                isAudioPlaying = isAudioPlaying,
                                onAdUnavailable = { reason ->
                                    isLoadingAd = false
                                    unavailableMessage = reason
                                },
                                onDismissedWithoutReward = {
                                    isLoadingAd = false
                                    unavailableMessage = "Video was closed before completion. No reward was granted."
                                },
                                onRewardEarned = { token ->
                                    isLoadingAd = false
                                    successMessage = "Reward unlocked! JazakAllahu Khayran."
                                    onRewardGranted(token)
                                }
                            )
                        }
                    ) {
                        if (isLoadingAd) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(6.dp))
                            Text("Loading Ad...")
                        } else {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Watch Ad")
                        }
                    }
                    OutlinedButton(onClick = { dismissed = true }) {
                        Text("Not Now")
                    }
                }
            }
        }
    }
}
