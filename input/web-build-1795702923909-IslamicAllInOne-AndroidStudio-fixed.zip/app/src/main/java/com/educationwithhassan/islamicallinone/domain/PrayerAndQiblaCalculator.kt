package com.educationwithhassan.islamicallinone.domain

import com.batoulapps.adhan2.CalculationMethod
import com.batoulapps.adhan2.Coordinates
import com.batoulapps.adhan2.Madhab
import com.batoulapps.adhan2.PrayerTimes
import com.batoulapps.adhan2.Qibla
import com.batoulapps.adhan2.data.DateComponents
import java.util.Calendar

data class DailyPrayerSchedule(
    val fajrEpochMs: Long,
    val sunriseEpochMs: Long,
    val dhuhrEpochMs: Long,
    val asrEpochMs: Long,
    val maghribEpochMs: Long,
    val ishaEpochMs: Long,
    val qiblaDegrees: Double
)

object PrayerAndQiblaCalculator {
    fun calculate(
        latitude: Double,
        longitude: Double,
        method: CalculationMethod = CalculationMethod.MUSLIM_WORLD_LEAGUE,
        madhab: Madhab = Madhab.SHAFI
    ): DailyPrayerSchedule {
        val cal = Calendar.getInstance()
        val date = DateComponents(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
        val coords = Coordinates(latitude, longitude)
        val params = method.parameters.copy(madhab = madhab)
        val times = PrayerTimes(coords, date, params)
        val qibla = Qibla(coords)
        return DailyPrayerSchedule(
            fajrEpochMs = times.fajr.toEpochMilliseconds(),
            sunriseEpochMs = times.sunrise.toEpochMilliseconds(),
            dhuhrEpochMs = times.dhuhr.toEpochMilliseconds(),
            asrEpochMs = times.asr.toEpochMilliseconds(),
            maghribEpochMs = times.maghrib.toEpochMilliseconds(),
            ishaEpochMs = times.isha.toEpochMilliseconds(),
            qiblaDegrees = qibla.direction
        )
    }
}
