package com.educationwithhassan.islamicallinone.audio

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.educationwithhassan.islamicallinone.data.SurahData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class RepeatModeState { OFF, AYAH, SURAH }
enum class PlaybackModeState { IDLE, FULL_SURAH, SINGLE_AYAH, TRACK }

data class AudioUiState(
    val mode: PlaybackModeState = PlaybackModeState.IDLE,
    val isPlaying: Boolean = false,
    val isLoading: Boolean = false,
    val qariId: String = "ar.alafasy",
    val surahNumber: Int = 0,
    val surahName: String = "",
    val currentAyahNumber: Int = 0,
    val totalAyahs: Int = 0,
    val trackId: String = "",
    val trackTitle: String = "",
    val trackSubtitle: String = "",
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val repeatMode: RepeatModeState = RepeatModeState.OFF,
    val playbackSpeed: Float = 1.0f,
    val isOfflineSource: Boolean = false,
    val errorMessage: String? = null,
    val unavailableNotice: String? = null
)

class AudioPlayerManager(
    private val context: Context,
    private val downloadManager: AudioDownloadManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null
    private var activeSurah: SurahData? = null
    private var startOffsetInSurah: Int = 0

    var onBeforeMediaPlay: (() -> Unit)? = null

    private val _uiState = MutableStateFlow(AudioUiState())
    val uiState: StateFlow<AudioUiState> = _uiState.asStateFlow()

    fun connect() {
        if (controller != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val mc = future.get()
            controller = mc
            attachListeners(mc)
            startProgressTicker()
        }, ContextCompat.getMainExecutor(context))
    }

    private fun attachListeners(mc: MediaController) {
        mc.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(
                    isPlaying = isPlaying,
                    isLoading = mc.playbackState == Player.STATE_BUFFERING,
                    errorMessage = if (isPlaying) null else _uiState.value.errorMessage
                )
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                val endedTrack = playbackState == Player.STATE_ENDED && _uiState.value.mode == PlaybackModeState.TRACK
                _uiState.value = _uiState.value.copy(
                    isLoading = playbackState == Player.STATE_BUFFERING,
                    isPlaying = if (endedTrack) false else _uiState.value.isPlaying,
                    positionMs = if (endedTrack) 0L else _uiState.value.positionMs,
                    durationMs = mc.duration.coerceAtLeast(0L),
                    errorMessage = if (playbackState == Player.STATE_READY) null else _uiState.value.errorMessage
                )
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                syncCurrentIndex(mc)
            }

            override fun onPlayerError(error: PlaybackException) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isPlaying = false,
                    errorMessage = "Audio playback failed. Check connection or tap Retry."
                )
            }
        })
    }

    private fun syncCurrentIndex(mc: MediaController) {
        val surah = activeSurah ?: return
        val idx = startOffsetInSurah + mc.currentMediaItemIndex
        val ayah = surah.ayahs.getOrNull(idx) ?: return
        val offline = mediaItemOfflineFlag(mc.currentMediaItem)
        _uiState.value = _uiState.value.copy(
            currentAyahNumber = ayah.n,
            totalAyahs = surah.ayahCount,
            isOfflineSource = offline,
            durationMs = mc.duration.coerceAtLeast(0L)
        )
    }

    private fun mediaItemOfflineFlag(item: MediaItem?): Boolean {
        return item?.mediaMetadata?.extras?.getBoolean("isOffline", false) == true
    }

    private fun startProgressTicker() {
        scope.launch {
            while (isActive) {
                val mc = controller
                if (mc != null && _uiState.value.mode != PlaybackModeState.IDLE) {
                    _uiState.value = _uiState.value.copy(
                        positionMs = mc.currentPosition.coerceAtLeast(0L),
                        durationMs = mc.duration.coerceAtLeast(0L)
                    )
                }
                delay(400L)
            }
        }
    }

    /**
     * Plays EVERY Ayah in the selected Surah continuously in a single Media3 sequential playlist.
     * Never stops after a single Ayah; advances automatically through the final Ayah.
     */
    fun playFullSurah(surah: SurahData, startIndex: Int = 0, qariOverride: String? = null) {
        onBeforeMediaPlay?.invoke()
        val mc = controller ?: return
        val qari = qariOverride ?: _uiState.value.qariId
        activeSurah = surah
        startOffsetInSurah = startIndex.coerceIn(0, (surah.ayahs.size - 1).coerceAtLeast(0))

        val qariInfo = QariCatalog.findById(qari)
        val mediaItems = surah.ayahs.drop(startOffsetInSurah).map { ayah ->
            val (uri, isOffline) = downloadManager.getPlayableUri(qari, surah.number, ayah.n, ayah.g)
            val extras = Bundle().apply { putBoolean("isOffline", isOffline) }
            val metadata = MediaMetadata.Builder()
                .setTitle("${surah.englishName} · Ayah ${ayah.n} / ${surah.ayahCount}")
                .setArtist(qariInfo.name)
                .setAlbumTitle("Holy Quran — Full Surah Playback")
                .setExtras(extras)
                .build()
            MediaItem.Builder()
                .setMediaId("quran_${qari}_${surah.number}_${ayah.n}")
                .setUri(uri)
                .setMediaMetadata(metadata)
                .build()
        }

        if (mediaItems.isEmpty()) return
        mc.setMediaItems(mediaItems, 0, 0L)
        applyRepeatToPlayer(mc, _uiState.value.repeatMode)
        mc.playbackParameters = PlaybackParameters(_uiState.value.playbackSpeed)
        mc.prepare()
        mc.play()

        val firstAyah = surah.ayahs[startOffsetInSurah]
        _uiState.value = _uiState.value.copy(
            mode = PlaybackModeState.FULL_SURAH,
            qariId = qari,
            surahNumber = surah.number,
            surahName = surah.englishName,
            currentAyahNumber = firstAyah.n,
            totalAyahs = surah.ayahCount,
            trackTitle = "",
            trackSubtitle = "",
            isLoading = true,
            errorMessage = null,
            unavailableNotice = null
        )
    }

    /**
     * Plays ONLY the chosen individual Ayah and stops when it finishes.
     */
    fun playSingleAyah(surah: SurahData, ayahIndex: Int, qariOverride: String? = null) {
        onBeforeMediaPlay?.invoke()
        val mc = controller ?: return
        val qari = qariOverride ?: _uiState.value.qariId
        val ayah = surah.ayahs.getOrNull(ayahIndex) ?: return
        activeSurah = surah
        startOffsetInSurah = ayahIndex

        val qariInfo = QariCatalog.findById(qari)
        val (uri, isOffline) = downloadManager.getPlayableUri(qari, surah.number, ayah.n, ayah.g)
        val extras = Bundle().apply { putBoolean("isOffline", isOffline) }
        val item = MediaItem.Builder()
            .setMediaId("single_${qari}_${surah.number}_${ayah.n}")
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle("${surah.englishName} · Ayah ${ayah.n}")
                    .setArtist(qariInfo.name)
                    .setExtras(extras)
                    .build()
            )
            .build()

        mc.setMediaItem(item)
        applyRepeatToPlayer(mc, if (_uiState.value.repeatMode == RepeatModeState.AYAH) RepeatModeState.AYAH else RepeatModeState.OFF)
        mc.playbackParameters = PlaybackParameters(_uiState.value.playbackSpeed)
        mc.prepare()
        mc.play()

        _uiState.value = _uiState.value.copy(
            mode = PlaybackModeState.SINGLE_AYAH,
            qariId = qari,
            surahNumber = surah.number,
            surahName = surah.englishName,
            currentAyahNumber = ayah.n,
            totalAyahs = surah.ayahCount,
            isOfflineSource = isOffline,
            isLoading = true,
            errorMessage = null,
            unavailableNotice = null
        )
    }

    fun playTrack(title: String, subtitle: String, audioUrl: String?, trackId: String = "") {
        onBeforeMediaPlay?.invoke()
        if (audioUrl.isNullOrBlank()) {
            _uiState.value = _uiState.value.copy(
                unavailableNotice = "${title}: Audio unavailable (no verified authentic recording bundled)."
            )
            return
        }
        val mc = controller ?: return
        activeSurah = null
        val item = MediaItem.Builder()
            .setMediaId(if (trackId.isNotBlank()) trackId else "track_${audioUrl.hashCode()}")
            .setUri(Uri.parse(audioUrl))
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(subtitle)
                    .setAlbumTitle("Islamic All-in-One")
                    .build()
            )
            .build()
        mc.setMediaItem(item)
        mc.repeatMode = Player.REPEAT_MODE_OFF
        mc.playbackParameters = PlaybackParameters(_uiState.value.playbackSpeed)
        mc.prepare()
        mc.play()

        _uiState.value = _uiState.value.copy(
            mode = PlaybackModeState.TRACK,
            trackId = trackId,
            trackTitle = title,
            trackSubtitle = subtitle,
            surahNumber = 0,
            surahName = "",
            positionMs = 0L,
            durationMs = 0L,
            isOfflineSource = false,
            isLoading = true,
            errorMessage = null,
            unavailableNotice = null
        )
    }

    fun pause() { controller?.pause() }
    fun resume() {
        val mc = controller ?: return
        if (mc.playbackState == Player.STATE_ENDED) {
            mc.seekTo(0L)
        }
        mc.play()
    }
    fun stop() {
        controller?.stop()
        controller?.clearMediaItems()
        activeSurah = null
        _uiState.value = _uiState.value.copy(
            mode = PlaybackModeState.IDLE,
            isPlaying = false,
            isLoading = false,
            trackId = "",
            trackTitle = "",
            trackSubtitle = "",
            positionMs = 0L,
            durationMs = 0L,
            errorMessage = null
        )
    }

    fun nextAyah() { controller?.seekToNextMediaItem() }
    fun prevAyah() { controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }

    fun cycleRepeatMode() {
        val next = when (_uiState.value.repeatMode) {
            RepeatModeState.OFF -> RepeatModeState.AYAH
            RepeatModeState.AYAH -> RepeatModeState.SURAH
            RepeatModeState.SURAH -> RepeatModeState.OFF
        }
        _uiState.value = _uiState.value.copy(repeatMode = next)
        controller?.let { applyRepeatToPlayer(it, next) }
    }

    private fun applyRepeatToPlayer(mc: MediaController, mode: RepeatModeState) {
        mc.repeatMode = when (mode) {
            RepeatModeState.OFF -> Player.REPEAT_MODE_OFF
            RepeatModeState.AYAH -> Player.REPEAT_MODE_ONE
            RepeatModeState.SURAH -> Player.REPEAT_MODE_ALL
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _uiState.value = _uiState.value.copy(playbackSpeed = speed)
        controller?.playbackParameters = PlaybackParameters(speed)
    }

    fun setQari(qariId: String) {
        val current = _uiState.value
        val surah = activeSurah
        _uiState.value = current.copy(qariId = qariId)
        if (surah != null && current.mode != PlaybackModeState.IDLE) {
            val idx = (current.currentAyahNumber - 1).coerceAtLeast(0)
            if (current.mode == PlaybackModeState.FULL_SURAH) {
                playFullSurah(surah, idx, qariId)
            } else if (current.mode == PlaybackModeState.SINGLE_AYAH) {
                playSingleAyah(surah, idx, qariId)
            }
        }
    }

    fun retry() {
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        controller?.prepare()
        controller?.play()
    }

    fun clearUnavailableNotice() {
        _uiState.value = _uiState.value.copy(unavailableNotice = null)
    }
}
