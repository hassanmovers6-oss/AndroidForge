package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.HadithAudioCatalog
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.data.HadithAssetRepository
import com.educationwithhassan.islamicallinone.data.HadithCollectionData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun formatDurationMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "${m}:${s.toString().padStart(2, '0')}"
}

@Composable
fun HadithScreen(
    audioManager: AudioPlayerManager
) {
    val context = LocalContext.current
    val collections = remember { HadithAssetRepository.loadIndex(context) }
    var selectedBookId by remember { mutableStateOf(collections.firstOrNull()?.id ?: "bukhari") }
    var bookData by remember { mutableStateOf<HadithCollectionData?>(null) }
    var loadingBook by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedChapter by remember { mutableStateOf("All") }
    var showChapterMenu by remember { mutableStateOf(false) }

    val audioState by audioManager.uiState.collectAsState()

    LaunchedEffect(selectedBookId) {
        loadingBook = true
        selectedChapter = "All"
        bookData = withContext(Dispatchers.IO) {
            HadithAssetRepository.loadBook(context, selectedBookId)
        }
        loadingBook = false
    }

    val chapters = remember(bookData) {
        val list = bookData?.hadiths?.map { it.chapter }?.distinct().orEmpty()
        listOf("All") + list
    }

    val filteredHadiths = remember(bookData, searchQuery, selectedChapter) {
        val data = bookData ?: return@remember emptyList()
        val q = searchQuery.trim().lowercase()
        data.hadiths.filter { h ->
            val chapterOk = selectedChapter == "All" || h.chapter == selectedChapter
            val queryOk = q.isEmpty() ||
                h.en.lowercase().contains(q) ||
                h.ar.contains(searchQuery.trim()) ||
                h.ur.contains(searchQuery.trim()) ||
                h.n.toString().contains(q) ||
                h.chapter.lowercase().contains(q)
            chapterOk && queryOk
        }.take(80)
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text(
            "Authentic Hadith Library",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(collections, key = { it.id }) { col ->
                FilterChip(
                    selected = selectedBookId == col.id,
                    onClick = { selectedBookId = col.id },
                    label = { Text("${col.title} (${col.bundledCount})") }
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search Hadith text, number, or chapter...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(6.dp))

        Box {
            OutlinedButton(onClick = { showChapterMenu = true }) {
                Text(if (selectedChapter == "All") "All Chapters" else selectedChapter)
            }
            DropdownMenu(expanded = showChapterMenu, onDismissRequest = { showChapterMenu = false }) {
                chapters.forEach { ch ->
                    DropdownMenuItem(
                        text = { Text(if (ch == "All") "All Chapters" else ch) },
                        onClick = {
                            selectedChapter = ch
                            showChapterMenu = false
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (loadingBook) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (bookData != null) {
            val activeBook = bookData!!
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(filteredHadiths, key = { "${activeBook.id}_${it.n}" }) { h ->
                    val trackId = "hadith_${activeBook.id}_${h.n}"
                    val audioInfo = remember(activeBook.id, h.n) {
                        HadithAudioCatalog.getHadithAudioInfo(activeBook.id, h.n)
                    }
                    val isThisTrack = audioState.mode == PlaybackModeState.TRACK && audioState.trackId == trackId
                    val isThisLoading = isThisTrack && audioState.isLoading
                    val isThisPlaying = isThisTrack && audioState.isPlaying
                    val isThisPaused = isThisTrack && !audioState.isPlaying && !audioState.isLoading && audioState.errorMessage == null

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        border = if (isThisTrack) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        h.ref,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                    if (h.chapter.isNotBlank()) {
                                        Text(
                                            h.chapter,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                if (audioInfo.arabicUrl != null) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Button(
                                            onClick = {
                                                when {
                                                    isThisLoading -> Unit
                                                    isThisPlaying -> audioManager.pause()
                                                    isThisPaused -> audioManager.resume()
                                                    else -> audioManager.playTrack(
                                                        title = h.ref,
                                                        subtitle = audioInfo.arabicSource ?: "Arabic Hadith Narration",
                                                        audioUrl = audioInfo.arabicUrl,
                                                        trackId = trackId
                                                    )
                                                }
                                            },
                                            enabled = !isThisLoading,
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            when {
                                                isThisLoading -> {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(16.dp),
                                                        strokeWidth = 2.dp,
                                                        color = MaterialTheme.colorScheme.onPrimary
                                                    )
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("Loading", style = MaterialTheme.typography.labelMedium)
                                                }
                                                isThisPlaying -> {
                                                    Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Pause", style = MaterialTheme.typography.labelMedium)
                                                }
                                                isThisPaused -> {
                                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Resume", style = MaterialTheme.typography.labelMedium)
                                                }
                                                else -> {
                                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Play Arabic", style = MaterialTheme.typography.labelMedium)
                                                }
                                            }
                                        }
                                        if (isThisTrack) {
                                            IconButton(onClick = { audioManager.stop() }) {
                                                Icon(Icons.Default.Stop, contentDescription = "Stop")
                                            }
                                        }
                                    }
                                } else {
                                    Surface(
                                        shape = MaterialTheme.shapes.small,
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.VolumeOff,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                "Audio unavailable",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }

                            if (isThisTrack) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                if (audioState.isLoading) "Loading Arabic narration..." else (audioInfo.arabicSource ?: "Arabic Narration"),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                "${formatDurationMs(audioState.positionMs)} / ${formatDurationMs(audioState.durationMs)}",
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }

                                        if (audioState.errorMessage != null) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    audioState.errorMessage!!,
                                                    modifier = Modifier.weight(1f),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                                OutlinedButton(onClick = { audioManager.retry() }) {
                                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Retry")
                                                }
                                            }
                                        } else if (audioState.durationMs > 0L) {
                                            Slider(
                                                value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                                                onValueChange = { audioManager.seekTo(it.toLong()) },
                                                valueRange = 0f..audioState.durationMs.toFloat()
                                            )
                                        }
                                    }
                                }
                            }

                            if (h.ar.isNotBlank()) {
                                Text(
                                    h.ar,
                                    fontSize = 20.sp,
                                    lineHeight = 34.sp,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Text(h.en, style = MaterialTheme.typography.bodyMedium)

                            if (h.ur.isNotBlank()) {
                                Text(
                                    h.ur,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                if (audioInfo.arabicUrl != null) {
                                    Text(
                                        "Urdu audio unavailable",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            val gradeText = if (h.grades.isNotEmpty()) {
                                h.grades.joinToString(" · ")
                            } else if (activeBook.id == "bukhari" || activeBook.id == "muslim") {
                                "Sahih (Agreed upon canonical Sahihayn edition)"
                            } else {
                                "See collection commentary for grading"
                            }
                            Text(
                                "Scholarly Grading: ${gradeText}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
