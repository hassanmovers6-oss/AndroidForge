package com.educationwithhassan.islamicallinone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.educationwithhassan.islamicallinone.ads.AdManager
import com.educationwithhassan.islamicallinone.ads.AdaptiveBannerBar
import com.educationwithhassan.islamicallinone.ads.RewardStorage
import com.educationwithhassan.islamicallinone.ads.findActivity
import com.educationwithhassan.islamicallinone.audio.AudioDownloadManager
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.EducationalTtsManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.ui.screens.DuasAndAzkarScreen
import com.educationwithhassan.islamicallinone.ui.screens.HadithScreen
import com.educationwithhassan.islamicallinone.ui.screens.HomeScreen
import com.educationwithhassan.islamicallinone.ui.screens.MoreDestination
import com.educationwithhassan.islamicallinone.ui.screens.MoreHubScreen
import com.educationwithhassan.islamicallinone.ui.screens.Names99Screen
import com.educationwithhassan.islamicallinone.ui.screens.QuizScreen
import com.educationwithhassan.islamicallinone.ui.screens.QuranScreen
import com.educationwithhassan.islamicallinone.ui.screens.SeerahAndLearningScreen
import com.educationwithhassan.islamicallinone.ui.screens.SettingsAndCustomizationScreen

enum class BottomTab(val label: String) {
    HOME("Home"),
    QURAN("Quran"),
    HADITH("Hadith"),
    DUAS("Duas"),
    MORE("More")
}

private fun formatMiniPlayerTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "${m}:${s.toString().padStart(2, '0')}"
}

@Composable
fun IslamicRootApp(
    adManager: AdManager,
    rewardStorage: RewardStorage,
    audioManager: AudioPlayerManager,
    downloadManager: AudioDownloadManager,
    ttsManager: EducationalTtsManager
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var showSplash by remember { mutableStateOf(true) }
    var activeTab by remember { mutableStateOf(BottomTab.HOME) }
    var duasInitialTab by remember { mutableIntStateOf(0) }
    var moreDest by remember { mutableStateOf(MoreDestination.HUB) }

    val audioState by audioManager.uiState.collectAsState()
    val ttsState by ttsManager.uiState.collectAsState()
    val isAudioPlaying = audioState.isPlaying || audioState.isLoading || ttsState.isSpeaking

    val isSacredScreen =
        activeTab == BottomTab.QURAN ||
            activeTab == BottomTab.HADITH ||
            activeTab == BottomTab.DUAS ||
            (activeTab == BottomTab.MORE && moreDest == MoreDestination.NAMES99)

    LaunchedEffect(Unit) {
        val act = activity
        if (act != null) {
            adManager.loadAndShowSplashAppOpen(act, isAudioPlaying = isAudioPlaying) {
                showSplash = false
            }
        } else {
            showSplash = false
        }
    }

    if (showSplash) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(24.dp)
            ) {
                Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text("Islamic All-in-One", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Your Complete Islamic Companion", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.5.dp)
            }
        }
        return
    }

    fun returnToMoreHubWithNaturalInterstitial(placement: String) {
        val navigate = { moreDest = MoreDestination.HUB }
        if (activity != null) {
            adManager.showInterstitialIfEligible(
                activity = activity,
                isSacredScreen = false,
                isAudioPlaying = isAudioPlaying,
                placement = placement,
                onContinue = navigate
            )
        } else {
            navigate()
        }
    }

    Scaffold(
        bottomBar = {
            Column {
                val notice = audioState.unavailableNotice ?: ttsState.unavailableNotice
                notice?.let { msg ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(msg, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = {
                                audioManager.clearUnavailableNotice()
                                ttsManager.clearUnavailableNotice()
                            }) { Text("Dismiss") }
                        }
                    }
                }

                if (ttsState.isActive) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${ttsState.title} (${ttsState.langLabel} TTS)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (ttsState.errorMessage != null) ttsState.errorMessage!!
                                    else "${ttsState.subtitle} · Section ${ttsState.chunkIndex}/${ttsState.totalChunks}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            if (ttsState.errorMessage != null) {
                                TextButton(onClick = { ttsManager.retry() }) {
                                    Text("Retry")
                                }
                            } else {
                                IconButton(onClick = {
                                    if (ttsState.isSpeaking) ttsManager.pause() else ttsManager.resume()
                                }) {
                                    Icon(if (ttsState.isSpeaking) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause TTS")
                                }
                            }
                            IconButton(onClick = { ttsManager.stop() }) {
                                Icon(Icons.Default.Stop, "Stop TTS")
                            }
                        }
                    }
                }

                if (audioState.mode != PlaybackModeState.IDLE) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        if (audioState.surahNumber > 0)
                                            "${audioState.surahName} · Ayah ${audioState.currentAyahNumber} / ${audioState.totalAyahs}"
                                        else audioState.trackTitle,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    val statusText = when {
                                        audioState.errorMessage != null -> audioState.errorMessage!!
                                        audioState.isLoading -> "Loading audio..."
                                        audioState.isOfflineSource -> "Playing Offline · ${formatMiniPlayerTime(audioState.positionMs)} / ${formatMiniPlayerTime(audioState.durationMs)}"
                                        else -> "Streaming Verified Audio · ${formatMiniPlayerTime(audioState.positionMs)} / ${formatMiniPlayerTime(audioState.durationMs)}"
                                    }
                                    Text(
                                        statusText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (audioState.errorMessage != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                if (audioState.errorMessage != null) {
                                    TextButton(onClick = { audioManager.retry() }) {
                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Retry")
                                    }
                                } else if (audioState.isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                                } else {
                                    IconButton(onClick = {
                                        if (audioState.isPlaying) audioManager.pause() else audioManager.resume()
                                    }) {
                                        Icon(if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
                                    }
                                }
                                IconButton(onClick = { audioManager.stop() }) {
                                    Icon(Icons.Default.Stop, "Stop")
                                }
                            }
                            if (audioState.mode == PlaybackModeState.TRACK && audioState.errorMessage == null && audioState.durationMs > 0L) {
                                Slider(
                                    value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                                    onValueChange = { audioManager.seekTo(it.toLong()) },
                                    valueRange = 0f..audioState.durationMs.toFloat()
                                )
                            }
                        }
                    }
                }

                AdaptiveBannerBar(
                    adManager = adManager,
                    isVisible = !isSacredScreen && !isAudioPlaying,
                    screenTag = "${activeTab.name}_${moreDest.name}"
                )

                NavigationBar {
                    BottomTab.entries.forEach { tab ->
                        val icon = when (tab) {
                            BottomTab.HOME -> Icons.Default.Home
                            BottomTab.QURAN -> Icons.Default.MenuBook
                            BottomTab.HADITH -> Icons.Default.AutoStories
                            BottomTab.DUAS -> Icons.Default.Favorite
                            BottomTab.MORE -> Icons.Default.GridView
                        }
                        NavigationBarItem(
                            selected = activeTab == tab,
                            onClick = {
                                activeTab = tab
                                if (tab == BottomTab.MORE) moreDest = MoreDestination.HUB
                            },
                            icon = { Icon(icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (activeTab) {
                BottomTab.HOME -> HomeScreen(
                    adManager = adManager,
                    rewardStorage = rewardStorage,
                    audioManager = audioManager,
                    ttsManager = ttsManager,
                    isAudioPlaying = isAudioPlaying,
                    onOpenQuran = { activeTab = BottomTab.QURAN },
                    onOpenHadith = { activeTab = BottomTab.HADITH },
                    onOpenDuas = {
                        duasInitialTab = 1
                        activeTab = BottomTab.DUAS
                    },
                    onOpenAzkar = {
                        duasInitialTab = 0
                        activeTab = BottomTab.DUAS
                    },
                    onOpenMoreSection = { dest ->
                        moreDest = dest
                        activeTab = BottomTab.MORE
                    }
                )
                BottomTab.QURAN -> QuranScreen(audioManager = audioManager, downloadManager = downloadManager)
                BottomTab.HADITH -> HadithScreen(audioManager = audioManager)
                BottomTab.DUAS -> DuasAndAzkarScreen(audioManager = audioManager, initialModeTab = duasInitialTab)
                BottomTab.MORE -> when (moreDest) {
                    MoreDestination.HUB -> MoreHubScreen(
                        adManager = adManager,
                        isAudioPlaying = isAudioPlaying,
                        onOpenAzkar = {
                            duasInitialTab = 0
                            activeTab = BottomTab.DUAS
                        },
                        onSelectDestination = { moreDest = it }
                    )
                    MoreDestination.NAMES99 -> Names99Screen(
                        audioManager = audioManager,
                        onBack = { moreDest = MoreDestination.HUB }
                    )
                    MoreDestination.SEERAH -> SeerahAndLearningScreen(
                        adManager = adManager,
                        audioManager = audioManager,
                        ttsManager = ttsManager,
                        isAudioPlaying = isAudioPlaying,
                        initialSectionTab = 0,
                        onBack = { returnToMoreHubWithNaturalInterstitial("seerah_exit") }
                    )
                    MoreDestination.LEARNING -> SeerahAndLearningScreen(
                        adManager = adManager,
                        audioManager = audioManager,
                        ttsManager = ttsManager,
                        isAudioPlaying = isAudioPlaying,
                        initialSectionTab = 1,
                        onBack = { returnToMoreHubWithNaturalInterstitial("learning_exit") }
                    )
                    MoreDestination.TASBEEH -> SeerahAndLearningScreen(
                        adManager = adManager,
                        audioManager = audioManager,
                        ttsManager = ttsManager,
                        isAudioPlaying = isAudioPlaying,
                        initialSectionTab = 2,
                        onBack = { returnToMoreHubWithNaturalInterstitial("tasbeeh_exit") }
                    )
                    MoreDestination.QUIZ -> QuizScreen(
                        adManager = adManager,
                        rewardStorage = rewardStorage,
                        isAudioPlaying = isAudioPlaying,
                        onBack = { returnToMoreHubWithNaturalInterstitial("quiz_exit") }
                    )
                    MoreDestination.SETTINGS -> SettingsAndCustomizationScreen(
                        adManager = adManager,
                        rewardStorage = rewardStorage,
                        isAudioPlaying = isAudioPlaying,
                        onBack = { moreDest = MoreDestination.HUB }
                    )
                }
            }
        }
    }
}
