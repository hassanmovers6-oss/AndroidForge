package com.educationwithhassan.islamicallinone.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.islamicallinone.audio.AudioPlayerManager
import com.educationwithhassan.islamicallinone.audio.PlaybackModeState
import com.educationwithhassan.islamicallinone.data.AllSectionsRepository

private fun formatNameDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "${m}:${s.toString().padStart(2, '0')}"
}

@Composable
fun Names99Screen(
    audioManager: AudioPlayerManager,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val names = remember { AllSectionsRepository.load(context).asmaUlHusna }
    var query by remember { mutableStateOf("") }
    val audioState by audioManager.uiState.collectAsState()

    val filtered = remember(names, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) names
        else names.filter {
            it.transliteration.lowercase().contains(q) ||
                it.english.lowercase().contains(q) ||
                it.arabic.contains(query.trim()) ||
                it.urdu.contains(query.trim()) ||
                it.number.toString() == q
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Asma-ul-Husna · 99 Names of Allah", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Individual verified Arabic pronunciation for each Name · Urdu audio unavailable", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search by Name, meaning, Urdu, or number (1-99)...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(filtered, key = { it.number }) { item ->
                val trackId = "name99_${item.number}"
                val isThis = audioState.mode == PlaybackModeState.TRACK && audioState.trackId == trackId
                val isLoading = isThis && audioState.isLoading
                val isPlaying = isThis && audioState.isPlaying
                val isPaused = isThis && !audioState.isPlaying && !audioState.isLoading && audioState.errorMessage == null

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    border = if (isThis) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("#${item.number} · ${item.transliteration}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(item.english, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            }
                            if (item.audioUrl != null) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(
                                        onClick = {
                                            when {
                                                isLoading -> Unit
                                                isPlaying -> audioManager.pause()
                                                isPaused -> audioManager.resume()
                                                else -> audioManager.playTrack(
                                                    title = "#${item.number} ${item.transliteration} (${item.arabic})",
                                                    subtitle = item.audioSourceNote ?: "Verified Arabic Pronunciation",
                                                    audioUrl = item.audioUrl,
                                                    trackId = trackId
                                                )
                                            }
                                        },
                                        enabled = !isLoading,
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        when {
                                            isLoading -> {
                                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                                Spacer(Modifier.width(6.dp))
                                                Text("Loading", style = MaterialTheme.typography.labelMedium)
                                            }
                                            isPlaying -> {
                                                Icon(Icons.Default.Pause, null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Pause", style = MaterialTheme.typography.labelMedium)
                                            }
                                            isPaused -> {
                                                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Resume", style = MaterialTheme.typography.labelMedium)
                                            }
                                            else -> {
                                                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Play Arabic", style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                    if (isThis) {
                                        IconButton(onClick = { audioManager.stop() }) {
                                            Icon(Icons.Default.Stop, contentDescription = "Stop")
                                        }
                                    }
                                }
                            } else {
                                Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant) {
                                    Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.VolumeOff, null, modifier = Modifier.size(14.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Audio unavailable", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }

                        if (isThis) {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(
                                            if (audioState.isLoading) "Loading Arabic pronunciation..." else (item.audioSourceNote ?: "Arabic Pronunciation"),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text("${formatNameDuration(audioState.positionMs)} / ${formatNameDuration(audioState.durationMs)}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    if (audioState.errorMessage != null) {
                                        Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text(audioState.errorMessage!!, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                            OutlinedButton(onClick = { audioManager.retry() }) {
                                                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Retry")
                                            }
                                        }
                                    } else if (audioState.durationMs > 0L) {
                                        Slider(
                                            value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                                            onValueChange = { audioManager.seekTo(it.toLong()) },
                                            valueRange = 0f..audioState.durationMs.toFloat()
                                        )
                                    }
                                }
                            }
                        }

                        Text(item.arabic, fontSize = 26.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                        Text(item.urdu, textAlign = TextAlign.End, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
                        Text(item.explanation, style = MaterialTheme.typography.bodySmall)
                        Text("Urdu audio unavailable · Arabic recitation verified", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
