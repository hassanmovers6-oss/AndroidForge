# Islamic All-in-One (Android Studio Project)

Package Name: `com.educationwithhassan.islamicallinone`
Tagline: Your Complete Islamic Companion

## Audio Architecture (Media3 ExoPlayer + MediaSessionService + Coordinated TextToSpeech)
- **Full Surah Continuous Playback**: `AudioPlayerManager.playFullSurah` builds an ordered sequential `MediaItem` playlist containing every Ayah of the selected Surah and plays continuously in foreground & background through the final Ayah.
- **Individual Ayah Playback**: `AudioPlayerManager.playSingleAyah` plays only the selected Ayah and stops when complete.
- **Hadith, 99 Names, Duas, Azkar, Dhikr & Learning Steps**: `AudioPlayerManager.playTrack` plays verified authentic recordings with seek bar, Pause/Resume/Stop, Retry, and honest `Audio unavailable` handling.
- **Educational Narration (Seerah, History, Lesson Guides, Daily Reminders)**: `EducationalTtsManager` provides sentence-chunked English & Urdu device Text-to-Speech clearly labeled as Text-to-Speech (not an authentic recording), automatically synchronized with Media3 so two audio streams never play together.
- **Lock-Screen & Notification Controls + Audio Focus**: `PlaybackService` extends `MediaSessionService` with `AudioAttributes` speech focus handling and `setHandleAudioBecomingNoisy(true)`.
- **Offline Surah Cache**: `AudioDownloadManager` stores verified Qari MP3s under `filesDir/quran_audio/` with progress tracking and duplicate avoidance.

## Build Instructions
1. Open this folder in Android Studio Ladybug / Koala or import into AndroidForge.
2. Offline Quran, Hadith, Quiz, and Audio Sections JSON datasets live in `app/src/main/assets/data/`.
3. Sync Gradle and run on Android API 24+ (Target SDK 35).

## AdMob Setup (All 5 Formats + Rewarded Placements)
- Configured Production App ID: `ca-app-pub-3133971041724338~8711999965`
- Banner: `ca-app-pub-3133971041724338/4228656986`
- Interstitial: `ca-app-pub-3133971041724338/7976330301` (120s minimum cooldown, 45s post-App-Open guard)
- Rewarded: `ca-app-pub-3133971041724338/2724003629` (Optional 24h Themes/Customization, +25 Daily Bonus Points, +2 Quiz Hints & Bonus Practice)
- Native: `ca-app-pub-3133971041724338/6990551699` (`NativeAdView` in More Hub, Seerah & Learning feeds)
- App Open: `ca-app-pub-3133971041724338/5158595277` (Splash 3s max timeout + ProcessLifecycleOwner foreground resume)
- Test Mode toggle is built into `Themes, Customization & AdMob` screen and `AdManager.setTestMode(true)` to swap cleanly to Official Google Test IDs during QA.
- Religious respect policy enforced in `AdManager.kt`: zero ads inside Quran, Hadith, Duas/Azkar, 99 Names, or during active audio playback.

## Verified Content Sources & Attribution
- Holy Quran Uthmani Arabic, Sahih International English, Jalandhry Urdu, Yusuf Ali: Tanzil / AlQuran.cloud verified editions.
- Hadith Collections: fawazahmed0/hadith-api (Sunnah.com verified editions).
- Duas & Azkar: Hisn al-Muslim verified Arabic recordings.
- 99 Names of Allah: Verified individual Arabic pronunciation recordings (`1..99.mp3`).
- Prayer Times & Qibla Math: Batoul Apps Adhan library.
