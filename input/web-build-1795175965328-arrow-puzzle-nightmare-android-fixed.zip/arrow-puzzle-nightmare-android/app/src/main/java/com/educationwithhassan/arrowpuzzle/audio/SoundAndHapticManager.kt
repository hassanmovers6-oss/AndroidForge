package com.educationwithhassan.arrowpuzzle.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class SoundAndHapticManager(context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    @Volatile
    var soundEnabled: Boolean = true

    @Volatile
    var vibrationEnabled: Boolean = true

    fun playClick() {
        playTone(540.0, 380.0, 55, 0.18f)
        vibrate(12L)
    }

    fun playArrowSlide() {
        playTone(340.0, 760.0, 130, 0.24f)
        vibrate(20L)
    }

    fun playBlocked() {
        playTone(170.0, 90.0, 140, 0.28f)
        vibrate(45L)
    }

    fun playHeartLost() {
        playTone(280.0, 140.0, 200, 0.24f)
    }

    fun playWin() {
        scope.launch {
            val notes = listOf(523.25, 659.25, 783.99, 1046.5)
            for (n in notes) {
                synthesizeAndPlay(n, n * 1.01, 130, 0.24f)
            }
        }
        vibrate(60L)
    }

    fun playGameOver() {
        scope.launch {
            val notes = listOf(392.0, 349.23, 311.13, 261.63)
            for (n in notes) {
                synthesizeAndPlay(n, n * 0.96, 170, 0.22f)
            }
        }
        vibrate(90L)
    }

    private fun playTone(freqStart: Double, freqEnd: Double, durationMs: Int, gain: Float) {
        if (!soundEnabled) return
        scope.launch {
            synthesizeAndPlay(freqStart, freqEnd, durationMs, gain)
        }
    }

    private fun synthesizeAndPlay(freqStart: Double, freqEnd: Double, durationMs: Int, gain: Float) {
        if (!soundEnabled) return
        val sampleRate = 22050
        val count = (sampleRate * durationMs) / 1000
        val samples = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toDouble() / count
            val freq = freqStart + (freqEnd - freqStart) * t
            val envelope = if (t < 0.1) t / 0.1 else (1.0 - t)
            phase += 2.0 * PI * freq / sampleRate
            samples[i] = (sin(phase) * envelope * gain * Short.MAX_VALUE).toInt().toShort()
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(samples.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        runCatching {
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep(durationMs.toLong() + 20L)
            track.stop()
        }
        track.release()
    }

    private fun vibrate(durationMs: Long) {
        if (!vibrationEnabled) return
        val activeVibrator = vibrator ?: return
        runCatching {
            activeVibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
