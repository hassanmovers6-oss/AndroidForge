package com.educationwithhassan.shadowninja

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * Manages Google User Messaging Platform (UMP) consent updates,
 * non-personalized ad compliance, offline-to-online retry, and privacy options re-entry.
 */
class ConsentManager(private val appContext: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val consentInformation: ConsentInformation =
        UserMessagingPlatform.getConsentInformation(appContext)

    @Volatile
    var isGatheringConsent: Boolean = false
        private set

    @Volatile
    private var lastAttemptMs: Long = 0L

    val canRequestAds: Boolean
        get() = consentInformation.canRequestAds()

    val isPrivacyOptionsRequired: Boolean
        get() = consentInformation.privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    val statusLabel: String
        get() = when (consentInformation.consentStatus) {
            ConsentInformation.ConsentStatus.OBTAINED -> "OBTAINED"
            ConsentInformation.ConsentStatus.NOT_REQUIRED -> "NOT_REQUIRED"
            ConsentInformation.ConsentStatus.REQUIRED -> "REQUIRED"
            else -> "UNKNOWN"
        }

    fun gatherConsent(activity: Activity, onConsentComplete: (canRequestAds: Boolean) -> Unit) {
        mainHandler.post {
            if (isGatheringConsent || activity.isFinishing || activity.isDestroyed) {
                return@post
            }
            isGatheringConsent = true
            lastAttemptMs = System.currentTimeMillis()

            // Shadow Ninja – Dark Quest is a dark fantasy action game for teen/general audiences.
            val params = ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build()

            Log.i(
                AdConfig.LOG_TAG,
                "[Consent] Requesting UMP update (status=$statusLabel, cachedCanRequest=${consentInformation.canRequestAds()})"
            )

            consentInformation.requestConsentInfoUpdate(
                activity,
                params,
                {
                    if (activity.isFinishing || activity.isDestroyed) {
                        isGatheringConsent = false
                        return@requestConsentInfoUpdate
                    }
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                        isGatheringConsent = false
                        if (formError != null) {
                            Log.w(
                                AdConfig.LOG_TAG,
                                "[Consent] Form error code=${formError.errorCode}: ${formError.message}"
                            )
                        } else {
                            Log.i(
                                AdConfig.LOG_TAG,
                                "[Consent] Resolved status=$statusLabel, canRequestAds=$canRequestAds, privacyRequired=$isPrivacyOptionsRequired"
                            )
                        }
                        onConsentComplete(consentInformation.canRequestAds())
                    }
                },
                { requestError ->
                    isGatheringConsent = false
                    Log.w(
                        AdConfig.LOG_TAG,
                        "[Consent] Info update failed/offline code=${requestError.errorCode}: ${requestError.message} (cachedCanRequest=${consentInformation.canRequestAds()})"
                    )
                    // Do not block gameplay if offline or consent endpoint fails
                    onConsentComplete(consentInformation.canRequestAds())
                }
            )
        }
    }

    /**
     * Retries UMP consent strictly when cached canRequestAds is still false (e.g., cold launch while offline)
     * and at least 15s have elapsed since the previous attempt. Never bypasses consent.
     */
    fun retryConsentIfNeeded(activity: Activity, onConsentComplete: (canRequestAds: Boolean) -> Unit) {
        if (canRequestAds || isGatheringConsent) return
        val now = System.currentTimeMillis()
        if (now - lastAttemptMs < 15_000L) return
        Log.i(AdConfig.LOG_TAG, "[Consent] Retrying UMP consent check after reconnect/resume.")
        gatherConsent(activity, onConsentComplete)
    }

    fun showPrivacyOptionsForm(activity: Activity, onDismissed: (Boolean) -> Unit = {}) {
        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                onDismissed(consentInformation.canRequestAds())
                return@post
            }
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
                if (formError != null) {
                    Log.w(
                        AdConfig.LOG_TAG,
                        "[Consent] Privacy options error code=${formError.errorCode}: ${formError.message}"
                    )
                } else {
                    Log.i(
                        AdConfig.LOG_TAG,
                        "[Consent] Privacy options closed (canRequestAds=${consentInformation.canRequestAds()})"
                    )
                }
                onDismissed(consentInformation.canRequestAds())
            }
        }
    }
}
