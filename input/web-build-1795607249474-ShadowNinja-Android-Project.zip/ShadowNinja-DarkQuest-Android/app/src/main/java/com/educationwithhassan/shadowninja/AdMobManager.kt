package com.educationwithhassan.shadowninja

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min
import kotlin.math.roundToInt

enum class AdFormatState {
    NOT_INITIALIZED,
    LOADING,
    LOADED,
    SHOWING,
    FAILED,
    NOT_AVAILABLE,
}

/**
 * Centralized, process-scoped Google AdMob Manager for Shadow Ninja – Dark Quest.
 * Manages all six AdMob formats (App ID, App Open, Anchored Adaptive Banner,
 * Interstitial, Native Advanced, Rewarded) strictly on Android's Main Looper
 * with lifecycle coordination, retry backoff, consent compliance, and diagnostics.
 */
object AdMobManager : DefaultLifecycleObserver {

    interface HostCallbacks {
        fun onFullscreenAdWillShow()
        fun onFullscreenAdDismissed()
        fun onTransitionInterstitialFinished(shown: Boolean)
        fun onNativeAdAvailabilityChanged(loaded: Boolean)
        fun onRewardedAdAvailabilityChanged(loaded: Boolean)
        fun onColdLaunchOverlayVisibility(visible: Boolean)
    }

    private const val PREFS_NAME = "shadow_ninja_admob_prefs"
    private const val KEY_LAST_APP_OPEN_MS = "last_app_open_ms"
    private const val MAX_RETRY_ATTEMPTS = 5
    private const val WIDTH_HYSTERESIS_DP = 16

    private val mainHandler = Handler(Looper.getMainLooper())
    private val sdkInitStarted = AtomicBoolean(false)

    @Volatile
    var isSdkInitialized: Boolean = false
        private set

    @Volatile
    var consentManager: ConsentManager? = null
        private set

    private lateinit var appContext: Context
    private lateinit var prefs: SharedPreferences

    private var activityRef: WeakReference<Activity>? = null
    private var bannerContainerRef: WeakReference<FrameLayout>? = null
    private var nativeContainerRef: WeakReference<FrameLayout>? = null
    private var hostCallbacksRef: WeakReference<HostCallbacks>? = null

    // Format states
    @Volatile var appOpenState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var bannerState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var interstitialState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var nativeState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var rewardedState = AdFormatState.NOT_INITIALIZED; private set
    @Volatile var lastLoadError: String = "None"; private set

    // Active gameplay / screen safety guards
    @Volatile var currentScreen: String = "SPLASH"; private set
    @Volatile var isInActiveGameplay: Boolean = false; private set
    @Volatile var isInBossFight: Boolean = false; private set
    @Volatile private var isFullscreenShowing: Boolean = false
    @Volatile private var externalAdClickInProgress: Boolean = false
    @Volatile private var coldLaunchAttempted: Boolean = false
    @Volatile private var coldLaunchWaitingOverlay: Boolean = false

    // Banner
    private var bannerView: AdView? = null
    @Volatile private var bannerShouldBeVisible: Boolean = false
    private var bannerRetryCount = 0
    private var lastBannerWidthDp = 0
    private var lastBannerOrientation = 0

    // Interstitial
    @Volatile private var interstitialAd: InterstitialAd? = null
    private var interstitialRetryCount = 0
    private var lastInterstitialShownMs = 0L
    private var lastCompletedLevelToken: String = ""

    // Rewarded
    @Volatile private var rewardedAd: RewardedAd? = null
    private var rewardedRetryCount = 0

    // App Open
    @Volatile private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadTimeMs = 0L
    private var appOpenRetryCount = 0
    private var lastAppOpenShownMs = 0L

    // Native Advanced
    @Volatile private var cachedNativeAd: NativeAd? = null
    private var nativeRetryCount = 0
    private var nativeSlotBounds: SlotBounds? = null

    private data class SlotBounds(
        val xRatio: Float,
        val yRatio: Float,
        val wRatio: Float,
        val hRatio: Float,
    )

    private inline fun runOnMain(crossinline action: () -> Unit) {
        if (Looper.myLooper() === Looper.getMainLooper()) {
            action()
        } else {
            mainHandler.post { action() }
        }
    }

    fun initApplication(context: Context) {
        appContext = context.applicationContext
        prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        lastAppOpenShownMs = prefs.getLong(KEY_LAST_APP_OPEN_MS, 0L)
        consentManager = ConsentManager(appContext)
        Log.i(
            AdConfig.LOG_TAG,
            "[SDK] AdMobManager initialized (${if (AdConfig.isTestMode) "TEST MODE" else "PRODUCTION MODE"})"
        )
    }

    fun attachActivity(
        activity: Activity,
        bannerHolder: FrameLayout,
        nativeHolder: FrameLayout,
        callbacks: HostCallbacks,
    ) {
        runOnMain {
            activityRef = WeakReference(activity)
            bannerContainerRef = WeakReference(bannerHolder)
            nativeContainerRef = WeakReference(nativeHolder)
            hostCallbacksRef = WeakReference(callbacks)

            if (isSdkInitialized && canRequestAds()) {
                if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                    showBanner()
                } else {
                    updateBannerContainerVisibility()
                }
                renderBoundNativeAd()
            }
        }
    }

    fun detachActivity(activity: Activity) {
        runOnMain {
            if (activityRef?.get() === activity) {
                bannerView?.destroy()
                bannerView = null
                bannerContainerRef?.get()?.removeAllViews()
                nativeContainerRef?.get()?.removeAllViews()
                activityRef = null
                bannerContainerRef = null
                nativeContainerRef = null
                hostCallbacksRef = null
                lastBannerWidthDp = 0
            }
        }
    }

    fun initializeSdkAfterConsent(activity: Activity) {
        runOnMain {
            if (!canRequestAds()) {
                Log.w(AdConfig.LOG_TAG, "[SDK] Consent does not permit ad requests yet; delaying SDK load.")
                return@runOnMain
            }
            if (sdkInitStarted.getAndSet(true)) {
                if (isSdkInitialized) {
                    preloadAllFormats()
                    if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                        showBanner()
                    }
                }
                return@runOnMain
            }

            Log.i(AdConfig.LOG_TAG, "[SDK] Initializing Google Mobile Ads SDK...")
            MobileAds.initialize(appContext) { initStatus ->
                isSdkInitialized = true
                Log.i(AdConfig.LOG_TAG, "[SDK] MobileAds initialized: ${initStatus.adapterStatusMap.keys}")
                runOnMain {
                    preloadAllFormats()
                    if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                        showBanner()
                    }
                    hostCallbacksRef?.get()?.onRewardedAdAvailabilityChanged(isRewardedReady())
                    hostCallbacksRef?.get()?.onNativeAdAvailabilityChanged(isNativeLoaded())
                }
            }
        }
    }

    private fun canRequestAds(): Boolean = consentManager?.canRequestAds == true

    private fun isConsentFormBusy(): Boolean = consentManager?.isGatheringConsent == true

    private fun preloadAllFormats() {
        if (!isSdkInitialized || !canRequestAds()) return
        preloadAppOpen()
        preloadInterstitial()
        preloadRewarded()
        preloadNativeAd()
    }

    fun updateGameState(screen: String, inGameplay: Boolean, inBoss: Boolean) {
        currentScreen = screen
        isInActiveGameplay = inGameplay
        isInBossFight = inBoss
        runOnMain {
            if (screen == "SPLASH") {
                hideBanner()
            } else {
                updateBannerContainerVisibility()
            }
            if (inGameplay) {
                hideNativeAdOverlay()
                // Warm up interstitial & rewarded asynchronously during gameplay breaks
                if (isSdkInitialized && canRequestAds()) {
                    preloadInterstitial()
                    preloadRewarded()
                }
            }
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        if (!coldLaunchAttempted) {
            return
        }
        if (externalAdClickInProgress) {
            externalAdClickInProgress = false
            Log.d(AdConfig.LOG_TAG, "[AppOpen] Skipped onStart: returning from external ad click.")
            return
        }
        showAppOpenIfAppropriate()
    }

    // =========================================================================
    // 1. APP OPEN AD (4-hour freshness & frequency gate)
    // =========================================================================

    fun tryColdLaunchAppOpen() {
        runOnMain {
            if (coldLaunchAttempted) return@runOnMain
            coldLaunchAttempted = true
            if (!canRequestAds() || isConsentFormBusy()) return@runOnMain

            val now = System.currentTimeMillis()
            if (now - lastAppOpenShownMs < AdConfig.APP_OPEN_COOLDOWN_MS) {
                Log.d(AdConfig.LOG_TAG, "[AppOpen] Cold launch skipped (4h cooldown active).")
                return@runOnMain
            }

            if (isAppOpenAvailable()) {
                showAppOpenIfAppropriate()
                return@runOnMain
            }

            coldLaunchWaitingOverlay = true
            updateBannerContainerVisibility()
            hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(true)
            if (isSdkInitialized) preloadAppOpen()

            mainHandler.postDelayed({
                if (coldLaunchWaitingOverlay) {
                    coldLaunchWaitingOverlay = false
                    hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
                    updateBannerContainerVisibility()
                    if (currentScreen == "SPLASH" || currentScreen == "MAIN_MENU") {
                        showAppOpenIfAppropriate()
                    }
                }
            }, 1450L)
        }
    }

    fun preloadAppOpen() {
        runOnMain {
            if (!isSdkInitialized || !canRequestAds()) return@runOnMain
            if (appOpenState == AdFormatState.LOADING || isAppOpenAvailable()) return@runOnMain

            appOpenState = AdFormatState.LOADING
            Log.d(
                AdConfig.LOG_TAG,
                if (AdConfig.isTestMode) "[AppOpen] Load started (${AdConfig.activeAppOpenId})" else "[AppOpen] Load started"
            )

            AppOpenAd.load(
                appContext,
                AdConfig.activeAppOpenId,
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        runOnMain {
                            appOpenAd = ad
                            appOpenLoadTimeMs = System.currentTimeMillis()
                            appOpenState = AdFormatState.LOADED
                            appOpenRetryCount = 0
                            Log.i(AdConfig.LOG_TAG, "[AppOpen] Loaded successfully.")
                            if (coldLaunchWaitingOverlay && (currentScreen == "SPLASH" || currentScreen == "MAIN_MENU")) {
                                coldLaunchWaitingOverlay = false
                                hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
                                updateBannerContainerVisibility()
                                showAppOpenIfAppropriate()
                            }
                        }
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        runOnMain {
                            appOpenAd = null
                            appOpenState = AdFormatState.FAILED
                            lastLoadError = "AppOpen(${error.code}): ${error.message}"
                            Log.w(AdConfig.LOG_TAG, "[AppOpen] Load failed code=${error.code}: ${error.message}")
                            if (coldLaunchWaitingOverlay) {
                                coldLaunchWaitingOverlay = false
                                hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
                                updateBannerContainerVisibility()
                            }
                            scheduleRetry(appOpenRetryCount++) { preloadAppOpen() }
                        }
                    }
                }
            )
        }
    }

    private fun isAppOpenAvailable(): Boolean {
        if (appOpenAd == null) return false
        val ageMs = System.currentTimeMillis() - appOpenLoadTimeMs
        val fresh = ageMs < AdConfig.APP_OPEN_EXPIRATION_MS
        if (!fresh) {
            appOpenAd = null
            appOpenState = AdFormatState.NOT_AVAILABLE
        }
        return fresh
    }

    fun showAppOpenIfAppropriate(): Boolean {
        val activity = activityRef?.get() ?: return false
        if (!canRequestAds() || isConsentFormBusy()) return false
        if (isInActiveGameplay || isInBossFight || currentScreen == "PLAYING" || currentScreen == "PAUSED") {
            Log.d(AdConfig.LOG_TAG, "[AppOpen] Blocked during active gameplay/boss encounter.")
            return false
        }
        if (isFullscreenShowing) {
            Log.d(AdConfig.LOG_TAG, "[AppOpen] Blocked: another full-screen ad is active.")
            return false
        }
        val now = System.currentTimeMillis()
        if (now - lastAppOpenShownMs < AdConfig.APP_OPEN_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "[AppOpen] Skipped: 4-hour frequency window active.")
            return false
        }
        val ad = appOpenAd?.takeIf { isAppOpenAvailable() } ?: run {
            preloadAppOpen()
            return false
        }

        isFullscreenShowing = true
        appOpenState = AdFormatState.SHOWING

        runOnMain {
            if (activity.isFinishing || activity.isDestroyed) {
                isFullscreenShowing = false
                appOpenState = AdFormatState.LOADED
                updateBannerContainerVisibility()
                return@runOnMain
            }
            coldLaunchWaitingOverlay = false
            hostCallbacksRef?.get()?.onColdLaunchOverlayVisibility(false)
            updateBannerContainerVisibility()
            hostCallbacksRef?.get()?.onFullscreenAdWillShow()

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "[AppOpen] Displayed.")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "[AppOpen] Impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "[AppOpen] Clicked.")
                }

                override fun onAdDismissedFullScreenContent() {
                    runOnMain {
                        appOpenAd = null
                        appOpenState = AdFormatState.NOT_AVAILABLE
                        isFullscreenShowing = false
                        val shownAt = System.currentTimeMillis()
                        lastAppOpenShownMs = shownAt
                        prefs.edit().putLong(KEY_LAST_APP_OPEN_MS, shownAt).apply()
                        Log.i(AdConfig.LOG_TAG, "[AppOpen] Dismissed.")
                        hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                        updateBannerContainerVisibility()
                        preloadAppOpen()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    runOnMain {
                        appOpenAd = null
                        appOpenState = AdFormatState.FAILED
                        isFullscreenShowing = false
                        lastLoadError = "AppOpenShow(${error.code}): ${error.message}"
                        Log.w(AdConfig.LOG_TAG, "[AppOpen] Show failed code=${error.code}: ${error.message}")
                        hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                        updateBannerContainerVisibility()
                        preloadAppOpen()
                    }
                }
            }
            try {
                ad.show(activity)
            } catch (err: Throwable) {
                Log.w(AdConfig.LOG_TAG, "[AppOpen] Exception on show: ${err.message}")
                appOpenAd = null
                appOpenState = AdFormatState.FAILED
                isFullscreenShowing = false
                hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                updateBannerContainerVisibility()
                preloadAppOpen()
            }
        }
        return true
    }

    // =========================================================================
    // 2. ANCHORED ADAPTIVE BANNER AD
    // =========================================================================

    private fun computeAdaptiveAdSize(activity: Activity, container: FrameLayout): AdSize {
        val parentView = container.parent as? View
        var adWidthPx = when {
            container.width > 0 -> container.width.toFloat()
            parentView != null && parentView.width > 0 -> parentView.width.toFloat()
            else -> 0f
        }
        if (adWidthPx <= 0f) {
            adWidthPx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = activity.windowManager.currentWindowMetrics.bounds
                bounds.width().toFloat()
            } else {
                val outMetrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                activity.windowManager.defaultDisplay.getMetrics(outMetrics)
                outMetrics.widthPixels.toFloat()
            }
        }
        val density = activity.resources.displayMetrics.density.coerceAtLeast(1f)
        val adWidthDp = (adWidthPx / density).roundToInt().coerceAtLeast(320)
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidthDp)
    }

    private fun updateBannerContainerVisibility() {
        val container = bannerContainerRef?.get() ?: return
        val canShow =
            bannerShouldBeVisible &&
                currentScreen != "SPLASH" &&
                !isFullscreenShowing &&
                !coldLaunchWaitingOverlay &&
                !isConsentFormBusy() &&
                bannerState == AdFormatState.LOADED &&
                bannerView != null

        val target = if (canShow) View.VISIBLE else View.GONE
        if (container.visibility != target) {
            container.visibility = target
            Log.d(
                AdConfig.LOG_TAG,
                "[Banner] Visibility=${if (canShow) "VISIBLE" else "GONE"} (screen=$currentScreen, state=$bannerState, fullscreen=$isFullscreenShowing)"
            )
        }
    }

    fun showBanner() {
        if (currentScreen == "SPLASH") {
            hideBanner()
            return
        }
        bannerShouldBeVisible = true
        if (!isSdkInitialized || !canRequestAds()) {
            Log.d(AdConfig.LOG_TAG, "[Banner] Queued showBanner until SDK/Consent ready (screen=$currentScreen)")
            return
        }

        runOnMain {
            val activity = activityRef?.get() ?: return@runOnMain
            val container = bannerContainerRef?.get() ?: return@runOnMain
            if (activity.isFinishing || activity.isDestroyed) return@runOnMain

            val adaptiveSize = computeAdaptiveAdSize(activity, container)
            val orientation = activity.resources.configuration.orientation
            val widthDeltaDp = kotlin.math.abs(lastBannerWidthDp - adaptiveSize.width)
            val needsRebuild =
                bannerView == null ||
                    lastBannerWidthDp <= 0 ||
                    widthDeltaDp > WIDTH_HYSTERESIS_DP ||
                    lastBannerOrientation != orientation

            if (needsRebuild) {
                bannerView?.destroy()
                container.removeAllViews()
                lastBannerWidthDp = adaptiveSize.width
                lastBannerOrientation = orientation

                val adView = AdView(activity).apply {
                    adUnitId = AdConfig.activeBannerId
                    setAdSize(adaptiveSize)
                }
                bannerView = adView
                container.addView(
                    adView,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )

                bannerState = AdFormatState.LOADING
                Log.d(
                    AdConfig.LOG_TAG,
                    if (AdConfig.isTestMode) {
                        "[Banner] Load started widthDp=${adaptiveSize.width} (${AdConfig.activeBannerId})"
                    } else {
                        "[Banner] Load started widthDp=${adaptiveSize.width}"
                    }
                )

                adView.adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        runOnMain {
                            bannerState = AdFormatState.LOADED
                            bannerRetryCount = 0
                            updateBannerContainerVisibility()
                            Log.i(AdConfig.LOG_TAG, "[Banner] Loaded on screen=$currentScreen.")
                        }
                    }

                    override fun onAdImpression() {
                        Log.i(AdConfig.LOG_TAG, "[Banner] Impression recorded.")
                    }

                    override fun onAdClicked() {
                        externalAdClickInProgress = true
                        Log.i(AdConfig.LOG_TAG, "[Banner] Clicked.")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        runOnMain {
                            bannerState = AdFormatState.FAILED
                            lastLoadError = "Banner(${error.code}): ${error.message}"
                            Log.w(AdConfig.LOG_TAG, "[Banner] Load failed code=${error.code}: ${error.message}")
                            updateBannerContainerVisibility()
                            if (bannerRetryCount < MAX_RETRY_ATTEMPTS) {
                                val delayMs = min(60_000L, (++bannerRetryCount) * 10_000L)
                                mainHandler.postDelayed({
                                    if (bannerShouldBeVisible && bannerView != null && isSdkInitialized && canRequestAds()) {
                                        bannerState = AdFormatState.LOADING
                                        Log.d(AdConfig.LOG_TAG, "[Banner] Retrying load (attempt $bannerRetryCount)...")
                                        bannerView?.loadAd(AdRequest.Builder().build())
                                    }
                                }, delayMs)
                            }
                        }
                    }
                }
                adView.loadAd(AdRequest.Builder().build())
            } else if (bannerState == AdFormatState.LOADED) {
                updateBannerContainerVisibility()
            } else if (bannerState == AdFormatState.FAILED || bannerState == AdFormatState.NOT_AVAILABLE) {
                bannerRetryCount = 0
                bannerState = AdFormatState.LOADING
                Log.d(AdConfig.LOG_TAG, "[Banner] Reloading after failure/unavailable state...")
                bannerView?.loadAd(AdRequest.Builder().build())
            }
        }
    }

    fun hideBanner() {
        bannerShouldBeVisible = false
        runOnMain {
            updateBannerContainerVisibility()
        }
    }

    fun refreshBannerLayout() {
        runOnMain {
            if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                lastBannerWidthDp = -1 // Trigger adaptive resize on config change
                showBanner()
            }
        }
    }

    // =========================================================================
    // 3. INTERSTITIAL AD
    // =========================================================================

    fun preloadInterstitial() {
        runOnMain {
            if (!isSdkInitialized || !canRequestAds()) return@runOnMain
            if (interstitialState == AdFormatState.LOADING || interstitialAd != null) return@runOnMain

            interstitialState = AdFormatState.LOADING
            Log.d(
                AdConfig.LOG_TAG,
                if (AdConfig.isTestMode) "[Interstitial] Load started (${AdConfig.activeInterstitialId})" else "[Interstitial] Load started"
            )

            InterstitialAd.load(
                appContext,
                AdConfig.activeInterstitialId,
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        runOnMain {
                            interstitialAd = ad
                            interstitialState = AdFormatState.LOADED
                            interstitialRetryCount = 0
                            Log.i(AdConfig.LOG_TAG, "[Interstitial] Loaded.")
                        }
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        runOnMain {
                            interstitialAd = null
                            interstitialState = AdFormatState.FAILED
                            lastLoadError = "Interstitial(${error.code}): ${error.message}"
                            Log.w(AdConfig.LOG_TAG, "[Interstitial] Load failed code=${error.code}: ${error.message}")
                            scheduleRetry(interstitialRetryCount++) { preloadInterstitial() }
                        }
                    }
                }
            )
        }
    }

    fun showInterstitialIfReady(runToken: String = ""): Boolean {
        val activity = activityRef?.get() ?: return false
        if (!canRequestAds() || isConsentFormBusy()) return false
        if (isInActiveGameplay || isInBossFight || currentScreen == "PLAYING" || currentScreen == "PAUSED") {
            Log.d(AdConfig.LOG_TAG, "[Interstitial] Blocked during gameplay/boss fight.")
            return false
        }
        if (isFullscreenShowing) {
            Log.d(AdConfig.LOG_TAG, "[Interstitial] Blocked: another full-screen ad is showing.")
            return false
        }
        if (runToken.isNotEmpty() && runToken == lastCompletedLevelToken) {
            Log.d(AdConfig.LOG_TAG, "[Interstitial] Blocked: duplicate request for same level completion.")
            return false
        }

        val now = System.currentTimeMillis()
        if (now - lastInterstitialShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "[Interstitial] Skipped: 3-minute cooldown active.")
            return false
        }
        if (now - lastAppOpenShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS) {
            Log.d(AdConfig.LOG_TAG, "[Interstitial] Skipped: too soon after App Open ad.")
            return false
        }

        val ad = interstitialAd ?: run {
            preloadInterstitial()
            return false
        }

        if (runToken.isNotEmpty()) {
            lastCompletedLevelToken = runToken
        }
        isFullscreenShowing = true
        interstitialState = AdFormatState.SHOWING

        runOnMain {
            if (activity.isFinishing || activity.isDestroyed) {
                isFullscreenShowing = false
                interstitialState = AdFormatState.LOADED
                updateBannerContainerVisibility()
                return@runOnMain
            }
            updateBannerContainerVisibility()
            hostCallbacksRef?.get()?.onFullscreenAdWillShow()

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "[Interstitial] Displayed.")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "[Interstitial] Impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "[Interstitial] Clicked.")
                }

                override fun onAdDismissedFullScreenContent() {
                    runOnMain {
                        interstitialAd = null
                        interstitialState = AdFormatState.NOT_AVAILABLE
                        isFullscreenShowing = false
                        lastInterstitialShownMs = System.currentTimeMillis()
                        Log.i(AdConfig.LOG_TAG, "[Interstitial] Dismissed.")
                        hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                        updateBannerContainerVisibility()
                        preloadInterstitial()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    runOnMain {
                        interstitialAd = null
                        interstitialState = AdFormatState.FAILED
                        isFullscreenShowing = false
                        lastLoadError = "InterstitialShow(${error.code}): ${error.message}"
                        Log.w(AdConfig.LOG_TAG, "[Interstitial] Show failed code=${error.code}: ${error.message}")
                        hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                        updateBannerContainerVisibility()
                        preloadInterstitial()
                    }
                }
            }
            try {
                ad.show(activity)
            } catch (err: Throwable) {
                Log.w(AdConfig.LOG_TAG, "[Interstitial] Exception on show: ${err.message}")
                interstitialAd = null
                interstitialState = AdFormatState.FAILED
                isFullscreenShowing = false
                hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                updateBannerContainerVisibility()
                preloadInterstitial()
            }
        }
        return true
    }

    fun showInterstitialForTransition(runToken: String = "") {
        runOnMain {
            val activity = activityRef?.get()
            if (activity == null ||
                !canRequestAds() ||
                isConsentFormBusy() ||
                isInActiveGameplay ||
                isInBossFight ||
                currentScreen == "PLAYING" ||
                currentScreen == "PAUSED" ||
                isFullscreenShowing
            ) {
                hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
                return@runOnMain
            }
            if (runToken.isNotEmpty() && runToken == lastCompletedLevelToken) {
                hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
                return@runOnMain
            }
            val now = System.currentTimeMillis()
            if (now - lastInterstitialShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS ||
                now - lastAppOpenShownMs < AdConfig.INTERSTITIAL_COOLDOWN_MS
            ) {
                hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
                return@runOnMain
            }
            val ad = interstitialAd ?: run {
                preloadInterstitial()
                hostCallbacksRef?.get()?.onTransitionInterstitialFinished(false)
                return@runOnMain
            }

            if (runToken.isNotEmpty()) {
                lastCompletedLevelToken = runToken
            }
            isFullscreenShowing = true
            interstitialState = AdFormatState.SHOWING
            var finished = false
            fun completeTransition(shown: Boolean) {
                if (finished) return
                finished = true
                isFullscreenShowing = false
                hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                hostCallbacksRef?.get()?.onTransitionInterstitialFinished(shown)
                updateBannerContainerVisibility()
                preloadInterstitial()
            }

            if (activity.isFinishing || activity.isDestroyed) {
                interstitialState = AdFormatState.LOADED
                completeTransition(false)
                return@runOnMain
            }

            updateBannerContainerVisibility()
            hostCallbacksRef?.get()?.onFullscreenAdWillShow()

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "[Interstitial] Transition displayed.")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "[Interstitial] Transition impression recorded.")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "[Interstitial] Transition clicked.")
                }

                override fun onAdDismissedFullScreenContent() {
                    runOnMain {
                        interstitialAd = null
                        interstitialState = AdFormatState.NOT_AVAILABLE
                        lastInterstitialShownMs = System.currentTimeMillis()
                        Log.i(AdConfig.LOG_TAG, "[Interstitial] Transition dismissed.")
                        completeTransition(true)
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    runOnMain {
                        interstitialAd = null
                        interstitialState = AdFormatState.FAILED
                        lastLoadError = "InterstitialShow(${error.code}): ${error.message}"
                        Log.w(AdConfig.LOG_TAG, "[Interstitial] Transition show failed code=${error.code}: ${error.message}")
                        completeTransition(false)
                    }
                }
            }
            try {
                ad.show(activity)
            } catch (err: Throwable) {
                Log.w(AdConfig.LOG_TAG, "[Interstitial] Exception on transition show: ${err.message}")
                interstitialAd = null
                interstitialState = AdFormatState.FAILED
                completeTransition(false)
            }
        }
    }

    // =========================================================================
    // 4. NATIVE ADVANCED AD (Genuine NativeAdView with Media & AdChoices)
    // =========================================================================

    fun preloadNativeAd() {
        runOnMain {
            if (!isSdkInitialized || !canRequestAds()) return@runOnMain
            if (nativeState == AdFormatState.LOADING || cachedNativeAd != null) return@runOnMain

            nativeState = AdFormatState.LOADING
            Log.d(
                AdConfig.LOG_TAG,
                if (AdConfig.isTestMode) "[Native] Load started (${AdConfig.activeNativeId})" else "[Native] Load started"
            )

            val options = NativeAdOptions.Builder()
                .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                .build()

            val loaderContext: Context =
                activityRef?.get()?.takeUnless { it.isFinishing || it.isDestroyed } ?: appContext

            val loader = AdLoader.Builder(loaderContext, AdConfig.activeNativeId)
                .forNativeAd { nativeAd ->
                    runOnMain {
                        cachedNativeAd?.destroy()
                        cachedNativeAd = nativeAd
                        nativeState = AdFormatState.LOADED
                        nativeRetryCount = 0
                        Log.i(AdConfig.LOG_TAG, "[Native] Loaded (${nativeAd.headline}).")
                        hostCallbacksRef?.get()?.onNativeAdAvailabilityChanged(true)
                        renderBoundNativeAd()
                    }
                }
                .withAdListener(object : AdListener() {
                    override fun onAdImpression() {
                        Log.i(AdConfig.LOG_TAG, "[Native] Impression recorded.")
                    }

                    override fun onAdClicked() {
                        externalAdClickInProgress = true
                        Log.i(AdConfig.LOG_TAG, "[Native] Clicked.")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        runOnMain {
                            nativeState = AdFormatState.FAILED
                            lastLoadError = "Native(${error.code}): ${error.message}"
                            Log.w(AdConfig.LOG_TAG, "[Native] Load failed code=${error.code}: ${error.message}")
                            hostCallbacksRef?.get()?.onNativeAdAvailabilityChanged(false)
                            scheduleRetry(nativeRetryCount++) { preloadNativeAd() }
                        }
                    }
                })
                .withNativeAdOptions(options)
                .build()

            loader.loadAd(AdRequest.Builder().build())
        }
    }

    fun bindNativeAdOverlay(xRatio: Float, yRatio: Float, wRatio: Float, hRatio: Float) {
        nativeSlotBounds = SlotBounds(xRatio, yRatio, wRatio, hRatio)
        runOnMain { renderBoundNativeAd() }
    }

    fun hideNativeAdOverlay() {
        nativeSlotBounds = null
        runOnMain {
            nativeContainerRef?.get()?.let { container ->
                container.visibility = View.GONE
                container.isClickable = false
                container.isFocusable = false
                container.removeAllViews()
            }
        }
    }

    private fun renderBoundNativeAd() {
        val bounds = nativeSlotBounds ?: run {
            nativeContainerRef?.get()?.let { container ->
                container.visibility = View.GONE
                container.isClickable = false
                container.isFocusable = false
            }
            return
        }
        val activity = activityRef?.get() ?: return
        val container = nativeContainerRef?.get() ?: return
        val ad = cachedNativeAd ?: run {
            container.visibility = View.GONE
            container.isClickable = false
            container.isFocusable = false
            preloadNativeAd()
            return
        }
        if (isInActiveGameplay ||
            isFullscreenShowing ||
            bounds.wRatio <= 0.05f ||
            bounds.hRatio <= 0.05f
        ) {
            container.visibility = View.GONE
            container.isClickable = false
            container.isFocusable = false
            return
        }

        val parent = container.parent as? View ?: return
        val parentW = parent.width
        val parentH = parent.height
        if (parentW <= 0 || parentH <= 0) {
            parent.post { renderBoundNativeAd() }
            return
        }

        val density = activity.resources.displayMetrics.density.coerceAtLeast(1f)
        val pxX = (bounds.xRatio * parentW).roundToInt().coerceAtLeast(0)
        val pxY = (bounds.yRatio * parentH).roundToInt().coerceAtLeast(0)
        val pxW = (bounds.wRatio * parentW).roundToInt().coerceIn(min((180 * density).roundToInt(), parentW), parentW)
        val pxH = (bounds.hRatio * parentH).roundToInt().coerceIn(min((64 * density).roundToInt(), parentH), parentH)
        val dpW = (pxW / density).roundToInt()
        val dpH = (pxH / density).roundToInt()

        val lp = FrameLayout.LayoutParams(pxW, pxH).apply {
            leftMargin = pxX
            topMargin = pxY
        }
        container.layoutParams = lp

        container.removeAllViews()
        val adView = LayoutInflater.from(activity)
            .inflate(R.layout.native_ad_layout, container, false) as NativeAdView

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        val advertiserView = adView.findViewById<TextView>(R.id.ad_advertiser)
        val ctaView = adView.findViewById<Button>(R.id.ad_call_to_action)
        val iconView = adView.findViewById<ImageView>(R.id.ad_app_icon)
        val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
        val choicesView = adView.findViewById<AdChoicesView>(R.id.ad_choices_view)

        adView.headlineView = headlineView
        adView.bodyView = bodyView
        adView.advertiserView = advertiserView
        adView.callToActionView = ctaView
        adView.iconView = iconView
        adView.mediaView = mediaView
        adView.adChoicesView = choicesView

        headlineView.text = ad.headline ?: ""
        bodyView.text = ad.body ?: ""
        bodyView.visibility = if (ad.body.isNullOrBlank()) View.GONE else View.VISIBLE
        advertiserView.text = ad.advertiser ?: "Sponsored"

        if (ad.callToAction.isNullOrBlank()) {
            ctaView.visibility = View.GONE
        } else {
            ctaView.visibility = View.VISIBLE
            ctaView.text = ad.callToAction
        }

        if (ad.icon != null) {
            iconView.setImageDrawable(ad.icon?.drawable)
            iconView.visibility = View.VISIBLE
        } else {
            iconView.visibility = View.GONE
        }

        if (ad.mediaContent != null && dpW >= 340 && dpH >= 72) {
            mediaView.mediaContent = ad.mediaContent
            mediaView.visibility = View.VISIBLE
        } else {
            mediaView.visibility = View.GONE
        }

        adView.setNativeAd(ad)
        container.addView(adView)
        container.isClickable = true
        container.isFocusable = true
        container.visibility = View.VISIBLE
    }

    fun isNativeLoaded(): Boolean = cachedNativeAd != null && nativeState == AdFormatState.LOADED

    // =========================================================================
    // 5. REWARDED AD (Strictly opt-in, earned callback guarded)
    // =========================================================================

    fun preloadRewarded() {
        runOnMain {
            if (!isSdkInitialized || !canRequestAds()) return@runOnMain
            if (rewardedState == AdFormatState.LOADING || rewardedAd != null) return@runOnMain

            rewardedState = AdFormatState.LOADING
            hostCallbacksRef?.get()?.onRewardedAdAvailabilityChanged(false)
            Log.d(
                AdConfig.LOG_TAG,
                if (AdConfig.isTestMode) "[Rewarded] Load started (${AdConfig.activeRewardedId})" else "[Rewarded] Load started"
            )

            RewardedAd.load(
                appContext,
                AdConfig.activeRewardedId,
                AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        runOnMain {
                            rewardedAd = ad
                            rewardedState = AdFormatState.LOADED
                            rewardedRetryCount = 0
                            Log.i(AdConfig.LOG_TAG, "[Rewarded] Loaded.")
                            hostCallbacksRef?.get()?.onRewardedAdAvailabilityChanged(true)
                        }
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        runOnMain {
                            rewardedAd = null
                            rewardedState = AdFormatState.FAILED
                            lastLoadError = "Rewarded(${error.code}): ${error.message}"
                            Log.w(AdConfig.LOG_TAG, "[Rewarded] Load failed code=${error.code}: ${error.message}")
                            hostCallbacksRef?.get()?.onRewardedAdAvailabilityChanged(false)
                            scheduleRetry(rewardedRetryCount++) { preloadRewarded() }
                        }
                    }
                }
            )
        }
    }

    fun isRewardedReady(): Boolean = rewardedAd != null && rewardedState == AdFormatState.LOADED

    fun showRewarded(placement: String, onCompleted: (Boolean) -> Unit) {
        runOnMain {
            val activity = activityRef?.get()
            if (activity == null || !canRequestAds() || isConsentFormBusy() || isFullscreenShowing) {
                Log.d(AdConfig.LOG_TAG, "[Rewarded] Unavailable/busy for $placement.")
                onCompleted(false)
                return@runOnMain
            }

            val ad = rewardedAd ?: run {
                preloadRewarded()
                Log.w(AdConfig.LOG_TAG, "[Rewarded] Not loaded when requested ($placement).")
                hostCallbacksRef?.get()?.onRewardedAdAvailabilityChanged(false)
                onCompleted(false)
                return@runOnMain
            }

            isFullscreenShowing = true
            rewardedState = AdFormatState.SHOWING
            hostCallbacksRef?.get()?.onRewardedAdAvailabilityChanged(false)
            var rewardEarned = false
            var callbackDispatched = false

            fun finishOnce(granted: Boolean) {
                if (callbackDispatched) return
                callbackDispatched = true
                isFullscreenShowing = false
                hostCallbacksRef?.get()?.onFullscreenAdDismissed()
                updateBannerContainerVisibility()
                onCompleted(granted)
                preloadRewarded()
            }

            if (activity.isFinishing || activity.isDestroyed) {
                rewardedState = AdFormatState.LOADED
                finishOnce(false)
                return@runOnMain
            }

            updateBannerContainerVisibility()
            hostCallbacksRef?.get()?.onFullscreenAdWillShow()

            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    Log.i(AdConfig.LOG_TAG, "[Rewarded] Displayed ($placement).")
                }

                override fun onAdImpression() {
                    Log.i(AdConfig.LOG_TAG, "[Rewarded] Impression recorded ($placement).")
                }

                override fun onAdClicked() {
                    externalAdClickInProgress = true
                    Log.i(AdConfig.LOG_TAG, "[Rewarded] Clicked ($placement).")
                }

                override fun onAdDismissedFullScreenContent() {
                    runOnMain {
                        rewardedAd = null
                        rewardedState = AdFormatState.NOT_AVAILABLE
                        Log.i(AdConfig.LOG_TAG, "[Rewarded] Dismissed ($placement), earned=$rewardEarned")
                        finishOnce(rewardEarned)
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    runOnMain {
                        rewardedAd = null
                        rewardedState = AdFormatState.FAILED
                        lastLoadError = "RewardedShow(${error.code}): ${error.message}"
                        Log.w(AdConfig.LOG_TAG, "[Rewarded] Show failed code=${error.code}: ${error.message}")
                        finishOnce(false)
                    }
                }
            }

            try {
                ad.show(activity) { rewardItem ->
                    rewardEarned = true
                    Log.i(
                        AdConfig.LOG_TAG,
                        "[Rewarded] User earned reward ($placement): ${rewardItem.amount} ${rewardItem.type}"
                    )
                }
            } catch (err: Throwable) {
                Log.w(AdConfig.LOG_TAG, "[Rewarded] Exception on show: ${err.message}")
                rewardedAd = null
                rewardedState = AdFormatState.FAILED
                finishOnce(false)
            }
        }
    }

    // =========================================================================
    // RETRY, LIFECYCLE & DEBUG DIAGNOSTICS
    // =========================================================================

    private fun scheduleRetry(attempt: Int, action: () -> Unit) {
        if (attempt >= MAX_RETRY_ATTEMPTS) return
        val delayMs = min(60_000L, (attempt + 1) * 12_000L)
        mainHandler.postDelayed({
            if (isSdkInitialized && canRequestAds()) {
                action()
            }
        }, delayMs)
    }

    fun getDebugStatusJson(): String {
        if (!BuildConfig.DEBUG) return "{}"
        val obj = JSONObject()
        obj.put("mode", if (AdConfig.isTestMode) "TEST_ADS" else "PRODUCTION")
        obj.put("sdkInitialized", isSdkInitialized)
        obj.put("consentStatus", consentManager?.statusLabel ?: "UNKNOWN")
        obj.put("canRequestAds", canRequestAds())
        obj.put("privacyOptionsRequired", consentManager?.isPrivacyOptionsRequired ?: false)
        obj.put("appOpenState", appOpenState.name)
        obj.put("bannerState", bannerState.name)
        obj.put("interstitialState", interstitialState.name)
        obj.put("nativeState", nativeState.name)
        obj.put("rewardedState", rewardedState.name)
        obj.put("lastLoadError", lastLoadError)
        return obj.toString()
    }

    fun onActivityPaused() {
        runOnMain {
            bannerView?.pause()
        }
    }

    fun onActivityResumed() {
        runOnMain {
            bannerView?.resume()
            if (!isSdkInitialized || !canRequestAds()) return@runOnMain

            // Recover any format that exhausted retries while offline or backgrounded
            if (bannerShouldBeVisible && currentScreen != "SPLASH") {
                if (bannerView == null || bannerState == AdFormatState.FAILED) {
                    bannerRetryCount = 0
                    showBanner()
                } else {
                    updateBannerContainerVisibility()
                }
            }
            if (interstitialState == AdFormatState.FAILED || interstitialAd == null) {
                interstitialRetryCount = 0
                preloadInterstitial()
            }
            if (rewardedState == AdFormatState.FAILED || rewardedAd == null) {
                rewardedRetryCount = 0
                preloadRewarded()
            }
            if (nativeState == AdFormatState.FAILED || cachedNativeAd == null) {
                nativeRetryCount = 0
                preloadNativeAd()
            }
            if (appOpenState == AdFormatState.FAILED || !isAppOpenAvailable()) {
                appOpenRetryCount = 0
                preloadAppOpen()
            }
        }
    }

    fun releaseCachedNative() {
        runOnMain {
            cachedNativeAd?.destroy()
            cachedNativeAd = null
        }
    }
}
