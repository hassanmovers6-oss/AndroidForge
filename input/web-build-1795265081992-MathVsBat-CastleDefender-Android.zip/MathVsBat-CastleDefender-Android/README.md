# Math vs Bat – Castle Defender (Android Studio Project)

- **Developer:** Rana Hassan
- **Package Name:** `com.educationwithhassan.mathvsbat`
- **Platform:** Android (Native Kotlin + Jetpack Compose Shell + Shared WebViewAssetLoader 2D Canvas Game Engine)
- **Orientation:** Portrait
- **Mode:** 100% Offline Single-Player + Full Google AdMob & UMP Consent Integration

## Shared Preview-to-APK Architecture
- `app/src/main/assets/www/` packages the exact compiled HTML5 Canvas / React game bundle used in Preview, served 100% offline via `androidx.webkit.WebViewAssetLoader` (`https://appassets.androidplatform.net/assets/www/index.html`).
- Visual design, castle artwork, animated cartoon bats, 100 levels, 6 math modes, audio, and gameplay logic are 100% identical between Preview and Android APK.
- `MainActivity.kt` bridges the game via `AndroidNativeBridge` directly into native Google Mobile Ads SDK (`AdMobManager.kt`), native Adaptive Banner & Native Advanced Ad views, Android hardware back button, and native device haptics.

## AdMob Configuration (Test vs Production)
- **Debug builds** automatically use **Google's official test AdMob App ID and Ad Unit IDs** (`BuildConfig.USE_TEST_ADS = true`). Never click live production ads during testing!
- **Release builds** automatically use your exact production IDs:
  - App ID: `ca-app-pub-3133971041724338~1455863450`
  - App Open: `ca-app-pub-3133971041724338/8379002010`
  - Banner: `ca-app-pub-3133971041724338/9142781786`
  - Interstitial: `ca-app-pub-3133971041724338/7638128425`
  - Native Advanced: `ca-app-pub-3133971041724338/7520999346`
  - Rewarded: `ca-app-pub-3133971041724338/1281884898`

## Opening & Building in Android Studio
1. Extract this ZIP archive into a clean folder.
2. Open **Android Studio** (Koala / Ladybug or newer) and select **Open** -> choose the extracted root folder.
3. Let Gradle sync finish (compileSdk 35, targetSdk 35, minSdk 24, JDK 17).
4. Click **Run** on an Android device/emulator (uses test ads) or run `./gradlew assembleRelease` / **Build > Generate Signed Bundle / APK**.
