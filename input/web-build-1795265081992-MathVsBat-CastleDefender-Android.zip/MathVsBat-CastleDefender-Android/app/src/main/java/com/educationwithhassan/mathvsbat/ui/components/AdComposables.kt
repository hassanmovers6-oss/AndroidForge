package com.educationwithhassan.mathvsbat.ui.components

import android.view.LayoutInflater
import android.widget.Button as AndroidNativeButton
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.mathvsbat.R
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

@Composable
fun AdaptiveBannerAd(modifier: Modifier = Modifier) {
    if (!AdMobManager.canRequestAds()) return
    val context = LocalContext.current
    val widthDp = LocalConfiguration.current.screenWidthDp
    var adLoaded by remember { mutableStateOf(false) }

    val adView = remember(widthDp) {
        AdView(context).apply {
            adUnitId = AdMobManager.bannerUnitId()
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp))
            adListener = object : AdListener() {
                override fun onAdLoaded() { adLoaded = true }
                override fun onAdFailedToLoad(err: LoadAdError) { adLoaded = false }
            }
            loadAd(AdRequest.Builder().build())
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        if (adLoaded) {
            AndroidView(factory = { adView }, modifier = Modifier.fillMaxWidth())
        } else {
            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}

@Composable
fun NativeAdBanner(modifier: Modifier = Modifier) {
    if (!AdMobManager.canRequestAds()) return
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        AdMobManager.loadNativeAd(
            context = context,
            onLoaded = { ad ->
                nativeAd?.destroy()
                nativeAd = ad
            },
            onFailed = { /* Keep screen clean on load failure */ }
        )
        onDispose {
            nativeAd?.destroy()
            nativeAd = null
        }
    }

    val ad = nativeAd ?: return
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            val view = LayoutInflater.from(ctx).inflate(R.layout.native_ad_layout, null) as NativeAdView
            val headlineView = view.findViewById<TextView>(R.id.ad_headline)
            val bodyView = view.findViewById<TextView>(R.id.ad_body)
            val ctaView = view.findViewById<AndroidNativeButton>(R.id.ad_call_to_action)
            val iconView = view.findViewById<ImageView>(R.id.ad_app_icon)

            headlineView.text = ad.headline
            bodyView.text = ad.body ?: ""
            ctaView.text = ad.callToAction ?: "Learn More"
            ad.icon?.drawable?.let { iconView.setImageDrawable(it) }

            view.headlineView = headlineView
            view.bodyView = bodyView
            view.callToActionView = ctaView
            view.iconView = iconView
            view.setNativeAd(ad)
            view
        }
    )
}
