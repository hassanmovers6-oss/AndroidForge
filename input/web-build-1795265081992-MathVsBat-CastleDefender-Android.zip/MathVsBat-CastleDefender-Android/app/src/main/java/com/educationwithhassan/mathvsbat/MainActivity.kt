package com.educationwithhassan.mathvsbat

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.educationwithhassan.mathvsbat.ui.components.AdaptiveBannerAd
import com.educationwithhassan.mathvsbat.ui.components.NativeAdBanner
import com.educationwithhassan.mathvsbat.ui.theme.CastleDarkBg
import com.educationwithhassan.mathvsbat.ui.theme.MathVsBatTheme
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var gameWebView: WebView
    private var showNativeAdSlot by mutableStateOf(false)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ProcessLifecycleOwner.get().lifecycle.addObserver(AdMobManager)
        AdMobManager.initialize(this)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        if (BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true)
        }

        gameWebView = WebView(this).apply {
            setBackgroundColor(AndroidColor.parseColor("#0E1529"))
            overScrollMode = WebView.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                useWideViewPort = true
                loadWithOverviewMode = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val host = request.url.host ?: return true
                    return host != "appassets.androidplatform.net"
                }
            }
            addJavascriptInterface(AndroidBridge(), "AndroidNativeBridge")
            loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::gameWebView.isInitialized) {
                    gameWebView.evaluateJavascript(
                        "(function(){ return window.__onAndroidBackPressed ? window.__onAndroidBackPressed() : false; })()"
                    ) { result ->
                        if (result != "true") {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        }
                    }
                }
            }
        })

        setContent {
            MathVsBatTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(CastleDarkBg)
                        .safeDrawingPadding(),
                    color = CastleDarkBg
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (showNativeAdSlot) {
                            NativeAdBanner(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        AndroidView(
                            factory = { gameWebView },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )
                        AdaptiveBannerAd()
                    }
                }
            }
        }
    }

    private fun dispatchJs(script: String) {
        runOnUiThread {
            if (::gameWebView.isInitialized) {
                gameWebView.evaluateJavascript(script, null)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun triggerVibration(durationMs: Long) {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator.vibrate(durationMs)
            }
        } catch (_: Throwable) {
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun isNativeAndroid(): Boolean = true

        @JavascriptInterface
        fun setRoute(route: String) {
            runOnUiThread {
                AdMobManager.setGameplayActive(route == "gameplay")
                showNativeAdSlot = route == "levels" || route == "modes" || route == "daily" || route == "profile"
            }
        }

        @JavascriptInterface
        fun showRewardedAd(callbackId: String) {
            val safeId = JSONObject.quote(callbackId)
            runOnUiThread {
                AdMobManager.showRewarded(
                    activity = this@MainActivity,
                    onRewardEarnedOnce = {
                        dispatchJs("window.__onAndroidRewardedResult && window.__onAndroidRewardedResult($safeId, true, '')")
                    },
                    onClosedWithoutReward = {
                        dispatchJs("window.__onAndroidRewardedResult && window.__onAndroidRewardedResult($safeId, false, 'Ad closed before completion — reward not granted.')")
                    },
                    onUnavailable = {
                        dispatchJs("window.__onAndroidRewardedResult && window.__onAndroidRewardedResult($safeId, false, 'No rewarded ad available right now. Continue playing!')")
                    }
                )
            }
        }

        @JavascriptInterface
        fun maybeShowInterstitial(callbackId: String, countLevelWin: Boolean) {
            val safeId = JSONObject.quote(callbackId)
            runOnUiThread {
                AdMobManager.maybeShowInterstitial(this@MainActivity, countLevelWin) {
                    dispatchJs("window.__onAndroidInterstitialDone && window.__onAndroidInterstitialDone($safeId)")
                }
            }
        }

        @JavascriptInterface
        fun showPrivacyOptions() {
            runOnUiThread {
                AdMobManager.showPrivacyOptionsForm(this@MainActivity) {}
            }
        }

        @JavascriptInterface
        fun vibrate(durationMs: Long) {
            triggerVibration(durationMs.coerceIn(15L, 400L))
        }
    }

    override fun onPause() {
        super.onPause()
        if (::gameWebView.isInitialized) {
            dispatchJs("window.__onAndroidLifecycle && window.__onAndroidLifecycle('pause')")
            gameWebView.onPause()
        }
    }

    override fun onResume() {
        super.onResume()
        AdMobManager.setCurrentActivity(this)
        if (::gameWebView.isInitialized) {
            gameWebView.onResume()
            dispatchJs("window.__onAndroidLifecycle && window.__onAndroidLifecycle('resume')")
        }
    }

    override fun onDestroy() {
        if (::gameWebView.isInitialized) {
            gameWebView.removeJavascriptInterface("AndroidNativeBridge")
            gameWebView.destroy()
        }
        super.onDestroy()
    }
}
