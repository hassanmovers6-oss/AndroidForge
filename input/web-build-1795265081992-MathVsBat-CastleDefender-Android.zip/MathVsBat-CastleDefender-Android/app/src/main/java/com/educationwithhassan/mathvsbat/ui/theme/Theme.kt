package com.educationwithhassan.mathvsbat.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CastleDarkBg = Color(0xFF0E1529)
val CastlePanel = Color(0xFF1B2749)
val ArcaneCyan = Color(0xFF22D3EE)
val EmeraldAction = Color(0xFF10B981)
val AmberGold = Color(0xFFF59E0B)

private val DarkScheme = darkColorScheme(
    primary = EmeraldAction,
    secondary = ArcaneCyan,
    tertiary = AmberGold,
    background = CastleDarkBg,
    surface = CastlePanel,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun MathVsBatTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
