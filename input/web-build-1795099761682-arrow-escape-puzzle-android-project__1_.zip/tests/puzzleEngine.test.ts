import assert from 'node:assert/strict';
import test from 'node:test';
import { getAllLevels, TOTAL_LEVELS } from '../src/data/levelRepository';
import {
  DEFAULT_PROGRESS,
  loadProgress,
  markLevelCompleted,
  resetAllProgress,
  StorageBackend,
} from '../src/data/progressRepository';
import {
  hitTestArrow,
  isArrowFree,
} from '../src/domain/engine/collisionEngine';
import {
  createInitialGameState,
  grantBonusHints,
  restartLevel,
  reviveWithExtraLife,
  tapArrow,
  useHint,
} from '../src/domain/engine/puzzleEngine';
import {
  pickBestHintArrow,
  solveLevel,
  validateSolutionSequence,
} from '../src/domain/engine/puzzleSolver';
import { Arrow, Level } from '../src/domain/model/types';

function makeArrow(
  id: number,
  direction: Arrow['direction'],
  points: { x: number; y: number }[],
  pathWidth = 0.03
): Arrow {
  const segments = [];
  for (let i = 1; i < points.length; i++) {
    segments.push({ start: points[i - 1], end: points[i] });
  }
  return {
    id,
    direction,
    segments,
    exitPoint: points[points.length - 1],
    pathWidth,
  };
}

function makeMockLevel(id: number, arrows: Arrow[]): Level {
  return {
    id,
    difficulty: 'EASY',
    gridSize: 5,
    arrows,
    startingLives: 3,
    startingHints: 2,
    metrics: {
      arrowCount: arrows.length,
      initiallyFreeCount: 1,
      maxDependencyDepth: 1,
      avgAvailableMoves: 1,
      misleadingBlockedCount: 0,
      totalTurns: 0,
      boardDensity: 0.1,
      difficultyScore: 10,
    },
  };
}

test('CollisionEngine: clear arrow, blocked arrow, removed arrow, and perpendicular geometry', () => {
  const rightArrow = makeArrow(1, 'RIGHT', [
    { x: 0.2, y: 0.5 },
    { x: 0.4, y: 0.5 },
  ]);
  const perpendicularBlocker = makeArrow(2, 'UP', [
    { x: 0.7, y: 0.7 },
    { x: 0.7, y: 0.3 },
  ]);
  const parallelNeighbor = makeArrow(3, 'RIGHT', [
    { x: 0.2, y: 0.85 },
    { x: 0.4, y: 0.85 },
  ]);

  const active = [rightArrow, perpendicularBlocker, parallelNeighbor];
  assert.equal(isArrowFree(rightArrow, active), false);
  assert.equal(isArrowFree(perpendicularBlocker, active), true);
  assert.equal(isArrowFree(parallelNeighbor, active), true);

  // Removing perpendicularBlocker frees rightArrow
  const afterRemoval = active.filter((a) => a.id !== perpendicularBlocker.id);
  assert.equal(isArrowFree(rightArrow, afterRemoval), true);
});

test('CollisionEngine: hitTestArrow detects segments, corners, arrowheads, and chooses closest', () => {
  const bentArrow = makeArrow(1, 'RIGHT', [
    { x: 0.2, y: 0.2 },
    { x: 0.2, y: 0.5 },
    { x: 0.45, y: 0.5 },
  ]);
  const nearbyArrow = makeArrow(2, 'DOWN', [
    { x: 0.7, y: 0.2 },
    { x: 0.7, y: 0.5 },
  ]);
  const arrows = [bentArrow, nearbyArrow];

  // Tap on vertical segment of bentArrow
  assert.equal(hitTestArrow({ x: 0.21, y: 0.35 }, arrows)?.id, 1);
  // Tap on corner of bentArrow
  assert.equal(hitTestArrow({ x: 0.2, y: 0.5 }, arrows)?.id, 1);
  // Tap on arrowhead tip of bentArrow
  assert.equal(hitTestArrow({ x: 0.465, y: 0.5 }, arrows)?.id, 1);
  // Tap on nearbyArrow
  assert.equal(hitTestArrow({ x: 0.7, y: 0.35 }, arrows)?.id, 2);
  // Tap in empty space far away
  assert.equal(hitTestArrow({ x: 0.9, y: 0.9 }, arrows), null);
});

test('PuzzleSolver: solves solvable level and rejects impossible cycle', () => {
  const a1 = makeArrow(1, 'RIGHT', [
    { x: 0.2, y: 0.3 },
    { x: 0.4, y: 0.3 },
  ]);
  const a2 = makeArrow(2, 'UP', [
    { x: 0.6, y: 0.5 },
    { x: 0.6, y: 0.2 },
  ]);
  const solvableLevel = makeMockLevel(101, [a1, a2]);
  const solved = solveLevel(solvableLevel);

  assert.equal(solved.solvable, true);
  assert.deepEqual(solved.moveSequence, [2, 1]);
  assert.equal(validateSolutionSequence(solvableLevel, solved.moveSequence), true);

  // Deadlock 2-cycle: b1 points RIGHT into b2, b2 points LEFT into b1? Or 4-cycle!
  const c1 = makeArrow(1, 'RIGHT', [{ x: 0.2, y: 0.3 }, { x: 0.3, y: 0.3 }]);
  const c2 = makeArrow(2, 'DOWN', [{ x: 0.6, y: 0.2 }, { x: 0.6, y: 0.4 }]);
  const c3 = makeArrow(3, 'LEFT', [{ x: 0.7, y: 0.7 }, { x: 0.5, y: 0.7 }]);
  const c4 = makeArrow(4, 'UP', [{ x: 0.2, y: 0.8 }, { x: 0.2, y: 0.6 }]);
  // c1 blocked by c2 (at x=0.6, y in 0.2..0.4); c2 blocked by c3 (at y=0.7, x in 0.5..0.7);
  // c3 blocked by c4 (at x=0.2, y in 0.6..0.8); c4 blocked by c1 (at y=0.3, x in 0.2..0.3)
  const impossibleLevel = makeMockLevel(102, [c1, c2, c3, c4]);
  const impossibleRes = solveLevel(impossibleLevel);

  assert.equal(impossibleRes.solvable, false);
  assert.equal(impossibleRes.moveSequence.length, 0);
});

test('PuzzleEngine: valid tap, blocked tap, game over, completion, restart, and intelligent hint', () => {
  const blocked = makeArrow(1, 'RIGHT', [
    { x: 0.2, y: 0.5 },
    { x: 0.4, y: 0.5 },
  ]);
  const blocker = makeArrow(2, 'UP', [
    { x: 0.7, y: 0.7 },
    { x: 0.7, y: 0.3 },
  ]);
  const level = makeMockLevel(1, [blocked, blocker]);

  let state = createInitialGameState(level);
  assert.equal(state.lives, 3);
  assert.equal(state.hintsRemaining, 2);

  // Intelligent hint must choose blocker (#2), NOT blocked (#1)
  const hintRes = useHint(state);
  assert.equal(hintRes.hintedArrowId, 2);
  assert.equal(hintRes.nextState.hintsRemaining, 1);
  assert.equal(pickBestHintArrow(state.remainingArrows)?.id, 2);

  // Blocked tap reduces life
  const blockedTap = tapArrow(hintRes.nextState, 1);
  assert.equal(blockedTap.outcome, 'BLOCKED');
  assert.equal(blockedTap.nextState.lives, 2);
  assert.equal(blockedTap.nextState.isGameOver, false);

  // Two more blocked taps trigger game over
  const tap2 = tapArrow(blockedTap.nextState, 1);
  assert.equal(tap2.nextState.lives, 1);
  const tap3 = tapArrow(tap2.nextState, 1);
  assert.equal(tap3.nextState.lives, 0);
  assert.equal(tap3.nextState.isGameOver, true);

  // Restart restores initial state
  state = restartLevel(level);
  assert.equal(state.lives, 3);
  assert.equal(state.isGameOver, false);
  assert.equal(state.remainingArrows.length, 2);

  // Valid taps clear board and trigger completion
  const escape1 = tapArrow(state, 2);
  assert.equal(escape1.outcome, 'ESCAPED');
  assert.equal(escape1.nextState.remainingArrows.length, 1);
  assert.equal(escape1.nextState.isComplete, false);

  const escape2 = tapArrow(escape1.nextState, 1);
  assert.equal(escape2.outcome, 'ESCAPED');
  assert.equal(escape2.nextState.remainingArrows.length, 0);
  assert.equal(escape2.nextState.isComplete, true);
});

test('PuzzleEngine: grantBonusHints and reviveWithExtraLife reward transitions', () => {
  const blocked = makeArrow(1, 'RIGHT', [
    { x: 0.2, y: 0.5 },
    { x: 0.4, y: 0.5 },
  ]);
  const blocker = makeArrow(2, 'UP', [
    { x: 0.7, y: 0.7 },
    { x: 0.7, y: 0.3 },
  ]);
  const level = makeMockLevel(1, [blocked, blocker]);

  let state = createInitialGameState(level);
  state = grantBonusHints(state, 2);
  assert.equal(state.hintsRemaining, 4);

  // Trigger game over (3 blocked taps)
  state = tapArrow(state, 1).nextState;
  state = tapArrow(state, 1).nextState;
  state = tapArrow(state, 1).nextState;
  assert.equal(state.lives, 0);
  assert.equal(state.isGameOver, true);

  // Rewarded revive restores 1 heart and unlocks gameplay
  const revived = reviveWithExtraLife(state);
  assert.equal(revived.lives, 1);
  assert.equal(revived.isGameOver, false);
});

test('ProgressRepository: level unlocking, persistence reload, and reset', () => {
  const mem = new Map<string, string>();
  const mockStorage: StorageBackend = {
    getItem: (k) => mem.get(k) ?? null,
    setItem: (k, v) => mem.set(k, v),
    removeItem: (k) => mem.delete(k),
  };

  let progress = loadProgress(mockStorage);
  assert.equal(progress.highestUnlockedLevel, 1);
  assert.deepEqual(progress.completedLevels, []);

  progress = markLevelCompleted(progress, 1, 50, mockStorage);
  assert.equal(progress.highestUnlockedLevel, 2);
  assert.deepEqual(progress.completedLevels, [1]);

  // Reload from storage
  const reloaded = loadProgress(mockStorage);
  assert.equal(reloaded.highestUnlockedLevel, 2);
  assert.deepEqual(reloaded.completedLevels, [1]);
  assert.equal(reloaded.currentLevelId, 2);

  // Reset clears progress
  const reset = resetAllProgress(true, reloaded, mockStorage);
  assert.equal(reset.highestUnlockedLevel, 1);
  assert.deepEqual(reset.completedLevels, []);
  assert.equal(loadProgress(mockStorage).highestUnlockedLevel, 1);
  assert.equal(DEFAULT_PROGRESS.highestUnlockedLevel, 1);
});

test('All 50 shipped levels load, have valid normalized geometry, and pass solver + simulation validation', () => {
  const levels = getAllLevels();
  assert.equal(TOTAL_LEVELS, 50);
  assert.equal(levels.length, 50);

  for (let i = 0; i < levels.length; i++) {
    const level = levels[i];
    assert.equal(level.id, i + 1, `Expected sequential level ID ${i + 1}`);
    assert.ok(level.arrows.length >= 6, `Level ${level.id} has too few arrows`);

    for (const arrow of level.arrows) {
      assert.ok(arrow.segments.length >= 1, `Level ${level.id} arrow ${arrow.id} missing segments`);
      for (const seg of arrow.segments) {
        assert.ok(
          seg.start.x >= 0 && seg.start.x <= 1 && seg.start.y >= 0 && seg.start.y <= 1,
          `Level ${level.id} arrow ${arrow.id} start out of bounds`
        );
        assert.ok(
          seg.end.x >= 0 && seg.end.x <= 1 && seg.end.y >= 0 && seg.end.y <= 1,
          `Level ${level.id} arrow ${arrow.id} end out of bounds`
        );
      }
    }

    const result = solveLevel(level);
    assert.equal(result.solvable, true, `Level ${level.id} must be solvable`);
    assert.equal(
      result.moveSequence.length,
      level.arrows.length,
      `Level ${level.id} moveSequence must clear all arrows`
    );
    assert.equal(
      validateSolutionSequence(level, result.moveSequence),
      true,
      `Level ${level.id} solution simulation failed`
    );
  }

  assert.ok(levels[0].arrows.length <= 8, 'Level 1 should remain easy and compact');
  assert.ok(
    levels[49].arrows.length >= 120,
    `Level 50 should be a dense expert silhouette (got ${levels[49].arrows.length})`
  );
});
