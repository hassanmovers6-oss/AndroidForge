-keepclassmembers class com.arrowescape.puzzle.AdMobManager$AdJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.ads.**
