import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { solveLevel, validateSolutionSequence } from '../src/domain/engine/puzzleSolver';
import { generateAll50Levels } from '../src/domain/generator/levelGenerator';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const levels = generateAll50Levels();

if (levels.length !== 50) {
  throw new Error(`Expected 50 levels, got ${levels.length}`);
}

for (const level of levels) {
  const result = solveLevel(level);
  if (!result.solvable) {
    throw new Error(`Level ${level.id} failed solveLevel`);
  }
  if (result.moveSequence.length !== level.arrows.length) {
    throw new Error(`Level ${level.id} solution length mismatch`);
  }
  if (!validateSolutionSequence(level, result.moveSequence)) {
    throw new Error(`Level ${level.id} moveSequence simulation failed`);
  }
}

const outDir = path.resolve(__dirname, '../src/data');
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, 'levelsData.json');
fs.writeFileSync(outPath, JSON.stringify(levels, null, 2), 'utf8');

console.log(`Validated and wrote ${levels.length} levels to ${outPath}`);
for (const l of levels) {
  console.log(
    `L${String(l.id).padStart(2, '0')} [${l.difficulty.padEnd(6)}] grid=${l.gridSize}x${l.gridSize} arrows=${String(l.metrics.arrowCount).padStart(2)} free0=${String(l.metrics.initiallyFreeCount).padStart(2)} depth=${String(l.metrics.maxDependencyDepth).padStart(2)} turns=${String(l.metrics.totalTurns).padStart(2)} score=${l.metrics.difficultyScore}`
  );
}
