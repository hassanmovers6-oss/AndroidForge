import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const distDir = path.resolve(__dirname, '../dist');
const androidPublicDir = path.resolve(
  __dirname,
  '../android/app/src/main/assets/public'
);

if (!fs.existsSync(distDir)) {
  throw new Error('dist/ directory does not exist. Run vite build first.');
}

fs.rmSync(androidPublicDir, { recursive: true, force: true });
fs.mkdirSync(androidPublicDir, { recursive: true });
fs.cpSync(distDir, androidPublicDir, { recursive: true, force: true });

console.log(`Synced built web assets from ${distDir} -> ${androidPublicDir}`);
