import express from 'express';
import type { Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = __dirname;
const PORT = Number(process.env.PORT) || 3000;

const EXCLUDED_DIRS = new Set([
  'node_modules',
  '.git',
  '.aistudio',
  '.gradle',
  'build',
]);

function addDirectoryToZip(zip: JSZip, dirPath: string, zipBase = ''): void {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    if (EXCLUDED_DIRS.has(entry.name)) {
      continue;
    }
    if (entry.name.endsWith('.zip')) {
      continue;
    }

    const fullPath = path.join(dirPath, entry.name);
    const relPath = zipBase ? `${zipBase}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      addDirectoryToZip(zip, fullPath, relPath);
    } else if (entry.isFile()) {
      const content = fs.readFileSync(fullPath);
      zip.file(relPath, content);
    }
  }
}

async function startServer(): Promise<void> {
  const app = express();

  app.get('/api/download-project-zip', async (_req: Request, res: Response) => {
    try {
      const zip = new JSZip();
      addDirectoryToZip(zip, ROOT_DIR);

      const buffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="arrow-escape-puzzle-android-project.zip"'
      );
      res.setHeader('Content-Length', String(buffer.length));
      res.setHeader('Cache-Control', 'no-store');
      res.send(buffer);
    } catch (err) {
      console.error('Failed to generate project zip:', err);
      res.status(500).json({ error: 'Failed to generate project zip archive' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Arrow Escape server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
