import { useCallback, useEffect, useState } from 'react';
import { adManager } from './ads/adManager';
import { getSafeLevel, TOTAL_LEVELS } from './data/levelRepository';
import {
  loadProgress,
  markLevelCompleted,
  PlayerProgress,
  resetAllProgress,
  saveProgress,
} from './data/progressRepository';
import { GameScreen } from './ui/screens/GameScreen';
import { LevelCompleteScreen } from './ui/screens/LevelCompleteScreen';
import { LevelSelectScreen } from './ui/screens/LevelSelectScreen';
import { MainMenuScreen } from './ui/screens/MainMenuScreen';
import { SettingsScreen } from './ui/screens/SettingsScreen';
import { TutorialOverlay } from './ui/screens/TutorialOverlay';

type Route =
  | { name: 'main' }
  | { name: 'levels' }
  | { name: 'game'; levelId: number; bonusHints?: number }
  | { name: 'complete'; levelId: number }
  | { name: 'settings'; returnTo: Route };

export default function App() {
  const [progress, setProgress] = useState<PlayerProgress>(() => loadProgress());
  const [route, setRoute] = useState<Route>({ name: 'main' });
  const [showTutorial, setShowTutorial] = useState<boolean>(false);

  // Sync debug flag if `?debug=1` is passed in URL
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('debug') === '1' && !progress.debugMode) {
      const updated = { ...progress, debugMode: true };
      setProgress(updated);
      saveProgress(updated);
    }
  }, [progress]);

  // Keep Banner Ad visible and Native Ad hidden except on completion/menu transitions
  useEffect(() => {
    adManager.setBannerVisible(true);
    if (route.name !== 'complete') {
      adManager.hideNativeAd();
    }
  }, [route.name]);

  // Android hardware back button bridge
  useEffect(() => {
    if (typeof window === 'undefined') return;
    window.__handleAndroidBack = () => {
      if (showTutorial) {
        setShowTutorial(false);
        return true;
      }
      if (route.name === 'game') {
        setRoute({ name: 'levels' });
        return true;
      }
      if (route.name === 'complete') {
        setRoute({ name: 'levels' });
        return true;
      }
      if (route.name === 'levels') {
        setRoute({ name: 'main' });
        return true;
      }
      if (route.name === 'settings') {
        setRoute(route.returnTo);
        return true;
      }
      return false;
    };
    return () => {
      delete window.__handleAndroidBack;
    };
  }, [route, showTutorial]);

  const updateSetting = useCallback(
    <K extends keyof PlayerProgress>(key: K, value: PlayerProgress[K]) => {
      setProgress((prev) => {
        const next = { ...prev, [key]: value };
        saveProgress(next);
        return next;
      });
    },
    []
  );

  const startLevel = useCallback((levelId: number, bonusHints = 0) => {
    const clamped = Math.max(1, Math.min(TOTAL_LEVELS, levelId));
    setProgress((prev) => {
      const next = { ...prev, currentLevelId: clamped };
      saveProgress(next);
      return next;
    });
    setRoute({ name: 'game', levelId: clamped, bonusHints });
  }, []);

  const handlePlayFromMenu = useCallback(() => {
    const targetLevel = Math.min(
      TOTAL_LEVELS,
      Math.max(1, progress.highestUnlockedLevel)
    );
    if (!progress.tutorialShown && progress.completedLevels.length === 0) {
      setShowTutorial(true);
    }
    startLevel(targetLevel, 0);
  }, [
    progress.tutorialShown,
    progress.completedLevels.length,
    progress.highestUnlockedLevel,
    startLevel,
  ]);

  const handleLevelComplete = useCallback((levelId: number) => {
    setProgress((prev) => markLevelCompleted(prev, levelId, TOTAL_LEVELS));
    setRoute({ name: 'complete', levelId });
  }, []);

  const handleDismissTutorial = useCallback(() => {
    setShowTutorial(false);
    setProgress((prev) => {
      if (prev.tutorialShown) return prev;
      const next = { ...prev, tutorialShown: true };
      saveProgress(next);
      return next;
    });
  }, []);

  const handleResetProgress = useCallback(() => {
    setProgress((prev) => resetAllProgress(true, prev));
    setRoute({ name: 'main' });
  }, []);

  return (
    <>
      {route.name === 'main' && (
        <MainMenuScreen
          progress={progress}
          onPlayCurrent={handlePlayFromMenu}
          onOpenLevels={() => setRoute({ name: 'levels' })}
          onOpenSettings={() =>
            setRoute({ name: 'settings', returnTo: { name: 'main' } })
          }
          onOpenTutorial={() => setShowTutorial(true)}
        />
      )}

      {route.name === 'levels' && (
        <LevelSelectScreen
          progress={progress}
          onSelectLevel={(id) => startLevel(id, 0)}
          onBack={() => setRoute({ name: 'main' })}
        />
      )}

      {route.name === 'game' && (
        <GameScreen
          level={getSafeLevel(route.levelId)}
          bonusHints={route.bonusHints ?? 0}
          progress={progress}
          onToggleGrid={() => updateSetting('showGrid', !progress.showGrid)}
          onLevelComplete={handleLevelComplete}
          onBackToLevels={() => setRoute({ name: 'levels' })}
          onBackToMenu={() => setRoute({ name: 'main' })}
          onOpenSettings={() =>
            setRoute({
              name: 'settings',
              returnTo: {
                name: 'game',
                levelId: route.levelId,
                bonusHints: route.bonusHints,
              },
            })
          }
        />
      )}

      {route.name === 'complete' && (
        <LevelCompleteScreen
          level={getSafeLevel(route.levelId)}
          onNextLevel={(bonusGranted) =>
            startLevel(route.levelId + 1, bonusGranted ? 1 : 0)
          }
          onMainMenu={() => setRoute({ name: 'main' })}
          onLevelSelect={() => setRoute({ name: 'levels' })}
        />
      )}

      {route.name === 'settings' && (
        <SettingsScreen
          progress={progress}
          onUpdateSetting={updateSetting}
          onResetProgress={handleResetProgress}
          onOpenTutorial={() => setShowTutorial(true)}
          onBack={() => setRoute(route.returnTo)}
        />
      )}

      {showTutorial && (
        <TutorialOverlay
          onComplete={handleDismissTutorial}
          onSkip={handleDismissTutorial}
        />
      )}
    </>
  );
}
