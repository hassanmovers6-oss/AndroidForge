import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  Bug,
  Grid3X3,
  Heart,
  Lightbulb,
  RotateCcw,
  Settings,
} from 'lucide-react';
import {
  playBlockedSound,
  playCompleteSound,
  playEscapeSound,
  playHintSound,
  playUiClickSound,
} from '../../audio/soundEffects';
import { PlayerProgress } from '../../data/progressRepository';
import { isArrowFree } from '../../domain/engine/collisionEngine';
import { adManager } from '../../ads/adManager';
import {
  createInitialGameState,
  grantBonusHints,
  restartLevel,
  reviveWithExtraLife,
  tapArrow,
  useHint,
} from '../../domain/engine/puzzleEngine';
import { solveLevel } from '../../domain/engine/puzzleSolver';
import { Difficulty, GameState, Level } from '../../domain/model/types';
import {
  triggerBlockedHaptic,
  triggerCompleteHaptic,
  triggerEscapeHaptic,
} from '../../utils/haptics';
import {
  ArrowBoardCanvas,
  BlockedAnimation,
  EscapingAnimation,
  getEscapeDurationMs,
} from '../components/ArrowBoardCanvas';

interface GameScreenProps {
  level: Level;
  bonusHints?: number;
  progress: PlayerProgress;
  onToggleGrid: () => void;
  onLevelComplete: (levelId: number) => void;
  onBackToLevels: () => void;
  onBackToMenu: () => void;
  onOpenSettings: () => void;
}

function formatDifficulty(d: Difficulty): string {
  switch (d) {
    case 'EASY':
      return 'Easy';
    case 'NORMAL':
      return 'Normal';
    case 'HARD':
      return 'Hard';
    case 'EXPERT':
      return 'Expert';
  }
}

export const GameScreen: React.FC<GameScreenProps> = ({
  level,
  bonusHints = 0,
  progress,
  onToggleGrid,
  onLevelComplete,
  onBackToLevels,
  onBackToMenu,
  onOpenSettings,
}) => {
  const [gameState, setGameState] = useState<GameState>(() =>
    grantBonusHints(createInitialGameState(level), bonusHints)
  );
  const [escapingArrows, setEscapingArrows] = useState<EscapingAnimation[]>([]);
  const [blockedAnimation, setBlockedAnimation] =
    useState<BlockedAnimation | null>(null);
  const [statusNote, setStatusNote] = useState<string | null>(null);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showDebugPanel, setShowDebugPanel] = useState(false);

  const completionTriggeredRef = useRef(false);
  const timersRef = useRef<number[]>([]);

  const clearScheduledTimers = () => {
    for (const id of timersRef.current) {
      window.clearTimeout(id);
    }
    timersRef.current = [];
  };

  // Reset state whenever level changes
  useEffect(() => {
    clearScheduledTimers();
    adManager.hideNativeAd();
    adManager.setBannerVisible(true);
    setGameState(grantBonusHints(createInitialGameState(level), bonusHints));
    setEscapingArrows([]);
    setBlockedAnimation(null);
    setStatusNote(null);
    setShowExitConfirm(false);
    completionTriggeredRef.current = false;

    return () => clearScheduledTimers();
  }, [level, bonusHints]);

  // Trigger completion transition after final arrow animation settles
  useEffect(() => {
    if (gameState.isComplete && !completionTriggeredRef.current) {
      completionTriggeredRef.current = true;
      playCompleteSound(progress.soundEnabled);
      triggerCompleteHaptic(progress.hapticsEnabled);

      const timer = window.setTimeout(() => {
        onLevelComplete(level.id);
      }, 620);
      timersRef.current.push(timer);
    }
  }, [
    gameState.isComplete,
    level.id,
    onLevelComplete,
    progress.soundEnabled,
    progress.hapticsEnabled,
  ]);

  const escapingIds = useMemo(
    () => new Set(escapingArrows.map((e) => e.arrow.id)),
    [escapingArrows]
  );

  const handleArrowTap = (arrowId: number) => {
    if (gameState.isComplete || gameState.isGameOver) return;
    // Rapid-tap protection: ignore arrows already animating out
    if (escapingIds.has(arrowId)) return;

    const tappedObj = gameState.remainingArrows.find((a) => a.id === arrowId);
    if (!tappedObj) return;

    const { nextState, outcome } = tapArrow(gameState, arrowId);

    if (outcome === 'ESCAPED') {
      setGameState(nextState);
      setStatusNote(null);
      playEscapeSound(progress.soundEnabled);
      triggerEscapeHaptic(progress.hapticsEnabled);

      const durationMs = getEscapeDurationMs(tappedObj);
      const animEntry: EscapingAnimation = {
        arrow: tappedObj,
        startTime: performance.now(),
        durationMs,
      };
      setEscapingArrows((prev) => [...prev, animEntry]);

      const cleanupTimer = window.setTimeout(() => {
        setEscapingArrows((prev) =>
          prev.filter((item) => item.arrow.id !== arrowId)
        );
      }, durationMs + 40);
      timersRef.current.push(cleanupTimer);
    } else if (outcome === 'BLOCKED') {
      setGameState(nextState);
      playBlockedSound(progress.soundEnabled);
      triggerBlockedHaptic(progress.hapticsEnabled);
      setBlockedAnimation({
        arrowId,
        startTime: performance.now(),
        durationMs: 320,
      });
      setStatusNote('Path blocked — clear arrows ahead first');

      const clearNoteTimer = window.setTimeout(() => {
        setStatusNote((prev) =>
          prev === 'Path blocked — clear arrows ahead first' ? null : prev
        );
      }, 1700);
      timersRef.current.push(clearNoteTimer);
    }
  };

  const handleHint = () => {
    if (gameState.isComplete || gameState.isGameOver) return;
    if (gameState.hintsRemaining <= 0) {
      adManager.showRewarded('more_hints', (granted) => {
        if (granted) {
          setGameState((prev) => {
            const withHints = grantBonusHints(prev, 2);
            const { nextState, hintedArrowId } = useHint(withHints);
            if (hintedArrowId !== null) {
              playHintSound(progress.soundEnabled);
            }
            return nextState;
          });
          setStatusNote('+2 Hints earned · Free arrow highlighted');
        } else {
          setStatusNote('Ad not ready yet — try again in a moment');
        }
      });
      return;
    }

    const { nextState, hintedArrowId } = useHint(gameState);
    if (hintedArrowId !== null) {
      setGameState(nextState);
      playHintSound(progress.soundEnabled);
      setStatusNote('Free arrow highlighted');
    }
  };

  const handleRewardedRevive = () => {
    if (!gameState.isGameOver) return;
    adManager.showRewarded('revive', (granted) => {
      if (granted) {
        setGameState((prev) => reviveWithExtraLife(prev));
        playHintSound(progress.soundEnabled);
        setStatusNote('+1 Heart restored — keep going!');
      } else {
        setStatusNote('Ad unavailable — tap Restart Level');
      }
    });
  };

  const performRestart = () => {
    clearScheduledTimers();
    playUiClickSound(progress.soundEnabled);
    setGameState(restartLevel(level));
    setEscapingArrows([]);
    setBlockedAnimation(null);
    setStatusNote(null);
    completionTriggeredRef.current = false;
  };

  const handleRestart = () => {
    if (gameState.movesTaken > 0 || gameState.isGameOver) {
      adManager.showInterstitial('restart_level', performRestart);
    } else {
      performRestart();
    }
  };

  const handleBackPress = () => {
    playUiClickSound(progress.soundEnabled);
    if (
      gameState.movesTaken > 0 &&
      !gameState.isComplete &&
      !gameState.isGameOver
    ) {
      setShowExitConfirm(true);
    } else {
      onBackToLevels();
    }
  };

  // Optional dev-only debug metrics
  const debugStats = useMemo(() => {
    if (!progress.debugMode || !showDebugPanel) return null;
    const freeCount = gameState.remainingArrows.filter((a) =>
      isArrowFree(a, gameState.remainingArrows)
    ).length;
    const solved = solveLevel({
      ...level,
      arrows: gameState.remainingArrows,
    });
    return {
      total: level.arrows.length,
      remaining: gameState.remainingArrows.length,
      freeCount,
      blockedCount: gameState.remainingArrows.length - freeCount,
      nextSolutionId: solved.moveSequence[0] ?? null,
    };
  }, [progress.debugMode, showDebugPanel, gameState.remainingArrows, level]);

  return (
    <div className="min-h-dvh w-full bg-[#F8FAFC] flex flex-col items-center justify-between px-4 sm:px-6 pt-4 pb-6">
      {/* Top utility bar */}
      <div className="w-full max-w-[460px] flex items-center justify-between">
        <button
          type="button"
          onClick={handleBackPress}
          aria-label="Back to levels"
          className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white border border-slate-200 text-[#0F2147] hover:bg-slate-50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          {progress.debugMode && (
            <button
              type="button"
              onClick={() => setShowDebugPanel((s) => !s)}
              aria-label="Toggle puzzle debug inspector"
              className={`inline-flex items-center justify-center w-11 h-11 rounded-xl border transition-colors focus-visible:outline-2 focus-visible:outline-blue-600 ${
                showDebugPanel
                  ? 'bg-blue-50 border-blue-300 text-[#2563EB]'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Bug className="w-5 h-5" />
            </button>
          )}

          <button
            type="button"
            onClick={handleRestart}
            aria-label="Restart level"
            className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => {
              playUiClickSound(progress.soundEnabled);
              onOpenSettings();
            }}
            aria-label="Settings"
            className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Level Title & Clean Unboxed Status Strip */}
      <header className="w-full max-w-[460px] flex flex-col items-center text-center mt-2 mb-3">
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#0F2147] leading-tight">
          Arrow Escape
        </h1>
        <p className="mt-1 text-base font-bold text-[#2563EB] tabular-nums">
          Level {level.id}
        </p>

        {/* Clean horizontal status line — zero pill capsules */}
        <div className="mt-3 w-full flex items-center justify-between px-2 text-sm font-semibold text-[#0F2147]">
          <div
            className="flex items-center gap-1.5 tabular-nums"
            aria-label={`${gameState.remainingArrows.length} arrows remaining`}
          >
            <ArrowUpRight className="w-4 h-4 text-[#2563EB]" strokeWidth={2.5} />
            <span>{gameState.remainingArrows.length}</span>
          </div>

          <div
            className="flex items-center gap-1.5"
            aria-label={`${gameState.lives} of ${level.startingLives} lives remaining`}
          >
            {Array.from({ length: level.startingLives }, (_, idx) => {
              const alive = idx < gameState.lives;
              return (
                <Heart
                  key={idx}
                  className={`w-5 h-5 transition-all duration-200 ${
                    alive
                      ? 'text-[#EF4444] fill-[#EF4444] scale-100'
                      : 'text-slate-300 fill-slate-200 scale-90'
                  }`}
                />
              );
            })}
          </div>

          <div className="text-slate-600 font-semibold">
            {formatDifficulty(level.difficulty)}
          </div>
        </div>
      </header>

      {/* Dominant Center Anchor: Puzzle Board */}
      <main className="w-full flex flex-col items-center justify-center my-auto">
        <ArrowBoardCanvas
          arrows={gameState.remainingArrows}
          gridSize={level.gridSize}
          showGrid={progress.showGrid}
          highlightedArrowId={gameState.highlightedArrowId}
          escapingArrows={escapingArrows}
          blockedAnimation={blockedAnimation}
          disabled={gameState.isComplete || gameState.isGameOver}
          onArrowTap={handleArrowTap}
        />

        {/* Subtle non-intrusive feedback message */}
        <div className="h-6 mt-2.5 flex items-center justify-center">
          {statusNote && (
            <p
              role="status"
              className="text-xs font-semibold text-slate-600 transition-opacity"
            >
              {statusNote}
            </p>
          )}
        </div>
      </main>

      {/* Bottom Controls: Circular Hint + Grid Buttons */}
      <footer className="w-full max-w-[460px] flex items-center justify-center gap-8 pt-1 pb-2">
        <div className="relative">
          <button
            type="button"
            onClick={handleHint}
            disabled={gameState.isComplete || gameState.isGameOver}
            aria-label={
              gameState.hintsRemaining > 0
                ? `Use hint, ${gameState.hintsRemaining} remaining`
                : 'Watch ad for 2 more hints'
            }
            className="w-14 h-14 rounded-full flex items-center justify-center border shadow-sm transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 bg-white border-slate-200 text-[#0F2147] hover:border-blue-300 hover:text-[#2563EB] active:scale-95"
          >
            <Lightbulb className="w-6 h-6" />
          </button>
          <span
            aria-hidden="true"
            className={`absolute -top-1 -right-1 min-w-[24px] h-[22px] px-1.5 rounded-full text-[11px] font-bold flex items-center justify-center tabular-nums shadow-xs ${
              gameState.hintsRemaining > 0
                ? 'bg-[#2563EB] text-white'
                : 'bg-[#2563EB] text-white'
            }`}
          >
            {gameState.hintsRemaining > 0 ? gameState.hintsRemaining : 'Ad'}
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            playUiClickSound(progress.soundEnabled);
            onToggleGrid();
          }}
          aria-label={progress.showGrid ? 'Hide grid overlay' : 'Show grid overlay'}
          aria-pressed={progress.showGrid}
          className={`w-14 h-14 rounded-full flex items-center justify-center border shadow-sm transition-all active:scale-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 ${
            progress.showGrid
              ? 'bg-[#2563EB] border-[#2563EB] text-white'
              : 'bg-white border-slate-200 text-[#0F2147] hover:border-slate-300'
          }`}
        >
          <Grid3X3 className="w-6 h-6" />
        </button>
      </footer>

      {/* Optional Dev-Only Debug Inspector */}
      {progress.debugMode && showDebugPanel && debugStats && (
        <aside className="w-full max-w-[460px] mt-2 p-3.5 rounded-2xl bg-slate-900 text-slate-100 text-xs font-mono space-y-1.5">
          <div className="flex justify-between">
            <span>Level: {level.id}</span>
            <span>Grid: {level.gridSize}×{level.gridSize}</span>
          </div>
          <div className="flex justify-between">
            <span>Arrows: {debugStats.remaining}/{debugStats.total}</span>
            <span>Free: {debugStats.freeCount} · Blocked: {debugStats.blockedCount}</span>
          </div>
          <div className="flex justify-between">
            <span>Score: {level.metrics.difficultyScore}</span>
            <span>Max Depth: {level.metrics.maxDependencyDepth}</span>
          </div>
          {debugStats.nextSolutionId !== null && (
            <button
              type="button"
              onClick={() => {
                setGameState((prev) => ({
                  ...prev,
                  highlightedArrowId: debugStats.nextSolutionId,
                }));
              }}
              className="w-full mt-1 py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-sans font-semibold text-xs"
            >
              Highlight Next Valid Solution Arrow (#{debugStats.nextSolutionId})
            </button>
          )}
        </aside>
      )}

      {/* Out of Lives Modal */}
      {gameState.isGameOver && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="game-over-title"
          className="fixed inset-0 z-40 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-6"
        >
          <div className="w-full max-w-xs rounded-3xl bg-white p-7 text-center shadow-2xl border border-slate-100">
            <div className="mx-auto w-12 h-12 rounded-2xl bg-red-50 text-[#EF4444] flex items-center justify-center">
              <Heart className="w-6 h-6" />
            </div>
            <h2
              id="game-over-title"
              className="mt-4 text-xl font-extrabold text-[#0F2147]"
            >
              Out of Lives
            </h2>
            <p className="mt-1.5 text-sm text-slate-600">
              Think carefully and try again.
            </p>

            <div className="mt-6 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={handleRewardedRevive}
                className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-bold text-sm transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
              >
                Watch Ad · Revive (+1 Heart)
              </button>
              <button
                type="button"
                onClick={handleRestart}
                className="w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#1D4ED8] font-bold text-sm transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
              >
                Restart Level
              </button>
              <button
                type="button"
                onClick={onBackToMenu}
                className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0F2147] font-semibold text-sm transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
              >
                Main Menu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Leave Mid-Puzzle Confirmation Modal */}
      {showExitConfirm && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="leave-level-title"
          className="fixed inset-0 z-40 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-6"
        >
          <div className="w-full max-w-xs rounded-3xl bg-white p-7 text-center shadow-2xl border border-slate-100">
            <h2
              id="leave-level-title"
              className="text-lg font-extrabold text-[#0F2147]"
            >
              Leave Level {level.id}?
            </h2>
            <p className="mt-1.5 text-sm text-slate-600">
              Your current board moves will be reset.
            </p>

            <div className="mt-6 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => setShowExitConfirm(false)}
                className="w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-bold text-sm transition-colors"
              >
                Keep Playing
              </button>
              <button
                type="button"
                onClick={onBackToLevels}
                className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0F2147] font-semibold text-sm transition-colors"
              >
                Back to Levels
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
