import React from 'react';
import { Download, Grid3X3, HelpCircle, Play, Settings } from 'lucide-react';
import { isAndroidNativeApp } from '../../ads/adManager';
import { AppLogoMark } from '../components/AppLogoMark';
import { PlayerProgress } from '../../data/progressRepository';
import { TOTAL_LEVELS } from '../../data/levelRepository';

interface MainMenuScreenProps {
  progress: PlayerProgress;
  onPlayCurrent: () => void;
  onOpenLevels: () => void;
  onOpenSettings: () => void;
  onOpenTutorial: () => void;
}

export const MainMenuScreen: React.FC<MainMenuScreenProps> = ({
  progress,
  onPlayCurrent,
  onOpenLevels,
  onOpenSettings,
  onOpenTutorial,
}) => {
  const completedCount = progress.completedLevels.length;
  const playLevel = Math.min(TOTAL_LEVELS, Math.max(1, progress.highestUnlockedLevel));
  const showDownloadLink = !isAndroidNativeApp();

  return (
    <main className="min-h-dvh w-full bg-[#F8FAFC] flex flex-col items-center justify-between px-6 py-10">
      {/* Top quiet utility row */}
      <div className="w-full max-w-md flex items-center justify-between">
        <button
          type="button"
          onClick={onOpenTutorial}
          aria-label="How to play"
          className="inline-flex items-center gap-2 min-h-[44px] px-3 rounded-xl text-sm font-semibold text-slate-600 hover:text-[#0F2147] hover:bg-slate-200/50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600 whitespace-nowrap shrink-0"
        >
          <HelpCircle className="w-5 h-5" />
          <span>How to Play</span>
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          aria-label="Settings"
          className="inline-flex items-center justify-center w-11 h-11 rounded-xl text-slate-600 hover:text-[#0F2147] hover:bg-slate-200/50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Centered focal branding + primary CTA */}
      <section className="w-full max-w-sm flex flex-col items-center text-center my-auto py-8">
        <AppLogoMark size={84} />

        <h1 className="mt-7 text-4xl sm:text-5xl font-extrabold tracking-tight text-[#0F2147] leading-[1.08] text-balance">
          Arrow Escape
        </h1>
        <p className="mt-3 text-base text-slate-600 font-medium">
          A relaxing logic puzzle
        </p>

        {/* Quiet unboxed progress summary */}
        <div className="mt-4 flex items-center gap-2 text-sm text-slate-500 font-medium tabular-nums">
          <span>Level {playLevel}</span>
          <span aria-hidden="true">·</span>
          <span>
            {completedCount} / {TOTAL_LEVELS} Completed
          </span>
        </div>

        <div className="mt-10 w-full flex flex-col gap-3.5">
          <button
            type="button"
            onClick={onPlayCurrent}
            className="w-full min-h-[56px] px-6 py-4 rounded-2xl bg-[#2563EB] hover:bg-[#1D4ED8] active:scale-[0.99] text-white font-bold text-lg shadow-[0_12px_26px_-8px_rgba(37,99,235,0.55)] transition-all flex items-center justify-center gap-2.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 whitespace-nowrap"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>{completedCount > 0 ? `Play Level ${playLevel}` : 'Play'}</span>
          </button>

          <button
            type="button"
            onClick={onOpenLevels}
            className="w-full min-h-[52px] px-6 py-3.5 rounded-2xl bg-white hover:bg-slate-50 active:scale-[0.99] text-[#0F2147] font-semibold text-base border border-slate-200 shadow-xs transition-all flex items-center justify-center gap-2.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 whitespace-nowrap"
          >
            <Grid3X3 className="w-5 h-5 text-slate-600" />
            <span>Levels</span>
          </button>

          {showDownloadLink && (
            <a
              href="/api/download-project-zip"
              download="arrow-escape-puzzle-android-project.zip"
              className="w-full min-h-[46px] px-5 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200/80 text-[#0F2147] font-semibold text-sm transition-colors flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-[#2563EB]" />
              <span>Download Full Android Project (.zip)</span>
            </a>
          )}
        </div>
      </section>

      {/* Quiet bottom tagline */}
      <footer className="text-xs text-slate-400 font-medium text-center">
        Find the free path · Tap arrows in order
      </footer>
    </main>
  );
};
