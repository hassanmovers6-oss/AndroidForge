import React, { useState } from 'react';
import {
  ArrowLeft,
  Bug,
  Download,
  Grid3X3,
  HelpCircle,
  Smartphone,
  Trash2,
  Volume2,
} from 'lucide-react';
import { isAndroidNativeApp } from '../../ads/adManager';
import { PlayerProgress } from '../../data/progressRepository';

interface SettingsScreenProps {
  progress: PlayerProgress;
  onUpdateSetting: <K extends keyof PlayerProgress>(
    key: K,
    value: PlayerProgress[K]
  ) => void;
  onResetProgress: () => void;
  onOpenTutorial: () => void;
  onBack: () => void;
}

interface ToggleRowProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  checked: boolean;
  onChange: (next: boolean) => void;
}

const ToggleRow: React.FC<ToggleRowProps> = ({
  icon,
  title,
  description,
  checked,
  onChange,
}) => {
  return (
    <div className="flex items-center justify-between gap-4 py-4 px-5">
      <div className="flex items-start gap-3.5 min-w-0">
        <div className="mt-0.5 text-slate-500 shrink-0">{icon}</div>
        <div>
          <p className="text-sm font-bold text-[#0F2147]">{title}</p>
          <p className="text-xs text-slate-500 mt-0.5">{description}</p>
        </div>
      </div>

      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={title}
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 ${
          checked ? 'bg-[#2563EB]' : 'bg-slate-300'
        }`}
      >
        <span
          aria-hidden="true"
          className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-sm transition duration-200 ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
};

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  progress,
  onUpdateSetting,
  onResetProgress,
  onOpenTutorial,
  onBack,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  return (
    <div className="min-h-dvh w-full bg-[#F8FAFC] flex flex-col items-center px-4 sm:px-6 py-6">
      <div className="w-full max-w-lg flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between gap-4 pb-6">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back"
            className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white border border-slate-200 text-[#0F2147] hover:bg-slate-50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <h1 className="text-2xl font-extrabold tracking-tight text-[#0F2147]">
            Settings
          </h1>

          <div className="w-11" aria-hidden="true" />
        </header>

        {/* Preferences Group */}
        <section className="rounded-3xl bg-white border border-slate-200/90 divide-y divide-slate-100 shadow-xs overflow-hidden">
          <ToggleRow
            icon={<Volume2 className="w-5 h-5" />}
            title="Sound Effects"
            description="Subtle audio chimes on escape and completion"
            checked={progress.soundEnabled}
            onChange={(v) => onUpdateSetting('soundEnabled', v)}
          />
          <ToggleRow
            icon={<Smartphone className="w-5 h-5" />}
            title="Haptics"
            description="Gentle vibration feedback on supported devices"
            checked={progress.hapticsEnabled}
            onChange={(v) => onUpdateSetting('hapticsEnabled', v)}
          />
          <ToggleRow
            icon={<Grid3X3 className="w-5 h-5" />}
            title="Show Grid"
            description="Display subtle alignment dots on the puzzle board"
            checked={progress.showGrid}
            onChange={(v) => onUpdateSetting('showGrid', v)}
          />
          <ToggleRow
            icon={<Bug className="w-5 h-5" />}
            title="Developer Solver View"
            description="Inspect level metrics and step-by-step solver hints"
            checked={progress.debugMode}
            onChange={(v) => onUpdateSetting('debugMode', v)}
          />
        </section>

        {/* Actions */}
        <section className="mt-5 rounded-3xl bg-white border border-slate-200/90 divide-y divide-slate-100 shadow-xs overflow-hidden">
          <button
            type="button"
            onClick={onOpenTutorial}
            className="w-full flex items-center gap-3.5 py-4 px-5 text-left hover:bg-slate-50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
          >
            <HelpCircle className="w-5 h-5 text-slate-500 shrink-0" />
            <div>
              <p className="text-sm font-bold text-[#0F2147]">How to Play</p>
              <p className="text-xs text-slate-500 mt-0.5">
                View the 4-step puzzle walkthrough
              </p>
            </div>
          </button>

          {!isAndroidNativeApp() && (
            <a
              href="/api/download-project-zip"
              download="arrow-escape-puzzle-android-project.zip"
              className="w-full flex items-center gap-3.5 py-4 px-5 text-left hover:bg-blue-50/60 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600"
            >
              <Download className="w-5 h-5 text-[#2563EB] shrink-0" />
              <div>
                <p className="text-sm font-bold text-[#0F2147]">
                  Download Full Android Project (.zip)
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Includes Android Forge / Gradle project, AdMob IDs & web bundle
                </p>
              </div>
            </a>
          )}

          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="w-full flex items-center gap-3.5 py-4 px-5 text-left hover:bg-red-50/60 transition-colors focus-visible:outline-2 focus-visible:outline-red-600"
          >
            <Trash2 className="w-5 h-5 text-[#EF4444] shrink-0" />
            <div>
              <p className="text-sm font-bold text-[#DC2626]">Reset Progress</p>
              <p className="text-xs text-slate-500 mt-0.5">
                Clear completed levels and lock levels back to Level 1
              </p>
            </div>
          </button>
        </section>

        {/* About */}
        <section className="mt-6 px-2 text-center text-xs text-slate-500 space-y-1">
          <p className="font-semibold text-[#0F2147]">Arrow Escape Puzzle</p>
          <p>50 offline logic puzzles · Geometric corridor solver</p>
        </section>
      </div>

      {/* Confirmation Dialog */}
      {confirmReset && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="reset-dialog-title"
          className="fixed inset-0 z-40 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-6"
        >
          <div className="w-full max-w-xs rounded-3xl bg-white p-7 text-center shadow-2xl border border-slate-100">
            <h2
              id="reset-dialog-title"
              className="text-lg font-extrabold text-[#0F2147]"
            >
              Reset All Progress?
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              All completed levels will be cleared and only Level 1 will remain unlocked.
            </p>
            <div className="mt-6 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => {
                  onResetProgress();
                  setConfirmReset(false);
                }}
                className="w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-[#EF4444] hover:bg-[#DC2626] text-white font-bold text-sm transition-colors"
              >
                Reset Progress
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="w-full min-h-[44px] px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0F2147] font-semibold text-sm transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
