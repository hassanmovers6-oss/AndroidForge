import React, { useMemo, useState } from 'react';
import { ArrowLeft, Check, Lock } from 'lucide-react';
import { getAllLevels, TOTAL_LEVELS } from '../../data/levelRepository';
import { PlayerProgress } from '../../data/progressRepository';
import { Difficulty } from '../../domain/model/types';

interface LevelSelectScreenProps {
  progress: PlayerProgress;
  onSelectLevel: (levelId: number) => void;
  onBack: () => void;
}

type FilterOption = 'ALL' | Difficulty;

const FILTER_LABELS: { key: FilterOption; label: string }[] = [
  { key: 'ALL', label: 'All (50)' },
  { key: 'EASY', label: 'Easy' },
  { key: 'NORMAL', label: 'Normal' },
  { key: 'HARD', label: 'Hard' },
  { key: 'EXPERT', label: 'Expert' },
];

export const LevelSelectScreen: React.FC<LevelSelectScreenProps> = ({
  progress,
  onSelectLevel,
  onBack,
}) => {
  const [filter, setFilter] = useState<FilterOption>('ALL');
  const allLevels = useMemo(() => getAllLevels(), []);
  const completedSet = useMemo(
    () => new Set(progress.completedLevels),
    [progress.completedLevels]
  );

  const visibleLevels = useMemo(() => {
    if (filter === 'ALL') return allLevels;
    return allLevels.filter((l) => l.difficulty === filter);
  }, [allLevels, filter]);

  return (
    <div className="min-h-dvh w-full bg-[#F8FAFC] flex flex-col items-center px-4 sm:px-6 py-6">
      <div className="w-full max-w-2xl flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between gap-4 pb-5">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back to main menu"
            className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-white border border-slate-200 text-[#0F2147] hover:bg-slate-50 transition-colors focus-visible:outline-2 focus-visible:outline-blue-600 shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center">
            <h1 className="text-2xl font-extrabold tracking-tight text-[#0F2147]">
              Levels
            </h1>
            <p className="text-xs font-medium text-slate-500 tabular-nums mt-0.5">
              {progress.completedLevels.length} / {TOTAL_LEVELS} Completed
            </p>
          </div>

          <div className="w-11 shrink-0" aria-hidden="true" />
        </header>

        {/* Functional difficulty filter control */}
        <div
          role="tablist"
          aria-label="Filter levels by difficulty"
          className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-xl overflow-x-auto mb-6"
        >
          {FILTER_LABELS.map((item) => {
            const active = filter === item.key;
            return (
              <button
                key={item.key}
                role="tab"
                aria-selected={active}
                type="button"
                onClick={() => setFilter(item.key)}
                className={`flex-1 min-h-[38px] px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-blue-600 ${
                  active
                    ? 'bg-white text-[#0F2147] shadow-xs'
                    : 'text-slate-600 hover:text-[#0F2147]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* Level grid */}
        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 gap-2.5 sm:gap-3 pb-10">
          {visibleLevels.map((level) => {
            const isCompleted = completedSet.has(level.id);
            const isUnlocked = level.id <= progress.highestUnlockedLevel;
            const isCurrent =
              level.id === progress.highestUnlockedLevel && !isCompleted;

            return (
              <button
                key={level.id}
                type="button"
                disabled={!isUnlocked}
                onClick={() => isUnlocked && onSelectLevel(level.id)}
                aria-label={
                  isCompleted
                    ? `Level ${level.id}, completed`
                    : isUnlocked
                      ? `Level ${level.id}, unlocked`
                      : `Level ${level.id}, locked`
                }
                className={`relative aspect-square min-h-[54px] rounded-2xl flex flex-col items-center justify-center gap-0.5 transition-all tabular-nums focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 ${
                  isCurrent
                    ? 'bg-[#2563EB] text-white shadow-[0_8px_18px_-6px_rgba(37,99,235,0.6)] hover:bg-[#1D4ED8] active:scale-[0.97]'
                    : isCompleted
                      ? 'bg-white text-[#0F2147] border border-blue-200 hover:border-blue-400 hover:bg-blue-50/40 active:scale-[0.97]'
                      : isUnlocked
                        ? 'bg-white text-[#0F2147] border border-slate-200 hover:border-slate-300 active:scale-[0.97]'
                        : 'bg-slate-100 text-slate-400 border border-slate-200/70 cursor-not-allowed'
                }`}
              >
                <span className="text-base font-bold leading-none">
                  {level.id}
                </span>
                {isCompleted ? (
                  <Check className="w-3.5 h-3.5 text-[#2563EB] stroke-[2.75]" />
                ) : !isUnlocked ? (
                  <Lock className="w-3 h-3 text-slate-400" />
                ) : (
                  <span
                    className={`text-[10px] font-semibold leading-none ${
                      isCurrent ? 'text-blue-100' : 'text-slate-400'
                    }`}
                  >
                    {level.difficulty === 'EASY'
                      ? 'Easy'
                      : level.difficulty === 'NORMAL'
                        ? 'Norm'
                        : level.difficulty === 'HARD'
                          ? 'Hard'
                          : 'Exp'}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
