import React, { useEffect } from 'react';
import { ArrowRight, CheckCircle2, Home, Sparkles } from 'lucide-react';
import { adManager, isAndroidNativeApp } from '../../ads/adManager';
import { TOTAL_LEVELS } from '../../data/levelRepository';
import { Level } from '../../domain/model/types';
import { ConfettiOverlay } from '../components/ConfettiOverlay';
import { MiniBoardPreview } from '../components/MiniBoardPreview';

interface LevelCompleteScreenProps {
  level: Level;
  onNextLevel: (bonusHintGranted?: boolean) => void;
  onMainMenu: () => void;
  onLevelSelect: () => void;
}

export const LevelCompleteScreen: React.FC<LevelCompleteScreenProps> = ({
  level,
  onNextLevel,
  onMainMenu,
  onLevelSelect,
}) => {
  const hasNext = level.id < TOTAL_LEVELS;
  const compactForNativeAd = isAndroidNativeApp();

  useEffect(() => {
    adManager.setBannerVisible(true);
    adManager.showNativeAd();
    return () => {
      adManager.hideNativeAd();
    };
  }, [level.id]);

  const handleNextWithInterstitial = () => {
    adManager.hideNativeAd();
    adManager.showInterstitial('next_level', () => {
      onNextLevel(false);
    });
  };

  const handleBonusHintRewardedInterstitial = () => {
    adManager.hideNativeAd();
    adManager.showRewardedInterstitial('bonus_next_level', (granted) => {
      onNextLevel(granted);
    });
  };

  const handleMainMenu = () => {
    adManager.hideNativeAd();
    adManager.showInterstitial('complete_to_menu', onMainMenu);
  };

  return (
    <div
      className={`relative min-h-full w-full overflow-y-auto overflow-x-hidden bg-[radial-gradient(circle_at_50%_28%,#3B82F6_0%,#2563EB_48%,#1E40AF_100%)] flex flex-col items-center justify-center px-6 ${
        compactForNativeAd ? 'py-5' : 'min-h-dvh py-10'
      } text-white`}
    >
      {/* Subtle rotating light rays */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-20"
      >
        <svg
          viewBox="0 0 400 400"
          className="w-[150vmax] h-[150vmax] animate-rays-slow"
        >
          {Array.from({ length: 12 }, (_, idx) => (
            <polygon
              key={idx}
              points="200,200 186,0 214,0"
              fill="#FFFFFF"
              transform={`rotate(${idx * 30} 200 200)`}
            />
          ))}
        </svg>
      </div>

      <ConfettiOverlay />

      <div className="relative z-20 w-full max-w-sm flex flex-col items-center text-center">
        <div
          className={`rounded-full bg-white/15 backdrop-blur-xs flex items-center justify-center ${
            compactForNativeAd ? 'w-11 h-11 mb-2.5' : 'w-14 h-14 mb-4'
          }`}
        >
          <CheckCircle2
            className={compactForNativeAd ? 'w-6 h-6 text-white' : 'w-8 h-8 text-white'}
            strokeWidth={2.4}
          />
        </div>

        <h1
          className={`font-extrabold tracking-tight text-white ${
            compactForNativeAd ? 'text-2xl' : 'text-3xl sm:text-4xl'
          }`}
        >
          Level Complete!
        </h1>
        <p className="mt-1.5 text-sm sm:text-base text-blue-100 font-medium tabular-nums">
          {hasNext
            ? `Level ${level.id} cleared · ${level.arrows.length} arrows escaped`
            : `All ${TOTAL_LEVELS} levels mastered!`}
        </p>

        {/* Miniature completed puzzle preview card */}
        <div
          className={`rounded-3xl bg-white shadow-[0_20px_50px_-14px_rgba(15,23,42,0.4)] flex flex-col items-center ${
            compactForNativeAd ? 'mt-4 p-3' : 'mt-6 p-4'
          }`}
        >
          <MiniBoardPreview level={level} size={compactForNativeAd ? 108 : 142} />
          <span className="mt-2 text-xs font-semibold text-slate-500 tabular-nums">
            Level {level.id} Layout
          </span>
        </div>

        {/* Actions */}
        <div className="mt-7 w-full flex flex-col gap-3">
          {hasNext ? (
            <>
              <button
                type="button"
                onClick={handleNextWithInterstitial}
                className="w-full min-h-[54px] px-6 py-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.99] text-[#1D4ED8] font-extrabold text-base shadow-lg transition-all flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <span>Next Level</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={handleBonusHintRewardedInterstitial}
                className="w-full min-h-[48px] px-5 py-3 rounded-2xl bg-blue-950/35 hover:bg-blue-950/50 border border-white/25 text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Watch Ad · Next Level +1 Bonus Hint</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => {
                adManager.hideNativeAd();
                onLevelSelect();
              }}
              className="w-full min-h-[54px] px-6 py-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.99] text-[#1D4ED8] font-extrabold text-base shadow-lg transition-all flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <span>All Levels</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleMainMenu}
            className="w-full min-h-[46px] px-6 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white font-semibold text-sm backdrop-blur-xs transition-colors flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            <Home className="w-4 h-4" />
            <span>Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
