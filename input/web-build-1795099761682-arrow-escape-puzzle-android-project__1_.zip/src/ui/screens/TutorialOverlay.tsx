import React, { useState } from 'react';
import { ArrowRight, X } from 'lucide-react';

interface TutorialOverlayProps {
  onComplete: () => void;
  onSkip: () => void;
}

interface TutorialStep {
  title: string;
  body: string;
  renderIllustration: () => React.ReactNode;
}

const STEPS: TutorialStep[] = [
  {
    title: 'Find an arrow with a clear path.',
    body: 'Look ahead of each arrowhead. An arrow can only move if nothing blocks its straight line to the board edge.',
    renderIllustration: () => (
      <svg viewBox="0 0 200 140" className="w-48 h-32">
        <rect x="16" y="14" width="168" height="112" rx="16" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" />
        {/* Blocked horizontal arrow */}
        <path d="M40 52 H96" stroke="#0F2147" strokeWidth="8" strokeLinecap="round" />
        <path d="M108 52 L92 42 V62 Z" fill="#0F2147" />
        {/* Blocking vertical arrow */}
        <path d="M136 96 V40" stroke="#0F2147" strokeWidth="8" strokeLinecap="round" />
        <path d="M136 28 L126 44 H146 Z" fill="#0F2147" />
        {/* Clear blue arrow */}
        <path d="M44 96 H94" stroke="#2563EB" strokeWidth="8" strokeLinecap="round" />
        <path d="M106 96 L90 86 V106 Z" fill="#2563EB" />
        <line x1="112" y1="96" x2="174" y2="96" stroke="#93C5FD" strokeWidth="3" strokeDasharray="5 5" />
      </svg>
    ),
  },
  {
    title: 'Tap it to let it escape.',
    body: 'Tap any free arrow and it will slide cleanly off the board.',
    renderIllustration: () => (
      <svg viewBox="0 0 200 140" className="w-48 h-32">
        <rect x="16" y="14" width="168" height="112" rx="16" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" />
        <path d="M40 70 H136" stroke="#2563EB" strokeWidth="9" strokeLinecap="round" />
        <path d="M150 70 L132 58 V82 Z" fill="#2563EB" />
        <circle cx="88" cy="70" r="16" fill="#3B82F6" fillOpacity="0.2" />
        <circle cx="88" cy="70" r="8" fill="#2563EB" fillOpacity="0.35" />
      </svg>
    ),
  },
  {
    title: 'Clearing arrows opens paths for others.',
    body: 'Once a blocking arrow leaves, the arrows trapped behind it become free to escape.',
    renderIllustration: () => (
      <svg viewBox="0 0 200 140" className="w-48 h-32">
        <rect x="16" y="14" width="168" height="112" rx="16" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" />
        {/* Newly free arrow */}
        <path d="M44 70 H112" stroke="#2563EB" strokeWidth="8" strokeLinecap="round" />
        <path d="M126 70 L108 59 V81 Z" fill="#2563EB" />
        {/* Ghost of cleared arrow */}
        <path d="M150 106 V42" stroke="#CBD5E1" strokeWidth="6" strokeDasharray="6 6" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    title: 'Tap them all in the right order.',
    body: 'Wrong taps cost a heart. You have 3 hearts per level and helpful hints whenever you need one.',
    renderIllustration: () => (
      <svg viewBox="0 0 200 140" className="w-48 h-32">
        <rect x="16" y="14" width="168" height="112" rx="16" fill="#F8FAFC" stroke="#E2E8F0" strokeWidth="2" />
        <path d="M46 92 V48 H92" fill="none" stroke="#0F2147" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M104 48 L88 38 V58 Z" fill="#0F2147" />
        <path d="M148 48 V92 H102" fill="none" stroke="#2563EB" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M90 92 L106 82 V102 Z" fill="#2563EB" />
      </svg>
    ),
  },
];

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({
  onComplete,
  onSkip,
}) => {
  const [stepIdx, setStepIdx] = useState(0);
  const current = STEPS[stepIdx];
  const isLast = stepIdx === STEPS.length - 1;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="tutorial-title"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-5"
    >
      <div className="w-full max-w-sm rounded-3xl bg-white p-6 sm:p-7 shadow-2xl border border-slate-100 flex flex-col items-center text-center">
        <div className="w-full flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-400 tabular-nums">
            Step {stepIdx + 1} of {STEPS.length}
          </span>
          <button
            type="button"
            onClick={onSkip}
            aria-label="Skip tutorial"
            className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-[#0F2147] py-1 px-2 rounded-lg transition-colors"
          >
            <span>Skip</span>
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="my-4">{current.renderIllustration()}</div>

        <h2
          id="tutorial-title"
          className="text-xl font-extrabold text-[#0F2147] text-balance leading-snug"
        >
          {current.title}
        </h2>
        <p className="mt-2.5 text-sm text-slate-600 leading-relaxed">
          {current.body}
        </p>

        {/* Step dots */}
        <div className="mt-6 flex items-center gap-2" aria-hidden="true">
          {STEPS.map((_, idx) => (
            <span
              key={idx}
              className={`h-2 rounded-full transition-all ${
                idx === stepIdx ? 'w-6 bg-[#2563EB]' : 'w-2 bg-slate-200'
              }`}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={() => {
            if (isLast) {
              onComplete();
            } else {
              setStepIdx((s) => s + 1);
            }
          }}
          className="mt-6 w-full min-h-[50px] px-6 py-3 rounded-2xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-bold text-base shadow-md transition-colors flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <span>{isLast ? 'Start Playing' : 'Next'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
