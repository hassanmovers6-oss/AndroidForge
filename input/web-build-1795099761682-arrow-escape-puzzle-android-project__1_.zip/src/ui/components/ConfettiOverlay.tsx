import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  vr: number;
  alpha: number;
}

const COLORS = ['#FFFFFF', '#DBEAFE', '#93C5FD', '#FDE68A', '#38BDF8'];

export const ConfettiOverlay: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const updateDims = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    updateDims();
    window.addEventListener('resize', updateDims);

    const count = 64;
    const particles: Particle[] = Array.from({ length: count }, (_, i) => {
      const spreadAngle = -Math.PI / 2 + (Math.random() - 0.5) * 1.4;
      const speed = 4 + Math.random() * 7.5;
      return {
        x: canvas.width * (0.2 + Math.random() * 0.6),
        y: canvas.height * (0.35 + (i % 3) * 0.08),
        vx: Math.cos(spreadAngle) * speed + (Math.random() - 0.5) * 3,
        vy: Math.sin(spreadAngle) * speed - Math.random() * 2,
        size: 5 + Math.random() * 5,
        color: COLORS[i % COLORS.length],
        rotation: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.16,
        alpha: 0.95,
      };
    });

    let rafId = 0;
    const start = performance.now();

    const tick = (now: number) => {
      const elapsed = now - start;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      let anyVisible = false;
      for (const p of particles) {
        p.vy += 0.14;
        p.vx *= 0.992;
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.vr;

        if (elapsed > 1800) {
          p.alpha = Math.max(0, p.alpha - 0.022);
        }

        if (p.alpha > 0.02 && p.y < canvas.height + 40) {
          anyVisible = true;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size * 0.32, p.size, p.size * 0.64);
          ctx.restore();
        }
      }

      if (anyVisible && elapsed < 3600) {
        rafId = requestAnimationFrame(tick);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener('resize', updateDims);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-10"
    />
  );
};
