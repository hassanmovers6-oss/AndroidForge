import React from 'react';

interface AppLogoMarkProps {
  size?: number;
}

export const AppLogoMark: React.FC<AppLogoMarkProps> = ({ size = 72 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 88 88"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className="drop-shadow-[0_10px_24px_rgba(37,99,235,0.28)]"
    >
      <defs>
        <linearGradient id="arrowEscapeIconGrad" x1="10" y1="8" x2="78" y2="80" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="80" height="80" rx="22" fill="url(#arrowEscapeIconGrad)" />
      {/* Subtle inner L-shaped navy accent path */}
      <path
        d="M24 58H42V40"
        stroke="#0F2147"
        strokeOpacity="0.35"
        strokeWidth="7.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Escaping crisp white arrow */}
      <path
        d="M26 30H54"
        stroke="#FFFFFF"
        strokeWidth="8"
        strokeLinecap="round"
      />
      <path
        d="M67 30L51 19V41L67 30Z"
        fill="#FFFFFF"
        stroke="#FFFFFF"
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
      {/* Secondary upward arrow */}
      <path
        d="M58 64V48"
        stroke="#DBEAFE"
        strokeWidth="7"
        strokeLinecap="round"
      />
      <path
        d="M58 38L49.5 50H66.5L58 38Z"
        fill="#DBEAFE"
        stroke="#DBEAFE"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
};
