import React, { useEffect, useRef, useState } from 'react';
import { Minus, Plus, RotateCcw } from 'lucide-react';
import { hitTestArrow } from '../../domain/engine/collisionEngine';
import { Arrow, Direction, Point } from '../../domain/model/types';

export interface EscapingAnimation {
  arrow: Arrow;
  startTime: number;
  durationMs: number;
}

export interface BlockedAnimation {
  arrowId: number;
  startTime: number;
  durationMs: number;
}

interface ArrowBoardCanvasProps {
  arrows: readonly Arrow[];
  gridSize: number;
  showGrid: boolean;
  highlightedArrowId: number | null;
  escapingArrows: readonly EscapingAnimation[];
  blockedAnimation: BlockedAnimation | null;
  disabled?: boolean;
  onArrowTap: (arrowId: number) => void;
}

function dirDelta(dir: Direction): Point {
  switch (dir) {
    case 'UP':
      return { x: 0, y: -1 };
    case 'DOWN':
      return { x: 0, y: 1 };
    case 'LEFT':
      return { x: -1, y: 0 };
    case 'RIGHT':
      return { x: 1, y: 0 };
  }
}

export function getPolylinePoints(arrow: Arrow): Point[] {
  if (arrow.segments.length === 0) return [];
  const pts: Point[] = [arrow.segments[0].start];
  for (const seg of arrow.segments) {
    pts.push(seg.end);
  }
  return pts;
}

function computePolylineLength(pts: readonly Point[]): number {
  let len = 0;
  for (let i = 1; i < pts.length; i++) {
    len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  }
  return len;
}

/**
 * Computes the snake-unwinding polyline at travel distance `travelPx` along the arrow's own path.
 * Bent turns smoothly slide forward through `exitPoint` and straighten out in `direction`.
 */
function computeUnwoundPolyline(
  pxPts: readonly Point[],
  dir: Point,
  travelPx: number
): { pts: Point[]; headPos: Point } {
  const totalLen = computePolylineLength(pxPts);
  const exitPt = pxPts[pxPts.length - 1];
  const headPos: Point = {
    x: exitPt.x + dir.x * travelPx,
    y: exitPt.y + dir.y * travelPx,
  };

  if (travelPx <= 0.001) {
    return { pts: [...pxPts], headPos: exitPt };
  }

  if (travelPx >= totalLen) {
    const tailPastExit = travelPx - totalLen;
    const tailPos: Point = {
      x: exitPt.x + dir.x * tailPastExit,
      y: exitPt.y + dir.y * tailPastExit,
    };
    return { pts: [tailPos, headPos], headPos };
  }

  // Slice remaining tail of original polyline starting at arc-length = travelPx
  let remainingSkip = travelPx;
  const sliced: Point[] = [];
  let started = false;

  for (let i = 1; i < pxPts.length; i++) {
    const a = pxPts[i - 1];
    const b = pxPts[i];
    const segLen = Math.hypot(b.x - a.x, b.y - a.y);

    if (!started) {
      if (remainingSkip <= segLen + 1e-6) {
        const t = segLen > 1e-6 ? remainingSkip / segLen : 0;
        sliced.push({
          x: a.x + (b.x - a.x) * t,
          y: a.y + (b.y - a.y) * t,
        });
        sliced.push(b);
        started = true;
      } else {
        remainingSkip -= segLen;
      }
    } else {
      sliced.push(b);
    }
  }

  // Extend straight ahead from exitPoint to headPos
  if (sliced.length === 0) {
    sliced.push(exitPt);
  }
  const last = sliced[sliced.length - 1];
  if (Math.hypot(headPos.x - last.x, headPos.y - last.y) > 0.5) {
    sliced.push(headPos);
  }

  return { pts: sliced, headPos };
}

function drawPolylineArrow(
  ctx: CanvasRenderingContext2D,
  pxPts: readonly Point[],
  dir: Point,
  strokePx: number,
  color: string,
  options?: {
    alpha?: number;
    glowColor?: string;
    glowBlur?: number;
  }
): void {
  if (pxPts.length < 2) return;

  const alpha = options?.alpha ?? 1;
  const lastIdx = pxPts.length - 1;
  const headCenter = pxPts[lastIdx];

  // Pull shaft endpoint slightly inside arrowhead base for clean seam
  const shaftEnd = {
    x: headCenter.x - dir.x * strokePx * 0.45,
    y: headCenter.y - dir.y * strokePx * 0.45,
  };

  // Avoid reversing the last tiny segment if shorter than pull-back
  const prevPt = pxPts[lastIdx - 1];
  const lastSegLen = Math.hypot(headCenter.x - prevPt.x, headCenter.y - prevPt.y);
  const drawPts =
    lastSegLen > strokePx * 0.5
      ? [...pxPts.slice(0, lastIdx), shaftEnd]
      : [...pxPts];

  ctx.save();
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = strokePx;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (options?.glowColor && options?.glowBlur) {
    ctx.shadowColor = options.glowColor;
    ctx.shadowBlur = options.glowBlur;
  }

  ctx.beginPath();
  ctx.moveTo(drawPts[0].x, drawPts[0].y);

  for (let i = 1; i < drawPts.length - 1; i++) {
    const prev = drawPts[i - 1];
    const curr = drawPts[i];
    const next = drawPts[i + 1];
    const d1 = Math.hypot(curr.x - prev.x, curr.y - prev.y);
    const d2 = Math.hypot(next.x - curr.x, next.y - curr.y);
    const radius = Math.min(d1 * 0.44, d2 * 0.44, strokePx * 1.15);
    if (radius > 0.5) {
      ctx.arcTo(curr.x, curr.y, next.x, next.y, radius);
    } else {
      ctx.lineTo(curr.x, curr.y);
    }
  }
  const finalPt = drawPts[drawPts.length - 1];
  ctx.lineTo(finalPt.x, finalPt.y);
  ctx.stroke();

  // Sleek realistic triangular arrowhead with subtle swept notch
  const tipPos = {
    x: headCenter.x + dir.x * strokePx * 1.05,
    y: headCenter.y + dir.y * strokePx * 1.05,
  };
  const wingBack = {
    x: headCenter.x - dir.x * strokePx * 0.55,
    y: headCenter.y - dir.y * strokePx * 0.55,
  };
  const notchCenter = {
    x: headCenter.x - dir.x * strokePx * 0.34,
    y: headCenter.y - dir.y * strokePx * 0.34,
  };
  const perp = { x: -dir.y, y: dir.x };
  const halfWing = strokePx * 1.24;

  ctx.beginPath();
  ctx.moveTo(tipPos.x, tipPos.y);
  ctx.lineTo(wingBack.x + perp.x * halfWing, wingBack.y + perp.y * halfWing);
  ctx.lineTo(notchCenter.x, notchCenter.y);
  ctx.lineTo(wingBack.x - perp.x * halfWing, wingBack.y - perp.y * halfWing);
  ctx.closePath();
  ctx.fill();

  ctx.lineWidth = Math.max(0.75, strokePx * 0.14);
  ctx.stroke();

  ctx.restore();
}

export function drawArrowOnContext(
  ctx: CanvasRenderingContext2D,
  arrow: Arrow,
  boardSize: number,
  color: string,
  options?: {
    offsetX?: number;
    offsetY?: number;
    alpha?: number;
    glowColor?: string;
    glowBlur?: number;
    strokeScale?: number;
    unravelDistancePx?: number;
  }
): void {
  const normPts = getPolylinePoints(arrow);
  if (normPts.length < 2) return;

  const offsetX = options?.offsetX ?? 0;
  const offsetY = options?.offsetY ?? 0;
  const strokeScale = options?.strokeScale ?? 1;
  const strokePx = Math.max(1.9, arrow.pathWidth * boardSize * strokeScale);
  const dir = dirDelta(arrow.direction);

  const pxPts = normPts.map((p) => ({
    x: p.x * boardSize + offsetX,
    y: p.y * boardSize + offsetY,
  }));

  if (options?.unravelDistancePx !== undefined) {
    const { pts } = computeUnwoundPolyline(pxPts, dir, options.unravelDistancePx);
    drawPolylineArrow(ctx, pts, dir, strokePx, color, {
      alpha: options.alpha,
      glowColor: options.glowColor,
      glowBlur: options.glowBlur,
    });
    return;
  }

  drawPolylineArrow(ctx, pxPts, dir, strokePx, color, {
    alpha: options?.alpha,
    glowColor: options?.glowColor,
    glowBlur: options?.glowBlur,
  });
}

function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

export function getEscapeDurationMs(arrow: Arrow): number {
  const normLen = computePolylineLength(getPolylinePoints(arrow));
  // Longer bent arrows take slightly longer so the player clearly watches them unbend & straighten
  return Math.round(360 + Math.min(340, normLen * 440));
}

export const ArrowBoardCanvas: React.FC<ArrowBoardCanvasProps> = ({
  arrows,
  gridSize,
  showGrid,
  highlightedArrowId,
  escapingArrows,
  blockedAnimation,
  disabled = false,
  onArrowTap,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [boardSize, setBoardSize] = useState(360);
  const [hoveringArrow, setHoveringArrow] = useState(false);

  // Zoom & Pan state (helpful for dense 100-170+ arrow silhouette levels)
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState<Point>({ x: 0, y: 0 });
  const dragRef = useRef<{
    active: boolean;
    pointerId: number;
    startX: number;
    startY: number;
    startPanX: number;
    startPanY: number;
    moved: boolean;
  } | null>(null);
  const pinchRef = useRef<Map<number, Point>>(new Map());
  const pinchStartDistRef = useRef<number | null>(null);
  const pinchStartZoomRef = useRef<number>(1);

  const supportsZoom = gridSize >= 14;

  // Reset zoom/pan cleanly when level grid changes
  useEffect(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, [gridSize]);

  const clampPan = (nextPan: Point, targetZoom: number, size: number): Point => {
    if (targetZoom <= 1.01) return { x: 0, y: 0 };
    const maxOffset = ((targetZoom - 1) * size) / 2 + size * 0.08;
    return {
      x: Math.max(-maxOffset, Math.min(maxOffset, nextPan.x)),
      y: Math.max(-maxOffset, Math.min(maxOffset, nextPan.y)),
    };
  };

  const applyZoom = (nextZoomRaw: number) => {
    const nextZoom = Math.max(1, Math.min(3.2, Number(nextZoomRaw.toFixed(2))));
    setZoom(nextZoom);
    setPan((prev) => clampPan(prev, nextZoom, boardSize));
  };

  // Track container dimensions cleanly via ResizeObserver
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const updateSize = () => {
      const rect = el.getBoundingClientRect();
      const size = Math.max(220, Math.floor(Math.min(rect.width, rect.height)));
      setBoardSize(size);
    };

    updateSize();
    const observer = new ResizeObserver(updateSize);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // State-driven Canvas drawing + rAF only while animations/pulse are active
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr =
      typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 3) : 1;
    canvas.width = Math.round(boardSize * dpr);
    canvas.height = Math.round(boardSize * dpr);

    let rafId = 0;

    const renderFrame = (now: number) => {
      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, boardSize, boardSize);

      // Apply centered zoom + pan transform
      ctx.translate(boardSize / 2 + pan.x, boardSize / 2 + pan.y);
      ctx.scale(zoom, zoom);
      ctx.translate(-boardSize / 2, -boardSize / 2);

      // Subtle optional grid overlay
      if (showGrid && gridSize > 0) {
        const margin = 0.055 * boardSize;
        const playable = boardSize - 2 * margin;
        const cellSize = playable / gridSize;

        ctx.save();
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.04)';
        ctx.lineWidth = 0.75 / zoom;
        for (let i = 0; i <= gridSize; i++) {
          const pos = margin + i * cellSize;
          ctx.beginPath();
          ctx.moveTo(pos, margin);
          ctx.lineTo(pos, boardSize - margin);
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(margin, pos);
          ctx.lineTo(boardSize - margin, pos);
          ctx.stroke();
        }

        ctx.fillStyle = 'rgba(15, 23, 42, 0.1)';
        const dotR = Math.max(0.8, Math.min(2.0, cellSize * 0.06));
        for (let r = 0; r < gridSize; r++) {
          for (let c = 0; c < gridSize; c++) {
            const cx = margin + (c + 0.5) * cellSize;
            const cy = margin + (r + 0.5) * cellSize;
            ctx.beginPath();
            ctx.arc(cx, cy, dotR, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
      }

      const prefersReducedMotion =
        typeof window !== 'undefined' &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      // Draw resting active arrows
      for (const arrow of arrows) {
        const isHighlighted = arrow.id === highlightedArrowId;
        const isBlocked =
          blockedAnimation !== null && blockedAnimation.arrowId === arrow.id;

        let offsetX = 0;
        let offsetY = 0;
        let color = '#0F172A';
        let glowColor: string | undefined;
        let glowBlur = 0;
        let strokeScale = 1;

        if (isBlocked && blockedAnimation) {
          const elapsed = now - blockedAnimation.startTime;
          const t = Math.min(1, Math.max(0, elapsed / blockedAnimation.durationMs));
          if (t < 1) {
            color = '#DC2626';
            if (!prefersReducedMotion) {
              const shake =
                Math.sin(t * Math.PI * 4) *
                (1 - t) *
                arrow.pathWidth *
                boardSize *
                0.42;
              const d = dirDelta(arrow.direction);
              offsetX = d.x * shake + d.y * shake * 0.3;
              offsetY = d.y * shake + d.x * shake * 0.3;
            }
          }
        } else if (isHighlighted) {
          color = '#2563EB';
          const pulse = prefersReducedMotion
            ? 0.7
            : 0.55 + 0.45 * Math.sin(now * 0.0065);
          glowColor = `rgba(37, 99, 235, ${0.45 + pulse * 0.3})`;
          glowBlur = 10 + pulse * 8;
          strokeScale = 1.12 + pulse * 0.06;
        }

        drawArrowOnContext(ctx, arrow, boardSize, color, {
          offsetX,
          offsetY,
          glowColor,
          glowBlur,
          strokeScale,
        });
      }

      // Draw escaping arrows unwinding smoothly along their path and straightening out
      for (const esc of escapingArrows) {
        const elapsed = now - esc.startTime;
        const rawT = Math.min(1, Math.max(0, elapsed / esc.durationMs));
        if (rawT >= 1) continue;

        const normPts = getPolylinePoints(esc.arrow);
        const totalPxLen = computePolylineLength(normPts) * boardSize;
        const totalTravelPx = totalPxLen + boardSize * 0.92;
        const eased = prefersReducedMotion ? 1 : easeInOutQuad(rawT);
        const travelPx = totalTravelPx * eased;

        // Keep arrow solid while it unbends; fade out smoothly only near board exit
        const straightenRatio = Math.min(0.75, totalPxLen / Math.max(1, totalTravelPx));
        const fadeStart = Math.max(straightenRatio + 0.1, 0.65);
        const alpha =
          rawT < fadeStart ? 1 : Math.max(0, 1 - (rawT - fadeStart) / (1 - fadeStart));

        drawArrowOnContext(ctx, esc.arrow, boardSize, '#2563EB', {
          alpha,
          glowColor: 'rgba(37, 99, 235, 0.32)',
          glowBlur: 8,
          strokeScale: 1.06,
          unravelDistancePx: travelPx,
        });
      }

      ctx.restore();

      const hasActiveEscapes = escapingArrows.some(
        (e) => now - e.startTime < e.durationMs
      );
      const hasActiveBlocked =
        blockedAnimation !== null &&
        now - blockedAnimation.startTime < blockedAnimation.durationMs;
      const needsPulse = highlightedArrowId !== null && !prefersReducedMotion;

      if (hasActiveEscapes || hasActiveBlocked || needsPulse) {
        rafId = requestAnimationFrame(renderFrame);
      }
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [
    arrows,
    boardSize,
    showGrid,
    gridSize,
    highlightedArrowId,
    escapingArrows,
    blockedAnimation,
    zoom,
    pan,
  ]);

  const toNormalizedPoint = (clientX: number, clientY: number): Point | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;

    // Inverse-map screen coordinates through current pan & zoom back into [0..1] board space
    const sx = clientX - rect.left;
    const sy = clientY - rect.top;
    const bx = (sx - rect.width / 2 - pan.x) / zoom + rect.width / 2;
    const by = (sy - rect.height / 2 - pan.y) / zoom + rect.height / 2;

    return {
      x: bx / rect.width,
      y: by / rect.height,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (disabled) return;
    pinchRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pinchRef.current.size === 2 && supportsZoom) {
      const pts = Array.from(pinchRef.current.values());
      pinchStartDistRef.current = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
      pinchStartZoomRef.current = zoom;
      dragRef.current = null;
      return;
    }

    if (pinchRef.current.size === 1) {
      dragRef.current = {
        active: true,
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        startPanX: pan.x,
        startPanY: pan.y,
        moved: false,
      };
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (pinchRef.current.has(e.pointerId)) {
      pinchRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }

    if (pinchRef.current.size === 2 && supportsZoom && pinchStartDistRef.current) {
      const pts = Array.from(pinchRef.current.values());
      const dist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
      const scaleFactor = dist / pinchStartDistRef.current;
      applyZoom(pinchStartZoomRef.current * scaleFactor);
      return;
    }

    if (
      dragRef.current &&
      dragRef.current.active &&
      dragRef.current.pointerId === e.pointerId &&
      zoom > 1.01
    ) {
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      if (Math.hypot(dx, dy) > 6) {
        dragRef.current.moved = true;
        setPan(
          clampPan(
            { x: dragRef.current.startPanX + dx, y: dragRef.current.startPanY + dy },
            zoom,
            boardSize
          )
        );
      }
      return;
    }

    if (disabled) {
      if (hoveringArrow) setHoveringArrow(false);
      return;
    }
    const pt = toNormalizedPoint(e.clientX, e.clientY);
    if (!pt) return;
    const hit = hitTestArrow(pt, arrows);
    const shouldHover = hit !== null;
    if (shouldHover !== hoveringArrow) {
      setHoveringArrow(shouldHover);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    pinchRef.current.delete(e.pointerId);
    if (pinchRef.current.size < 2) {
      pinchStartDistRef.current = null;
    }

    const drag = dragRef.current;
    if (drag && drag.pointerId === e.pointerId) {
      const wasDrag = drag.moved;
      dragRef.current = null;
      if (!wasDrag && !disabled) {
        const pt = toNormalizedPoint(e.clientX, e.clientY);
        if (pt) {
          const hit = hitTestArrow(pt, arrows);
          if (hit) {
            onArrowTap(hit.id);
          }
        }
      }
    }
  };

  const handlePointerCancel = (e: React.PointerEvent<HTMLCanvasElement>) => {
    pinchRef.current.delete(e.pointerId);
    pinchStartDistRef.current = null;
    if (dragRef.current?.pointerId === e.pointerId) {
      dragRef.current = null;
    }
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    if (!supportsZoom) return;
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.15 : 0.87;
    applyZoom(zoom * factor);
  };

  return (
    <div
      ref={containerRef}
      className="relative flex w-full aspect-square max-w-[460px] items-center justify-center rounded-3xl border border-slate-200/80 bg-white shadow-[0_12px_36px_-18px_rgba(15,23,42,0.12)] overflow-hidden select-none touch-none"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
        onPointerLeave={() => setHoveringArrow(false)}
        onWheel={handleWheel}
        aria-label="Arrow puzzle board"
        style={{ width: boardSize, height: boardSize }}
        className={`block touch-none ${
          hoveringArrow && !disabled ? 'cursor-pointer' : 'cursor-default'
        }`}
      />

      {/* Subtle zoom controls for dense multi-arrow silhouettes */}
      {supportsZoom && (
        <div className="absolute bottom-2.5 right-2.5 flex items-center gap-1 rounded-xl bg-white/90 backdrop-blur-xs border border-slate-200/90 p-1 shadow-xs">
          <button
            type="button"
            onClick={() => applyZoom(zoom - 0.5)}
            disabled={zoom <= 1}
            aria-label="Zoom out"
            className="w-7 h-7 rounded-lg flex items-center justify-center text-[#0F2147] hover:bg-slate-100 disabled:opacity-35 transition-colors"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          {zoom > 1.05 && (
            <button
              type="button"
              onClick={() => {
                setZoom(1);
                setPan({ x: 0, y: 0 });
              }}
              aria-label="Reset zoom"
              className="px-1.5 h-7 rounded-lg flex items-center gap-1 text-[11px] font-bold text-[#2563EB] hover:bg-blue-50 tabular-nums transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{zoom.toFixed(1)}×</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => applyZoom(zoom + 0.5)}
            disabled={zoom >= 3.2}
            aria-label="Zoom in"
            className="w-7 h-7 rounded-lg flex items-center justify-center text-[#0F2147] hover:bg-slate-100 disabled:opacity-35 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
