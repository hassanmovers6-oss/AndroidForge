import React, { useEffect, useRef } from 'react';
import { Level } from '../../domain/model/types';
import { drawArrowOnContext } from './ArrowBoardCanvas';

interface MiniBoardPreviewProps {
  level: Level;
  size?: number;
}

export const MiniBoardPreview: React.FC<MiniBoardPreviewProps> = ({
  level,
  size = 148,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 2) : 1;
    canvas.width = Math.round(size * dpr);
    canvas.height = Math.round(size * dpr);

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, size, size);

    for (const arrow of level.arrows) {
      drawArrowOnContext(ctx, arrow, size, '#0F2147');
    }

    ctx.restore();
  }, [level, size]);

  return (
    <canvas
      ref={canvasRef}
      style={{ width: size, height: size }}
      aria-label={`Completed Level ${level.id} layout preview`}
      className="block"
    />
  );
};
