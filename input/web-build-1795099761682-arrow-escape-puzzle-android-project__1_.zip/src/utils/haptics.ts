function vibrate(enabled: boolean, pattern: number | number[]): void {
  if (!enabled) return;
  if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore environments blocking vibration
    }
  }
}

export function triggerEscapeHaptic(enabled: boolean): void {
  vibrate(enabled, 12);
}

export function triggerBlockedHaptic(enabled: boolean): void {
  vibrate(enabled, [22, 30, 22]);
}

export function triggerCompleteHaptic(enabled: boolean): void {
  vibrate(enabled, [18, 40, 32]);
}
