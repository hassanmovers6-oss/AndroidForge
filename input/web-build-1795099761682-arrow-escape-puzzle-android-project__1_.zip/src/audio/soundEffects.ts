let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!audioCtx) {
    try {
      audioCtx = new Ctx();
    } catch {
      return null;
    }
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

function playTone(
  freq: number,
  durationSec: number,
  type: OscillatorType,
  gainPeak: number,
  endFreq?: number,
  delaySec = 0
): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime + delaySec;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), now + durationSec);
    }

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainPeak, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + durationSec + 0.02);
  } catch {
    // Ignore audio errors
  }
}

export function playEscapeSound(enabled: boolean): void {
  if (!enabled) return;
  playTone(520, 0.14, 'sine', 0.12, 840);
}

export function playBlockedSound(enabled: boolean): void {
  if (!enabled) return;
  playTone(190, 0.11, 'triangle', 0.14, 130);
}

export function playHintSound(enabled: boolean): void {
  if (!enabled) return;
  playTone(660, 0.12, 'sine', 0.09);
  playTone(880, 0.16, 'sine', 0.09, undefined, 0.08);
}

export function playCompleteSound(enabled: boolean): void {
  if (!enabled) return;
  playTone(523.25, 0.16, 'sine', 0.11, undefined, 0);
  playTone(659.25, 0.16, 'sine', 0.11, undefined, 0.09);
  playTone(783.99, 0.18, 'sine', 0.12, undefined, 0.18);
  playTone(1046.5, 0.34, 'sine', 0.13, undefined, 0.27);
}

export function playUiClickSound(enabled: boolean): void {
  if (!enabled) return;
  playTone(440, 0.045, 'sine', 0.05);
}
