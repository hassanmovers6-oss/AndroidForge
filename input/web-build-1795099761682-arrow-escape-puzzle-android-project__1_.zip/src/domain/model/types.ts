export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type Difficulty = 'EASY' | 'NORMAL' | 'HARD' | 'EXPERT';

export interface Point {
  x: number;
  y: number;
}

export interface ArrowSegment {
  start: Point;
  end: Point;
}

export interface Arrow {
  id: number;
  direction: Direction;
  segments: ArrowSegment[];
  exitPoint: Point;
  pathWidth: number;
}

export interface LevelMetrics {
  arrowCount: number;
  initiallyFreeCount: number;
  maxDependencyDepth: number;
  avgAvailableMoves: number;
  misleadingBlockedCount: number;
  totalTurns: number;
  boardDensity: number;
  difficultyScore: number;
}

export interface Level {
  id: number;
  difficulty: Difficulty;
  gridSize: number;
  arrows: Arrow[];
  startingLives: number;
  startingHints: number;
  metrics: LevelMetrics;
}

export interface SolutionResult {
  solvable: boolean;
  moveSequence: number[];
  metrics: LevelMetrics;
}

export interface GameState {
  level: Level;
  remainingArrows: Arrow[];
  lives: number;
  hintsRemaining: number;
  highlightedArrowId: number | null;
  isComplete: boolean;
  isGameOver: boolean;
  movesTaken: number;
}
