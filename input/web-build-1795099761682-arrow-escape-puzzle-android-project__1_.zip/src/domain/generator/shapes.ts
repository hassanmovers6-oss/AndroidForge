export interface ShapeDefinition {
  name: string;
  contains: (col: number, row: number, gridSize: number) => boolean;
}

function norm(col: number, row: number, gridSize: number): { nx: number; ny: number } {
  return {
    nx: ((col + 0.5) / gridSize) * 2 - 1, // -1 .. 1
    ny: ((row + 0.5) / gridSize) * 2 - 1, // -1 .. 1
  };
}

export const SHAPES: Record<string, ShapeDefinition> = {
  square: {
    name: 'Square',
    contains: () => true,
  },

  diamond: {
    name: 'Diamond',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      return Math.abs(nx) + Math.abs(ny) <= 1.08;
    },
  },

  cross: {
    name: 'Plus',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      return Math.abs(nx) <= 0.42 || Math.abs(ny) <= 0.42;
    },
  },

  circle: {
    name: 'Circle',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      return nx * nx + ny * ny <= 0.94;
    },
  },

  ring: {
    name: 'Ring',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const d2 = nx * nx + ny * ny;
      return d2 <= 0.96 && d2 >= 0.14;
    },
  },

  heart: {
    name: 'Heart',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const x = nx * 1.15;
      const y = -ny * 1.15 + 0.12;
      const a = x * x + y * y - 0.72;
      return a * a * a - x * x * y * y * y <= 0.04;
    },
  },

  mushroom: {
    name: 'Mushroom',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      // Cap: broad asymmetric dome in upper half (matching reference silhouette)
      const capDist = (nx * nx) / 0.88 + ((ny + 0.22) * (ny + 0.22)) / 0.56;
      const inCap = ny <= 0.18 && capDist <= 1.0;
      // Left & right cap brim flare
      const inBrim =
        ny > -0.18 &&
        ny <= 0.22 &&
        Math.abs(nx) <= 0.94 &&
        (nx * nx) / 0.96 + ((ny - 0.04) * (ny - 0.04)) / 0.14 <= 1.0;
      // Rounded bulbous stem in lower half
      const stemBulb = (nx * nx) / 0.24 + ((ny - 0.52) * (ny - 0.52)) / 0.24 <= 1.0;
      const stemNeck = ny >= 0.05 && ny <= 0.55 && Math.abs(nx) <= 0.26;
      return inCap || inBrim || stemBulb || stemNeck;
    },
  },

  star: {
    name: 'Star',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const angle = Math.atan2(ny, nx) + Math.PI / 2;
      const rad = Math.hypot(nx, ny);
      const starR = 0.62 + 0.34 * Math.cos(5 * angle);
      return rad <= starR;
    },
  },

  tree: {
    name: 'Pine Tree',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const tier1 = ny >= -0.95 && ny <= -0.25 && Math.abs(nx) <= (ny + 0.98) * 0.65;
      const tier2 = ny >= -0.45 && ny <= 0.2 && Math.abs(nx) <= (ny + 0.65) * 0.78;
      const tier3 = ny >= -0.05 && ny <= 0.58 && Math.abs(nx) <= (ny + 0.32) * 0.92;
      const trunk = ny >= 0.52 && ny <= 0.94 && Math.abs(nx) <= 0.2;
      return tier1 || tier2 || tier3 || trunk;
    },
  },

  crown: {
    name: 'Crown',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      if (ny > 0.68 || ny < -0.68) return false;
      if (ny >= 0.15 && Math.abs(nx) <= 0.85) return true;
      // Three peaks
      const leftPeak = nx <= -0.35 && ny >= -0.55 + Math.abs(nx + 0.65) * 1.4 && Math.abs(nx) <= 0.88;
      const midPeak = Math.abs(nx) <= 0.38 && ny >= -0.66 + Math.abs(nx) * 1.5;
      const rightPeak = nx >= 0.35 && ny >= -0.55 + Math.abs(nx - 0.65) * 1.4 && Math.abs(nx) <= 0.88;
      return leftPeak || midPeak || rightPeak;
    },
  },

  rocket: {
    name: 'Rocket',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const nose = ny <= -0.35 && Math.abs(nx) <= (ny + 0.98) * 0.55 && ny >= -0.95;
      const body = ny > -0.35 && ny <= 0.58 && Math.abs(nx) <= 0.34;
      const leftFin = ny >= 0.15 && ny <= 0.78 && nx <= -0.25 && nx >= -0.78 && Math.abs(nx) <= (ny + 0.15) * 0.85;
      const rightFin = ny >= 0.15 && ny <= 0.78 && nx >= 0.25 && nx <= 0.78 && Math.abs(nx) <= (ny + 0.15) * 0.85;
      const thruster = ny > 0.58 && ny <= 0.88 && Math.abs(nx) <= 0.22;
      return nose || body || leftFin || rightFin || thruster;
    },
  },

  butterfly: {
    name: 'Butterfly',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const body = Math.abs(nx) <= 0.14 && Math.abs(ny) <= 0.75;
      const upperWing =
        ((Math.abs(nx) - 0.48) ** 2) / 0.24 + ((ny + 0.28) ** 2) / 0.24 <= 1.0;
      const lowerWing =
        ((Math.abs(nx) - 0.42) ** 2) / 0.18 + ((ny - 0.36) ** 2) / 0.20 <= 1.0;
      return body || upperWing || lowerWing;
    },
  },

  hourglass: {
    name: 'Hourglass',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      if (Math.abs(ny) > 0.88) return false;
      const cap = Math.abs(ny) >= 0.72 && Math.abs(nx) <= 0.84;
      const waist = Math.abs(nx) <= 0.14 + Math.abs(ny) * 0.82;
      return cap || waist;
    },
  },

  shield: {
    name: 'Shield',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      if (ny < -0.82 || ny > 0.9) return false;
      if (ny <= 0.05) return Math.abs(nx) <= 0.82;
      const t = (ny - 0.05) / 0.85;
      return Math.abs(nx) <= 0.82 * (1 - t * t);
    },
  },

  apple: {
    name: 'Apple',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const leftLobe = ((nx + 0.24) ** 2) / 0.42 + ((ny - 0.05) ** 2) / 0.62 <= 1.0;
      const rightLobe = ((nx - 0.24) ** 2) / 0.42 + ((ny - 0.05) ** 2) / 0.62 <= 1.0;
      const stem = ny >= -0.88 && ny <= -0.45 && Math.abs(nx - 0.04) <= 0.1;
      const leaf = ((nx - 0.26) ** 2) / 0.07 + ((ny + 0.72) ** 2) / 0.035 <= 1.0;
      return leftLobe || rightLobe || stem || leaf;
    },
  },

  anchor: {
    name: 'Anchor',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const ring = ((nx ** 2 + (ny + 0.68) ** 2) <= 0.085) && ((nx ** 2 + (ny + 0.68) ** 2) >= 0.012);
      const shaft = Math.abs(nx) <= 0.14 && ny >= -0.55 && ny <= 0.78;
      const crossbar = ny >= -0.42 && ny <= -0.22 && Math.abs(nx) <= 0.48;
      const hook =
        ny >= 0.15 &&
        ((nx * nx) / 0.72 + ((ny - 0.15) * (ny - 0.15)) / 0.56 <= 1.0) &&
        ((nx * nx) / 0.38 + ((ny - 0.12) * (ny - 0.12)) / 0.28 >= 1.0);
      return ring || shaft || crossbar || hook;
    },
  },

  fish: {
    name: 'Fish',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const body = ((nx + 0.15) ** 2) / 0.56 + (ny ** 2) / 0.36 <= 1.0;
      const tail = nx >= 0.32 && nx <= 0.9 && Math.abs(ny) <= (nx - 0.22) * 0.95;
      return body || tail;
    },
  },

  key: {
    name: 'Key',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const bow = (nx + 0.44) ** 2 + ny ** 2 <= 0.24 && (nx + 0.44) ** 2 + ny ** 2 >= 0.035;
      const blade = Math.abs(ny) <= 0.13 && nx >= -0.05 && nx <= 0.88;
      const tooth1 = nx >= 0.42 && nx <= 0.56 && ny >= 0.1 && ny <= 0.42;
      const tooth2 = nx >= 0.68 && nx <= 0.84 && ny >= 0.1 && ny <= 0.48;
      return bow || blade || tooth1 || tooth2;
    },
  },

  bell: {
    name: 'Bell',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const top = ny >= -0.88 && ny <= -0.58 && Math.abs(nx) <= 0.16;
      const dome = ny >= -0.62 && ny <= 0.36 && Math.abs(nx) <= 0.22 + (ny + 0.62) * 0.46;
      const rim = ny > 0.34 && ny <= 0.56 && Math.abs(nx) <= 0.84;
      const clapper = nx * nx + (ny - 0.68) ** 2 <= 0.055;
      return top || dome || rim || clapper;
    },
  },

  trophy: {
    name: 'Trophy',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const cup = ny >= -0.78 && ny <= 0.18 && Math.abs(nx) <= 0.58 - (ny + 0.78) * 0.28;
      const handles =
        ny >= -0.62 &&
        ny <= -0.05 &&
        Math.abs(nx) >= 0.46 &&
        Math.abs(nx) <= 0.84 &&
        ((Math.abs(nx) - 0.52) ** 2) / 0.12 + ((ny + 0.34) ** 2) / 0.12 <= 1.0;
      const stem = ny > 0.16 && ny <= 0.58 && Math.abs(nx) <= 0.16;
      const base = ny > 0.56 && ny <= 0.84 && Math.abs(nx) <= 0.46;
      return cup || handles || stem || base;
    },
  },

  house: {
    name: 'House',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const roof = ny >= -0.88 && ny <= -0.05 && Math.abs(nx) <= (ny + 0.92) * 1.05;
      const walls = ny > -0.05 && ny <= 0.84 && Math.abs(nx) <= 0.68;
      return roof || walls;
    },
  },

  hexagon: {
    name: 'Hexagon',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      return Math.abs(ny) <= 0.82 && Math.abs(nx) * 0.866 + Math.abs(ny) * 0.5 <= 0.86;
    },
  },

  crescent: {
    name: 'Crescent',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const outer = nx * nx + ny * ny <= 0.92;
      const cutout = (nx - 0.36) ** 2 + (ny + 0.1) ** 2 <= 0.52;
      return outer && !cutout;
    },
  },

  owl: {
    name: 'Owl',
    contains: (c, r, n) => {
      const { nx, ny } = norm(c, r, n);
      const body = (nx * nx) / 0.58 + ((ny - 0.14) * (ny - 0.14)) / 0.66 <= 1.0;
      const head = (nx * nx) / 0.44 + ((ny + 0.44) * (ny + 0.44)) / 0.22 <= 1.0;
      const earL = ny >= -0.84 && ny <= -0.52 && nx <= -0.22 && nx >= -0.58;
      const earR = ny >= -0.84 && ny <= -0.52 && nx >= 0.22 && nx <= 0.58;
      return body || head || earL || earR;
    },
  },
};

export function getShapeMask(shapeKey: string, gridSize: number): boolean[][] {
  const shape = SHAPES[shapeKey] ?? SHAPES.square;
  const mask: boolean[][] = Array.from({ length: gridSize }, (_, r) =>
    Array.from({ length: gridSize }, (_, c) => shape.contains(c, r, gridSize))
  );
  return mask;
}
