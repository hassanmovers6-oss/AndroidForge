import { isArrowFree } from '../engine/collisionEngine';
import {
  computeLevelMetrics,
  solveLevel,
  validateSolutionSequence,
} from '../engine/puzzleSolver';
import {
  Arrow,
  ArrowSegment,
  Difficulty,
  Direction,
  Level,
  Point,
} from '../model/types';
import { getShapeMask } from './shapes';

interface GridCell {
  col: number;
  row: number;
}

interface TierConfig {
  difficulty: Difficulty;
  shapeKey: string;
  gridSize: number;
  minArrows: number;
  minLen: number;
  maxLen: number;
  maxTurns: number;
  minDepth: number;
  startingHints: number;
}

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function cellToPoint(cell: GridCell, gridSize: number): Point {
  const margin = 0.055;
  const playable = 1 - 2 * margin;
  const cellSize = playable / gridSize;
  return {
    x: Number((margin + (cell.col + 0.5) * cellSize).toFixed(5)),
    y: Number((margin + (cell.row + 0.5) * cellSize).toFixed(5)),
  };
}

function computePathWidth(gridSize: number): number {
  const margin = 0.055;
  const playable = 1 - 2 * margin;
  const cellSize = playable / gridSize;
  // Sleek, crisp line thickness proportional to cell pitch (matches dense silhouette style)
  return Number(Math.max(0.0082, Math.min(0.036, cellSize * 0.24)).toFixed(5));
}

function buildArrowFromGridCells(
  id: number,
  cells: GridCell[],
  gridSize: number
): Arrow {
  if (cells.length < 2) {
    throw new Error(`Arrow ${id} must have at least 2 cells`);
  }

  const head = cells[cells.length - 1];
  const prev = cells[cells.length - 2];
  const dc = head.col - prev.col;
  const dr = head.row - prev.row;

  let direction: Direction;
  if (dc === 1 && dr === 0) direction = 'RIGHT';
  else if (dc === -1 && dr === 0) direction = 'LEFT';
  else if (dc === 0 && dr === 1) direction = 'DOWN';
  else if (dc === 0 && dr === -1) direction = 'UP';
  else throw new Error(`Invalid final step in arrow ${id}`);

  const points = cells.map((c) => cellToPoint(c, gridSize));
  const segments: ArrowSegment[] = [];
  let segStart = points[0];
  let prevDirX = Math.sign(cells[1].col - cells[0].col);
  let prevDirY = Math.sign(cells[1].row - cells[0].row);

  for (let i = 2; i < cells.length; i++) {
    const curDirX = Math.sign(cells[i].col - cells[i - 1].col);
    const curDirY = Math.sign(cells[i].row - cells[i - 1].row);
    if (curDirX !== prevDirX || curDirY !== prevDirY) {
      segments.push({ start: segStart, end: points[i - 1] });
      segStart = points[i - 1];
      prevDirX = curDirX;
      prevDirY = curDirY;
    }
  }
  segments.push({ start: segStart, end: points[points.length - 1] });

  return {
    id,
    direction,
    segments,
    exitPoint: points[points.length - 1],
    pathWidth: computePathWidth(gridSize),
  };
}

function stepDir(dir: Direction): { dc: number; dr: number } {
  switch (dir) {
    case 'UP':
      return { dc: 0, dr: -1 };
    case 'DOWN':
      return { dc: 0, dr: 1 };
    case 'LEFT':
      return { dc: -1, dr: 0 };
    case 'RIGHT':
      return { dc: 1, dr: 0 };
  }
}

const ALL_DIRS: Direction[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];

function getRayCells(
  head: GridCell,
  dir: Direction,
  gridSize: number
): GridCell[] {
  const { dc, dr } = stepDir(dir);
  const ray: GridCell[] = [];
  let c = head.col + dc;
  let r = head.row + dr;
  while (c >= 0 && c < gridSize && r >= 0 && r < gridSize) {
    ray.push({ col: c, row: r });
    c += dc;
    r += dr;
  }
  return ray;
}

function keyOf(c: number, r: number): string {
  return `${c},${r}`;
}

/**
 * Level 1 & 2 stay gentle and clear; Levels 3..5 introduce turns and shaped chains.
 */
function buildIntroLevel(levelId: number): Level {
  const make = (
    gridSize: number,
    paths: GridCell[][],
    startingHints = 2
  ): Level => {
    const arrows = paths.map((cells, idx) =>
      buildArrowFromGridCells(idx + 1, cells, gridSize)
    );
    const base: Level = {
      id: levelId,
      difficulty: 'EASY',
      gridSize,
      arrows,
      startingLives: 3,
      startingHints,
      metrics: computeLevelMetrics(arrows, gridSize, 1, 1),
    };
    const solved = solveLevel(base);
    if (!solved.solvable || !validateSolutionSequence(base, solved.moveSequence)) {
      throw new Error(`Intro level ${levelId} failed solver validation`);
    }
    return { ...base, metrics: solved.metrics };
  };

  if (levelId === 1) {
    // Level 1: Super simple, clear 5x5 board — teaches tapping free arrows & 1 easy unlock
    return make(5, [
      [{ col: 1, row: 0 }, { col: 0, row: 0 }], // FREE LEFT
      [{ col: 3, row: 0 }, { col: 4, row: 0 }], // FREE RIGHT
      [{ col: 1, row: 2 }, { col: 2, row: 2 }, { col: 3, row: 2 }], // Blocked by #4
      [{ col: 4, row: 3 }, { col: 4, row: 2 }, { col: 4, row: 1 }], // FREE UP -> frees #3
      [{ col: 0, row: 2 }, { col: 0, row: 3 }, { col: 0, row: 4 }], // FREE DOWN
      [{ col: 2, row: 4 }, { col: 3, row: 4 }], // FREE RIGHT
    ]);
  }

  // Level 2: Clean 6x6 with simple 90-degree bent arrows & clear dependencies
  return make(6, [
    [{ col: 1, row: 1 }, { col: 1, row: 0 }, { col: 0, row: 0 }], // FREE LEFT
    [{ col: 2, row: 0 }, { col: 3, row: 0 }, { col: 4, row: 0 }], // Blocked by #3
    [{ col: 5, row: 2 }, { col: 5, row: 1 }, { col: 5, row: 0 }], // FREE UP -> frees #2
    [{ col: 0, row: 2 }, { col: 0, row: 3 }, { col: 1, row: 3 }], // Blocked by #5
    [{ col: 2, row: 2 }, { col: 2, row: 3 }, { col: 2, row: 4 }], // Blocked by #6
    [{ col: 1, row: 5 }, { col: 2, row: 5 }, { col: 3, row: 5 }], // Blocked by #7
    [{ col: 4, row: 5 }, { col: 5, row: 5 }], // FREE RIGHT -> frees #6 -> frees #5
    [{ col: 3, row: 2 }, { col: 3, row: 3 }, { col: 4, row: 3 }], // Blocked by #3 initially
  ]);
}

const LEVEL_PLAN: Omit<TierConfig, 'startingHints'>[] = [
  // Levels 3-5: Small recognizable shapes, easy winding turns
  { difficulty: 'EASY', shapeKey: 'diamond', gridSize: 8, minArrows: 8, minLen: 2, maxLen: 4, maxTurns: 2, minDepth: 3 },
  { difficulty: 'EASY', shapeKey: 'cross', gridSize: 9, minArrows: 11, minLen: 2, maxLen: 4, maxTurns: 2, minDepth: 4 },
  { difficulty: 'EASY', shapeKey: 'heart', gridSize: 10, minArrows: 15, minLen: 2, maxLen: 4, maxTurns: 3, minDepth: 4 },

  // Levels 6-15: Medium silhouettes, progressively denser
  { difficulty: 'EASY', shapeKey: 'hexagon', gridSize: 11, minArrows: 18, minLen: 2, maxLen: 4, maxTurns: 3, minDepth: 5 },
  { difficulty: 'EASY', shapeKey: 'crescent', gridSize: 13, minArrows: 20, minLen: 2, maxLen: 4, maxTurns: 3, minDepth: 5 },
  { difficulty: 'EASY', shapeKey: 'house', gridSize: 12, minArrows: 24, minLen: 2, maxLen: 5, maxTurns: 3, minDepth: 6 },
  { difficulty: 'EASY', shapeKey: 'circle', gridSize: 13, minArrows: 28, minLen: 2, maxLen: 5, maxTurns: 3, minDepth: 6 },
  { difficulty: 'EASY', shapeKey: 'star', gridSize: 15, minArrows: 28, minLen: 2, maxLen: 5, maxTurns: 3, minDepth: 6 },
  { difficulty: 'EASY', shapeKey: 'bell', gridSize: 14, minArrows: 32, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 6 },
  { difficulty: 'EASY', shapeKey: 'apple', gridSize: 14, minArrows: 36, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 7 },
  { difficulty: 'EASY', shapeKey: 'shield', gridSize: 15, minArrows: 40, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 7 },
  { difficulty: 'EASY', shapeKey: 'crown', gridSize: 16, minArrows: 42, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 7 },
  { difficulty: 'EASY', shapeKey: 'fish', gridSize: 16, minArrows: 44, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 7 },

  // Levels 16-30: Normal — Rich intricate silhouettes (50 to 95 arrows)
  { difficulty: 'NORMAL', shapeKey: 'tree', gridSize: 18, minArrows: 48, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 8 },
  { difficulty: 'NORMAL', shapeKey: 'ring', gridSize: 18, minArrows: 50, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 8 },
  { difficulty: 'NORMAL', shapeKey: 'mushroom', gridSize: 18, minArrows: 54, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 8 },
  { difficulty: 'NORMAL', shapeKey: 'rocket', gridSize: 19, minArrows: 56, minLen: 2, maxLen: 5, maxTurns: 4, minDepth: 8 },
  { difficulty: 'NORMAL', shapeKey: 'hourglass', gridSize: 19, minArrows: 60, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 9 },
  { difficulty: 'NORMAL', shapeKey: 'heart', gridSize: 19, minArrows: 64, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 9 },
  { difficulty: 'NORMAL', shapeKey: 'butterfly', gridSize: 21, minArrows: 68, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 9 },
  { difficulty: 'NORMAL', shapeKey: 'key', gridSize: 22, minArrows: 60, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 9 },
  { difficulty: 'NORMAL', shapeKey: 'anchor', gridSize: 22, minArrows: 64, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 9 },
  { difficulty: 'NORMAL', shapeKey: 'trophy', gridSize: 22, minArrows: 72, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 9 },
  { difficulty: 'NORMAL', shapeKey: 'owl', gridSize: 21, minArrows: 76, minLen: 2, maxLen: 5, maxTurns: 5, minDepth: 10 },
  { difficulty: 'NORMAL', shapeKey: 'star', gridSize: 23, minArrows: 80, minLen: 2, maxLen: 6, maxTurns: 5, minDepth: 10 },
  { difficulty: 'NORMAL', shapeKey: 'hexagon', gridSize: 22, minArrows: 86, minLen: 2, maxLen: 6, maxTurns: 5, minDepth: 10 },
  { difficulty: 'NORMAL', shapeKey: 'apple', gridSize: 22, minArrows: 90, minLen: 2, maxLen: 6, maxTurns: 5, minDepth: 10 },
  { difficulty: 'NORMAL', shapeKey: 'crown', gridSize: 24, minArrows: 92, minLen: 2, maxLen: 6, maxTurns: 5, minDepth: 10 },

  // Levels 31-47: Hard — High-density winding maze silhouettes (95 to 150 arrows)
  { difficulty: 'HARD', shapeKey: 'shield', gridSize: 23, minArrows: 96, minLen: 2, maxLen: 6, maxTurns: 5, minDepth: 11 },
  { difficulty: 'HARD', shapeKey: 'bell', gridSize: 24, minArrows: 98, minLen: 2, maxLen: 6, maxTurns: 5, minDepth: 11 },
  { difficulty: 'HARD', shapeKey: 'tree', gridSize: 25, minArrows: 102, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 11 },
  { difficulty: 'HARD', shapeKey: 'rocket', gridSize: 26, minArrows: 106, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 11 },
  { difficulty: 'HARD', shapeKey: 'mushroom', gridSize: 26, minArrows: 120, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 12 },
  { difficulty: 'HARD', shapeKey: 'butterfly', gridSize: 26, minArrows: 114, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 12 },
  { difficulty: 'HARD', shapeKey: 'house', gridSize: 25, minArrows: 118, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 12 },
  { difficulty: 'HARD', shapeKey: 'hourglass', gridSize: 26, minArrows: 120, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 12 },
  { difficulty: 'HARD', shapeKey: 'fish', gridSize: 26, minArrows: 122, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 12 },
  { difficulty: 'HARD', shapeKey: 'owl', gridSize: 26, minArrows: 126, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 12 },
  { difficulty: 'HARD', shapeKey: 'heart', gridSize: 26, minArrows: 130, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 13 },
  { difficulty: 'HARD', shapeKey: 'circle', gridSize: 26, minArrows: 134, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 13 },
  { difficulty: 'HARD', shapeKey: 'trophy', gridSize: 28, minArrows: 132, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 13 },
  { difficulty: 'HARD', shapeKey: 'anchor', gridSize: 28, minArrows: 130, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 13 },
  { difficulty: 'HARD', shapeKey: 'star', gridSize: 28, minArrows: 136, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 13 },
  { difficulty: 'HARD', shapeKey: 'apple', gridSize: 27, minArrows: 142, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 14 },
  { difficulty: 'HARD', shapeKey: 'hexagon', gridSize: 27, minArrows: 146, minLen: 2, maxLen: 6, maxTurns: 6, minDepth: 14 },

  // Levels 48-50: Expert — Grand ultra-dense 150–170+ arrow maze silhouettes
  { difficulty: 'EXPERT', shapeKey: 'owl', gridSize: 28, minArrows: 150, minLen: 2, maxLen: 6, maxTurns: 7, minDepth: 14 },
  { difficulty: 'EXPERT', shapeKey: 'heart', gridSize: 29, minArrows: 158, minLen: 2, maxLen: 6, maxTurns: 7, minDepth: 15 },
  { difficulty: 'EXPERT', shapeKey: 'mushroom', gridSize: 29, minArrows: 162, minLen: 2, maxLen: 6, maxTurns: 7, minDepth: 15 },
];

function getTierConfig(levelId: number): TierConfig {
  const idx = levelId - 3;
  const plan = LEVEL_PLAN[Math.max(0, Math.min(LEVEL_PLAN.length - 1, idx))];
  return {
    ...plan,
    startingHints: 2,
  };
}

/**
 * Generates a tightly-packed shaped arrow silhouette using reverse-unpeeling +
 * safe tail-extension gap filling, then independently verifies solvability.
 */
function attemptGenerateShapedLevel(
  levelId: number,
  config: TierConfig,
  seed: number
): Level | null {
  const rng = mulberry32(seed);
  const { gridSize, shapeKey } = config;
  const mask = getShapeMask(shapeKey, gridSize);

  const maskCells: GridCell[] = [];
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      if (mask[r][c]) {
        maskCells.push({ col: c, row: r });
      }
    }
  }

  const occupied = new Map<string, number>();
  const rayBlockCount = new Map<string, number>(); // "c,r" -> how many placed arrows' rays pass through here
  const placedPaths: {
    cells: GridCell[];
    dir: Direction;
    rayKeys: Set<string>;
  }[] = [];

  const center = (gridSize - 1) / 2;
  let consecutiveFailures = 0;
  const maxFailures = 30;

  while (consecutiveFailures < maxFailures) {
    const emptyCells = maskCells.filter(
      (cell) => !occupied.has(keyOf(cell.col, cell.row))
    );
    if (emptyCells.length < 2) break;

    const candidates: {
      head: GridCell;
      dir: Direction;
      ray: GridCell[];
      score: number;
    }[] = [];

    const sampleLimit = Math.min(emptyCells.length, 45);
    for (let s = 0; s < sampleLimit; s++) {
      const cell =
        emptyCells.length <= sampleLimit
          ? emptyCells[s]
          : emptyCells[Math.floor(rng() * emptyCells.length)];

      const cellKey = keyOf(cell.col, cell.row);
      const blocksExistingCount = rayBlockCount.get(cellKey) ?? 0;

      for (const dir of ALL_DIRS) {
        const ray = getRayCells(cell, dir, gridSize);
        let blockedByLater = false;
        for (const rc of ray) {
          if (occupied.has(keyOf(rc.col, rc.row))) {
            blockedByLater = true;
            break;
          }
        }
        if (blockedByLater) continue;

        const { dc, dr } = stepDir(dir);
        const prevCol = cell.col - dc;
        const prevRow = cell.row - dr;
        if (
          prevCol < 0 ||
          prevCol >= gridSize ||
          prevRow < 0 ||
          prevRow >= gridSize ||
          !mask[prevRow][prevCol] ||
          occupied.has(keyOf(prevCol, prevRow))
        ) {
          continue;
        }

        const distFromCenter =
          Math.abs(cell.col - center) + Math.abs(cell.row - center);
        const score =
          blocksExistingCount * 11 +
          (gridSize - distFromCenter) * 0.45 +
          rng() * 3.5;

        candidates.push({ head: cell, dir, ray, score });
      }
    }

    if (candidates.length === 0) {
      consecutiveFailures++;
      continue;
    }

    candidates.sort((a, b) => b.score - a.score);
    const chosen = candidates[Math.floor(rng() * Math.min(3, candidates.length))];

    const { dc, dr } = stepDir(chosen.dir);
    const rayKeySet = new Set(chosen.ray.map((c) => keyOf(c.col, c.row)));

    const prevCell: GridCell = {
      col: chosen.head.col - dc,
      row: chosen.head.row - dr,
    };
    const revCells: GridCell[] = [chosen.head, prevCell];
    const usedInSelf = new Set<string>([
      keyOf(chosen.head.col, chosen.head.row),
      keyOf(prevCell.col, prevCell.row),
    ]);

    const desiredLen =
      config.minLen + Math.floor(rng() * (config.maxLen - config.minLen + 1));
    let cur = prevCell;
    let curBackDir = { dc: -dc, dr: -dr };
    let turns = 0;

    while (revCells.length < desiredLen) {
      const stepOptions: {
        next: GridCell;
        d: { dc: number; dr: number };
        isTurn: boolean;
        weight: number;
      }[] = [];

      for (const dir of ALL_DIRS) {
        const d = stepDir(dir);
        const nc = cur.col + d.dc;
        const nr = cur.row + d.dr;
        if (nc < 0 || nc >= gridSize || nr < 0 || nr >= gridSize) continue;
        if (!mask[nr][nc]) continue;
        const nk = keyOf(nc, nr);
        if (occupied.has(nk) || usedInSelf.has(nk)) continue;
        if (rayKeySet.has(nk)) continue;

        const isTurn = d.dc !== curBackDir.dc || d.dr !== curBackDir.dr;
        if (isTurn && turns >= config.maxTurns) continue;

        let neighborOccupancy = 0;
        for (const ndir of ALL_DIRS) {
          const nd = stepDir(ndir);
          const ac = nc + nd.dc;
          const ar = nr + nd.dr;
          if (
            ac < 0 ||
            ac >= gridSize ||
            ar < 0 ||
            ar >= gridSize ||
            !mask[ar][ac] ||
            occupied.has(keyOf(ac, ar)) ||
            usedInSelf.has(keyOf(ac, ar))
          ) {
            neighborOccupancy++;
          }
        }

        const blocksExisting = rayBlockCount.get(nk) ?? 0;
        const weight =
          (isTurn ? 2.4 : 1.1) +
          neighborOccupancy * 1.4 +
          blocksExisting * 5 +
          rng() * 1.4;
        stepOptions.push({ next: { col: nc, row: nr }, d, isTurn, weight });
      }

      if (stepOptions.length === 0) break;
      stepOptions.sort((a, b) => b.weight - a.weight);
      const picked =
        stepOptions[Math.floor(rng() * Math.min(2, stepOptions.length))];
      revCells.push(picked.next);
      usedInSelf.add(keyOf(picked.next.col, picked.next.row));
      if (picked.isTurn) turns++;
      cur = picked.next;
      curBackDir = picked.d;
    }

    const forwardCells = revCells.reverse();
    const arrowIdx = placedPaths.length;
    for (const c of forwardCells) {
      occupied.set(keyOf(c.col, c.row), arrowIdx);
    }
    for (const rk of rayKeySet) {
      rayBlockCount.set(rk, (rayBlockCount.get(rk) ?? 0) + 1);
    }
    placedPaths.push({
      cells: forwardCells,
      dir: chosen.dir,
      rayKeys: rayKeySet,
    });
    consecutiveFailures = 0;
  }

  // Gap-Filling Pass 1: Place 2-cell arrows in remaining adjacent empty pairs with clear rays
  for (const cell of maskCells) {
    if (occupied.has(keyOf(cell.col, cell.row))) continue;
    for (const dir of ALL_DIRS) {
      const ray = getRayCells(cell, dir, gridSize);
      if (ray.some((rc) => occupied.has(keyOf(rc.col, rc.row)))) continue;
      const { dc, dr } = stepDir(dir);
      const pc = cell.col - dc;
      const pr = cell.row - dr;
      if (
        pc < 0 ||
        pc >= gridSize ||
        pr < 0 ||
        pr >= gridSize ||
        !mask[pr][pc] ||
        occupied.has(keyOf(pc, pr))
      ) {
        continue;
      }
      const arrowIdx = placedPaths.length;
      const cells = [{ col: pc, row: pr }, cell];
      occupied.set(keyOf(pc, pr), arrowIdx);
      occupied.set(keyOf(cell.col, cell.row), arrowIdx);
      const rayKeySet = new Set(ray.map((c) => keyOf(c.col, c.row)));
      placedPaths.push({ cells, dir, rayKeys: rayKeySet });
      break;
    }
  }

  // Gap-Filling Pass 2: Extend tails safely into leftover isolated cells inside silhouette
  let extended = true;
  let extPasses = 0;
  while (extended && extPasses < 4) {
    extended = false;
    extPasses++;
    for (let i = placedPaths.length - 1; i >= 0; i--) {
      const path = placedPaths[i];
      if (path.cells.length >= config.maxLen + 3) continue;
      const tail = path.cells[0];

      for (const dir of ALL_DIRS) {
        const d = stepDir(dir);
        const nc = tail.col + d.dc;
        const nr = tail.row + d.dr;
        if (nc < 0 || nc >= gridSize || nr < 0 || nr >= gridSize) continue;
        if (!mask[nr][nc]) continue;
        const nk = keyOf(nc, nr);
        if (occupied.has(nk) || path.rayKeys.has(nk)) continue;

        let blocksEarlierEscaper = false;
        for (let j = i + 1; j < placedPaths.length; j++) {
          if (placedPaths[j].rayKeys.has(nk)) {
            blocksEarlierEscaper = true;
            break;
          }
        }
        if (blocksEarlierEscaper) continue;

        path.cells.unshift({ col: nc, row: nr });
        occupied.set(nk, i);
        extended = true;
        break;
      }
    }
  }

  if (placedPaths.length < config.minArrows) {
    return null;
  }

  const ordered = [...placedPaths].sort((a, b) => {
    const aHead = a.cells[a.cells.length - 1];
    const bHead = b.cells[b.cells.length - 1];
    if (aHead.row !== bHead.row) return aHead.row - bHead.row;
    return aHead.col - bHead.col;
  });

  const arrows = ordered.map((p, idx) =>
    buildArrowFromGridCells(idx + 1, p.cells, gridSize)
  );

  const initialFree = arrows.filter((a) => isArrowFree(a, arrows)).length;
  if (initialFree === 0 || initialFree === arrows.length) {
    return null;
  }

  const candidateLevel: Level = {
    id: levelId,
    difficulty: config.difficulty,
    gridSize,
    arrows,
    startingLives: 3,
    startingHints: config.startingHints,
    metrics: computeLevelMetrics(arrows, gridSize, 1, 1),
  };

  const solved = solveLevel(candidateLevel);
  if (!solved.solvable) return null;
  if (solved.metrics.maxDependencyDepth < config.minDepth) return null;

  return {
    ...candidateLevel,
    metrics: solved.metrics,
  };
}

function countMaskCells(shapeKey: string, gridSize: number): number {
  const mask = getShapeMask(shapeKey, gridSize);
  let count = 0;
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      if (mask[r][c]) count++;
    }
  }
  return count;
}

export function generateLevel(levelId: number): Level {
  if (levelId === 1 || levelId === 2) {
    return buildIntroLevel(levelId);
  }

  const baseConfig = getTierConfig(levelId);
  let adaptiveGrid = baseConfig.gridSize;
  const requiredCells = Math.ceil(baseConfig.minArrows * 4.2);
  while (countMaskCells(baseConfig.shapeKey, adaptiveGrid) < requiredCells && adaptiveGrid < 38) {
    adaptiveGrid++;
  }
  const config: TierConfig = { ...baseConfig, gridSize: adaptiveGrid };

  let bestCandidate: Level | null = null;

  const maxAttempts = config.gridSize >= 22 ? 6 : 10;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const seed = levelId * 104729 + attempt * 7919 + 888888;
    const candidate = attemptGenerateShapedLevel(levelId, config, seed);
    if (!candidate) continue;

    if (
      !bestCandidate ||
      candidate.arrows.length * 1.5 + candidate.metrics.difficultyScore >
        bestCandidate.arrows.length * 1.5 + bestCandidate.metrics.difficultyScore
    ) {
      bestCandidate = candidate;
    }

    if (attempt >= 2 && bestCandidate && bestCandidate.arrows.length >= config.minArrows) {
      break;
    }
  }

  if (!bestCandidate) {
    const relaxed: TierConfig = {
      ...config,
      gridSize: Math.min(38, config.gridSize + 3),
      minArrows: Math.max(6, Math.floor(config.minArrows * 0.65)),
      minDepth: Math.max(2, config.minDepth - 4),
    };
    for (let attempt = 0; attempt < 12; attempt++) {
      const seed = levelId * 99991 + attempt * 3571 + 777;
      const candidate = attemptGenerateShapedLevel(levelId, relaxed, seed);
      if (candidate) {
        bestCandidate = candidate;
        break;
      }
    }
  }

  if (!bestCandidate) {
    throw new Error(`Failed to generate valid level ${levelId}`);
  }

  const check = solveLevel(bestCandidate);
  if (!check.solvable || !validateSolutionSequence(bestCandidate, check.moveSequence)) {
    throw new Error(`Level ${levelId} failed final simulation validation`);
  }

  return bestCandidate;
}

export function generateAll50Levels(): Level[] {
  const levels: Level[] = [];
  for (let id = 1; id <= 50; id++) {
    levels.push(generateLevel(id));
  }
  return levels;
}
