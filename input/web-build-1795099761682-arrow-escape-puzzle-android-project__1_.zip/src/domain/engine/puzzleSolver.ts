import { Arrow, Level, LevelMetrics, SolutionResult } from '../model/types';
import { doesArrowBlock, isArrowFree } from './collisionEngine';

/**
 * Counts 90-degree turns across an arrow's orthogonal segment list.
 */
export function countArrowTurns(arrow: Arrow): number {
  if (arrow.segments.length <= 1) return 0;
  let turns = 0;
  for (let i = 1; i < arrow.segments.length; i++) {
    const prev = arrow.segments[i - 1];
    const curr = arrow.segments[i];
    const prevHoriz = Math.abs(prev.end.y - prev.start.y) < Math.abs(prev.end.x - prev.start.x);
    const currHoriz = Math.abs(curr.end.y - curr.start.y) < Math.abs(curr.end.x - curr.start.x);
    if (prevHoriz !== currHoriz) {
      turns++;
    }
  }
  return turns;
}

/**
 * Computes structural dependency & complexity metrics for a level.
 */
export function computeLevelMetrics(
  arrows: readonly Arrow[],
  gridSize: number,
  avgAvailableMoves: number,
  maxDependencyDepth: number
): LevelMetrics {
  const arrowCount = arrows.length;
  const initiallyFreeCount = arrows.filter((a) => isArrowFree(a, arrows)).length;
  const misleadingBlockedCount = Math.max(0, arrowCount - initiallyFreeCount);

  let totalTurns = 0;
  let totalSegmentLength = 0;
  for (const a of arrows) {
    totalTurns += countArrowTurns(a);
    for (const s of a.segments) {
      totalSegmentLength += Math.hypot(s.end.x - s.start.x, s.end.y - s.start.y);
    }
  }

  // Board density estimated from total normalized path area relative to playable board area (0.88^2)
  const avgWidth =
    arrowCount > 0 ? arrows.reduce((sum, a) => sum + a.pathWidth, 0) / arrowCount : 0.02;
  const boardDensity = Math.min(
    1,
    Number(((totalSegmentLength * (avgWidth * 1.45)) / 0.7744).toFixed(3))
  );

  // Structural difficulty score (0..100) weighted by dependency depth, scarcity of initial moves, turns, and count
  const depthFactor = Math.min(35, maxDependencyDepth * 3.8);
  const countFactor = Math.min(30, arrowCount * 0.45);
  const turnFactor = Math.min(20, (totalTurns / Math.max(1, arrowCount)) * 11);
  const scarcityFactor = Math.min(
    15,
    (1 - initiallyFreeCount / Math.max(1, arrowCount)) * 15
  );
  const difficultyScore = Math.round(
    Math.min(100, depthFactor + countFactor + turnFactor + scarcityFactor)
  );

  // Unused parameter guard if gridSize is useful for future density normalization
  void gridSize;

  return {
    arrowCount,
    initiallyFreeCount,
    maxDependencyDepth,
    avgAvailableMoves: Number(avgAvailableMoves.toFixed(2)),
    misleadingBlockedCount,
    totalTurns,
    boardDensity,
    difficultyScore,
  };
}

/**
 * Solves a level by topological peeling / confluence over the geometric blocking graph
 * and computes exact dependency depth and solution move sequence.
 */
export function solveLevel(level: Level): SolutionResult {
  const arrows = level.arrows;
  const n = arrows.length;

  if (n === 0) {
    return {
      solvable: true,
      moveSequence: [],
      metrics: computeLevelMetrics(arrows, level.gridSize, 0, 0),
    };
  }

  // Build adjacency: blockersOf[targetIdx] = list of blocker indices; unlocks[blockerIdx] = list of target indices
  const blockersCount = new Int32Array(n);
  const unlocks: number[][] = Array.from({ length: n }, () => []);
  const depth = new Int32Array(n);

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i === j) continue;
      if (doesArrowBlock(arrows[i], arrows[j])) {
        // arrow[i] blocks arrow[j]
        blockersCount[j]++;
        unlocks[i].push(j);
      }
    }
  }

  const removed = new Uint8Array(n);
  const moveSequence: number[] = [];
  let totalAvailableAcrossSteps = 0;

  // Deterministic topological wave peeling:
  // Each wave picks the currently free arrow that unblocks the most downstream arrows (ties broken by id),
  // while computing exact DAG dependency depth (longest chain to clear).
  for (let step = 0; step < n; step++) {
    const freeIndices: number[] = [];
    for (let i = 0; i < n; i++) {
      if (!removed[i] && blockersCount[i] === 0) {
        freeIndices.push(i);
      }
    }

    if (freeIndices.length === 0) {
      // Deadlock cycle detected — level is unsolvable
      return {
        solvable: false,
        moveSequence: [],
        metrics: computeLevelMetrics(arrows, level.gridSize, 0, 0),
      };
    }

    totalAvailableAcrossSteps += freeIndices.length;

    // Prefer picking lower depth first for wave-accurate ordering, then highest unlock impact
    freeIndices.sort((a, b) => {
      if (depth[a] !== depth[b]) return depth[a] - depth[b];
      if (unlocks[b].length !== unlocks[a].length) return unlocks[b].length - unlocks[a].length;
      return arrows[a].id - arrows[b].id;
    });

    const chosen = freeIndices[0];
    removed[chosen] = 1;
    moveSequence.push(arrows[chosen].id);

    for (const targetIdx of unlocks[chosen]) {
      if (!removed[targetIdx]) {
        blockersCount[targetIdx]--;
        if (depth[chosen] + 1 > depth[targetIdx]) {
          depth[targetIdx] = depth[chosen] + 1;
        }
      }
    }
  }

  let maxDepth = 0;
  for (let i = 0; i < n; i++) {
    if (depth[i] + 1 > maxDepth) {
      maxDepth = depth[i] + 1;
    }
  }

  const avgAvailable = totalAvailableAcrossSteps / n;
  const metrics = computeLevelMetrics(arrows, level.gridSize, avgAvailable, maxDepth);

  return {
    solvable: true,
    moveSequence,
    metrics,
  };
}

/**
 * Independently simulates a move sequence against `isArrowFree` to confirm every step is legal
 * and leaves 0 remaining arrows.
 */
export function validateSolutionSequence(level: Level, moveSequence: readonly number[]): boolean {
  if (moveSequence.length !== level.arrows.length) return false;

  let active = [...level.arrows];
  for (const moveId of moveSequence) {
    const idx = active.findIndex((a) => a.id === moveId);
    if (idx === -1) return false;
    const arrow = active[idx];
    if (!isArrowFree(arrow, active)) return false;
    active = active.filter((a) => a.id !== moveId);
  }

  return active.length === 0;
}

/**
 * Intelligently chooses a currently free arrow for the Hint system.
 * Prioritizes free arrows that immediately unblock the highest number of blocked arrows
 * (or unlock the deepest dependency chain), never choosing arbitrarily when strategic moves exist.
 */
export function pickBestHintArrow(activeArrows: readonly Arrow[]): Arrow | null {
  const freeArrows = activeArrows.filter((a) => isArrowFree(a, activeArrows));
  if (freeArrows.length === 0) return null;
  if (freeArrows.length === 1) return freeArrows[0];

  let bestArrow = freeArrows[0];
  let bestScore = -1;

  for (const candidate of freeArrows) {
    const remainingWithoutCandidate = activeArrows.filter((a) => a.id !== candidate.id);
    // Count how many previously blocked arrows become free immediately after removing candidate
    let newlyFreed = 0;
    let directBlocks = 0;
    for (const other of remainingWithoutCandidate) {
      if (doesArrowBlock(candidate, other)) {
        directBlocks++;
        if (isArrowFree(other, remainingWithoutCandidate)) {
          newlyFreed++;
        }
      }
    }

    const score = newlyFreed * 10 + directBlocks * 2;
    if (score > bestScore) {
      bestScore = score;
      bestArrow = candidate;
    }
  }

  return bestArrow;
}
