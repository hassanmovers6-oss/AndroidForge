import { Arrow, ArrowSegment, Direction, Point } from '../model/types';

interface Rect {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

function rectsOverlap(a: Rect, b: Rect): boolean {
  return a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY;
}

function segmentBounds(seg: ArrowSegment, padding: number): Rect {
  return {
    minX: Math.min(seg.start.x, seg.end.x) - padding,
    minY: Math.min(seg.start.y, seg.end.y) - padding,
    maxX: Math.max(seg.start.x, seg.end.x) + padding,
    maxY: Math.max(seg.start.y, seg.end.y) + padding,
  };
}

function directionVector(dir: Direction): Point {
  switch (dir) {
    case 'UP':
      return { x: 0, y: -1 };
    case 'DOWN':
      return { x: 0, y: 1 };
    case 'LEFT':
      return { x: -1, y: 0 };
    case 'RIGHT':
      return { x: 1, y: 0 };
  }
}

/**
 * Builds the straight geometric escape corridor from an arrow's exit point
 * to beyond the normalized board boundary [0.0, 1.0].
 */
function buildEscapeCorridor(arrow: Arrow): Rect {
  const { x, y } = arrow.exitPoint;
  const startOffset = arrow.pathWidth * 0.35;
  const halfCorridor = arrow.pathWidth * 0.42;

  switch (arrow.direction) {
    case 'RIGHT':
      return {
        minX: x + startOffset,
        minY: y - halfCorridor,
        maxX: 1.25,
        maxY: y + halfCorridor,
      };
    case 'LEFT':
      return {
        minX: -0.25,
        minY: y - halfCorridor,
        maxX: x - startOffset,
        maxY: y + halfCorridor,
      };
    case 'DOWN':
      return {
        minX: x - halfCorridor,
        minY: y + startOffset,
        maxX: x + halfCorridor,
        maxY: 1.25,
      };
    case 'UP':
      return {
        minX: x - halfCorridor,
        minY: -0.25,
        maxX: x + halfCorridor,
        maxY: y - startOffset,
      };
  }
}

/**
 * Checks whether arrowA's escape corridor is intersected by arrowB's segments or arrowhead.
 */
export function doesArrowBlock(blocker: Arrow, target: Arrow): boolean {
  if (blocker.id === target.id) return false;

  const corridor = buildEscapeCorridor(target);
  const blockerRadius = blocker.pathWidth * 0.42;

  for (const seg of blocker.segments) {
    if (rectsOverlap(corridor, segmentBounds(seg, blockerRadius))) {
      return true;
    }
  }

  // Also check the protruding arrowhead tip geometry of the blocker arrow
  const dirVec = directionVector(blocker.direction);
  const tipCenter: Point = {
    x: blocker.exitPoint.x + dirVec.x * blocker.pathWidth * 0.3,
    y: blocker.exitPoint.y + dirVec.y * blocker.pathWidth * 0.3,
  };
  const headRadius = blocker.pathWidth * 0.55;
  const headRect: Rect = {
    minX: tipCenter.x - headRadius,
    minY: tipCenter.y - headRadius,
    maxX: tipCenter.x + headRadius,
    maxY: tipCenter.y + headRadius,
  };

  return rectsOverlap(corridor, headRect);
}

/**
 * Returns true if no other remaining active arrow blocks this arrow's straight escape corridor.
 */
export function isArrowFree(arrow: Arrow, activeArrows: readonly Arrow[]): boolean {
  for (const other of activeArrows) {
    if (other.id === arrow.id) continue;
    if (doesArrowBlock(other, arrow)) {
      return false;
    }
  }
  return true;
}

/**
 * Returns the IDs of all active arrows that currently block `arrow`.
 */
export function getBlockingArrowIds(arrow: Arrow, activeArrows: readonly Arrow[]): number[] {
  const blockers: number[] = [];
  for (const other of activeArrows) {
    if (other.id === arrow.id) continue;
    if (doesArrowBlock(other, arrow)) {
      blockers.push(other.id);
    }
  }
  return blockers;
}

function distanceToSegment(p: Point, a: Point, b: Point): number {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const lenSq = dx * dx + dy * dy;
  if (lenSq <= 1e-12) {
    return Math.hypot(p.x - a.x, p.y - a.y);
  }
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq));
  const projX = a.x + t * dx;
  const projY = a.y + t * dy;
  return Math.hypot(p.x - projX, p.y - projY);
}

/**
 * Computes minimum distance from a normalized tap point to an arrow's geometry
 * (all segments, corners, and arrowhead).
 */
export function distanceToArrow(tapPoint: Point, arrow: Arrow): number {
  let minDist = Infinity;

  for (const seg of arrow.segments) {
    const d = distanceToSegment(tapPoint, seg.start, seg.end);
    if (d < minDist) {
      minDist = d;
    }
  }

  // Include the arrowhead tip area
  const dirVec = directionVector(arrow.direction);
  const tipPoint: Point = {
    x: arrow.exitPoint.x + dirVec.x * arrow.pathWidth * 0.7,
    y: arrow.exitPoint.y + dirVec.y * arrow.pathWidth * 0.7,
  };
  const headDist = distanceToSegment(tapPoint, arrow.exitPoint, tipPoint);
  if (headDist < minDist) {
    minDist = headDist;
  }

  return minDist;
}

/**
 * Dedicated hit-test function returning the closest active arrow within touch tolerance,
 * or null if the tap missed all arrows.
 */
export function hitTestArrow(
  tapPoint: Point,
  activeArrows: readonly Arrow[],
  minTolerance = 0.024
): Arrow | null {
  if (
    !Number.isFinite(tapPoint.x) ||
    !Number.isFinite(tapPoint.y) ||
    activeArrows.length === 0
  ) {
    return null;
  }

  let bestArrow: Arrow | null = null;
  let bestScore = Infinity;

  for (const arrow of activeArrows) {
    const dist = distanceToArrow(tapPoint, arrow);
    const tolerance = Math.max(minTolerance, arrow.pathWidth * 2.1);
    if (dist <= tolerance && dist < bestScore) {
      bestScore = dist;
      bestArrow = arrow;
    }
  }

  return bestArrow;
}
