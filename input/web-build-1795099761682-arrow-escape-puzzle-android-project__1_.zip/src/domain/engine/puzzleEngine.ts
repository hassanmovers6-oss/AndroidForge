import { GameState, Level } from '../model/types';
import { isArrowFree } from './collisionEngine';
import { pickBestHintArrow } from './puzzleSolver';

export type TapOutcome = 'ESCAPED' | 'BLOCKED' | 'IGNORED';

export function createInitialGameState(level: Level): GameState {
  return {
    level,
    remainingArrows: [...level.arrows],
    lives: level.startingLives,
    hintsRemaining: level.startingHints,
    highlightedArrowId: null,
    isComplete: level.arrows.length === 0,
    isGameOver: false,
    movesTaken: 0,
  };
}

export function tapArrow(
  state: GameState,
  arrowId: number
): { nextState: GameState; outcome: TapOutcome } {
  if (state.isComplete || state.isGameOver) {
    return { nextState: state, outcome: 'IGNORED' };
  }

  const tappedArrow = state.remainingArrows.find((a) => a.id === arrowId);
  if (!tappedArrow) {
    return { nextState: state, outcome: 'IGNORED' };
  }

  if (isArrowFree(tappedArrow, state.remainingArrows)) {
    const nextRemaining = state.remainingArrows.filter((a) => a.id !== arrowId);
    const isComplete = nextRemaining.length === 0;
    return {
      outcome: 'ESCAPED',
      nextState: {
        ...state,
        remainingArrows: nextRemaining,
        highlightedArrowId:
          state.highlightedArrowId === arrowId ? null : state.highlightedArrowId,
        isComplete,
        movesTaken: state.movesTaken + 1,
      },
    };
  }

  const nextLives = Math.max(0, state.lives - 1);
  return {
    outcome: 'BLOCKED',
    nextState: {
      ...state,
      lives: nextLives,
      isGameOver: nextLives === 0,
    },
  };
}

export function useHint(state: GameState): {
  nextState: GameState;
  hintedArrowId: number | null;
} {
  if (state.isComplete || state.isGameOver || state.hintsRemaining <= 0) {
    return { nextState: state, hintedArrowId: null };
  }

  // If a valid arrow is already highlighted, don't waste an extra hint
  if (
    state.highlightedArrowId !== null &&
    state.remainingArrows.some((a) => a.id === state.highlightedArrowId)
  ) {
    return { nextState: state, hintedArrowId: state.highlightedArrowId };
  }

  const bestArrow = pickBestHintArrow(state.remainingArrows);
  if (!bestArrow) {
    return { nextState: state, hintedArrowId: null };
  }

  return {
    hintedArrowId: bestArrow.id,
    nextState: {
      ...state,
      hintsRemaining: state.hintsRemaining - 1,
      highlightedArrowId: bestArrow.id,
    },
  };
}

export function restartLevel(level: Level): GameState {
  return createInitialGameState(level);
}

export function grantBonusHints(state: GameState, amount = 2): GameState {
  if (state.isComplete || amount <= 0) return state;
  return {
    ...state,
    hintsRemaining: state.hintsRemaining + amount,
  };
}

export function reviveWithExtraLife(state: GameState): GameState {
  if (state.isComplete || !state.isGameOver) return state;
  return {
    ...state,
    lives: 1,
    isGameOver: false,
  };
}

