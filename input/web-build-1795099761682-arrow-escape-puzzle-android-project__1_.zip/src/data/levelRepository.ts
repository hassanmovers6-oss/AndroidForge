import levelsJson from './levelsData.json';
import { Level } from '../domain/model/types';

const ALL_LEVELS: Level[] = levelsJson as Level[];

export const TOTAL_LEVELS = ALL_LEVELS.length;

export function getAllLevels(): readonly Level[] {
  return ALL_LEVELS;
}

export function getLevelById(id: number): Level | undefined {
  return ALL_LEVELS.find((level) => level.id === id);
}

export function getSafeLevel(id: number): Level {
  return getLevelById(id) ?? ALL_LEVELS[0];
}
