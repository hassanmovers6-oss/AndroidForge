export interface PlayerProgress {
  highestUnlockedLevel: number;
  completedLevels: number[];
  currentLevelId: number;
  showGrid: boolean;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  tutorialShown: boolean;
  debugMode: boolean;
}

export const DEFAULT_PROGRESS: PlayerProgress = {
  highestUnlockedLevel: 1,
  completedLevels: [],
  currentLevelId: 1,
  showGrid: false,
  soundEnabled: true,
  hapticsEnabled: true,
  tutorialShown: false,
  debugMode: false,
};

const STORAGE_KEY = 'arrow_escape_puzzle_progress_v1';

export interface StorageBackend {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

function getDefaultStorage(): StorageBackend | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage;
    }
  } catch {
    return null;
  }
  return null;
}

export function loadProgress(
  storage: StorageBackend | null = getDefaultStorage()
): PlayerProgress {
  if (!storage) return { ...DEFAULT_PROGRESS };
  try {
    const raw = storage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_PROGRESS };
    const parsed = JSON.parse(raw) as Partial<PlayerProgress>;
    const completed = Array.isArray(parsed.completedLevels)
      ? Array.from(
          new Set(
            parsed.completedLevels.filter(
              (id): id is number => typeof id === 'number' && id >= 1 && id <= 50
            )
          )
        ).sort((a, b) => a - b)
      : [];
    const highest =
      typeof parsed.highestUnlockedLevel === 'number'
        ? Math.max(1, Math.min(50, Math.floor(parsed.highestUnlockedLevel)))
        : 1;
    const current =
      typeof parsed.currentLevelId === 'number'
        ? Math.max(1, Math.min(highest, Math.floor(parsed.currentLevelId)))
        : highest;

    return {
      highestUnlockedLevel: highest,
      completedLevels: completed,
      currentLevelId: current,
      showGrid: typeof parsed.showGrid === 'boolean' ? parsed.showGrid : false,
      soundEnabled: typeof parsed.soundEnabled === 'boolean' ? parsed.soundEnabled : true,
      hapticsEnabled:
        typeof parsed.hapticsEnabled === 'boolean' ? parsed.hapticsEnabled : true,
      tutorialShown:
        typeof parsed.tutorialShown === 'boolean' ? parsed.tutorialShown : false,
      debugMode: typeof parsed.debugMode === 'boolean' ? parsed.debugMode : false,
    };
  } catch {
    return { ...DEFAULT_PROGRESS };
  }
}

export function saveProgress(
  progress: PlayerProgress,
  storage: StorageBackend | null = getDefaultStorage()
): void {
  if (!storage) return;
  try {
    storage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Ignore storage quota errors gracefully
  }
}

export function markLevelCompleted(
  progress: PlayerProgress,
  levelId: number,
  totalLevels = 50,
  storage: StorageBackend | null = getDefaultStorage()
): PlayerProgress {
  const completedSet = new Set(progress.completedLevels);
  completedSet.add(levelId);
  const completedLevels = Array.from(completedSet).sort((a, b) => a - b);
  const nextUnlock = Math.min(totalLevels, Math.max(progress.highestUnlockedLevel, levelId + 1));
  const nextCurrent = Math.min(totalLevels, levelId + 1);

  const updated: PlayerProgress = {
    ...progress,
    completedLevels,
    highestUnlockedLevel: nextUnlock,
    currentLevelId: nextCurrent,
  };
  saveProgress(updated, storage);
  return updated;
}

export function resetAllProgress(
  preservePreferences = true,
  progress?: PlayerProgress,
  storage: StorageBackend | null = getDefaultStorage()
): PlayerProgress {
  const next: PlayerProgress = preservePreferences && progress
    ? {
        ...DEFAULT_PROGRESS,
        showGrid: progress.showGrid,
        soundEnabled: progress.soundEnabled,
        hapticsEnabled: progress.hapticsEnabled,
        tutorialShown: true,
        debugMode: progress.debugMode,
      }
    : { ...DEFAULT_PROGRESS };
  saveProgress(next, storage);
  return next;
}
