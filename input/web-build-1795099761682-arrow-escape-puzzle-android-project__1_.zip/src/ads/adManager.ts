export interface AndroidAdsBridge {
  setBannerVisible(visible: boolean): void;
  showInterstitial(placement: string): void;
  showRewarded(placement: string): void;
  showRewardedInterstitial(placement: string): void;
  showNativeAd(): void;
  hideNativeAd(): void;
  isRewardedReady(): boolean;
  isInterstitialReady(): boolean;
}

export interface AndroidAdEventPayload {
  type:
    | 'interstitial_closed'
    | 'rewarded_earned'
    | 'rewarded_closed'
    | 'rewarded_failed'
    | 'rewarded_unavailable'
    | 'rewarded_interstitial_earned'
    | 'rewarded_interstitial_closed'
    | 'rewarded_interstitial_failed'
    | 'rewarded_interstitial_unavailable';
  placement: string;
  granted: boolean;
}

declare global {
  interface Window {
    AndroidAds?: AndroidAdsBridge;
    __onAndroidAdEvent?: (payload: AndroidAdEventPayload) => void;
    __handleAndroidBack?: () => boolean;
  }
}

type AdCallback = (granted: boolean) => void;

const pendingCallbacks = new Map<string, AdCallback>();

function ensureListenerRegistered(): void {
  if (typeof window === 'undefined') return;
  if (!window.__onAndroidAdEvent) {
    window.__onAndroidAdEvent = (payload: AndroidAdEventPayload) => {
      const key = payload.placement;
      if (
        payload.type === 'rewarded_earned' ||
        payload.type === 'rewarded_interstitial_earned'
      ) {
        const cb = pendingCallbacks.get(key);
        if (cb) {
          pendingCallbacks.delete(key);
          cb(true);
        }
        return;
      }

      if (
        payload.type === 'rewarded_closed' ||
        payload.type === 'rewarded_failed' ||
        payload.type === 'rewarded_unavailable' ||
        payload.type === 'rewarded_interstitial_closed' ||
        payload.type === 'rewarded_interstitial_failed' ||
        payload.type === 'rewarded_interstitial_unavailable' ||
        payload.type === 'interstitial_closed'
      ) {
        const cb = pendingCallbacks.get(key);
        if (cb) {
          pendingCallbacks.delete(key);
          cb(Boolean(payload.granted));
        }
      }
    };
  }
}

export function isAndroidNativeApp(): boolean {
  return typeof window !== 'undefined' && Boolean(window.AndroidAds);
}

export const adManager = {
  setBannerVisible(visible: boolean): void {
    if (typeof window === 'undefined') return;
    window.AndroidAds?.setBannerVisible(visible);
  },

  showNativeAd(): void {
    if (typeof window === 'undefined') return;
    window.AndroidAds?.showNativeAd();
  },

  hideNativeAd(): void {
    if (typeof window === 'undefined') return;
    window.AndroidAds?.hideNativeAd();
  },

  showInterstitial(placement: string, onDone?: () => void): void {
    ensureListenerRegistered();
    if (typeof window !== 'undefined' && window.AndroidAds) {
      if (onDone) {
        pendingCallbacks.set(placement, () => onDone());
      }
      window.AndroidAds.showInterstitial(placement);
    } else {
      onDone?.();
    }
  },

  showRewarded(placement: string, onResult: (granted: boolean) => void): void {
    ensureListenerRegistered();
    if (typeof window !== 'undefined' && window.AndroidAds) {
      pendingCallbacks.set(placement, onResult);
      window.AndroidAds.showRewarded(placement);
    } else {
      // In web preview without Android AdMob SDK, simulate reward completion smoothly
      onResult(true);
    }
  },

  showRewardedInterstitial(
    placement: string,
    onResult: (granted: boolean) => void
  ): void {
    ensureListenerRegistered();
    if (typeof window !== 'undefined' && window.AndroidAds) {
      pendingCallbacks.set(placement, onResult);
      window.AndroidAds.showRewardedInterstitial(placement);
    } else {
      onResult(true);
    }
  },
};
