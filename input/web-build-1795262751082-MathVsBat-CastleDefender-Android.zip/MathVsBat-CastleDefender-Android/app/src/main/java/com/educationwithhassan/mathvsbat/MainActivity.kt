package com.educationwithhassan.mathvsbat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ProcessLifecycleOwner
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.educationwithhassan.mathvsbat.model.ScreenRoute
import com.educationwithhassan.mathvsbat.ui.screens.DailyChallengeScreen
import com.educationwithhassan.mathvsbat.ui.screens.GameplayScreen
import com.educationwithhassan.mathvsbat.ui.screens.HowToPlayScreen
import com.educationwithhassan.mathvsbat.ui.screens.LevelsScreen
import com.educationwithhassan.mathvsbat.ui.screens.MainMenuScreen
import com.educationwithhassan.mathvsbat.ui.screens.MathModesScreen
import com.educationwithhassan.mathvsbat.ui.screens.ProfileStatsScreen
import com.educationwithhassan.mathvsbat.ui.screens.SettingsScreen
import com.educationwithhassan.mathvsbat.ui.theme.CastleDarkBg
import com.educationwithhassan.mathvsbat.ui.theme.MathVsBatTheme
import com.educationwithhassan.mathvsbat.ui.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProcessLifecycleOwner.get().lifecycle.addObserver(AdMobManager)
        AdMobManager.initialize(this)

        setContent {
            MathVsBatTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = CastleDarkBg) {
                    val route by viewModel.route.collectAsState()
                    val saveData by viewModel.saveData.collectAsState()

                    AdMobManager.setGameplayActive(route == ScreenRoute.GAMEPLAY)

                    when (route) {
                        ScreenRoute.MENU -> MainMenuScreen(viewModel, saveData)
                        ScreenRoute.GAMEPLAY -> GameplayScreen(viewModel, saveData, this@MainActivity)
                        ScreenRoute.LEVELS -> LevelsScreen(viewModel, saveData)
                        ScreenRoute.MODES -> MathModesScreen(viewModel, saveData)
                        ScreenRoute.DAILY -> DailyChallengeScreen(viewModel, saveData)
                        ScreenRoute.PROFILE -> ProfileStatsScreen(viewModel, saveData, this@MainActivity)
                        ScreenRoute.HOW_TO_PLAY -> HowToPlayScreen(viewModel)
                        ScreenRoute.SETTINGS -> SettingsScreen(viewModel, saveData, this@MainActivity)
                    }
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.onAppPause()
    }

    override fun onResume() {
        super.onResume()
        AdMobManager.setCurrentActivity(this)
        viewModel.onAppResume()
    }
}
