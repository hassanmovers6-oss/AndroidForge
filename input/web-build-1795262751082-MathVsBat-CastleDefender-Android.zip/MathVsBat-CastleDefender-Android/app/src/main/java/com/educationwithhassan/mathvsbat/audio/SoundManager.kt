package com.educationwithhassan.mathvsbat.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.educationwithhassan.mathvsbat.model.GameSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class SoundManager(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var musicJob: Job? = null
    private var settings = GameSettings()

    fun updateSettings(newSettings: GameSettings) {
        val wasMusic = settings.musicEnabled
        settings = newSettings
        if (!settings.musicEnabled) {
            stopMusic()
        } else if (!wasMusic) {
            startMusic()
        }
    }

    fun startMusic() {
        if (!settings.musicEnabled || musicJob?.isActive == true) return
        val melody = doubleArrayOf(293.66, 349.23, 440.0, 523.25, 440.0, 349.23, 329.63, 392.0)
        musicJob = scope.launch {
            var idx = 0
            while (isActive && settings.musicEnabled) {
                playSineTone(melody[idx % melody.size], 220, 0.08f)
                idx++
                delay(420L)
            }
        }
    }

    fun stopMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    fun playClick() = playSfx(540.0, 45, 0.14f)
    fun playPowerUp() = playSfx(880.0, 140, 0.22f)
    fun playCorrect() {
        if (!settings.soundEnabled) return
        scope.launch {
            playSineTone(523.25, 90, 0.22f)
            playSineTone(659.25, 90, 0.22f)
            playSineTone(783.99, 130, 0.24f)
        }
    }

    fun playIncorrect() {
        playSfx(190.0, 140, 0.20f)
        vibrate(60L)
    }

    fun playDamage() {
        playSfx(135.0, 210, 0.28f)
        vibrate(100L)
    }

    fun playLevelComplete() {
        if (!settings.soundEnabled) return
        scope.launch {
            listOf(523.25, 659.25, 783.99, 1046.5).forEach { freq ->
                playSineTone(freq, 130, 0.24f)
                delay(75L)
            }
        }
    }

    fun playGameOver() {
        if (!settings.soundEnabled) return
        scope.launch {
            listOf(392.0, 349.23, 311.13, 261.63).forEach { freq ->
                playSineTone(freq, 150, 0.22f)
                delay(90L)
            }
        }
    }

    private fun playSfx(freq: Double, durationMs: Int, gain: Float) {
        if (!settings.soundEnabled) return
        scope.launch { playSineTone(freq, durationMs, gain) }
    }

    private fun playSineTone(freq: Double, durationMs: Int, gain: Float) {
        val sampleRate = 22050
        val numSamples = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val env = 1.0 - (i.toDouble() / numSamples)
            val sample = sin(2.0 * PI * i * freq / sampleRate) * gain * env
            buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioFormat.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(buffer, 0, buffer.size)
        track.play()
        Thread.sleep(durationMs.toLong() + 15L)
        track.release()
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        if (!settings.vibrationEnabled) return
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(ms)
        }
    }
}
