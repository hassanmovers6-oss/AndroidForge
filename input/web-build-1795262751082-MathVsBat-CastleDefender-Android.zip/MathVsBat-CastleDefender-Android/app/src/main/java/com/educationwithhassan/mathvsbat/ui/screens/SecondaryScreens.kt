package com.educationwithhassan.mathvsbat.ui.screens

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.educationwithhassan.mathvsbat.engine.LevelRepository
import com.educationwithhassan.mathvsbat.model.MathMode
import com.educationwithhassan.mathvsbat.model.PowerUpType
import com.educationwithhassan.mathvsbat.model.SaveData
import com.educationwithhassan.mathvsbat.model.ScreenRoute
import com.educationwithhassan.mathvsbat.ui.components.AdaptiveBannerAd
import com.educationwithhassan.mathvsbat.ui.components.NativeAdBanner
import com.educationwithhassan.mathvsbat.ui.components.RewardedPowerUpDialog
import com.educationwithhassan.mathvsbat.ui.theme.AmberGold
import com.educationwithhassan.mathvsbat.ui.theme.ArcaneCyan
import com.educationwithhassan.mathvsbat.ui.theme.EmeraldAction
import com.educationwithhassan.mathvsbat.ui.viewmodel.GameViewModel

@Composable
fun LevelsScreen(viewModel: GameViewModel, saveData: SaveData) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.weight(1f).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }) { Text("Back") }
                Text("Levels (1–100)", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.width(48.dp))
            }
            NativeAdBanner(modifier = Modifier.padding(vertical = 8.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(LevelRepository.allLevels) { lvl ->
                    val unlocked = lvl.levelNumber <= saveData.unlockedLevel
                    Button(
                        onClick = { viewModel.startLevel(lvl.levelNumber) },
                        enabled = unlocked
                    ) {
                        Text("${lvl.levelNumber}")
                    }
                }
            }
        }
        AdaptiveBannerAd()
    }
}

@Composable
fun MathModesScreen(viewModel: GameViewModel, saveData: SaveData) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.weight(1f).padding(16.dp)) {
            TextButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }) { Text("Back") }
            Text("Math Modes", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(MathMode.entries) { mode ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("${mode.symbol} ${mode.displayName}", fontWeight = FontWeight.Bold)
                                if (saveData.selectedMode == mode) Text("Selected", color = ArcaneCyan, fontSize = 12.sp)
                            }
                            Button(onClick = {
                                viewModel.selectMode(mode)
                                viewModel.startLevel(saveData.unlockedLevel, mode)
                            }) { Text("Play") }
                        }
                    }
                }
                item { NativeAdBanner(modifier = Modifier.padding(top = 6.dp)) }
            }
        }
        AdaptiveBannerAd()
    }
}

@Composable
fun DailyChallengeScreen(viewModel: GameViewModel, saveData: SaveData) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.weight(1f).padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }) { Text("Back") }
                Text("Daily Challenge", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Works 100% offline with a date-seeded 15-bat defense wave.", color = Color.LightGray)
                Text("Daily Best: ${saveData.dailyBestScore} · Streak: ${saveData.dailyStreak}", color = ArcaneCyan, fontWeight = FontWeight.Bold)
                NativeAdBanner()
            }
            Button(
                onClick = { viewModel.startLevel(15, MathMode.MIXED, isDaily = true) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldAction, contentColor = Color.Black)
            ) { Text("Start Daily Challenge", fontWeight = FontWeight.Bold) }
        }
        AdaptiveBannerAd()
    }
}

@Composable
fun ProfileStatsScreen(viewModel: GameViewModel, saveData: SaveData, activity: Activity) {
    var rewardedTarget by remember { mutableStateOf<PowerUpType?>(null) }
    val totalAnswered = saveData.totalCorrect + saveData.totalIncorrect
    val accuracy = if (totalAnswered > 0) (saveData.totalCorrect * 100) / totalAnswered else 100

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                TextButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }) { Text("Back") }
                Text(saveData.playerName, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Best: ${saveData.highestScore} · Total: ${saveData.totalScore}", color = AmberGold, fontWeight = FontWeight.Bold)
                Text("Accuracy: $accuracy% · Bats Banished: ${saveData.totalBatsBanished}", color = ArcaneCyan, fontSize = 13.sp)
            }
            items(PowerUpType.entries) { powerUp ->
                val count = saveData.powerUps[powerUp] ?: 0
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${powerUp.fullName} (×$count)", fontWeight = FontWeight.Bold)
                        }
                        Button(onClick = { rewardedTarget = powerUp }) {
                            Text("Watch Ad +1")
                        }
                    }
                }
            }
            item { NativeAdBanner() }
        }
        AdaptiveBannerAd()
    }

    rewardedTarget?.let { target ->
        RewardedPowerUpDialog(
            powerUp = target,
            activity = activity,
            onRewardGranted = { granted ->
                viewModel.grantRewardedPowerUp(granted)
                rewardedTarget = null
            },
            onDismiss = { rewardedTarget = null }
        )
    }
}

@Composable
fun HowToPlayScreen(viewModel: GameViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.weight(1f).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TextButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }) { Text("Back") }
            Text("How To Play", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("1. Read the math equation floating above each bat.")
            Text("2. Enter the answer using the 0–9 keypad.")
            Text("3. Press ATTACK to send a magical pulse.")
            Text("4. Protect the castle from Armored, Swift, Tricky, and Bonus bats.")
            Text("5. Use power-ups or unlock extra charges via optional Rewarded Ads!")
            Button(onClick = { viewModel.startLevel(1) }, modifier = Modifier.fillMaxWidth()) {
                Text("Replay Level 1 Tutorial")
            }
        }
        AdaptiveBannerAd()
    }
}

@Composable
fun SettingsScreen(viewModel: GameViewModel, saveData: SaveData, activity: Activity) {
    var confirmReset by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.weight(1f).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }) { Text("Back") }
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Music")
                Switch(checked = saveData.settings.musicEnabled, onCheckedChange = {
                    viewModel.updateSettings(saveData.settings.copy(musicEnabled = it))
                })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Sound Effects")
                Switch(checked = saveData.settings.soundEnabled, onCheckedChange = {
                    viewModel.updateSettings(saveData.settings.copy(soundEnabled = it))
                })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Vibration")
                Switch(checked = saveData.settings.vibrationEnabled, onCheckedChange = {
                    viewModel.updateSettings(saveData.settings.copy(vibrationEnabled = it))
                })
            }
            OutlinedButton(
                onClick = { AdMobManager.showPrivacyOptionsForm(activity) {} },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ad Privacy & Consent Options (UMP)")
            }
            Text("Developer: Rana Hassan · com.educationwithhassan.mathvsbat", fontSize = 12.sp, color = Color.Gray)
            if (!confirmReset) {
                OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Reset Game Progress")
                }
            } else {
                Button(
                    onClick = {
                        viewModel.resetProgress()
                        confirmReset = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Confirm Reset All Progress") }
            }
        }
        AdaptiveBannerAd()
    }
}
