package com.educationwithhassan.mathvsbat.ui.screens

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.educationwithhassan.mathvsbat.model.BatType
import com.educationwithhassan.mathvsbat.model.MathMode
import com.educationwithhassan.mathvsbat.model.PowerUpType
import com.educationwithhassan.mathvsbat.model.SaveData
import com.educationwithhassan.mathvsbat.model.ScreenRoute
import com.educationwithhassan.mathvsbat.ui.components.AdaptiveBannerAd
import com.educationwithhassan.mathvsbat.ui.components.RewardedContinueDialog
import com.educationwithhassan.mathvsbat.ui.components.RewardedPowerUpDialog
import com.educationwithhassan.mathvsbat.ui.theme.*
import com.educationwithhassan.mathvsbat.ui.viewmodel.GameViewModel
import com.educationwithhassan.mathvsbat.ui.viewmodel.PlayPhase

@Composable
fun GameplayScreen(viewModel: GameViewModel, saveData: SaveData, activity: Activity) {
    val state by viewModel.game.collectAsState()
    var rewardedTarget by remember { mutableStateOf<PowerUpType?>(null) }
    var showContinueRewarded by remember { mutableStateOf(false) }
    var continueNotice by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(CastleDarkBg)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top HUD
            Row(
                modifier = Modifier.fillMaxWidth().background(CastlePanel).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        if (state.isDaily) "Daily Challenge (${state.timedSecondsLeft}s)"
                        else if (state.timedSecondsLeft > 0) "Timed Lv ${state.levelNumber} (${state.timedSecondsLeft}s)"
                        else "Level ${state.levelNumber}",
                        fontWeight = FontWeight.Bold, color = Color.White
                    )
                    Text("Score: ${state.score} · Bats ${state.defeated}/${state.targetBats}", fontSize = 12.sp, color = AmberGold)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("❤ ${state.lives}", color = CoralError, fontWeight = FontWeight.Bold)
                    Button(onClick = { viewModel.togglePause() }, contentPadding = PaddingValues(horizontal = 10.dp)) {
                        Text("Pause", fontSize = 12.sp)
                    }
                }
            }

            // 2D Cartoon Castle + Bats Canvas
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val baseY = h * 0.85f

                    drawRect(Color(0xFF1E4638), Offset(0f, baseY), Size(w, h - baseY))
                    drawRect(Color(0xFF94A3B8), Offset(w / 2f - 85f, baseY - 50f), Size(170f, 70f))
                    drawRect(Color(0xFF64748B), Offset(w / 2f - 36f, baseY - 105f), Size(72f, 55f))
                    drawCircle(ArcaneCyan, radius = 11f, center = Offset(w / 2f, baseY - 118f))

                    if (state.shieldRemainingSec > 0) {
                        drawCircle(
                            color = ArcaneCyan.copy(alpha = 0.28f),
                            radius = w * 0.36f,
                            center = Offset(w / 2f, baseY),
                            style = Stroke(width = 6f)
                        )
                    }

                    state.pulses.forEach { pulse ->
                        drawLine(
                            color = if (pulse.isBonus) AmberGold else ArcaneCyan,
                            start = Offset(pulse.fromX * w, pulse.fromY * h),
                            end = Offset(pulse.toX * w, pulse.toY * h),
                            strokeWidth = 10f * (1f - pulse.progress)
                        )
                    }

                    state.bats.forEach { bat ->
                        val bx = bat.xRatio * w
                        val by = bat.yRatio * h
                        val color = when (bat.type) {
                            BatType.SMALL -> Color(0xFF7C3AED)
                            BatType.SWIFT -> Color(0xFF0EA5E9)
                            BatType.ARMORED -> Color(0xFF64748B)
                            BatType.TRICKY -> Color(0xFFDB2777)
                            BatType.BONUS -> Color(0xFFF59E0B)
                        }
                        drawCircle(color, radius = 22f, center = Offset(bx, by))
                    }
                }

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    state.bats.forEach { bat ->
                        val xDp = maxWidth * bat.xRatio - 46.dp
                        val yDp = maxHeight * bat.yRatio - 44.dp
                        Surface(
                            modifier = Modifier.offset(x = xDp.coerceIn(8.dp, maxWidth - 104.dp), y = yDp.coerceAtLeast(6.dp)),
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White
                        ) {
                            Text(
                                text = bat.question.expression,
                                color = Color.Black,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                state.feedbackText?.let { msg ->
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp),
                        color = CastlePanel.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(msg, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                    }
                }
            }

            // Power-Ups Strip (Locked power-ups open optional Rewarded Ad unlock)
            Row(
                modifier = Modifier.fillMaxWidth().background(CastlePanel).padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PowerUpType.entries.forEach { p ->
                    val count = saveData.powerUps[p] ?: 0
                    OutlinedButton(
                        onClick = {
                            if (count > 0) {
                                viewModel.usePowerUp(p)
                            } else {
                                viewModel.setPaused(true)
                                rewardedTarget = p
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(2.dp)
                    ) {
                        Text(if (count > 0) "${p.label} ($count)" else "${p.label} 🔒Ad", fontSize = 9.sp)
                    }
                }
            }

            // Answer Bar + 0-9 Keypad
            Column(modifier = Modifier.fillMaxWidth().background(CastleDarkBg).padding(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = state.answerInput.ifEmpty { "?" },
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                    Button(
                        onClick = { viewModel.submitAnswer() },
                        enabled = state.answerInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAction, contentColor = Color.Black)
                    ) {
                        Text("ATTACK", fontWeight = FontWeight.ExtraBold)
                    }
                }

                val rows = listOf(listOf("1", "2", "3", "4", "5", "6"), listOf("7", "8", "9", "0", "DEL", "CLR"))
                rows.forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { key ->
                            Button(
                                onClick = {
                                    when (key) {
                                        "DEL" -> viewModel.backspace()
                                        "CLR" -> viewModel.clearInput()
                                        else -> viewModel.appendDigit(key)
                                    }
                                },
                                modifier = Modifier.weight(1f).padding(vertical = 2.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(key, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Dedicated Bottom Adaptive Banner Area cleanly separated below keypad
            AdaptiveBannerAd()
        }

        if (state.phase != PlayPhase.PLAYING && rewardedTarget == null && !showContinueRewarded) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.82f)),
                contentAlignment = Alignment.Center
            ) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Card(modifier = Modifier.padding(24.dp), colors = CardDefaults.cardColors(containerColor = CastlePanel)) {
                            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    when (state.phase) {
                                        PlayPhase.PAUSED -> "Game Paused"
                                        PlayPhase.WON -> "Castle Defended!"
                                        PlayPhase.LOST -> "Castle Breached"
                                        else -> ""
                                    },
                                    fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White
                                )
                                Text("Score: ${state.score} · Correct: ${state.correctCount} · Wrong: ${state.incorrectCount}", color = AmberGold, fontSize = 13.sp)
                                if (state.phase == PlayPhase.PAUSED) {
                                    Button(onClick = { viewModel.togglePause() }, modifier = Modifier.fillMaxWidth()) { Text("Resume") }
                                }
                                if (state.phase == PlayPhase.LOST && state.revivesUsed == 0) {
                                    Button(
                                        onClick = {
                                            continueNotice = null
                                            showContinueRewarded = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAction, contentColor = Color.Black),
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Watch Ad · Continue (+1 Life)", fontWeight = FontWeight.ExtraBold) }
                                }
                                if (state.phase == PlayPhase.WON && !state.isDaily && state.levelNumber < 100) {
                                    Button(
                                        onClick = {
                                            AdMobManager.maybeShowInterstitialAfterLevelWin(activity) {
                                                viewModel.startLevel(state.levelNumber + 1)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Next Level") }
                                }
                                Button(onClick = {
                                    continueNotice = null
                                    viewModel.startLevel(state.levelNumber, state.mode, state.isDaily)
                                }, modifier = Modifier.fillMaxWidth()) { Text("Retry") }
                                OutlinedButton(onClick = { viewModel.navigate(ScreenRoute.MENU) }, modifier = Modifier.fillMaxWidth()) { Text("Main Menu") }
                                continueNotice?.let { notice ->
                                    Text(notice, color = AmberGold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    AdaptiveBannerAd()
                }
            }
        }

        rewardedTarget?.let { targetPowerUp ->
            RewardedPowerUpDialog(
                powerUp = targetPowerUp,
                activity = activity,
                onRewardGranted = { granted ->
                    viewModel.grantRewardedPowerUp(granted)
                    rewardedTarget = null
                    viewModel.setPaused(false)
                },
                onDismiss = { msg ->
                    msg?.let { viewModel.showFeedbackMessage(it) }
                    rewardedTarget = null
                    viewModel.setPaused(false)
                }
            )
        }

        if (showContinueRewarded) {
            RewardedContinueDialog(
                activity = activity,
                isTimedMode = state.isDaily || state.mode == MathMode.CHALLENGE,
                onRewardGranted = {
                    showContinueRewarded = false
                    continueNotice = null
                    viewModel.continueAfterRewardedAd()
                },
                onDismiss = { msg ->
                    continueNotice = msg
                    showContinueRewarded = false
                }
            )
        }
    }
}
