# Keep Math vs Bat data models & AdMob callbacks
-keep class com.educationwithhassan.mathvsbat.model.** { *; }
-keep class com.educationwithhassan.mathvsbat.ads.** { *; }
