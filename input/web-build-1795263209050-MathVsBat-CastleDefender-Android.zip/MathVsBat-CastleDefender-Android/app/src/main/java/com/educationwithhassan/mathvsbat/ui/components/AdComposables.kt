package com.educationwithhassan.mathvsbat.ui.components

import android.app.Activity
import android.view.LayoutInflater
import android.widget.Button as AndroidNativeButton
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.mathvsbat.R
import com.educationwithhassan.mathvsbat.ads.AdMobManager
import com.educationwithhassan.mathvsbat.model.PowerUpType
import com.educationwithhassan.mathvsbat.ui.theme.AmberGold
import com.educationwithhassan.mathvsbat.ui.theme.CastlePanel
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

@Composable
fun AdaptiveBannerAd(modifier: Modifier = Modifier) {
    if (!AdMobManager.canRequestAds()) return
    val context = LocalContext.current
    val widthDp = LocalConfiguration.current.screenWidthDp
    var adLoaded by remember { mutableStateOf(false) }

    val adView = remember(widthDp) {
        AdView(context).apply {
            adUnitId = AdMobManager.bannerUnitId()
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp))
            adListener = object : AdListener() {
                override fun onAdLoaded() { adLoaded = true }
                override fun onAdFailedToLoad(err: LoadAdError) { adLoaded = false }
            }
            loadAd(AdRequest.Builder().build())
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        if (adLoaded) {
            AndroidView(factory = { adView }, modifier = Modifier.fillMaxWidth())
        } else {
            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}

@Composable
fun NativeAdBanner(modifier: Modifier = Modifier) {
    if (!AdMobManager.canRequestAds()) return
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        AdMobManager.loadNativeAd(
            context = context,
            onLoaded = { ad ->
                nativeAd?.destroy()
                nativeAd = ad
            },
            onFailed = { /* Keep screen clean on load failure */ }
        )
        onDispose {
            nativeAd?.destroy()
            nativeAd = null
        }
    }

    val ad = nativeAd ?: return
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx ->
            val view = LayoutInflater.from(ctx).inflate(R.layout.native_ad_layout, null) as NativeAdView
            val headlineView = view.findViewById<TextView>(R.id.ad_headline)
            val bodyView = view.findViewById<TextView>(R.id.ad_body)
            val ctaView = view.findViewById<AndroidNativeButton>(R.id.ad_call_to_action)
            val iconView = view.findViewById<ImageView>(R.id.ad_app_icon)

            headlineView.text = ad.headline
            bodyView.text = ad.body ?: ""
            ctaView.text = ad.callToAction ?: "Learn More"
            ad.icon?.drawable?.let { iconView.setImageDrawable(it) }

            view.headlineView = headlineView
            view.bodyView = bodyView
            view.callToActionView = ctaView
            view.iconView = iconView
            view.setNativeAd(ad)
            view
        }
    )
}

@Composable
fun RewardedPowerUpDialog(
    powerUp: PowerUpType,
    activity: Activity,
    onRewardGranted: (PowerUpType) -> Unit,
    onDismiss: (String?) -> Unit
) {
    var statusText by remember { mutableStateOf("Watch a short video ad to unlock +1 ${powerUp.fullName}.") }
    var isWatching by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!isWatching) onDismiss(null) },
        containerColor = CastlePanel,
        title = { Text("Unlock +1 ${powerUp.fullName}", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(statusText, color = Color.LightGray, fontSize = 13.sp)
            }
        },
        confirmButton = {
            Button(
                enabled = !isWatching,
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = Color.Black),
                onClick = {
                    isWatching = true
                    statusText = "Loading Rewarded Ad..."
                    AdMobManager.showRewarded(
                        activity = activity,
                        onRewardEarnedOnce = {
                            isWatching = false
                            onRewardGranted(powerUp)
                        },
                        onClosedWithoutReward = {
                            isWatching = false
                            onDismiss("Ad closed before completion — reward not granted.")
                        },
                        onUnavailable = {
                            isWatching = false
                            onDismiss("No rewarded ad available right now. Continue playing!")
                        }
                    )
                }
            ) {
                Text("Watch Ad", fontWeight = FontWeight.ExtraBold)
            }
        },
        dismissButton = {
            OutlinedButton(enabled = !isWatching, onClick = { onDismiss(null) }) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RewardedContinueDialog(
    activity: Activity,
    isTimedMode: Boolean,
    onRewardGranted: () -> Unit,
    onDismiss: (String?) -> Unit
) {
    var statusText by remember {
        mutableStateOf(
            if (isTimedMode) "Watch a short video ad to continue from here with +1 Life, 4s Magic Shield, and +20s bonus time."
            else "Watch a short video ad to continue from here with +1 Life and a 4s Magic Shield."
        )
    }
    var isWatching by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!isWatching) onDismiss(null) },
        containerColor = CastlePanel,
        title = { Text("Continue Gameplay", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(statusText, color = Color.LightGray, fontSize = 13.sp)
            }
        },
        confirmButton = {
            Button(
                enabled = !isWatching,
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = Color.Black),
                onClick = {
                    isWatching = true
                    statusText = "Loading Rewarded Ad..."
                    AdMobManager.showRewarded(
                        activity = activity,
                        onRewardEarnedOnce = {
                            isWatching = false
                            onRewardGranted()
                        },
                        onClosedWithoutReward = {
                            isWatching = false
                            onDismiss("Ad closed before completion — reward not granted.")
                        },
                        onUnavailable = {
                            isWatching = false
                            onDismiss("No rewarded ad available right now. Tap Retry anytime!")
                        }
                    )
                }
            ) {
                Text("Watch Ad", fontWeight = FontWeight.ExtraBold)
            }
        },
        dismissButton = {
            OutlinedButton(enabled = !isWatching, onClick = { onDismiss(null) }) {
                Text("Cancel")
            }
        }
    )
}
