package com.educationwithhassan.mathvsbat.model

enum class MathMode(val displayName: String, val symbol: String) {
    ADDITION("Addition", "+"),
    SUBTRACTION("Subtraction", "−"),
    MULTIPLICATION("Multiplication", "×"),
    DIVISION("Division", "÷"),
    MIXED("Mixed Mathematics", "±×÷"),
    CHALLENGE("Timed Challenge", "⏱")
}

enum class DifficultyTier {
    BEGINNER,
    EASY,
    NORMAL,
    HARD,
    VERY_HARD,
    EXPERT,
    MASTER
}

enum class BatType(
    val speedMultiplier: Float,
    val baseHp: Int,
    val basePoints: Int
) {
    SMALL(1.0f, 1, 100),
    SWIFT(1.38f, 1, 130),
    ARMORED(0.78f, 2, 160),
    TRICKY(0.92f, 1, 185),
    BONUS(1.18f, 1, 280)
}

enum class PowerUpType(val label: String, val fullName: String) {
    EXTRA_LIFE("+Life", "Extra Life"),
    TIME_FREEZE("Freeze", "Time Freeze"),
    MATH_HINT("Hint", "Powerful Math Hint"),
    SHIELD("Shield", "Magic Shield"),
    DOUBLE_SCORE("2× Pts", "Double Score")
}

enum class ScreenRoute {
    MENU,
    GAMEPLAY,
    LEVELS,
    MODES,
    DAILY,
    PROFILE,
    HOW_TO_PLAY,
    SETTINGS
}

data class MathQuestion(
    val id: String,
    val expression: String,
    val answer: Int,
    val tier: DifficultyTier
)

data class BatEntity(
    val id: String,
    val type: BatType,
    val lane: Int,
    val xRatio: Float,
    var yRatio: Float,
    val speed: Float,
    var hp: Int,
    val maxHp: Int,
    var question: MathQuestion,
    val spawnedAtMs: Long,
    val points: Int,
    var hitFlash: Float = 0f
)

data class EnergyPulse(
    val id: String,
    val fromX: Float,
    val fromY: Float,
    val toX: Float,
    val toY: Float,
    val isBonus: Boolean,
    var progress: Float = 0f
)

data class LevelConfig(
    val levelNumber: Int,
    val tier: DifficultyTier,
    val title: String,
    val targetBats: Int,
    val waves: Int,
    val baseSpeed: Float,
    val spawnIntervalMs: Long,
    val maxConcurrentBats: Int,
    val startingLives: Int,
    val allowedBats: List<BatType>,
    val completionBonus: Int,
    val hasTutorial: Boolean
)

data class GameSettings(
    val musicEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val language: String = "en"
)

data class SaveData(
    val playerName: String = "Castle Guardian",
    val unlockedLevel: Int = 1,
    val completedStars: Map<Int, Int> = emptyMap(),
    val highestScore: Int = 0,
    val totalScore: Int = 0,
    val totalCorrect: Int = 0,
    val totalIncorrect: Int = 0,
    val totalBatsBanished: Int = 0,
    val selectedMode: MathMode = MathMode.ADDITION,
    val settings: GameSettings = GameSettings(),
    val dailyBestScore: Int = 0,
    val dailyStreak: Int = 0,
    val dailyLastDate: String = "",
    val powerUps: Map<PowerUpType, Int> = mapOf(
        PowerUpType.EXTRA_LIFE to 1,
        PowerUpType.TIME_FREEZE to 1,
        PowerUpType.MATH_HINT to 2,
        PowerUpType.SHIELD to 1,
        PowerUpType.DOUBLE_SCORE to 1
    ),
    val tutorialSeen: Boolean = false
)
