package com.educationwithhassan.mathvsbat.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.educationwithhassan.mathvsbat.audio.SoundManager
import com.educationwithhassan.mathvsbat.data.SaveRepository
import com.educationwithhassan.mathvsbat.engine.LevelRepository
import com.educationwithhassan.mathvsbat.engine.MathQuestionGenerator
import com.educationwithhassan.mathvsbat.model.BatEntity
import com.educationwithhassan.mathvsbat.model.BatType
import com.educationwithhassan.mathvsbat.model.EnergyPulse
import com.educationwithhassan.mathvsbat.model.GameSettings
import com.educationwithhassan.mathvsbat.model.MathMode
import com.educationwithhassan.mathvsbat.model.MathQuestion
import com.educationwithhassan.mathvsbat.model.PowerUpType
import com.educationwithhassan.mathvsbat.model.SaveData
import com.educationwithhassan.mathvsbat.model.ScreenRoute
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

enum class PlayPhase { PLAYING, PAUSED, WON, LOST }

data class GameplayUiState(
    val levelNumber: Int = 1,
    val mode: MathMode = MathMode.ADDITION,
    val isDaily: Boolean = false,
    val phase: PlayPhase = PlayPhase.PLAYING,
    val score: Int = 0,
    val lives: Int = 5,
    val startingLives: Int = 5,
    val defeated: Int = 0,
    val targetBats: Int = 6,
    val correctCount: Int = 0,
    val incorrectCount: Int = 0,
    val combo: Int = 0,
    val answerInput: String = "",
    val feedbackText: String? = null,
    val bats: List<BatEntity> = emptyList(),
    val pulses: List<EnergyPulse> = emptyList(),
    val targetedBatId: String? = null,
    val freezeRemainingSec: Int = 0,
    val shieldRemainingSec: Int = 0,
    val doubleRemainingSec: Int = 0,
    val timedSecondsLeft: Int = 90,
    val revivesUsed: Int = 0
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val saveRepo = SaveRepository(application)
    val soundManager = SoundManager(application)

    private val _route = MutableStateFlow(ScreenRoute.MENU)
    val route: StateFlow<ScreenRoute> = _route.asStateFlow()

    private val _saveData = MutableStateFlow(saveRepo.load())
    val saveData: StateFlow<SaveData> = _saveData.asStateFlow()

    private val _game = MutableStateFlow(GameplayUiState())
    val game: StateFlow<GameplayUiState> = _game.asStateFlow()

    private var loopJob: Job? = null
    private var spawnedCount = 0
    private var spawnAccumulatorMs = 0L
    private var lastSubmitMs = 0L
    private var freezeTimer = 0f
    private var shieldTimer = 0f
    private var doubleTimer = 0f
    private var timedAccumulatorMs = 0L
    private var recordedCorrect = 0
    private var recordedIncorrect = 0
    private var recordedBanished = 0
    private var dailyQueue: List<MathQuestion> = emptyList()
    private val laneX = floatArrayOf(0.19f, 0.39f, 0.61f, 0.81f)

    init {
        soundManager.updateSettings(_saveData.value.settings)
        soundManager.startMusic()
    }

    fun navigate(target: ScreenRoute) {
        soundManager.playClick()
        if (target != ScreenRoute.GAMEPLAY) {
            loopJob?.cancel()
        }
        _route.value = target
    }

    fun startLevel(levelNumber: Int, mode: MathMode = _saveData.value.selectedMode, isDaily: Boolean = false) {
        val cfg = LevelRepository.getLevel(levelNumber)
        spawnedCount = 0
        spawnAccumulatorMs = 2400L
        timedAccumulatorMs = 0L
        freezeTimer = 0f
        shieldTimer = 0f
        doubleTimer = 0f
        recordedCorrect = 0
        recordedIncorrect = 0
        recordedBanished = 0
        dailyQueue = if (isDaily) MathQuestionGenerator.generateDailySet() else emptyList()

        val lives = if (isDaily) 4 else cfg.startingLives
        val target = if (isDaily) 15 else cfg.targetBats
        val initialSeconds = if (isDaily) 90 else if (mode == MathMode.CHALLENGE) 75 else 0

        _game.value = GameplayUiState(
            levelNumber = levelNumber,
            mode = mode,
            isDaily = isDaily,
            phase = PlayPhase.PLAYING,
            lives = lives,
            startingLives = lives,
            targetBats = target,
            timedSecondsLeft = initialSeconds,
            revivesUsed = 0
        )
        _route.value = ScreenRoute.GAMEPLAY
        spawnBat()
        startGameLoop()
    }

    private fun startGameLoop() {
        loopJob?.cancel()
        loopJob = viewModelScope.launch {
            var lastTick = System.currentTimeMillis()
            while (true) {
                delay(16L)
                val now = System.currentTimeMillis()
                val dt = min(0.05f, (now - lastTick) / 1000f)
                lastTick = now
                if (_game.value.phase == PlayPhase.PLAYING) {
                    stepSimulation(dt)
                }
            }
        }
    }

    private fun stepSimulation(dt: Float) {
        val cur = _game.value
        val cfg = LevelRepository.getLevel(cur.levelNumber)

        freezeTimer = max(0f, freezeTimer - dt)
        shieldTimer = max(0f, shieldTimer - dt)
        doubleTimer = max(0f, doubleTimer - dt)

        var nextSecondsLeft = cur.timedSecondsLeft
        if (cur.isDaily || cur.mode == MathMode.CHALLENGE) {
            timedAccumulatorMs += (dt * 1000).toLong()
            if (timedAccumulatorMs >= 1000L) {
                timedAccumulatorMs -= 1000L
                nextSecondsLeft = max(0, nextSecondsLeft - 1)
                if (nextSecondsLeft == 0) {
                    val minNeeded = if (cur.isDaily) 10 else (cur.targetBats * 0.6f).toInt()
                    if (cur.defeated >= minNeeded) {
                        val finalScore = cur.score + 250
                        soundManager.playLevelComplete()
                        recordWin(cur.levelNumber, finalScore, cur.lives >= cur.startingLives, cur.isDaily, cur.correctCount, cur.incorrectCount, cur.defeated)
                        _game.value = cur.copy(phase = PlayPhase.WON, score = finalScore, timedSecondsLeft = 0)
                    } else {
                        soundManager.playGameOver()
                        recordGameOver(cur.score, cur.correctCount, cur.incorrectCount, cur.defeated)
                        _game.value = cur.copy(phase = PlayPhase.LOST, timedSecondsLeft = 0)
                    }
                    return
                }
            }
        }

        spawnAccumulatorMs += (dt * 1000).toLong()
        val interval = if (cur.isDaily) 2400L else cfg.spawnIntervalMs
        if (spawnAccumulatorMs >= interval) {
            spawnAccumulatorMs = 0L
            spawnBat()
        }

        val freezeFactor = if (freezeTimer > 0f) 0.3f else 1f
        var nextLives = cur.lives
        var nextDefeated = cur.defeated
        var nextCombo = cur.combo
        var feedback = cur.feedbackText
        val remaining = mutableListOf<BatEntity>()

        for (bat in cur.bats) {
            val updatedY = bat.yRatio + bat.speed * freezeFactor * dt
            if (updatedY >= 0.775f) {
                if (shieldTimer > 0f) {
                    nextDefeated += 1
                    feedback = "Magic Shield blocked a bat!"
                } else {
                    nextLives = max(0, nextLives - 1)
                    nextCombo = 0
                    soundManager.playDamage()
                    feedback = "Bat reached the castle! -1 Life"
                    if (nextLives > 0) {
                        spawnedCount = max(0, spawnedCount - 1)
                    }
                }
            } else {
                remaining += bat.copy(yRatio = updatedY, hitFlash = max(0f, bat.hitFlash - dt * 4f))
            }
        }

        val pulses = cur.pulses.mapNotNull {
            val p = it.progress + dt * 3.4f
            if (p < 1f) it.copy(progress = p) else null
        }

        var nextPhase = cur.phase
        if (nextLives <= 0) {
            nextPhase = PlayPhase.LOST
            soundManager.playGameOver()
            recordGameOver(cur.score, cur.correctCount, cur.incorrectCount, nextDefeated)
        } else if (nextDefeated >= cur.targetBats && remaining.isEmpty()) {
            nextPhase = PlayPhase.WON
            val finalScore = cur.score + if (cur.isDaily) 350 else cfg.completionBonus
            soundManager.playLevelComplete()
            recordWin(cur.levelNumber, finalScore, nextLives >= cur.startingLives, cur.isDaily, cur.correctCount, cur.incorrectCount, nextDefeated)
            _game.value = cur.copy(
                phase = nextPhase,
                score = finalScore,
                lives = nextLives,
                defeated = nextDefeated,
                bats = emptyList(),
                pulses = pulses,
                timedSecondsLeft = nextSecondsLeft
            )
            return
        }

        val targetId = if (remaining.any { it.id == cur.targetedBatId }) {
            cur.targetedBatId
        } else {
            remaining.maxByOrNull { it.yRatio }?.id
        }

        _game.value = cur.copy(
            phase = nextPhase,
            lives = nextLives,
            defeated = nextDefeated,
            combo = nextCombo,
            bats = remaining,
            pulses = pulses,
            targetedBatId = targetId,
            feedbackText = feedback,
            freezeRemainingSec = freezeTimer.toInt(),
            shieldRemainingSec = shieldTimer.toInt(),
            doubleRemainingSec = doubleTimer.toInt(),
            timedSecondsLeft = nextSecondsLeft
        )
    }

    private fun spawnBat() {
        val cur = _game.value
        if (spawnedCount >= cur.targetBats) return
        val cfg = LevelRepository.getLevel(cur.levelNumber)
        val maxConcurrent = if (cur.isDaily) 3 else cfg.maxConcurrentBats
        if (cur.bats.size >= maxConcurrent) return

        val clearLanes = (0..3).filter { lane ->
            cur.bats.none { it.lane == lane && it.yRatio <= 0.21f }
        }
        if (clearLanes.isEmpty()) return

        val lane = clearLanes.random()
        val type = if (cur.isDaily) {
            if (spawnedCount == 4 || spawnedCount == 11) BatType.BONUS
            else if (spawnedCount >= 10) BatType.TRICKY
            else BatType.SMALL
        } else {
            cfg.allowedBats.random()
        }

        val q = if (cur.isDaily && spawnedCount < dailyQueue.size) {
            dailyQueue[spawnedCount]
        } else {
            MathQuestionGenerator.generate(cur.mode, cfg.tier, type == BatType.TRICKY, spawnedCount)
        }

        val hp = if (type == BatType.ARMORED && cur.levelNumber >= 45) 3 else type.baseHp
        val baseSpeed = if (cur.isDaily) 0.056f else cfg.baseSpeed
        val newBat = BatEntity(
            id = "bat_${System.currentTimeMillis()}_$spawnedCount",
            type = type,
            lane = lane,
            xRatio = laneX[lane],
            yRatio = 0.09f,
            speed = baseSpeed * type.speedMultiplier,
            hp = hp,
            maxHp = hp,
            question = q,
            spawnedAtMs = System.currentTimeMillis(),
            points = type.basePoints
        )
        spawnedCount += 1
        _game.value = cur.copy(
            bats = cur.bats + newBat,
            targetedBatId = cur.targetedBatId ?: newBat.id
        )
    }

    fun appendDigit(d: String) {
        if (_game.value.phase != PlayPhase.PLAYING) return
        soundManager.playClick()
        val cur = _game.value.answerInput
        if (cur.length >= 6) return
        _game.value = _game.value.copy(answerInput = if (cur == "0") d else cur + d)
    }

    fun backspace() {
        soundManager.playClick()
        _game.value = _game.value.copy(answerInput = _game.value.answerInput.dropLast(1))
    }

    fun clearInput() {
        soundManager.playClick()
        _game.value = _game.value.copy(answerInput = "")
    }

    fun submitAnswer() {
        val cur = _game.value
        if (cur.phase != PlayPhase.PLAYING || cur.answerInput.isBlank()) return
        val now = System.currentTimeMillis()
        if (now - lastSubmitMs < 160L) return
        lastSubmitMs = now

        val guess = cur.answerInput.toIntOrNull() ?: return
        val target = cur.bats.find { it.id == cur.targetedBatId }
        val match = if (target?.question?.answer == guess) target else cur.bats.find { it.question.answer == guess }

        if (match != null) {
            soundManager.playCorrect()
            val speedBonus = if (now - match.spawnedAtMs <= 3500L) 50 else 0
            val combo = cur.combo + 1
            val mult = if (doubleTimer > 0f) 2 else 1
            val pulse = EnergyPulse(
                id = "p_$now",
                fromX = 0.5f,
                fromY = 0.72f,
                toX = match.xRatio,
                toY = match.yRatio,
                isBonus = match.type == BatType.BONUS
            )

            if (match.hp > 1) {
                val cfg = LevelRepository.getLevel(cur.levelNumber)
                val updated = cur.bats.map {
                    if (it.id == match.id) it.copy(
                        hp = it.hp - 1,
                        hitFlash = 1f,
                        yRatio = max(0.12f, it.yRatio - 0.08f),
                        question = MathQuestionGenerator.generate(cur.mode, cfg.tier)
                    ) else it
                }
                _game.value = cur.copy(
                    bats = updated,
                    pulses = cur.pulses + pulse,
                    answerInput = "",
                    combo = combo,
                    correctCount = cur.correctCount + 1,
                    score = cur.score + (60 + speedBonus) * mult,
                    feedbackText = "Armor cracked! Solve next equation!"
                )
            } else {
                val pts = (match.points + speedBonus + min(200, (combo - 1) * 25)) * mult
                _game.value = cur.copy(
                    bats = cur.bats.filterNot { it.id == match.id },
                    pulses = cur.pulses + pulse,
                    answerInput = "",
                    combo = combo,
                    defeated = cur.defeated + 1,
                    correctCount = cur.correctCount + 1,
                    score = cur.score + pts,
                    feedbackText = "+$pts Magic Pulse!"
                )
            }
        } else {
            soundManager.playIncorrect()
            _game.value = cur.copy(
                answerInput = "",
                combo = 0,
                incorrectCount = cur.incorrectCount + 1,
                feedbackText = "Try again!"
            )
        }
    }

    fun usePowerUp(type: PowerUpType): Boolean {
        val cur = _game.value
        val count = _saveData.value.powerUps[type] ?: 0
        if (cur.phase != PlayPhase.PLAYING || count <= 0) return false

        when (type) {
            PowerUpType.EXTRA_LIFE -> _game.value = cur.copy(lives = min(6, cur.lives + 1), feedbackText = "Extra Life! +1 Heart")
            PowerUpType.TIME_FREEZE -> {
                freezeTimer = 7f
                _game.value = cur.copy(feedbackText = "Time Freeze active for 7s!")
            }
            PowerUpType.SHIELD -> {
                shieldTimer = 10f
                _game.value = cur.copy(feedbackText = "Magic Shield active for 10s!")
            }
            PowerUpType.DOUBLE_SCORE -> {
                doubleTimer = 12f
                _game.value = cur.copy(feedbackText = "Double Score active for 12s!")
            }
            PowerUpType.MATH_HINT -> {
                val target = cur.bats.find { it.id == cur.targetedBatId } ?: cur.bats.firstOrNull()
                if (target != null) {
                    _game.value = cur.copy(feedbackText = MathQuestionGenerator.hintFor(target.question))
                }
            }
        }
        soundManager.playPowerUp()
        val nextMap = _saveData.value.powerUps.toMutableMap().apply { this[type] = count - 1 }
        persistSave(_saveData.value.copy(powerUps = nextMap))
        return true
    }

    fun continueAfterRewardedAd() {
        val cur = _game.value
        val isTimed = cur.isDaily || cur.mode == MathMode.CHALLENGE
        shieldTimer = 4f
        val safeBats = cur.bats.map { it.copy(yRatio = min(it.yRatio, 0.28f)) }
        spawnedCount = min(spawnedCount, cur.defeated + safeBats.size)
        val bonusSeconds = if (isTimed && cur.timedSecondsLeft <= 0) 20 else cur.timedSecondsLeft

        soundManager.playPowerUp()
        _game.value = cur.copy(
            phase = PlayPhase.PLAYING,
            lives = 1,
            bats = safeBats,
            answerInput = "",
            shieldRemainingSec = 4,
            timedSecondsLeft = bonusSeconds,
            revivesUsed = cur.revivesUsed + 1,
            feedbackText = if (isTimed) "Second Chance! +1 Life, +20s & 4s Shield!" else "Second Chance! +1 Life & 4s Shield!"
        )
    }

    fun grantRewardedPowerUp(type: PowerUpType) {
        soundManager.playPowerUp()
        val nextMap = _saveData.value.powerUps.toMutableMap().apply {
            this[type] = ((this[type] ?: 0) + 1).coerceAtMost(99)
        }
        persistSave(_saveData.value.copy(powerUps = nextMap))
        _game.value = _game.value.copy(feedbackText = "Reward confirmed! +1 ${type.fullName}")
    }

    fun showFeedbackMessage(msg: String) {
        _game.value = _game.value.copy(feedbackText = msg)
    }

    fun setPaused(paused: Boolean) {
        val cur = _game.value
        if (paused && cur.phase == PlayPhase.PLAYING) {
            _game.value = cur.copy(phase = PlayPhase.PAUSED)
        } else if (!paused && cur.phase == PlayPhase.PAUSED) {
            _game.value = cur.copy(phase = PlayPhase.PLAYING)
        }
    }

    fun togglePause() {
        setPaused(_game.value.phase == PlayPhase.PLAYING)
    }

    fun selectMode(mode: MathMode) {
        persistSave(_saveData.value.copy(selectedMode = mode))
    }

    fun updateSettings(settings: GameSettings) {
        soundManager.updateSettings(settings)
        persistSave(_saveData.value.copy(settings = settings))
    }

    fun resetProgress() {
        val fresh = saveRepo.reset()
        soundManager.updateSettings(fresh.settings)
        _saveData.value = fresh
    }

    private fun recordWin(
        level: Int,
        score: Int,
        fullLives: Boolean,
        isDaily: Boolean,
        correct: Int,
        incorrect: Int,
        banished: Int
    ) {
        val dCorrect = (correct - recordedCorrect).coerceAtLeast(0)
        val dIncorrect = (incorrect - recordedIncorrect).coerceAtLeast(0)
        val dBanished = (banished - recordedBanished).coerceAtLeast(0)
        recordedCorrect = correct
        recordedIncorrect = incorrect
        recordedBanished = banished

        val s = _saveData.value
        val stars = if (fullLives) 3 else 2
        val updatedStars = s.completedStars.toMutableMap().apply {
            this[level] = max(this[level] ?: 0, stars)
        }
        val nextSave = s.copy(
            unlockedLevel = if (isDaily) s.unlockedLevel else min(100, max(s.unlockedLevel, level + 1)),
            completedStars = updatedStars,
            highestScore = max(s.highestScore, score),
            totalScore = s.totalScore + score,
            totalCorrect = s.totalCorrect + dCorrect,
            totalIncorrect = s.totalIncorrect + dIncorrect,
            totalBatsBanished = s.totalBatsBanished + dBanished,
            dailyBestScore = if (isDaily) max(s.dailyBestScore, score) else s.dailyBestScore,
            dailyStreak = if (isDaily) s.dailyStreak + 1 else s.dailyStreak,
            dailyLastDate = if (isDaily) MathQuestionGenerator.todayKey() else s.dailyLastDate
        )
        persistSave(nextSave)
    }

    private fun recordGameOver(score: Int, correct: Int, incorrect: Int, banished: Int) {
        val dCorrect = (correct - recordedCorrect).coerceAtLeast(0)
        val dIncorrect = (incorrect - recordedIncorrect).coerceAtLeast(0)
        val dBanished = (banished - recordedBanished).coerceAtLeast(0)
        recordedCorrect = correct
        recordedIncorrect = incorrect
        recordedBanished = banished

        val s = _saveData.value
        persistSave(
            s.copy(
                highestScore = max(s.highestScore, score),
                totalCorrect = s.totalCorrect + dCorrect,
                totalIncorrect = s.totalIncorrect + dIncorrect,
                totalBatsBanished = s.totalBatsBanished + dBanished
            )
        )
    }

    private fun persistSave(next: SaveData) {
        _saveData.value = next
        saveRepo.save(next)
    }

    fun onAppPause() {
        setPaused(true)
        soundManager.stopMusic()
    }

    fun onAppResume() {
        soundManager.startMusic()
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
