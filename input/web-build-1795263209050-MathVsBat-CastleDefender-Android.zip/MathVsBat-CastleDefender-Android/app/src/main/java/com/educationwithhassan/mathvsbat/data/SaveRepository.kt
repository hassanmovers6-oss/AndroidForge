package com.educationwithhassan.mathvsbat.data

import android.content.Context
import com.educationwithhassan.mathvsbat.model.GameSettings
import com.educationwithhassan.mathvsbat.model.MathMode
import com.educationwithhassan.mathvsbat.model.PowerUpType
import com.educationwithhassan.mathvsbat.model.SaveData
import org.json.JSONObject

class SaveRepository(context: Context) {
    private val prefs = context.getSharedPreferences("math_vs_bat_save_v1", Context.MODE_PRIVATE)

    fun load(): SaveData {
        val raw = prefs.getString("save_json", null) ?: return SaveData()
        return try {
            val root = JSONObject(raw)
            val starsMap = mutableMapOf<Int, Int>()
            val starsObj = root.optJSONObject("completedStars")
            starsObj?.keys()?.forEach { key ->
                key.toIntOrNull()?.let { lvl -> starsMap[lvl] = starsObj.optInt(key, 1) }
            }

            val powerMap = mutableMapOf<PowerUpType, Int>()
            val pObj = root.optJSONObject("powerUps")
            PowerUpType.entries.forEach { p ->
                powerMap[p] = pObj?.optInt(p.name, 1) ?: 1
            }

            val sObj = root.optJSONObject("settings")
            val settings = GameSettings(
                musicEnabled = sObj?.optBoolean("musicEnabled", true) ?: true,
                soundEnabled = sObj?.optBoolean("soundEnabled", true) ?: true,
                vibrationEnabled = sObj?.optBoolean("vibrationEnabled", true) ?: true,
                language = sObj?.optString("language", "en") ?: "en"
            )

            SaveData(
                playerName = root.optString("playerName", "Castle Guardian"),
                unlockedLevel = root.optInt("unlockedLevel", 1).coerceIn(1, 100),
                completedStars = starsMap,
                highestScore = root.optInt("highestScore", 0),
                totalScore = root.optInt("totalScore", 0),
                totalCorrect = root.optInt("totalCorrect", 0),
                totalIncorrect = root.optInt("totalIncorrect", 0),
                totalBatsBanished = root.optInt("totalBatsBanished", 0),
                selectedMode = MathMode.entries.firstOrNull {
                    it.name == root.optString("selectedMode", "ADDITION")
                } ?: MathMode.ADDITION,
                settings = settings,
                dailyBestScore = root.optInt("dailyBestScore", 0),
                dailyStreak = root.optInt("dailyStreak", 0),
                dailyLastDate = root.optString("dailyLastDate", ""),
                powerUps = powerMap,
                tutorialSeen = root.optBoolean("tutorialSeen", false)
            )
        } catch (_: Exception) {
            SaveData()
        }
    }

    fun save(data: SaveData) {
        val root = JSONObject().apply {
            put("playerName", data.playerName)
            put("unlockedLevel", data.unlockedLevel)
            put("highestScore", data.highestScore)
            put("totalScore", data.totalScore)
            put("totalCorrect", data.totalCorrect)
            put("totalIncorrect", data.totalIncorrect)
            put("totalBatsBanished", data.totalBatsBanished)
            put("selectedMode", data.selectedMode.name)
            put("dailyBestScore", data.dailyBestScore)
            put("dailyStreak", data.dailyStreak)
            put("dailyLastDate", data.dailyLastDate)
            put("tutorialSeen", data.tutorialSeen)

            val starsObj = JSONObject()
            data.completedStars.forEach { (k, v) -> starsObj.put(k.toString(), v) }
            put("completedStars", starsObj)

            val powerObj = JSONObject()
            data.powerUps.forEach { (k, v) -> powerObj.put(k.name, v) }
            put("powerUps", powerObj)

            put("settings", JSONObject().apply {
                put("musicEnabled", data.settings.musicEnabled)
                put("soundEnabled", data.settings.soundEnabled)
                put("vibrationEnabled", data.settings.vibrationEnabled)
                put("language", data.settings.language)
            })
        }
        prefs.edit().putString("save_json", root.toString()).apply()
    }

    fun reset(): SaveData {
        val fresh = SaveData()
        save(fresh)
        return fresh
    }
}
