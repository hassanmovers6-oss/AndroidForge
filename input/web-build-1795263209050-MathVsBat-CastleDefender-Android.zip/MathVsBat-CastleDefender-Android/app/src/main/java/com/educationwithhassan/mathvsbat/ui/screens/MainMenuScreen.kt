package com.educationwithhassan.mathvsbat.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.mathvsbat.model.SaveData
import com.educationwithhassan.mathvsbat.model.ScreenRoute
import com.educationwithhassan.mathvsbat.ui.components.AdaptiveBannerAd
import com.educationwithhassan.mathvsbat.ui.theme.*
import com.educationwithhassan.mathvsbat.ui.viewmodel.GameViewModel

@Composable
fun MainMenuScreen(viewModel: GameViewModel, saveData: SaveData) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1126), Color(0xFF1A2752)))),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.weight(1f).padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { viewModel.navigate(ScreenRoute.PROFILE) }) {
                    Column {
                        Text(saveData.playerName, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Lv ${saveData.unlockedLevel}/100 · Stats", fontSize = 12.sp, color = ArcaneCyan)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        viewModel.updateSettings(saveData.settings.copy(musicEnabled = !saveData.settings.musicEnabled))
                    }) { Text(if (saveData.settings.musicEnabled) "Music ON" else "Music OFF", fontSize = 11.sp) }
                    TextButton(onClick = {
                        viewModel.updateSettings(saveData.settings.copy(soundEnabled = !saveData.settings.soundEnabled))
                    }) { Text(if (saveData.settings.soundEnabled) "SFX ON" else "SFX OFF", fontSize = 11.sp) }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Math vs Bat", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Castle Defender", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = ArcaneCyan)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Best: ${saveData.highestScore} · Total: ${saveData.totalScore}",
                    color = AmberGold,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { viewModel.startLevel(saveData.unlockedLevel) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAction, contentColor = Color.Black),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("PLAY LEVEL ${saveData.unlockedLevel} (${saveData.selectedMode.displayName})", fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { viewModel.navigate(ScreenRoute.LEVELS) }, modifier = Modifier.weight(1f)) { Text("Levels") }
                    Button(onClick = { viewModel.navigate(ScreenRoute.MODES) }, modifier = Modifier.weight(1f)) { Text("Modes") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { viewModel.navigate(ScreenRoute.DAILY) }, modifier = Modifier.weight(1f)) { Text("Daily") }
                    Button(onClick = { viewModel.navigate(ScreenRoute.HOW_TO_PLAY) }, modifier = Modifier.weight(1f)) { Text("How To Play") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { viewModel.navigate(ScreenRoute.PROFILE) }, modifier = Modifier.weight(1f)) { Text("Profile") }
                    OutlinedButton(onClick = { viewModel.navigate(ScreenRoute.SETTINGS) }, modifier = Modifier.weight(1f)) { Text("Settings") }
                }
            }
        }

        AdaptiveBannerAd()
    }
}
