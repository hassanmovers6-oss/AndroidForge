package com.educationwithhassan.mathvsbat.engine

import com.educationwithhassan.mathvsbat.model.DifficultyTier
import com.educationwithhassan.mathvsbat.model.MathMode
import com.educationwithhassan.mathvsbat.model.MathQuestion
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object MathQuestionGenerator {
    private val seq = AtomicLong(0L)

    fun tierForLevel(level: Int): DifficultyTier = when {
        level <= 5 -> DifficultyTier.BEGINNER
        level <= 15 -> DifficultyTier.EASY
        level <= 30 -> DifficultyTier.NORMAL
        level <= 50 -> DifficultyTier.HARD
        level <= 70 -> DifficultyTier.VERY_HARD
        level <= 90 -> DifficultyTier.EXPERT
        else -> DifficultyTier.MASTER
    }

    fun generate(
        mode: MathMode,
        tier: DifficultyTier,
        isTricky: Boolean = false,
        challengeStep: Int = 0,
        rng: Random = Random.Default
    ): MathQuestion {
        val op = when (mode) {
            MathMode.ADDITION -> '+'
            MathMode.SUBTRACTION -> '-'
            MathMode.MULTIPLICATION -> '×'
            MathMode.DIVISION -> '÷'
            MathMode.MIXED, MathMode.CHALLENGE -> {
                val pool = if (tier == DifficultyTier.BEGINNER) {
                    listOf('+', '-')
                } else {
                    listOf('+', '-', '×', '÷')
                }
                pool[rng.nextInt(pool.size)]
            }
        }

        val tiers = DifficultyTier.entries
        var idx = tiers.indexOf(tier)
        if (mode == MathMode.CHALLENGE) {
            idx = min(tiers.lastIndex, max(idx, challengeStep / 4))
        }
        if (isTricky) {
            idx = min(tiers.lastIndex, idx + 1)
        }
        val effectiveTier = tiers[idx]
        val id = "q_${seq.incrementAndGet()}"

        if ((isTricky || mode == MathMode.CHALLENGE) && idx >= 3 && rng.nextFloat() < 0.35f) {
            val a = rng.nextInt(3, 13 + idx * 2)
            val b = rng.nextInt(2, 10 + idx)
            val c = rng.nextInt(5, 26 + idx * 8)
            return if (rng.nextBoolean()) {
                MathQuestion(id, "($a × $b) + $c", a * b + c, effectiveTier)
            } else {
                val prod = a * b
                val sub = rng.nextInt(2, max(3, prod))
                MathQuestion(id, "($a × $b) - $sub", prod - sub, effectiveTier)
            }
        }

        return when (op) {
            '+' -> {
                val (minVal, maxVal) = when (effectiveTier) {
                    DifficultyTier.BEGINNER -> 2 to 12
                    DifficultyTier.EASY -> 8 to 35
                    DifficultyTier.NORMAL -> 18 to 95
                    DifficultyTier.HARD -> 45 to 260
                    DifficultyTier.VERY_HARD -> 120 to 580
                    DifficultyTier.EXPERT -> 320 to 980
                    DifficultyTier.MASTER -> 650 to 1850
                }
                val a = rng.nextInt(minVal, maxVal + 1)
                val b = rng.nextInt(minVal, maxVal + 1)
                MathQuestion(id, "$a + $b", a + b, effectiveTier)
            }
            '-' -> {
                val (minA, maxA) = when (effectiveTier) {
                    DifficultyTier.BEGINNER -> 5 to 20
                    DifficultyTier.EASY -> 15 to 55
                    DifficultyTier.NORMAL -> 40 to 150
                    DifficultyTier.HARD -> 110 to 420
                    DifficultyTier.VERY_HARD -> 250 to 750
                    DifficultyTier.EXPERT -> 480 to 1250
                    DifficultyTier.MASTER -> 800 to 2400
                }
                val a = rng.nextInt(minA, maxA + 1)
                val b = rng.nextInt(max(1, (minA * 0.3).toInt()), a)
                MathQuestion(id, "$a - $b", a - b, effectiveTier)
            }
            '×' -> {
                val (aRange, bRange) = when (effectiveTier) {
                    DifficultyTier.BEGINNER -> (2..5) to (2..5)
                    DifficultyTier.EASY -> (2..9) to (2..9)
                    DifficultyTier.NORMAL -> (4..12) to (3..12)
                    DifficultyTier.HARD -> (11..24) to (4..15)
                    DifficultyTier.VERY_HARD -> (14..35) to (6..18)
                    DifficultyTier.EXPERT -> (22..65) to (8..22)
                    DifficultyTier.MASTER -> (35..125) to (11..25)
                }
                val a = rng.nextInt(aRange.first, aRange.last + 1)
                val b = rng.nextInt(bRange.first, bRange.last + 1)
                MathQuestion(id, "$a × $b", a * b, effectiveTier)
            }
            else -> {
                val (dRange, qRange) = when (effectiveTier) {
                    DifficultyTier.BEGINNER -> (2..5) to (2..6)
                    DifficultyTier.EASY -> (2..9) to (2..10)
                    DifficultyTier.NORMAL -> (3..12) to (4..14)
                    DifficultyTier.HARD -> (6..15) to (6..18)
                    DifficultyTier.VERY_HARD -> (8..18) to (9..24)
                    DifficultyTier.EXPERT -> (11..22) to (11..30)
                    DifficultyTier.MASTER -> (12..28) to (14..42)
                }
                val divisor = rng.nextInt(dRange.first, dRange.last + 1)
                val quotient = rng.nextInt(qRange.first, qRange.last + 1)
                val dividend = divisor * quotient
                MathQuestion(id, "$dividend ÷ $divisor", quotient, effectiveTier)
            }
        }
    }

    fun todayKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun generateDailySet(dateKey: String = todayKey(), count: Int = 15): List<MathQuestion> {
        val seed = dateKey.fold(7L) { acc, c -> acc * 31L + c.code }
        val rng = Random(seed)
        val schedule = listOf(
            DifficultyTier.EASY, DifficultyTier.EASY, DifficultyTier.NORMAL,
            DifficultyTier.NORMAL, DifficultyTier.NORMAL, DifficultyTier.HARD,
            DifficultyTier.HARD, DifficultyTier.HARD, DifficultyTier.VERY_HARD,
            DifficultyTier.VERY_HARD, DifficultyTier.VERY_HARD, DifficultyTier.EXPERT,
            DifficultyTier.EXPERT, DifficultyTier.MASTER, DifficultyTier.MASTER
        )
        return (0 until count).map { idx ->
            generate(
                mode = MathMode.MIXED,
                tier = schedule[min(idx, schedule.lastIndex)],
                isTricky = idx >= 10,
                rng = rng
            )
        }
    }

    fun hintFor(question: MathQuestion): String {
        val ans = question.answer
        if (ans < 10) {
            return "Hint: Single digit (${if (ans % 2 == 0) "Even" else "Odd"})"
        }
        val low = (ans / 10) * 10
        return "Hint: Between $low–${low + 10} · Ends in ${abs(ans) % 10}"
    }
}
