package com.educationwithhassan.mathvsbat.engine

import com.educationwithhassan.mathvsbat.model.BatType
import com.educationwithhassan.mathvsbat.model.DifficultyTier
import com.educationwithhassan.mathvsbat.model.LevelConfig
import kotlin.math.min
import kotlin.math.roundToInt

object LevelRepository {
    val allLevels: List<LevelConfig> = (1..100).map { levelNum ->
        val tier = MathQuestionGenerator.tierForLevel(levelNum)
        val progress = (levelNum - 1) / 99f
        val allowed = mutableListOf(BatType.SMALL)
        if (levelNum >= 3) allowed += BatType.BONUS
        if (levelNum >= 5) allowed += BatType.SWIFT
        if (levelNum >= 10) allowed += BatType.ARMORED
        if (levelNum >= 18) allowed += BatType.TRICKY

        val label = when (tier) {
            DifficultyTier.BEGINNER -> "Moonlit Gate"
            DifficultyTier.EASY -> "Silver Drawbridge"
            DifficultyTier.NORMAL -> "Twilight Battlement"
            DifficultyTier.HARD -> "Thunder Keep"
            DifficultyTier.VERY_HARD -> "Arcane Citadel"
            DifficultyTier.EXPERT -> "Dragonstone Hold"
            DifficultyTier.MASTER -> "Celestial Throne"
        }

        LevelConfig(
            levelNumber = levelNum,
            tier = tier,
            title = "$label $levelNum",
            targetBats = (6 + progress * 22).roundToInt(),
            waves = min(5, 2 + levelNum / 22),
            baseSpeed = 0.048f + progress * 0.044f,
            spawnIntervalMs = (3400 - progress * 1750).toLong(),
            maxConcurrentBats = when {
                levelNum <= 3 -> 2
                levelNum <= 15 -> 3
                else -> 4
            },
            startingLives = when {
                levelNum <= 15 -> 5
                levelNum <= 60 -> 4
                else -> 3
            },
            allowedBats = allowed,
            completionBonus = 100 + levelNum * 15,
            hasTutorial = levelNum == 1
        )
    }

    fun getLevel(levelNumber: Int): LevelConfig =
        allLevels[(levelNumber.coerceIn(1, 100)) - 1]
}
