package com.educationwithhassan.mathvsbat.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.educationwithhassan.mathvsbat.BuildConfig
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Centralized AdMob Manager for com.educationwithhassan.mathvsbat.
 * Implements all 5 formats: App Open, Adaptive Banner, Interstitial, Native Advanced, and Rewarded.
 * Debug builds automatically select Google's official Test IDs; Release builds use supplied Production IDs.
 */
object AdMobManager : DefaultLifecycleObserver {

    // Supplied Production Ad Unit IDs (Release builds)
    private const val PROD_APP_OPEN_ID = "ca-app-pub-3133971041724338/8379002010"
    private const val PROD_BANNER_ID = "ca-app-pub-3133971041724338/9142781786"
    private const val PROD_INTERSTITIAL_ID = "ca-app-pub-3133971041724338/7638128425"
    private const val PROD_NATIVE_ID = "ca-app-pub-3133971041724338/7520999346"
    private const val PROD_REWARDED_ID = "ca-app-pub-3133971041724338/1281884898"

    // Official Google AdMob Test Ad Unit IDs (Debug builds)
    private const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    private const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    private const val APP_OPEN_COOLDOWN_MS = 4L * 60L * 60L * 1000L // 4 hours
    private const val INTERSTITIAL_COOLDOWN_MS = 3L * 60L * 1000L // 3 minutes
    private const val INTERSTITIAL_EVERY_N_LEVELS = 3

    private val handler = Handler(Looper.getMainLooper())
    private val isMobileAdsInitialized = AtomicBoolean(false)
    private val isShowingFullscreen = AtomicBoolean(false)

    private var currentActivityRef: WeakReference<Activity>? = null
    private var isGameplayActive: Boolean = false
    private var consentInformation: ConsentInformation? = null

    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadedAtMs: Long = 0L
    private var lastAppOpenShownAtMs: Long = 0L

    private var interstitialAd: InterstitialAd? = null
    private var lastInterstitialShownAtMs: Long = 0L
    private var levelsCompletedCounter: Int = 0
    private var interstitialRetryCount: Int = 0

    private var rewardedAd: RewardedAd? = null
    private var rewardedRetryCount: Int = 0
    private var lastFullscreenEndedAtMs: Long = 0L

    fun appOpenUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_APP_OPEN_ID else PROD_APP_OPEN_ID
    fun bannerUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_BANNER_ID else PROD_BANNER_ID
    fun interstitialUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_INTERSTITIAL_ID else PROD_INTERSTITIAL_ID
    fun nativeUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_NATIVE_ID else PROD_NATIVE_ID
    fun rewardedUnitId(): String = if (BuildConfig.USE_TEST_ADS) TEST_REWARDED_ID else PROD_REWARDED_ID

    fun setCurrentActivity(activity: Activity?) {
        currentActivityRef = if (activity != null) WeakReference(activity) else null
    }

    fun setGameplayActive(active: Boolean) {
        isGameplayActive = active
    }

    fun canRequestAds(): Boolean = consentInformation?.canRequestAds() ?: true

    fun initialize(activity: Activity) {
        setCurrentActivity(activity)
        val params = ConsentRequestParameters.Builder().build()
        val info = UserMessagingPlatform.getConsentInformation(activity)
        consentInformation = info

        info.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                    if (info.canRequestAds()) {
                        startMobileAdsSdk(activity.applicationContext)
                    }
                }
            },
            {
                // Offline or UMP error: keep game 100% playable without crashing
                if (info.canRequestAds()) {
                    startMobileAdsSdk(activity.applicationContext)
                }
            }
        )
    }

    fun showPrivacyOptionsForm(activity: Activity, onComplete: () -> Unit) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ ->
            onComplete()
        }
    }

    private fun startMobileAdsSdk(context: Context) {
        if (!isMobileAdsInitialized.compareAndSet(false, true)) return
        try {
            MobileAds.initialize(context) {
                loadAppOpen(context)
                loadInterstitial(context)
                loadRewarded(context)
            }
        } catch (_: Exception) {
            isMobileAdsInitialized.set(false)
        }
    }

    // ---------------- APP OPEN ----------------
    fun loadAppOpen(context: Context) {
        if (!canRequestAds() || appOpenAd != null) return
        AppOpenAd.load(
            context,
            appOpenUnitId(),
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    appOpenLoadedAtMs = System.currentTimeMillis()
                }
                override fun onAdFailedToLoad(err: LoadAdError) {
                    appOpenAd = null
                }
            }
        )
    }

    override fun onStart(owner: LifecycleOwner) {
        val activity = currentActivityRef?.get() ?: return
        showAppOpenIfEligible(activity)
    }

    fun showAppOpenIfEligible(activity: Activity) {
        val now = System.currentTimeMillis()
        if (isGameplayActive || isShowingFullscreen.get()) return
        if (now - lastAppOpenShownAtMs < APP_OPEN_COOLDOWN_MS) return
        if (now - lastFullscreenEndedAtMs < 60_000L) return

        val ad = appOpenAd
        if (ad == null || now - appOpenLoadedAtMs > APP_OPEN_COOLDOWN_MS) {
            appOpenAd = null
            loadAppOpen(activity.applicationContext)
            return
        }

        isShowingFullscreen.set(true)
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isShowingFullscreen.set(false)
                lastAppOpenShownAtMs = System.currentTimeMillis()
                lastFullscreenEndedAtMs = System.currentTimeMillis()
                loadAppOpen(activity.applicationContext)
            }
            override fun onAdFailedToShowFullScreenContent(err: AdError) {
                appOpenAd = null
                isShowingFullscreen.set(false)
                loadAppOpen(activity.applicationContext)
            }
        }
        ad.show(activity)
    }

    // ---------------- INTERSTITIAL ----------------
    fun loadInterstitial(context: Context) {
        if (!canRequestAds() || interstitialAd != null) return
        InterstitialAd.load(
            context,
            interstitialUnitId(),
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    interstitialRetryCount = 0
                }
                override fun onAdFailedToLoad(err: LoadAdError) {
                    interstitialAd = null
                    val delayMs = (5000L * (1 shl interstitialRetryCount.coerceAtMost(4)))
                    interstitialRetryCount++
                    handler.postDelayed({ loadInterstitial(context.applicationContext) }, delayMs)
                }
            }
        )
    }

    fun maybeShowInterstitialAfterLevelWin(activity: Activity?, onDone: () -> Unit) {
        levelsCompletedCounter++
        val now = System.currentTimeMillis()
        val ad = interstitialAd
        if (
            activity == null ||
            ad == null ||
            isShowingFullscreen.get() ||
            levelsCompletedCounter < INTERSTITIAL_EVERY_N_LEVELS ||
            now - lastInterstitialShownAtMs < INTERSTITIAL_COOLDOWN_MS ||
            now - lastFullscreenEndedAtMs < 45_000L
        ) {
            onDone()
            return
        }

        levelsCompletedCounter = 0
        isShowingFullscreen.set(true)
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                isShowingFullscreen.set(false)
                lastInterstitialShownAtMs = System.currentTimeMillis()
                lastFullscreenEndedAtMs = System.currentTimeMillis()
                loadInterstitial(activity.applicationContext)
                onDone()
            }
            override fun onAdFailedToShowFullScreenContent(err: AdError) {
                interstitialAd = null
                isShowingFullscreen.set(false)
                loadInterstitial(activity.applicationContext)
                onDone()
            }
        }
        ad.show(activity)
    }

    // ---------------- REWARDED ----------------
    fun isRewardedReady(): Boolean = rewardedAd != null

    fun loadRewarded(context: Context) {
        if (!canRequestAds() || rewardedAd != null) return
        RewardedAd.load(
            context,
            rewardedUnitId(),
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    rewardedRetryCount = 0
                }
                override fun onAdFailedToLoad(err: LoadAdError) {
                    rewardedAd = null
                    val delayMs = (5000L * (1 shl rewardedRetryCount.coerceAtMost(4)))
                    rewardedRetryCount++
                    handler.postDelayed({ loadRewarded(context.applicationContext) }, delayMs)
                }
            }
        )
    }

    /**
     * Grants reward strictly once inside OnUserEarnedRewardListener.
     * Never grants reward on open, failure, or early dismissal.
     */
    fun showRewarded(
        activity: Activity?,
        onRewardEarnedOnce: () -> Unit,
        onClosedWithoutReward: () -> Unit,
        onUnavailable: () -> Unit
    ) {
        val ad = rewardedAd
        if (activity == null || ad == null || isShowingFullscreen.get()) {
            activity?.let { loadRewarded(it.applicationContext) }
            onUnavailable()
            return
        }

        val rewardDelivered = AtomicBoolean(false)
        isShowingFullscreen.set(true)

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                isShowingFullscreen.set(false)
                lastFullscreenEndedAtMs = System.currentTimeMillis()
                loadRewarded(activity.applicationContext)
                if (!rewardDelivered.get()) {
                    onClosedWithoutReward()
                }
            }
            override fun onAdFailedToShowFullScreenContent(err: AdError) {
                rewardedAd = null
                isShowingFullscreen.set(false)
                loadRewarded(activity.applicationContext)
                onUnavailable()
            }
        }

        ad.show(activity) { _ ->
            if (rewardDelivered.compareAndSet(false, true)) {
                onRewardEarnedOnce()
            }
        }
    }

    // ---------------- NATIVE ADVANCED ----------------
    fun loadNativeAd(
        context: Context,
        onLoaded: (NativeAd) -> Unit,
        onFailed: () -> Unit
    ) {
        if (!canRequestAds()) {
            onFailed()
            return
        }
        val loader = AdLoader.Builder(context, nativeUnitId())
            .forNativeAd { nativeAd -> onLoaded(nativeAd) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(err: LoadAdError) {
                    onFailed()
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build()
            )
            .build()
        loader.loadAd(AdRequest.Builder().build())
    }
}
